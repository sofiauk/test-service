# FTM Program Performance Service
[![Build Status](https://jenkins-rqs-common.origin-ctc-core.optum.com/buildStatus/icon?job=RQNS%2FRQNS%2Fprospective-ftm-program-performance%2Fmaster)](https://jenkins-rqs-common.origin-ctc-core.optum.com/job/RQNS/job/RQNS/job/prospective-ftm-program-performance/job/master/)

#To enable swagger added below properties in application.properties file
springdoc.swagger-ui.path=/swagger-ui

#Swagger URL
http://{hostname}:{port}/swagger-ui
http://localhost:8080/swagger-ui

#Version
http://localhost:8080/version

#Heartbeat
http://localhost:8080/heartbeat

#To enable version API added version.properties in src/main/resources

#FTM-parent and FTM-boot-starter
If any common dependency required add in FTM-parent pom and FTM-boot-starter
Any common controllers add in FTM-boot-starter

## How to run locally

### Docker
##### using docker-compose
- download the [redis.conf](https://raw.githubusercontent.com/ashutoshkarna03/redis-docker-python/master/config/redis.conf) file in a directory
- add the following docker-compose.yml file in that directory.
docker-compose.yml
```
version: '3'
services:
    redis:
        image: redis:latest
        ports:
            - 6379:6379
        volumes:
            - ./redis.conf:/usr/local/etc/redis.conf
        command: redis-server /usr/local/etc/redis.conf requirepass "redis"
```
- run docker-compose up -d
- Run SpringBoot app `mvn spring-boot:run -Dspring-boot.run.arguments="--jasypt.encryptor.password=Not4Use --server.port=8081" -Pnonprod`
- Run in debug mode `mvn spring-boot:run -Dspring-boot.run.arguments="--jasypt.encryptor.password=Not4Use --server.port=8081" -Dspring-boot.run.jvmArguments="-Xdebug -Xrunjdwp:transport=dt_socket,server=y,suspend=y,address=5005" -Pnonprod`

### For Mac
* Install Redis on your local env-> `brew install redis`
* Start Redis with a command -> `redis-server /usr/local/etc/redis.conf requirepass "redis"`
  or start Redis via Docker -> `docker run --name redis -d -p 6379:6379 redis redis-server --requirepass "redis"`
* Run SpringBoot app `mvn spring-boot:run -Dspring-boot.run.arguments="--jasypt.encryptor.password=Not4Use --server.port=8081" -Pnonprod`

#GCP certs - configuration changes for local setup
* Copy certs from REPO to local machine: https://github.optum.com/RQNS/prospective-ftm-common-certs
* Use local path in spring.gcpkafka.properties.certs.ofc.ssl - certs configuration like below (in application-{env}.yml file)-
* key-store-location: "C:/Users/msoni6/IdeaProjects/Common-Certs/certs/ofc/dev/keystore.jks"
* trust-store-location: "C:/Users/msoni6/IdeaProjects/Common-Certs/certs/ofc/dev/truststore.jks"
