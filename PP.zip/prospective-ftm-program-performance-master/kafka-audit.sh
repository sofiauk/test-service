#!/bin/bash

declare environment=""
declare -a devList=("dev" "dev2" "dev3")
declare -a stageList=("stage" "stage2" "stage3")

declare keystoreUrl="https://github.optum.com/RQNS/prospective-gcp-common-certs/blob/master/certs/common/env/keystore.jks?raw=true"
declare truststoreUrl="https://github.optum.com/RQNS/prospective-gcp-common-certs/blob/master/certs/common/env/truststore.jks?raw=true"

# get all arguments
while getopts ":e:" arg; do
  case "${arg}" in
  		e)
  			environment=${OPTARG}
  			;;
  esac
done

# create keystore and truststore url
if [[ "${devList[*]}" == *$environment* ]];
	then
    keystoreUrl=${keystoreUrl/env/"dev"}
    truststoreUrl=${truststoreUrl/env/"dev"}
elif [[ $environment == "test" ]];
	then
		keystoreUrl=${keystoreUrl/env/"test"}
		truststoreUrl=${truststoreUrl/env/"test"}
elif [[ "${stageList[*]}" == *$environment* ]];
	then
		keystoreUrl=${keystoreUrl/env/"stage"}
		truststoreUrl=${truststoreUrl/env/"stage"}
elif [[ $environment == "prod" ]];
	then
		keystoreUrl=${keystoreUrl/env/"prod"}
		truststoreUrl=${truststoreUrl/env/"prod"}
else
	echo "Environment passed is invalid, kafka-audit-library won't work"
	exit
fi
# download gcp certs and put it in /kafka-audit/gcpcerts
( mkdir -p /kafka-audit/gcpcerts &&
 chmod 777 /kafka-audit/gcpcerts &&
 curl -L -o /kafka-audit/gcpcerts/keystore.jks $keystoreUrl &&
 curl -L -o /kafka-audit/gcpcerts/truststore.jks $truststoreUrl ) ||
(echo "failed to download cert files. Check user permissions or download location $truststoreUrl"
)