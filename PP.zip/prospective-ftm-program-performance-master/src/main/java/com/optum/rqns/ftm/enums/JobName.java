package com.optum.rqns.ftm.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum JobName {
    LOAD_MEMBER_ASSESSMENT("LoadMemberAssessment", 0),
    LOAD_LOB_TARGET_VALUES_AND_ACTUALS("LoadLOBTargetValuesAndActuals", 2),
    RUN_RETURN_RULES("RunReturnRules", 3),
    RUN_REJECT_RULES("RunRejectRules", 4),
    RUN_PAYMENT_RULES("RunPaymentRules", 5),
    RUN_OUTLIER_RULES("RunOutlierRules", 6),
    RUN_SECONDARY_SUBMISSION_RULES("RunSecondarySubmissionRules", 7),
    RUN_CC_GROWTH_RATE("RunCommandCenterGrowthRateAggregates",8),
    LEADER_PERFORMANCE("RunLeaderPerformance",9),
    LOAD_HISTORICAL_LEADER_PERFORMANCE("RunHistoricalLeaderPerformance", 10),
    QFOPERFORMANCE("RunQFOPerformance", 11),
    EMPTY("", 12),
    RUN_NEW_PROVIDER_GROUP_RULES("RunNewProviderGroupRules", 13),
    //LOAD_FUTURE_WEEKLY_TARGETS("LoadFutureWeeklyTargets", 14),  unused Job ,partition can be reused for new job
   // LOG_MEMBER_ASSESSMENT_OPPORTUNITIES("LogMemberAssessmentOpportunities", 15), unused Job ,partition can be reused for new job
    EXPORT_DATA("ExportData", 16),
    RUN_PROVIDERGROUPS_DEPLOYMENTS("RunProviderGroupsDeployments", 17),
    RUN_DEPLOYMENT_RULES("RunDeploymentRules", 18),
    RUN_PAFX_MEMBER_DEPLOYMENT_UPDATES("RunPAFxMemberDeploymentUpdates", 19) ,
    RUN_ELIGIBLE_MEMBER_COUNT("RunEligibleMemberCount", 20) ,
    RUN_WEEKLY_JOBS("RunWeeklyJobs", 21),
    LOAD_HISTORICAL_LOB_TARGET_VALUES_AND_ACTUALS("RunHistoricalDeploymentActuals", 22),
    IDM_GLIDEPATH("RunIDMGlidepathMergeToProvGroupPerf", 23),
    RUN_DERIVED_DEPLOYMENTS ("RunDerivedDeployments", 24),
    RETURN_METRIC_JOB("RunReturnTargetTrackingFieldActionRule",25),
    REJECT_AGING_JOB("RunRejectAgingFieldActionRule",26),
    NEW_PROVIDER_MANUAL_ASSOCIATION_JOB("RunNewProviderManualAssociationFieldActionRule",27),
    RUN_CHANGE_SERVICE_LEVEL_RULE("RunChangeServiceLevelFieldActionRule",28),
    RUN_NEW_PROVIDER_GROUP_MEMBERSHIP("RunNewProviderGroupMembershipFieldActionRule",29),
    AVAIL_MEMBERSHIP_CLIENT_LOB_STATE_RULE("AvailMembershipClientLobStateFieldActionRule",30),
    RUN_WEEKLY_IDM_TARGETS("RunWeeklyIDMTargets", 31),
    RUN_COMMAND_CENTER("RunCommandCenterAggregates", 32),

    RUN_MEMBER_PAYMENT_OVERALL_STATUS_SYNC("RunMemberPaymentOverallStatusSync", 34),
    RUN_CLIENT_GOALS("RunClientGoals", 35),
    QUALITYGAPS_OPPORTUNITIES("RunQualityGapsOpportunities",36),
    SUSPECT_CONDITIONS_OPPORTUNITIES("RunSuspectConditionsOpportunities",37),
    ANNUAL_CARE_OPPORTUNITIES("RunAnnualCareOpportunities",38),

    RUN_WEEKLY_EMODALITY_LOAD("RunWeeklyEModalityLoad", 40),
    LEADER_QUALITY_GAPS_OPPORTUNITIES("RunLeaderQualityGapsOpportunities",41),
    LEADER_ANNUAL_CARE_VISITS_OPPORTUNITIES("RunLeaderAnnualCareVisitsOpportunities",42),
    LEADER_SUSPECT_OPPORTUNITIES("RunLeaderSuspectConditionsOpportunities",43),
    RUN_CPG_ELIGIBLEPROGRAMTYPE_UPDATES("RunCPGEligibleProgramTypeUpdates", 44),
    RUN_KAFKA_ERROR_HANDLING_JOB("RunKafkaErrorHandlingJob",45),
    RUN_QFO_QUALITY_GAPS_OPPORTUNITIES("RunQFOQualityGapsOpportunities",46),
    RUN_QFO_ANNUAL_CARE_OPPORTUNITIES("RunQFOAnnualCareVisitsOpportunities", 47),
    RUN_QFO_SUSPECT_CONDITIONS_OPPORTUNITIES("RunQFOSuspectConditionsOpportunities",48),
    QFO_PATIENT_EXPERIENCE_SCORES("RunQFOPatientExperienceScores",49),
    QFO_HEALTH_SYSTEM_OPPORTUNITIES("RunQFOHealthSystemOppportunities",50),
	RUN_QUALITY_AGGREGATION("RunQualityAggregation",39),
	RUN_SUSPECT_AGGREGATION("RunSuspectAggregation",33),
	RUN_MED_ADHERENCE_AGGREGATION("RunMedAdherenceAggregation",51),
    RUN_MEMBER_SUMMARY_AGGREGATION("RunMemberSummaryAggregation",52),
    RUN_PROVIDER_ELIGIBLE_MEMBERSHIP("RunProviderEligibleMembership", 53),
	RUN_MEMBER_HOSPITAL_EVENTS_AGGREGATION("RunHospitalEventsAggregation", 54);


    private String value;
    private int partitionId;

    public static JobName fromString(String text) {
        for (JobName jobName : JobName.values()) {
            if (jobName.value.equalsIgnoreCase(text)) {
                return jobName;
            }
        }
        return null;
    }
}
