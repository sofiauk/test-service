package com.optum.rqns.ftm.dto.providergrp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.time.LocalDateTime;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ProviderGroupDetailsDTO {
    private String providerGroupName;
    private String providerGroupId;
    private String state;
    private String serviceLevel;
    private String taxId;
    private String ownerType;
    private String ownerName;
    private boolean isNewForDeployment;
    private LocalDateTime lastActivityDate;
    private Boolean engagementOnshoreFlag;
    private Boolean canShowPSCOwner;
}