package com.optum.rqns.ftm.repository.qfo;

import com.optum.rqns.ftm.dto.performance.providergrp.qfo.ProviderGroupPerformanceDetailsDTO;
import com.optum.rqns.ftm.dto.performance.providergrp.qfo.QFOProviderGroupPerformanceDetailsDTO;
import com.optum.rqns.ftm.dto.performance.providergrp.qfo.QFOSuspectConditionsDTO;
import com.optum.rqns.ftm.dto.qfo.QFOGroupStarRatingDTO;
import com.optum.rqns.ftm.dto.qfo.QFOPatientsCoveredDTO;
import com.optum.rqns.ftm.model.qfo.StarRating;
import com.optum.rqns.ftm.model.qfo.SuspectConditionTotal;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Map;

public interface ProviderGroupPerformanceDetailsRepository {
    Mono<ProviderGroupPerformanceDetailsDTO> getPerformanceDetails(String providerGroupId, int programYear);
    Mono<Map<String,String>> getConfigurationValues(int programYear);
    Flux<QFOProviderGroupPerformanceDetailsDTO> getPerformanceDetailsByYear(String providerGroupId, int programYear);
    Mono<QFOSuspectConditionsDTO> getQFOSuspectConditions(String uuid, int programYear);
    Flux<StarRating> getStarRatings(String uuid, int programYear);
    Flux<SuspectConditionTotal> getSuspectConditionTotals(String uuid, int programYear);
    Mono<QFOGroupStarRatingDTO> getGroupsStarRatingDetails(String uuid, int programYear, int rating);
    Mono<QFOPatientsCoveredDTO> getQFOPatientsCoveredDetails(String uuid, int programYear, String teamType);
}
