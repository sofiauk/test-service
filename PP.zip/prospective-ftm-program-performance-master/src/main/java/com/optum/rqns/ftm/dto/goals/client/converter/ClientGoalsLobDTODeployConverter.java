package com.optum.rqns.ftm.dto.goals.client.converter;

import com.optum.rqns.ftm.dto.goals.client.RegionDeployDTO;
import com.optum.rqns.ftm.repository.goals.client.ClientGoalsReactiveRepositoryImpl;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;

public class ClientGoalsLobDTODeployConverter implements Converter<Row, RegionDeployDTO>,DTOConverter {

    @Override
    public RegionDeployDTO convert(Row rs) {

      return RegionDeployDTO.builder()
                .clientName(rs.get(ClientGoalsReactiveRepositoryImpl.ColumnNames.CLIENTNAME.getColumnName(), String.class))
                .region(rs.get(ClientGoalsReactiveRepositoryImpl.ColumnNames.REGIONNAME.getColumnName(), String.class))
                .lob(rs.get(ClientGoalsReactiveRepositoryImpl.ColumnNames.LOBNAME.getColumnName(), String.class))
                .clientId(getIntegerValue(rs, ClientGoalsReactiveRepositoryImpl.ColumnNames.CLIENTID.getColumnName()))
                .state(rs.get(ClientGoalsReactiveRepositoryImpl.ColumnNames.STATENAME.getColumnName(), String.class))
                .stateId(rs.get(ClientGoalsReactiveRepositoryImpl.ColumnNames.STATEID.getColumnName(),String.class))
                .regionId(rs.get(ClientGoalsReactiveRepositoryImpl.ColumnNames.REGIONID.getColumnName(),String.class))
                .hcfa(rs.get(ClientGoalsReactiveRepositoryImpl.ColumnNames.HCFA.getColumnName(), String.class))
                .pbpId(rs.get(ClientGoalsReactiveRepositoryImpl.ColumnNames.PBPID.getColumnName(), String.class))
                .eligibleMembers(getDoubleValue(rs,ClientGoalsReactiveRepositoryImpl.ColumnNames.ELIGIBLEMEMBERS.getColumnName()))
                .deployed(getFloatValue(rs, ClientGoalsReactiveRepositoryImpl.ColumnNames.DEPLOYED.getColumnName()))
                .returned(getFloatValue(rs, ClientGoalsReactiveRepositoryImpl.ColumnNames.RETURNED.getColumnName()))
                .completed(getFloatValue(rs, ClientGoalsReactiveRepositoryImpl.ColumnNames.COMPLETED.getColumnName()))
                .build();
    }
}
