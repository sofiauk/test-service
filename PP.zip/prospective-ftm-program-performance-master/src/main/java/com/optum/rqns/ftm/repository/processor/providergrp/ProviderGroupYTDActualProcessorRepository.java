package com.optum.rqns.ftm.repository.processor.providergrp;

import com.optum.rqns.ftm.dto.processor.providergrp.ProgramYearCalendarDTO;
import reactor.core.publisher.Mono;

import java.util.List;

public interface ProviderGroupYTDActualProcessorRepository {

    Mono<Integer> updatePerformanceTableActualValues(int programYear, ProgramYearCalendarDTO ytdDuration, List<String> lobs);

    Mono<ProgramYearCalendarDTO> getYTDDurationValue(int programYear, boolean isPreviousProgramYear);

    Mono<Integer> updatePerformanceWeeklyTableActualValues(int programYear, ProgramYearCalendarDTO programYearCalendarDTO, List<String> lobs);

    Mono<Integer> setIsCurrentWeekForPerformanceToTrue(ProgramYearCalendarDTO programYearCalendarDTO, boolean isWeekly);

    Mono<Integer> calculateForecastColumnValues(ProgramYearCalendarDTO programYearCalendarDTO);

    Mono<Integer> calculateVarianceValues(ProgramYearCalendarDTO programYearCalendarDTO);

    Mono<Integer> calculateReturnsOpportunityValues(ProgramYearCalendarDTO programYearCalendarDTO);

    Mono<Integer>   getTotalCountforAggerateTargetsRollup(int programYear, ProgramYearCalendarDTO programYearCalendarDTO);

    Mono<Integer> upsertPerformanceTableWithAggregatedTargets(int programYear, ProgramYearCalendarDTO programYearCalendarDTO, Integer currentBeginId, Integer batchSize);

    Mono<Integer> getTotalCountforSpecialRollup(int programYear, ProgramYearCalendarDTO programYearCalendarDTO);

    Mono<Integer> updatePerformanceTableWithSpecialPnoTargets(int programYear, ProgramYearCalendarDTO programYearCalendarDTO, Integer currentBeginId, int batchSize);

}
