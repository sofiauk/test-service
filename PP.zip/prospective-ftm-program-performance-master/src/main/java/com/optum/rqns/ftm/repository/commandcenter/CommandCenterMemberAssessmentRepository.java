package com.optum.rqns.ftm.repository.commandcenter;

import com.optum.rqns.ftm.model.providergrpdeployment.POCConversionCount;
import reactor.core.publisher.Mono;

public interface CommandCenterMemberAssessmentRepository {

    Mono<POCConversionCount> getPOCConversionCounts(int projectYear, boolean checkUtilizingPOC, boolean isNewProviderGroup);

}
