package com.optum.rqns.ftm.controller.qfo;

import com.optum.rqns.ftm.response.qfo.HealthSystemPerformanceDetailsByYearResponse;
import com.optum.rqns.ftm.response.qfo.HealthSystemPerformanceDetailsResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.optum.rqns.ftm.customannotation.CustomApiResponse;
import com.optum.rqns.ftm.enums.TypeEnum;
import com.optum.rqns.ftm.service.qfo.HealthSystemPerformanceService;
import com.optum.rqns.ftm.util.StargateStandardResponseUtilV2;

import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Profile("rqnsFtmApi")
@RestController
@RequestMapping("/v1/qfo/health-systems/")
@Slf4j
@CustomApiResponse
public class HealthSystemPerformanceController {

    @Autowired
    StargateStandardResponseUtilV2<Object, Object> stargateStandardResponseUtilV2;

    @Autowired
    HealthSystemPerformanceService healthSystemPerformanceService;



    @GetMapping("{health-system-id}/performance")
    @ApiResponse(responseCode = "200", description = "Sucess Request",
            content = @Content(schema = @Schema(implementation = HealthSystemPerformanceDetailsResponse.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<HealthSystemPerformanceDetailsResponse> getHealthSystemPerformance(
            @PathVariable("health-system-id") String healthSystemId,
            @RequestParam("program-year") int programYear
    ) {
        log.info("Getting Qfo Health System Performance Details for the given details: {}, {}", healthSystemId, programYear);

        return stargateStandardResponseUtilV2
                .generateStargateStandardResponse(
                		healthSystemPerformanceService.getPerformanceDetails(healthSystemId, programYear)
                        , TypeEnum.MONO
                        , new HealthSystemPerformanceDetailsResponse())
                .cast(HealthSystemPerformanceDetailsResponse.class);
    }

    // New Api For Health System Performance Star Rating
    @GetMapping("{health-system-id}/health-system-performances-by-year")
    @ApiResponse(responseCode = "200", description = "Sucess Request",
            content = @Content(schema = @Schema(implementation = HealthSystemPerformanceDetailsResponse.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<HealthSystemPerformanceDetailsByYearResponse> getHealthSystemPerformanceByYear(
            @PathVariable("health-system-id") String healthSystemId,
            @RequestParam("program-year") int programYear
    ) {
        log.info("Getting Qfo Health System Performance Details for the Given Details: {}, {}", healthSystemId, programYear);

        return stargateStandardResponseUtilV2
                .generateStargateStandardResponse(
                        healthSystemPerformanceService.getHealthSystemPerformanceDetailsByYear(healthSystemId, programYear)
                        , TypeEnum.FLUX
                        , new HealthSystemPerformanceDetailsByYearResponse())
                .cast(HealthSystemPerformanceDetailsByYearResponse.class);
    }

}
