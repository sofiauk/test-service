package com.optum.rqns.ftm.model.programyearcalendar;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CurrentPreviousMonth {
    private String currentMonth;
    private String previousMonth;
    private int isCurrentProgramYear;
}
