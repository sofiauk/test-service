package com.optum.rqns.ftm.model.practiceassist.providerdashboard;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.PositiveOrZero;

@Data
public class ProviderDashboardAggrRequest {

    protected transient static final String TIMEZONE = "America/Chicago";

    @NotNull(message = "'Program Year' is required")
    @PositiveOrZero(message = "'Program Year' is not valid")
    private String pgmAsesYr;
    @NotNull(message = "'uuid' is required")
    private String uuid;
    private UserProfile[] prvGrps;
    private String aco;
    private String[] acoProvGrpId;
    private String healthSystemId;

}
