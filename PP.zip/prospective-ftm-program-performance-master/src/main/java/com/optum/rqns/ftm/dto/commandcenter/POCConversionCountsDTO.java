package com.optum.rqns.ftm.dto.commandcenter;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class POCConversionCountsDTO {

    private Integer existingProviderGroupUtilizingPOCCount;
    private Integer existingProviderGroupEligibleCount;
    private Double existingGoalPercent;
    private Integer newProviderGroupUtilizingPOCCount;
    private Integer newProviderGroupEligibleCount;
    private Double newGoalPercent;
}
