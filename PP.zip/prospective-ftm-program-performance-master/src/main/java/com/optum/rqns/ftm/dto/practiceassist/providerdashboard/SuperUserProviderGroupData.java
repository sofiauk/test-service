package com.optum.rqns.ftm.dto.practiceassist.providerdashboard;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SuperUserProviderGroupData {

    private String providerGroupId;
}
