package com.optum.rqns.ftm.exception;

import com.optum.rqns.ftm.constants.ProviderGroupConstants;
import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum APIErrorCode {
    GENERIC("1001","Something went wrong please contact System Admin", ProviderGroupConstants.INTERNAL_SERVER),
    DATA_ACCESS_EXCEPTION("2001","Unable to read data from Database, please contact System Admin",ProviderGroupConstants.INTERNAL_SERVER),
    CLIENT_GOAL_YEARS_NO_DATA("3001","Client goals data is not available", ProviderGroupConstants.NO_DATA_WARNING),
    CLIENT_GOAL_REGION_NO_DATA("4001","No data for the Goal Type",ProviderGroupConstants.NO_DATA_WARNING),
    CLIENT_GOAL_NO_DATA_FOR_YEAR("5001","Client goals data is not available for the given year",ProviderGroupConstants.NO_DATA_WARNING),
    DB_CONNECTION_EXCEPTION("6001","Unable to connect to Database, please contact System Admin",ProviderGroupConstants.INTERNAL_SERVER),
    INVALID_GOAL_TYPE("7001","Please provide the valid goal type to retrieve goal values",ProviderGroupConstants.INVALID_DATA_WARNING),
    NO_CONTENT("8001","Data not available",ProviderGroupConstants.NO_DATA_WARNING),
    INVALID_MONTH("9001","Please provide the valid Month to retrieve goal values",ProviderGroupConstants.INVALID_DATA_WARNING),
    INVALID_QUARTER("10001","Please provide the valid Quarter to retrieve goal values",ProviderGroupConstants.INVALID_DATA_WARNING),
    NO_DATA_AVAILABLE("11001", "No Data Available", ProviderGroupConstants.NO_DATA_WARNING),
    INVALID_FILTER_TYPE("12001","Please provide the valid filter type to retrieve goal values",ProviderGroupConstants.INVALID_DATA_WARNING),
    INVALID_OPPORTUNITY_TYPE_NAME("12002","Please provide the valid opportunity type","Invalid Opportunity Type Warning"),

    //Provider Group
    PROVIDER_GROUP_PERFORMANCE_NO_DATA_FOR_YEAR("13001","Provider group performance data is not available for the current Program year",ProviderGroupConstants.NO_DATA_WARNING),
    JOB_EXCEPTION_OCCURRED("15001","Job Has been Failed","Job Failed"),
    PROVIDER_GROUP_INVALID_PARAMS("13002", "Please provide valid input parameter values", ProviderGroupConstants.INVALID_DATA_WARNING),
    PROVIDER_GROUP_RETURN_RATE_TARGET("13003","MemberAssesmentHistory data is not available",ProviderGroupConstants.NO_DATA_WARNING),
    NO_PROVIDER_GROUPS("13004","Provider Group data is not available",ProviderGroupConstants.NO_DATA_WARNING),
    PROVIDER_GROUP_PROCESSOR_ACTUAL_CALCULATION_EXCEPTION("13005","Exception occurred while calculating actual ","Data Processing Exception"),
    NO_MEMBER_ASSESSMENT_HISTORY("13006","Member Assessment History data is not available",ProviderGroupConstants.NO_DATA_WARNING),
    INVALID_ROLE_TYPE("13007", "Role type is not avaliable in provider group","Invalid role type"),
    INVALID_BY_TYPE("13008", "Provided By Type is not one of the available options", "Invalid By Type"),
    INVALID_BY_SERVICE_LEVEL("13009", "Provided By Service Level is not one of the available options", "Invalid By Service Level"),
    INVALID_SORT_OPTION("13009", "Provided Sort Option is not one of the available options", "Invalid By Sort Option"),
    PROVIDER_GROUP_NOT_ASSIGNED_TO_USER("14000","Provider Group is not assigned to user",ProviderGroupConstants.NO_DATA_WARNING),

    //Exports
    NO_TRANSACTION_AVAILABLE("17001","Export is not available for the given transactionId ",ProviderGroupConstants.NO_DATA_WARNING),
    INVALID_PROCESS_TYPE("17002","Process Type is Invalid ",ProviderGroupConstants.INVALID_INPUT_PARAMETERS),
    INVALID_PROCESS_SUB_TYPE("17003","Process Sub Type is Invalid ",ProviderGroupConstants.INVALID_INPUT_PARAMETERS),
    INVALID_DOCUMENT_TYPE("17004","Document Type is Invalid   ",ProviderGroupConstants.INVALID_INPUT_PARAMETERS),
    INVALID_STATUS_TO_UPDATE("17005","Status is Invalid, please provide valid status to update  ",ProviderGroupConstants.INVALID_INPUT_PARAMETERS),
    INVALID_STATUS_TO_GET_NOTIFICATIONS("17006","Status is Invalid, provide valid status to get  notifications ",ProviderGroupConstants.INVALID_INPUT_PARAMETERS),
    NO_TRANSACTIONS_AVAILABLE("17007","No exports are updated, either Exports are already updated or no exports available ",ProviderGroupConstants.NO_DATA_WARNING),
    INVALID_TRACE_ID("17008", "TraceId cannot be null",ProviderGroupConstants.NO_DATA_WARNING),
    INVALID_USER_HEADER("9001", "Invalid User details or UUID is missing ", "Invalid User Header"),
    INVALID_PAYLOAD_REQUEST("9018", "Invalid Payload Request or Payload Request is missing ", "Invalid Payload Request"),//need to have some constant

    //Kafka JobEventProducer
    INVALID_JOB_NAME("16001","Job Name is not available in Provider Group Opportunities - Job Name list",ProviderGroupConstants.INVALID_DATA_WARNING),
    INVALID_GROUPS_TO_EXECUTE("16002","GroupsToExecute is not available in  Provider Group Opportunities - GroupsToExecute list",ProviderGroupConstants.INVALID_DATA_WARNING),
    INVALID_EXECUTION_WEEK("16003","ExecutionWeek is not available in Provider Group Opportunities - ExecutionWeek list",ProviderGroupConstants.INVALID_DATA_WARNING),
    KAFKA_PRODUCER_EXCEPTION("16004","Kafka producer exception occurred","Kafka Producer Exception"),
    KAFKA_EXCEPTION("16005","Kafka exception occurred","Kafka Exception"),
    INVALID_JOB_EVENT_DETAILS("16006","Job details are not configured properly",ProviderGroupConstants.INVALID_INPUT),
    UNAUTHORIZED("16007","UnAuthorized!!!","UnAuthorized"),

    //Upload & Download
    UPLOAD_FAILED("16008", "Uploading to S3 bucket failed", "Upload Exception"),
    DOWNLOAD_FAILED("16009", "Downloading from S3 bucket failed", "Download Exception"),
    INVALID_TOKEN("16010","Token received from request is empty or null or invalid","Invalid Token"),
    INVALID_JOB_NAME_INPUT("16011", "Please Provide Job Name", ProviderGroupConstants.INVALID_INPUT),


    REPONSE_LIST_CREATION_FAILED("16012","Response List Creation Failed","Response List Creation Failed"),

    //Landing page
    INVALID_PROVIDER_GROUP_HEALTHSYS_ID("16013", "Missing data in Request: Program Year and UUID or either (Provider Group ID or Health System Id or ACO Provider Group ID) should be provided in a user profile", ProviderGroupConstants.INVALID_INPUT),
    INVALID_STATE("16014", "Missing data in Request: State is mandatory paramater", ProviderGroupConstants.INVALID_INPUT),
    INVALID_SUPER_USER_PROVIDER_GROUP_ID("16014", "Missing data in Request: Program Year and (Sub Client SK & Super User=true) should be provided in a user profile", ProviderGroupConstants.INVALID_INPUT);

    private String code;
    private String detail;
    private String title;

}
