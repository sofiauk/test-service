package com.optum.rqns.ftm.configuration;

import com.optum.rqns.ftm.constants.Constants;
import io.confluent.kafka.serializers.AbstractKafkaSchemaSerDeConfig;
import io.confluent.kafka.serializers.KafkaAvroDeserializerConfig;
import io.confluent.kafka.serializers.KafkaAvroSerializer;
import io.confluent.kafka.serializers.subject.TopicNameStrategy;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.config.SslConfigs;
import org.apache.kafka.common.serialization.Deserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.apache.logging.log4j.core.util.UuidUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.config.KafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.listener.ConcurrentMessageListenerContainer;
import org.springframework.kafka.support.serializer.JsonSerializer;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import static org.springframework.kafka.listener.ContainerProperties.AckMode.MANUAL;

@Configuration
@Slf4j
public class GCPBaseKafkaConfiguration {

    public static final String APPLICATION_PREFIX = "FTM-PROGRAM-PERFORMANCE";// OFC
    public static final String APPLICATION_ENVIRONMENT = "ENV_PROFILES_ACTIVE";

    @Autowired
    protected com.optum.rqns.ftm.configuration.GCPKafkaProperties gcpKafkaProperties;

     /*
    Note: - PAFM Listener
    Instead of gcpProducerFactoryWithKeyStringAndValueJsonSerializer and gcpProducerFactoryKeyJsonAndValueAvroSerializer 2 methods
    Tried with common method with generic Serializer Key and Value Serializer parameters but getting
    - Invalid value org.apache.kafka.common.serialization.StringSerializer@365de5cf for configuration key.serializer: Expected a Class instance or class name.
    - Invalid value org.springframework.kafka.support.serializer.JsonSerializer@465de5cf for configuration key.serializer: Expected a Class instance or class name.
    */
    /**
     * Producer -- input parameter StringSerializer , JsonSerializer
     * @param clientId
     * @param applicationName
     * @param <K>
     * @param <V>
     * @return
     */
    protected <K, V> ProducerFactory<K, V> gcpProducerFactoryWithKeyStringAndValueJsonSerializer(String clientId, String applicationName) {

        Map<String, Object> producerProps = gcpKafkaProperties.buildProducerProperties();

        producerProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        producerProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);

        return gcpCommonProducerFactory(clientId, applicationName, producerProps);
    }

    /**
     * Producer -- StringSerializer, KafkaAvroSerializer
     * @param clientId
     * @param applicationName
     * @param <K>
     * @param <V>
     * @return
     */
    protected <K, V> ProducerFactory<K, V> gcpProducerFactory(String clientId, String applicationName){

        Map<String, Object> producerProps = gcpKafkaProperties.buildProducerProperties();

        producerProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        producerProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, KafkaAvroSerializer.class);

        return gcpCommonProducerFactory(clientId, applicationName, producerProps);

    }

    private <K, V> ProducerFactory<K, V> gcpCommonProducerFactory(String clientId, String applicationName, Map<String, Object> producerProps)  {

        producerProps.put(ProducerConfig.CLIENT_ID_CONFIG, clientId);
        producerProps.put(ProducerConfig.ACKS_CONFIG, "all");

        producerProps.put(ProducerConfig.BATCH_SIZE_CONFIG, Constants.BATCH_SIZE);
        producerProps.put(ProducerConfig.DELIVERY_TIMEOUT_MS_CONFIG, Integer.MAX_VALUE);
        producerProps.put(ProducerConfig.LINGER_MS_CONFIG, Constants.LINGER_MS_CONFIG);
        producerProps.put(ProducerConfig.REQUEST_TIMEOUT_MS_CONFIG, Constants.REQUEST_TIMEOUT_MS_CONFIG);

        //Added BOOTSTRAP_SERVERS_CONFIG -- GCP
        producerProps.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, gcpKafkaProperties.getBootstrapServers());

        //Schema URL SSL
        producerProps.put(Constants.SCHEMA_REGISTRY_SSL_TRUSTSTORE_LOCATION, new File(gcpKafkaProperties.getProperties().get("certs." + applicationName + ".ssl.trust-store-location")).getAbsolutePath());
        producerProps.put(Constants.SCHEMA_REGISTRY_SSL_TRUSTSTORE_PASSWORD,  gcpKafkaProperties.getProperties().get("certs." + applicationName + ".ssl.trust-store-password"));
        producerProps.put(Constants.SCHEMA_REGISTRY_SSL_KEYSTORE_LOCATION, new File(gcpKafkaProperties.getProperties().get("certs." + applicationName + ".ssl.key-store-location")).getAbsolutePath());
        producerProps.put(Constants.SCHEMA_REGISTRY_SSL_KEYSTORE_PASSWORD, gcpKafkaProperties.getProperties().get("certs." + applicationName + ".ssl.key-store-password"));
        producerProps.put(Constants.SCHEMA_REGISTRY_SSL_KEY_PASSWORD, gcpKafkaProperties.getProperties().get("certs." + applicationName + ".ssl.key-password"));

        //configure the following three settings for SSL Encryption
        producerProps.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, gcpKafkaProperties.getProperties().get("security.protocol"));

        //SSL - CERTS - Based on application name loading for Producer
        producerProps.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, new File(gcpKafkaProperties.getProperties().get("certs." + applicationName + ".ssl.trust-store-location")).getAbsolutePath());
        producerProps.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG,  gcpKafkaProperties.getProperties().get("certs." + applicationName + ".ssl.trust-store-password"));

        // configure the following three settings for SSL Authentication
        producerProps.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, new File(gcpKafkaProperties.getProperties().get("certs." + applicationName + ".ssl.key-store-location")).getAbsolutePath());
        producerProps.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, gcpKafkaProperties.getProperties().get("certs." + applicationName + ".ssl.key-store-password"));
        producerProps.put(SslConfigs.SSL_KEY_PASSWORD_CONFIG, gcpKafkaProperties.getProperties().get("certs." + applicationName + ".ssl.key-password"));

        producerProps.put(ProducerConfig.MAX_IN_FLIGHT_REQUESTS_PER_CONNECTION, 1);

        //Set the number of retries - retries
        producerProps.put(ProducerConfig.RETRIES_CONFIG, gcpKafkaProperties.getProperties().get("retries_config"));

        //Request timeout - request.timeout.ms
        producerProps.put(ProducerConfig.REQUEST_TIMEOUT_MS_CONFIG, gcpKafkaProperties.getProperties().get("timeout_config"));

        //Only retry after one second.
        producerProps.put(ProducerConfig.RETRY_BACKOFF_MS_CONFIG, gcpKafkaProperties.getProperties().get("backoff_config"));
        // audit producer interceptor
        // below configs will come from yml file
//        producerProps.put(ProducerConfig.INTERCEPTOR_CLASSES_CONFIG,"com.optum.payer.kafka.audit.recon.interceptor.AuditProducerInterceptor");
//        producerProps.put(com.optum.payer.kafka.audit.recon.model.Constants.AUDIT_APPLICATION_ID_CONFIG,clientId);
//        producerProps.put(com.optum.payer.kafka.audit.recon.model.Constants.AUDIT_ENV,environment.getActiveProfiles()[0]);
        return new DefaultKafkaProducerFactory<>(producerProps);
    }

    protected <K, V> KafkaListenerContainerFactory<ConcurrentMessageListenerContainer<K, V>> gcpCreateContainerFactory(
            Deserializer<K> keyDeserializer, Deserializer<V> valueDeserializer, String topicName, String consumer, String applicationName) {

        String prefix = "";
        if (consumer != null) {
            prefix = consumer + ".";
        }
        Map<String, Object> deserializerProps = new HashMap<>();
        deserializerProps.put (AbstractKafkaSchemaSerDeConfig.SCHEMA_REGISTRY_URL_CONFIG, gcpKafkaProperties.getProperties ().get (AbstractKafkaSchemaSerDeConfig.SCHEMA_REGISTRY_URL_CONFIG));
        deserializerProps.put (AbstractKafkaSchemaSerDeConfig.VALUE_SUBJECT_NAME_STRATEGY, TopicNameStrategy.class);
        deserializerProps.put (KafkaAvroDeserializerConfig.SPECIFIC_AVRO_READER_CONFIG, Boolean.TRUE);
        
        //Schema HTTPS changes -- PKIX path building failed - unable to find valid certification path to requested target
        deserializerProps.put(Constants.SCHEMA_REGISTRY_SSL_TRUSTSTORE_LOCATION, new File(gcpKafkaProperties.getProperties().get("certs." + applicationName + ".ssl.trust-store-location")).getAbsolutePath());
        deserializerProps.put(Constants.SCHEMA_REGISTRY_SSL_TRUSTSTORE_PASSWORD,  gcpKafkaProperties.getProperties().get("certs." + applicationName + ".ssl.trust-store-password"));
        deserializerProps.put(Constants.SCHEMA_REGISTRY_SSL_KEYSTORE_LOCATION, new File(gcpKafkaProperties.getProperties().get("certs." + applicationName + ".ssl.key-store-location")).getAbsolutePath());
        deserializerProps.put(Constants.SCHEMA_REGISTRY_SSL_KEYSTORE_PASSWORD, gcpKafkaProperties.getProperties().get("certs." + applicationName + ".ssl.key-store-password"));

        keyDeserializer.configure (deserializerProps, true);
        valueDeserializer.configure (deserializerProps, false);

        Map<String, Object> consumerProps = gcpKafkaProperties.buildConsumerProperties ();

        //Added BOOTSTRAP_SERVERS_CONFIG -- GCP
        consumerProps.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, gcpKafkaProperties.getBootstrapServers());

        consumerProps.put (ConsumerConfig.CLIENT_ID_CONFIG,   gcpKafkaProperties.getClientId () + "_" + UuidUtil.getTimeBasedUuid ().toString ());

        //Consumer GroupId Dynamic - based on CERTS GCP application name
        consumerProps.put (ConsumerConfig.GROUP_ID_CONFIG, getConsumerGroupId (gcpKafkaProperties.getProperties().get("certs." + applicationName + ".consumerGroupId"), topicName));
        consumerProps.put (ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, consumerProps.get (prefix + "auto.offset.reset").toString ());
        consumerProps.put (ConsumerConfig.MAX_POLL_RECORDS_CONFIG, Integer.valueOf (consumerProps.get (prefix + "max.poll.records").toString ()));

        //Schema URL SSL
        consumerProps.put(Constants.SCHEMA_REGISTRY_SSL_TRUSTSTORE_LOCATION, new File(gcpKafkaProperties.getProperties().get("certs." + applicationName + ".ssl.trust-store-location")).getAbsolutePath());
        consumerProps.put(Constants.SCHEMA_REGISTRY_SSL_TRUSTSTORE_PASSWORD,  gcpKafkaProperties.getProperties().get("certs." + applicationName + ".ssl.trust-store-password"));
        consumerProps.put(Constants.SCHEMA_REGISTRY_SSL_KEYSTORE_LOCATION, new File(gcpKafkaProperties.getProperties().get("certs." + applicationName + ".ssl.key-store-location")).getAbsolutePath());
        consumerProps.put(Constants.SCHEMA_REGISTRY_SSL_KEYSTORE_PASSWORD, gcpKafkaProperties.getProperties().get("certs." + applicationName + ".ssl.key-store-password"));
        consumerProps.put(Constants.SCHEMA_REGISTRY_SSL_KEY_PASSWORD, gcpKafkaProperties.getProperties().get("certs." + applicationName + ".ssl.key-password"));


        //configure the following three settings for SSL Encryption
        //SSL - CERTS - Based on application name loading for consumer
        consumerProps.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, gcpKafkaProperties.getProperties().get("security.protocol"));
        consumerProps.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, new File(gcpKafkaProperties.getProperties().get("certs." + applicationName + ".ssl.trust-store-location")).getAbsolutePath());
        consumerProps.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG,  gcpKafkaProperties.getProperties().get("certs." + applicationName + ".ssl.trust-store-password"));

        // configure the following three settings for SSL Authentication
        consumerProps.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, new File(gcpKafkaProperties.getProperties().get("certs." + applicationName + ".ssl.key-store-location")).getAbsolutePath());
        consumerProps.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, gcpKafkaProperties.getProperties().get("certs." + applicationName + ".ssl.key-store-password"));
        consumerProps.put(SslConfigs.SSL_KEY_PASSWORD_CONFIG, gcpKafkaProperties.getProperties().get("certs." + applicationName + ".ssl.key-password"));
        // audit consumer interceptor
        // below configs will come from yml file
//        consumerProps.put(ProducerConfig.INTERCEPTOR_CLASSES_CONFIG,"com.optum.payer.kafka.audit.recon.interceptor.AuditConsumerInterceptor");
//        consumerProps.put(com.optum.payer.kafka.audit.recon.model.Constants.AUDIT_APPLICATION_ID_CONFIG,consumerGroupId);
//        consumerProps.put(com.optum.payer.kafka.audit.recon.model.Constants.AUDIT_ENV,environment.getActiveProfiles()[0]);
        ConsumerFactory consumerFactory = new DefaultKafkaConsumerFactory<>(consumerProps, keyDeserializer,
                valueDeserializer);

        ConcurrentKafkaListenerContainerFactory<K, V> factory = new ConcurrentKafkaListenerContainerFactory<> ();

        factory.setConsumerFactory (consumerFactory);

        factory.setBatchListener (Boolean.valueOf (consumerProps.get (prefix + "concurrentKafkaListenerContainerFactory.batch.listener").toString ()));
        factory.setAutoStartup (Boolean.valueOf (consumerProps.get (prefix + "concurrentKafkaListenerContainerFactory.auto.startup").toString ()));
        factory.getContainerProperties ().setAckMode (MANUAL);
        factory.setConcurrency (Integer.valueOf (consumerProps.get (prefix + "concurrentKafkaListenerContainerFactory.concurrency").toString ()));
        factory.getContainerProperties ().setSyncCommits (Boolean.valueOf (consumerProps.get ("concurrentKafkaListenerContainerFactory.syncCommits").toString ()));
        factory.getContainerProperties ().setPollTimeout (Long.valueOf (consumerProps.get ("concurrentKafkaListenerContainerFactory.pollTimeOut").toString ()));
        return factory;
    }

    private String getConsumerGroupId(String gcpConsumerGroupId, String topicName) {
        String applicationEnvironment = System.getenv(APPLICATION_ENVIRONMENT);
        if (StringUtils.isEmpty(applicationEnvironment))
            applicationEnvironment = "ENV_Unknown";
        String consumerGroupId = String.format("%s_%s_%s_%s",  gcpConsumerGroupId, APPLICATION_PREFIX,  topicName, applicationEnvironment); //Dont give any Prefix --  GCP not supporting -- prefix should be with consumerGroupId
        return consumerGroupId;
    }

}
