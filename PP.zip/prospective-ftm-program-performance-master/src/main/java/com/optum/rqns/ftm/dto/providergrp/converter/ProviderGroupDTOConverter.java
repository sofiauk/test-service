package com.optum.rqns.ftm.dto.providergrp.converter;

import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.dto.providergrp.ProviderGroupDTO;
import com.optum.rqns.ftm.repository.providergrp.ProviderGroupDetailsRepositoryImpl;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;

public class ProviderGroupDTOConverter implements Converter<Row, ProviderGroupDTO>, DTOWrapperTypeConverter {

    @Override
    public ProviderGroupDTO convert(Row rs) {

        Integer eliglbleMembers = rs.get(ProviderGroupDetailsRepositoryImpl.ColumnNames.ELIGIBLE_PREFERRED_MEMBERS.getColumnName(), Integer.class);
        eliglbleMembers = eliglbleMembers == null ? 0 : eliglbleMembers;

        return ProviderGroupDTO.builder()
                .providerGroupId(rs.get(ProviderGroupDetailsRepositoryImpl.ColumnNames.PROVIDER_GROUP_ID.getColumnName(), String.class))
                .state(rs.get(ProviderGroupDetailsRepositoryImpl.ColumnNames.STATE.getColumnName(), String.class))
                .isNewForDeployment(hasBooleanValue(rs, ProviderGroupDetailsRepositoryImpl.ColumnNames.IS_NEW_FOR_DEPLOYMENT.getColumnName()))
                .eligiblePreferredMembers(Double.valueOf(eliglbleMembers))
                .programYear(rs.get(ProviderGroupDetailsRepositoryImpl.ColumnNames.PROGRAMYEAR.getColumnName(), Integer.class))
                .build();
    }
}