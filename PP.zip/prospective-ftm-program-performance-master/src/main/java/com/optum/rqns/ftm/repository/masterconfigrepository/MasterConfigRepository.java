package com.optum.rqns.ftm.repository.masterconfigrepository;

import com.optum.rqns.ftm.dto.masterconfig.MasterConfigDTO;
import com.optum.rqns.ftm.dto.masterconfig.MasterConfigurationDTO;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;

@Repository
public interface MasterConfigRepository {

    Flux<String> getValueFromCode(String columnName);

    Flux<String> getLastRunDate(String jobName);

    Flux<String> getProgramYearStartDate(String programYear, String durationValue);

    Flux<MasterConfigDTO> getProgramYears();

    Flux<MasterConfigurationDTO> getAllProgramYears();

    Mono<Integer> updateProgramYears(String currentProgramYearValue, String qfoCurrentProgramYearValue);

    Flux<MasterConfigurationDTO> getQfoStarRatings();

    Mono<Integer> updateQfoStarRatings(String currentStarRatingValue, String qfoCurrentStarRatingValue);

    Flux<MasterConfigDTO> getYTDMasterConfiguration(List<String> codes);

    Flux<MasterConfigDTO> getRulesMasterConfiguration(List<String> configs,List<String> jobNames);

    Mono<Integer> updateConfgValue(String code, String value);

    Flux<MasterConfigurationDTO> getAdminConfigurationList();

    Flux<MasterConfigurationDTO> getConfigurationByCode(String code);
}
