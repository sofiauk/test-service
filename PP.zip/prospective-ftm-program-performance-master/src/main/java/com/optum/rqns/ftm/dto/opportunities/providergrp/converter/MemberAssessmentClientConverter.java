package com.optum.rqns.ftm.dto.opportunities.providergrp.converter;

import com.optum.rqns.ftm.constants.ProviderGroupConstants;
import com.optum.rqns.ftm.model.opportunities.providergrp.MemberAssessmentClients;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;

public class MemberAssessmentClientConverter implements Converter<Row, MemberAssessmentClients> {

    public MemberAssessmentClients convert(Row row) {
        return MemberAssessmentClients.builder()
                .clientName(row.get(ProviderGroupConstants.CLIENT_NAME, String.class))
                .build();
    }
}
