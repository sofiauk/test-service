package com.optum.rqns.ftm.constants;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class ClientGoalConstants {
    public static final Map<String, String> COLUMN_NAMES;
    public static final String DEPLOYED = "DEPLOYED";
    public static final String DEPLOYED_GOAL = "Deploy";
    public static final String RETURNED = "RETURNED";
    public static final String RETURNED_GOAL = "Return";
    public static final String COMPLETED = "COMPLETED";
    public static final String COMPLETE_GOAL = "Completed";
    public static final String SECONDARY_SUBMISSION = "SECONDARYSUBMISSION";
    public static final String SECONDARY_SUBMISSION_VALUE = "Secondary Submission";
    public static final String GA_RISK = "GARISK";
    public static final String RISK_GAP_ASSESSMENT = "Risk Gap Assessment";
    public static final String GA_QUALITY = "GAQUALITY";
    public static final String QUALITY_GAP_ASSESSMENT = "Quality Gap Assessment";
    public static final String DV_RISK = "DVRISK";
    public static final String RISK_DOCUMENTATION_VERIFICATION = "Risk Documentation Verification";
    public static final String RISKGAPCLOSURE = "RISKGAPCLOSURE";
    public static final String RISK_GAP_CLOSURE = "Risk Gap Closure";
    public static final String DV_QUALITY = "DVQUALITY";
    public static final String QUALITY_DOCUMENTATION_VERIFICATION = "Quality Documentation Verification";
    public static final String DIAGNOSEDVERIFIED = "DIAGNOSEDVERIFIED";
    public static final String DIAGNOSED_VERIFIED = "Diagnosed & Verified";
    public static final String LOB = "LOB";
    public static final String STATE = "STATE";
    public static final String REGION = "REGION";
    public static final String H_PLANS = "HPLANS";
    public static final String PBP = "PBP";
    public static final String C_GAP_RISK = "CGAPRISK";
    public static final String C_GAP_QUALITY = "CGAPQUALITY";
    public static final String YEAR = "YEAR";
    public static final String LOB_ID = "LOBID";
    public static final String CLIENT_ID = "CLIENTID";
    public static final String REGION_ID = "REGIONID";
    public static final String CLIENT_REGION = "CLIENTREGION";
    public static final String ELIGIBLEMEMBERS_COLUMN_NAME = "ELIGIBLEMEMBERS";
    public static final String GOAL_VALUE_COLUMN_NAME = "GOALVALUE";
    public static final String GOAL_TYPE_COLUMN_NAME = "GOALTYPE";
    public static final String IS_CLIENT_REGION_COLUMN_NAME = "ISCLIENTREGION";
    public static final String STATE_COUNT_COLUMN_NAME = "STATECOUNT";
    public static final String CLIENT_COLUMN_NAME = "CLIENT";
    public static final String MONTHLY = "Monthly";
    public static final String QUARTERLY = "Quarterly";
    public static final String FILTER_VALUE = "filtervalue";
    public static final String YEARLY = "Yearly";
    public static final String PROGRAM_YEAR = "PROGRAMYEAR";

    public static final List<String> goalTypes = Collections.unmodifiableList(
            Arrays.asList(DEPLOYED, RETURNED
                    , COMPLETED, SECONDARY_SUBMISSION, GA_RISK, GA_QUALITY, DIAGNOSEDVERIFIED, DV_QUALITY
                    , DV_RISK, RISKGAPCLOSURE)
    );

    public static final String SNAPSHOT_DATE_FORMAT = "M/d/yyyy";
    public static final String DATE_FORMAT = "dd/MM/yyyy";
    public static final String DATE_WEEKS_FORMAT = "dd MMM yyyy";

    static {
        Map<String, String> columnNames = new LinkedHashMap<>();
        columnNames.put(DEPLOYED, DEPLOYED_GOAL);
        columnNames.put(RETURNED, RETURNED_GOAL);
        columnNames.put(COMPLETED, COMPLETE_GOAL);
        columnNames.put(SECONDARY_SUBMISSION, SECONDARY_SUBMISSION_VALUE);
        columnNames.put(GA_RISK, RISK_GAP_ASSESSMENT);
        columnNames.put(GA_QUALITY, QUALITY_GAP_ASSESSMENT);
        columnNames.put(DV_RISK, RISK_DOCUMENTATION_VERIFICATION);
        columnNames.put(RISKGAPCLOSURE, RISK_GAP_CLOSURE);
        columnNames.put(DV_QUALITY, QUALITY_DOCUMENTATION_VERIFICATION);
        columnNames.put(DIAGNOSEDVERIFIED, DIAGNOSED_VERIFIED);

        COLUMN_NAMES = Collections.unmodifiableMap(columnNames);
    }

    private ClientGoalConstants() {
    }
}
