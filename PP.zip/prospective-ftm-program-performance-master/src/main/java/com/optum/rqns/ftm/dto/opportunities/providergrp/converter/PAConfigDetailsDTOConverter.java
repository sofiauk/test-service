package com.optum.rqns.ftm.dto.opportunities.providergrp.converter;

import com.optum.rqns.ftm.constants.ProviderGroupConstants;
import com.optum.rqns.ftm.model.opportunities.providergrp.PAConfigDetails;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;

public class PAConfigDetailsDTOConverter implements Converter<Row, PAConfigDetails> {
        @Override
        public PAConfigDetails convert(Row row) {
            return PAConfigDetails.builder()
                    .name(row.get(ProviderGroupConstants.NAME, String.class))
                    .key(row.get(ProviderGroupConstants.KEY,String.class))
                    .value(row.get(ProviderGroupConstants.VALUE,String.class))
                    .build();
        }

}
