package com.optum.rqns.ftm.constants;

public final class JobConfigurationConstants {
    private JobConfigurationConstants() {
    }

    public static final String JOB_ID = "jobID";
    public static final String JOB_NAME = "jobName";
    public static final String JOB_DESCRIPTION = "jobDescription";
    public static final String CREATED_BY = "createdBy";
    public static final String CREATED_DATE = "createdDate";
    public static final String MODIFIED_BY = "modifiedBy";
    public static final String MODIFIED_DATE = "modifiedDate";
    public static final String LAST_SUCCESSFUL_RUN_DATE = "lastSuccessfulRunDate";
    public static final String ID = "iD";
    public static final String STATUS = "status";
    public static final String JOB_START = "jobStart";
    public static final String JOB_END = "jobEnd";
    public static final String ERROR_MESSAGE = "errorMessage";
    public static final String AFFECTED_ROWS = "affectedRows";
    public static final String MESSAGE_KEY = "messageKey";
    public static final String MESSAGE = "message";
    public static final String JOB_EVENT = "jobEvent";
    public static final String IS_ACTIVE = "isActive";

    // Paf Over All Status API Constants
    public static final String PROJECT_ID = "projectId";
    public static final String OVERALL_STATUS = "overallStatus";
    public static final String COUNT = "count";

    //Category updated date API constants
    public static final String UPDATED_DATE = "updateDate";
    public static final String CATEGORY = "category";

    public static final String LINGER_MS_CONFIG = "120000";
    public static final String REQUEST_TIMEOUT_MS_CONFIG = "120000";
}
