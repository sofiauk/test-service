package com.optum.rqns.ftm.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum ExportType {
    ALL("All"),
    FILTERED("Filtered");
    String value;
}
