package com.optum.rqns.ftm.model.qfo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.time.LocalDateTime;

@Data
@Builder
@EqualsAndHashCode
@NoArgsConstructor
@ToString
@AllArgsConstructor
public class SuspectConditionTotal {
    private Integer programYear;
    private String month;
    private Long suspectConditionsTotal;
    private Long suspectConditionsAssessedDiagnosed;
    private Long suspectConditionsAssessedUndiagnosed;
    private String targetSuspect;
    private String suspectUndiagnosedTarget;
    private LocalDateTime updatedDate;
}
