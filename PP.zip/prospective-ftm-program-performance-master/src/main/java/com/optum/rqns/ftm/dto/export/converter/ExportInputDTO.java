package com.optum.rqns.ftm.dto.export.converter;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Data
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class ExportInputDTO {
    private String processType;
    private String processSubType;
    private String documentType;
    private String exportType;
    private String traceId;
    private Long transactionId;
    private Object exportInput;
}
