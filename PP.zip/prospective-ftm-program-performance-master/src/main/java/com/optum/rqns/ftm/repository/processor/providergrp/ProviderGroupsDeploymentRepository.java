package com.optum.rqns.ftm.repository.processor.providergrp;

import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.model.providergrpdeployment.ProviderGroupFlatData;
import com.optum.rqns.ftm.model.providergrpdeployment.ProviderGroupPerformanceInfo;
import com.optum.rqns.ftm.model.providergrpdeployment.ProviderGroupsDeployment;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Map;


public interface ProviderGroupsDeploymentRepository {
    Flux<ProviderGroupsDeployment> getProviderGroupsDeployment(Map<String,String> inputMap, JobEvent jobEvent);

    Mono<Long> batchQueriesForProviderGroupDeploymentCounts(List<ProviderGroupsDeployment> providerGroupsDeploymentList, Map<String, String> inputMap);

    Flux<ProviderGroupFlatData> getDeploymentsWithCTE(JobEvent jobEvent);

    Mono<Long> batchQueriesForProviderGroupDeploymentCountsV1(List<ProviderGroupPerformanceInfo> providerGroupsDeploymentList, Map<String, String> jobEvent);

}