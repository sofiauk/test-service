package com.optum.rqns.ftm.repository.commandcenter;

import com.optum.rqns.ftm.model.providergrpdeployment.GrowthRate;
import reactor.core.publisher.Mono;

public interface CommandCenterGrowthRateRepository {
    Mono<Integer> calculateCCTargetGrowthRates(int projectYear);
    Mono<GrowthRate> getCommandCenterGrowthRate(int projectYear, String month);
}
