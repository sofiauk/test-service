package com.optum.rqns.ftm.dto.commandcenter;

import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
public class ClientCPDDTO {

    private String name;
    private String uuid;
}