package com.optum.rqns.ftm.dto.job_configuration.converter;

import com.optum.rqns.ftm.constants.JobConfigurationConstants;
import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.dto.job_configuration.PafOverAllStatusDetailDTO;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;

public class PafOverAllStatusDetailDTOConverter implements Converter<Row, PafOverAllStatusDetailDTO>, DTOWrapperTypeConverter {

    @Override
    public PafOverAllStatusDetailDTO convert(Row rs) {

        return PafOverAllStatusDetailDTO.builder()
                .projectId(rs.get(JobConfigurationConstants.PROJECT_ID, String.class))
                .overallStatus(rs.get(JobConfigurationConstants.OVERALL_STATUS, String.class))
                .count(rs.get(JobConfigurationConstants.COUNT, Long.class))
                .build();
    }
}
