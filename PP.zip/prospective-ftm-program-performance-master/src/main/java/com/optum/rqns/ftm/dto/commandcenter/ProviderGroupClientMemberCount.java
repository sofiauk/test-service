package com.optum.rqns.ftm.dto.commandcenter;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class ProviderGroupClientMemberCount {
    private String clientName;
    private String lob;
    private Long totalMembership;
    private Long eligibleMembership;
    private int isIdmTarget;
    private Long programEligibleMembercount;
}