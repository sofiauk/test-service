package com.optum.rqns.ftm.model.performance.providergrp;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AssignedProviderGroupOpportunities {

    private String providerGroupName;
    private String tin;
    private Long returnYTDActual;
    private Long returnYTDTargetPercent;
    private Long returns;
    private Long rejects;
    private Long secondarySubmission;
    private Long financialInfo;
    private Long outliers;
    private String state;
    private String providerGroupId;
    private LocalDate lastTouchPoint;
    private Long deployments;
    @JsonIgnore
    private Long opportunitiesCount;
    @JsonIgnore
    private Long gapsCount;
    @JsonIgnore
    private String opportunitiesType;
    private String lastUpdated;
    @JsonIgnore
    private Integer hoursAgo;
    private String serviceLevel;

}
