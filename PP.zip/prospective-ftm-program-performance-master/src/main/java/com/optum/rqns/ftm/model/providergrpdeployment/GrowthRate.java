package com.optum.rqns.ftm.model.providergrpdeployment;

import lombok.Builder;
import lombok.Data;
import org.springframework.data.relational.core.mapping.Table;


@Data
@Builder
@Table("ProgPerf.CommandCenterGrowthRate")
public class GrowthRate {
    private Integer programYear;
    private String month;
    private Integer agreedYTD;
    private Integer engagedYTD;
    private Integer agreedTarget;
    private Integer engagedTarget;
    private Integer totalProvidersGroup;
    private Double agreedYTDPercent;
    private Double engagedYTDPercent;
}