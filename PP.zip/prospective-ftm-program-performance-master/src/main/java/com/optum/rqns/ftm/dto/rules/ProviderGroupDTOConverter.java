package com.optum.rqns.ftm.dto.rules;

import com.optum.rqns.ftm.model.rules.ProviderGroup;
import com.optum.rqns.ftm.repository.rules.RuleRepositoryImpl;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;

public class ProviderGroupDTOConverter implements Converter<Row, ProviderGroup> {

    @Override
    public ProviderGroup convert(Row rs) {

        return ProviderGroup.builder()
                .providerGroupID(rs.get(RuleRepositoryImpl.ColumnNames.PROVIDERGROUPID.getColumnName(), String.class))
                .state(rs.get(RuleRepositoryImpl.ColumnNames.STATE.getColumnName(), String.class))
                .build();
    }
}
