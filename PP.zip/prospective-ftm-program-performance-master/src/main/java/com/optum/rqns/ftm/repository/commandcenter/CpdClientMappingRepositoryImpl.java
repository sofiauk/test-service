package com.optum.rqns.ftm.repository.commandcenter;

import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.model.cpdclientmapping.ClientCPD;
import org.springframework.data.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

@Repository
public class CpdClientMappingRepositoryImpl implements CpdClientMappingRepository, DTOWrapperTypeConverter {

    private final DatabaseClient client;

    CpdClientMappingRepositoryImpl(DatabaseClient client) {
        this.client = client;
    }

    public enum ColumnNames {

        CLIENT_NAME("ClientName");

        private String columnName;

        ColumnNames(String columnName) {
            this.columnName = columnName;
        }

        public String getColumnName() {
            return this.columnName;
        }
    }

    private static final String CPD_BY_CLIENT = "SELECT TOP 1 CpdName, UUID FROM ProgPerf.CpdClientMapping " +
            "WHERE Client = :ClientName AND IsDeleted = 0";

    @Override
    public Mono<ClientCPD> getCPDOfClient(String clientName) {
        return client.execute(CPD_BY_CLIENT)
                .bind(ColumnNames.CLIENT_NAME.getColumnName(), clientName)
                .as(ClientCPD.class)
                .map((row, rowMetaData) -> ClientCPD
                        .builder()
                        .name(getValue(row, "CpdName", String.class))
                        .uuid(getValue(row, "UUID", String.class))
                        .build()
                )
                .first();
    }
}
