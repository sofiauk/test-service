package com.optum.rqns.ftm.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum RoleType {
    HCA("HCA"),PSC("PSC"),HSC("HSC"),CQC("CQC"),MANAGER("Manager");
    private String value;

    public static RoleType fromString(String text) {
        switch (text.trim().toUpperCase()){
            case "HCA": return HCA;
            case "PSC": return PSC;
            case "HSC": return HSC;
            case "CQC": return CQC;
            case "MANAGER": return MANAGER;
            default:throw new IllegalArgumentException("Unexpected value:"+text+" Please provide a Valid Role.");
        }
    }
}
