package com.optum.rqns.ftm.kafka.consumer.events;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.context.annotation.Profile;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.annotation.TopicPartition;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.repository.common.CommonRepository;
import com.optum.rqns.ftm.service.memberDeploymentUpdates.PAFxMemberDeploymentUpdatesService;

import lombok.extern.slf4j.Slf4j;

@Profile("rqnsFtmJobs")
@Component
@Slf4j
public class PAFxMemberDeploymentUpdatesConsumer extends JobEventConsumer {
    public PAFxMemberDeploymentUpdatesConsumer(PAFxMemberDeploymentUpdatesService pAFxMemberDeploymentUpdatesService, CommonRepository commonRepository) {
        super(pAFxMemberDeploymentUpdatesService, commonRepository);
    }
    /*@KafkaListener(topicPartitions = {@TopicPartition(topic = "${spring.kafka.properties.topics.jobEvent}", partitions = {"19"})},
            containerFactory = "jobEventKafkaListenerContainerFactory", autoStartup = "true")
    public void onMessage(ConsumerRecord<String, JobEvent> record, Acknowledgment acknowledgment) {
        log.info("{} Begin Consumer PAFxMemberDeploymentUpdates: {}", super.generateTransactionId (record), record);
        processMessage(19, record, acknowledgment);
    }*/
    @Override
    public void handleMessage(String jobEvent){
        processMessage(jobEvent);
    }
}
