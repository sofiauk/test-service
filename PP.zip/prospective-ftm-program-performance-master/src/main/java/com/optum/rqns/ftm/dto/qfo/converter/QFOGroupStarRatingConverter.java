package com.optum.rqns.ftm.dto.qfo.converter;

import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.dto.qfo.QFOGroupStarRatingDTO;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.ReadingConverter;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

@Component
@ReadingConverter
public class QFOGroupStarRatingConverter implements Converter<Row, QFOGroupStarRatingDTO>, DTOWrapperTypeConverter {

	@Override
	public QFOGroupStarRatingDTO convert(Row row) {
			return QFOGroupStarRatingDTO.builder()
					.assignedGroups(getPrimitiveIntegerValue(row, "AssignedGroups"))
					.actual(getFloatValue(row, "Actual"))
					.target(getFloatValue(row, "Target"))
					.performance(getFloatValue(row, "Performance"))
					.lastUpdatedDate(getValue(row, "LastUpdatedDate", LocalDateTime.class))
					.build();
	}
}
