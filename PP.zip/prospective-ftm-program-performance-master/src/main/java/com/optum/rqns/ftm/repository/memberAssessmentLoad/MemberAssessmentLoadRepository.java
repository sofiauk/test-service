package com.optum.rqns.ftm.repository.memberAssessmentLoad;

import reactor.core.publisher.Mono;

import java.time.LocalDateTime;
import java.util.Map;

public interface MemberAssessmentLoadRepository {

    Mono<Integer> getJobIdByJobName(String jobName);

    Mono<Map<String,LocalDateTime>> getJobStartAndLastSuccessDateForMemberAssessmentDataSync(int jobConfigId);

    Mono<Integer> executeMemberAssessmentDataSyncForBatch(int projectYear, LocalDateTime lastSyncDate, LocalDateTime currentSyncDate, int batchOffset, int batchSize);

    Mono<Integer> executeMemberAssessmentHistoryDataSyncForBatch(int projectYear, LocalDateTime lastSyncDate, LocalDateTime currentSyncDate, int batchOffset, int batchSize);

    Mono<Integer> updateJobRunConfigurationWithBatchProgress(int jobConfigId, int executionHistoryId, int completedRowsCount);

    Mono<Integer> updateJobExecutionHistoryWithBatchProgress(int jobConfigId, int executionHistoryId, int completedRowsCount);

    Mono<Integer> getTotalCountToSyncForMemberAssessment(int projectYear, String formattedLastSyncDate, String formattedCurrentSyncDate);

    Mono<Integer> getTotalCountToSyncForMemberAssessmentHistory(int projectYear, String formattedLastSyncDate, String formattedCurrentSyncDate);

    Mono<Integer> getCurrentJobExecutionHistoryID(int jobConfigId);

}