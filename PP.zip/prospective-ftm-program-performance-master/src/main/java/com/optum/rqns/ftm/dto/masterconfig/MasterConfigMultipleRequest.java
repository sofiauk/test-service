package com.optum.rqns.ftm.dto.masterconfig;

import lombok.Builder;
import lombok.Getter;

import java.util.List;

@Builder
@Getter
public class MasterConfigMultipleRequest {
    private List<MasterConfigDTO> data;
    private String reason;
}
