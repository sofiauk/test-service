package com.optum.rqns.ftm.model.export;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.optum.rqns.ftm.enums.DocumentType;
import com.optum.rqns.ftm.enums.ExportStatus;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.Objects;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(value = JsonInclude.Include.NON_NULL)
public class ExportTransaction {
    String uuid;
    long transactionId;
    String fileName;
    @Getter(AccessLevel.NONE)
    DocumentType documentType;
    @Getter(AccessLevel.NONE)
    ExportStatus exportStatus;

    public String getExportStatus() {
        return Objects.nonNull(this.exportStatus) ? this.exportStatus.getValue() : null;
    }

    public String getDocumentType() {
        return Objects.nonNull(this.documentType) ? this.documentType.getValue() : null;
    }

}
