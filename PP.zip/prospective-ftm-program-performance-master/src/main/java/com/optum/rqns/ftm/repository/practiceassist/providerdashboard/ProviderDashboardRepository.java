package com.optum.rqns.ftm.repository.practiceassist.providerdashboard;

import com.optum.rqns.ftm.dto.practiceassist.providerdashboard.ProviderDashboardAggrDTO;
import com.optum.rqns.ftm.dto.practiceassist.providerdashboard.SuperUserProviderGroupData;
import com.optum.rqns.ftm.model.practiceassist.providerdashboard.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;

public interface ProviderDashboardRepository {
    Mono<QualityAggregationDO> getQualityAggr(ProviderDashboardAggrRequest providerDashboardAggrRequest);
    
    Mono<MedAdherenceAggregationDO> getMedAdherenceAggr(ProviderDashboardAggrRequest providerDashboardAggrRequest);

    Flux<SuperUserProvDashDO> calcSuperUserProvGrp();

    Mono<Integer> upsertSuperUserProvGrp(List<SuperUserProvDashDO> superUserProvDashDOList);

    Mono<SuperUserProviderGroupData> findSuperUserProvGrpId(ProviderDashboardAggrDTO providerDashboardAggrDTO);
}
