package com.optum.rqns.ftm.request.exports;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Data
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
public class ExportsRequestPayload   {

    private String processType;
    private String processSubType;
    private String documentType;
    private String exportType;
    private String traceId;
    private Long transactionId;
    private IGenericExportRequestInput exportInput;
}
