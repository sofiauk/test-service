package com.optum.rqns.ftm.dto.goals.client.Response;

import com.optum.rqns.ftm.dto.goals.client.Region;
import com.optum.rqns.ftm.wrapper.Meta;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.ToString;

import java.util.ArrayList;
import java.util.List;

@Data
@ToString
@AllArgsConstructor
@Builder
public class RegionResponse {
    private Meta meta;

    private List<Region> data;

    public RegionResponse() {
        this.meta = new Meta();
        this.data = new ArrayList<>();

    }
}