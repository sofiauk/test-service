package com.optum.rqns.ftm.model.opportunities.providergrp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Data
@ToString
@Builder
public class PAConfigDetails {
        String name;
        String key;
        String value;
}
