package com.optum.rqns.ftm.response.performance.providergrp.qfo;

import com.optum.rqns.ftm.model.performance.providergrp.qfo.ProviderGroupPerformanceDetails;
import com.optum.rqns.ftm.wrapper.Meta;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class ProviderGroupPerformanceDetailsResponse {

    private Meta meta;

    private List<ProviderGroupPerformanceDetails> data;

    public ProviderGroupPerformanceDetailsResponse() {
        this.meta = new Meta();
        this.data = new ArrayList<>();
    }
}
