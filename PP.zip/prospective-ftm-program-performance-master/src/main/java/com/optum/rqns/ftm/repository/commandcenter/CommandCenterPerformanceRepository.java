package com.optum.rqns.ftm.repository.commandcenter;

import com.optum.rqns.ftm.model.providergrpdeployment.DerivedDeployment;
import com.optum.rqns.ftm.model.providergrpdeployment.DerivedDeploymentWeekly;
import com.optum.rqns.ftm.model.providergrpdeployment.ReturnsNetCNA;
import com.optum.rqns.ftm.model.providergrpdeployment.ReturnsNetCNAWeekly;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;

public interface CommandCenterPerformanceRepository {

    Flux<DerivedDeployment> getDerivedDeploymentCounts(int programYear, String byType, String name, int offset, int limit, boolean regionSummary);
    Flux<ReturnsNetCNA> getReturnsNetCNACounts(int programYear, String byType, String name, int offset, int limit, boolean regionSummary);
    Flux<Long> getDerivedDeploymentOrReturnsNetCNATotalCount(int programYear, String byType, String name);
    Mono<Long> getDerivedDeploymentOrReturnsNetCNATotalRegionCount(int programYear, String byType, String name);
    Flux<DerivedDeploymentWeekly> getDerivedDeploymentWeeklyCounts(int programYear, List<String> regions, List<String> states, List<String> lobs, List<String> clients);
    Flux<DerivedDeploymentWeekly> getDerivedDeploymentWeeklyGoals(int programYear, List<String> regions, List<String> states, List<String> lobs, List<String> clients);
    Flux<ReturnsNetCNAWeekly> getReturnsNetCnaWeeklyCounts(int programYear, List<String> regions, List<String> states, List<String> lobs, List<String> clients);
    Flux<ReturnsNetCNAWeekly> getReturnsNetCnaWeeklyGoals(int programYear, List<String> regions, List<String> states, List<String> lobs, List<String> clients);
    Flux<String> getCommandCenterRegions();
}
