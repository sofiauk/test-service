package com.optum.rqns.ftm.dto.opportunities.providergrp.converter;

import com.optum.rqns.ftm.constants.ProviderGroupConstants;
import com.optum.rqns.ftm.model.opportunities.providergrp.ClientsFilterDetails;
import com.optum.rqns.ftm.model.opportunities.providergrp.LobFilterDetails;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;

public class LobFilterDetailsConverter implements Converter<Row, LobFilterDetails> {

    public LobFilterDetails convert(Row row) {
        return LobFilterDetails.builder()
                .lobName(row.get(ProviderGroupConstants.LOB_NAME, String.class))
                .build();
    }
}
