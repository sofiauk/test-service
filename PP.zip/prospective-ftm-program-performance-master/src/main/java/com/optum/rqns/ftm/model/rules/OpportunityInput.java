package com.optum.rqns.ftm.model.rules;

public interface OpportunityInput {
    String getProviderGroupId();
    String getProviderGroupName();
    String getProviderState();
    String getServiceLevel();
    int getProjectYear();
    String getClient();
    String getClientId();
    String getLobName();
    int getDeployYTDActual();
    int getReturnYTDActual();
    int getReturnYTDActualPercentage();
    int getReturnYTDTargetPercent();
    String getPaymentRejectReason();
    String getSingleRejectReason();
    String getChartID();
    String getOutlierName();
    String getGapType();
    String getGapDesc();
    String getIsSecondarySubmissionEligible();
    String getOverAllStatus();
    int getEligibleMembersCount();
 }
