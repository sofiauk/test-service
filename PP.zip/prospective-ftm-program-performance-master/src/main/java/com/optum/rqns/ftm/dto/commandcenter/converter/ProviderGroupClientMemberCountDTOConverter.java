package com.optum.rqns.ftm.dto.commandcenter.converter;

import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.dto.commandcenter.ProviderGroupClientMemberCount;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;

public class ProviderGroupClientMemberCountDTOConverter implements Converter<Row, ProviderGroupClientMemberCount>, DTOWrapperTypeConverter {
    @Override
    public ProviderGroupClientMemberCount convert(Row row) {

        return ProviderGroupClientMemberCount.builder()
                .clientName(row.get("ClientName",String.class))
                .lob(row.get("lob",String.class))
                .totalMembership(row.get("totalMembership",Long.class))
                .eligibleMembership(row.get("eligibleMembership",Long.class))
                .isIdmTarget(row.get("IsIDMTarget",Integer.class) )
                .programEligibleMembercount(row.get("programEligibleMembercount",Long.class))
                .build();

    }


}