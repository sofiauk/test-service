package com.optum.rqns.ftm.constants;

public final class CommandCenterConstants {

    private CommandCenterConstants() {
    }

    public static final String RETURN_RATE_EXISTING_GOAL_PERCENT = "CommandCenter_ReturnRate_ExistingGroupsGoalPercent";
    public static final String RETURN_RATE_NEW_GOAL_PERCENT = "CommandCenter_ReturnRate_NewGroupsGoalPercent";
    public static final String POC_CONVERSION_EXISTING_GOAL_PERCENT = "CommandCenter_POCConversion_ExistingGoalPercent";
    public static final String POC_CONVERSION_NEW_GOAL_PERCENT = "CommandCenter_POCConversion_NewGoalPercent";
    public static final String ALL = "All";
}
