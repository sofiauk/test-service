package com.optum.rqns.ftm.dto.performance.providergrp.converter;

import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.dto.performance.providergrp.ProviderGroupPerformanceYTDGraphDTO;
import com.optum.rqns.ftm.repository.performance.providergrp.ProviderGroupPerformanceRepositoryImpl;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;

import java.time.LocalDate;

public class ProviderGroupsPerformanceDTOConverter implements Converter<Row, ProviderGroupPerformanceYTDGraphDTO>, DTOWrapperTypeConverter {

    public ProviderGroupPerformanceYTDGraphDTO convert(Row resultSet) {

        return ProviderGroupPerformanceYTDGraphDTO.builder()
                .year(getPrimitiveIntegerValue(resultSet, ProviderGroupPerformanceRepositoryImpl.ColumnNames.YEAR.getColumnName()))
                .returnYTDActual(getLongValue(resultSet, ProviderGroupPerformanceRepositoryImpl.ColumnNames.RETURN_YTD_ACTUAL.getColumnName()))
                .returnYETarget(getLongValue(resultSet, ProviderGroupPerformanceRepositoryImpl.ColumnNames.RETURN_YE_TARGET.getColumnName()))
                .eligibleMemberCount(getLongValue(resultSet, ProviderGroupPerformanceRepositoryImpl.ColumnNames.ELIGIBLE_DEPLOYABLE_MEMBER_COUNT.getColumnName()))
                .deployYETarget(getLongValue(resultSet, ProviderGroupPerformanceRepositoryImpl.ColumnNames.DEPLOY_YE_TARGET.getColumnName()))
                .deployYTDTarget(getLongValue(resultSet, ProviderGroupPerformanceRepositoryImpl.ColumnNames.DEPLOY_YTD_TARGET.getColumnName()))
                .returnYTDTarget(getLongValue(resultSet, ProviderGroupPerformanceRepositoryImpl.ColumnNames.RETURN_YTD_TARGET.getColumnName()))
                .deployYTDActual(getLongValue(resultSet, ProviderGroupPerformanceRepositoryImpl.ColumnNames.DEPLOY_YTD_ACTUAL.getColumnName()))
                .month(resultSet.get(ProviderGroupPerformanceRepositoryImpl.ColumnNames.MONTH.getColumnName(),String.class))
                .durationValue(resultSet.get(ProviderGroupPerformanceRepositoryImpl.ColumnNames.DURATION_VALUE.getColumnName(),String.class))
                .startDate(resultSet.get(ProviderGroupPerformanceRepositoryImpl.ColumnNames.START_DATE.getColumnName(), LocalDate.class))
                .endDate(resultSet.get(ProviderGroupPerformanceRepositoryImpl.ColumnNames.END_DATE.getColumnName(), LocalDate.class))
                .returnedNetCnaActual(getLongValue(resultSet,ProviderGroupPerformanceRepositoryImpl.ColumnNames.RETURNED_NET_CNA_ACTUAL.getColumnName()))
                .build();
    }
}
