package com.optum.rqns.ftm.dto.opportunities.providergrp.converter;

import com.optum.rqns.ftm.constants.ProviderGroupConstants;
import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.dto.opportunities.providergrp.MemberACVDTO;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;

import java.time.LocalDate;

public class MemberACVDTOConverter implements Converter<Row, MemberACVDTO>, DTOWrapperTypeConverter {
    @Override
    public MemberACVDTO convert(Row row) {
        return MemberACVDTO.builder().build().builder().programYear(row.get(ProviderGroupConstants.PROGRAM_YEAR,Integer.class))
                .annualCareVisitDate(row.get(ProviderGroupConstants.ANNUAL_CARE_VISIT_DATE, LocalDate.class))
                .carePriorityGroup(convertIntToString(row,ProviderGroupConstants.CARE_PRIORITY_GROUP))
                .gender(row.get(ProviderGroupConstants.GENDER, String.class))
                .houseCallsVisitDate(row.get(ProviderGroupConstants.HOUSE_CALL_VISIT_DATE, LocalDate.class))
                .incentiveProgram(row.get(ProviderGroupConstants.INCENTIVE_PROGRAM, String.class))
                .insuranceCarrier(row.get(ProviderGroupConstants.INSURANCE_CARRIER, String.class))
                .lob(row.get(ProviderGroupConstants.LOB_NAME, String.class))
                .patientCardId(row.get(ProviderGroupConstants.PATIENT_CARD_ID, String.class))
                .patientDOB(row.get(ProviderGroupConstants.PATIENT_DOB, LocalDate.class))
                .patientFirstName(row.get(ProviderGroupConstants.PATIENT_FIRST_NAME, String.class))
                .patientLastName(row.get(ProviderGroupConstants.PATIENT_LAST_NAME, String.class))
                .pcpNpi(row.get(ProviderGroupConstants.PCP_NI, String.class))
                .primaryCareProviderName(row.get(ProviderGroupConstants.PRIMARY_CARE_PROVIDER_NAME, String.class))
                .highPriorityPatient(row.get(ProviderGroupConstants.HIGH_PRIORITY_PATIENT,String.class))
                .build();
    }
}
