package com.optum.rqns.ftm.model.rules;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashSet;
import java.util.Set;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProviderGroupOpportunitiesSummary{
    String providerGroupID;
    String providerGroupName;
    String state;
    String serviceLevel;
    int programYear;
    @JsonIgnore
    Set<String> clients = new HashSet<>();
    @JsonIgnore
    String clientName;
    @JsonIgnore
    String lobName;
    String masterOpportunityType;
    int masterOpportunityTypePosition;
    int totalGapsCount;
    int totalAssessmentsCount;
    int totalClientsCount;
    @JsonIgnore
    int deployYTDActual;
    @JsonIgnore
    int returnYTDActual;
    @JsonIgnore
    int returnYTDActualPercentage;
    @JsonIgnore
    int returnYTDTargetPercent;
    @JsonIgnore
    String chartID;
    @JsonIgnore
    String isSecondarySubmissionEligible;
    @JsonIgnore
    String outlierName;
    @JsonIgnore
    String gapType;
    @JsonIgnore
    Set<String> assessments = new HashSet<>();
    @JsonIgnore
    String gapDesc;
    @JsonIgnore
    String createdBy;
    @JsonIgnore
    String paymentRejectReason;
    int eligibleMembersCount;
    @JsonIgnore
    String singleRejectReason;

    public ProviderGroupOpportunitiesSummary(ProviderGroupOpportunitiesSummary providerGroupOpportunitiesSummary){
        providerGroupID=providerGroupOpportunitiesSummary.providerGroupID;
        providerGroupName=providerGroupOpportunitiesSummary.providerGroupName;
        state=providerGroupOpportunitiesSummary.state;
        serviceLevel=providerGroupOpportunitiesSummary.serviceLevel;
        programYear=providerGroupOpportunitiesSummary.programYear;
        clients=providerGroupOpportunitiesSummary.clients;
        clientName=providerGroupOpportunitiesSummary.clientName;
        lobName=providerGroupOpportunitiesSummary.lobName;
        masterOpportunityType=providerGroupOpportunitiesSummary.masterOpportunityType;
        masterOpportunityTypePosition=providerGroupOpportunitiesSummary.masterOpportunityTypePosition;
        totalGapsCount=providerGroupOpportunitiesSummary.totalGapsCount;
        totalAssessmentsCount=providerGroupOpportunitiesSummary.totalAssessmentsCount;
        totalClientsCount=providerGroupOpportunitiesSummary.totalClientsCount;
        deployYTDActual=providerGroupOpportunitiesSummary.deployYTDActual;
        returnYTDActual=providerGroupOpportunitiesSummary.returnYTDActual;
        returnYTDActualPercentage=providerGroupOpportunitiesSummary.returnYTDActualPercentage;
        returnYTDTargetPercent=providerGroupOpportunitiesSummary.returnYTDTargetPercent;
        chartID=providerGroupOpportunitiesSummary.chartID;
        isSecondarySubmissionEligible=providerGroupOpportunitiesSummary.isSecondarySubmissionEligible;
        outlierName=providerGroupOpportunitiesSummary.outlierName;
        gapType=providerGroupOpportunitiesSummary.gapType;
        assessments=providerGroupOpportunitiesSummary.assessments;
        gapDesc=providerGroupOpportunitiesSummary.gapDesc;
        createdBy=providerGroupOpportunitiesSummary.createdBy;
        paymentRejectReason=providerGroupOpportunitiesSummary.paymentRejectReason;
        eligibleMembersCount=providerGroupOpportunitiesSummary.eligibleMembersCount;
        singleRejectReason=providerGroupOpportunitiesSummary.singleRejectReason;
    }
}