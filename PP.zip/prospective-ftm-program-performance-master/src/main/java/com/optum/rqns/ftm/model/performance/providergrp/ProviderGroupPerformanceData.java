package com.optum.rqns.ftm.model.performance.providergrp;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.optum.rqns.ftm.constants.ProviderGroupConstants;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class ProviderGroupPerformanceData {
    private Long deploymentYtdActual;
    private Long returnYtdActual;
    private Long returnYtdTarget;
    private Long returnYeTarget;
    private Long deploymentYeTarget;
    private Double returnRate;
    private Double returnYtdTargetPercentage;
    private Double returnYeTargetPercentage;
    private Long ytdDiffPercentage;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = ProviderGroupConstants.PERFORMANCE_DATE_FORMAT)
    private LocalDate deploymentStartDate;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = ProviderGroupConstants.PERFORMANCE_DATE_FORMAT)
    private LocalDate lastDeploymentDate;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = ProviderGroupConstants.PERFORMANCE_DATE_FORMAT)
    private LocalDate durationEndDate;
    private Long eligibleDeployedMemberCount;
    private Long deployYTDTarget;
    private Double deployPerformanceTargetPercentage;
    private Double returnPerformanceTargetPercentage;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = ProviderGroupConstants.PERFORMANCE_DATE_FORMAT)
    private LocalDate lastUpdatedDate;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = ProviderGroupConstants.PERFORMANCE_DATE_FORMAT)
    private LocalDate lastReturnedDate;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = ProviderGroupConstants.PERFORMANCE_DATE_FORMAT)
    private LocalDate returnedStartDate;
    private Long eligiblePreferredMemberCount;
    private Long cnaCount;
    private Long returnedNetCnaYtdActual;


}
