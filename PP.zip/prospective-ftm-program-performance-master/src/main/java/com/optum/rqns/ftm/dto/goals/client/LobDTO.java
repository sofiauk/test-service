package com.optum.rqns.ftm.dto.goals.client;

import lombok.Data;
import lombok.ToString;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Builder;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class LobDTO {
    private Integer lobId;
    private String lobName;
}