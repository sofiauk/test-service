package com.optum.rqns.ftm.dto.qfo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SuspectConditionTotalsDTO {
    private Integer programYear;
    private String month;
    private Long conditionsAssessedPercentage;
    private Long assessedUnableToDiagnosePercentage;
    private String targetSuspect;
    private String suspectUndiagnosedTarget;
    private LocalDateTime lastUpdatedDate;
}
