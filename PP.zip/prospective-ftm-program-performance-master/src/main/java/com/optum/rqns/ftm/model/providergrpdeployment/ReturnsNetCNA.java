package com.optum.rqns.ftm.model.providergrpdeployment;

import lombok.Builder;
import lombok.Data;
import org.springframework.data.relational.core.mapping.Table;
import java.time.LocalDateTime;


@Data
@Builder
@Table("ProgPerf.CommandCenterPerformance")
public class ReturnsNetCNA {
    private String name;
    private String state;
    private LocalDateTime lastUpdated;
    private Long ytdActual;
    private Long currentWeekCounts;
    private Long previousWeekCounts;
    private Long nextWeekForecastCounts;
    private Long opportunityCounts;
    private Double programYearGoal;
    private Double programYearVariance;
    private Double ytdGoal;
    private Double ytdVariance;
}
