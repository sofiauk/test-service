package com.optum.rqns.ftm.controller;

import com.optum.rqns.ftm.constants.FTMHeaders;
import com.optum.rqns.ftm.customannotation.CustomApiResponse;
import com.optum.rqns.ftm.dto.performance.providergrp.ProviderGroupPerformanceYTDGraphDTO;
import com.optum.rqns.ftm.dto.performance.providergrp.ProviderGroupStateDerivedDeploymentsDTO;
import com.optum.rqns.ftm.dto.performance.providergrp.ProviderGroupStateReturnsNetCNADTO;
import com.optum.rqns.ftm.enums.RoleType;
import com.optum.rqns.ftm.enums.TypeEnum;
import com.optum.rqns.ftm.exception.APIErrorCode;
import com.optum.rqns.ftm.exception.ProgramPerformanceException;
import com.optum.rqns.ftm.model.UserInfo;
import com.optum.rqns.ftm.model.UserRole;
import com.optum.rqns.ftm.response.performance.providergrp.AssignedProviderGroupOpportunitiesResponse;
import com.optum.rqns.ftm.response.performance.providergrp.AssignedProviderGroupPerformanceResponse;
import com.optum.rqns.ftm.response.performance.providergrp.ProviderGroupPerformanceResponse;
import com.optum.rqns.ftm.response.performance.providergrp.ProviderGroupPerformanceYTDGraphResponse;
import com.optum.rqns.ftm.response.performance.providergrp.ProviderGroupStateDerivedDeploymentsResponse;
import com.optum.rqns.ftm.response.performance.providergrp.ProviderGroupStateReturnsNetCNAResponse;
import com.optum.rqns.ftm.response.providergrp.ToggleYearResponse;
import com.optum.rqns.ftm.service.RedisCacheManager;
import com.optum.rqns.ftm.service.performance.providergrp.ProviderGroupPerformanceService;
import com.optum.rqns.ftm.util.ProgramPerformanceUtil;
import com.optum.rqns.ftm.util.StargateStandardResponseUtilV2;
import com.optum.rqns.ftm.wrapper.Pagination;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Objects;

@Profile("rqnsFtmApi")
@RestController
@RequestMapping("/v1/provider-groups")
@Slf4j
@CustomApiResponse
public class ProviderGroupPerformanceController {

    @Autowired
    ProviderGroupPerformanceService providerGroupPerformanceService;

    @Autowired
    StargateStandardResponseUtilV2<Object, Object> stargateStandardResponseUtilV2;

    @Autowired
    RedisCacheManager redisCacheManager;

    @GetMapping("{provider-group-id}/performances")
    @ApiResponse(responseCode = "200", description = "Sucess Request",
            content = @Content(schema = @Schema(implementation = ProviderGroupPerformanceResponse.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<ProviderGroupPerformanceResponse> getProviderGroupPerformance(
            @PathVariable("provider-group-id") String providerGroupId,
            @RequestParam String state,
            @RequestParam("service-level") String serviceLevel,
            @RequestParam("program-year") int programYear
    ) {
        log.info("Getting Provider Group Performance Details for the Given Details: {}, {},{},{}", providerGroupId, state, serviceLevel, programYear);

        return stargateStandardResponseUtilV2
                .generateStargateStandardResponse(
                        providerGroupPerformanceService.getProviderGroupPerformance(providerGroupId, state, serviceLevel, programYear)
                        , TypeEnum.MONO
                        , new ProviderGroupPerformanceResponse())
                .cast(ProviderGroupPerformanceResponse.class);
    }

    @GetMapping("groups-performances")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = AssignedProviderGroupPerformanceResponse.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<AssignedProviderGroupPerformanceResponse> getAssignedProviderGroupsPerformance(
            @RequestParam("uuid") String uuid,
            @RequestParam("program-year") int programYear,
            @RequestHeader(FTMHeaders.X_USER_DETAILS) String userDetailsJson,
            @RequestHeader(value = FTMHeaders.X_TRACE_ID, required = false) String traceId
    ) {
        log.info("Getting  Assigned Provider Groups Performance Details for uuid: {} {} {}", uuid, programYear, userDetailsJson);

        UserInfo userInfo = (UserInfo) ProgramPerformanceUtil.jsonToPojo(userDetailsJson, UserInfo.class);

        UserRole userRole = null;
        RoleType roleType = null;
        if (Objects.nonNull(userInfo.getRoles())) {
            userRole = userInfo.getRoles().get(0);
            roleType = RoleType.fromString(userRole.getName());
        }

        if (roleType == null) {
            log.info("TraceId :: {} Invalid Role Type to fetch the Performance data", traceId);
            return Mono.error(new ProgramPerformanceException(HttpStatus.OK, APIErrorCode.INVALID_ROLE_TYPE));
        }

        return stargateStandardResponseUtilV2
                .generateStargateStandardResponse(
                        providerGroupPerformanceService.getAssignedProviderGroupsPerformance(uuid, programYear, roleType)
                        , TypeEnum.MONO
                        , new AssignedProviderGroupPerformanceResponse())
                .cast(AssignedProviderGroupPerformanceResponse.class);
    }


    @GetMapping("groups-opportunities")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = AssignedProviderGroupOpportunitiesResponse.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<AssignedProviderGroupOpportunitiesResponse> getAssignedProviderGroupsOpportunities(
            @RequestParam("uuid") String uuid,
            @RequestHeader(FTMHeaders.X_USER_DETAILS) String userDetailsJson
    ) {
        UserInfo userInfo = (UserInfo) ProgramPerformanceUtil.jsonToPojo(userDetailsJson, UserInfo.class);
        UserRole userRole = userInfo.getRoles().get(0);
        log.info("Getting  top opportunities Assigned Provider Groups for uuid: {} {}", uuid, userRole.getName());
        RoleType roleType = RoleType.fromString(userRole.getName());
        if (roleType == null) {
            log.info("Invalid Role Type");
            return Mono.error(new ProgramPerformanceException(HttpStatus.OK, APIErrorCode.INVALID_ROLE_TYPE));
        }

        return stargateStandardResponseUtilV2
                .generateStargateStandardResponse(
                        providerGroupPerformanceService.getAssignedProviderGroupsOpportunities(uuid, roleType)
                        , TypeEnum.FLUX
                        , new AssignedProviderGroupOpportunitiesResponse())
                .cast(AssignedProviderGroupOpportunitiesResponse.class);
    }

    @PostMapping(value = "groups-performances-graph-returns")
    public ResponseEntity getProviderGroupPerformanceForYTDGraph(
            @RequestParam("uuid") String uuid,
            @RequestHeader(FTMHeaders.X_USER_DETAILS) String userDetailsJson,
            @RequestParam("program-year") int programYear,
            ServerHttpResponse response) {
        log.info("Entered the Graph Calculation Process: {}", userDetailsJson);
        String traceId = providerGroupPerformanceService.validateAndGetTraceId(uuid, userDetailsJson, programYear);
            long now = System.currentTimeMillis();
            HttpHeaders headers = response.getHeaders();
            headers.put(HttpHeaders.LOCATION, Collections.singletonList("groups-performances-graph-returns/" + traceId));
            headers.put(HttpHeaders.EXPIRES, Collections.singletonList(new Date(now + redisCacheManager.getExpirationInMins() * 60000).toString()));
            response.setStatusCode(HttpStatus.ACCEPTED);
            providerGroupPerformanceService.saveGraphDataInCache(uuid, userDetailsJson, programYear, traceId);
         return ResponseEntity.accepted().headers(headers).build();
        }


    @RequestMapping(value = "groups-performances-graph-returns/isReady/{requestId}", method = RequestMethod.HEAD)
    public ResponseEntity checkIsReady(@PathVariable("requestId") String requestId) {
        log.info("is ready? requestId:" + requestId);
         if (!providerGroupPerformanceService.isDataReadyInCache(requestId)) {
            if (!providerGroupPerformanceService.hasGraphAPIError(requestId)) {
                log.info("Graph data is still not ready in cache:{}", requestId);
                return ResponseEntity
                        .noContent()
                        .allow(HttpMethod.HEAD)
                        .build();
            } else {
                log.error("Server side Error while building graph API details for traceId :{}", requestId);
                return ResponseEntity
                        .status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .allow(HttpMethod.HEAD)
                        .build();
            }
        } else {
            log.info("graph is ready to render:  traceid{}", requestId);
            return ResponseEntity.ok().build();
        }

    }

    @GetMapping(path = "/groups-performances-graph-returns/{requestId}", produces = {MediaType.APPLICATION_JSON_VALUE})
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = ProviderGroupPerformanceYTDGraphDTO.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<ProviderGroupPerformanceYTDGraphResponse> getGraphData(@PathVariable("requestId") String requestId) {

        List<ProviderGroupPerformanceYTDGraphDTO> list = providerGroupPerformanceService.processRedisData(requestId);
        if (!list.isEmpty()) {
            log.info("Getting graph details from Cache {}", requestId);

            return stargateStandardResponseUtilV2
                    .generateStargateStandardResponse(
                            Mono.just(list)
                            , TypeEnum.MONO
                            , new ProviderGroupPerformanceYTDGraphResponse())
                    .cast(ProviderGroupPerformanceYTDGraphResponse.class);
        } else {
            return stargateStandardResponseUtilV2
                    .generateStargateStandardResponse(
                            Mono.just(Collections.EMPTY_LIST)
                            , TypeEnum.MONO
                            , new ProviderGroupPerformanceYTDGraphResponse())
                    .cast(ProviderGroupPerformanceYTDGraphResponse.class);
        }
    }

    @GetMapping("/derived-deployments/{program-year}/{by-type}/{state}")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = ProviderGroupStateDerivedDeploymentsDTO.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<ProviderGroupStateDerivedDeploymentsResponse> getProviderGroupsStateDerivedDeployments(@PathVariable("program-year") int programYear,
                                                                                                       @PathVariable("by-type") String type,
                                                                                                       @PathVariable("state") String state,
                                                                                                       @RequestParam("service-level") String serviceLevel,
                                                                                                       @RequestParam("name") String name,
                                                                                                       @RequestParam("start") int start,
                                                                                                       @RequestParam("count") int count) {
        log.info("Getting Derived Deployments Provider Groups by State for program year: {}, type: {}, state: {}, " +
                "service level: {}, name: {}", programYear, type, state, serviceLevel, name);

        ProviderGroupStateDerivedDeploymentsResponse response = new ProviderGroupStateDerivedDeploymentsResponse();

        if (!ProgramPerformanceUtil.isValidByTypes(type)) {
            return stargateStandardResponseUtilV2.generateStargateStandardResponse(
                    Mono.error(new ProgramPerformanceException(HttpStatus.OK, APIErrorCode.INVALID_BY_TYPE)), TypeEnum.MONO, response)
                    .cast(ProviderGroupStateDerivedDeploymentsResponse.class);

        }

        if (!ProgramPerformanceUtil.isValidByServiceLevels(serviceLevel)) {
            return stargateStandardResponseUtilV2.generateStargateStandardResponse(
                    Mono.error(new ProgramPerformanceException(HttpStatus.OK, APIErrorCode.INVALID_BY_SERVICE_LEVEL)), TypeEnum.MONO, response)
                    .cast(ProviderGroupStateDerivedDeploymentsResponse.class);

        }

        Pagination pagination = new Pagination();

        return stargateStandardResponseUtilV2.generateStargateStandardResponse(
                providerGroupPerformanceService.getProviderGroupsStateDerivedDeployments(programYear, type, name, state, serviceLevel, start, count), TypeEnum.FLUX, response)
                .cast(ProviderGroupStateDerivedDeploymentsResponse.class)
                .doOnNext(responseGenerated -> {
                    long totalCount = responseGenerated.getData().size();
                    pagination.setTotalResults(totalCount);
                    pagination.setOffset(start);
                    pagination.setLimit(count);
                    pagination.setTotalPageCount(totalCount % count == 0 ? (totalCount / count) : (totalCount / count) + 1);
                    responseGenerated.getMeta().setPagination(pagination);
                });
    }


    @GetMapping("/returns-net-cna/{program-year}/{by-type}/{state}")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = ProviderGroupStateReturnsNetCNADTO.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<ProviderGroupStateReturnsNetCNAResponse> getProviderGroupsStateReturnsNetCNA(@PathVariable("program-year") int programYear,
                                                                                             @PathVariable("by-type") String type,
                                                                                             @PathVariable("state") String state,
                                                                                             @RequestParam("service-level") String serviceLevel,
                                                                                             @RequestParam("name") String name,
                                                                                             @RequestParam("start") int start,
                                                                                             @RequestParam("count") int count) {
        log.info("Getting Returns Net CNA Provider Groups by State for program year: {}, type: {}, state: {}, " +
                "service level: {}, name: {}", programYear, type, state, serviceLevel, name);

        ProviderGroupStateReturnsNetCNAResponse response = new ProviderGroupStateReturnsNetCNAResponse();

        if (!ProgramPerformanceUtil.isValidByTypes(type)) {
            return stargateStandardResponseUtilV2.generateStargateStandardResponse(
                    Mono.error(new ProgramPerformanceException(HttpStatus.OK, APIErrorCode.INVALID_BY_TYPE)), TypeEnum.MONO, response)
                    .cast(ProviderGroupStateReturnsNetCNAResponse.class);
        }

        if (!ProgramPerformanceUtil.isValidByServiceLevels(serviceLevel)) {
            return stargateStandardResponseUtilV2.generateStargateStandardResponse(
                    Mono.error(new ProgramPerformanceException(HttpStatus.OK, APIErrorCode.INVALID_BY_SERVICE_LEVEL)), TypeEnum.MONO, response)
                    .cast(ProviderGroupStateReturnsNetCNAResponse.class);

        }

        Pagination pagination = new Pagination();

        return stargateStandardResponseUtilV2.generateStargateStandardResponse(
                providerGroupPerformanceService.getProviderGroupsStateReturnsNetCNA(programYear, type, name, state, serviceLevel, start, count), TypeEnum.FLUX, response)
                .cast(ProviderGroupStateReturnsNetCNAResponse.class)
                .doOnNext(responseGenerated -> {
                    long totalCount = responseGenerated.getData().size();
                    pagination.setTotalResults(totalCount);
                    pagination.setOffset(start);
                    pagination.setLimit(count);
                    pagination.setTotalPageCount(totalCount % count == 0 ? (totalCount / count) : (totalCount / count) + 1);
                    responseGenerated.getMeta().setPagination(pagination);
                });
    }

    @GetMapping("/current-year")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = ToggleYearResponse.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<ToggleYearResponse> getCurrentProgramYear(@RequestHeader(value = FTMHeaders.X_USER_DETAILS) String userDetails) {
        log.info("Getting CurrentProgramYear");
        UserInfo userInfo = (UserInfo) ProgramPerformanceUtil.jsonToPojo(userDetails, UserInfo.class);
        String userRole = userInfo.getRoles().stream().filter(role -> role.getName().startsWith("QFO")).findFirst().map(userRole1 -> userRole1.getName()).orElse("");
        log.info("Getting  top user role: {}", userRole);
        return stargateStandardResponseUtilV2
                .generateStargateStandardResponse(
                        providerGroupPerformanceService.getCurrentProgramYear(userRole)
                        , TypeEnum.FLUX
                        , new ToggleYearResponse())
                .cast(ToggleYearResponse.class);
    }

}
