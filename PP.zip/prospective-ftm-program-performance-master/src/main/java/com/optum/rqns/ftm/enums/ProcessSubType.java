package com.optum.rqns.ftm.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum ProcessSubType {
    RETURNS("Returns"),
    REJECTS("Rejects"),
    SECONDARY_SUBMISSIONS("Secondary Submissions"),
    OUTLIERS("Outliers"),
    QUALITY_GAP("Quality Gaps"),
    SUSPECT_CONDITIONS("Suspect Conditions"),
    ANNUAL_CARE_VISITS("Annual Care Visits"),
    ANNUAL_CARE_VISITS_NOT_COMPLETED("Annual Care Visits Not Completed"),
    ANNUAL_CARE_VISITS_HIGH_PRIORITY("High Priority Patients Without an Annual Care Visit"),
    SUSPECT_CONDITIONS_NOT_ASSESSED("Suspect Conditions Not Assessed"),
    PATIENTS_NOT_FULLY_ASSESSED("Patients Not Fully Assessed"),
    PRE_VISIT_PLANNING_WITH_ACV_COMPLETED("Pre-visit Planning Confirmations Missing for Patients with an ACV Completed");
    String value;

    public static ProcessSubType fromString(String text) {
        for (ProcessSubType processSubType : ProcessSubType.values()) {
            if (processSubType.value.equalsIgnoreCase(text)) {
                return processSubType;
            }
        }
        return null;
    }
}