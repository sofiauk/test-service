package com.optum.rqns.ftm.dto.goals.client;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ClientLobRegionGoalValuesDTO {
    private int lobId;
    private String lobName;
    private int clientId;
    private String clientName;
    private int stateCount;
    private String regionName;
    private String regionId;
    private boolean isClientRegion;
    private double goalValue;
    private String goalType;
    private double eligibleMembers;
}
