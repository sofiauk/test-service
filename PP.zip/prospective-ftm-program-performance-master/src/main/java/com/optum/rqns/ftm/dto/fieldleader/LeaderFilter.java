package com.optum.rqns.ftm.dto.fieldleader;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class LeaderFilter {
    private String name;
    private String type;
}
