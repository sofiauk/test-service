package com.optum.rqns.ftm.dto.performance.providergrp.qfo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@Builder
@EqualsAndHashCode
@NoArgsConstructor
@ToString
@AllArgsConstructor
public class ProviderGroupPerformanceDetailsDTO {

    String providerGroupId;
    Long  totalPatients;
    BigDecimal overAllStarRating;
    Long mapCpiEligiblePatients;
    BigDecimal mapCpiStarRating;
    BigDecimal pCpiPartDRating;
    Long mapCpiAnnualCareVisits;
    Long suspectConditionsTotal;
    Long suspectConditionAssessedTotal;
    Long suspectDiagnosed;
    Long suspectUndiagnosed;
    Long suspectNotAssessed;
    Long mcaipFullyAssessed;
    Long mcaipSuspectMedicalConditions;
    Long mcaipTotalPatients;
    LocalDateTime updatedDate;
    LocalDateTime mapCpiLastUpdated;
    LocalDateTime mcaipLastUpdated;
}
