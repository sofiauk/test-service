package com.optum.rqns.ftm.repository.fieldleader;

import com.optum.rqns.ftm.dto.fieldleader.LeaderFilter;
import com.optum.rqns.ftm.dto.fieldleader.LeaderRequestFilter;
import com.optum.rqns.ftm.enums.ScopeType;
import com.optum.rqns.ftm.model.fieldleader.LeaderEModality;
import com.optum.rqns.ftm.model.fieldleader.LeaderGrowthRate;
import com.optum.rqns.ftm.model.fieldleader.LeaderIOAPerformance;
import com.optum.rqns.ftm.model.fieldleader.LeaderPOCConversionRate;
import com.optum.rqns.ftm.model.fieldleader.LeaderPerformance;
import com.optum.rqns.ftm.model.programyearcalendar.CurrentPreviousMonth;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;

public interface LeaderPerformanceRepository {

    Flux<LeaderPerformance> getLeaderPerformance(String currentUUID, String type, int programYear);
    Flux<LeaderPOCConversionRate> getLeaderPOCConversionRate(String currentUUID, int programYear, CurrentPreviousMonth currentPreviousMonth);
    Flux<LeaderGrowthRate> getLeaderGrowthRates(int programYear, ScopeType scopeType, String currentUUID, List<String> serviceLevels);
    Flux<LeaderEModality> getLeaderEModality(String currentUUID, int programYear);
    Flux<LeaderIOAPerformance> getLeaderIOAPerformance(String uuid, int programYear, List<String> clientName, List<String> lob, List<String> serviceLevel);
    Flux<LeaderIOAPerformance> getLeaderIOAPerformanceRegion(String region, int programYear, int offset, int limit, List<String> clientName, List<String> lob, List<String> serviceLevel);
    Mono<Long> getLeaderIOAPerformanceRegionCount(String region, int programYear, List<String> clientName, List<String> lob, List<String> serviceLevel);
    Flux<LeaderIOAPerformance> getLeaderIOAPerformanceMyTeam(String uuid, int programYear, List<String> clientName, List<String> lob, List<String> serviceLevel);
    Flux<String> getLeaderFilter(int programYear, String resource, String type);
}
