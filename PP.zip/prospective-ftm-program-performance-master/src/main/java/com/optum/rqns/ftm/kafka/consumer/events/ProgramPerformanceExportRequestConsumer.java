package com.optum.rqns.ftm.kafka.consumer.events;

import com.fasterxml.jackson.core.type.TypeReference;
import com.optum.rqns.common.export.kafka.AbstractExportRequestConsumer;
import com.optum.rqns.common.export.model.ExportFile;
import com.optum.rqns.common.export.model.ExportInput;
import com.optum.rqns.common.export.model.ExportRequestPayload;
import com.optum.rqns.ftm.enums.DocumentType;
import com.optum.rqns.ftm.enums.ProcessSubType;
import com.optum.rqns.ftm.enums.ProcessType;
import com.optum.rqns.ftm.exception.APIErrorCode;
import com.optum.rqns.ftm.exception.ProgramPerformanceException;
import com.optum.rqns.ftm.model.opportunities.providergrp.MemberAssessment;
import com.optum.rqns.ftm.service.export.ExportFactory;
import com.optum.rqns.ftm.service.export.ExportFileService;
import com.optum.rqns.ftm.util.ProgramPerformanceUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpStatus;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

import java.util.Optional;
import java.util.Set;

@Component
@Profile({"exportRequest"})
@Slf4j
public class ProgramPerformanceExportRequestConsumer extends AbstractExportRequestConsumer {

    @Autowired
    private ExportFactory exportFactory;

    @Override
    protected ExportFile processExportRequest(ExportInput exportInput, boolean offshoreRestricted, int exportRequestId) {

        MemberAssessment exportfiltercriteria;
        ExportFileService exportFileService;
        log.info("processExportRequest :: ExportInput - {}",exportInput);
        ProcessType.fromString(exportInput.getExportParams().getProcessType());
        ProcessSubType processSubType = ProcessSubType.fromString(exportInput.getExportParams().getProcessSubType());
        if (exportInput.getExportParams().getExportFilterCriteria() == null) {
            log.error("processExportRequest::export Filter Criteria Can not be null");
            throw new ProgramPerformanceException(HttpStatus.NO_CONTENT, APIErrorCode.NO_CONTENT);
        }

        try {
            exportfiltercriteria = ProgramPerformanceUtil.convert(exportInput.getExportParams().getExportFilterCriteria(), new TypeReference<MemberAssessment>() {
            });
        } catch (Exception e) {
            log.error("processExportRequest::Parsing issue in parsing memberAssessment", e);
            throw new ProgramPerformanceException(HttpStatus.BAD_REQUEST, APIErrorCode.INVALID_PAYLOAD_REQUEST);
        }

        if(processSubType.getValue() == "Annual Care Visits" || processSubType.getValue() == "Suspect Conditions"){
            if(exportInput.getExportParams().getExportFilterCriteria() != null){
                Set<String> oppTypes = exportfiltercriteria.getOpportunityTypes();
                processSubType = ProcessSubType.fromString(oppTypes.stream().findFirst().get());
                log.info(processSubType.getValue());
            }
        }


        exportFileService = exportFactory.getInstance(processSubType);
        Optional<ExportFile> exportFileOptional= exportFileService.getExportFile(exportInput.getUserInfo(), DocumentType.fromString(exportInput.getExportParams().getDocumentType()), exportRequestId, exportfiltercriteria).blockOptional();
        if (exportFileOptional.isPresent()){
            return exportFileOptional.get();
        }else {
            throw new ProgramPerformanceException(HttpStatus.NO_CONTENT, APIErrorCode.NO_CONTENT);
        }

    }

    @KafkaListener(topics = "${spring.gcpkafka.properties.topics.exportRequest}",
            containerFactory = "exportRequestConsumerKafkaListenerContainerFactory",concurrency = "10")
    public void onMessage(ConsumerRecord<String, ExportRequestPayload> record, Acknowledgment acknowledgment) {
        MDC.put("traceId", record.value().getTraceId());
        MDC.put("messageId", record.key());
        String transactionId = super.generateTransactionId(record);
        MDC.put("transactionId", transactionId);
        log.info("{} Begin Consumer ExportDataConsumer: {}", transactionId, record);
        processMessage(record, acknowledgment);
    }
}
