package com.optum.rqns.ftm.model.fieldleader;

import lombok.Builder;
import lombok.Data;
import org.springframework.data.relational.core.mapping.Table;

import java.time.LocalDateTime;

@Data
@Builder
@Table("ProgPerf.LeaderPerformance")
public class LeaderIOAPerformance {
	private String firstName;
    private String lastName;
    private String uuid;
    private String role;
    private String parentUUID;
    private String regionMarket;
	private Double pctToDeployGoalEOY;
	private Double deploymentPct;
	private Double pctToReturnGoalEOY;
	private Double returnPct;
	private Double rejectPct;
	private Double cGAPClosurePct;
    private LocalDateTime lastUpdatedDate;
}
