package com.optum.rqns.ftm.response.processor.providergrp;

import com.optum.rqns.ftm.dto.job_configuration.JobConfigurationDTO;
import com.optum.rqns.ftm.wrapper.Meta;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class JobConfigurationResponse {
    private Meta meta;

    private List<JobConfigurationDTO> data;

    public JobConfigurationResponse() {
        this.meta = new Meta();
        this.data = new ArrayList<>();
    }
}
