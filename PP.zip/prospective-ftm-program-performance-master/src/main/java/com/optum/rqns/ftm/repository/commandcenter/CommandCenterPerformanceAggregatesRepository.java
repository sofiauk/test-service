package com.optum.rqns.ftm.repository.commandcenter;

import com.optum.rqns.ftm.model.providergrpdeployment.PerformanceAggregate;
import reactor.core.publisher.Flux;

public interface CommandCenterPerformanceAggregatesRepository {

    Flux<PerformanceAggregate> getCommandCenterPerformanceAggregates(int projectYear);
}
