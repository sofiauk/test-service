package com.optum.rqns.ftm.request.exports;

import com.optum.rqns.ftm.model.UserInfo;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@Builder
public class ExportsRequestPayloadInputs {
    String requestID;
    ExportsRequestPayload exportParams;
    UserInfo userInfo;
    boolean offshoreRestricted;
}
