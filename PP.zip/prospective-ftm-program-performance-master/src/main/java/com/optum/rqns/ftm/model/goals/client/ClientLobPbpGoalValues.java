package com.optum.rqns.ftm.model.goals.client;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author dvenka19
 *  This class will hold PbpGoals data
 *  lombok will generate getter,setter,toString,noArgsConstructor and allArgsConstructor
 */

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ClientLobPbpGoalValues {
    private String name;
    @JsonProperty("aggregate")
    private GoalDetailValues goalDetailValues;
}
