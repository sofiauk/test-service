package com.optum.rqns.ftm.enums;

public enum TypeEnum {
   MONO(0), FLUX(1);
    private int value;

    private TypeEnum(int value) {
        this.value = value;
    }
}
