package com.optum.rqns.ftm.model.opportunities.providergrp;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OpportunitiesLogging {
    private String masterOpportunityType;
    private String opportunityType;
    private String opportunitySubType;
    private String providerGroupID;
    private String providerGroupName;
    private String tin;
    private String state;
    private String memberID;
    private String chartID;
    private int programYear;
    private String exportedBy;
    private LocalDateTime exportedDate;
    private String exportedByEmail;
    private String requestId;
}
