package com.optum.rqns.ftm.model.providergrpdeployment;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.relational.core.mapping.Column;


@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class POCConversionCount {
    @Column("ProviderGroupCount")
    private int providerGroupCount;
}
