package com.optum.rqns.ftm.repository.practiceassist.providerdashboard;

import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import javax.annotation.PostConstruct;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

import static com.optum.rqns.ftm.constants.practiceassist.providerdashboard.PracticeAssistConstant.LAST_REFRESH_HOUR;

@Slf4j
@Repository
public class ProviderRedisRepository {

    public static final String KEY = "PA_PROVIDER_DASHBOARD_CACHE";

    private HashOperations<String, String, ObjectNode> hashOperations;


    @Autowired
    private RedisTemplate<String, ObjectNode> redisTemplate;

    @PostConstruct
    public void init() {
        this.hashOperations = redisTemplate.opsForHash();
    }

    public ObjectNode save(ObjectNode data, String key) {
        this.hashOperations.put(KEY, key, data);
        return data;
    }

    public long size() {
        return this.hashOperations.size(KEY);
    }

    public Boolean hasKey(String key) {
        return this.hashOperations.hasKey(KEY, key);
    }

    public ObjectNode get(String key) {
        return this.hashOperations.get(KEY, key);
    }

    public long delete(String... key) {
        return this.hashOperations.delete(KEY, (Object[]) key);
    }

    public List<ObjectNode> getAll() {
        return this.hashOperations.values(KEY);
    }

    public Set<String> getAllKeys() {
        return this.hashOperations.keys(KEY);
    }

    public Mono<Long> deleteProviderCacheData(){
        LocalDateTime localDateTime = LocalDateTime.now();
        Flux<Set<String>> cacheKeyFlux = Flux.just(getAllKeys());
        AtomicReference<Long> cacheKeyCount = new AtomicReference<>(0L);
        cacheKeyFlux.doOnNext(keys->{
            String []toDelete= keys.stream().collect(Collectors.toSet()).toArray(new String[0]);
            log.info("In ProviderRedisRepository.deleteProviderCacheData key size : {}", keys.size());
            if (toDelete.length > 0){
                log.info("Started deleting cache data for {} hour", localDateTime.getHour());
                cacheKeyCount.set(hashOperations.delete(KEY, toDelete));
                LAST_REFRESH_HOUR = localDateTime.getHour();
            }
        }).subscribe();
        return Mono.just(cacheKeyCount.get());
    }
}
