package com.optum.rqns.ftm.dto.rules;

import com.optum.rqns.ftm.model.rules.FinancialInformationOpportunityInput;
import com.optum.rqns.ftm.repository.rules.RuleRepositoryImpl;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;

public class FinancialInformationOpportunityInputConverter implements Converter<Row, FinancialInformationOpportunityInput> {
    @Override
    public FinancialInformationOpportunityInput convert(Row rs) {
        return FinancialInformationOpportunityInput.builder()
                .providerGroupId(rs.get(RuleRepositoryImpl.ColumnNames.PROVIDERGROUPID.getColumnName(),String.class))
                .providerGroupName(rs.get(RuleRepositoryImpl.ColumnNames.PROVIDERGROUPNAME.getColumnName(),String.class))
                .providerState(rs.get(RuleRepositoryImpl.ColumnNames.PROVIDER_STATE.getColumnName(),String.class))
                .serviceLevel(rs.get(RuleRepositoryImpl.ColumnNames.SERVICELEVEL.getColumnName(),String.class))
                .projectYear(rs.get(RuleRepositoryImpl.ColumnNames.PROJECT_YEAR.getColumnName(),Integer.class))
                .paymentRejectReason(rs.get(RuleRepositoryImpl.ColumnNames.PAYMENTREJECTREASON.getColumnName(),String.class))
                .build();
    }
}
