package com.optum.rqns.ftm.kafka.consumer.events;

import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.repository.common.CommonRepositoryImpl;
import com.optum.rqns.ftm.service.processor.providergrp.ProviderGroupsDeploymentService;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.context.annotation.Profile;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.annotation.TopicPartition;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

@Profile("rqnsFtmJobs-TargetsActuals")
@Component
@Slf4j
public class DerivedDeploymentCountConsumer extends JobEventConsumer {
    public DerivedDeploymentCountConsumer(final ProviderGroupsDeploymentService providerGroupsDeploymentService, final CommonRepositoryImpl commonRepository) {
        super (providerGroupsDeploymentService, commonRepository);
    }

    @KafkaListener(topicPartitions = {@TopicPartition(topic = "${spring.gcpkafka.properties.topics.jobEvent}", partitions = {"24"})},
            containerFactory = "jobEventKafkaListenerContainerFactory", autoStartup = "true")
    public void onMessage(ConsumerRecord<String, JobEvent> record, Acknowledgment acknowledgment) {
        log.info ("{} Begin Consumer Derived Deployment Count: {}", super.generateTransactionId (record), record);
        processMessage (24, record, acknowledgment);
    }
    @Override
    public void handleMessage(String jobEvent){
        processMessage(jobEvent);
    }
}
