package com.optum.rqns.ftm.model.providergrp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MembershipChangeIhaToIoa {

    private String providerGroupId;
    private String providerState;
    private Integer programYear;
    private LocalDateTime latestMemberMoveDate;

    private Integer newDeploymentOpportunityCount;
    private Integer currentMonthIhaOnlyCount;
    private Integer previousMonthIhaOnlyCount;
    private Integer currentMonthIoaOnlyCount;
    private Integer previousMonthIoaOnlyCount;
    private Integer currentMonthBothIoaIhaCount;
    private Integer previousMonthBothIoaIhaCount;

}
