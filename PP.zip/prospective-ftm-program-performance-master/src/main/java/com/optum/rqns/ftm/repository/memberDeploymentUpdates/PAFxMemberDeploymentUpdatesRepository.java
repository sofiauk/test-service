package com.optum.rqns.ftm.repository.memberDeploymentUpdates;

import com.optum.rqns.ftm.dto.memberDeploymentUpdates.DeploymentMemberAssessmentDTO;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;

public interface PAFxMemberDeploymentUpdatesRepository {

    Mono<Integer> updateIsDeployedAndProviderGroupAssociated(Integer currentBeginId, List<Integer> batchesList);

    Mono<List<Integer>> getBeginEndIdsRangesForBatching(int batchSize);
}
