package com.optum.rqns.ftm.model.fieldaction;


import lombok.Builder;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class JobDetails {
    private String jobName;
    private boolean triggerOnError=false;
    private String jobInput;
}
