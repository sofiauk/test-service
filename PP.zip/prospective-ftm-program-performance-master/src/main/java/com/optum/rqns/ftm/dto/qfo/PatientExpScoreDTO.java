package com.optum.rqns.ftm.dto.qfo;

import lombok.Data;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PatientExpScoreDTO {
    private Float gncRate;
    private Float cooRate;
    private Float dpcRate;
    private Float scoreQuestion1;
    private Float scoreQuestion2;
    private Float scoreQuestion3;
    private Float scoreQuestion4;
    private Float scoreQuestion5;
    private Float scoreQuestion6;
    private Float scoreQuestion8;
    private Float scoreQuestion9;
    private Float scoreQuestion10;
    private String updatedDate;
}
