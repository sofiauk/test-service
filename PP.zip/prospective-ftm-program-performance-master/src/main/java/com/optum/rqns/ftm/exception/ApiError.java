package com.optum.rqns.ftm.exception;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.ToString;

import java.io.Serializable;

@Data
@AllArgsConstructor
@ToString
public class ApiError implements Serializable {
    private static final long serialVersionUID = 1905122041950251208L;
    private String code;
    private String detail;
    private String title;
}
