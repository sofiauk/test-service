package com.optum.rqns.ftm.repository.programyearcalendar;

import com.optum.rqns.ftm.model.programyearcalendar.CurrentPreviousMonth;
import com.optum.rqns.ftm.model.programyearcalendar.DurationWeekCurrentPreviousMonth;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface ProgramYearCalendarRepository {
    Flux<CurrentPreviousMonth> getCurrentPreviousMonth(int programYear);
    Mono<DurationWeekCurrentPreviousMonth> getDurationValueCurrentWeekAndPreviousMonth();
}
