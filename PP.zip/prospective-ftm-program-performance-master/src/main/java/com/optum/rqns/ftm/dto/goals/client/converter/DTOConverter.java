package com.optum.rqns.ftm.dto.goals.client.converter;

import io.r2dbc.spi.Row;

import java.util.Objects;

public  interface DTOConverter {
     default double getDoublePercentageValue(Row resultSet, String columnName) {
        return getPercentage(getDoubleValue(resultSet, columnName));
    }

    default double getDoubleValue(Row resultSet, String columnName) {
        return Objects.isNull(resultSet.get(columnName)) ? 0.0 : resultSet.get(columnName, Double.class);
    }

    default float getFloatValue(Row resultSet, String columnName) {
        return Objects.isNull(resultSet.get(columnName)) ? 0.0f : resultSet.get(columnName, Float.class);
    }

     default long getLongValue(Row resultSet, String columnName) {
        return Objects.isNull(resultSet.get(columnName)) ? 0 : resultSet.get(columnName, Long.class);
    }

     default int getIntegerValue(Row resultSet, String columnName) {
        return Objects.isNull(resultSet.get(columnName)) ? 0 : resultSet.get(columnName, Integer.class);
    }


     default double getPercentage(Double percentageValue) {
        Long percentage = Math.round(percentageValue * 100);
        return Double.valueOf(percentage);
    }
}
