package com.optum.rqns.ftm.repository.jobalerts;

import com.optum.rqns.ftm.dto.jobalerts.JobAlert;
import com.optum.rqns.ftm.util.ProgramPerformanceUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

@Repository
@Slf4j
public class PrometheusJobAlertRepositoryImpl implements PrometheusJobAlertRepository {
    @Autowired
    private DatabaseClient databaseClient;

    private static final String GET_JOB_ALERT_BY_JOB_NAME =
            "select top 1 A.JobName, A.JobDescription, A.LastRunDate, A.CreatedBy, " +
                    "A.CreatedDate, A.ModifiedBy, A.ModifiedDate, A.LastSuccessfulRunDate, " +
                    "A.messageKey, A.jobEvent, A.message, A.isActive, " +
                    "C.ID, C.JobID, C.Status,C.ErrorMessage,C.AffectedRows,C.JobStart,C.JobEnd " +
                    "FROM ProgPerf.JobRunConfiguration A WITH (NOLOCK)" +
                    "inner join " +
                    "    ProgPerf.JobExecutionHistory " +
                    "    as C on A.ID = C.JobID " +
                    "where A.JobName = :JOB_NAME " +
                    "ORDER by C.ID DESC";


    @Override
    public Mono<JobAlert> getJobAlertByName(String jobName) {
        log.info("Fetching JobAlertDTO details :{} ", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier());
        return databaseClient.execute(GET_JOB_ALERT_BY_JOB_NAME)
                .bind("JOB_NAME", jobName)
                .as(JobAlert.class)
                .fetch()
                .one();
    }
}
