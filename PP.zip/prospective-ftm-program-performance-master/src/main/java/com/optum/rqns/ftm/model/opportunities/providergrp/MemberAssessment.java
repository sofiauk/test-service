package com.optum.rqns.ftm.model.opportunities.providergrp;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.optum.rqns.ftm.request.exports.IGenericExportRequestInput;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.ToString;

import java.util.Set;

@AllArgsConstructor
@Data
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
public class MemberAssessment implements IGenericExportRequestInput {
    private String clientName;
    private String lobName;
    private String opportunityType;
    private String opportunitySubtype;
    private String programType;
    private String providerGroupId;
    private String providerState;
    private String serviceLevel;
    private int programYear;
    private Long offset;
    private Integer limit;
    private String sort;
    private String providerGroupName;
    private String tin;
    //used for QualityGap Export
    private Set<String> clientIds;
    private Set<String> clientNames;
    private Set<String> lobs;
    private Set<String> opportunityTypes;
    private boolean onShoreFlag;
    private String teamType;

    private final String className;

    public MemberAssessment() {
        this.className = getClass().getName();
    }


    @JsonIgnore
    public boolean isValid(String providerGroupId, String opType) {

        return (this.providerGroupId.equalsIgnoreCase(providerGroupId) &&
                this.opportunityType.equalsIgnoreCase(opType));

    }

    @JsonIgnore
    public boolean isProviderValid(String providerGroupId) {
        return (this.providerGroupId.equalsIgnoreCase(providerGroupId));
    }

    @Override
    public String getClassName() {
        return this.className;
    }
}
