package com.optum.rqns.ftm.dto.masterconfig;

import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
public class MasterConfigDTO {
    String code;
    String value;
}
