package com.optum.rqns.ftm.repository.commandcenter;

import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.model.providergrpdeployment.POCConversionCount;
import io.r2dbc.spi.Row;
import org.springframework.data.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;


@Repository
public class CommandCenterMemberAssessmentRepositoryImpl implements CommandCenterMemberAssessmentRepository, DTOWrapperTypeConverter {

    private final DatabaseClient client;

    CommandCenterMemberAssessmentRepositoryImpl(DatabaseClient client) {
        this.client = client;
    }

    public enum ColumnNames {

        PROGRAM_YEAR("ProgramYear"),
        DEPLOYMENT_CUTOFF_DATE("DeploymentCutOffDate"),
        USE_LESSTHAN_DEPLOYMENT_CUTOFF_DATE("UseLessThanDeploymentCutOffDate"),
        IS_NEW_FOR_DEPLOYMENT("IsNewForDeployment"),
        DEPLOY_COUNT("DeployCount"),
        RETURN_COUNT("ReturnCount"),
        IS_NEW_PROVIDER_GROUP("IsNewProviderGroup"),
        CHECK_UTILIZING_POC("CheckUtilizingPOC"),
        PROVIDER_GROUP_COUNT("ProviderGroupCount");

        private String columnName;

        ColumnNames(String columnName) {
            this.columnName = columnName;
        }

        public String getColumnName() {
            return this.columnName;
        }
    }

    private static final String PROVIDER_GROUP_COUNT_FOR_POC_CONVERSION = 
            "SELECT TOP 1 SUM(COUNT(distinct ma.ID)) OVER () AS ProviderGroupCount " +
            "   FROM ProgPerf.MemberAssessment ma " +
            "   INNER JOIN ProgPerf.Accounts a " +
            "      ON a.GroupId = ma.prov_group_id AND a.State = ma.providerstate " +
            "   INNER JOIN ProgPerf.ProviderGroupPerformance pgp " +
            "      ON pgp.ProviderGroupID = ma.prov_group_id AND pgp.State = ma.providerstate " +
            "   WHERE " +
            "      a.ServiceLevel = 'HCA' AND " +
            "      ma.project_year = :ProgramYear AND " +
            "      ma.projectid_type IN ('PAF', 'FLA') AND " +
            "      ma.chart_dup_id = 1 AND " +
            "      pgp.ProgramYear = :ProgramYear AND " +
            "      pgp.DeployYTDActual > 0 AND " +
            "      pgp.ReturnedNetCnaYtdActual > 0 AND " +
            "      ((:CheckUtilizingPOC = 0) OR (:CheckUtilizingPOC = 1 AND a.UtilizingPOC = 1)) " +
            "   GROUP BY ma.prov_group_id, ma.providerstate " +
            "      HAVING ((:IsNewProviderGroup = 0 AND SUM(ma.deriveddeployed) > 0) OR (:IsNewProviderGroup = 1 AND SUM(ma.deriveddeployed) <= 0));";

    @Override
    public Mono<POCConversionCount> getPOCConversionCounts(int projectYear, boolean checkUtilizingPOC, boolean isNewProviderGroup) {

        return client.execute(PROVIDER_GROUP_COUNT_FOR_POC_CONVERSION)
                .bind(ColumnNames.PROGRAM_YEAR.getColumnName(), projectYear)
                .bind(ColumnNames.CHECK_UTILIZING_POC.getColumnName(), checkUtilizingPOC)
                .bind(ColumnNames.IS_NEW_PROVIDER_GROUP.getColumnName(), isNewProviderGroup)
                .as(POCConversionCount.class)
                .map((row, rowMetadata) -> POCConversionCount
                                    .builder()
                                    .providerGroupCount(getCount(row, ColumnNames.PROVIDER_GROUP_COUNT.getColumnName()))
                                    .build()
                )
                .one()
                .switchIfEmpty(Mono.just(POCConversionCount.builder().providerGroupCount(0).build()));
    }

    int getCount(Row row, String columnName) {
        final Long count = getLongValue(row, columnName);
        return count != null ? count.intValue() : 0;
    }
}
