package com.optum.rqns.ftm.response.processor.providergrp;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class CalculateActualResponse {
    private int programYear;
    private int performanceTableUpdatedCount;
    private int weeklyTableUpdatedCount;
    private int forecastUpdatedCount;
    private int varianceUpdatedCount;
    private int regionUpdatedCount;
    private int performanceTableIsCurrentWeekFlagUpdateCount;
    private int weeklyTableIsCurrentWeekFlagUpdateCount;
    private int weeklyTableCurrentWeekActualsUpdatedCount;
    private int weeklyTablePastWeekActualsUpdatedCount;
    private int ccpTableUpdateCount;
    private int returnsOpportunityUpdatedCount;
    private int performanceTableUpdatedTargetCount;
}
