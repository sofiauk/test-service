package com.optum.rqns.ftm.model.rules;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Data
@ToString
@Builder
public class MemberAssessmentOpportunity {
    private String providerGroupID;
    private String state;
    private String serviceLevel;
    private int programYear;
    private String masterOpportunityType;
    private String opportunityType;
    private String opportunitySubType;
    private String clientName;
    private String lobName;
    private String chartID;
    @JsonIgnore
    String createdBy;
}
