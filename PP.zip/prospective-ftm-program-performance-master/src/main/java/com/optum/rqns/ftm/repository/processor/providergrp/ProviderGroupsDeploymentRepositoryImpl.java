package com.optum.rqns.ftm.repository.processor.providergrp;

import com.optum.rqns.ftm.constants.RuleConstants;
import com.optum.rqns.ftm.enums.GroupsToExecute;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.model.providergrpdeployment.ProviderGroupFlatData;
import com.optum.rqns.ftm.model.providergrpdeployment.ProviderGroupPerformanceInfo;
import com.optum.rqns.ftm.model.providergrpdeployment.ProviderGroupsDeployment;
import com.optum.rqns.ftm.repository.common.CommonRepository;
import com.optum.rqns.ftm.util.ProgramPerformanceUtil;
import io.r2dbc.spi.ConnectionFactory;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Repository
public class ProviderGroupsDeploymentRepositoryImpl implements ProviderGroupsDeploymentRepository {

    private ConnectionFactory connectionFactory;
    private DatabaseClient databaseClient;

    @Autowired
    CommonRepository commonRepository;

    @Autowired
    public ProviderGroupsDeploymentRepositoryImpl(ConnectionFactory connectionFactory, DatabaseClient databaseClient) {
        this.connectionFactory = connectionFactory;
        this.databaseClient = databaseClient;
    }


    private static final String SELECT_PROVIDERGROUP_DEPLOYMENTS =
            "  SELECT " +
            "  ma.Prov_Group_ID AS providerGroupID ,  " +
            "  ma.providerstate AS state ,  " +
            "  ma.project_year AS programYear,  " +
            "  SUM(CASE WHEN ma.project_year = :PROJECTYEAR AND ma.DerivedDeployed = 1 AND UPPER(ma.RecordChangeType) <> 'DELETED' THEN 1 ELSE 0 END) AS deploymentsCount,  " +
            "  SUM(CASE WHEN ma.project_year = :PROJECTYEAR AND ma.Returned = 1 AND UPPER(ma.RecordChangeType) <> 'DELETED' THEN 1 ELSE 0 END) AS returnsCount,  " +
            "  SUM(CASE WHEN ma.project_year = :PROJECTYEAR AND ma.ReturnedNetCna = 1 AND UPPER(ma.RecordChangeType) <> 'DELETED' THEN 1 ELSE 0 END) AS returnsNetCnaCount  " +
            "  FROM  " +
            "  ProgPerf.MemberAssessment ma WITH (NOLOCK)  " +
            "  WHERE  " +
            "  ma.DerivedDeployed = 1  " +
            "  AND ma.providerstate IS NOT NULL  " +
            "  AND ma.Project_Year = :PROJECTYEAR  " +
            "  %s  " +
            "  GROUP BY  " +
            "  ma.Prov_Group_ID,  " +
            "  ma.providerstate,  " +
            "  ma.project_year  " +

            "  UNION ALL  " +

            "  SELECT " +
            "  mah.Prov_Group_ID AS providerGroupID ,  " +
            "  mah.providerstate AS state ,  " +
            "  mah.project_year AS programYear,  " +
            "  SUM(CASE WHEN mah.project_year = :PROJECTYEAR-1 AND mah.DerivedDeployed = 1 AND UPPER(mah.RecordChangeType) <> 'DELETED' THEN 1 ELSE 0 END) AS deploymentsCount,  " +
            "  SUM(CASE WHEN mah.project_year = :PROJECTYEAR-1 AND mah.Returned = 1 AND UPPER(mah.RecordChangeType) <> 'DELETED' THEN 1 ELSE 0 END) AS returnsCount,  " +
            "  SUM(CASE WHEN mah.project_year = :PROJECTYEAR-1 AND mah.ReturnedNetCna = 1 AND UPPER(mah.RecordChangeType) <> 'DELETED' THEN 1 ELSE 0 END) AS returnsNetCnaCount  " +
            "  FROM  " +
            "  ProgPerf.MemberAssessmentHistory mah WITH (NOLOCK)  " +
            "  WHERE  " +
            "  mah.DerivedDeployed = 1  " +
            "  AND mah.providerstate IS NOT NULL  " +
            "  AND mah.Project_Year = :PROJECTYEAR-1  " +
            "  %s  " +
            "  GROUP BY  " +
            "  mah.Prov_Group_ID,  " +
            "  mah.providerstate,  " +
            "  mah.project_year";



    private static final String MODIFIED_PROVIDER_GROUPS_MEMBERASSESSMENT=
                    " AND ma.Prov_Group_ID + ma.providerstate in (  " +
                    " SELECT  " +
                    " DISTINCT Ax.Prov_Group_ID + Ax.providerstate AS ProviderGroupIDState  " +
                    " FROM  " +
                    " progperf.MemberAssessment Ax WITH (NOLOCK)  " +
                    " WHERE  " +
                    " Ax.Project_Year = :PROJECTYEAR  " +
                    " AND AX.providerstate IS NOT NULL  " +
                    " AND Ax.UpdatedDate > :LASTRUNDATE) ";

    private static final String MODIFIED_PROVIDER_GROUPS_MEMBERASSESSMENT_HISTORY=
                    "  AND mah.Prov_Group_ID + mah.providerstate in (  " +
                    "  SELECT  " +
                    "  DISTINCT Ax.Prov_Group_ID + Ax.providerstate AS ProviderGroupIDState  " +
                    "  FROM  " +
                    "  progperf.MemberAssessmentHistory Ax WITH (NOLOCK)  " +
                    "  WHERE  " +
                    "  Ax.Project_Year = :PROJECTYEAR-1   " +
                    "  AND AX.providerstate IS NOT NULL   " +
                    "  AND Ax.UpdatedDate > :LASTRUNDATE) ";

    private static final String UPDATE_DEPLOYMENT_COUNTS_PROVIDER_GROUP = "UPDATE PROGPERF.ProviderGroup  SET DerivedDeployedCount = %d " +
            "WHERE ProviderGroupID = '%s' AND State = '%s' " ;

    private static final String UPDATE_PREVIOUS_YEAR_DEPLOYMENT_COUNTS_PROVIDER_GROUP = "UPDATE PROGPERF.ProviderGroup SET PreviousYearDerivedDeployedCount = %d " +
            "WHERE ProviderGroupID = '%s' AND State = '%s' " ;

    private static final String SELECT_DEPLOYEMNT_DETAIL_INFO_WITH_CTE="; " +
            "WITH retrieval_channel_translation_CTE " +
            "AS ( " +
            "SELECT [Key] " +
            ", Value " +
            "FROM ProgPerf.CategoryMasterConfiguration " +
            "WHERE Name = 'RetrievalChannelTranslation' " +
            "AND IsActive = 1 " +
            "AND IsDeleted = 0 " +
            ") " +
            ", deployment_channel_translation_CTE " +
            "AS ( " +
            "SELECT [Key] " +
            ", Value " +
            "FROM ProgPerf.CategoryMasterConfiguration " +
            "WHERE Name = 'DeploymentChannelTranslation' " +
            "AND IsActive = 1 " +
            "AND IsDeleted = 0 " +
            ") " +
            ", PROV_GRP_CLIENT_LOB_CTE " +
            "AS ( " +
            "SELECT prov_group_id AS [providerGroupID] " +
            ", providerstate AS [state] " +
            ", project_year AS [programYear] " +
            ", ( " +
            "SELECT ProviderGroupName " +
            "FROM ProgPerf.ProviderGroup pg " +
            "WHERE pg.ProviderGroupID = ma.prov_group_id " +
            "AND pg.STATE = ma.providerstate " +
            ") AS [providerGroupName] " +
            ", ma.lob2 AS [lob] " +
            ", ma.clientid AS [clientId] " +
            ", ma.ClientNameOFCStandard AS [clientName] " +
            ", IIF(ma.DerivedDeployed = 1 AND UPPER(ma.RecordChangeType) <> 'DELETED', 1, 0) AS [deploymentsFlag] " +
            ", IIF(ma.Returned = 1 AND UPPER(ma.RecordChangeType) <> 'DELETED', 1, 0) AS [returnsFlag] " +
            ", IIF(ma.ReturnedNetCna = 1 AND UPPER(ma.RecordChangeType) <> 'DELETED', 1, 0) AS [returnsNetCNAFlag] " +
            ", ( " +
            "CASE " +
            "WHEN ma.distributionchannel IS NULL " +
            "THEN NULL " +
            "WHEN LEN(ma.distributionchannel) = 0 " +
            "THEN NULL " +
            "ELSE ISNULL(( " +
            "SELECT [Value] " +
            "FROM deployment_channel_translation_CTE " +
            "WHERE LTRIM(RTRIM(LOWER([Key]))) = LTRIM(RTRIM(LOWER(ma.distributionchannel))) " +
            "), ma.distributionchannel) " +
            "END " +
            ") AS [distributionChannel] " +
            ", ( " +
            "CASE " +
            "WHEN ma.retrievedby IS NULL " +
            "THEN NULL " +
            "WHEN LEN(ma.retrievedby) = 0 " +
            "THEN NULL " +
            "ELSE ISNULL(( " +
            "SELECT [Value] " +
            "FROM retrieval_channel_translation_CTE " +
            "WHERE LTRIM(RTRIM(LOWER([Key]))) = LTRIM(RTRIM(LOWER(ma.retrievedby))) " +
            "), 'Other') " +
            "END " +
            ") AS [retrievalChannel] " +
            ", ma.retrieval_date_clean AS [retrieval_date_clean] " +
            "FROM ProgPerf.MemberAssessment ma WITH (NOLOCK) " +
            "WHERE ma.deriveddeployed = 1 " +
            "AND ma.project_year IN (:PROGRAM_YEAR, :PREVIOUS_PROGRAM_YEAR) %s " +
            ") " +
            "SELECT PROV_GRP_CLIENT_LOB_CTE.[providerGroupID] " +
            ", PROV_GRP_CLIENT_LOB_CTE.[state] " +
            ", PROV_GRP_CLIENT_LOB_CTE.[programYear] " +
            ", PROV_GRP_CLIENT_LOB_CTE.[providerGroupName] " +
            ", PROV_GRP_CLIENT_LOB_CTE.[lob] " +
            ", PROV_GRP_CLIENT_LOB_CTE.[clientId] " +
            ", PROV_GRP_CLIENT_LOB_CTE.[clientName] " +
            ", SUM([deploymentsFlag]) AS [deploymentsCount] " +
            ", SUM([returnsFlag]) AS [returnsCount] " +
            ", SUM([returnsNetCNAFlag]) AS [returnsNetCNACount] " +
            ", PROV_GRP_CLIENT_LOB_CTE.[distributionChannel] " +
            ", PROV_GRP_CLIENT_LOB_CTE.[retrievalChannel] " +
            ", MAX(PROV_GRP_CLIENT_LOB_CTE.[retrieval_date_clean]) AS [lastReturnDate] " +
            "FROM PROV_GRP_CLIENT_LOB_CTE " +
            "GROUP BY PROV_GRP_CLIENT_LOB_CTE.[providerGroupID] " +
            ", PROV_GRP_CLIENT_LOB_CTE.[state] " +
            ", PROV_GRP_CLIENT_LOB_CTE.[programYear] " +
            ", PROV_GRP_CLIENT_LOB_CTE.[providerGroupName] " +
            ", PROV_GRP_CLIENT_LOB_CTE.[lob] " +
            ", PROV_GRP_CLIENT_LOB_CTE.[clientId] " +
            ", PROV_GRP_CLIENT_LOB_CTE.[clientName] " +
            ", PROV_GRP_CLIENT_LOB_CTE.[distributionChannel] " +
            ", PROV_GRP_CLIENT_LOB_CTE.[retrievalChannel] " +
            "ORDER BY PROV_GRP_CLIENT_LOB_CTE.[programYear] " +
            ", PROV_GRP_CLIENT_LOB_CTE.[lob] " +
            ", PROV_GRP_CLIENT_LOB_CTE.[clientId] " +
            ", PROV_GRP_CLIENT_LOB_CTE.[distributionChannel] " +
            ", PROV_GRP_CLIENT_LOB_CTE.[retrievalChannel] " +
            ", [lastReturnDate] ";

    private static final String MODIFIED_PROVIDER_GROUPS_MEMBERASSESSMENT_CTE=
            " AND ma.Prov_Group_ID + ma.providerstate in (  " +
                    " SELECT  " +
                    " DISTINCT Ax.Prov_Group_ID + Ax.providerstate AS ProviderGroupIDState  " +
                    " FROM  " +
                    " progperf.MemberAssessment Ax WITH (NOLOCK)  " +
                    " WHERE  " +
                    " Ax.Project_Year IN(:PROGRAM_YEAR,:PREVIOUS_PROGRAM_YEAR)  " +
                    " AND AX.providerstate IS NOT NULL  " +
                    " AND Ax.UpdatedDate > (select LastSuccessfulRunDate from ProgPerf.JobRunConfiguration where JobName = :JOBNAME)) ";

    @Override
    public Flux<ProviderGroupsDeployment> getProviderGroupsDeployment(Map<String,String> inputMap, JobEvent jobEvent) {
        log.info("{} : Repository::Getting Provider Groups Deployments for : {}", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier (), jobEvent.getGroupsToExecute());
        if(GroupsToExecute.MODIFIED.getValue().equalsIgnoreCase(jobEvent.getGroupsToExecute().toString())){
            final String modifiedQuery= String.format(SELECT_PROVIDERGROUP_DEPLOYMENTS ,MODIFIED_PROVIDER_GROUPS_MEMBERASSESSMENT, MODIFIED_PROVIDER_GROUPS_MEMBERASSESSMENT_HISTORY);
            return databaseClient.execute(modifiedQuery)
                    .bind("PROJECTYEAR", Integer.parseInt(inputMap.get(RuleConstants.PROGRAM_YEAR)))
                    .bind("LASTRUNDATE", String.valueOf(inputMap.get(RuleConstants.LOAD_LOB_TARGET_VALUES_AND_ACTUALS)))
                    .as(ProviderGroupsDeployment.class)
                    .fetch().all();
        }else{
            final String allQuery= String.format(SELECT_PROVIDERGROUP_DEPLOYMENTS , StringUtils.EMPTY,StringUtils.EMPTY);
            return databaseClient.execute(allQuery)
                    .bind("PROJECTYEAR", Integer.parseInt(inputMap.get(RuleConstants.PROGRAM_YEAR)))
                    .as(ProviderGroupsDeployment.class)
                    .fetch().all();
        }
    }

    @Override
    public Mono<Long> batchQueriesForProviderGroupDeploymentCounts(List<ProviderGroupsDeployment> providerGroupsDeploymentList, Map<String, String> inputMap) {
        List<String> updateQueries = providerGroupsDeploymentList.stream()
                .map(providerGroupsDeployment ->
                        getFormattedQueryForDeploymentCountsInsert(providerGroupsDeployment,inputMap)
                )
                .collect(Collectors.toList());
        providerGroupsDeploymentList.clear();
        return commonRepository.updateBatchQueries(updateQueries);
    }

    private String getFormattedQueryForDeploymentCountsInsert(ProviderGroupsDeployment providerGroupsDeployment, Map<String, String> inputMap) {
        if(Integer.parseInt(inputMap.get(RuleConstants.PROGRAM_YEAR)) == providerGroupsDeployment.getProgramYear())
            return String.format(UPDATE_DEPLOYMENT_COUNTS_PROVIDER_GROUP, providerGroupsDeployment.getDeploymentsCount(),
                    providerGroupsDeployment.getProviderGroupID(),providerGroupsDeployment.getState());
        else
            return String.format(UPDATE_PREVIOUS_YEAR_DEPLOYMENT_COUNTS_PROVIDER_GROUP, providerGroupsDeployment.getDeploymentsCount(),
                    providerGroupsDeployment.getProviderGroupID(),providerGroupsDeployment.getState());

    }

    @Override
    public Mono<Long> batchQueriesForProviderGroupDeploymentCountsV1(List<ProviderGroupPerformanceInfo> providerGroupsDeploymentList, Map<String, String> jobEvent) {
        List<String> updateQueries = providerGroupsDeploymentList.stream()
                .map(providerGroupsDeployment ->
                        getFormattedQueryForDeploymentCountsInsertV1(providerGroupsDeployment,jobEvent)
                )
                .collect(Collectors.toList());
        providerGroupsDeploymentList.clear();
        return commonRepository.updateBatchQueries(updateQueries);
    }

    private String getFormattedQueryForDeploymentCountsInsertV1(ProviderGroupPerformanceInfo providerGroupsDeployment, Map<String, String> jobEvent) {
        if(Integer.parseInt(jobEvent.get(RuleConstants.PROGRAM_YEAR)) == providerGroupsDeployment.getProgramYear())
            return String.format(UPDATE_DEPLOYMENT_COUNTS_PROVIDER_GROUP, providerGroupsDeployment.getDeploymentsCount(),
                    providerGroupsDeployment.getProviderGroupID(),providerGroupsDeployment.getState());
        else
            return String.format(UPDATE_PREVIOUS_YEAR_DEPLOYMENT_COUNTS_PROVIDER_GROUP, providerGroupsDeployment.getDeploymentsCount(),
                    providerGroupsDeployment.getProviderGroupID(),providerGroupsDeployment.getState());

    }



    @Override
    public Flux<ProviderGroupFlatData> getDeploymentsWithCTE(JobEvent jobEvent) {

        log.info("{} : Repository::Getting Provider Groups Deployments for : {}", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier (), jobEvent.getGroupsToExecute());
        if(GroupsToExecute.MODIFIED.getValue().equalsIgnoreCase(jobEvent.getGroupsToExecute().toString())){
            final String modifiedQuery= String.format(SELECT_DEPLOYEMNT_DETAIL_INFO_WITH_CTE, MODIFIED_PROVIDER_GROUPS_MEMBERASSESSMENT_CTE);
            return databaseClient.execute(modifiedQuery)
                    .bind("PROGRAM_YEAR", jobEvent.getProgramYear())
                    .bind("PREVIOUS_PROGRAM_YEAR",jobEvent.getProgramYear() - 1)
                    .bind("JOBNAME", jobEvent.getJobName().toString())
                    .as(ProviderGroupFlatData.class)
                    .fetch()
                    .all();
        } else {
            final String modifiedQuery= String.format(SELECT_DEPLOYEMNT_DETAIL_INFO_WITH_CTE, StringUtils.EMPTY);
            return databaseClient.execute(modifiedQuery)
                    .bind("PROGRAM_YEAR", jobEvent.getProgramYear())
                    .bind("PREVIOUS_PROGRAM_YEAR",jobEvent.getProgramYear() - 1)
                    .as(ProviderGroupFlatData.class)
                    .fetch()
                    .all();
        }
    }
}
