package com.optum.rqns.ftm.dto.opportunities.providergrp.converter;


import com.optum.rqns.ftm.constants.ProviderGroupConstants;
import com.optum.rqns.ftm.model.opportunities.providergrp.ClientsFilterDetails;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;

public class ClientLobFilterDetailsConverter implements Converter<Row, ClientsFilterDetails> {

    public ClientsFilterDetails convert(Row row) {
        return ClientsFilterDetails.builder()
                .clientName(row.get(ProviderGroupConstants.CLIENT_NAME, String.class))
                .clientId(row.get(ProviderGroupConstants.CLIENT_ID,String.class))
                .build();
    }
}
