package com.optum.rqns.ftm.model.goals.client;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ClientLobGoalValues {
    private String goalType;
    @JsonProperty("aggregate")
    private GoalDetailValues goalDetailValues;
    @JsonProperty("regions")
    private List<ClientLobRegionGoalValues> clientLobRegionGoalValues;
}
