package com.optum.rqns.ftm.repository.commandcenter;

import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.dto.commandcenter.ProviderGroupClientMemberCount;
import com.optum.rqns.ftm.repository.performance.providergrp.ProviderGroupPerformanceRepositoryImpl;
import org.springframework.data.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;

@Repository
public class CCProviderClientMemberCountRepositoryImpl implements CCProviderGroupClientMemberCountRepository, DTOWrapperTypeConverter {

    private final DatabaseClient client;

    CCProviderClientMemberCountRepositoryImpl(DatabaseClient client) {
        this.client = client;
    }

    private static final String GET_PROVIDER_GROUP_CLIENT_MEMBER_DATA = "SELECT distinct  pgpw .ClientName ,pgpw .LobName as lob, " +
            "(case when pgpw .PreferredMemberCount is null then 0 else pgpw .PreferredMemberCount  end ) as totalMembership, " +
            "(case when pgpw .EligiblePreferredMemberCount is null then 0 else pgpw .EligiblePreferredMemberCount  end )  as eligibleMembership, " +
            "(case  when pgpw.IsIDMTarget=1 and pgpw.DeployYETarget >0 then 1 else 0 end ) as IsIDMTarget , " +
            "(case when pgpw .DeploymentsOpportunityAssessmentCount is null then 0 else pgpw .DeploymentsOpportunityAssessmentCount  end ) as programEligibleMembercount " +
            "from ProgPerf .ProviderGroupPerformanceWeekly pgpw " +
            "where pgpw.IsCurrentWeekForPerformance ='1' " +
            "and pgpw .ProgramYear =:ProgramYear " +
            "and pgpw.ProviderGroupID=:ProviderGroupId " +
            "and pgpw.State =:State " +
            "and (case when pgpw .PreferredMemberCount is null then 0 else pgpw .PreferredMemberCount  end ) not in (0) " +
            "order by pgpw .ClientName ,pgpw .LobName  ; ";
    @Override
    public Flux<ProviderGroupClientMemberCount> getProviderGroupClientLobData(String providerGroupId, String state, String programYear) {
        return client.execute(GET_PROVIDER_GROUP_CLIENT_MEMBER_DATA)
                .bind(ProviderGroupPerformanceRepositoryImpl.ColumnNames.PROVIDER_GROUP_ID.getColumnName(), providerGroupId)
                .bind(ProviderGroupPerformanceRepositoryImpl.ColumnNames.STATE.getColumnName(), state)
                .bind(ProviderGroupPerformanceRepositoryImpl.ColumnNames.PROGRAM_YEAR.getColumnName(), programYear)
                .as(ProviderGroupClientMemberCount.class)
                .fetch()
                .all();
    }

    @Override
    public Mono<LocalDateTime> getLastUpdateDateforClientsEligibleMemberCount() {
        return client.execute("SELECT jrc.LastSuccessfulRunDate FROM ProgPerf.JobRunConfiguration jrc where jrc.JobName ='RunEligibleMemberCount'")
                .as(LocalDateTime.class)
                .fetch()
                .one();
    }
}
