package com.optum.rqns.ftm.dto.opportunities.providergrp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class OpportunityConfigurationDTO {
    private int id;
    private String masterOpportunityName;
    private String opportunityName;
    private int masterOpportunityDisplayOrder;
    private int opportunityDisplayOrder;
    private String databaseLogic;
    private boolean isActive;
    private String whereClauseCondition;
    private String selectClauseCondition;
    private boolean isSummaryAggregationRequired;
}
