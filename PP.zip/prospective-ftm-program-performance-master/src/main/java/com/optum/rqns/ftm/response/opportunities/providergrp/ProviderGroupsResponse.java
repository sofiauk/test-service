package com.optum.rqns.ftm.response.opportunities.providergrp;

import com.optum.rqns.ftm.model.rules.ProviderGroup;
import com.optum.rqns.ftm.wrapper.Meta;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.ToString;

import java.util.ArrayList;
import java.util.List;

@Data
@ToString
@AllArgsConstructor
@Builder
public class ProviderGroupsResponse {
    private Meta meta;

    private List<ProviderGroup> data;

    public ProviderGroupsResponse() {
        this.meta = new Meta();
        this.data = new ArrayList<>();
    }
}
