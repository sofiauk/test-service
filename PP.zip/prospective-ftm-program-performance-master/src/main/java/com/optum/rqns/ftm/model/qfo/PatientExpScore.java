package com.optum.rqns.ftm.model.qfo;

import lombok.Data;
import lombok.Builder;
import lombok.AllArgsConstructor;
import java.util.ArrayList;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
public class PatientExpScore {
    private String typeName;
    private Integer score;
    private List<QuestionDetail> questionList;
    private String lastUpdatedDate;

    public PatientExpScore() {
        this.questionList=new ArrayList<>();
    }

    public void addQuestionList(QuestionDetail questionDetail){
        this.questionList.add(questionDetail);
    }

}


