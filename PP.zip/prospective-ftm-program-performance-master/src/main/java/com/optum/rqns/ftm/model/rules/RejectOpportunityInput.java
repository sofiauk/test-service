package com.optum.rqns.ftm.model.rules;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RejectOpportunityInput implements OpportunityInput {
    String  providerGroupId ;
    String  providerGroupName ;
    String providerState;
    String serviceLevel;
    int projectYear;
    String client;
    String clientId;
    String lobName;
    String chartID;
    String singleRejectReason;
    String overAllStatus;

    @Override
    public String getPaymentRejectReason() {
        return null;
    }

    @Override
    public String getOutlierName() {
        return null;
    }

    @Override
    public String getGapType() {
        return null;
    }

    @Override
    public String getGapDesc() {
        return null;
    }

    @Override
    public String getIsSecondarySubmissionEligible() {
        return null;
    }

    @Override
    public int getDeployYTDActual() {
        return 0;
    }

    @Override
    public int getReturnYTDActual() {
        return 0;
    }

    @Override
    public int getReturnYTDActualPercentage() {
        return 0;
    }

    @Override
    public int getReturnYTDTargetPercent() {
        return 0;
    }

    @Override
    public int getEligibleMembersCount() {
        return 0;
    }

}
