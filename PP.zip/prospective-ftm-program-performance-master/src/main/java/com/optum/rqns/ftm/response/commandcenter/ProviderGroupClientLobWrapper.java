package com.optum.rqns.ftm.response.commandcenter;

import com.optum.rqns.ftm.dto.commandcenter.ProviderGroupClientMembersCountDto;
import com.optum.rqns.ftm.wrapper.Meta;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ProviderGroupClientLobWrapper {
    private List<ProviderGroupClientMembersCountDto> providerGroupClientMembers;
    private LocalDateTime lastUpdateDate;

}
