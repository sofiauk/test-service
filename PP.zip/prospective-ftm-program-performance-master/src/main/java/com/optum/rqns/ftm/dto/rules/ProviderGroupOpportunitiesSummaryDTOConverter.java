package com.optum.rqns.ftm.dto.rules;

import com.optum.rqns.ftm.constants.RuleConstants;
import com.optum.rqns.ftm.repository.rules.RuleRepositoryImpl;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;

import java.time.LocalDateTime;

public class ProviderGroupOpportunitiesSummaryDTOConverter implements Converter<Row, ProviderGroupOpportunitiesSummaryDTO> {
    @Override
    public ProviderGroupOpportunitiesSummaryDTO convert(Row rs) {
        return ProviderGroupOpportunitiesSummaryDTO.builder()
                .opportunityID(rs.get(RuleRepositoryImpl.ColumnNames.ROW_ACTION.getColumnName()).toString().equalsIgnoreCase(RuleConstants.DELETED) ? rs.get(RuleRepositoryImpl.ColumnNames.OPPORTUNITY_ID.getColumnName(), Integer.class) : rs.get(RuleRepositoryImpl.ColumnNames.ID.getColumnName(), Integer.class))
                .providerGroupID(rs.get(RuleRepositoryImpl.ColumnNames.PROVIDERGROUPID.getColumnName(), String.class))
                .providerGroupName(rs.get(RuleRepositoryImpl.ColumnNames.PROVIDERGROUP_NAME.getColumnName(), String.class))
                .state(rs.get(RuleRepositoryImpl.ColumnNames.STATE.getColumnName(), String.class))
                .programYear(rs.get(RuleRepositoryImpl.ColumnNames.PROGRAMYEAR.getColumnName(), Integer.class))
                .masterOpportunityType(rs.get(RuleRepositoryImpl.ColumnNames.MASTERLEVELOPPORTUNITY.getColumnName(), String.class))
                .masterOpportunityTypePosition(rs.get(RuleRepositoryImpl.ColumnNames.MASTERLEVELOPPORTUNITY_POSITION.getColumnName(), Integer.class))
                .totalAssessmentsCount(rs.get(RuleRepositoryImpl.ColumnNames.TOTALASSESSMENTSCOUNT.getColumnName(), Integer.class))
                .totalClientsCount(rs.get(RuleRepositoryImpl.ColumnNames.TOTALCLIENTSCOUNT.getColumnName(), Integer.class))
                .totalGapsCount(rs.get(RuleRepositoryImpl.ColumnNames.TOTALGAPSCOUNT.getColumnName(), Integer.class))
                .createdBy(rs.get(RuleRepositoryImpl.ColumnNames.CREATEDBY.getColumnName(), String.class))
                .createdDate(rs.get(RuleRepositoryImpl.ColumnNames.CREATEDDATE.getColumnName(), LocalDateTime.class))
                .rowAction(rs.get(RuleRepositoryImpl.ColumnNames.ROW_ACTION.getColumnName(), String.class))
                .build();
    }
}
