package com.optum.rqns.ftm.repository.programyearcalendar;

import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.model.programyearcalendar.CurrentPreviousMonth;
import com.optum.rqns.ftm.model.programyearcalendar.DurationWeekCurrentPreviousMonth;
import io.r2dbc.spi.Row;
import org.springframework.data.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Repository
public class ProgramYearCalendarRepositoryImpl implements ProgramYearCalendarRepository, DTOWrapperTypeConverter {

    private final DatabaseClient client;

    private static final String QUERY =
            "SELECT " +
            "   v.*, " +
            "   (CASE " +
            "       WHEN v.IsCurrentProgramYear = 1 " +
            "       THEN CASE " +
            "           WHEN v.CurrentMonth = 'JAN' THEN 'DEC' " +
            "           WHEN v.CurrentMonth = 'FEB' THEN 'JAN' " +
            "           WHEN v.CurrentMonth = 'MAR' THEN 'FEB' " +
            "           WHEN v.CurrentMonth = 'APR' THEN 'MAR' " +
            "           WHEN v.CurrentMonth = 'MAY' THEN 'APR' " +
            "           WHEN v.CurrentMonth = 'JUN' THEN 'MAY' " +
            "           WHEN v.CurrentMonth = 'JUL' THEN 'JUN' " +
            "           WHEN v.CurrentMonth = 'AUG' THEN 'JUL' " +
            "           WHEN v.CurrentMonth = 'SEP' THEN 'AUG' " +
            "           WHEN v.CurrentMonth = 'OCT' THEN 'SEP' " +
            "           WHEN v.CurrentMonth = 'NOV' THEN 'OCT' " +
            "           WHEN v.CurrentMonth = 'DEC' THEN 'NOV' " +
            "           ELSE NULL " +
            "           END " +
            "       ELSE 'DEC' " +
            "       END " +
            "   ) AS PreviousMonth " +
            "FROM ( " +
            "   SELECT " +
            "       u.*, " +
            "       (CASE " +
            "           WHEN u.IsCurrentProgramYear = 1 " +
            "           THEN " +
            "               (SELECT [Month] " +
            "               FROM ProgPerf.ProgramYearCalendar pyc " +
            "               WHERE pyc.ProgramYear = :ProgramYear " +
            "               AND GETDATE() BETWEEN StartDate AND EndDate " +
            "               AND DurationType = 'WEEK') " +
            "           ELSE 'JAN' " +
            "           END " +
            "       ) AS CurrentMonth " +
            "   FROM ( " +
            "       SELECT " +
            "           (CASE WHEN t.CurrentProgramYear = :ProgramYear THEN 1 ELSE 0 END) AS IsCurrentProgramYear " +
            "       FROM ( " +
            "           SELECT CAST(value AS INT) AS CurrentProgramYear " +
            "           FROM ProgPerf.MasterConfiguration " +
            "           WHERE code = 'CurrentProgramYear' " +
            "       ) t " +
            "   ) u " +
            ") v ";

    private static final String GET_DURATION_CURRENT_WEEK_AND_LAST_WEEK_OF_PREVIOUS_MONTH =
            " WITH CTE_CURRENT " +
            "   AS ( " +
            "       SELECT TOP (1) DurationValue AS currentWeek " +
            "       FROM [ProgPerf].[ProgramYearCalendar] WITH (NOLOCK) " +
            "       WHERE DurationType = 'WEEK' " +
            "       AND StartDate <= GETUTCDATE() " +
            "       AND EndDate >= GETUTCDATE() " +
            "   )" +
            "   , CTE_PREV_MTH " +
            "   AS ( " +
            "       SELECT TOP (1) DurationValue AS lastWeekPreviousMonth " +
            "       FROM [ProgPerf].[ProgramYearCalendar] WITH (NOLOCK) " +
            "       WHERE DurationType = 'WEEK' " +
            "       AND StartDate <= DATEADD(s, - 1, DATEADD(m, DATEDIFF(m, 0, GETUTCDATE()), 0)) " +
            "       AND EndDate >= DATEADD(s, - 1, DATEADD(m, DATEDIFF(m, 0, GETUTCDATE()), 0)) " +
            "   ) " +
            " SELECT CTE_CURRENT.currentWeek, CTE_PREV_MTH.lastWeekPreviousMonth " +
            " FROM CTE_CURRENT, CTE_PREV_MTH;";

    ProgramYearCalendarRepositoryImpl(DatabaseClient client) {
        this.client = client;
    }

    @Override
    public Flux<CurrentPreviousMonth> getCurrentPreviousMonth(int programYear) {
        return client.execute(QUERY)
                .bind("ProgramYear",programYear)
                .as(CurrentPreviousMonth.class)
                .map((row, rowMetadata) -> CurrentPreviousMonth
                        .builder()
                        .isCurrentProgramYear(getPrimitiveIntegerValue(row,"IsCurrentProgramYear"))
                        .currentMonth(getStringValue(row,"CurrentMonth"))
                        .previousMonth(getStringValue(row,"PreviousMonth"))
                        .build()
                )
                .all();
    }

    private String getStringValue(Row row, String columnName) {
        return getValue(row, columnName, String.class);
    }

    public Mono<DurationWeekCurrentPreviousMonth> getDurationValueCurrentWeekAndPreviousMonth()
    {
        return client.execute(GET_DURATION_CURRENT_WEEK_AND_LAST_WEEK_OF_PREVIOUS_MONTH)
                .as(DurationWeekCurrentPreviousMonth.class)
                .map((row, rowMetadata) -> DurationWeekCurrentPreviousMonth
                        .builder()
                        .currentWeek(getStringValue(row,"currentWeek"))
                        .lastWeekPreviousMonth(getStringValue(row,"lastWeekPreviousMonth"))
                        .build()
                )
                .one ();
    }

}
