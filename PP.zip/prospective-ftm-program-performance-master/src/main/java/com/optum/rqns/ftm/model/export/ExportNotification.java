package com.optum.rqns.ftm.model.export;

import com.optum.rqns.ftm.enums.ExportStatus;
import com.optum.rqns.ftm.enums.ProcessSubType;
import com.optum.rqns.ftm.enums.ProcessType;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.Objects;

@Data
@NoArgsConstructor
@Builder
@AllArgsConstructor
public class ExportNotification {
    private String optumUuid;
    private long transactionId;
    @Getter(AccessLevel.NONE)
    private ProcessType processType;
    @Getter(AccessLevel.NONE)
    private ProcessSubType processSubType;
    private String fileName;
    @Getter(AccessLevel.NONE)
    private ExportStatus exportStatus;
    private boolean isNotified;
    private boolean isActive;

    public String getExportStatus() {
        return Objects.nonNull(this.exportStatus) ? this.exportStatus.getValue() : null;
    }

    public String getProcessType() {
        return Objects.nonNull(this.processType) ? this.processType.getValue() : null;
    }

    public String getProcessSubType() {
        return Objects.nonNull(this.processSubType) ? this.processSubType.getValue() : null;
    }
}