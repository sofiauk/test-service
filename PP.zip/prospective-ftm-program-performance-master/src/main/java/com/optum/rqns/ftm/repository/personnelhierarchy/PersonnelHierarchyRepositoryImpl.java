package com.optum.rqns.ftm.repository.personnelhierarchy;

import com.optum.rqns.ftm.model.personnelhierarchy.PersonnelHierarchy;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;
import java.util.Objects;

@Repository
@Slf4j
public class PersonnelHierarchyRepositoryImpl implements PersonnelHierarchyRepository {

    private final DatabaseClient client;

    @Autowired
    public PersonnelHierarchyRepositoryImpl(DatabaseClient client) {
        this.client = client;
    }

    private static final String PARENT_ID = "parentId";
    private static final String UUID = "uuid";
    private static final String DELETED_DATE = "deletedDate";

    private static final String GET_HIERARCHY =
            "SELECT u.UUID, u.FirstName, u.LastName, JSON_VALUE(u.[Role], '$[0].name') AS Role, u.Status, p.PersonnelHierarchyId, p.ParentId " +
                    "FROM ProgPerf.Users u " +
                    "LEFT JOIN ProgPerf.PersonnelHierarchy p " +
                    "ON p.UUID LIKE u.UUID AND p.DeletedDate IS NULL";

    private static final String GET_HIERARCHY_NODE =
            "SELECT u.UUID, u.FirstName, u.LastName, JSON_VALUE(u.[Role], '$[0].name') AS Role, u.Status, p.PersonnelHierarchyId, p.ParentId " +
                    "FROM ProgPerf.Users u " +
                    "LEFT JOIN ProgPerf.PersonnelHierarchy p " +
                    "ON p.UUID LIKE u.UUID " +
                    "WHERE u.UUID = :uuid";

    private static final String INSERT_HIERARCHY =
            "INSERT INTO ProgPerf.PersonnelHierarchy(UUID, ParentId) " +
                    "VALUES(:uuid, :parentId)";

    private static final String UPDATE_HIERARCHY =
            "UPDATE ProgPerf.PersonnelHierarchy " +
                    "SET ParentId = :parentId, DeletedDate = NULL " +
                    "WHERE UUID = :uuid";

    private static final String REMOVE_HIERARCHY =
            "UPDATE ProgPerf.PersonnelHierarchy " +
                    "SET DeletedDate = :deletedDate " +
                    "WHERE UUID = :uuid";

    @Override
    public Flux<PersonnelHierarchy> getPersonnelHierarchy() {
        return client.execute(GET_HIERARCHY)
                .map((row, rowMetadata) -> {
                    boolean convertedStatus = Objects.equals(row.get("Status", String.class), "A");
                    return PersonnelHierarchy.builder()
                            .uuid(row.get("UUID", String.class))
                            .firstName(row.get("FirstName", String.class))
                            .lastName(row.get("LastName", String.class))
                            .role(row.get("Role", String.class))
                            .isActive(convertedStatus)
                            .personnelHierarchyId(row.get("PersonnelHierarchyId", Integer.class))
                            .parentId(row.get("ParentId", Integer.class))
                            .build();
                })
                .all();
    }
    @Override
    public Flux<PersonnelHierarchy> getPersonnelHierarchyNode(String uuid) {
        return client.execute(GET_HIERARCHY_NODE)
                .bind("uuid", uuid)
                .map((row, rowMetadata) -> {
                    boolean convertedStatus = Objects.equals(row.get("Status", String.class), "A");
                    return PersonnelHierarchy.builder()
                            .uuid(row.get("UUID", String.class))
                            .firstName(row.get("FirstName", String.class))
                            .lastName(row.get("LastName", String.class))
                            .role(row.get("Role", String.class))
                            .isActive(convertedStatus)
                            .personnelHierarchyId(row.get("PersonnelHierarchyId", Integer.class))
                            .parentId(row.get("ParentId", Integer.class))
                            .build();
                })
                .all();
    }


    @Override
    public Mono<Integer> createPersonnelHierarchy(String uuid, Integer parentId) {
        if (parentId == null) {
            return client.execute(INSERT_HIERARCHY)
                    .bind(UUID, uuid)
                    .bindNull(PARENT_ID, Integer.class)
                    .fetch()
                    .rowsUpdated();
        }
        return client.execute(INSERT_HIERARCHY)
                .bind(UUID, uuid)
                .bind(PARENT_ID, parentId)
                .fetch()
                .rowsUpdated();
    }

    @Override
    public Mono<Integer> updatePersonnelHierarchy(String uuid, Integer parentId) {
        if (parentId == null) {
            return client.execute(UPDATE_HIERARCHY)
                    .bind(UUID, uuid)
                    .bindNull(PARENT_ID, Integer.class)
                    .fetch()
                    .rowsUpdated();
        }
        return client.execute(UPDATE_HIERARCHY)
                .bind(UUID, uuid)
                .bind(PARENT_ID, parentId)
                .fetch()
                .rowsUpdated();
    }

    @Override
    public Mono<Integer> removePersonnelHierarchy(String uuid, LocalDateTime deletedDate) {
        return client.execute(REMOVE_HIERARCHY)
                .bind(UUID, uuid)
                .bind(DELETED_DATE, deletedDate)
                .fetch()
                .rowsUpdated();
    }
}
