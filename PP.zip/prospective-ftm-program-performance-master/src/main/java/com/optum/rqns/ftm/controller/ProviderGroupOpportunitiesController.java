package com.optum.rqns.ftm.controller;


import com.optum.rqns.ftm.customannotation.CustomApiResponse;
import com.optum.rqns.ftm.enums.TypeEnum;
import com.optum.rqns.ftm.exception.APIErrorCode;
import com.optum.rqns.ftm.exception.ProgramPerformanceException;
import com.optum.rqns.ftm.model.UserInfo;
import com.optum.rqns.ftm.model.opportunities.providergrp.DetailsRequestBody;
import com.optum.rqns.ftm.model.opportunities.providergrp.ClientsRequestBody;
import com.optum.rqns.ftm.model.opportunities.providergrp.MemberAssessment;
import com.optum.rqns.ftm.model.opportunities.providergrp.ProviderGroupMemberAssessment;
import com.optum.rqns.ftm.model.opportunities.providergrp.ProviderGroupMemberGap;
import com.optum.rqns.ftm.model.opportunities.providergrp.QFOHealthSystemDetailsRequestBody;
import com.optum.rqns.ftm.response.opportunities.providergrp.MemberAssessmentClientResponse;
import com.optum.rqns.ftm.response.opportunities.providergrp.PAFilterResponse;
import com.optum.rqns.ftm.response.opportunities.providergrp.MemberAssessmentLobResponse;
import com.optum.rqns.ftm.response.opportunities.providergrp.MemberAssessmentOpportunitySubTypeResponse;
import com.optum.rqns.ftm.response.opportunities.providergrp.MemberAssessmentProgramYearResponse;
import com.optum.rqns.ftm.response.opportunities.providergrp.MemberGapAssessmentFluxResponse;
import com.optum.rqns.ftm.response.opportunities.providergrp.ClientDetailsFluxResponse;
import com.optum.rqns.ftm.response.opportunities.providergrp.OpportunitiesDetailsResponse;
import com.optum.rqns.ftm.response.opportunities.providergrp.ProviderGroupMemberAssessmentResponse;
import com.optum.rqns.ftm.response.opportunities.providergrp.ProviderGroupMemberGapResponse;
import com.optum.rqns.ftm.response.opportunities.providergrp.ProviderGroupOpportunitiesResponse;
import com.optum.rqns.ftm.response.opportunities.providergrp.ProviderGroupsResponse;
import com.optum.rqns.ftm.response.opportunities.providergrp.QFOHealthSystemOpportunitiesDetailsResponse;
import com.optum.rqns.ftm.service.opportunities.providergrp.ProviderGroupOpportunitiesService;
import com.optum.rqns.ftm.util.ProgramPerformanceUtil;
import com.optum.rqns.ftm.util.StargateStandardResponseUtilV2;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

import java.io.InputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

import static com.optum.rqns.ftm.constants.ProviderGroupConstants.REG_EXP_ALPHA_NUMERIC;

@Profile("rqnsFtmApi")
@RestController
@RequestMapping("/v1/provider-groups")
@Slf4j
@CustomApiResponse
public class ProviderGroupOpportunitiesController {


    @Autowired
    private ProviderGroupOpportunitiesService providerGroupOpportunitiesService;

    @Autowired
    StargateStandardResponseUtilV2<Object,Object> stargateStandardResponseUtilV2;

    @ApiResponse(responseCode = "202", description = "Success Request", content = @Content(schema = @Schema(implementation = ProviderGroupMemberAssessmentResponse.class),mediaType = MediaType.APPLICATION_JSON_VALUE))
    @PostMapping("/{provider-group-id}/opportunities/{opportunity-type}")
    public Mono<ProviderGroupMemberAssessmentResponse> getMemberAssessments(@PathVariable("provider-group-id") String providerGroupId, @PathVariable("opportunity-type") String opportunityType, @RequestBody MemberAssessment memberAssessment, @RequestHeader("x-userDetails") String userDetailsJson,@RequestHeader("x-providerOnshore") String providerOnshoreFlag){
        log.debug("Getting Provider Group Opportunities Member Assessments for the Given Details: {}, {}", providerGroupId,memberAssessment);
        UserInfo userInfo = (UserInfo) ProgramPerformanceUtil.jsonToPojo(userDetailsJson, UserInfo.class);
        boolean offshoreRestricted = userInfo.isOffshore();
        if(memberAssessment.isValid(providerGroupId,opportunityType)) {
            return stargateStandardResponseUtilV2.generateStargateStandardResponse(providerGroupOpportunitiesService.getMemberAssessments(memberAssessment,offshoreRestricted), TypeEnum.MONO, new ProviderGroupMemberAssessmentResponse()).cast(ProviderGroupMemberAssessmentResponse.class);
        }else{
            log.info("invalid input params");
            return stargateStandardResponseUtilV2.generateStargateStandardResponse(Mono.error(new ProgramPerformanceException(HttpStatus.NOT_FOUND, APIErrorCode.PROVIDER_GROUP_INVALID_PARAMS)), TypeEnum.MONO, new ProviderGroupMemberAssessmentResponse()).cast(ProviderGroupMemberAssessmentResponse.class);
        }
    }

    @ApiResponse(responseCode = "202", description = "Success Request", content = @Content(schema = @Schema(implementation = ProviderGroupMemberGapResponse.class),mediaType = MediaType.APPLICATION_JSON_VALUE))
    @PostMapping("/{provider-group-id}/opportunities/outliers")
    public Mono<ProviderGroupMemberGapResponse> getMemberGaps(@PathVariable("provider-group-id") String providerGroupId, @RequestBody MemberAssessment memberAssessment, @RequestHeader("x-userDetails") String userDetailsJson,@RequestHeader("x-providerOnshore") String providerOnshoreFlag) {
        log.debug("Getting Provider Group Opportunities Member Gaps for the Given Details: {}, {}", providerGroupId,memberAssessment);
        UserInfo userInfo = (UserInfo) ProgramPerformanceUtil.jsonToPojo(userDetailsJson, UserInfo.class);
        boolean offshoreRestricted = userInfo.isOffshore();
        if(memberAssessment.isProviderValid(providerGroupId)) {
            return stargateStandardResponseUtilV2.generateStargateStandardResponse(providerGroupOpportunitiesService.getMemberGaps(memberAssessment,offshoreRestricted), TypeEnum.MONO, new ProviderGroupMemberGapResponse()).cast(ProviderGroupMemberGapResponse.class);
        }else{
            return stargateStandardResponseUtilV2.generateStargateStandardResponse(Mono.error(new ProgramPerformanceException(HttpStatus.NOT_FOUND, APIErrorCode.PROVIDER_GROUP_INVALID_PARAMS)), TypeEnum.MONO, new ProviderGroupMemberGapResponse()).cast(ProviderGroupMemberGapResponse.class);
        }
    }

    @GetMapping("/{provider-group-id}/opportunities/summaries")
    @ApiResponse(responseCode = "200", description = "Success Request", content = @Content(schema = @Schema(implementation = ProviderGroupOpportunitiesResponse.class), mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<ProviderGroupOpportunitiesResponse> getOpportunitySummaryDetails(@PathVariable("provider-group-id") String providerGroupId, @RequestParam String state, @RequestParam("service-level") String serviceLevel,@RequestParam("program-year") int programYear) {
        return stargateStandardResponseUtilV2.generateStargateStandardResponse(providerGroupOpportunitiesService.getOpportunitiesSummary(providerGroupId, state, serviceLevel, programYear), TypeEnum.FLUX,new ProviderGroupOpportunitiesResponse()).cast(ProviderGroupOpportunitiesResponse.class);
    }

    @GetMapping("/{provider-group-id}/opportunities/details")
    @ApiResponse(responseCode = "200", description = "Success Request", content = @Content(schema = @Schema(implementation = ProviderGroupOpportunitiesResponse.class), mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<ProviderGroupOpportunitiesResponse> getOpportunityDetails(@PathVariable("provider-group-id") String providerGroupId, @RequestParam String state, @RequestParam("service-level") String serviceLevel, @RequestParam("program-year") String programYear) {
        return stargateStandardResponseUtilV2.generateStargateStandardResponse(providerGroupOpportunitiesService.getOpportunitiesDetails(providerGroupId, state, serviceLevel, programYear), TypeEnum.FLUX, new ProviderGroupOpportunitiesResponse()).cast(ProviderGroupOpportunitiesResponse.class);
    }

    @GetMapping("/{provider-group-id}/opportunities/opportunity-sub-types")
    @ApiResponse(responseCode = "200", description = "Success Request", content = @Content(schema = @Schema(implementation = ProviderGroupsResponse.class), mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<MemberAssessmentOpportunitySubTypeResponse> getMemberAssessmentOpportunitySubTypes(@PathVariable("provider-group-id") String providerGroupId, @RequestParam String state, @RequestParam String type, @RequestParam("service-level") String serviceLevel,@RequestParam("program-year") int programYear) {
        return stargateStandardResponseUtilV2.generateStargateStandardResponse(providerGroupOpportunitiesService.getMemberAssessmentOpportunitySubTypes(providerGroupId,state, type, serviceLevel,programYear), TypeEnum.FLUX, new MemberAssessmentOpportunitySubTypeResponse()).cast(MemberAssessmentOpportunitySubTypeResponse.class);
    }

    @GetMapping("/{provider-group-id}/opportunities/years")
    @ApiResponse(responseCode = "200", description = "Success Request", content = @Content(schema = @Schema(implementation = ProviderGroupsResponse.class), mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<MemberAssessmentProgramYearResponse> getMemberAssessmentProgramYears(@PathVariable("provider-group-id") String providerGroupId, @RequestParam String state, @RequestParam String type, @RequestParam("service-level") String serviceLevel) {
        return stargateStandardResponseUtilV2.generateStargateStandardResponse(providerGroupOpportunitiesService.getMemberAssessmentProgramYears(providerGroupId,state, type, serviceLevel), TypeEnum.FLUX, new MemberAssessmentProgramYearResponse()).cast(MemberAssessmentProgramYearResponse.class);
    }

    @GetMapping("/{provider-group-id}/opportunities/lobs")
    @ApiResponse(responseCode = "200", description = "Success Request", content = @Content(schema = @Schema(implementation = ProviderGroupsResponse.class), mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<MemberAssessmentLobResponse> getMemberAssessmentLobs(@PathVariable("provider-group-id") String providerGroupId, @RequestParam String state, @RequestParam String type, @RequestParam("service-level") String serviceLevel,@RequestParam("program-year") int programYear, @RequestHeader("x-userDetails") String userDetailsJson,@RequestHeader("x-providerOnshore") String providerOnshoreFlag) {
        UserInfo userInfo = (UserInfo) ProgramPerformanceUtil.jsonToPojo(userDetailsJson, UserInfo.class);
        boolean offshoreRestricted = userInfo.isOffshore();
    	return stargateStandardResponseUtilV2.generateStargateStandardResponse(providerGroupOpportunitiesService.getMemberAssessmentLobs(providerGroupId,state, type, serviceLevel, offshoreRestricted,programYear), TypeEnum.FLUX, new MemberAssessmentLobResponse()).cast(MemberAssessmentLobResponse.class);
    }

    @GetMapping("/{provider-group-id}/opportunities/clients")
    @ApiResponse(responseCode = "200", description = "Success Request", content = @Content(schema = @Schema(implementation = ProviderGroupsResponse.class), mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<MemberAssessmentClientResponse> getMemberAssessmentClients(@PathVariable("provider-group-id") String providerGroupId, @RequestParam String state, @RequestParam String type, @RequestParam("service-level") String serviceLevel,@RequestParam("program-year") int programYear) {
        return stargateStandardResponseUtilV2.generateStargateStandardResponse(providerGroupOpportunitiesService.getMemberAssessmentClients(providerGroupId,state, type, serviceLevel,programYear), TypeEnum.FLUX, new MemberAssessmentClientResponse()).cast(MemberAssessmentClientResponse.class);
    }


    @GetMapping("/{provider-group-id}/opportunities/gaps-years")
    @ApiResponse(responseCode = "200", description = "Success Request", content = @Content(schema = @Schema(implementation = MemberGapAssessmentFluxResponse.class), mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<MemberGapAssessmentFluxResponse> getMemberGapAssessmentProgramYears(@PathVariable("provider-group-id") String providerGroupId, @RequestParam String state, @RequestParam String type) {
        return stargateStandardResponseUtilV2.generateStargateStandardResponse(providerGroupOpportunitiesService.getMemberGapAssessmentProgramYears(providerGroupId,state, type),TypeEnum.FLUX, new MemberGapAssessmentFluxResponse()).cast(MemberGapAssessmentFluxResponse.class);
    }

    @GetMapping("/{provider-group-id}/opportunities/gaps-lobs")
    @ApiResponse(responseCode = "200", description = "Success Request", content = @Content(schema = @Schema(implementation = MemberGapAssessmentFluxResponse.class), mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<MemberGapAssessmentFluxResponse> getMemberGapAssessmentLobs(@PathVariable("provider-group-id") String providerGroupId, @RequestParam String state, @RequestParam String type ,@RequestParam("program-year") int programYear, @RequestHeader("x-userDetails") String userDetailsJson,@RequestHeader("x-providerOnshore") String providerOnshoreFlag) {
        UserInfo userInfo = (UserInfo) ProgramPerformanceUtil.jsonToPojo(userDetailsJson, UserInfo.class);
        boolean offshoreRestricted = userInfo.isOffshore();
        return stargateStandardResponseUtilV2.generateStargateStandardResponse(providerGroupOpportunitiesService.getMemberGapAssessmentLobs(providerGroupId,state, type, offshoreRestricted,programYear),TypeEnum.FLUX, new MemberGapAssessmentFluxResponse()).cast(MemberGapAssessmentFluxResponse.class);
    }

    @GetMapping("/{provider-group-id}/opportunities/gaps-clients")
    @ApiResponse(responseCode = "200", description = "Success Request", content = @Content(schema = @Schema(implementation = MemberGapAssessmentFluxResponse.class), mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<MemberGapAssessmentFluxResponse> getMemberGapAssessmentClients(@PathVariable("provider-group-id") String providerGroupId, @RequestParam String state, @RequestParam String type,@RequestParam("program-year") int programYear) {
        return stargateStandardResponseUtilV2.generateStargateStandardResponse(providerGroupOpportunitiesService.getMemberGapAssessmentClients(providerGroupId,state, type,programYear),TypeEnum.FLUX, new MemberGapAssessmentFluxResponse()).cast(MemberGapAssessmentFluxResponse.class);
    }

    @GetMapping("/{provider-group-id}/opportunities/gaps-opportunity-sub-types")
    @ApiResponse(responseCode = "200", description = "Success Request", content = @Content(schema = @Schema(implementation = MemberGapAssessmentFluxResponse.class), mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<MemberGapAssessmentFluxResponse> getMemberGapAssessmentOpportunitySubTypes(@PathVariable("provider-group-id") String providerGroupId, @RequestParam String state, @RequestParam String type,@RequestParam("program-year") int programYear) {
        return stargateStandardResponseUtilV2.generateStargateStandardResponse(providerGroupOpportunitiesService.getMemberGapAssessmentOpportunitySubTypes(providerGroupId,state, type,programYear),TypeEnum.FLUX, new MemberGapAssessmentFluxResponse()).cast(MemberGapAssessmentFluxResponse.class);
    }
   /**
    * @deprecated (New APIs added in ExportsController class)
    */
    @Deprecated
    @ApiResponse(responseCode = "200", description = "Success Request", content = @Content(mediaType = MediaType.APPLICATION_OCTET_STREAM_VALUE,schema = @Schema(implementation = InputStream.class)))
    @GetMapping(value = "/{provider-group-id}/opportunities/{opportunity-type}/export-assessments", produces = "application/octet-stream")
    public Mono<InputStreamResource> getMemberAssessmentsReport(@PathVariable("provider-group-id") String providerGroupId, @PathVariable("opportunity-type") String opportunityType, MemberAssessment memberassessment, ServerHttpResponse response, @RequestHeader("x-userDetails") String userDetailsJson,@RequestHeader("x-providerOnshore") String providerOnshoreFlag) {
      if (!opportunityType.matches(REG_EXP_ALPHA_NUMERIC)) {
            return Mono.error(new ProgramPerformanceException(HttpStatus.OK, APIErrorCode.INVALID_OPPORTUNITY_TYPE_NAME));
        }
        UserInfo userInfo = (UserInfo) ProgramPerformanceUtil.jsonToPojo (userDetailsJson, UserInfo.class);
        /* always practice that do null check before values set in response object */
        try {
            if (null != response ) {
                String fileName = URLEncoder.encode(memberassessment.getOpportunityType(),StandardCharsets.UTF_8.displayName());
                response.getHeaders().set(HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename="+ fileName + ".xlsx");
            }
        }catch (Exception e){
            log.error("Error while response headers parsing to perform export",e);
        }
        boolean offshoreRestricted = userInfo.isOffshore();
        return "Outliers".equalsIgnoreCase(opportunityType) ? providerGroupOpportunitiesService.getMembersGapAssessmentReport (memberassessment,userInfo,offshoreRestricted) : providerGroupOpportunitiesService.getMembersAssessmentReport(memberassessment, userInfo, offshoreRestricted);

    }

    @PostMapping("/opportunities/risk-quality-opportunities/details")
    @ApiResponse(responseCode = "200", description = "Success Request", content = @Content(schema = @Schema(implementation = OpportunitiesDetailsResponse.class), mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<OpportunitiesDetailsResponse> getRiskQualityOpportunitiesDetails(@RequestBody DetailsRequestBody detailsRequestBody) {
        log.info("Getting Risk and Quality Opportunities Details");
        return stargateStandardResponseUtilV2.generateStargateStandardResponse(providerGroupOpportunitiesService.getRiskQualityOpportunitiesDetails(detailsRequestBody), TypeEnum.MONO, new OpportunitiesDetailsResponse()).cast(OpportunitiesDetailsResponse.class);
    }

    @PostMapping("/opportunities/risk-quality-opportunities/client-lob/details")
    @ApiResponse(responseCode = "200", description = "Success Request", content = @Content(schema = @Schema(implementation = ClientDetailsFluxResponse.class), mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<ClientDetailsFluxResponse> getRiskQualityOpportunitiesClients(@RequestBody ClientsRequestBody clientsRequestBody) {
        log.info("Getting Risk and Quality Opportunities client Details");
        return stargateStandardResponseUtilV2.generateStargateStandardResponse(providerGroupOpportunitiesService.getRiskQualityOpportunitiesClientLobDetails(clientsRequestBody), TypeEnum.MONO, new ClientDetailsFluxResponse()).cast(ClientDetailsFluxResponse.class);
    }

    @PostMapping("/opportunities/risk-quality-opportunities/qfo-healthsystem-details")
    @ApiResponse(responseCode = "200", description = "Success Request", content = @Content(schema = @Schema(implementation = QFOHealthSystemOpportunitiesDetailsResponse.class), mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<QFOHealthSystemOpportunitiesDetailsResponse> getQFOHealthSystemRiskQualityOpportunitiesDetails(@RequestBody QFOHealthSystemDetailsRequestBody qfoHealthSystemDetailsRequestBody) {
        log.info("Getting QFO Health System Risk and Quality Opportunities Details");
        return stargateStandardResponseUtilV2.generateStargateStandardResponse(providerGroupOpportunitiesService.getQFOHealthSystemRiskQualityOpportunitiesDetails(qfoHealthSystemDetailsRequestBody), TypeEnum.MONO, new QFOHealthSystemOpportunitiesDetailsResponse()).cast(QFOHealthSystemOpportunitiesDetailsResponse.class);
    }

    @GetMapping("/opportunities/risk-quality-opportunities/pa-filter-details")
    @ApiResponse(responseCode = "200", description = "Success Request", content = @Content(schema = @Schema(implementation = PAFilterResponse.class), mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<PAFilterResponse> getOFCPAMasterConfigurationValues() {
        log.info("Getting PA config values");
        return stargateStandardResponseUtilV2.generateStargateStandardResponse(providerGroupOpportunitiesService.getOFCPAMasterConfigurationValues(), TypeEnum.MONO, new PAFilterResponse()).cast(PAFilterResponse.class);
    }

}
