package com.optum.rqns.ftm.model.opportunities.providergrp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ProviderGroupMemberAssessments {

    private String memberName;
    private String memberId;
    private String chartId;
    private String secondarySubmission;
    private String client;
    private String providerName;
    private String gaMet;
    private String dvMet;
    private String cGapMet;
    private String opportunityReason;
    private LocalDate memberDob;
    private LocalDate deployDate;
    private LocalDate returnDate;
    private String lobName;
    private String eligibleProgramType;
    private String cpg;

}
