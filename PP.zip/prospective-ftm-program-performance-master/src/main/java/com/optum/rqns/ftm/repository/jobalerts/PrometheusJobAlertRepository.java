package com.optum.rqns.ftm.repository.jobalerts;

import com.optum.rqns.ftm.dto.jobalerts.JobAlert;

import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;
@Repository
public interface PrometheusJobAlertRepository {


    Mono<JobAlert> getJobAlertByName(String jobName);
}
