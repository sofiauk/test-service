package com.optum.rqns.ftm.repository.fieldleader;

import java.util.List;

public class LeaderGrowthRatePOCEModalityQueryBuilder {

    private static final LeaderGrowthRatePOCEModalityQueryBuilder INSTANCE =
            new LeaderGrowthRatePOCEModalityQueryBuilder();

    private LeaderGrowthRatePOCEModalityQueryBuilder() {}

    public static LeaderGrowthRatePOCEModalityQueryBuilder.Builder builder() { return INSTANCE.new Builder(); }

    public class Builder {

        private static final String AND = " AND ";
        private static final String FROM_SUFFIX = ") t ) u ";
        private static final String SERVICE_LEVEL= "ServiceLevel";

        private static final String FIELD_IN =
                " %s IN (%s) ";

        private static final String STANDARD_SELECT_OUTER =
                "u.PrevMonthConversionRateNew, " +
                "u.CurrentMonthConversionRateNew, " +
                "(CASE WHEN u.CurrentMonthConversionRateNew IS NOT NULL AND u.PrevMonthConversionRateNew IS NOT NULL THEN u.CurrentMonthConversionRateNew - u.PrevMonthConversionRateNew ELSE NULL END) AS MonthOverMonthChangeNew, " +
                "u.PrevMonthConversionRateExisting, " +
                "u.CurrentMonthConversionRateExisting, " +
                "(CASE WHEN u.CurrentMonthConversionRateExisting IS NOT NULL AND u.PrevMonthConversionRateExisting IS NOT NULL THEN u.CurrentMonthConversionRateExisting - u.PrevMonthConversionRateExisting ELSE NULL END) AS MonthOverMonthChangeExisting, " +
                "u.UpdatedDate ";

        private static final String STANDARD_SELECT_INNER =
                "FROM ( SELECT " +
                " %s t.UpdatedDate, " +
                "(CASE WHEN POCNewTotalGroupsPrevious > 0 AND POCNewGroupsPrevious IS NOT NULL THEN CONVERT(FLOAT,POCNewGroupsPrevious) / CONVERT(FLOAT,POCNewTotalGroupsPrevious) * 100 ELSE NULL END) AS PrevMonthConversionRateNew, " +
                "(CASE WHEN POCNewTotalGroupsCurrent > 0 AND POCNewGroupsCurrent IS NOT NULL THEN CONVERT(FLOAT,POCNewGroupsCurrent) / CONVERT(FLOAT,POCNewTotalGroupsCurrent) * 100 ELSE NULL END) AS CurrentMonthConversionRateNew, " +
                "(CASE WHEN POCExistingTotalGroupsPrevious > 0 AND POCExistingGroupsPrevious IS NOT NULL THEN CONVERT(FLOAT,POCExistingGroupsPrevious) / CONVERT(FLOAT,POCExistingTotalGroupsPrevious) * 100 ELSE NULL END) AS PrevMonthConversionRateExisting, " +
                "(CASE WHEN POCExistingTotalGroupsCurrent > 0 AND POCExistingGroupsCurrent IS NOT NULL THEN CONVERT(FLOAT,POCExistingGroupsCurrent) / CONVERT(FLOAT,POCExistingTotalGroupsCurrent) * 100 ELSE NULL END) AS CurrentMonthConversionRateExisting ";

        private static final String STANDARD_SELECT_AGGREGATE =
                "FROM ( SELECT " +
                " %s MAX(lgrp.updatedDate) AS UpdatedDate, " +
                "SUM(CASE WHEN [Month] = :PreviousMonth THEN POCNewGroups ELSE NULL END) AS POCNewGroupsPrevious, " +
                "SUM(CASE WHEN [Month] = :PreviousMonth THEN POCNewTotalGroups ELSE NULL END) AS POCNewTotalGroupsPrevious, " +
                "SUM(CASE WHEN [Month] = :PreviousMonth THEN POCExistingGroups ELSE NULL END) AS POCExistingGroupsPrevious, " +
                "SUM(CASE WHEN [Month] = :PreviousMonth THEN POCExistingTotalGroups ELSE NULL END) AS POCExistingTotalGroupsPrevious, " +
                "SUM(CASE WHEN [Month] = :CurrentMonth THEN POCNewGroups ELSE NULL END) AS POCNewGroupsCurrent, " +
                "SUM(CASE WHEN [Month] = :CurrentMonth THEN POCNewTotalGroups ELSE NULL END) AS POCNewTotalGroupsCurrent, " +
                "SUM(CASE WHEN [Month] = :CurrentMonth THEN POCExistingGroups ELSE NULL END) AS POCExistingGroupsCurrent, " +
                "SUM(CASE WHEN [Month] = :CurrentMonth THEN POCExistingTotalGroups ELSE NULL END) AS POCExistingTotalGroupsCurrent ";

        private static final String STANDARD_FROM =
                "FROM ProgPerf.LeaderGrowthRatePOCEModality lgrp " +
                "WHERE IsActive = 1 " +
                "AND ProgramYear = :ProgramYear " +
                "AND (( :CurrentMonth = 'Feb' AND [Month] = 'Feb' ) OR ( :CurrentMonth <> 'Feb' AND [Month] IN ( :PreviousMonth , :CurrentMonth))) ";

        private static final String WITH_MY_TEAM =
                "WITH MyTeam (UUID, PersonnelHierarchyId, ParentId, Depth, DeletedDate) AS " +
                "( " +
                "   SELECT " +
                "       UUID, " +
                "       PersonnelHierarchyId, " +
                "       ParentId, " +
                "       0 AS Depth, " +
                "       DeletedDate " +
                "   FROM ProgPerf.PersonnelHierarchy " +
                "   WHERE UUID = :UUID " +
                "   UNION ALL " +
                "   SELECT " +
                "       ph.UUID, " +
                "       ph.PersonnelHierarchyId, " +
                "       ph.ParentId, " +
                "       (mt.Depth + 1) AS Depth, " +
                "       ph.DeletedDate " +
                "   FROM ProgPerf.PersonnelHierarchy ph " +
                "   INNER JOIN MyTeam mt " +
                "   ON ph.ParentId = mt.PersonnelHierarchyId " +
                "   AND mt.Depth < 2 " +
                "   AND ph.DeletedDate IS NULL " +
                ") ";

        private static final String SELECT_NATIONAL =
                "SELECT 0 AS FixedOrder, " +
                "'National' AS RegionMarket, " +
                STANDARD_SELECT_OUTER;

        private static final String SELECT_LOGGED_IN =
                "SELECT 1 AS FixedOrder, " +
                "( " +
                "   SELECT CONCAT(FirstName, ' ', LastName) " +
                "   FROM ProgPerf.Users us " +
                "   WHERE us.UUID = :UUID" +
                ") AS RegionMarket, " +
                STANDARD_SELECT_OUTER;

        private static final String SELECT_REGION =
                "SELECT 2 AS FixedOrder, " +
                "Region AS RegionMarket, " +
                STANDARD_SELECT_OUTER;

        private static final String SELECT_STATE =
                "SELECT u.State AS RegionMarket, " +
                STANDARD_SELECT_OUTER;

        private static final String SELECT_MY_TEAM =
                "SELECT u.FirstName AS FirstName, " +
                "u.LastName AS LastName, " +
                "u.UUID AS UUID, " +
                "u.ParentUUID AS ParentUUID, " +
                "Role as Role, " +
                STANDARD_SELECT_OUTER;

        private static final String FROM_NATIONAL =
                STANDARD_FROM +
                "AND UUID = 'National' AND Region = 'All' AND State = 'All' %s" +
                FROM_SUFFIX;

        private static final String FROM_LOGGED_IN =
                STANDARD_FROM +
                "AND UUID = :UUID %s " +
                FROM_SUFFIX;

        private static final String FROM_REGION =
                STANDARD_FROM +
                "AND UUID = 'National' AND Region <> 'All' AND Region IS NOT NULL AND State <> 'All' " +
                "%s " +
                "GROUP BY Region " +
                FROM_SUFFIX;

        private static final String FROM_STATE =
                STANDARD_FROM +
                "AND UUID = 'National' AND Region IN ( :Region ) AND State <> 'All' AND State IS NOT NULL " +
                "%s " +
                "GROUP BY Region, State " +
                FROM_SUFFIX;

        private static final String FROM_MY_TEAM =
                "FROM MyTeam mt " +
                "INNER JOIN ProgPerf.Users u " +
                "ON mt.UUID = u.UUID " +
                "LEFT JOIN ( " +
                "   SELECT * " +
                "   FROM ProgPerf.LeaderGrowthRatePOCEModality " +
                "   WHERE IsActive = 1 " +
                "   %s " +
                "   AND ProgramYear = :ProgramYear " +
                "   AND (( :CurrentMonth = 'Feb' AND [Month] = 'Feb' ) OR ( :CurrentMonth <> 'Feb' AND [Month] IN ( :PreviousMonth , :CurrentMonth))) " +
                ") lgrp " +
                "ON mt.UUID = lgrp.UUID " +
                "GROUP BY " +
                "mt.UUID, " +
                "FirstName, " +
                "LastName, " +
                "u.[Role] " +
                FROM_SUFFIX;

        private static final String MY_TEAM_INNER = "t.UUID, t.FirstName, t.LastName, t.ParentUUID, t.Role, ";
        private static final String MY_TEAM_AGGREGATE =
                "mt.UUID, " +
			    "(" +
                "   SELECT UUID " +
                "   FROM ProgPerf.PersonnelHierarchy " +
                "   WHERE PersonnelHierarchyId = MAX(mt.ParentId)" +
                ") AS ParentUUID, " +
                "FirstName, " +
                "LastName, " +
                "JSON_VALUE(u.[Role],'$[0].name') AS Role, ";

        private boolean isLeaderPOCConversion = false;
        private boolean isLeaderPOCConversionRegion = false;
        private boolean isLeaderPOCConversionTeam = false;
        private String filterConditions = "";

        Builder asLeaderPOCConversion(List<String> appliedFilters) {
            filterConditions = setFilterConditions(filterConditions, appliedFilters);
            this.isLeaderPOCConversion = true;
            return this;
        }

        Builder asLeaderPOCConversionRegion(List<String> appliedFilters) {
            filterConditions = setFilterConditions(filterConditions, appliedFilters);
            this.isLeaderPOCConversionRegion = true;
            return this;
        }

        Builder asLeaderPOCConversionTeam(List<String> appliedFilters) {
            filterConditions = setFilterConditions(filterConditions, appliedFilters);
            this.isLeaderPOCConversionTeam = true;
            return this;
        }

        public String build() {
            StringBuilder sb = new StringBuilder();
            String serviceLevel = filterConditions == null || filterConditions.equals("") ? "" : AND + String.format(FIELD_IN, SERVICE_LEVEL, filterConditions);

            if (isLeaderPOCConversion) {
                sb.append("SELECT * FROM ( ")
                        .append(SELECT_NATIONAL)
                        .append(String.format(STANDARD_SELECT_INNER,""))
                        .append(String.format(STANDARD_SELECT_AGGREGATE,""))
                        .append(String.format(FROM_NATIONAL, serviceLevel))
                        .append("UNION ")
                        .append(SELECT_LOGGED_IN)
                        .append(String.format(STANDARD_SELECT_INNER,""))
                        .append(String.format(STANDARD_SELECT_AGGREGATE,""))
                        .append(String.format(FROM_LOGGED_IN, serviceLevel))
                        .append("UNION ")
                        .append(SELECT_REGION)
                        .append(String.format(STANDARD_SELECT_INNER,"t.Region, "))
                        .append(String.format(STANDARD_SELECT_AGGREGATE,"Region, "))
                        .append(String.format(FROM_REGION, serviceLevel))
                        .append(") v ORDER BY FixedOrder, RegionMarket");
            } else if (isLeaderPOCConversionRegion) {
                sb.append(SELECT_STATE)
                        .append(String.format(STANDARD_SELECT_INNER,"t.State, "))
                        .append(String.format(STANDARD_SELECT_AGGREGATE,"Region, State, "))
                        .append(String.format(FROM_STATE, serviceLevel));
            } else if (isLeaderPOCConversionTeam) {
                sb.append(WITH_MY_TEAM)
                        .append(SELECT_MY_TEAM)
                        .append(String.format(STANDARD_SELECT_INNER,MY_TEAM_INNER))
                        .append(String.format(STANDARD_SELECT_AGGREGATE,MY_TEAM_AGGREGATE))
                        .append(String.format(FROM_MY_TEAM, serviceLevel));
            } else {
                sb.setLength(0);
            }
            return sb.toString();
        }

        private String setFilterConditions(String filterCondion, List<String> appliedFilters) {
            if (appliedFilters != null && !appliedFilters.isEmpty()) {
                filterCondion += "'" + appliedFilters.get(0) + "'";
                for (int i = 1; i < appliedFilters.size(); i++) {
                    filterCondion += ",'" + appliedFilters.get(i) + "'";
                }

            }

            return filterCondion.replace("[", "").replace("]", "");
        }
    }
}
