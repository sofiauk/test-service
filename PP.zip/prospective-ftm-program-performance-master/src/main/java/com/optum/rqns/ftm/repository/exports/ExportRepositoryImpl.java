package com.optum.rqns.ftm.repository.exports;

import com.google.gson.Gson;
import com.optum.rqns.ftm.constants.ProviderGroupConstants;
import com.optum.rqns.ftm.dto.opportunities.providergrp.exports.ExportRequestParamsDTO;
import com.optum.rqns.ftm.enums.DocumentType;
import com.optum.rqns.ftm.enums.ExportStatus;
import com.optum.rqns.ftm.enums.ProcessSubType;
import com.optum.rqns.ftm.enums.ProcessType;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.exception.APIErrorCode;
import com.optum.rqns.ftm.exception.ProgramPerformanceException;
import com.optum.rqns.ftm.model.UserInfo;
import com.optum.rqns.ftm.model.export.ExportDetail;
import com.optum.rqns.ftm.model.export.ExportNotification;
import com.optum.rqns.ftm.model.export.ExportTransaction;
import com.optum.rqns.ftm.model.opportunities.providergrp.MemberAssessment;
import com.optum.rqns.ftm.request.exports.ExportsRequestPayload;
import com.optum.rqns.ftm.request.exports.ExportsRequestPayloadInputs;
import com.optum.rqns.ftm.util.ProgramPerformanceUtil;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.r2dbc.core.DatabaseClient;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Year;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

@Repository
@Slf4j
public class ExportRepositoryImpl implements ExportRepository {


    private static final List<String> notificationStatusList = Collections.unmodifiableList(
            Arrays.asList("Success", "Failed")
    );
    private static final String NOTIFICATION_STATUS = "notificationStatus";
    private static final String PROCESS_TYPE_CRITERIA = " and er.ProcessName='%s' ";
    private static final String PROCESS_SUB_TYPE_CRITERIA = " and er.ProcessSubType='%s' ";
    private static final String DOCUMENT_TYPE_CRITERIA = " and er.DocumentType='%s' ";
    private static final String NOT_NOTIFIED_CRITERIA = " and IsNotified = 0 and IsCancelled = 0 ";
    private static final String UNREAD_CRITERIA = " and IsRead = 0";

    private static final String USER_EXPORTED_FILES = "" +
            " select er.OptumUUID, er.Id as TransactionId, er.FileName,er.ProcessName as ProcessType," +
            " er.ProcessSubType, er.DocumentType, er.CreatedDate as ExportedDate" +
            " , er.FileSize, er.Status as ExportStatus, er.IsRead, er.IsCancelled" +
            " from ProgPerf.ExportsRequest er" +
            " where er.OptumUUID=:OptumUUID and IsActive = 1 and IsDeleted = 0 %s " +
            " order by CreatedDate desc";

    private static final String UPDATE_EXPORT_FILE_STATUS = "update ProgPerf.ExportsRequest set %s " +
            "where OptumUUID = :OptumUUID and id = :TransactionId and IsActive=1";

    private static final String UPDATE_EXPORT_FILE_IS_READ_STATUS = "update ProgPerf.ExportsRequest set IsRead = 1 " +
            "where OptumUUID = :OptumUUID and IsActive=1 and ProcessName = :ProcessType and ProcessSubType = :ProcessSubType";

    private static final String USER_NOTIFICATIONS = "" +
            "select er.OptumUUID, er.Id as TransactionId, er.ProcessName as ProcessType, er.ProcessSubType ," +
            " er.FileName, er.DocumentType , er.Status as ExportStatus,er.IsNotified ,er.IsActive " +
            " from ProgPerf.ExportsRequest er" +
            " where er.OptumUUID=:OptumUUID " +
            "  and er.IsActive = 1 and er.IsDeleted = 0" +
            "  and er.Status in(:notificationStatus) " +
            "  %s ";

    private static final String DELETE_EXPORTED_FILE = "update ProgPerf.ExportsRequest set IsActive=0 " +
            "where OptumUUID = :OptumUUID and id = :TransactionId and IsActive=1";


    private static final String INSERT_EXPORTS_REQUEST = "INSERT INTO ProgPerf.ExportsRequest " +
            "(ProcessName, ExportType, ProcessSubType, SubmittedBy, TraceId, RequestPayload, " +
            "RecordsCount, ProgramYear, Status, IsRead, IsDeleted, IsCancelled, IsNotified, " +
            "FileName, FileSize, DocumentType, IsActive, TimeTakenInMS, CreatedBy, CreatedDate, " +
            "UpdatedBy, UpdatedDate, OptumUUID, MessageId) " +
            "VALUES(:ProcessName, :ExportType, :ProcessSubType, :SubmittedBy, :TraceId, :RequestPayload, " +
            "null, :ProgramYear, :Status, 0, 0, 0, 0, " +
            "'', null, :DocumentType, 1, null, :CreatedBy,getUTCDate(), " +
            ":UpdatedBy, getUTCDate(), :OptumUUID, null) ";


    private static final String FETCH_TRANSCATION_ID = "select OptumUUID ,id as TransactionId, FileName ,ProcessName as ProcessType," +
            "ProcessSubType ,DocumentType , CreatedDate as ExportedDate,FileSize , " +
            "Status as ExportStatus ,IsRead ,IsCancelled  from ProgPerf.ExportsRequest " +
            "where OptumUUID =:OptumUUID  " +
            "and TraceId =:TraceId  ";

    private static final String GET_TRANSACTION_ID_BY_UUID_FILE_NAME = "SELECT er.Id  FROM ProgPerf.ExportsRequest er " +
            "WHERE er.OptumUUID=:OptumUUID " +
            "AND er.FileName=:FileName " +
            "AND er.IsActive=1";

    private static final String UPDATE_EXPORT_REQUEST_DATA = "UPDATE  ProgPerf.ExportsRequest SET " +
            " TraceId = :TraceId, " +
            " Status = :Status, " +
            " FileSize = :FileSize, " +
            " TimeTakenInMS = :TIME_TAKEN, " +
            " UpdatedBy = :UpdatedBy, " +
            " UpdatedDate = GETUTCDATE(), " +
            " MessageId = :MESSAGE_ID, " +
            " RecordsCount = :RECORDS_COUNT, " +
            " FileName = :FileName" +
            " WHERE Id = :ID";

    private final DatabaseClient databaseClient;

    @Getter
    @AllArgsConstructor
    public enum Columns {
        OPTUM_UUID("OptumUUID"), TRANSACTION_ID("TransactionId"),
        FILE_NAME("FileName"), DOCUMENT_TYPE("DocumentType"),
        PROCESS_TYPE("ProcessType"), PROCESS_SUB_TYPE("ProcessSubType"),
        EXPORT_STATUS("ExportStatus"), EXPORT_TYPE("ExportType"),
        EXPORTED_DATE("ExportedDate"), FILE_SIZE("FileSize"),
        IS_CANCELLED("IsCancelled"), IS_READ("IsRead"),
        IS_NOTIFIED("IsNotified"), IS_ACTIVE("IsActive"),
        PROCESS_NAME("ProcessName"), SUBMITTED_BY("SubmittedBy"),
        TRACE_ID("TraceId"), REQUEST_PAYLOAD("RequestPayload"),
        PROGRAM_YEAR("ProgramYear"), STATUS("Status"),
        CREATED_BY("CreatedBy"), UPDATED_BY("UpdatedBy"),
        ID("ID"), TIME_TAKEN("TIME_TAKEN"),
        UPDATED_DATE("UPDATED_DATE"), MESSAGE_ID("MESSAGE_ID"),
        RECORDS_COUNT("RECORDS_COUNT");

        String value;
    }

    @Autowired
    public ExportRepositoryImpl(DatabaseClient databaseClient) {
        this.databaseClient = databaseClient;
    }

    @Override
    public Flux<ExportDetail> getExports(String traceId, String uuid, ProcessType processType, ProcessSubType processSubType, DocumentType documentType) {
        StringBuilder criteria = new StringBuilder();
        if (Objects.nonNull(processType)) {
            criteria.append(String.format(PROCESS_TYPE_CRITERIA, processType.getValue()));
        }
        if (Objects.nonNull(processSubType)) {
            criteria.append(String.format(PROCESS_SUB_TYPE_CRITERIA, processSubType.getValue()));
        }
        if (Objects.nonNull(documentType)) {
            criteria.append(String.format(DOCUMENT_TYPE_CRITERIA, documentType.getValue()));
        }
        String query = String.format(USER_EXPORTED_FILES, criteria.toString());
        log.info("TraceId :: {} query:{}", traceId, query);
        log.info("TraceId :: {} queryParams:{}", traceId, uuid);
        return databaseClient.execute(query)
                .bind(Columns.OPTUM_UUID.getValue(), uuid)
                .as(ExportDetail.class)
                .fetch()
                .all();
    }

    @Override
    public Mono<ExportTransaction> setExportStatus(String uuid, String traceId, long transactionId, ExportStatus exportStatus) {
        String query = null;
        if (ExportStatus.NOTIFIED.getValue().equals(exportStatus.getValue())) {
            query = String.format(UPDATE_EXPORT_FILE_STATUS, " IsNotified =1 ");
        } else if (ExportStatus.CANCELLED.getValue().equals(exportStatus.getValue())) {
            query = String.format(UPDATE_EXPORT_FILE_STATUS, " IsCancelled=1 ");
        } else {
            log.error("TraceId :: {} Invalid Export Status UUID :: {} TransactionId :: {} ExportStatus :: {}", traceId, uuid, transactionId, exportStatus);
            return Mono.error(new ProgramPerformanceException(HttpStatus.OK, APIErrorCode.INVALID_STATUS_TO_UPDATE));
        }

        log.info("TraceId :: {}  Query is {} Query Param {} {}", traceId, query, uuid, transactionId);

        return databaseClient.execute(query)
                .bind(Columns.OPTUM_UUID.getValue(), uuid)
                .bind(Columns.TRANSACTION_ID.getValue(), transactionId)
                .fetch()
                .rowsUpdated()
                .filter(updateCount -> updateCount > 0)
                .map(updateCount -> ExportTransaction.builder()
                        .uuid(uuid)
                        .transactionId(transactionId)
                        .exportStatus(exportStatus)
                        .build());
    }

    @Override
    public Flux<ExportNotification> getExportNotifications(String uuid, String traceId, ExportStatus exportStatus) {
        log.info("TraceId :: {} export Users Notifications Query is  {}", traceId, USER_NOTIFICATIONS);
        log.info("TraceId :: {} export Users Notifications Query parameters {}, {}, exportStatus", traceId, uuid, notificationStatusList);

        String query;

        if (ExportStatus.NON_NOTIFIED == exportStatus) {
            query = String.format(USER_NOTIFICATIONS, NOT_NOTIFIED_CRITERIA);
        } else if (ExportStatus.UNREAD == exportStatus) {
            query = String.format(USER_NOTIFICATIONS, UNREAD_CRITERIA);
        } else {
            query = String.format(USER_NOTIFICATIONS, "");
        }

        return databaseClient.execute(query)
                .bind(Columns.OPTUM_UUID.getValue(), uuid)
                .bind(NOTIFICATION_STATUS, notificationStatusList)
                .as(ExportNotification.class)
                .fetch()
                .all();
    }

    @Override
    public Mono<ExportTransaction> deleteExportedFile(String traceId, String uuid, long transactionId) {
        log.info("TraceId :: {} delete exported File Query is  {}", traceId, DELETE_EXPORTED_FILE);
        log.info("TraceId :: {} delete exported File Query parameters uuid:{}, transactionId:{}", traceId, uuid, transactionId);
        return databaseClient.execute(DELETE_EXPORTED_FILE)
                .bind(Columns.OPTUM_UUID.getValue(), uuid)
                .bind(Columns.TRANSACTION_ID.getValue(), transactionId)
                .fetch()
                .rowsUpdated()
                .filter(updateCount -> updateCount > 0)
                .map(updateCount -> ExportTransaction.builder()
                        .uuid(uuid)
                        .transactionId(transactionId)
                        .exportStatus(ExportStatus.DELETED)
                        .build());
    }

    @Override
    public Mono<ExportTransaction> updateExportIsReadStatus(String uuid, String traceId, ProcessType processType, ProcessSubType processSubType, ExportStatus exportStatus) {

        log.info("TraceId :: {}  Query is {} Query Params {} {} {}", traceId, UPDATE_EXPORT_FILE_IS_READ_STATUS, uuid, processType, processSubType);

        return databaseClient.execute(UPDATE_EXPORT_FILE_IS_READ_STATUS)
                .bind(Columns.OPTUM_UUID.getValue(), uuid)
                .bind(Columns.PROCESS_TYPE.getValue(), processType.getValue())
                .bind(Columns.PROCESS_SUB_TYPE.getValue(), processSubType.getValue())
                .fetch()
                .rowsUpdated()
                .filter(updateCount -> updateCount > 0)
                .map(updateCount -> ExportTransaction.builder()
                        .uuid(uuid)
                        .exportStatus(ExportStatus.SUCCESS)
                        .build());
    }

    @Override
    public Mono<ExportDetail> insertExportstRequest(ExportsRequestPayload exportsRequestPayload, MemberAssessment exportInput, UserInfo userInfo, String processName, String requestId) {
        log.info("insertUserExportsToExportRequest UserExportsPayLoad {}, userInfo {} ", exportsRequestPayload, userInfo);
        if (ProcessType.MEMBER_ASSESSMENT.getValue().equalsIgnoreCase(exportsRequestPayload.getProcessType()) ||
                ProcessType.OUTLIERS.getValue().equalsIgnoreCase(exportsRequestPayload.getProcessType())) {
            ExportsRequestPayloadInputs exportinputs = new ExportsRequestPayloadInputs(requestId, exportsRequestPayload, userInfo, userInfo.isOffshore());
            String serializedInput = new Gson().toJson(exportinputs);
            return databaseClient
                    .execute(INSERT_EXPORTS_REQUEST)
                    .bind(Columns.PROCESS_NAME.getValue(), processName)
                    .bind(Columns.EXPORT_TYPE.getValue(), ProviderGroupConstants.ALL)
                    .bind(Columns.PROCESS_SUB_TYPE.getValue(), exportInput.getOpportunityType())
                    .bind(Columns.SUBMITTED_BY.getValue(), "Manual")
                    .bind(Columns.TRACE_ID.getValue(), exportsRequestPayload.getTraceId())
                    .bind(Columns.REQUEST_PAYLOAD.getValue(), serializedInput)
                    .bind(Columns.PROGRAM_YEAR.getValue(), exportInput.getProgramYear() > 0 ? exportInput.getProgramYear() : Year.now().getValue())
                    .bind(Columns.STATUS.getValue(), Status.IN_PROGRESS.getValue())
                    .bind(Columns.DOCUMENT_TYPE.getValue(), DocumentType.EXCEL.getValue())
                    .bind(Columns.CREATED_BY.getValue(), userInfo.getFirstName() + " " + userInfo.getLastName())
                    .bind(Columns.UPDATED_BY.getValue(), userInfo.getFirstName() + " " + userInfo.getLastName())
                    .bind(Columns.OPTUM_UUID.getValue(), userInfo.getUuid())
                    .fetch()
                    .rowsUpdated()
                    .flatMap(count -> {
                        return databaseClient
                                .execute(FETCH_TRANSCATION_ID)
                                .bind(Columns.TRACE_ID.getValue(), exportsRequestPayload.getTraceId())
                                .bind(Columns.OPTUM_UUID.getValue(), userInfo.getUuid())
                                .as(ExportDetail.class)
                                .fetch()
                                .one();
                    });
        } else {
            return Mono.error(new ProgramPerformanceException(HttpStatus.EXPECTATION_FAILED, APIErrorCode.INVALID_PROCESS_TYPE));
        }

    }

    public Mono<Integer> getTransactionIdByUUIDAndFileName(String fileName, String uuid) {
        return databaseClient.execute(GET_TRANSACTION_ID_BY_UUID_FILE_NAME)
                .bind(Columns.OPTUM_UUID.getValue(), uuid)
                .bind(Columns.FILE_NAME.getValue(), fileName)
                .as(Integer.class)
                .fetch()
                .one();
    }

    @Override
    public Mono<Integer> updateExportRequestTable(ExportRequestParamsDTO exportRequestParams, boolean isSuccess) {
        return databaseClient.execute(UPDATE_EXPORT_REQUEST_DATA)
                .bind(Columns.TRACE_ID.getValue(), exportRequestParams.getExportsRequestPayloadInputs().getExportParams().getTraceId())
                .bind(Columns.STATUS.getValue(), isSuccess ? ExportStatus.SUCCESS.getValue() : ExportStatus.FAILED.getValue())
                .bind(Columns.FILE_SIZE.getValue(), isSuccess ? exportRequestParams.getFileSize() : 0)
                .bind(Columns.TIME_TAKEN.getValue(), exportRequestParams.getTimeTakenToExport())
                .bind(Columns.UPDATED_BY.getValue(), exportRequestParams.getUserInfo().getEmailId())
                .bind(Columns.MESSAGE_ID.getValue(), ProgramPerformanceUtil.TransactionIdLogger.getMessageIdIdentifier())
                .bind(Columns.RECORDS_COUNT.getValue(), exportRequestParams.getTotalRecordsCount())
                .bind(Columns.FILE_NAME.getValue(), exportRequestParams.getFileName())
                .bind(Columns.ID.getValue(), exportRequestParams.getExportsRequestPayloadInputs().getExportParams().getTransactionId())
                .fetch().rowsUpdated();
    }

}
