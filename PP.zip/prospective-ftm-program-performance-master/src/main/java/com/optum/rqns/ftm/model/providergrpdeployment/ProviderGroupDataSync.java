package com.optum.rqns.ftm.model.providergrpdeployment;

import com.optum.rqns.ftm.dto.rules.ProviderGroupOpportunitiesSummaryDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class ProviderGroupDataSync {
    private String providerGroupID;
    private String providerGroupName;
    private String state;
    private int programYear;
    private ProviderGroupOpportunitiesSummaryDTO opportunity;
    private NewProviderGroupDetail newProviderGroup;
    private PerformanceDetail performance;
}
