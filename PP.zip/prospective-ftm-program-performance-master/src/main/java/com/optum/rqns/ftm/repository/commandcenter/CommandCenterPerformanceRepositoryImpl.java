package com.optum.rqns.ftm.repository.commandcenter;

import com.optum.rqns.ftm.constants.CommandCenterConstants;
import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.model.providergrpdeployment.DerivedDeployment;
import com.optum.rqns.ftm.model.providergrpdeployment.DerivedDeploymentWeekly;
import com.optum.rqns.ftm.model.providergrpdeployment.ReturnsNetCNA;
import com.optum.rqns.ftm.model.providergrpdeployment.ReturnsNetCNAWeekly;
import io.r2dbc.spi.Row;
import org.springframework.data.r2dbc.core.DatabaseClient;
import org.springframework.data.r2dbc.core.RowsFetchSpec;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public class CommandCenterPerformanceRepositoryImpl implements CommandCenterPerformanceRepository, DTOWrapperTypeConverter {

    private final DatabaseClient client;

    private static final String UPDATED_DATE_COLUMN = "UpdatedDate";
    private static final String DEPLOY_YTD_ACTUAL_COLUMN = "DeployYTDActual";
    private static final String DEPLOY_YTD_TARGET_COLUMN = "DeployYTDTarget";
    private static final String RETURN_NET_CNA_YTD_ACTUAL_COLUMN = "ReturnedNetCnaYtdActual";
    private static final String RETURN_YTD_TARGET_COLUMN = "ReturnYTDTarget";

    CommandCenterPerformanceRepositoryImpl(DatabaseClient client) {
        this.client = client;
    }

    public enum ColumnNames {

        PROGRAM_YEAR("ProgramYear"),
        NAME("Name"),
        OFFSET("Offset"),
        LIMIT("Limit"),
        REGION("Region"),
        STATE("State"),
        LOB_NAME("LobName"),
        CLIENT_NAME("ClientName"),
        PROVIDER_GROUP_ID("ProviderGroupId"),
        MONTH("Month"),
        DURATION_START_DATE("DurationStartDate"),
        DURATION_END_DATE("DurationEndDate");

        private String columnName;

        ColumnNames(String columnName) {
            this.columnName = columnName;
        }

        public String getColumnName() {
            return this.columnName;
        }
    }

    private static final String DEPLOYMENT_AND_RETURN_WEEKLY_PARTS_QUERY = "SELECT c1.ProgramYear, c1.[Month], c1.DurationStartDate, c1.DurationEndDate, c2.%s, c2.UpdatedDate " +
            "FROM ( " +
            "   SELECT " +
            "       DISTINCT ccp.ProgramYear, ccp.[Month], ccp.DurationStartDate, ccp.DurationEndDate " +
            "   FROM " +
            "       ProgPerf.CommandCenterPerformance ccp " +
            "   WHERE " +
            "       ProviderGroupID = :ProviderGroupId " +
            "       AND ProgramYear = :ProgramYear ) AS c1 " +
            "LEFT JOIN ( " +
            "   SELECT " +
            "       ccp2.DurationStartDate, SUM(ccp2.%s) AS %s, MAX(ccp2.UpdatedDate) AS UpdatedDate " +
            "   FROM " +
            "       ProgPerf.CommandCenterPerformance ccp2 " +
            "   WHERE " +
            "       ccp2.ProviderGroupId = :ProviderGroupId " +
            "       AND ccp2.ProgramYear = :ProgramYear " +
            "       %s" +
            "   GROUP BY " +
            "       ccp2.DurationStartDate ) AS c2 ON " +
            "   c1.DurationStartDate = c2.DurationStartDate " +
            "   WHERE c1.[Month] IS NOT NULL " +
            "   AND c1.DurationStartDate IS NOT NULL " +
            "   AND c1.DurationEndDate IS NOT NULL " +
            "GROUP BY c1.DurationStartDate, c1.ProgramYear, c1.[Month], c1.DurationEndDate, c2.%s, c2.UpdatedDate " +
            "ORDER BY  " +
            "c1.DurationStartDate";


    @Override
    public Flux<DerivedDeployment> getDerivedDeploymentCounts(int programYear, String byType, String name, int offset, int limit, boolean regionSummary) {
        CommandCenterPerformanceQueryBuilder.Builder b = CommandCenterPerformanceQueryBuilder.builder();
        b.asDerivedDeployment();
        if (byType.equals(ColumnNames.REGION.getColumnName())) {
            return getDerivedDeploymentCountsRegion(b,programYear,byType,name,offset,limit,regionSummary);
        } else {
            return getDerivedDeploymentCountsLobNameOrClientName(b,programYear,byType,name,offset,limit);
        }

    }

    private Flux<DerivedDeployment> getDerivedDeploymentCountsRegion(CommandCenterPerformanceQueryBuilder.Builder b, int programYear, String byType, String name, int offset, int limit, boolean regionSummary) {
        b.asByRegion();
        if (regionSummary) {
            b.asByRegionSummary();
            return client.execute(b.build())
                    .bind(ColumnNames.REGION.getColumnName(), name)
                    .bind(ColumnNames.PROGRAM_YEAR.getColumnName(), programYear)
                    .as(DerivedDeployment.class)
                    .map((row, rowMetadata) -> getDerivedDeploymentRow(row, name,null,true))
                    .all();
        } else {
            return client.execute(b.build())
                    .bind(ColumnNames.REGION.getColumnName(), name)
                    .bind(ColumnNames.PROGRAM_YEAR.getColumnName(), programYear)
                    .bind(ColumnNames.OFFSET.getColumnName(), offset)
                    .bind(ColumnNames.LIMIT.getColumnName(), limit)
                    .as(DerivedDeployment.class)
                    .map((row, rowMetadata) -> getDerivedDeploymentRow(row, name,byType,true))
                    .all();
        }
    }

    private Flux<DerivedDeployment> getDerivedDeploymentCountsLobNameOrClientName(CommandCenterPerformanceQueryBuilder.Builder b, int programYear, String byType, String name, int offset, int limit) {
        if (byType.equals(ColumnNames.CLIENT_NAME.getColumnName())) {
            b.asByClientName();
        } else {
            b.asByLobName();
        }
        if (name == null) {
            return client.execute(b.build())
                    .bind(ColumnNames.PROGRAM_YEAR.getColumnName(), programYear)
                    .bind(ColumnNames.OFFSET.getColumnName(), offset)
                    .bind(ColumnNames.LIMIT.getColumnName(), limit)
                    .as(DerivedDeployment.class)
                    .map((row, rowMetadata) -> getDerivedDeploymentRow(row, byType,null,false))
                    .all();
        } else {
            b.asByName();
            return client.execute(b.build())
                    .bind(ColumnNames.PROGRAM_YEAR.getColumnName(), programYear)
                    .bind(ColumnNames.NAME.getColumnName(), name)
                    .bind(ColumnNames.OFFSET.getColumnName(), offset)
                    .bind(ColumnNames.LIMIT.getColumnName(), limit)
                    .as(DerivedDeployment.class)
                    .map((row, rowMetadata) -> getDerivedDeploymentRow(row, byType, name,false))
                    .all();
        }
    }

    private DerivedDeployment getDerivedDeploymentRow(Row row, String byType, String name, boolean isRegion) {
        DerivedDeployment.DerivedDeploymentBuilder builder = DerivedDeployment.builder();
        if (isRegion) {
            builder.name(byType);
        } else {
            builder.name(getStringValue(row, byType));
        }
        if (name != null) {
            builder.state(getStringValue(row, ColumnNames.STATE.getColumnName()));
        }
        builder
            .lastUpdated(getValue(row, UPDATED_DATE_COLUMN, LocalDateTime.class))
            .ytdActual(getLongValue(row, DEPLOY_YTD_ACTUAL_COLUMN))
            .currentWeekCounts(getLongValue(row, "CurrentWeekDeploymentsCount"))
            .previousWeekCounts(getLongValue(row, "PreviousWeekDeploymentsCount"))
            .nextWeekForecastCounts(getLongValue(row, "NextWeekForcastDeploymentsCount"))
            .opportunityCounts(getLongValue(row, "DeploymentsOpportunityAssessmentCount"))
            .programYearGoal(getDoubleValue(row, "DeployYETarget"))
            .programYearVariance(getDoubleValue(row, "DeployYETargetVariance"))
            .ytdGoal(getDoubleValue(row, DEPLOY_YTD_TARGET_COLUMN))
            .ytdVariance(getDoubleValue(row, "DeployYTDTargetVariance"));
        return builder.build();
    }

    @Override
    public Flux<ReturnsNetCNA> getReturnsNetCNACounts(int programYear, String byType, String name, int offset, int limit, boolean regionSummary) {
        CommandCenterPerformanceQueryBuilder.Builder b = CommandCenterPerformanceQueryBuilder.builder();
        b.asReturnsNetCNA();
        if (byType.equals(ColumnNames.REGION.getColumnName())) {
            return getReturnsNetCNACountsRegion(b,programYear,byType,name,offset,limit,regionSummary);
        } else {
            return getReturnsNetCNACountsLobNameOrClientName(b,programYear,byType,name,offset,limit);
        }
    }

    private Flux<ReturnsNetCNA> getReturnsNetCNACountsRegion(CommandCenterPerformanceQueryBuilder.Builder b, int programYear, String byType, String name, int offset, int limit, boolean regionSummary) {
        b.asByRegion();
        if (regionSummary) {
            b.asByRegionSummary();
            return client.execute(b.build())
                    .bind(ColumnNames.REGION.getColumnName(),name)
                    .bind(ColumnNames.PROGRAM_YEAR.getColumnName(),programYear)
                    .as(ReturnsNetCNA.class)
                    .map((row, rowMetadata) -> getReturnsNetCNARow(row, name, null,true))
                    .all();
        } else {
            return client.execute(b.build())
                    .bind(ColumnNames.REGION.getColumnName(),name)
                    .bind(ColumnNames.PROGRAM_YEAR.getColumnName(),programYear)
                    .bind(ColumnNames.OFFSET.getColumnName(), offset)
                    .bind(ColumnNames.LIMIT.getColumnName(), limit)
                    .as(ReturnsNetCNA.class)
                    .map((row, rowMetadata) -> getReturnsNetCNARow(row, name, byType,true))
                    .all();
        }
    }

    private Flux<ReturnsNetCNA> getReturnsNetCNACountsLobNameOrClientName(CommandCenterPerformanceQueryBuilder.Builder b, int programYear, String byType, String name, int offset, int limit) {
        if (byType.equals(ColumnNames.CLIENT_NAME.getColumnName())) {
            b.asByClientName();
        } else {
            b.asByLobName();
        }
        if (name == null) {
            return client.execute(b.build())
                    .bind(ColumnNames.PROGRAM_YEAR.getColumnName(), programYear)
                    .bind(ColumnNames.OFFSET.getColumnName(), offset)
                    .bind(ColumnNames.LIMIT.getColumnName(), limit)
                    .as(ReturnsNetCNA.class)
                    .map((row, rowMetadata) -> getReturnsNetCNARow(row, byType, null,false))
                    .all();
        } else {
            b.asByName();
            return client.execute(b.build())
                    .bind(ColumnNames.PROGRAM_YEAR.getColumnName(), programYear)
                    .bind(ColumnNames.NAME.getColumnName(), name)
                    .bind(ColumnNames.OFFSET.getColumnName(), offset)
                    .bind(ColumnNames.LIMIT.getColumnName(), limit)
                    .as(ReturnsNetCNA.class)
                    .map((row, rowMetadata) -> getReturnsNetCNARow(row, byType, name,false))
                    .all();
        }
    }

    private ReturnsNetCNA getReturnsNetCNARow(Row row, String byType, String name, boolean isRegion) {
        ReturnsNetCNA.ReturnsNetCNABuilder builder = ReturnsNetCNA.builder();
        if (isRegion) {
            builder
                    .name(byType);
        } else {
            builder
                    .name(getStringValue(row, byType));
        }
        if (name != null) {
            builder
                .state(getStringValue(row, ColumnNames.STATE.getColumnName()));
        }
        builder
            .lastUpdated(getValue(row, UPDATED_DATE_COLUMN, LocalDateTime.class))
            .ytdActual(getLongValue(row, RETURN_NET_CNA_YTD_ACTUAL_COLUMN))
            .currentWeekCounts(getLongValue(row, "CurrentWeekReturnsCount"))
            .previousWeekCounts(getLongValue(row, "PreviousWeekReturnsCount"))
            .nextWeekForecastCounts(getLongValue(row, "NextWeekForcastReturnsCount"))
            .opportunityCounts(getLongValue(row, "ReturnsOpportunityAssessmentCount"))
            .programYearGoal(getDoubleValue(row, "ReturnYETarget"))
            .programYearVariance(getDoubleValue(row, "ReturnYETargetVariance"))
            .ytdGoal(getDoubleValue(row, RETURN_YTD_TARGET_COLUMN))
            .ytdVariance(getDoubleValue(row, "ReturnYTDTargetVariance"));
        return builder.build();
    }

    @Override
    public Flux<String> getCommandCenterRegions() {
        CommandCenterPerformanceQueryBuilder.Builder b = CommandCenterPerformanceQueryBuilder.builder();
        b.asCommandCenterRegions();
        return client.execute(b.build())
                .as(String.class)
                .map(row -> getStringValue(row,ColumnNames.REGION.getColumnName()))
                .all();
    }

    @Override
    public Flux<Long> getDerivedDeploymentOrReturnsNetCNATotalCount(int programYear, String byType, String name) {
        CommandCenterPerformanceQueryBuilder.Builder b = CommandCenterPerformanceQueryBuilder.builder();
        b.asByCount();
        if (byType.equals(ColumnNames.CLIENT_NAME.getColumnName())) {
            b.asByClientName();
        } else {
            b.asByLobName();
        }
        if (name == null) {
            return client.execute(b.build())
                    .bind(ColumnNames.PROGRAM_YEAR.getColumnName(), programYear)
                    .as(Long.class)
                    .fetch()
                    .all();
        } else {
            b.asByName();
            return client.execute(b.build())
                    .bind(ColumnNames.PROGRAM_YEAR.getColumnName(), programYear)
                    .bind(ColumnNames.NAME.getColumnName(), name)
                    .as(Long.class)
                    .fetch()
                    .all();
        }

    }

    @Override
    public Mono<Long> getDerivedDeploymentOrReturnsNetCNATotalRegionCount(int programYear, String byType, String name) {
        CommandCenterPerformanceQueryBuilder.Builder b = CommandCenterPerformanceQueryBuilder.builder();
        b.asByCount();
        b.asByRegion();
        if (name == null) {
            b.asByRegionSummary();
            return client.execute(b.build())
                    .as(Long.class)
                    .fetch()
                    .one();
        } else {
            return client.execute(b.build())
                    .bind(ColumnNames.REGION.getColumnName(),name)
                    .bind(ColumnNames.PROGRAM_YEAR.getColumnName(),programYear)
                    .bind(ColumnNames.OFFSET.getColumnName(), 0)
                    .bind(ColumnNames.LIMIT.getColumnName(), 1000)
                    .as(Long.class)
                    .fetch()
                    .one();
        }
    }


    @Override
    public Flux<DerivedDeploymentWeekly> getDerivedDeploymentWeeklyCounts(int programYear, List<String> regions, List<String> states, List<String> lobs, List<String> clients) {
        final String outputColumn = "WeeklyTotalDeploymentsCount";
        DatabaseClient.GenericExecuteSpec executeSpec = client.execute(getDerivedDeploymentAndReturnsNetCNAQuery(DEPLOY_YTD_ACTUAL_COLUMN, outputColumn, regions, states, lobs, clients))
                .bind(ColumnNames.PROGRAM_YEAR.getColumnName(), programYear)
                .bind(ColumnNames.PROVIDER_GROUP_ID.getColumnName(), CommandCenterConstants.ALL);
        executeSpec = getDerivedDeploymentAndReturnsNetCnaSpec(executeSpec,regions, states, lobs, clients);

        return executeSpec.as(DerivedDeploymentWeekly.class)
                .map((row, rowMetaData) -> DerivedDeploymentWeekly
                        .builder()
                        .programYear(getPrimitiveIntegerValue(row, ColumnNames.PROGRAM_YEAR.getColumnName()))
                        .month(getStringValue(row, ColumnNames.MONTH.getColumnName()))
                        .durationStartDate(getValue(row, ColumnNames.DURATION_START_DATE.getColumnName(), LocalDate.class))
                        .durationEndDate(getValue(row, ColumnNames.DURATION_END_DATE.getColumnName(), LocalDate.class))
                        .currentWeekCounts(getLongValue(row, outputColumn))
                        .lastUpdatedDate(getValue(row, UPDATED_DATE_COLUMN, LocalDateTime.class))
                        .build())
                .all();
    }

    @Override
    public Flux<DerivedDeploymentWeekly> getDerivedDeploymentWeeklyGoals(int programYear, List<String> regions, List<String> states, List<String> lobs, List<String> clients) {
        final String outputColumn = "WeeklyTotalDeploymentsGoals";
        DatabaseClient.GenericExecuteSpec executeSpec = client.execute(getDerivedDeploymentAndReturnsNetCNAQuery(DEPLOY_YTD_TARGET_COLUMN, outputColumn, regions, states, lobs, clients))
                .bind(ColumnNames.PROGRAM_YEAR.getColumnName(), programYear)
                .bind(ColumnNames.PROVIDER_GROUP_ID.getColumnName(), CommandCenterConstants.ALL);
        executeSpec = getDerivedDeploymentAndReturnsNetCnaSpec(executeSpec,regions, states, lobs, clients);

        return executeSpec.as(DerivedDeploymentWeekly.class)
                .map((row, rowMetaData) ->  DerivedDeploymentWeekly
                        .builder()
                        .programYear(getPrimitiveIntegerValue(row, ColumnNames.PROGRAM_YEAR.getColumnName()))
                        .month(getStringValue(row, ColumnNames.MONTH.getColumnName()))
                        .durationStartDate(getValue(row, ColumnNames.DURATION_START_DATE.getColumnName(), LocalDate.class))
                        .durationEndDate(getValue(row, ColumnNames.DURATION_END_DATE.getColumnName(), LocalDate.class))
                        .currentWeekGoals(getFloatValue(row, outputColumn))
                        .lastUpdatedDate(getValue(row, UPDATED_DATE_COLUMN, LocalDateTime.class))
                        .build())
                .all();
    }

    @Override
    public Flux<ReturnsNetCNAWeekly> getReturnsNetCnaWeeklyCounts(int programYear, List<String> regions, List<String> states, List<String> lobs, List<String> clients) {
        final String outputColumn = "WeeklyTotalReturnsCounts";
        DatabaseClient.GenericExecuteSpec executeSpec = client.execute(getDerivedDeploymentAndReturnsNetCNAQuery(RETURN_NET_CNA_YTD_ACTUAL_COLUMN, outputColumn, regions, states, lobs, clients))
                .bind(ColumnNames.PROGRAM_YEAR.getColumnName(), programYear)
                .bind(ColumnNames.PROVIDER_GROUP_ID.getColumnName(), CommandCenterConstants.ALL);
        executeSpec = getDerivedDeploymentAndReturnsNetCnaSpec(executeSpec,regions, states, lobs, clients);

        return executeSpec.as(ReturnsNetCNAWeekly.class)
                .map((row, rowMetaData) ->  ReturnsNetCNAWeekly
                        .builder()
                        .programYear(getPrimitiveIntegerValue(row, ColumnNames.PROGRAM_YEAR.getColumnName()))
                        .month(getStringValue(row, ColumnNames.MONTH.getColumnName()))
                        .durationStartDate(getValue(row, ColumnNames.DURATION_START_DATE.getColumnName(), LocalDate.class))
                        .durationEndDate(getValue(row, ColumnNames.DURATION_END_DATE.getColumnName(), LocalDate.class))
                        .currentWeekCounts(getLongValue(row, outputColumn))
                        .lastUpdatedDate(getValue(row, UPDATED_DATE_COLUMN, LocalDateTime.class))
                        .build())
                .all();
    }

    @Override
    public Flux<ReturnsNetCNAWeekly> getReturnsNetCnaWeeklyGoals(int programYear, List<String> regions, List<String> states, List<String> lobs, List<String> clients) {
        final String outputColumn = "WeeklyTotalReturnsGoals";
        DatabaseClient.GenericExecuteSpec executeSpec = client.execute(getDerivedDeploymentAndReturnsNetCNAQuery(RETURN_YTD_TARGET_COLUMN, outputColumn, regions, states, lobs, clients))
                .bind(ColumnNames.PROGRAM_YEAR.getColumnName(), programYear)
                .bind(ColumnNames.PROVIDER_GROUP_ID.getColumnName(), CommandCenterConstants.ALL);

        executeSpec = getDerivedDeploymentAndReturnsNetCnaSpec(executeSpec,regions, states, lobs, clients);

        return executeSpec.as(ReturnsNetCNAWeekly.class)
                .map((row, rowMetaData) ->  ReturnsNetCNAWeekly
                        .builder()
                        .programYear(getPrimitiveIntegerValue(row, ColumnNames.PROGRAM_YEAR.getColumnName()))
                        .month(getStringValue(row, ColumnNames.MONTH.getColumnName()))
                        .durationStartDate(getValue(row, ColumnNames.DURATION_START_DATE.getColumnName(), LocalDate.class))
                        .durationEndDate(getValue(row, ColumnNames.DURATION_END_DATE.getColumnName(), LocalDate.class))
                        .currentWeekGoals(getFloatValue(row, outputColumn))
                        .lastUpdatedDate(getValue(row, UPDATED_DATE_COLUMN, LocalDateTime.class))
                        .build())
                .all();
    }

    private String derivedDeploymentAndNetCnaFilterQuery(List<String> regions, List<String> states, List<String> lobs, List<String> clients){
        String regionParam = "AND Region in (:Region) ";
        String stateParam = "AND State in (:State) ";
        String lobParam = "AND LobName in (:LobName) ";
        String clientParam = "AND ClientName in (:ClientName) ";
        StringBuilder querySb = new StringBuilder();

        if (regions.indexOf(CommandCenterConstants.ALL) == -1){
            querySb.append(regionParam);
        }
        if (states.indexOf(CommandCenterConstants.ALL) == -1){
            querySb.append(stateParam);
        }
        if (lobs.indexOf(CommandCenterConstants.ALL) == -1){
            querySb.append(lobParam);
        }
        if (clients.indexOf(CommandCenterConstants.ALL) == -1){
            querySb.append(clientParam);
        }

        return querySb.toString();
    }

    private DatabaseClient.GenericExecuteSpec getDerivedDeploymentAndReturnsNetCnaSpec(
            DatabaseClient.GenericExecuteSpec executeSpec, List<String> regions, List<String> states, List<String> lobs, List<String> clients){
        if (regions.indexOf("All") == -1){ executeSpec = executeSpec.bind(ColumnNames.REGION.getColumnName(), regions);}
        if (states.indexOf("All") == -1){ executeSpec = executeSpec.bind(ColumnNames.STATE.getColumnName(), states);}
        if (lobs.indexOf("All") == -1){ executeSpec = executeSpec.bind(ColumnNames.LOB_NAME.getColumnName(), lobs);}
        if (clients.indexOf("All") == -1){ executeSpec = executeSpec.bind(ColumnNames.CLIENT_NAME.getColumnName(), clients);}
        return executeSpec;
    }

    private String getDerivedDeploymentAndReturnsNetCNAQuery(String column, String outputName, List<String> regions, List<String> states, List<String> lobs, List<String> clients) {
        return String.format(DEPLOYMENT_AND_RETURN_WEEKLY_PARTS_QUERY, outputName, column, outputName, derivedDeploymentAndNetCnaFilterQuery(regions, states, lobs, clients), outputName);
    }


    String getStringValue(Row row, String columnName) {
        return getValue(row, columnName, String.class);
    }

}
