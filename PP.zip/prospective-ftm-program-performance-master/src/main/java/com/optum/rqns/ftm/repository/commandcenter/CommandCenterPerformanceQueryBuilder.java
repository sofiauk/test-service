package com.optum.rqns.ftm.repository.commandcenter;

public class CommandCenterPerformanceQueryBuilder {
    private static final CommandCenterPerformanceQueryBuilder INSTANCE =
            new CommandCenterPerformanceQueryBuilder();

    private CommandCenterPerformanceQueryBuilder() {}

    public static Builder builder() { return INSTANCE.new Builder(); }

    public class Builder {

        private static final String ORDER_BY_DEPLOY_YTD_TARGET_VARIANCE_NULL_LAST =
                "CASE WHEN MAX(DeployYTDTargetVariance) IS NULL THEN 1 ELSE 0 END, DeployYTDTargetVariance";
        private static final String ORDER_BY_RETURN_YTD_TARGET_VARIANCE_NULL_LAST =
                "CASE WHEN MAX(ReturnYTDTargetVariance) IS NULL THEN 1 ELSE 0 END, ReturnYTDTargetVariance";
        private static final String OFFSET_AND_LIMIT_PAGINATION = "OFFSET :Offset ROWS FETCH NEXT :Limit ROWS ONLY";
        private static final String LOB_NAME = "LobName";
        private static final String CLIENT_NAME = "ClientName";
        private static final String CURRENT_WEEK_PERFORMANCE_FOR_PROGRAM_YEAR =
                "IsCurrentWeekForPerformance = 1 AND ProgramYear = :ProgramYear ";
        private static final String FROM_PROG_PERF_COMMAND_CENTER_PERFORMANCE =
                "FROM ProgPerf.CommandCenterPerformance WHERE ";
        private static final String COUNT_PREFIX = "SELECT COUNT(*) FROM (";
        private static final String COUNT_SUFFIX = ") t2";
        private static final String REGION_IS_NOT_NULL = "AND Region IS NOT NULL ";

        static final String DERIVED_DEPLOYMENTS_AGGREGATION =
                "SUM(DeployYTDActual) AS DeployYTDActual, " +
                "SUM(CurrentWeekDeploymentsCount) AS CurrentWeekDeploymentsCount, " +
                "SUM(PreviousWeekDeploymentsCount) AS PreviousWeekDeploymentsCount, " +
                "SUM(NextWeekForcastDeploymentsCount) AS NextWeekForcastDeploymentsCount, " +
                "SUM(DeploymentsOpportunityAssessmentCount) AS DeploymentsOpportunityAssessmentCount, " +
                "SUM(DeployYETarget) AS DeployYETarget, " +
                "SUM(DeployYETargetVariance) AS DeployYETargetVariance, " +
                "SUM(DeployYTDTarget) AS DeployYTDTarget, " +
                "SUM(DeployYTDTargetVariance) AS DeployYTDTargetVariance, " +
                "MAX(UpdatedDate) AS UpdatedDate ";

        static final String DERIVED_DEPLOYMENTS_AGGREGATION_ALIASED =
                "SUM(t.DeployYTDActual) AS DeployYTDActual, " +
                "SUM(t.CurrentWeekDeploymentsCount) AS CurrentWeekDeploymentsCount, " +
                "SUM(t.PreviousWeekDeploymentsCount) AS PreviousWeekDeploymentsCount, " +
                "SUM(t.NextWeekForcastDeploymentsCount) AS NextWeekForcastDeploymentsCount, " +
                "SUM(t.DeploymentsOpportunityAssessmentCount) AS DeploymentsOpportunityAssessmentCount, " +
                "SUM(t.DeployYETarget) AS DeployYETarget, " +
                "SUM(t.DeployYETargetVariance) AS DeployYETargetVariance, " +
                "SUM(t.DeployYTDTarget) AS DeployYTDTarget, " +
                "SUM(t.DeployYTDTargetVariance) AS DeployYTDTargetVariance, " +
                "MAX(t.UpdatedDate) AS UpdatedDate ";

        static final String RETURN_NET_CNA_AGGREGATION =
                "SUM(ReturnedNetCnaYtdActual) AS ReturnedNetCnaYtdActual, " +
                "SUM(CurrentWeekReturnsCount) AS CurrentWeekReturnsCount, " +
                "SUM(PreviousWeekReturnsCount) AS PreviousWeekReturnsCount, " +
                "SUM(NextWeekForcastReturnsCount) AS NextWeekForcastReturnsCount, " +
                "SUM(ReturnsOpportunityAssessmentCount) AS ReturnsOpportunityAssessmentCount, " +
                "SUM(ReturnYETarget) AS ReturnYETarget, " +
                "SUM(ReturnYETargetVariance) AS ReturnYETargetVariance, " +
                "SUM(ReturnYTDTarget) AS ReturnYTDTarget, " +
                "SUM(ReturnYTDTargetVariance) AS ReturnYTDTargetVariance, " +
                "MAX(UpdatedDate) AS UpdatedDate ";

        static final String RETURN_NET_CNA_AGGREGATION_ALIASED =
                "SUM(t.ReturnedNetCnaYtdActual) AS ReturnedNetCnaYtdActual, " +
                "SUM(t.CurrentWeekReturnsCount) AS CurrentWeekReturnsCount, " +
                "SUM(t.PreviousWeekReturnsCount) AS PreviousWeekReturnsCount, " +
                "SUM(t.NextWeekForcastReturnsCount) AS NextWeekForcastReturnsCount, " +
                "SUM(t.ReturnsOpportunityAssessmentCount) AS ReturnsOpportunityAssessmentCount, " +
                "SUM(t.ReturnYETarget) AS ReturnYETarget, " +
                "SUM(t.ReturnYETargetVariance) AS ReturnYETargetVariance, " +
                "SUM(t.ReturnYTDTarget) AS ReturnYTDTarget, " +
                "SUM(t.ReturnYTDTargetVariance) AS ReturnYTDTargetVariance, " +
                "MAX(t.UpdatedDate) AS UpdatedDate ";
        
        static final String REGION_SUMMARY_BASE_QUERY =
                "SELECT %s " +
                "FROM (" +
                "   SELECT State, %s" +
                    FROM_PROG_PERF_COMMAND_CENTER_PERFORMANCE +
                    CURRENT_WEEK_PERFORMANCE_FOR_PROGRAM_YEAR +
                    REGION_IS_NOT_NULL +
                "   GROUP BY State " +
                ") as t " +
                "INNER JOIN ( " +
                "   SELECT DISTINCT(Location), MAX(LocationType) AS LocationType, MAX(Level) AS Level " +
                "   FROM ProgPerf.GeographicalHierarchy " +
                "   WHERE LocationType LIKE 'State' " +
                "   GROUP BY Location " +
                ") v " +
                "ON v.Location = t.State " +
                "AND v.Level.GetAncestor(2) IN ( " +
                "   SELECT gh1.Level " +
                "   FROM ProgPerf.GeographicalHierarchy gh1 " +
                "   WHERE gh1.Location LIKE :Region " + //THE ACTUAL REGION NAME E.G. (EAST, CENTRAL, WEST)
                "   AND gh1.LocationType LIKE 'Region'" +
                ")";

        static final String REGION_BY_STATE_BASE_QUERY =
                "SELECT State, %s " +
                FROM_PROG_PERF_COMMAND_CENTER_PERFORMANCE +
                CURRENT_WEEK_PERFORMANCE_FOR_PROGRAM_YEAR +
                "AND State in (" +
                    "SELECT Location " +
                    "FROM ProgPerf.GeographicalHierarchy " +
                    "WHERE LocationType LIKE 'State' " +
                    "AND Level.GetAncestor(2) IN (" +
                        "SELECT Level " +
                        "FROM ProgPerf.GeographicalHierarchy " +
                        "WHERE Location LIKE :Region " +
                        "AND LocationType LIKE 'Region'" +
                    ")" +
                ") " +
                "GROUP BY State " +
                "ORDER BY %s, State ";

        static final String COMMAND_CENTER_REGIONS =
                "SELECT Distinct(t.Location) AS Region, t.Ordering, MAX(UpdatedDate) as UpdatedDate " +
                "FROM (" +
                "   SELECT g.Location, g.Level, g.Ordering " +
                "   FROM ProgPerf.GeographicalHierarchy g" +
                "   WHERE g.LocationType LIKE 'Region' " +
                "   AND g.DeletedDate IS NULL" +
                ") t " +
                "INNER JOIN ProgPerf.GeographicalHierarchy g2 " +
                "ON g2.Level.GetAncestor(2) IN (" +
                "   SELECT Level" +
                "   FROM ProgPerf.GeographicalHierarchy" +
                "   WHERE Location LIKE t.Location " +
                "   AND LocationType LIKE 'Region'" +
                ") " +
                "WHERE g2.LocationType LIKE 'State' " +
                "AND LEN(g2.Location) = 2 " +
                "GROUP BY t.Ordering, t.Location " +
                "ORDER BY t.Ordering ASC OFFSET 0 ROWS FETCH NEXT 1000 ROWS ONLY";

        static final String LOB_OR_CLIENT_BASE_QUERY =
                "SELECT %s, %s" +
                FROM_PROG_PERF_COMMAND_CENTER_PERFORMANCE +
                CURRENT_WEEK_PERFORMANCE_FOR_PROGRAM_YEAR +
                REGION_IS_NOT_NULL +
                "GROUP BY %s " +
                "ORDER BY %s, %s ";

        static final String LOB_OR_CLIENT_BASE_QUERY_NAMED =
                "SELECT %s, State, %s" +
                FROM_PROG_PERF_COMMAND_CENTER_PERFORMANCE +
                CURRENT_WEEK_PERFORMANCE_FOR_PROGRAM_YEAR +
                REGION_IS_NOT_NULL +
                "AND %s = :Name " +
                "GROUP BY %s, State " +
                "ORDER BY %s, %s, State ";

        static final String BASE_DERIVED_DEPLOYMENT_RETURNS_COUNT =
                "SELECT COUNT(*) " +
                        FROM_PROG_PERF_COMMAND_CENTER_PERFORMANCE +
                CURRENT_WEEK_PERFORMANCE_FOR_PROGRAM_YEAR +
                REGION_IS_NOT_NULL +
                "GROUP BY %s";

        static final String BASE_DERIVED_DEPLOYMENT_RETURNS_COUNT_NAMED =
                "SELECT COUNT(*) " +
                FROM_PROG_PERF_COMMAND_CENTER_PERFORMANCE +
                CURRENT_WEEK_PERFORMANCE_FOR_PROGRAM_YEAR +
                REGION_IS_NOT_NULL +
                "AND %s = :Name " +
                "GROUP BY %s, State";
        
        private boolean isReturnsNetCNA = false;
        private boolean isDerivedDeployment = false;
        private boolean isCommandCenterRegions = false;
        private boolean isByRegion = false;
        private boolean isByRegionSummary = false;
        private boolean isByLobName = false;
        private boolean isByClientName = false;
        private boolean isByName = false;
        private boolean isCount = false;

        private Builder() {}

        Builder asReturnsNetCNA() {
            this.isReturnsNetCNA = true;
            return this;
        }

        Builder asDerivedDeployment() {
            this.isDerivedDeployment = true;
            return this;
        }

        Builder asCommandCenterRegions() {
            this.isCommandCenterRegions = true;
            return this;
        }

        Builder asByRegion() {
            this.isByRegion = true;
            return this;
        }

        Builder asByLobName() {
            this.isByLobName = true;
            return this;
        }

        Builder asByClientName() {
            this.isByClientName = true;
            return this;
        }

        Builder asByRegionSummary() {
            this.isByRegionSummary = true;
            return this;
        }

        Builder asByName() {
            this.isByName = true;
            return this;
        }

        Builder asByCount() {
            this.isCount = true;
            return this;
        }

        public String build() {
            StringBuilder sb = new StringBuilder();
            if (isByRegion) {
                constructByRegionQueries(sb);
            } else if (isByLobName) {
                constructByLobNameQueries(sb);
            } else if (isByClientName) {
                constructByClientNameQueries(sb);
            } else if (isCommandCenterRegions) {
                sb.append(COMMAND_CENTER_REGIONS);
            } else {
                sb.setLength(0);
            }
            return sb.toString();
        }
        
        private void constructByRegionQueries(StringBuilder sb) {
            if(isCount) {
                if (isByRegionSummary) {
                    sb.append(COUNT_PREFIX)
                        .append(COMMAND_CENTER_REGIONS)
                        .append(COUNT_SUFFIX);
                } else {
                    sb.append(COUNT_PREFIX)
                        .append(String.format(
                                REGION_BY_STATE_BASE_QUERY,
                                RETURN_NET_CNA_AGGREGATION,
                                ORDER_BY_RETURN_YTD_TARGET_VARIANCE_NULL_LAST
                        ))
                        .append(OFFSET_AND_LIMIT_PAGINATION)
                        .append(COUNT_SUFFIX);
                }
            } else if (isReturnsNetCNA) {
                if (isByRegionSummary) {
                    sb.append(String.format(
                            REGION_SUMMARY_BASE_QUERY,
                            RETURN_NET_CNA_AGGREGATION_ALIASED,
                            RETURN_NET_CNA_AGGREGATION
                    ));
                } else {
                    sb.append(String.format(
                            REGION_BY_STATE_BASE_QUERY,
                            RETURN_NET_CNA_AGGREGATION,
                            ORDER_BY_RETURN_YTD_TARGET_VARIANCE_NULL_LAST
                    ))
                    .append(OFFSET_AND_LIMIT_PAGINATION);
                }
            } else if(isDerivedDeployment) {
                if (isByRegionSummary) {
                    sb.append(String.format(
                            REGION_SUMMARY_BASE_QUERY,
                            DERIVED_DEPLOYMENTS_AGGREGATION_ALIASED,
                            DERIVED_DEPLOYMENTS_AGGREGATION
                    ));
                } else {
                    sb.append(String.format(
                            REGION_BY_STATE_BASE_QUERY,
                            DERIVED_DEPLOYMENTS_AGGREGATION,
                            ORDER_BY_DEPLOY_YTD_TARGET_VARIANCE_NULL_LAST
                    ))
                    .append(OFFSET_AND_LIMIT_PAGINATION);
                }
            } else {
                sb.setLength(0);
            }
        }

        private void constructByLobNameQueries(StringBuilder sb) {
            if(isCount) {
                if (isByName) {
                    sb.append(String.format(BASE_DERIVED_DEPLOYMENT_RETURNS_COUNT_NAMED,LOB_NAME,LOB_NAME));
                } else {
                    sb.append(String.format(BASE_DERIVED_DEPLOYMENT_RETURNS_COUNT,LOB_NAME));
                }
            } else if (isReturnsNetCNA) {
                if (isByName) {
                    sb.append(String.format(
                            LOB_OR_CLIENT_BASE_QUERY_NAMED,
                            LOB_NAME,
                            RETURN_NET_CNA_AGGREGATION,
                            LOB_NAME,
                            LOB_NAME,
                            ORDER_BY_RETURN_YTD_TARGET_VARIANCE_NULL_LAST,
                            LOB_NAME
                    ))
                    .append(OFFSET_AND_LIMIT_PAGINATION);
                } else {
                    sb.append(String.format(
                            LOB_OR_CLIENT_BASE_QUERY,
                            LOB_NAME,
                            RETURN_NET_CNA_AGGREGATION,
                            LOB_NAME,
                            ORDER_BY_RETURN_YTD_TARGET_VARIANCE_NULL_LAST,
                            LOB_NAME
                    ))
                    .append(OFFSET_AND_LIMIT_PAGINATION);
                }
            } else if(isDerivedDeployment) {
                if (isByName) {
                    sb.append(String.format(
                            LOB_OR_CLIENT_BASE_QUERY_NAMED,
                            LOB_NAME,
                            DERIVED_DEPLOYMENTS_AGGREGATION,
                            LOB_NAME,
                            LOB_NAME,
                            ORDER_BY_DEPLOY_YTD_TARGET_VARIANCE_NULL_LAST,
                            LOB_NAME
                    ))
                    .append(OFFSET_AND_LIMIT_PAGINATION);
                } else {
                    sb.append(String.format(
                            LOB_OR_CLIENT_BASE_QUERY,
                            LOB_NAME,
                            DERIVED_DEPLOYMENTS_AGGREGATION,
                            LOB_NAME,
                            ORDER_BY_DEPLOY_YTD_TARGET_VARIANCE_NULL_LAST,
                            LOB_NAME
                    ))
                    .append(OFFSET_AND_LIMIT_PAGINATION);
                }
            } else {
                sb.setLength(0);
            }
        }

        private void constructByClientNameQueries(StringBuilder sb) {
            if(isCount) {
                if (isByName) {
                    sb.append(String.format(BASE_DERIVED_DEPLOYMENT_RETURNS_COUNT_NAMED,CLIENT_NAME,CLIENT_NAME));
                } else {
                    sb.append(String.format(BASE_DERIVED_DEPLOYMENT_RETURNS_COUNT,CLIENT_NAME));
                }
            } else if (isReturnsNetCNA) {
                if (isByName) {
                    sb.append(String.format(
                            LOB_OR_CLIENT_BASE_QUERY_NAMED,
                            CLIENT_NAME,
                            RETURN_NET_CNA_AGGREGATION,
                            CLIENT_NAME,
                            CLIENT_NAME,
                            ORDER_BY_RETURN_YTD_TARGET_VARIANCE_NULL_LAST,
                            CLIENT_NAME
                    ))
                    .append(OFFSET_AND_LIMIT_PAGINATION);
                } else {
                    sb.append(String.format(
                            LOB_OR_CLIENT_BASE_QUERY,
                            CLIENT_NAME,
                            RETURN_NET_CNA_AGGREGATION,
                            CLIENT_NAME,
                            ORDER_BY_RETURN_YTD_TARGET_VARIANCE_NULL_LAST,
                            CLIENT_NAME
                    ))
                    .append(OFFSET_AND_LIMIT_PAGINATION);
                }
            } else if(isDerivedDeployment) {
                if (isByName) {
                    sb.append(String.format(
                            LOB_OR_CLIENT_BASE_QUERY_NAMED,
                            CLIENT_NAME,
                            DERIVED_DEPLOYMENTS_AGGREGATION,
                            CLIENT_NAME,
                            CLIENT_NAME,
                            ORDER_BY_DEPLOY_YTD_TARGET_VARIANCE_NULL_LAST,
                            CLIENT_NAME
                    ))
                    .append(OFFSET_AND_LIMIT_PAGINATION);
                } else {
                    sb.append(String.format(
                            LOB_OR_CLIENT_BASE_QUERY,
                            CLIENT_NAME,
                            DERIVED_DEPLOYMENTS_AGGREGATION,
                            CLIENT_NAME,
                            ORDER_BY_DEPLOY_YTD_TARGET_VARIANCE_NULL_LAST,
                            CLIENT_NAME
                    ))
                    .append(OFFSET_AND_LIMIT_PAGINATION);
                }
            } else {
                sb.setLength(0);
            }
        }

    }

}
