package com.optum.rqns.ftm.batch.quartz.jobs;

import com.optum.rqns.ftm.enums.ExecutionWeek;
import com.optum.rqns.ftm.enums.GroupsToExecute;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.producer.JobEventProducer;
import com.optum.rqns.ftm.repository.common.CommonRepository;
import com.optum.rqns.ftm.service.masterconfigservice.MasterConfigService;
import lombok.extern.slf4j.Slf4j;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;

@Profile("rqnsFtmJobs")
@Slf4j
@Component
@DisallowConcurrentExecution
public class PaymentRulesJob implements Job {

    @Autowired
    private JobEventProducer jobEventProducer;
    @Autowired
    private CommonRepository commonRepository;

    private static final String JOB_NAME = JobName.RUN_PAYMENT_RULES.getValue ();
    private static final String GROUPS_TO_EXECUTE = GroupsToExecute.ALL.getValue ();
    private static final String EXECUTION_WEEK = ExecutionWeek.ALL.getValue ();
    private static final String STATUS = Status.IN_PROGRESS.getValue (); //"Start";
    private static final String DESCRIPTION = "notification to run Payement Rules (Financial Information) job";

    @Override
    public void execute(JobExecutionContext context) {
        log.info ("Job ** {} ** starting @ {}", context.getJobDetail ().getKey ().getName (), context.getFireTime ());
        notifyRunOutlierRulesJob (context, buildJobEvent ());
    }

    private JobEvent buildJobEvent() {
        int projectYear = LocalDateTime.ofInstant (Instant.now (), ZoneOffset.UTC).getYear (); // Year not important for financial info rule execution - hence setting default date.
        return JobEvent.newBuilder ().setJobName (JOB_NAME).setGroupsToExecute (GROUPS_TO_EXECUTE)
                .setExecutionWeek (EXECUTION_WEEK).setStatus (STATUS).setProgramYear (projectYear)
                .setTimeStamp (Instant.now ()).build ();
    }

    private void notifyRunOutlierRulesJob(JobExecutionContext context, JobEvent jobEvent) {
        try {
            String value =  commonRepository.getValueFromConfiguration("EnableRedisJobFlow").block();
            if ("true".equalsIgnoreCase(value)){
                jobEvent.setEventType("REDIS");
            }
            boolean sent = jobEventProducer.postToMsgQue(jobEvent);
            if (!sent) {
                log.error ("Failed to send {}", DESCRIPTION);
            }
            log.info ("Successfully sent {}", DESCRIPTION);
        } catch (Exception e) {
            log.error ("Job Failed " + "Job ** {} ** starting @ {}  with Exception ## {} ",
                    context.getJobDetail ().getKey ().getName (), context.getFireTime (), e.getMessage ());
        }
    }
}