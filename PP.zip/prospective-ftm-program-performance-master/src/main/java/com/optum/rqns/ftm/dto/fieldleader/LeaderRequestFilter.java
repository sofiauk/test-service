package com.optum.rqns.ftm.dto.fieldleader;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Builder
@Data
public class LeaderRequestFilter {
    private List<LeaderFilter> serviceLevel;
    private List<LeaderFilter> clientName;
    private List<LeaderFilter> lob;
}
