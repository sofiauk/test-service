package com.optum.rqns.ftm.dto.export.converter;

import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.model.export.ExportDetail;
import io.r2dbc.spi.Row;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.convert.converter.Converter;

import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Objects;

import static com.optum.rqns.ftm.repository.exports.ExportRepositoryImpl.Columns.EXPORTED_DATE;
import static com.optum.rqns.ftm.repository.exports.ExportRepositoryImpl.Columns.FILE_NAME;
import static com.optum.rqns.ftm.repository.exports.ExportRepositoryImpl.Columns.FILE_SIZE;
import static com.optum.rqns.ftm.repository.exports.ExportRepositoryImpl.Columns.IS_CANCELLED;
import static com.optum.rqns.ftm.repository.exports.ExportRepositoryImpl.Columns.IS_READ;
import static com.optum.rqns.ftm.repository.exports.ExportRepositoryImpl.Columns.OPTUM_UUID;
import static com.optum.rqns.ftm.repository.exports.ExportRepositoryImpl.Columns.TRANSACTION_ID;


@Slf4j
public class ExportDTOConverter extends ExportsDTOConverterHelper implements Converter<Row, ExportDetail>, DTOWrapperTypeConverter {
    private static final byte B_SIZE = (byte) 1;
    private static final Long KB_SIZE = Long.valueOf(1024L * B_SIZE);
    private static final Long MB_SIZE = 1024 * KB_SIZE;
    DecimalFormat df = new DecimalFormat("#.##");

    @Override
    public ExportDetail convert(Row row) {

        return ExportDetail.builder()
                .optumUuid(row.get(OPTUM_UUID.getValue(), String.class))
                .transactionId(getPrimitiveLongValue(row, TRANSACTION_ID.getValue()))
                .fileName(row.get(FILE_NAME.getValue(), String.class))
                .processType(getProcessType(row))
                .processSubType(getProcessSubType(row))
                .documentType(getDocumentType(row))
                .exportedDateTime(row.get(EXPORTED_DATE.getValue(), LocalDateTime.class))
                .exportedDate(getDate(row.get(EXPORTED_DATE.getValue(), LocalDateTime.class)))
                .exportedTime(getTime(row.get(EXPORTED_DATE.getValue(), LocalDateTime.class)))
                .fileSize(getSizeString(getLongValue(row, FILE_SIZE.getValue())))
                .exportStatus(getExportStatus(row))
                .isRead(hasBooleanValue(row, IS_READ.getValue()))
                .isCancelled(hasBooleanValue(row, IS_CANCELLED.getValue()))
                .build();
    }

    private String getSizeString(Long longValue) {
        if (Objects.isNull(longValue)) {
            return null;
        } else if(longValue < KB_SIZE){
            return longValue + " B";
        } else if(longValue < MB_SIZE){
            return  df.format((double) longValue / (double) KB_SIZE ) + " KB";
        } else {
            return  df.format((double) longValue / (double) MB_SIZE ) + " MB";
        }
    }

    private LocalDate getDate(LocalDateTime localDateTime) {
        if (Objects.nonNull(localDateTime)) {
            return LocalDate.of(localDateTime.getYear(), localDateTime.getMonth(), localDateTime.getDayOfMonth());
        }
        return null;
    }

    private LocalTime getTime(LocalDateTime localDateTime) {
        if (Objects.nonNull(localDateTime)) {
            return LocalTime.of(localDateTime.getHour(), localDateTime.getMinute(), localDateTime.getSecond());
        }
        return null;
    }
}
