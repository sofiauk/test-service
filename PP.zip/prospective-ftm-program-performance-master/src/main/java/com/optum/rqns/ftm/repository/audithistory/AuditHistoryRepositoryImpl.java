package com.optum.rqns.ftm.repository.audithistory;

import com.optum.rqns.ftm.model.audithistory.AuditHistory;
import org.springframework.data.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

@Repository
public class AuditHistoryRepositoryImpl implements AuditHistoryRepository {

    private final DatabaseClient client;

    AuditHistoryRepositoryImpl(DatabaseClient client) { this.client = client;}

    private static final String INSERT_AUDIT_HISTORY =
            "INSERT INTO ProgPerf.AuditHistory " +
                "(TableName, FieldName, OldValue, NewValue, ByWhom, Reason, RecordId, UpdatedDate) " +
            "VALUES " +
                "('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')";

    @Override
    public Mono<Integer> insertAuditHistory(AuditHistory auditHistory) {
        return client.execute(getInsertAuditHistoryFormatted(auditHistory))
                .fetch()
                .rowsUpdated();
    }

    private String getInsertAuditHistoryFormatted(AuditHistory auditHistory) {
        return String.format(INSERT_AUDIT_HISTORY,
                auditHistory.getTableName(),
                auditHistory.getFieldName(),
                auditHistory.getOldValue(),
                auditHistory.getNewValue(),
                auditHistory.getByWhom(),
                auditHistory.getReason(),
                auditHistory.getRecordId(),
                auditHistory.getUpdatedDate());
    }

}
