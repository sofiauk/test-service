package com.optum.rqns.ftm.dto.rules;

import com.optum.rqns.ftm.model.rules.DeploymentOpportunityInput;
import com.optum.rqns.ftm.repository.rules.RuleRepositoryImpl;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;

public class DeploymentOpportunityInputConverter implements Converter<Row, DeploymentOpportunityInput> {

    @Override
    public DeploymentOpportunityInput convert(Row rs) {

        return DeploymentOpportunityInput.builder()
                .providerGroupId(rs.get(RuleRepositoryImpl.ColumnNames.PROVIDERGROUPID.getColumnName(),String.class))
                .providerState(rs.get(RuleRepositoryImpl.ColumnNames.PROVIDERSTATE.getColumnName(),String.class))
                .client(rs.get(RuleRepositoryImpl.ColumnNames.CLIENTNAME.getColumnName(),String.class))
                .clientId(rs.get(RuleRepositoryImpl.ColumnNames.CLIENT_ID.getColumnName(),String.class))
                .lobName(rs.get(RuleRepositoryImpl.ColumnNames.LOBNAME.getColumnName(),String.class))
                .projectYear(rs.get(RuleRepositoryImpl.ColumnNames.PROGRAMYEAR.getColumnName(),Integer.class))
                .eligibleMembersCount(rs.get(RuleRepositoryImpl.ColumnNames.ELIGIBLEMEMBERSCOUNT.getColumnName(),Integer.class))
                .providerGroupName(rs.get(RuleRepositoryImpl.ColumnNames.PROVIDERGROUPNAME.getColumnName(),String.class))
                .serviceLevel(rs.get(RuleRepositoryImpl.ColumnNames.SERVICELEVEL.getColumnName(),String.class))
                .isProviderAssociated(rs.get(RuleRepositoryImpl.ColumnNames.ISPROVIDERASSOCIATED.getColumnName(),String.class))
                .isDeployed(rs.get(RuleRepositoryImpl.ColumnNames.ISDEPLOYED.getColumnName(),String.class))
                .build();
    }
}