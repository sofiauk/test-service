package com.optum.rqns.ftm.model.goals.client;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
//@JsonInclude(JsonInclude.Include.NON_NULL)
public class ClientGoalsAggregate {
    private int programYear;
    private SnapshotValues aggregate;
}
