package com.optum.rqns.ftm.repository.weeklyJobs;

import com.optum.rqns.ftm.enums.JobName;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

@Repository
@Slf4j
public class RunWeeklyJobsRepositoryImpl implements RunWeeklyJobsRepository {
    private final DatabaseClient client;

    public RunWeeklyJobsRepositoryImpl(DatabaseClient client) {
        this.client = client;
    }

    private static final String PERFORMANCE_TABLE = "ProgPerf.ProviderGroupPerformance";
    private static final String WEEKLY_TABLE = "ProgPerf.ProviderGroupPerformanceWeekly";
    private static final String COMMAND_CENTER_TABLE = "ProgPerf.CommandCenterPerformance";
    private static final String PROGRAM_YEAR_STR = "ProgramYear";
    private static final String UPDATED_BY_STR = "UpdatedBy";



    private static final String DEFLAG_CURRENT_PY_IS_CURRENT_WEEK_PERFORMANCE = "update %s set isCurrentWeekForPerformance = 0  " +
            ",UpdatedBy =:UpdatedBy,UpdatedDate =getUtcDate() "+
            "WHERE ProgramYear = :ProgramYear and isCurrentWeekForPerformance = 1";
    private static final String DEFLAG_PREVIOUS_PY_IS_CURRENT_WEEK_PERFORMANCE = "update %s set isCurrentWeekForPerformance = 0  " +
            ",UpdatedBy =:UpdatedBy,UpdatedDate =getUtcDate() "+
            "WHERE ProgramYear = :ProgramYear - 1 and isCurrentWeekForPerformance = 1 " +
            "and DurationValue != (SELECT TOP 1 DurationValue FROM ProgPerf.ProgramYearCalendar   " +
            "WITH (NOLOCK) where  DurationType ='WEEK' and    " +
            "ProgramYear = :ProgramYear-1 ORDER BY EndDate DESC)";
    
    private static final String RESET_IS_ACTION_SENT = "update ProgPerf.ProviderGroupExtended set IsActionSent = 0 where IsActionSent = 1";

    private static final String UPDATE_IS_LAST_WEEK_OF_MONTH_WITH_ONE = "with cte as( Select  pyc.ProgramYear ProgramYear,  DateName(month,pyc.StartDate) month,  MAX(pyc.StartDate)  StartDate,  pyc.DurationType DurationType,  max(durationvalue) durationvalue from  ProgPerf.ProgramYearCalendar pyc where  pyc.DurationType = 'week'  and pyc.ProgramYear >=(:ProgramYear -2)  and pyc.ProgramYear <= :ProgramYear group by  pyc.ProgramYear,  DateName(month,pyc.StartDate),  pyc.DurationType  )  update ProgPerf.CommandCenterPerformance  set  isLastweekofmonth = 0,  month = DateName(month,DurationStartDate),  UpdatedBy = :UpdatedBy  where (isLastweekofmonth <> 0 or isLastweekofmonth is null) and DurationValue not in (select durationvalue from cte);";
    private static final String UPDATE_IS_LAST_WEEK_OF_MONTH_WITH_ZERO = "with cte as( Select   pyc.ProgramYear ProgramYear,   DateName(month,pyc.StartDate) month,   MAX(pyc.StartDate)  StartDate,   pyc.DurationType DurationType,   max(durationvalue) durationvalue from   ProgPerf.ProgramYearCalendar pyc where   pyc.DurationType = 'week'   and pyc.ProgramYear >=(:ProgramYear -2)   and pyc.ProgramYear <= :ProgramYear group by   pyc.ProgramYear,   DateName(month,pyc.StartDate),   pyc.DurationType   )   update ProgPerf.CommandCenterPerformance  set   isLastweekofmonth = 1,   month = DateName(month,DurationStartDate),   UpdatedBy = :UpdatedBy   where (isLastweekofmonth <> 1 or isLastweekofmonth is null) and DurationValue  in (select durationvalue from cte)   ;";
    private final String UPDATE_IS_LAST_WEEK_OF_MONTH_FOR_CURRENT_WEEK = "update ProgPerf.CommandCenterPerformance set IsLastWeekofMonth = 1,  UpdatedBy = :UpdatedBy where DurationStartDate <= GETUTCDATE() and DurationEndDate >=GETUTCDATE() and ProgramYear =:ProgramYear ";

    @Override
    public Mono<Integer> deflagIsCurretWeekPerformance(Integer programYear) {
        log.debug("deflagIsCurretWeekPerformance programYear:: {}", programYear);
        return client
                .execute(String.format(DEFLAG_CURRENT_PY_IS_CURRENT_WEEK_PERFORMANCE, PERFORMANCE_TABLE))
                .bind(PROGRAM_YEAR_STR, programYear)
                .bind(UPDATED_BY_STR, JobName.RUN_WEEKLY_JOBS.getValue())
                .fetch()
                .rowsUpdated()
                .flatMap(ppCurrentYearUpdatedCount -> {
                    log.debug("updateIsCurretWeekPerformanceWeely currentYearUpdatedcount {}", ppCurrentYearUpdatedCount);
                    return client
                            .execute(String.format(DEFLAG_CURRENT_PY_IS_CURRENT_WEEK_PERFORMANCE, WEEKLY_TABLE))
                            .bind(PROGRAM_YEAR_STR, programYear)
                            .bind(UPDATED_BY_STR, JobName.RUN_WEEKLY_JOBS.getValue())
                            .fetch()
                            .rowsUpdated()
                            .map(count -> ppCurrentYearUpdatedCount + count);
                })
                .flatMap(ccCurrentYearUpdatedCount -> {
                    log.debug("updateIsCurretWeekPerformance in command center currentYearUpdatedcount {}", ccCurrentYearUpdatedCount);
                    return client
                            .execute(String.format(DEFLAG_CURRENT_PY_IS_CURRENT_WEEK_PERFORMANCE, COMMAND_CENTER_TABLE))
                            .bind(PROGRAM_YEAR_STR, programYear)
                            .bind(UPDATED_BY_STR, JobName.RUN_WEEKLY_JOBS.getValue())
                            .fetch()
                            .rowsUpdated()
                            .map(count -> ccCurrentYearUpdatedCount + count);
                })

                .flatMap(currentYearUpdatedcount -> {
                    log.debug("updateIsCurretWeekPerformance currentYearUpdatedcount {}", currentYearUpdatedcount);
                    return client
                            .execute(String.format(DEFLAG_PREVIOUS_PY_IS_CURRENT_WEEK_PERFORMANCE, PERFORMANCE_TABLE))
                            .bind(PROGRAM_YEAR_STR, programYear)
                            .bind(UPDATED_BY_STR, JobName.RUN_WEEKLY_JOBS.getValue())
                            .fetch()
                            .rowsUpdated()
                            .flatMap(previousYearUpdatedcount -> {
                                log.debug("updateIsCurretWeekPerformance count (currentYearUpdatedcount + previousYearUpdatedcount):: {}", currentYearUpdatedcount + previousYearUpdatedcount);
                                return Mono.just(currentYearUpdatedcount + previousYearUpdatedcount);
                            });
                })
                .flatMap(weeklyCurrentYearCount -> {
                    log.debug("updateIsCurretWeekPerformance currentYearUpdatedcount {}", weeklyCurrentYearCount);
                    return client
                            .execute(String.format(DEFLAG_PREVIOUS_PY_IS_CURRENT_WEEK_PERFORMANCE, WEEKLY_TABLE))
                            .bind(PROGRAM_YEAR_STR, programYear)
                            .bind(UPDATED_BY_STR, JobName.RUN_WEEKLY_JOBS.getValue())
                            .fetch()
                            .rowsUpdated()
                            .flatMap(previousYearUpdatedcount -> {
                                log.debug("updateIsCurretWeekPerformance count (currentYearUpdatedcount + previousYearUpdatedcount):: {}", weeklyCurrentYearCount + previousYearUpdatedcount);
                                return Mono.just(weeklyCurrentYearCount + previousYearUpdatedcount);
                            });
                })
                .flatMap(weeklyCurrentYearCount -> {
                    log.debug("updateIsCurretWeekPerformance in command center currentYearUpdatedcount {}", weeklyCurrentYearCount);
                    return client
                            .execute(String.format(DEFLAG_PREVIOUS_PY_IS_CURRENT_WEEK_PERFORMANCE, COMMAND_CENTER_TABLE))
                            .bind(PROGRAM_YEAR_STR, programYear)
                            .bind(UPDATED_BY_STR, JobName.RUN_WEEKLY_JOBS.getValue())
                            .fetch()
                            .rowsUpdated()
                            .flatMap(previousYearUpdatedcount -> {
                                log.debug("updateIsCurretWeekPerformance in command center count (currentYearUpdatedcount + previousYearUpdatedcount):: {}", weeklyCurrentYearCount + previousYearUpdatedcount);
                                return Mono.just(weeklyCurrentYearCount + previousYearUpdatedcount);
                            });
                });
    }

    @Override
    public Mono<Integer> resetProviderGroupExtendedIsActionSent() {
        log.info(" resetProviderGroupExtendedIsActionSent has started");
        return client.execute(RESET_IS_ACTION_SENT)
                .fetch()
                .rowsUpdated();
    }

    @Override
    public Mono<Integer> markIsLastWeekOfMonthInCommandCenter(Integer programYear){
        return client
                .execute(UPDATE_IS_LAST_WEEK_OF_MONTH_WITH_ZERO)
                .bind(PROGRAM_YEAR_STR, programYear)
                .bind(UPDATED_BY_STR, JobName.RUN_WEEKLY_JOBS.getValue())
                .fetch()
                .rowsUpdated()
                .flatMap(updateCountOfZero -> {
                    log.debug("markIsLastWeekOfMonthInCommandCenter update count of zero :: {}", updateCountOfZero );
                   return client
                            .execute(UPDATE_IS_LAST_WEEK_OF_MONTH_WITH_ONE)
                            .bind(PROGRAM_YEAR_STR, programYear)
                            .bind(UPDATED_BY_STR, JobName.RUN_WEEKLY_JOBS.getValue())
                            .fetch()
                            .rowsUpdated()
                            .flatMap((updateCountOfOne)-> {
                                log.debug("markIsLastWeekOfMonthInCommandCenter update count of One :: {}",  updateCountOfOne );
                               return client
                                        .execute(UPDATE_IS_LAST_WEEK_OF_MONTH_FOR_CURRENT_WEEK)
                                        .bind(PROGRAM_YEAR_STR, programYear)
                                        .bind(UPDATED_BY_STR, JobName.RUN_WEEKLY_JOBS.getValue())
                                        .fetch()
                                        .rowsUpdated()
                                        .flatMap(updateCount -> {
                                            log.debug("markIsLastWeekOfMonthInCommandCenter count :: {}", updateCountOfZero + updateCountOfOne + updateCount);
                                            return Mono.just(updateCountOfZero + updateCountOfOne + updateCount);
                                        });
                            });
                });
    }
}

