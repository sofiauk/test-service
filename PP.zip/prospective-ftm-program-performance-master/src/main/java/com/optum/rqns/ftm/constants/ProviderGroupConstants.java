package com.optum.rqns.ftm.constants;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public final class ProviderGroupConstants {
    public static final int DB_BATCH_SIZE = 1000;
    public static final String ACTUAL_JOB_DESCRIPTION = "Job to calculate the actual on daily basis.";
    public static final String NEW_PROVIDERGROUP_JOB_DESCRIPTION = "Job to execute new provider group rules";
    public static final String ZERO = "0";
    public static final int BATCH_SIZE = 10000;
    public static final String EXPORT_TIME_FORMAT = "HH:mm";
    public static final String INTERNAL_SERVER = "Internal Server";
    public static final String NO_DATA_WARNING = "No Data Warning";
    public static final String INVALID_DATA_WARNING = "Invalid Data Warning";
    public static final String INVALID_INPUT_PARAMETERS = "Invalid Input Parameter(s)";
    public static final String INVALID_INPUT = "Invalid Input";
    public static final String EMPTY_STR = "";

    private ProviderGroupConstants() {
    }
    //Exports Constants
    public static final String EXPORT_DATE_FORMAT = "MM/dd/yyyy";

    public static final String PERFORMANCE_DATE_FORMAT = "MMMM dd, yyyy";
    public static final String OPPORTUNITY_TYPE = "OPPORTUNITYTYPE";
    public static final String MEMBER_NAME = "MEMBERNAME";
    public static final String CHARTID = "CHARTID";
    public static final String MEMBERID = "MEMBERID";
    public static final String CLIENT = "CLIENT";
    public static final String MEMBER_DOB = "MEMBERDOB";
    public static final String DEPLOY_DATE = "DEPLOYDATE";
    public static final String RETURN_DATE = "RETURNDATE";
    public static final String PROVIDER_NAME = "PROVIDERNAME";
    public static final String IS_SECONDARY_SUBMISSION = "ISSECONDARYSUBMISSION";
    public static final String IS_GA_MET = "ISGAMET";
    public static final String IS_DV_MET = "ISDVMET";
    public static final String IS_C_GAP_MET = "ISCGAPMET";
    public static final String OPPORTUNITY_SUB_TYPE = "OPPORTUNITYREASON";
    public static final String PROVIDER_GROUP_ID = "PROVIDERGROUPID";
    public static final String STATE = "STATE";
    public static final String SERVICE_LEVEL = "SERVICELEVEL";
    public static final String COVER_SHEET_RESPONSE = "COVERSHEETRESPONSE";
    public static final String GAP_STATUS = "GAPSTATUS";
    public static final String GAP_DESC = "GAPDESC";
    public static final String GAP_TYPE = "GAPTYPE";
    public static final String CURRENT_PROGRAM_YEAR = "CurrentProgramYear";
    public static final String PREVIOUS_PROGRAM_YEAR = "PreviousProgramYear";
    public static final String SERVICE_LEVELS = "ServiceLevel";
    public static final String PROJECT_ID_TYPE = "ProgramYearTarget_YE_ProjectID_Type";
    public static final String OVER_ALL_STATUS_IN = "ProgramYearTarget_YE_IN_Overall_Status";
    public static final String OVER_ALL_STATUS_NOT_IN = "ProgramYearTarget_YE_NOTIN_Overall_Status";
    public static final String LOB = "ProgramYearTarget_YE_LOB";
    public static final String OPPORTUNITY_SUB_TYPES = "OpportunitySubType";
    public static final String ELIGIBLE_PROGRAM_TYPE = "EligibleProgramType";
    public static final String CPG = "CPG";
    public static final String TEAMTYPE_QFO = "QFO";
    public static final String WHITE_SPACE = " ";
    public static final String OWNER_UUID = "ownerUuid";
    public static final String RATING = "rating";

    public static final String ID = "id";
    public static final String OPPORTUNITY_PROVIDER_GROUP_ID = "providerGroupID";
    public static final String PROVIDER_GROUP_NAME = "providerGroupName";
    public static final String OPPORTUNITY_STATE = "state";
    public static final String OPPORTUNITY_SERVICE_LEVEL = "serviceLevel";
    public static final String PROGRAM_YEAR = "programYear";
    public static final String MEASURE_ID = "measureId";
    public static final String UPDATED_DATE = "updatedDate";
    public static final String CLIENT_NAME = "clientName";
    public static final String OPPORTUNITY_TYPE_COLUMN = "opportunityType";
    public static final String OPPORTUNITY_SUB_TYPE_COLUMN = "opportunitySubType";
    public static final String OPPORTUNITY_TYPE_POSITION = "opportunityTypePosition";
    public static final String OPPORTUNITY_SUB_TYPE_POSITION = "opportunitySubTypePosition";
    public static final String DISPLAY_TEXT = "displayText";
    public static final String ASSESSMENT_COUNT = "assessmentCount";
    public static final String DEPLOYMENT_COUNT = "deploymentCount";
    public static final String GAP_COUNT = "gapCount";
    public static final String LAST_UPDATED_DATE = "lastUpdatedDate";
    public static final String MASTER_OPPORTUNITY_TYPE = "masterOpportunityType";
    public static final String MASTER_LEVEL_OPPORTUNITY = "MasterLevelOpportunity";
    public static final String MASTER_LEVEL_OPPORTUNITY_POSITION = "MasterLevelOpportunityPosition";
    public static final String MASTER_OPPORTUNITY_TYPE_POSITION = "masterOpportunityTypePosition";
    public static final String TOTAL_ASSESSMENTS_COUNT = "totalAssessmentsCount";
    public static final String TOTAL_GAPS_COUNT = "totalGapsCount";
    public static final String TOTAL_CLIENTS_COUNT = "totalClientsCount";
    public static final String OID = "oid";
    public static final String MEMBERS_TO_ACHIEVE_FIVE_STAR_RATINGS = "membersToAchieveFiveStarRatings";
    public static final String COMPLIANT_MEMBERS = "compliantMembers";
    public static final String DEPLOY_YTD_ACTUAL = "deployYTDActual";
    public static final String RETURN_YTD_ACTUAL = "returnYTDActual";
    public static final String RETURN_YTD_ACTUAL_PERCENTAGE = "retunYTDActualPercentage";
    public static final String RETURN_YTD_TARGET_PERCENTAGE = "returnYTDTargetPercent";
    public static final String LOB_NAME = "lobName";
    public static final String CLIENTNAME = "CLIENTNAME";
    public static final String OPPORTUNITY_LAST_UPDATED_DATE = "OpportunityLastUpdatedDate";
    public static final String REG_EXP_ALPHA_NUMERIC = "^\\s*[\\da-zA-Z][\\da-zA-Z\\s]*$";
    public static final String ALL = "All";
    public static final String COPY_RIGHT_IMG_PATH = "classpath:images/copyright.png";
    public static final String FILTERS_CONSTANTS = "Filters Used, if applicable";
    public static final String REPORT_GENERATED = "Report Generated";
    public static final String RETURNS = "Returns";
    public static final String REJECTS = "Rejects";
    public static final String OUTLIERS = "Outliers";
    public static final String FINANCIAL_INFORMATION = "Financial Information";
    public static final String SECONDARY_SUBMISSIONS = "Secondary Submissions";
    public static final String DISCLAIMER ="The information present reflects previously reported data, and is derived from multiple sources.  The information presented herein is for informational purposes only and is not intended to be used in place of medical diagnosis, treatment, or financial forecasts.  The current ICD-10-CM code classification and the Official Guidelines for Coding and Reporting are the authoritative references for accurate and complete coding. Specific documentation is reflective of the “thought process” of the provider when treating patients. All conditions affecting the care, treatment or management of the patient should be documented with their status and treatment, and coded to the highest level of specificity. Enhanced precision and accuracy in the codes selected is the ultimate goal.  Neither Optum nor its affiliates warrant or represent that the information contained herein is complete, accurate or free from defects.";
    public static final String COPY_RIGHT = " Optum, Inc. All rights reserved. Confidential property of Optum. Do not distribute or reproduce without express permission from Optum. ";
    public static final String DEPLOYMENTS = "Deployments";
    public static final String TEAMTYPE = "TEAMTYPE";

    public static final String PROVIDER_STATE = "state";
    public static final String PROVIDER_GROUPID = "providerGroupID";

    public static final String DERIVED_DEPLOYED = "derivedDeployed";

    public static final String DERIVED_DEPLOYED_SERVICELEVEL = "PSC-B";
    public static final String MEDICAID = "MEDICAID";

    public static final String DEPLOYMENTS_COUNT = "deploymentsCount";
    public static final String RETURNS_COUNT = "returnsCount";
    public static final String RETURNSNETCNA_COUNT = "returnsNetCnaCount";
    public static final String CLIENT_ID = "clientId";
    public static final String ANNUAL_CARE_VISIT_DATE ="AnnualCareVisitDate";
    public static final String CARE_OPPORTUNITY ="CareOpportunity";
    public static final String CARE_OPPORTUNITY_STATUS ="CareOpportunityStatus";
    public static final String CARE_PRIORITY_GROUP ="CarePriorityGroup";
    public static final String GENDER ="Gender";
    public static final String HIGH_PRIORITY_PATIENT ="HighPriorityPatient";
    public static final String HOUSE_CALL_VISIT_DATE ="HouseCallsVisitDate";
    public static final String INCENTIVE_PROGRAM ="IncentiveProgram";
    public static final String INSURANCE_CARRIER ="InsuranceCarrier";
    public static final String PATIENT_CARD_ID ="PatientCardId";
    public static final String PATIENT_DOB ="PatientDOB";
    public static final String PATIENT_FIRST_NAME ="PatientFirstName";
    public static final String PATIENT_LAST_NAME ="PatientLastName";
    public static final String PCP_NI ="pcpNpi";
    public static final String PRIMARY_CARE_PROVIDER_NAME="primaryCareProviderName";
    public static final String DATABASE_LOGIC = "DatabaseLogic";
    public static final String IS_ACTIVE = "IsActive";
    public static final String IS_SUMMARY_AGGREGATION_REQUIRED = "isSummaryAggregationRequired";
    public static final String MASTER_OPPORTUNITY_TYPE_NAME = "MasterOpportunityName";
    public static final String MASTER_OPPORTUNITY_DISPLAY_ORDER = "masterOpportunityDisplayOrder";
    public static final String OPPORTUNITY_NAME = "OpportunityName";
    public static final String OPPORTUNITY_DISPLAY_ORDER = "OpportunityDisplayOrder";
    public static final String SELECT_CLAUSE_CONDITION = "SelectClauseCondition";
    public static final String WHERE_CLAUSE_CONDITION = "WhereClauseCondition";
    public static final String OPPORTUNITY_NAMES = "opportunityNames";
    public static final String MEMBER_INC_PROGRAM_INDICATOR = "MEMBER_INC_PROGRAM_INDICATOR";
    public static final String MEMBER_INC_PROGRAM_INDICATOR_NAME="MemberIncProgramIndicator";
    public static final String CONDITION ="condition";
    public static final String SUSPECT_DETAILS ="suspectDetails";
    public static final String SUSPECT_CONDITION_DATE_ADDED ="suspectConditionDateAdded";
    public static final String DATE_OF_ASSESSMENT ="dateOfAssessment";
    public static final String DISPOSITION ="disposition";
    public static final String SUSPECT_OPEN_GAP_STATUS_VALUES = "SuspectOpenGapStatusValues";
    public static final String TEAM_TYPE = "teamType";
    public static final String CALENDAR_YEAR = "calendarYear";
    public static final String UUID = "uuid";

    public static final String QUALITY_RATINGS_THRESHOLD_1 ="starsThreshold1";
    public static final String QUALITY_RATINGS_THRESHOLD_2 ="starsThreshold2";
    public static final String QUALITY_RATINGS_THRESHOLD_3 ="starsThreshold3";
    public static final String QUALITY_RATINGS_THRESHOLD_4 ="starsThreshold4";
    public static final String QUALITY_RATINGS_THRESHOLD_5 ="starsThreshold5";

    public static final int QUALITY_RATINGS_1 =1;
    public static final int QUALITY_RATINGS_2 =2;
    public static final int QUALITY_RATINGS_3 =3;
    public static final int QUALITY_RATINGS_4 =4;
    public static final int QUALITY_RATINGS_5 =5;

    //QFO

    public static final String OVERALL_STAR_RATING_TARGET = "Overall_Star_Rating_Target";
    public static final String MAP_PCPI_STAR_RATING_TARGET = "MA-PCPi_Star_Rating_Target";
    public static final String PART_D_STAR_RATING_TARGET = "Part_D_Star_Rating_Target";
    public static final String ANNUAL_CARE_VISITS_TARGET = "Annual_Care_Visits_Target";
    public static final String SUSPECT_CONDITIONS_TARGET = "Suspect_Conditions_Target";
    public static final String QFO_RATING_TARGETS = "QFO_RatingTargets";
    public static final String HEALTH_SYSTEM_ID = "HEALTHSYSTEMID";
    public static final String HEALTH_SYSTEM_ID_TYPE = "HEALTHSYSTEMIDTYPE";
    public static final String QFO_ACV_MEMBERINCPROGRAMINDICATOR = "QFO_Acv_MemberIncProgramIndicator";
    public static final String QFO_SUSPECT_MEMBERINCPROGRAMINDICATOR = "QFO_Suspect_MemberIncProgramIndicator";
    public static final String QFO_QUALITY_GAPS_MEMBER_INC_PROGRAM_INDICATOR = "QFO_Quality_Gaps_MemberIncProgramIndicator";
    

    public static final String GNC="GETTING NEEDED CARE";
    public static final String COO="CARE COORDINATION";
    public static final String DPC="DOCTOR PATIENT CONVERSATIONS";

    public static final List<String> RECORD_TYPE_NOT_CHANGE_IN_LIST = Collections.
            unmodifiableList(Collections
                    .singletonList(
                            "DELETED"
                    ));
    public static final List<String> LOBS = Collections.unmodifiableList(
            Arrays.asList("Medicare", "Medicaid", "Commercial")
    );

    public static final String HEALTHSYSTEMID = "healthSystemId";
    public static final String DURATION_VALUE = "durationValue";
    public static final String HEALTH_SYSTEM_NAME = "healthSystemName";
    public static final String NAME = "Name";
    public static final String KEY = "Key";
    public static final String VALUE = "Value";

    public static final String APPLIED_FILTERS = "Applied Filters: ";
    public static final String OPPO_SUB_TYPES  = "Opportunity Sub-type: ";
    public static final String LOBNAME = "Lob Name";
    public static final String PROGRAMYEAR = "Program Year";


}
