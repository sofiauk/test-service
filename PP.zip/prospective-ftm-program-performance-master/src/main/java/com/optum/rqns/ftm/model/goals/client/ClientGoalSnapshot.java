package com.optum.rqns.ftm.model.goals.client;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
//@JsonInclude(JsonInclude.Include.NON_NULL)
public class ClientGoalSnapshot {
    private long clientId;
    private String clientName;
    private int programYear;
    private SnapshotValues aggregate;
    @JsonProperty("lobs")
    private List<ClientLobSnapshot> clientLobSnapshotValues;
}
