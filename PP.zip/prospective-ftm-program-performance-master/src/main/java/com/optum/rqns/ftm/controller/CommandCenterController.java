package com.optum.rqns.ftm.controller;

import com.optum.rqns.ftm.customannotation.CustomApiResponse;
import com.optum.rqns.ftm.dto.commandcenter.ClientCPDDTO;
import com.optum.rqns.ftm.dto.commandcenter.DerivedDeploymentDTO;
import com.optum.rqns.ftm.dto.commandcenter.DerivedDeploymentWeeklyDTO;
import com.optum.rqns.ftm.dto.commandcenter.GrowthRateDTO;
import com.optum.rqns.ftm.dto.commandcenter.POCConversionCountsDTO;
import com.optum.rqns.ftm.dto.commandcenter.ReturnRatesDTO;
import com.optum.rqns.ftm.dto.commandcenter.ReturnsNetCNADTO;
import com.optum.rqns.ftm.dto.commandcenter.ReturnsNetCNAWeeklyDTO;
import com.optum.rqns.ftm.enums.TypeEnum;
import com.optum.rqns.ftm.exception.APIErrorCode;
import com.optum.rqns.ftm.exception.ProgramPerformanceException;
import com.optum.rqns.ftm.response.ListResponse;
import com.optum.rqns.ftm.response.commandcenter.DerivedDeploymentResponse;
import com.optum.rqns.ftm.response.commandcenter.DerivedDeploymentWeeklyResponse;
import com.optum.rqns.ftm.response.commandcenter.ProviderGroupClientLobResponse;
import com.optum.rqns.ftm.response.commandcenter.ProviderGroupClientLobWrapper;
import com.optum.rqns.ftm.response.commandcenter.ReturnsNetCNAResponse;
import com.optum.rqns.ftm.response.commandcenter.ReturnsNetCNAWeeklyResponse;
import com.optum.rqns.ftm.service.commandcenter.CommandCenterService;
import com.optum.rqns.ftm.util.StargateStandardResponseUtilV2;
import com.optum.rqns.ftm.wrapper.GenericWrapper;
import com.optum.rqns.ftm.wrapper.Pagination;
import com.optum.rqns.ftm.wrapper.SingleResponseWrapper;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;
import java.util.Arrays;
import java.util.List;


@Profile("rqnsFtmApi")
@RestController
@RequestMapping("/v1/command-center")
@Slf4j
@CustomApiResponse
public class CommandCenterController {

    @Autowired
    private CommandCenterService commandCenterService;
    @Autowired
    StargateStandardResponseUtilV2<Object, Object> stargateStandardResponseUtilV2;

    private static final List<String> VALID_BY_TYPES = Arrays.asList("ClientName", "LobName", "Region");

    @GetMapping("/provider-groups/return-rates/{program-year}")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = ReturnRatesDTO.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<SingleResponseWrapper<ReturnRatesDTO>> getProviderGroupsReturnRates(@PathVariable("program-year") int programYear) {
        log.info("Getting Provider Group Return Rates for program year {}", programYear);

        return commandCenterService.getReturnRates(programYear).flatMap(t -> Mono.just(new SingleResponseWrapper<>(t)));
    }

    @GetMapping("/provider-groups/poc-conversion-counts/{program-year}")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = POCConversionCountsDTO.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<SingleResponseWrapper<POCConversionCountsDTO>> getProviderGroupsPOCConversion(@PathVariable("program-year") int programYear) {
        log.info("Getting Provider Group Counts for POC Conversion for program year {}", programYear);

        return commandCenterService.getPOCConversionCounts(programYear).flatMap(t -> Mono.just(new SingleResponseWrapper<>(t)));
    }

    @GetMapping("/provider-groups/derived-deployments/{program-year}/{by-type}")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = DerivedDeploymentDTO.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<DerivedDeploymentResponse> getProviderGroupsDerivedDeployments(@PathVariable("program-year") int programYear,
                                                                    @PathVariable("by-type") String byType,
                                                                    @RequestParam("start") int start,
                                                                    @RequestParam("count") int count,
                                                                    @RequestParam(value = "name", required = false) String name) {
        log.info("Getting Derived Deployments Counts for program year {}, by type {}, and name {}", programYear, byType, name);

        DerivedDeploymentResponse derivedDeploymentResponse = new DerivedDeploymentResponse();

        if (!VALID_BY_TYPES.contains(byType)) {
            return stargateStandardResponseUtilV2.generateStargateStandardResponse(
                    Mono.error(new ProgramPerformanceException(HttpStatus.OK, APIErrorCode.INVALID_BY_TYPE)), TypeEnum.MONO, derivedDeploymentResponse)
                    .cast(DerivedDeploymentResponse.class);
        }

        Pagination pagination = new Pagination();

        return stargateStandardResponseUtilV2.generateStargateStandardResponse(
                    commandCenterService.getDerivedDeployments(programYear, byType, name, start, count), TypeEnum.FLUX, derivedDeploymentResponse)
                .cast(DerivedDeploymentResponse.class)
                .flatMap(derivedDeploymentResponseGenerated ->
                        commandCenterService.getDerivedDeploymentOrReturnsNetCNATotalCount(programYear, byType, name)
                                .doOnNext(derivedDeploymentTotalCount -> {
                                    pagination.setTotalResults(derivedDeploymentTotalCount);
                                    pagination.setOffset(start);
                                    pagination.setLimit(count);
                                    pagination.setTotalPageCount(derivedDeploymentTotalCount % count == 0 ?
                                            (derivedDeploymentTotalCount / count) : (derivedDeploymentTotalCount / count) + 1);
                                    derivedDeploymentResponseGenerated.getMeta().setPagination(pagination);
                                }).then(Mono.just(derivedDeploymentResponseGenerated))
                );
    }

    @GetMapping("/provider-groups/returns-net-cna/{program-year}/{by-type}")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = ReturnsNetCNADTO.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<ReturnsNetCNAResponse> getProviderGroupsReturnsNetCNA(@PathVariable("program-year") int programYear,
                                                                      @PathVariable("by-type") String byType,
                                                                      @RequestParam("start") int start,
                                                                      @RequestParam("count") int count,
                                                                      @RequestParam(value = "name", required = false) String name) {
        log.info("Getting Returns Net CNA Counts for program year {}, by type {}, and name {}", programYear, byType, name);

        ReturnsNetCNAResponse returnsNetCNAResponse = new ReturnsNetCNAResponse();

        if (!VALID_BY_TYPES.contains(byType)) {
            return stargateStandardResponseUtilV2.generateStargateStandardResponse(
                    Mono.error(new ProgramPerformanceException(HttpStatus.OK, APIErrorCode.INVALID_BY_TYPE)), TypeEnum.MONO, returnsNetCNAResponse)
                    .cast(ReturnsNetCNAResponse.class);
        }

        Pagination pagination = new Pagination();

        return stargateStandardResponseUtilV2.generateStargateStandardResponse(
                commandCenterService.getReturnsNetCNA(programYear, byType, name, start, count), TypeEnum.FLUX, returnsNetCNAResponse)
                .cast(ReturnsNetCNAResponse.class)
                .flatMap(returnsNetCNAResponseGenerated ->
                        commandCenterService.getDerivedDeploymentOrReturnsNetCNATotalCount(programYear, byType, name)
                                .doOnNext(returnsNetCNATotalCount -> {
                                    pagination.setTotalResults(returnsNetCNATotalCount);
                                    pagination.setOffset(start);
                                    pagination.setLimit(count);
                                    pagination.setTotalPageCount(returnsNetCNATotalCount % count == 0 ?
                                            (returnsNetCNATotalCount / count) : (returnsNetCNATotalCount / count) + 1);
                                    returnsNetCNAResponseGenerated.getMeta().setPagination(pagination);
                                }).then(Mono.just(returnsNetCNAResponseGenerated))
                );
    }

    @GetMapping("/cpd/{client-name}")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = ClientCPDDTO.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<SingleResponseWrapper<ClientCPDDTO>> getCPDOfClient(@PathVariable("client-name") String clientName) {
        log.info("Getting the CPD of the client name {}", clientName);

        return commandCenterService.getCPDOfClient(clientName).flatMap(t -> Mono.just(new SingleResponseWrapper<>(t)));
    }

    @GetMapping("/provider-groups/growth-rates/{program-year}")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = GrowthRateDTO.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<GenericWrapper> getProviderGroupsGrowthRates(@PathVariable("program-year") int programYear, @RequestParam("month") String month) {
        log.info("Getting Provider Group Growth Rates for program year {} and month {}", programYear, month);

        return stargateStandardResponseUtilV2.generateStargateStandardResponse(
                commandCenterService.getGrowthRate(programYear, month), TypeEnum.MONO, new GenericWrapper())
                .cast(GenericWrapper.class);
    }

    @GetMapping("/clients-members-count")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = ProviderGroupClientLobResponse.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<ProviderGroupClientLobResponse> getProviderGroupClientMembersCountData(
            @RequestParam("provider-group-id" ) String providerGroupId,
            @RequestParam("state" ) String state, @RequestParam("program-year") String programYear
    ) {
        log.info("Getting  getProviderGroupClientLobData   providerGroupId::{}, state::{}, programyear :: {} ", providerGroupId,state,programYear);
        return commandCenterService.getProviderGroupClientMemberCountData(providerGroupId,state,programYear).flatMap(providerGroupClientMembersCountDtos -> {
            return stargateStandardResponseUtilV2
                    .generateStargateStandardResponse(
                          Mono.just(new ProviderGroupClientLobResponse(null,new ProviderGroupClientLobWrapper(providerGroupClientMembersCountDtos,null)))
                            , TypeEnum.MONO
                            , new ProviderGroupClientLobResponse())
                    .cast(ProviderGroupClientLobResponse.class)
                    .flatMap(providerGroupClientLobResponse -> {
                        return     commandCenterService.getClientsLastUpdatedDate().flatMap(lastupdate -> {
                            providerGroupClientLobResponse.getData().setProviderGroupClientMembers(providerGroupClientMembersCountDtos);
                            providerGroupClientLobResponse.getData().setLastUpdateDate(lastupdate);
                            return Mono.just(providerGroupClientLobResponse);
                        });
                    });
        });

    }

    @PostMapping("/target-growth-rates/{program-year}")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = SingleResponseWrapper.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<SingleResponseWrapper<Integer>> calculateCCTargetGrowthRates( @PathVariable("program-year") String programYear
    ) {
        log.info("Getting  calculateCCTargetGrowthRates  programyear :: {} ", programYear);
        return commandCenterService.calculateCCTargetGrowthRates(Integer.parseInt(programYear)).flatMap(t -> Mono.just(new SingleResponseWrapper<Integer>(t)));

    }


    @GetMapping("/derived-deployments/weekly-counts/{program-year}")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content=@Content(schema = @Schema(implementation = DerivedDeploymentWeeklyDTO.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<DerivedDeploymentWeeklyResponse> getDerivedDeploymentsWeeklyCounts(
            @PathVariable("program-year") int programYear,
            @RequestParam("regions") List<String> regions,
            @RequestParam("states") List<String> states,
            @RequestParam("lobs") List<String> lobs,
            @RequestParam("clients") List<String> clients) {
        DerivedDeploymentWeeklyResponse derivedDeploymentResponse = new DerivedDeploymentWeeklyResponse();
        return stargateStandardResponseUtilV2.generateStargateStandardResponse(
                commandCenterService.getDerivedDeploymentWeeklyCounts(programYear, regions, states, lobs, clients),
                TypeEnum.FLUX, derivedDeploymentResponse).cast(DerivedDeploymentWeeklyResponse.class);
    }

    @GetMapping("/derived-deployments/weekly-goals/{program-year}")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content=@Content(schema = @Schema(implementation = DerivedDeploymentWeeklyDTO.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<DerivedDeploymentWeeklyResponse> getDerivedDeploymentsWeeklyGoals(
            @PathVariable("program-year") int programYear,
            @RequestParam("regions") List<String> regions,
            @RequestParam("states") List<String> states,
            @RequestParam("lobs") List<String> lobs,
            @RequestParam("clients") List<String> clients) {
        DerivedDeploymentWeeklyResponse derivedDeploymentResponse = new DerivedDeploymentWeeklyResponse();
        return stargateStandardResponseUtilV2.generateStargateStandardResponse(
                commandCenterService.getDerivedDeploymentWeeklyGoals(programYear, regions, states, lobs, clients),
                TypeEnum.FLUX, derivedDeploymentResponse).cast(DerivedDeploymentWeeklyResponse.class);
    }

    @GetMapping("/returns-net-cna/weekly-counts/{program-year}")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content=@Content(schema = @Schema(implementation = ReturnsNetCNAWeeklyDTO.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<ReturnsNetCNAWeeklyResponse> getReturnsNetCnaWeeklyCounts(
            @PathVariable("program-year") int programYear,
            @RequestParam("regions") List<String> regions,
            @RequestParam("states") List<String> states,
            @RequestParam("lobs") List<String> lobs,
            @RequestParam("clients") List<String> clients) {
        ReturnsNetCNAWeeklyResponse returnsNetCNAResponse = new ReturnsNetCNAWeeklyResponse();
        return stargateStandardResponseUtilV2.generateStargateStandardResponse(
                commandCenterService.getReturnsNetCnaWeeklyCounts(programYear, regions, states, lobs, clients),
                TypeEnum.FLUX, returnsNetCNAResponse).cast(ReturnsNetCNAWeeklyResponse.class);
    }

    @GetMapping("/returns-net-cna/weekly-goals/{program-year}")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content=@Content(schema = @Schema(implementation = ReturnsNetCNAWeeklyDTO.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<ReturnsNetCNAWeeklyResponse> getReturnsNetCnaWeeklyGoals(
            @PathVariable("program-year") int programYear,
            @RequestParam("regions") List<String> regions,
            @RequestParam("states") List<String> states,
            @RequestParam("lobs") List<String> lobs,
            @RequestParam("clients") List<String> clients) {
        ReturnsNetCNAWeeklyResponse returnsNetCNAResponse = new ReturnsNetCNAWeeklyResponse();
        return stargateStandardResponseUtilV2.generateStargateStandardResponse(
                commandCenterService.getReturnsNetCnaWeeklyGoals(programYear, regions, states, lobs, clients),
                TypeEnum.FLUX, returnsNetCNAResponse).cast(ReturnsNetCNAWeeklyResponse.class);
    }

    @GetMapping("/clients")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content=@Content(schema = @Schema(implementation = ReturnsNetCNAWeeklyDTO.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<ListResponse<String>> getClients() {
        return stargateStandardResponseUtilV2.generateStargateStandardResponse(
                commandCenterService.getClients(), TypeEnum.FLUX, new ListResponse<>())
                .cast(ListResponse.class).map(listResponse -> (ListResponse<String>) listResponse);
    }
 }
