package com.optum.rqns.ftm.repository.providergrp;

import com.optum.rqns.ftm.dto.providergrp.MembershipStatsIhaIoaDTO;
import com.optum.rqns.ftm.dto.providergrp.ProviderGroupDTO;
import com.optum.rqns.ftm.dto.providergrp.ProviderGroupDetailsDTO;
import com.optum.rqns.ftm.enums.ServiceLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.springframework.data.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@Repository
public class ProviderGroupDetailsRepositoryImpl implements ProviderGroupDetailsRepository {
    private final DatabaseClient databaseClient;
    private static final List<String> ownerTypes = Collections.unmodifiableList(Arrays.asList("HCA", "PSC"));

    public ProviderGroupDetailsRepositoryImpl(DatabaseClient databaseClient) {
        this.databaseClient = databaseClient;
    }

    @AllArgsConstructor
    @Getter
    public enum ColumnNames {
        PROVIDER_GROUP_ID("ProviderGroupId"), STATE("State"), PROGRAMYEAR("programYear"),
        PROVIDER_GROUP_NAME("ProviderGroupName"), SERVICE_LEVEL("ServiceLevel"),
        TAX_ID("TaxId"), LAST_ACTIVITY_DATE("LastActivityDate"),
        IS_NEW_FOR_DEPLOYMENT("IsNewForDeployment"), OWNER_TYPE("OwnerType"), OWNER_NAME("OwnerName"),
        DURATION_END_DATE("DurationEndDate"),PSC_ENGAGEMENT_ON_SHORE("PscEngagementOnshore"),
        CAN_SHOW_PSC_OWNER("canShowPSCOwner"),
        ELIGIBLE_PREFERRED_MEMBERS("EligiblePreferredMembers"), LEADER_UUID("LeaderUuid");
        private String columnName;
    }

    private static final String PROVIDER_GROUP_QUERY = "select PG.ProviderGroupId, PG.State, PG.IsNewForDeployment, PG.EligiblePreferredMembers, PG.ProgramYear as programYear from ProgPerf.ProviderGroupExtended PG WHERE PG.ProgramYear = (select mc.value from ProgPerf.MasterConfiguration mc WITH (NOLOCK) where mc.code='CurrentProgramYear')";

    public static final String UPDATE_PROVIDER_GROUP_ISNEW = "UPDATE ProgPerf.ProviderGroup SET IsNewForDeployment = '%s' WHERE ProviderGroupId = '%s' AND state = '%s'";

    public static final String UPDATE_PROVIDER_GROUP_EXTENDED_ISNEW = "UPDATE ProgPerf.ProviderGroupExtended SET IsNewForDeployment = '%s' WHERE ProviderGroupId = '%s' AND state = '%s' AND ProgramYear = '%s'";

    private static final String PROVIDER_GROUP_DETAILS = "select PG.ProviderGroupId,PG.TaxId,PG.ProviderGroupName,PG.State " +
            ",a.accountId,A.ServiceLevel,A.LastActivityDate, PG.IsNewForDeployment" +
            " ,AO.OwnerType,AO.OwnerName, PG.PscEngagementOnshore " +
            " ,(case when :ServiceLevel = 'PSC-P' then 1" +
            "        when :ServiceLevel = 'PSC-B' and (ISNULL(pg.DerivedDeployedCount,0) + ISNULL(pg.PreviousYearDerivedDeployedCount,0)) > 0 then 1" +
            "  else 0 end) as canShowPSCOwner" +
            " from ProgPerf.ProviderGroup PG " +
            " left join ProgPerf.Accounts A on PG.ProviderGroupID =A.GroupId  and PG.State =A.State " +
            "    and A.ServiceLevel  =:ServiceLevel and A.GroupId = :ProviderGroupId and A.state = :State " +
            " left join ProgPerf.AccountOwner AO on AO.AccountId=a.AccountId and OwnerType in (:OwnerType) " +
            " where PG.ProviderGroupID = :ProviderGroupId and pg.State = :State ";

    private static final String CHECK_PROVIDERGROUP_ASSIGEND_TO_USER = "WITH cte_org AS ( SELECT    UUID, PersonnelHierarchyId, ParentID  FROM ProgPerf.PersonnelHierarchy  WHERE ParentID = (SELECT top 1  PersonnelHierarchyId from ProgPerf.PersonnelHierarchy where uuid = :LeaderUuid)  " +
            "UNION ALL SELECT  e.UUID, e.PersonnelHierarchyId, e.ParentID  FROM ProgPerf.PersonnelHierarchy e INNER JOIN cte_org o  ON o.PersonnelHierarchyId = e.ParentId ) , parent_ids as (SELECT DISTINCT ParentID from ProgPerf.PersonnelHierarchy ph where ph.ParentID is not null)   " +
            "SELECT DISTINCT a.GroupId from ProgPerf.AccountOwner ao  with (nolock) join ProgPerf.Accounts a on a.AccountId = ao.AccountId  " +
            " where (ao.OwnerUUID in( SELECT co.UUID FROM cte_org co WHERE co.PersonnelHierarchyId NOT IN (select ParentID from parent_ids)) or ao.OwnerUUID = :LeaderUuid) and a.GroupId=:ProviderGroupId and a.State=:State and a.ServiceLevel=:ServiceLevel " ;


    private static final String GET_MEMBERSHIP_CHANGE_STAT_FOR_IHA_AND_IOA =
            " SELECT ProviderGroupID, [State], ProgramYear " +
                    " , SUM(ISNULL(MemberIHACount, 0)) AS IHAOnlyCount " +
                    " , SUM(ISNULL(MemberIOACount, 0)) AS IOAOnlyCount " +
                    " , SUM(ISNULL(MemberIOAIHACount, 0)) AS BothIHAIOACount " +
                    " , SUM(ISNULL(MemberChangedFromIHACount, 0)) AS MemberChangeCount " +
                    " , MAX(MemberIOAIHALastUpdatedDate) AS LatestMemberMoveDate " +
                    " FROM ProgPerf.ProviderGroupPerformanceWeekly WITH (NOLOCK) " +
                    " WHERE ProviderGroupID = :PROVIDER_GROUP_ID " +
                    " AND [State] = :PROVIDER_STATE " +
                    " AND DurationValue = :DURATION_VALUE " +
                    " %s " + //Filter by clientName if client name list provided // " AND ClientName IN (:CLIENT_NAME_LIST) " +
                    " %s " + //Filter by LOBName if LOB name list provided // " AND LobName IN (:LOB_NAME_LIST) " +
                    " GROUP BY ProviderGroupID, [State], ProgramYear; ";
    private static final String CLIENT_NAME_FILTER_CLAUSE = " AND ClientName IN (:CLIENT_NAME_LIST) ";
    private static final String LOB_NAME_FILTER_CLAUSE = " AND LobName IN (:LOB_NAME_LIST) ";

    @Override
    public Flux<ProviderGroupDetailsDTO> getProviderGroupDetails(String providerGroupId, String state, String serviceLevel) {
        return databaseClient.execute(PROVIDER_GROUP_DETAILS)
                .bind(ColumnNames.SERVICE_LEVEL.getColumnName(), serviceLevel)
                .bind(ColumnNames.PROVIDER_GROUP_ID.getColumnName(), providerGroupId)
                .bind(ColumnNames.STATE.getColumnName(), state)
                .bind(ColumnNames.OWNER_TYPE.getColumnName(),ownerTypes)
                .as(ProviderGroupDetailsDTO.class)
                .fetch()
                .all();
    }

    @Override
    public Flux<ProviderGroupDTO> getProviderGroupDetails() {
        return databaseClient.execute(PROVIDER_GROUP_QUERY)
                .as(ProviderGroupDTO.class)
                .fetch()
                .all();
    }

    @Override
    public Mono<String> checkProviderGroupDetails(String providerGroupId, String state, String serviceLevel, String uuid) {
        return databaseClient.execute(CHECK_PROVIDERGROUP_ASSIGEND_TO_USER)
                .bind(ColumnNames.SERVICE_LEVEL.getColumnName(), ServiceLevel.getPerformanceMSServiceLevel(serviceLevel))
                .bind(ColumnNames.PROVIDER_GROUP_ID.getColumnName(), providerGroupId)
                .bind(ColumnNames.STATE.getColumnName(), state)
                .bind(ColumnNames.LEADER_UUID.getColumnName(),uuid)
                .as(String.class)
                .fetch()
                .first();
    }

    @Override
    public Mono<MembershipStatsIhaIoaDTO> getIhaIoaMembershipStats(String providerGroupId, String providerState, String durationValue,
                                                                   List<String> clientNameList, List<String> lobNameList) {
        String membershipChangeQuery = String.format (GET_MEMBERSHIP_CHANGE_STAT_FOR_IHA_AND_IOA,
                (clientNameList.size () > 0 ? CLIENT_NAME_FILTER_CLAUSE : ""),
                (lobNameList.size () > 0 ? LOB_NAME_FILTER_CLAUSE : ""));

        DatabaseClient.GenericExecuteSpec genExecSpec = databaseClient.execute (membershipChangeQuery)
                .bind ("PROVIDER_GROUP_ID", providerGroupId)
                .bind ("PROVIDER_STATE", providerState)
                .bind ("DURATION_VALUE", durationValue);
        if (clientNameList.size () > 0) {
            genExecSpec = genExecSpec.bind ("CLIENT_NAME_LIST", clientNameList);
        }
        if (lobNameList.size () > 0) {
            genExecSpec = genExecSpec.bind ("LOB_NAME_LIST", lobNameList);
        }

        return genExecSpec.as (MembershipStatsIhaIoaDTO.class)
                .fetch ()
                .one ();
    }

}
