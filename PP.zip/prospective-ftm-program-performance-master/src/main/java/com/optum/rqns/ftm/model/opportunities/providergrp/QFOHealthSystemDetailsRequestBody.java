package com.optum.rqns.ftm.model.opportunities.providergrp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.Set;

@AllArgsConstructor
@NoArgsConstructor
@Data
@ToString
@Builder
public class QFOHealthSystemDetailsRequestBody {
    private String healthSystemId;
    private int programYear;
    private Set<String> lobs;
    private Set<String> opportunityTypes;
    private String teamType;
}

