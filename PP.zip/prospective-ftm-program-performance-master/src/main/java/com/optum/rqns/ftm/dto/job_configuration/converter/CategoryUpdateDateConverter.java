package com.optum.rqns.ftm.dto.job_configuration.converter;

import com.optum.rqns.ftm.constants.JobConfigurationConstants;
import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.dto.job_configuration.CategoryUpdatedDetailDTO;
import com.optum.rqns.ftm.dto.job_configuration.PafOverAllStatusDetailDTO;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;

import java.time.LocalDateTime;

public class CategoryUpdateDateConverter implements Converter<Row, CategoryUpdatedDetailDTO>, DTOWrapperTypeConverter {

    @Override
    public CategoryUpdatedDetailDTO convert(Row rs) {

        return CategoryUpdatedDetailDTO.builder()
                .category(rs.get(JobConfigurationConstants.CATEGORY, String.class))
                .updateDate(rs.get(JobConfigurationConstants.UPDATED_DATE, LocalDateTime.class))
                .build();
    }
}


