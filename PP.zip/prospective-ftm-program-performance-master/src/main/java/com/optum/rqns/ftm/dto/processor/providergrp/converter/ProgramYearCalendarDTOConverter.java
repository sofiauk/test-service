package com.optum.rqns.ftm.dto.processor.providergrp.converter;

import com.optum.rqns.ftm.dto.processor.providergrp.ProgramYearCalendarDTO;
import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.repository.processor.providergrp.ProviderGroupHistoricalYTDActualProcessorRepositoryImpl;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Objects;

public class ProgramYearCalendarDTOConverter implements Converter<Row, ProgramYearCalendarDTO>, DTOWrapperTypeConverter {
    @Override
    public ProgramYearCalendarDTO convert(Row row) {

        return ProgramYearCalendarDTO.builder()
                .id(getLongValue(row,ProviderGroupHistoricalYTDActualProcessorRepositoryImpl.ColumnNames.ID.getColumnName()))
                .endDate(row.get(ProviderGroupHistoricalYTDActualProcessorRepositoryImpl.ColumnNames.END_DATE.getColumnName(),LocalDate.class))
                .durationType(row.get(ProviderGroupHistoricalYTDActualProcessorRepositoryImpl.ColumnNames.DURATION_TYPE.getColumnName(),String.class))
                .startDate(row.get(ProviderGroupHistoricalYTDActualProcessorRepositoryImpl.ColumnNames.START_DATE.getColumnName(),LocalDate.class))
                .programYear(row.get(ProviderGroupHistoricalYTDActualProcessorRepositoryImpl.ColumnNames.PROGRAM_YEAR.getColumnName(),Integer.class))
                .durationValue(row.get(ProviderGroupHistoricalYTDActualProcessorRepositoryImpl.ColumnNames.DURATION_VALUE.getColumnName(),String.class))
                .build();

    }


}