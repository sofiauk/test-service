package com.optum.rqns.ftm.configuration;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.enums.SecuritySchemeType;
import io.swagger.v3.oas.annotations.extensions.Extension;
import io.swagger.v3.oas.annotations.extensions.ExtensionProperty;
import io.swagger.v3.oas.annotations.info.Contact;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.security.OAuthFlow;
import io.swagger.v3.oas.annotations.security.OAuthFlows;
import io.swagger.v3.oas.annotations.security.SecurityScheme;

//TODO: NEED TO CHANGE BELOW INFO
@OpenAPIDefinition(
        info = @Info(
                title = "Field Tool Modernization Program Performance Application",
                version = "1.0",
                description = "Field Tool Modernization Program Performance Application",
                termsOfService = "https://www.optumdeveloper.com/content/odv-optumdev/optum-developer/en/legal-terms/terms-of-use.html",
                contact = @Contact(
                        name = "test",
                        email = "test@ds.uhc.com"
                )
        ),
        extensions = {
                @Extension(properties = {
                        @ExtensionProperty(name = "x-domain", value = "provider"),
                        @ExtensionProperty(name = "x-namespace", value = "ftm-prog-perf"),
                }),
                @Extension(name = "x-serviceLevelObjectives", properties = {
                        @ExtensionProperty(name = "x-availability", value = "99.98"),
                        @ExtensionProperty(name = "x-expectedMsgsPerDay", value = "10000"),
                        @ExtensionProperty(name = "x-maxMsgsPerHour", value = "100"),
                        @ExtensionProperty(name = "x-responseTime", value = "5000"),
                        @ExtensionProperty(name = "x-throughput", value = "2"),
                        @ExtensionProperty(name = "x-maxPayloadSize", value = "25")
                })
        }
)
@SecurityScheme(name = "oauth2", type = SecuritySchemeType.OAUTH2,
        description = "This API uses OAuth 2",
        flows = @OAuthFlows(clientCredentials = @OAuthFlow(tokenUrl = "https://gateway-stage-core.optum.com/auth/oauth2/cached/token")))
public class OpenApiConfig {
}