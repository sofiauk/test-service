package com.optum.rqns.ftm.dto.job_configuration;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class JobConfigurationRequestBody {
    @NotNull
    private String jobName;
    private Boolean isActive;
    private LocalDateTime lastSuccessfulRunDate;
}
