package com.optum.rqns.ftm.dto.performance.providergrp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@Builder
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class ProviderGroupPerformanceYTDGraphDTO {
    private int year;
    private Long returnYTDActual;
    private Long returnYETarget;
    private Long eligibleMemberCount;
    private Long deployYETarget;
    private Long deployYTDTarget;
    private Long returnYTDTarget;
    private Long deployYTDActual;
    private Long returnedNetCnaActual;
    private String month;
    private String durationValue;
    LocalDate startDate;
    LocalDate endDate;
}
