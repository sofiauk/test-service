package com.optum.rqns.ftm.controller;

import com.optum.rqns.ftm.customannotation.CustomApiResponse;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.service.processor.providergrp.ProviderGroupsDeploymentService;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

import java.time.Instant;

@Profile("rqnsFtmApi")
@RestController
@RequestMapping("/v1/provider-groups/derived-deployments")
@Slf4j
@CustomApiResponse
public class ProviderGroupsDeploymentController {

    @Autowired
    ProviderGroupsDeploymentService providerGroupsDeploymentService;

    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = String.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    @GetMapping()
    public Mono<String> getProviderGroupsDeployment(@RequestParam("mode-of-run") String modeOfRun) {

        JobEvent jobEvent = new JobEvent ();
        jobEvent.setProgramYear (2020);
        jobEvent.setJobName (JobName.RUN_PROVIDERGROUPS_DEPLOYMENTS.getValue ());
        jobEvent.setGroupsToExecute (modeOfRun);
        jobEvent.setExecutionWeek ("Current");
        jobEvent.setTimeStamp (Instant.now ());
        jobEvent.setStatus ("Complete");

        log.info ("Started getting Provider Groups Deployments for : {}", modeOfRun);
        /**** old topic **/
        //   return providerGroupsDeploymentService.getProviderGroupsDeployment(jobEvent);
        return providerGroupsDeploymentService.getDeploymentDetailsFluxWithCTE (jobEvent)
                .map (response -> response.getMessage ());
    }
}
