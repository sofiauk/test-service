package com.optum.rqns.ftm.repository.providergrp;

import com.optum.rqns.ftm.dto.providergrp.MembershipStatsIhaIoaDTO;
import com.optum.rqns.ftm.dto.providergrp.ProviderGroupDTO;
import com.optum.rqns.ftm.dto.providergrp.ProviderGroupDetailsDTO;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;

public interface ProviderGroupDetailsRepository {
    Flux<ProviderGroupDetailsDTO> getProviderGroupDetails(String providerGroupId, String state, String serviceLevel);

    Flux<ProviderGroupDTO> getProviderGroupDetails();

    Mono<String> checkProviderGroupDetails(String providerGroupId, String state, String serviceLevel, String uuid);

    Mono<MembershipStatsIhaIoaDTO> getIhaIoaMembershipStats(String providerGroupId, String providerState, String durationValue,
                                                            List<String> clientNameList, List<String> lobNameList);
}
