package com.optum.rqns.ftm.response.performance.providergrp.qfo;

import com.optum.rqns.ftm.dto.performance.providergrp.qfo.QFOProviderGroupPerformanceDetailsDTO;
import com.optum.rqns.ftm.wrapper.Meta;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class ProviderGroupPerformanceDetailsByYearResponse {
    private Meta meta;

    private List<QFOProviderGroupPerformanceDetailsDTO> data;

    public ProviderGroupPerformanceDetailsByYearResponse() {
        this.meta = new Meta();
        this.data = new ArrayList<>();
    }
}
