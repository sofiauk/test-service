package com.optum.rqns.ftm.repository.processor.providergrp;

import com.optum.rqns.ftm.constants.ProviderGroupConstants;
import com.optum.rqns.ftm.dto.processor.providergrp.ProgramYearCalendarDTO;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.util.ProgramPerformanceUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Objects;

import static com.optum.rqns.ftm.constants.ProviderGroupConstants.ALL;
import static com.optum.rqns.ftm.constants.ProviderGroupConstants.RECORD_TYPE_NOT_CHANGE_IN_LIST;


@Slf4j
@Repository
public class ProviderGroupHistoricalYTDActualProcessorRepositoryImpl implements ProviderGroupHistoricalYTDActualProcessorRepository {

    private DatabaseClient databaseClient;
    private static final String EMPTY_STRING = "";
    public static final String LOB = "Lob";
    public static final String SERVICE_LEVEL = "ServiceLevel";
    private static final String HISTORICAL_ACTUAL_JOB_NAME = "HistoricalActualJobName";
    private static final String RECORD_TYPE_NOT_CHANGE_IN = "recordChangeTypeNotIn";


    @Autowired
    public ProviderGroupHistoricalYTDActualProcessorRepositoryImpl(DatabaseClient databaseClient) {
        this.databaseClient = databaseClient;
    }

    public enum ColumnNames {
        DURATION_VALUE("DurationValue"), START_DATE("StartDate"), END_DATE("EndDate"),
        DURATION_TYPE("DurationType"), PROGRAM_YEAR("ProgramYear"), ID("ID"),
        PROVIDER_GROUP_ID("ProviderGroupID"), STATE("State"),
        PROVIDER_GROUP_NAME("ProviderGroupName"), SERVICE_LEVEL("ServiceLevel"),
        LOB_NAME("LobName"), CLIENT_NAME("ClientName"),
        DEPLOY_YTD_ACTUAL("DeployYTDActual"),RETURN_YTD_ACTUAL("ReturnYTDActual"), RETURN_CNA_ACTUAL("ReturnedNetCnaYtdActual"),
        CURRENT_WEEK_DEPLOYMENTS("CurrentWeekDeploymentsCount"),PREV_WEEK_DEPLOYMENTS("PreviousWeekDeploymentsCount"),
        CUURENT_WEEK_RETURNS("CurrentWeekReturnsCount"),PREV_WEEK_RETURNS("PreviousWeekReturnsCount");

        private String columnName;

        ColumnNames(String columnName) {
            this.columnName = columnName;
        }

        public String getColumnName() {
            return this.columnName;
        }
    }

    private static final String SELECT_PROGRAM_YEARS = " select  pyc.ProgramYear,  pyc.DurationValue ,pyc.StartDate ,pyc.EndDate, pyc.DurationType, pyc.ID " +
            "from ProgPerf.ProgramYearCalendar pyc WITH (NOLOCK) " +
            "where  pyc.ProgramYear in( :ProgramYear, :ProgramYear-1) " +
            "and pyc.EndDate <= getutcdate() and pyc.DurationType ='WEEK' and pyc.DurationValue " +
            "not in (select t1.DurationValue from (SELECT TOP 1 DurationValue FROM ProgPerf.ProgramYearCalendar " +
            "WITH (NOLOCK) where  DurationType ='WEEK' and  " +
            "ProgramYear = :ProgramYear-1 order by EndDate desc) t1 " +
            "UNION " +
            "SELECT TOP 1 DurationValue FROM ProgPerf.ProgramYearCalendar " +
            "WITH (NOLOCK) where  DurationType ='WEEK' and " +
            "StartDate <= (SELECT CAST( getUTCDate() AS Date )) AND " +
            "EndDate >= (SELECT CAST( getUTCDate() AS Date )) and ProgramYear = :ProgramYear) " +
            "order by pyc.StartDate asc";


    private static final String LAST_UPDATE_QUERY = "SELECT convert(varchar, min(RS.MinDate), 23) as updatedDate " +
            " FROM PROGPERF.JobRunConfiguration JR  With (NOLOCK)" +
            " CROSS APPLY (SELECT MIN(d) AS MinDate FROM (VALUES (JR.LastSuccessfulRunDate), (JR.JobStart)) AS RS(d)) RS" +
            "  WHERE JR.JobName in(" +
            "'" + JobName.LOAD_MEMBER_ASSESSMENT.getValue() + "'" +
            ",'" + JobName.LOAD_HISTORICAL_LOB_TARGET_VALUES_AND_ACTUALS.getValue() + "')";

    private static final String MEMBER_ASSESSMENT_QUERY_FILTER = " and A.UpdatedDate >= (" + LAST_UPDATE_QUERY + ")";


    public static final String PG_PERFORMANCE_UPDATED_MERGE_QUERY =
            "MERGE INTO ProgPerf.ProviderGroupPerformance AS pgp  " +
            "USING ( " +
            " SELECT ProviderGroupID,State,ClientName,ServiceLevel,LobName,ProgramYear,DurationValue," +
                    " sum(DeployYTDActual) as DeployYTDActual,sum(ReturnYTDActual) as ReturnYTDActual, sum(ReturnedNetCna) as ReturnedNetCna" +
                    " from (" +
                    "  SELECT  " +
                    "  A.Prov_Group_ID as ProviderGroupID ,  A.providerstate as State,  " +
                    "  :All as ClientName, :All as ServiceLevel," +
                    "  A.LOB2 as LobName,  " +
                    "  A.Project_Year as ProgramYear,  " +
                    "  :DurationValue AS DurationValue," +
                    "  sum(case  when A.deploydate <=:EndDate  then 1 else 0 end) as DeployYTDActual,  " +
                    "  sum(case  when A.Returned =1 and A.retrieval_date_clean <=:EndDate then 1 else 0 end) as ReturnYTDActual,  " +
                    "  sum(case  when A.returnednetcna =1 and A.retrieval_date_clean <=:EndDate then 1 else 0 end) as ReturnedNetCna  " +
                    "  FROM  " +
                    "  ProgPerf.MemberAssessment A WITH (NOLOCK) " +
                    "  WHERE  " +
                    "  A.DerivedDeployed = 1 " +
                    "  and A.Project_Year =:ProgramYear  " +
                    "  and A.LOB2 in (:Lob)  " +
                    "  and Upper(A.RecordChangeType) not in (:recordChangeTypeNotIn) " +
                    "  %s" +
                    "  GROUP BY  " +
                    "  A.Project_Year, A.LOB2, A.providerstate, A.Prov_Group_ID" +
                    "  ) as rs" +
                    "  where LEN(ProviderGroupID) > 0 and LEN(State) > 0 and LEN(LobName)> 0 and LEN(DurationValue)> 0" +
                    "  and ClientName = :All and ServiceLevel = :All" +
                    " group by ProviderGroupId, State, ClientName, LobName, ServiceLevel, ProgramYear, DurationValue " +
            ") AS sources " +
            "ON ( " +
            "    pgp.ProviderGroupID = sources.providerGroupID " +
            "    AND pgp.STATE = sources.State " +
            "    AND pgp.ServiceLevel = :All" +
            "    AND pgp.DurationValue = sources.durationValue " +
            "    AND pgp.ProgramYear = sources.programYear " +
            "    AND pgp.ClientName = :All " +
            "    AND pgp.LobName = sources.lobName " +
            ") " +
            "WHEN MATCHED " +
            "    THEN " +
            "        UPDATE " +
            "        SET DeployYTDActual = sources.DeployYTDActual" +
            "        , ReturnYTDActual = sources.ReturnYTDActual " +
            "        , ReturnedNetCnaYtdActual = sources.ReturnedNetCna " +
            "        , UpdatedDate = getUTCDate() " +
            "        , UpdatedBy = :HistoricalActualJobName" +
            "        , DurationEndDate = :EndDate" +
            "        , DurationStartDate = :StartDate " +
            "        , isCurrentWeekForPerformance = 0" +
            "WHEN NOT MATCHED " +
            "    THEN " +
            "        INSERT (ProviderGroupID , State, ServiceLevel " +
            "        , ClientName , LobName , ProgramYear, DurationValue , DeployYTDActual " +
            "        , ReturnYTDActual, ReturnedNetCnaYtdActual, isCurrentWeekForPerformance" +
            "        , DurationEndDate, DurationStartDate, CreatedBy, CreatedDate " +
            "        , UpdatedBy , UpdatedDate ) " +
            "        VALUES (sources.providerGroupID,  sources.State,  :All, :All,  sources.lobName ,  sources.programYear " +
            "        ,  sources.durationValue ,  sources.DeployYTDActual, sources.ReturnYTDActual, sources.ReturnedNetCna, 0" +
            "        , :EndDate " +
            "        , :StartDate " +
            "        , :HistoricalActualJobName, getUTCDate() , :HistoricalActualJobName ,  getUTCDate())" +
                    ";";


    private static final String PG_PERFORMANCE_WEEKLY_UPDATED_MERGE_QUERY=
            "MERGE INTO ProgPerf.ProviderGroupPerformanceWeekly AS pgp   " +
                    "USING  " +
                    "(  " +
                    " SELECT  " +
                    "   ProviderGroupID " +
                    "   ,State " +
                    "   ,ClientName " +
                    "   ,ServiceLevel " +
                    "   ,LobName " +
                    "   ,ProgramYear " +
                    "   ,DurationValue " +
                    "   ,sum(DeployYTDActual) as DeployYTDActual " +
                    "   ,sum(ReturnYTDActual) as ReturnYTDActual " +
                    "   ,sum(ReturnedNetCna) as ReturnedNetCna " +
                    " FROM ( " +
                    "    SELECT   " +
                    "      A.Prov_Group_ID as ProviderGroupID  " +
                    "      ,A.providerstate as State   " +
                    "      ,A.ClientNameOFCStandard as ClientName  " +
                    "      ,:All as ServiceLevel " +
                    "      ,A.LOB2 as LobName  " +
                    "      ,A.Project_Year as ProgramYear  " +
                    "      ,:DurationValue AS DurationValue " +
                    "      ,sum(case  when A.deploydate <=:EndDate  then 1 else 0 end) as DeployYTDActual " +
                    "      ,sum(case  when A.Returned =1 and A.retrieval_date_clean <=:EndDate then 1 else 0 end) as ReturnYTDActual   " +
                    "      ,sum(case  when A.returnednetcna =1 and A.retrieval_date_clean <=:EndDate then 1 else 0 end) as ReturnedNetCna " +
                    "    FROM   " +
                    "        ProgPerf.MemberAssessment A WITH (NOLOCK)  " +
                    "    WHERE   " +
                    "        A.DerivedDeployed = 1  " +
                    "        and A.Project_Year =:ProgramYear   " +
                    "        and A.LOB2 in (:Lob)   " +
                    "        and Upper(A.RecordChangeType) not in (:recordChangeTypeNotIn)  " +
                    "          %s" +
                    "    GROUP BY   " +
                    "        A.Project_Year, A.LOB2, A.providerstate, A.Prov_Group_ID,A.ClientNameOFCStandard   " +
                    "    ) as rs " +
                    " WHERE  " +
                    "   LEN(ProviderGroupID) > 0 and LEN(State) > 0 and LEN(LobName)> 0 and LEN(DurationValue)> 0 " +
                    "  and LEN(ClientName)>0 and ServiceLevel = :All " +
                    "GROUP BY ProviderGroupId, State, ClientName, LobName, ServiceLevel, ProgramYear, DurationValue " +
                    ") AS sources  " +
                    "ON (  " +
                    "    pgp.ProviderGroupID = sources.providerGroupID  " +
                    "    AND pgp.STATE = sources.State  " +
                    "    AND pgp.ServiceLevel = :All " +
                    "    AND pgp.DurationValue = sources.durationValue  " +
                    "    AND pgp.ProgramYear = sources.programYear  " +
                    "    AND pgp.ClientName = sources.clientName  " +
                    "    AND pgp.LobName = sources.lobName  " +
                    ")  " +
                    "WHEN MATCHED  " +
                    "    THEN  " +
                    "        UPDATE  " +
                    "        SET DeployYTDActual = sources.DeployYTDActual " +
                    "        , ReturnYTDActual = sources.ReturnYTDActual  " +
                    "        , ReturnedNetCnaYtdActual = sources.ReturnedNetCna  " +
                    "        , UpdatedDate = getUTCDate()  " +
                    "        , UpdatedBy = :HistoricalActualJobName " +
                    "        , DurationEndDate = :EndDate " +
                    "        , DurationStartDate = :StartDate  " +
                    "        , isCurrentWeekForPerformance = 0 " +
                    "WHEN NOT MATCHED  " +
                    "    THEN  " +
                    "        INSERT (ProviderGroupID , State, ServiceLevel  " +
                    "        , ClientName , LobName , ProgramYear, DurationValue , DeployYTDActual  " +
                    "        , ReturnYTDActual, ReturnedNetCnaYtdActual, isCurrentWeekForPerformance " +
                    "        , DurationEndDate, DurationStartDate, CreatedBy, CreatedDate  " +
                    "        , UpdatedBy , UpdatedDate)  " +
                    "        VALUES (sources.providerGroupID,  sources.State,  :All, sources.clientName,  sources.lobName ,  sources.programYear  " +
                    "        ,  sources.durationValue ,  sources.DeployYTDActual, sources.ReturnYTDActual, sources.ReturnedNetCna, 0 " +
                    "        , :EndDate  " +
                    "        , :StartDate  " +
                    "        , :HistoricalActualJobName, getUTCDate() , :HistoricalActualJobName ,  getUTCDate()) ;" ;



    private static final String UPDATE_CURRENT_WEEK_ACTUALS =
                    ";with Previous_week_data as (" +
                            "SELECT pgp.ProviderGroupID, pgp.State, pgp.ClientName, pgp.LobName,pgp.ServiceLevel , pgp.DurationValue ,pgp.ProgramYear , " +
                            "       pgp.DeployYTDActual as p_DeployYTDActual, pgp.ReturnYTDActual as p_ReturnYTDActual , pgp.ReturnedNetCnaYtdActual as p_ReturnedNetCnaYtdActual " +
                            "FROM ProgPerf.ProviderGroupPerformanceWeekly pgp WITH (NOLOCK) " +
                            "where pgp.ProgramYear =:ProgramYear " +
                            "and pgp.DurationEndDate = :PrevEndDate " +
                                        ") " +
                    "UPDATE ProgPerf.ProviderGroupPerformanceWeekly " +
                    "SET " +
                    "   CurrentWeekDeploymentsCount=ISNULL(DeployYTDActual,0) - ISNULL(Previous_week_data.p_DeployYTDActual,0), " +
                    "   CurrentWeekReturnsCount=ISNULL(ReturnedNetCnaYtdActual,0)-ISNULL(Previous_week_data.p_ReturnedNetCnaYtdActual,0)  " +
                    "FROM ProgPerf.ProviderGroupPerformanceWeekly pgp  " +
                    "  LEFT JOIN Previous_week_data on Previous_week_data.ProviderGroupID=pgp.ProviderGroupID " +
                    "  and Previous_week_data.State=pgp.State " +
                    "  and Previous_week_data.ProgramYear = pgp.ProgramYear " +
                    "  and Previous_week_data.ServiceLevel = pgp.ServiceLevel " +
                    "  and Previous_week_data.ClientName=pgp.ClientName " +
                    "  and Previous_week_data.LobName=pgp.LobName " +
                    "WHERE pgp.ProgramYear =:ProgramYear " +
                    "AND pgp.DurationEndDate=:EndDate;" ;


    private static final String UPDATE_PREVIOUS_WEEK_ACTUALS =
                   " ;with Previous_week_data as ( " +
                            "SELECT pgp.ProviderGroupID, pgp.State, pgp.ClientName, pgp.LobName,pgp.ServiceLevel , pgp.DurationValue ,pgp.ProgramYear , " +
                            "       pgp.CurrentWeekDeploymentsCount, pgp.CurrentWeekReturnsCount, pgp.ReturnedNetCnaYtdActual  " +
                            "FROM ProgPerf.ProviderGroupPerformanceWeekly pgp   WITH (NOLOCK)  " +
                            "WHERE pgp.ProgramYear =:ProgramYear " +
                            "AND pgp.DurationEndDate = :PrevEndDate " +
                                                ") " +
                    "UPDATE ProgPerf.ProviderGroupPerformanceWeekly " +
                    "SET " +
                    "   PreviousWeekDeploymentsCount=ISNULL(Previous_week_data.CurrentWeekDeploymentsCount,0),  " +
                    "   PreviousWeekReturnsCount=ISNULL(Previous_week_data.CurrentWeekReturnsCount,0) " +
                    "FROM ProgPerf.ProviderGroupPerformanceWeekly pgp  " +
                    "  LEFT JOIN Previous_week_data ON Previous_week_data.ProviderGroupID=pgp.ProviderGroupID " +
                    "  and Previous_week_data.State=pgp.State " +
                    "  and Previous_week_data.ProgramYear = pgp.ProgramYear " +
                    "  and Previous_week_data.ServiceLevel = pgp.ServiceLevel " +
                    "  and Previous_week_data.ClientName=pgp.ClientName " +
                    "  and Previous_week_data.LobName=pgp.LobName " +
                    "WHERE pgp.ProgramYear =:ProgramYear " +
                    "AND pgp.DurationEndDate=:EndDate;" ;

    private static final String COMMAND_CENTER_PERFORMANCE_MERGE_QUERY=
            "MERGE INTO ProgPerf.CommandCenterPerformance AS CCP  " +
                    "USING  " +
                    "(  " +
                    "  SELECT PGP.State  " +
                    "       ,PGP.ClientName  " +
                    "       ,PGP.ServiceLevel  " +
                    "       ,PGP.LobName  " +
                    "       ,PGP.ProgramYear  " +
                    "       ,PGP.DurationValue  " +
                    "       ,PGP.isCurrentWeekForPerformance "+
                    "       ,sum(PGP.DeployYTDActual) as DeployYTDActual  " +
                    "       ,sum(PGP.ReturnYTDActual) as ReturnYTDActual  " +
                    "       ,sum(PGP.ReturnedNetCnaYtdActual) as ReturnedNetCnaYtdActual  " +
                    "       ,sum(PGP.PreviousWeekDeploymentsCount) as PreviousWeekDeploymentsCount  " +
                    "       ,sum(PGP.CurrentWeekDeploymentsCount) as CurrentWeekDeploymentsCount  " +
                    "       ,sum(PGP.PreviousWeekReturnsCount) as PreviousWeekReturnsCount  " +
                    "       ,sum(PGP.CurrentWeekReturnsCount) as CurrentWeekReturnsCount  " +
                    "   FROM ProgPerf.ProviderGroupPerformanceWeekly PGP  WITH (NOLOCK) " +
                    "   WHERE LEN(PGP.State) > 0 and LEN(PGP.LobName)> 0 and LEN(PGP.DurationValue)> 0 and LEN(PGP.ClientName)> 0   " +
                    "       AND LEN(PGP.ServiceLevel)> 0   " +
                    "       AND PGP.DurationValue =:DurationValue  " +
                    "       AND PGP.ProgramYear =:ProgramYear  " +
                    "   GROUP BY PGP.State  " +
                    "         ,PGP.ClientName  " +
                    "         ,PGP.ServiceLevel  " +
                    "         ,PGP.LobName  " +
                    "         ,PGP.ProgramYear  " +
                    "         ,PGP.DurationValue  " +
                    "         ,PGP.isCurrentWeekForPerformance "+
                    ") AS sources  " +
                    "ON (  " +
                    "       CCP.ProviderGroupID = :All  " +
                    "       AND CCP.STATE = sources.State  " +
                    "       AND CCP.ServiceLevel = sources.ServiceLevel  " +
                    "       AND CCP.DurationValue = sources.DurationValue  " +
                    "       AND CCP.ProgramYear = sources.ProgramYear  " +
                    "       AND CCP.ClientName = sources.ClientName  " +
                    "       AND CCP.LobName = sources.LobName  " +
                    ")  " +
                    "WHEN MATCHED THEN  " +
                    "       UPDATE  " +
                    "             SET DeployYTDActual = sources.DeployYTDActual  " +
                    "             , ReturnYTDActual = sources.ReturnYTDActual  " +
                    "             , ReturnedNetCnaYtdActual = sources.ReturnedNetCnaYtdActual  " +
                    "             , PreviousWeekDeploymentsCount = sources.PreviousWeekDeploymentsCount  " +
                    "             , CurrentWeekDeploymentsCount =sources. CurrentWeekDeploymentsCount  " +
                    "             , PreviousWeekReturnsCount = sources.PreviousWeekReturnsCount  " +
                    "             , CurrentWeekReturnsCount = sources.CurrentWeekReturnsCount  " +
                    "             , UpdatedDate = getUTCDate()  " +
                    "             , UpdatedBy = :HistoricalActualJobName  " +
                    "             , DurationEndDate = :EndDate  " +
                    "             , DurationStartDate = :StartDate  " +
                    "             , isCurrentWeekForPerformance = sources.isCurrentWeekForPerformance  " +
                    "WHEN NOT MATCHED THEN  " +
                    "       INSERT (ProviderGroupID , State, ServiceLevel  " +
                    "       , ClientName , LobName , ProgramYear, DurationValue , DeployYTDActual  " +
                    "       , ReturnYTDActual, ReturnedNetCnaYtdActual  " +
                    "       , PreviousWeekDeploymentsCount, CurrentWeekDeploymentsCount  " +
                    "       , PreviousWeekReturnsCount, CurrentWeekReturnsCount  " +
                    "       , isCurrentWeekForPerformance  " +
                    "       , DurationEndDate, DurationStartDate, CreatedBy, CreatedDate  " +
                    "       , UpdatedBy , UpdatedDate )  " +
                    "       VALUES (:All, sources.State, sources.ServiceLevel, sources.ClientName, sources.LobName , sources.ProgramYear  " +
                    "       , sources.DurationValue , sources.DeployYTDActual, sources.ReturnYTDActual, sources.ReturnedNetCnaYtdActual  " +
                    "       , sources.PreviousWeekDeploymentsCount, sources. CurrentWeekDeploymentsCount  " +
                    "       , sources.PreviousWeekReturnsCount, sources.CurrentWeekReturnsCount  " +
                    "       , sources.isCurrentWeekForPerformance  " +
                    "       , :EndDate , :StartDate , :HistoricalActualJobName, getUTCDate()  " +
                    "       , :HistoricalActualJobName , getUTCDate());";
    private static final String SELECT_LAST_WEEK_PREVIOUS_YEAR =
                    "            SELECT TOP 1  pyc.ProgramYear,  pyc.DurationValue ,pyc.StartDate ,pyc.EndDate, pyc.DurationType, pyc.ID   " +
                    "            FROM ProgPerf.ProgramYearCalendar pyc WITH (NOLOCK)    " +
                    "            WHERE  pyc.ProgramYear in(:ProgramYear-1)    " +
                    "                 AND  pyc.DurationType ='WEEK'    " +
                    "            ORDER by EndDate desc ";
    private static final String UPDATE_ZEROED_DEPLOYMENT_COUNTS_WEEKLY =
            "update " +
            " ProgPerf.ProviderGroupPerformanceweekly  " +
            "set " +
            "DeployYTDActual = 0, " +
            "ReturnedNetCnaYtdActual = 0, " +
            "ReturnYTDActual = 0, " +
            "UpdatedDate = GETUTCDATE(), UpdatedBy =:HistoricalActualJobName " +
            "where " +
            "DurationValue = :DurationValue " +
            "and ProgramYear = :ProgramYear " +
            "and DeployYTDActual >0 " +
            "and EXISTS ( " +
            "Select " +
            "count(*) " +
            "from " +
            "ProgPerf.MemberAssessment ma " +
            "where " +
            "ma.project_year = :ProgramYear " +
            "and ma.providerstate = State " +
            "and ma.prov_group_id = ProviderGroupID " +
            "and ma.lob2 = LobName " +
            "and ma.ClientNameOFCStandard = ClientName " +
            "and ma.RecordChangeType <> 'Deleted' " +
            "and ma.deriveddeployed = 1 " +
            "having " +
            "count(*) = 0); ";
    private static final String UPDATE_ZEROED_DEPLOYMENT_COUNTS =
            "update " +
                    " ProgPerf.ProviderGroupPerformance  " +
                    "set " +
                    "DeployYTDActual = 0, " +
                    "ReturnedNetCnaYtdActual = 0, " +
                    "ReturnYTDActual = 0, " +
                    "UpdatedDate = GETUTCDATE(), UpdatedBy =:HistoricalActualJobName " +
                    "where " +
                    "DurationValue = :DurationValue " +
                    "and ProgramYear = :ProgramYear " +
                    "and DeployYTDActual >0 " +
                    "and EXISTS ( " +
                    "Select " +
                    "count(*) " +
                    "from " +
                    "ProgPerf.MemberAssessment ma " +
                    "where " +
                    "ma.project_year = :ProgramYear " +
                    "and ma.providerstate = State " +
                    "and ma.prov_group_id = ProviderGroupID " +
                    "and ma.lob2 = LobName " +
                    "and ma.RecordChangeType <> 'Deleted' " +
                    "and ma.deriveddeployed = 1 " +
                    "having " +
                    "count(*) = 0); ";

    @Override
    public Flux<ProgramYearCalendarDTO> getAllProgramYearDurations(int programYear) {
        log.info("{} : Repository::Getting All Duration values for given program Year ", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier());
        return this.databaseClient.execute(SELECT_PROGRAM_YEARS)
                .bind(ColumnNames.PROGRAM_YEAR.getColumnName(), programYear)
                .as(ProgramYearCalendarDTO.class)
                .fetch()
                .all();
    }


    @Override
    public Flux<ProgramYearCalendarDTO> getPrevoiusYearLastWeekDuration(int programYear) {
        log.info("{} Query is {},{} ", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier(), SELECT_LAST_WEEK_PREVIOUS_YEAR, programYear);
        return this.databaseClient.execute(SELECT_LAST_WEEK_PREVIOUS_YEAR)
                .bind(ColumnNames.PROGRAM_YEAR.getColumnName(), programYear)
                .as(ProgramYearCalendarDTO.class)
                .fetch()
                .all();
    }


    @Override
    public Mono<Integer> calculateActual(ProgramYearCalendarDTO dto, boolean isAllProviderGroups) {
        String query;
        if (Objects.isNull(dto)) {
            log.error("{} dto object is null so returning 0", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier());
            return Mono.just(0);
        }

        if (isAllProviderGroups) {
            query = String.format(PG_PERFORMANCE_UPDATED_MERGE_QUERY, EMPTY_STRING);
        } else {
            query = String.format(PG_PERFORMANCE_UPDATED_MERGE_QUERY, MEMBER_ASSESSMENT_QUERY_FILTER);
        }
        log.info("{} Query is {},{},{},{},{}", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier(), query,
                dto.getProgramYear(), dto.getDurationValue(), ProviderGroupConstants.LOBS, RECORD_TYPE_NOT_CHANGE_IN_LIST);


        return databaseClient.execute(query)
                .bind(ALL, ALL)
                .bind(ColumnNames.DURATION_VALUE.getColumnName(), dto.getDurationValue())
                .bind(ColumnNames.PROGRAM_YEAR.getColumnName(), dto.getProgramYear())
                .bind(ColumnNames.END_DATE.getColumnName(), dto.getEndDate())
                .bind(ColumnNames.START_DATE.getColumnName(), dto.getStartDate())
                .bind(LOB, ProviderGroupConstants.LOBS)
                .bind(RECORD_TYPE_NOT_CHANGE_IN, RECORD_TYPE_NOT_CHANGE_IN_LIST)
                .bind(HISTORICAL_ACTUAL_JOB_NAME, JobName.LOAD_HISTORICAL_LOB_TARGET_VALUES_AND_ACTUALS.getValue())
                .fetch()
                .rowsUpdated()
                .doOnNext(integer -> log.info("(*(*(*(*(* rows Updated {}", integer));
    }


    @Override
    public Mono<Integer> calculatePGPWeeklyActual(ProgramYearCalendarDTO dto, boolean isAllProviderGroups) {
        String query;
        if (Objects.isNull(dto)) {
            log.error("{} dto object is null so returning 0", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier());
            return Mono.just(0);
        }

        if (isAllProviderGroups) {
            query = String.format(PG_PERFORMANCE_WEEKLY_UPDATED_MERGE_QUERY, EMPTY_STRING);
        } else {
            query = String.format(PG_PERFORMANCE_WEEKLY_UPDATED_MERGE_QUERY, MEMBER_ASSESSMENT_QUERY_FILTER);
        }
        log.info("{} Query is {},{},{},{},{}", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier(), query,
                dto.getProgramYear(), dto.getDurationValue(), ProviderGroupConstants.LOBS, RECORD_TYPE_NOT_CHANGE_IN_LIST);


        return databaseClient.execute(query)
                .bind(ALL, ALL)
                .bind(ColumnNames.DURATION_VALUE.getColumnName(), dto.getDurationValue())
                .bind(ColumnNames.PROGRAM_YEAR.getColumnName(), dto.getProgramYear())
                .bind(ColumnNames.END_DATE.getColumnName(), dto.getEndDate())
                .bind(ColumnNames.START_DATE.getColumnName(), dto.getStartDate())
                .bind(LOB, ProviderGroupConstants.LOBS)
                .bind(RECORD_TYPE_NOT_CHANGE_IN, RECORD_TYPE_NOT_CHANGE_IN_LIST)
                .bind(HISTORICAL_ACTUAL_JOB_NAME, JobName.LOAD_HISTORICAL_LOB_TARGET_VALUES_AND_ACTUALS.getValue())
                .fetch()
                .rowsUpdated()
                .doOnNext(integer -> log.info("(*(*(*(*(* rows Updated {}", integer));
    }


    @Override
    public Mono<Integer> calculateCurrentWeekActuals(ProgramYearCalendarDTO dto) {
        return databaseClient.execute(UPDATE_CURRENT_WEEK_ACTUALS)
                .bind("PrevEndDate", dto.getEndDate().minusDays(7))
                .bind("ProgramYear", dto.getProgramYear())
                .bind("EndDate", dto.getEndDate())
                .fetch()
                .rowsUpdated();

    }

    @Override
    public Mono<Integer> calculatePreviousWeekActuals(ProgramYearCalendarDTO dto) {
        return databaseClient.execute(UPDATE_PREVIOUS_WEEK_ACTUALS)
                .bind("PrevEndDate", dto.getEndDate().minusDays(7))
                .bind("ProgramYear", dto.getProgramYear())
                .bind("EndDate", dto.getEndDate())
                .fetch()
                .rowsUpdated();

    }


    @Override
    public Mono<Integer> calculateCCPActual(ProgramYearCalendarDTO dto) {
       ;
        if (Objects.isNull(dto)) {
            log.error("{} dto object is null so returning 0", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier());
            return Mono.just(0);
        }

        log.info("{} Query is {},{},{},{}", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier(), COMMAND_CENTER_PERFORMANCE_MERGE_QUERY,
                dto.getProgramYear(), dto.getDurationValue(), ProviderGroupConstants.LOBS);


        return databaseClient.execute(COMMAND_CENTER_PERFORMANCE_MERGE_QUERY)
                .bind(ALL, ALL)
                .bind(ColumnNames.DURATION_VALUE.getColumnName(), dto.getDurationValue())
                .bind(ColumnNames.PROGRAM_YEAR.getColumnName(), dto.getProgramYear())
                .bind(ColumnNames.END_DATE.getColumnName(), dto.getEndDate())
                .bind(ColumnNames.START_DATE.getColumnName(), dto.getStartDate())
                .bind(HISTORICAL_ACTUAL_JOB_NAME, JobName.LOAD_HISTORICAL_LOB_TARGET_VALUES_AND_ACTUALS.getValue())
                .fetch()
                .rowsUpdated()
                .doOnNext(integer -> log.info("(*(*(*(*(* rows Updated {}", integer));
    }


    @Override
    public Mono<Integer> resetZeroedDeployments(ProgramYearCalendarDTO dto) {
        log.info("{} resetZeroedDeployments Query is {},{},{},{}", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier(), UPDATE_ZEROED_DEPLOYMENT_COUNTS,
                dto.getProgramYear(), dto.getDurationValue());
        return databaseClient.execute(UPDATE_ZEROED_DEPLOYMENT_COUNTS)
                .bind(ColumnNames.DURATION_VALUE.getColumnName(), dto.getDurationValue())
                .bind(ColumnNames.PROGRAM_YEAR.getColumnName(), dto.getProgramYear())
                .bind(HISTORICAL_ACTUAL_JOB_NAME, JobName.LOAD_HISTORICAL_LOB_TARGET_VALUES_AND_ACTUALS.getValue())
                .fetch()
                .rowsUpdated()
                .flatMap(integer -> {
                   return   databaseClient.execute(UPDATE_ZEROED_DEPLOYMENT_COUNTS_WEEKLY)
                            .bind(ColumnNames.DURATION_VALUE.getColumnName(), dto.getDurationValue())
                            .bind(ColumnNames.PROGRAM_YEAR.getColumnName(), dto.getProgramYear())
                            .bind(HISTORICAL_ACTUAL_JOB_NAME, JobName.LOAD_HISTORICAL_LOB_TARGET_VALUES_AND_ACTUALS.getValue())
                            .fetch()
                            .rowsUpdated()
                           .map(integer1 -> integer1+integer);
                });
    }



}