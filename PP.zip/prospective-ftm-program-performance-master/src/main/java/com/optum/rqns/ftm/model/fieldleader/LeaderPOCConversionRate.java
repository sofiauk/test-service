package com.optum.rqns.ftm.model.fieldleader;

import lombok.Builder;
import lombok.Data;
import org.springframework.data.relational.core.mapping.Table;

import java.time.LocalDateTime;

@Data
@Builder
@Table("ProgPerf.LeaderGrowthRatePOCEModality")
public class LeaderPOCConversionRate {
    private boolean currentMonth;
    private Integer existingGroups;
    private Integer existingTotalGroups;
    private Integer newGroups;
    private Integer newTotalGroups;
    private LocalDateTime updatedDate;
}
