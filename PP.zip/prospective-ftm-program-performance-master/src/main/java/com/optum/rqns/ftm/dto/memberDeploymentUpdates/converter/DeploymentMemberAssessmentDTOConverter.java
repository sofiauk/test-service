package com.optum.rqns.ftm.dto.memberDeploymentUpdates.converter;

import com.optum.rqns.ftm.dto.memberDeploymentUpdates.DeploymentMemberAssessmentDTO;
import com.optum.rqns.ftm.repository.memberDeploymentUpdates.PAFxMemberDeploymentUpdatesRepositoryImpl;
import io.r2dbc.spi.Row;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.convert.converter.Converter;

import java.time.LocalDate;
import java.util.Date;

@Slf4j
public class DeploymentMemberAssessmentDTOConverter  implements Converter<Row, DeploymentMemberAssessmentDTO>{
    @Override
    public DeploymentMemberAssessmentDTO convert(Row rs) {

        return DeploymentMemberAssessmentDTO.builder()
                .providerGroupId(rs.get(PAFxMemberDeploymentUpdatesRepositoryImpl.ColumnNames.PROVIDERGROUP_ID.getColumnName(), String.class))
                .providerState(rs.get(PAFxMemberDeploymentUpdatesRepositoryImpl.ColumnNames.PROVIDER_STATE.getColumnName(), String.class))
                .providerId(rs.get(PAFxMemberDeploymentUpdatesRepositoryImpl.ColumnNames.PROVIDER_ID.getColumnName(), String.class))
                .lobName(rs.get(PAFxMemberDeploymentUpdatesRepositoryImpl.ColumnNames.LOB_NAME.getColumnName(), String.class))
                .isAssociated(rs.get(PAFxMemberDeploymentUpdatesRepositoryImpl.ColumnNames.IS_PROVIDER_ASSOCIATED.getColumnName(), String.class))
                .isDeployed(rs.get(PAFxMemberDeploymentUpdatesRepositoryImpl.ColumnNames.ISDEPLOYED.getColumnName(), String.class))
                .globalMemberId(rs.get(PAFxMemberDeploymentUpdatesRepositoryImpl.ColumnNames.GLOBAL_MEMBER_ID.getColumnName(), String.class))
                .clientId(rs.get(PAFxMemberDeploymentUpdatesRepositoryImpl.ColumnNames.CLIENT_ID.getColumnName(), String.class))
                .programYear(rs.get(PAFxMemberDeploymentUpdatesRepositoryImpl.ColumnNames.PROGRAM_YEAR.getColumnName(), Integer.class))
                .validationStatus(rs.get(PAFxMemberDeploymentUpdatesRepositoryImpl.ColumnNames.VALIDATION_STATUS.getColumnName(), String.class))
                .associationValidFrom(rs.get(PAFxMemberDeploymentUpdatesRepositoryImpl.ColumnNames.ASSOCIATION_VALID_FROM.getColumnName(), LocalDate.class))
                .associationValidTo(rs.get(PAFxMemberDeploymentUpdatesRepositoryImpl.ColumnNames.ASSOCIATION_VALID_TO.getColumnName(), LocalDate.class))
                .build();
    }
}