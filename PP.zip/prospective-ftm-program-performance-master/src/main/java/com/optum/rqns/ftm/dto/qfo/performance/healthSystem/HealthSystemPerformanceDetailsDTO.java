package com.optum.rqns.ftm.dto.qfo.performance.healthSystem;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@Builder
@EqualsAndHashCode
@NoArgsConstructor
@ToString
@AllArgsConstructor
public class HealthSystemPerformanceDetailsDTO {

    String healthSystemId;
    String healthSystemName;
    int programYear;
    Long  totalPatients;
    Long mcaipTotalPatients;
    BigDecimal overAllStarRating;
    Long mapCpiEligiblePatients;
    BigDecimal mapCpiStarRating;
    String mapCpiPatientExperience;
    BigDecimal mapCpiPartDStarRating;
    BigDecimal acpStarRating;
    Long mapCpiAnnualCareVisits;
    Long suspectConditionsTotal;
    Long suspectConditionAssessedTotal;
    Long suspectDiagnosed;
    Long suspectUndiagnosed;
    Long suspectNotAssessed;
    Long mcaipFullyAssessed;
    Long mcaipSuspectMedicalConditions;
    //String incentiveProgram;
    String teamType;
    String durationValue;
    LocalDateTime updatedDate;
    LocalDateTime mapCpiLastUpdated;
    LocalDateTime mcaipLastUpdated;
}
