package com.optum.rqns.ftm.dto.fieldleader;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class LeaderPOCConversionMyTeamDTO {
    private List<LeaderPOCConversionDTO> hierarchy = new ArrayList<>();
}
