package com.optum.rqns.ftm.model.export;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.optum.rqns.ftm.constants.ProviderGroupConstants;
import com.optum.rqns.ftm.enums.DocumentType;
import com.optum.rqns.ftm.enums.ExportStatus;
import com.optum.rqns.ftm.enums.ProcessSubType;
import com.optum.rqns.ftm.enums.ProcessType;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Objects;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ExportDetail {
    String optumUuid;
    long transactionId;
    String fileName;
    @Getter(AccessLevel.NONE)
    ProcessType processType;
    @Getter(AccessLevel.NONE)
    ProcessSubType processSubType;
    @Getter(AccessLevel.NONE)
    DocumentType documentType;
    private LocalDateTime exportedDateTime;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = ProviderGroupConstants.EXPORT_DATE_FORMAT)
    private LocalDate exportedDate;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = ProviderGroupConstants.EXPORT_TIME_FORMAT)
    private LocalTime exportedTime;
    boolean isCancelled;
    String fileSize;
    @Getter(AccessLevel.NONE)
    ExportStatus exportStatus;
    boolean isRead;

    public String getExportStatus() {
        return Objects.nonNull(this.exportStatus) ? this.exportStatus.getValue() : null;
    }

    public String getProcessType() {
        return Objects.nonNull(this.processType) ? this.processType.getValue() : null;
    }

    public String getProcessSubType() {
        return Objects.nonNull(this.processSubType) ? this.processSubType.getValue() : null;
    }

    public String getDocumentType() {
        return Objects.nonNull(this.documentType) ? this.documentType.getValue() : null;
    }

}
