package com.optum.rqns.ftm.repository.weeklyJobs;

import reactor.core.publisher.Mono;

public interface RunWeeklyJobsRepository {
    Mono<Integer> deflagIsCurretWeekPerformance(Integer programYear);

    Mono<Integer> resetProviderGroupExtendedIsActionSent();

    Mono<Integer> markIsLastWeekOfMonthInCommandCenter(Integer programYear);
}
