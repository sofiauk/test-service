package com.optum.rqns.ftm.dto.processor.providergrp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.time.LocalDate;

@ToString
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class ProviderGroupYTD {
    private int projectYear;
    private  String lob;
    private String providerState;
    private String groupId;
    private String client;
    private Long deployed;
    private Long returned;
    private LocalDate minDeployed;
    private LocalDate maxDeployed;
}
