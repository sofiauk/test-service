package com.optum.rqns.ftm.repository.roleBasedAccess;

import reactor.core.publisher.Mono;

public interface RoleBasedAccessRepository {

     Mono<Boolean> isTollgateAccessible(String uuid, String groupId, String state, String role);
}
