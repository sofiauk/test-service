package com.optum.rqns.ftm.repository.fieldleader;

public class LeaderOpportunitiesDetailsQueryBuilder {
    private static final LeaderOpportunitiesDetailsQueryBuilder INSTANCE = new LeaderOpportunitiesDetailsQueryBuilder();

    private LeaderOpportunitiesDetailsQueryBuilder() {}

    public static Builder builder() { return INSTANCE.new Builder(); }

    public class Builder {

        private static final String BEGINNING_PROGRAM_YEAR_MONTH = "Feb";

        private static final String SUM_CASE_SINGLE = " SUM(CASE WHEN %s THEN %s ELSE NULL END) AS %s ";
        private static final String MAX_CASE_SINGLE = " MAX(CASE WHEN %s THEN %s ELSE NULL END) AS %s ";
        private static final String SUFFIX = " ) t ) u ";
        private static final String SELECT = "SELECT ";
        private static final String FROM = "FROM ( ";
        private static final String OPEN_GAPS = " OpenGaps ";

        private static final String MAX_CASE_DATE =
                " MasterOpportunityType = 'Quality Gaps' " +
                "OR (MasterOpportunityType = 'Annual Care Visits' AND OpportunityType = 'Annual Care Visits Not Completed') " +
                "OR (MasterOpportunityType = 'Suspect Conditions' AND (OpportunityType = 'Suspect Conditions Not Assessed' " +
                "OR OpportunityType = 'Patients Not Fully Assessed' )) ";

        private static final String FROM_COMMON =
                "FROM ProgPerf.LeaderOpportunitiesDetails " +
                "WHERE MasterOpportunityType = :MasterOpportunityType " +
                "AND ProgramYear = :ProgramYear " +
                "AND (( :CurrentMonth = '"+BEGINNING_PROGRAM_YEAR_MONTH+"' AND [Month] = " +
                        "'"+BEGINNING_PROGRAM_YEAR_MONTH+"' ) OR ( :CurrentMonth <> '"+BEGINNING_PROGRAM_YEAR_MONTH+"' " +
                        "AND [Month] IN ( :PreviousMonth , :CurrentMonth))) " +
                "AND UUID = :UUID " +
                "AND ServiceLevel IN ('HCA','PSC-B','PSC-P') " +
                "AND IsActive = 1 ";

        private static final String SUMMARY_FROM =
                "FROM ProgPerf.LeaderOpportunitiesDetails " +
                "WHERE ProgramYear = :ProgramYear " +
                "AND UUID = :UUID " +
                "AND ServiceLevel IN ('HCA','PSC-B','PSC-P') " +
                "AND IsActive = 1 " +
                "AND MasterOpportunityType IN ('Quality Gaps', 'Annual Care Visits', 'Suspect Conditions') " +
                "AND [Month] IN ( :CurrentMonth )";

        private static final String ANNUAL_QUALITY_SELECT_PREFIX =
                SELECT +
                "u.*, " +
                "(u.ClosureRateCur - u.ClosureRatePrev) AS MonthOverMonthChange " +
                FROM +
                SELECT +
                "t.*, " +
                "(CASE WHEN t.TotalPrev > 0 THEN CONVERT(FLOAT,t.ClosedGapsPrev) / CONVERT(FLOAT,t.TotalPrev) * 100 ELSE NULL END) AS ClosureRatePrev, " +
                "(CASE WHEN t.TotalCur > 0 THEN CONVERT(FLOAT,t.ClosedGapsCur) / CONVERT(FLOAT,t.TotalCur) * 100 ELSE NULL END) AS ClosureRateCur " +
                FROM +
                SELECT;

        private static final String ANNUAL_QUALITY_SELECT_COMMON =
                "SUM(CASE WHEN [Month] = :PreviousMonth THEN CAST(TotalPatients AS BIGINT) ELSE NULL END) AS TotalPrev, " +
                "SUM(CASE WHEN [Month] = :PreviousMonth THEN CAST(ClosedGaps AS BIGINT) ELSE NULL END) AS ClosedGapsPrev, " +
                "SUM(CASE WHEN [Month] = :PreviousMonth THEN CAST(OpenGaps AS BIGINT) ELSE NULL END) AS OpenGapsPrev, " +
                "SUM(CASE WHEN [Month] = :CurrentMonth THEN CAST(TotalPatients AS BIGINT) ELSE NULL END) AS TotalCur, " +
                "SUM(CASE WHEN [Month] = :CurrentMonth THEN CAST(ClosedGaps AS BIGINT) ELSE NULL END) AS ClosedGapsCur, " +
                "SUM(CASE WHEN [Month] = :CurrentMonth THEN CAST(OpenGaps AS BIGINT) ELSE NULL END) AS OpenGapsCur ";

        private static final String SUMMARY_SELECT_COMMON =
                "SUM(CASE WHEN [Month] = :PreviousMonth AND OpportunityType = 'Patients Not Fully Assessed' THEN CAST(TotalPatients AS BIGINT) ELSE NULL END) AS TotalPatientsPrev, " +
                "SUM(CASE WHEN [Month] = :PreviousMonth AND OpportunityType = 'Suspect Conditions Not Assessed' THEN CAST(TotalSuspectConditions AS BIGINT) ELSE NULL END) AS TotalSusPrev, " +
                "SUM(CASE WHEN [Month] = :PreviousMonth THEN CAST(OpenGaps AS BIGINT) ELSE NULL END) AS OpportunitiesPrev, " +
                "SUM(CASE WHEN [Month] = :PreviousMonth THEN CAST(ClosedGaps AS BIGINT) ELSE NULL END) AS ClosedPrev, " +
                "SUM(CASE WHEN [Month] = :CurrentMonth AND OpportunityType = 'Patients Not Fully Assessed' THEN CAST(TotalPatients AS BIGINT) ELSE NULL END) AS TotalPatientsCur, " +
                "SUM(CASE WHEN [Month] = :CurrentMonth AND OpportunityType = 'Suspect Conditions Not Assessed' THEN CAST(TotalSuspectConditions AS BIGINT) ELSE NULL END) AS TotalSusCur, " +
                "SUM(CASE WHEN [Month] = :CurrentMonth THEN CAST(OpenGaps AS BIGINT) ELSE NULL END) AS OpportunitiesCur, " +
                "SUM(CASE WHEN [Month] = :CurrentMonth THEN CAST(ClosedGaps AS BIGINT) ELSE NULL END) AS ClosedCur ";

        private static final String ANNUAL_CARE_VISITS =
                ANNUAL_QUALITY_SELECT_PREFIX +
                "'Annual Care Visits Not Completed' AS Measure, " +
                ANNUAL_QUALITY_SELECT_COMMON +
                FROM_COMMON +
                "AND OpportunityType IN ('Annual Care Visits Not Completed') " +
                SUFFIX;

        private static final String QUALITY_GAPS =
                ANNUAL_QUALITY_SELECT_PREFIX +
                "DISTINCT(OpportunityType) AS Measure, " +
                ANNUAL_QUALITY_SELECT_COMMON +
                FROM_COMMON +
                "GROUP BY OpportunityType " +
                SUFFIX;

        private static final String SUSPECT_CONDITIONS =
                SELECT +
                "u.Measure, " +
                "u.OpportunitiesPrev, " +
                "u.OpportunitiesCur, " +
                "(CASE WHEN u.Measure = 'Patients Not Fully Assessed' THEN u.TotalPatientsPrev WHEN  u.Measure = 'Suspect Conditions Not Assessed' THEN u.TotalSusPrev ELSE NULL END) AS TotalPrev, " +
                "(CASE WHEN u.Measure = 'Patients Not Fully Assessed' THEN u.ClosureRatePatientsPrev WHEN  u.Measure = 'Suspect Conditions Not Assessed' THEN u.ClosureRateSusPrev ELSE NULL END) AS ClosureRatePrev, " +
                "(CASE WHEN u.Measure = 'Patients Not Fully Assessed' THEN u.TotalPatientsCur WHEN  u.Measure = 'Suspect Conditions Not Assessed' THEN u.TotalSusCur ELSE NULL END) AS TotalCur, " +
                "(CASE WHEN u.Measure = 'Patients Not Fully Assessed' THEN u.ClosureRatePatientsCur WHEN  u.Measure = 'Suspect Conditions Not Assessed' THEN u.ClosureRateSusCur ELSE NULL END) AS ClosureRateCur, " +
                "(CASE WHEN u.Measure = 'Patients Not Fully Assessed' THEN (u.ClosureRatePatientsCur - u.ClosureRatePatientsPrev) WHEN  u.Measure = 'Suspect Conditions Not Assessed' THEN (u.ClosureRateSusCur - u.ClosureRateSusPrev) ELSE NULL END) AS MonthOverMonthChange " +
                FROM +
                SELECT +
                "t.*, " +
                "(CASE WHEN t.TotalPatientsPrev > 0 THEN  CONVERT(FLOAT,t.ClosedPrev) / CONVERT(FLOAT,t.TotalPatientsPrev) * 100 ELSE NULL END) AS ClosureRatePatientsPrev, " +
                "(CASE WHEN t.TotalSusPrev > 0 THEN  CONVERT(FLOAT,t.ClosedPrev) / CONVERT(FLOAT,t.TotalSusPrev) * 100 ELSE NULL END) AS ClosureRateSusPrev, " +
                "(CASE WHEN t.TotalPatientsCur > 0 THEN  CONVERT(FLOAT,t.ClosedCur) / CONVERT(FLOAT,t.TotalPatientsCur) * 100 ELSE NULL END) AS ClosureRatePatientsCur, " +
                "(CASE WHEN t.TotalSusCur > 0 THEN  CONVERT(FLOAT,t.ClosedCur) / CONVERT(FLOAT,t.TotalSusCur) * 100 ELSE NULL END) AS ClosureRateSusCur " +
                FROM +
                SELECT +
                "'Patients Not Fully Assessed' AS Measure, " +
                SUMMARY_SELECT_COMMON +
                FROM_COMMON +
                "AND OpportunityType = ('Patients Not Fully Assessed') " +
                "UNION " +
                SELECT +
                "'Suspect Conditions Not Assessed' AS Measure, " +
                SUMMARY_SELECT_COMMON +
                FROM_COMMON +
                "AND OpportunityType IN ('Suspect Conditions Not Assessed') " +
                SUFFIX;

        private boolean isSummary = false;
        private boolean isQualityGaps = false;
        private boolean isAnnualCareVisits = false;
        private boolean isSuspectConditions = false;
        private boolean isCount = false;
        private String sortColumn = "";
        private String sortBy = "";

        private Builder() {}

        Builder asSummary() {
            this.isSummary = true;
            return this;
        }

        Builder asAnnualCareVisits() {
            this.isAnnualCareVisits = true;
            return this;
        }

        Builder asQualityGaps(String sortColumn, String sortBy) {
            this.sortColumn = sortColumn;
            this.sortBy = sortBy;
            this.isQualityGaps = true;
            return this;
        }

        Builder asSuspectConditions() {
            this.isSuspectConditions = true;
            return this;
        }

        Builder asCount() {
            this.isCount = true;
            return this;
        }

        public String build() {
            StringBuilder sb = new StringBuilder();
            if (isSummary) {
                sb.append(SELECT)
                        .append(String.format(SUM_CASE_SINGLE," MasterOpportunityType = 'Quality Gaps' ",OPEN_GAPS,"QualityGaps, "))
                        .append(String.format(SUM_CASE_SINGLE," MasterOpportunityType = 'Annual Care Visits' AND OpportunityType = 'Annual Care Visits Not Completed' ",OPEN_GAPS,"AnnualCareVisits, "))
                        .append(String.format(SUM_CASE_SINGLE," MasterOpportunityType = 'Suspect Conditions' AND OpportunityType = 'Suspect Conditions Not Assessed' ",OPEN_GAPS,"SuspectConditions, "))
                        .append(String.format(MAX_CASE_SINGLE,MAX_CASE_DATE,"UpdatedDate","UpdatedDate "))
                        .append(SUMMARY_FROM);
            } else if (isAnnualCareVisits) {
                sb.append(ANNUAL_CARE_VISITS);
            } else if (isQualityGaps) {
                if (isCount) {
                    sb.append("SELECT COUNT(*) FROM (")
                            .append(QUALITY_GAPS)
                            .append(") v");
                } else {
                    sb.append(QUALITY_GAPS)
                        .append(String.format("ORDER BY %s %s OFFSET :Offset ROWS FETCH NEXT :Limit ROWS ONLY",this.sortColumn,this.sortBy));
                }
            } else if (isSuspectConditions) {
                sb.append(SUSPECT_CONDITIONS);
            } else {
                sb.setLength(0);
            }
            return sb.toString();
        }

    }
}
