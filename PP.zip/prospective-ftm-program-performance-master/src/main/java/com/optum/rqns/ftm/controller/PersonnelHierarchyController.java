package com.optum.rqns.ftm.controller;

import com.optum.rqns.ftm.customannotation.CustomApiResponse;
import com.optum.rqns.ftm.dto.personnelhierarchy.PersonnelHierarchyDTO;
import com.optum.rqns.ftm.dto.personnelhierarchy.PersonnelHierarchyRequest;
import com.optum.rqns.ftm.repository.personnelhierarchy.PersonnelHierarchyRepository;
import com.optum.rqns.ftm.exception.APIErrorCode;
import com.optum.rqns.ftm.exception.ProgramPerformanceException;
import com.optum.rqns.ftm.model.UserInfo;
import com.optum.rqns.ftm.service.personnelhierarchy.PersonnelHierarchyService;
import com.optum.rqns.ftm.util.ProgramPerformanceHeaders;
import com.optum.rqns.ftm.util.UserInfoUtil;
import com.optum.rqns.ftm.wrapper.SingleResponseWrapper;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import static com.optum.rqns.ftm.util.UserInfoUtil.isAdmin;


@Profile("rqnsFtmApi")
@RestController
@RequestMapping("/v1/personnel-hierarchy")
@Slf4j
@CustomApiResponse
public class PersonnelHierarchyController {

    @Autowired
    private PersonnelHierarchyService personnelHierarchyService;

    @Autowired
    private PersonnelHierarchyRepository personnelHierarchyRepository;

    @GetMapping
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = PersonnelHierarchyDTO.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<SingleResponseWrapper<PersonnelHierarchyDTO>> getPersonnelHierarchy() {
        log.info("Getting Personnel Hierarchy");
        return personnelHierarchyService.getPersonnelHierarchy().flatMap(t -> Mono.just(new SingleResponseWrapper<>(t)));
    }

    @PatchMapping("/{uuid}")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = SingleResponseWrapper.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<SingleResponseWrapper<Integer>> updatePersonnelHierarchy(
            @RequestHeader(value = ProgramPerformanceHeaders.X_USER_DETAILS_HEADER) String userDetails,
            @PathVariable String uuid,
            @RequestBody PersonnelHierarchyRequest request) {

        UserInfo userInfo = UserInfoUtil.parseUserInfo(userDetails);
        if(isAdmin(userInfo)) {
            return personnelHierarchyService.updatePersonnelHierarchy(uuid, request, userInfo.getUuid())
                    .flatMap(value -> {
                        log.info("Updated Personnel Hierarchy Node {}.  {} row(s) updated.", uuid, value);
                        return Mono.just(new SingleResponseWrapper<>(value));
                    });
        }
        return Mono.error(new ProgramPerformanceException(HttpStatus.BAD_REQUEST, APIErrorCode.INVALID_USER_HEADER));
    }

    @DeleteMapping("/{uuid}")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = SingleResponseWrapper.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<SingleResponseWrapper<Integer>> removePersonnelHierarchy(
            @PathVariable String uuid, @RequestParam("reason") String reason,
            @RequestHeader(value = ProgramPerformanceHeaders.X_USER_DETAILS_HEADER) String userDetails) {
        UserInfo userInfo = UserInfoUtil.parseUserInfo(userDetails);
        if(isAdmin(userInfo)) {
            return personnelHierarchyService.removePersonnelHierarchy(uuid, reason, userInfo.getUuid())
                    .flatMap(value -> {
                        log.info("Deleted Personnel Hierarchy Node {}.  {} row(s) updated.", uuid, value);
                        return Mono.just(new SingleResponseWrapper<>(value));
                    });
        }
        return Mono.error(new ProgramPerformanceException(HttpStatus.BAD_REQUEST, APIErrorCode.INVALID_USER_HEADER));
    }
}
