package com.optum.rqns.ftm.model.rules;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProviderGroupOpportunitiesDetail {
    String providerGroupID;
    String providerGroupName;
    String state;
    String serviceLevel;
    int programYear;
    String clientName;
    String clientId;
    @JsonIgnore
    String lobName;
    String masterOpportunityType;
    int masterOpportunityTypePosition;
    String opportunityType;
    int opportunityTypePosition;
    String opportunitySubType;
    int opportunitySubTypePosition;
    String displayText;
    int assessmentCount;
    int deploymentCount;
    int totalClientsCount;
    int gapCount;
    @JsonIgnore
    int deployYTDActual;
    @JsonIgnore
    int returnYTDActual;
    @JsonIgnore
    int returnYTDActualPercentage;
    @JsonIgnore
    int returnYTDTargetPercent;
    @JsonIgnore
    String chartID;
    @JsonIgnore
    String isSecondarySubmissionEligible;
    @JsonIgnore
    String outlierName;
    @JsonIgnore
    String gapType;
    @JsonIgnore
    String gapDesc;
    @JsonIgnore
    String createdBy;
    @JsonIgnore
    String paymentRejectReason;
    int eligibleMembersCount;
    @JsonIgnore
    String singleRejectReason;

    public ProviderGroupOpportunitiesDetail(ProviderGroupOpportunitiesDetail providerGroupOpportunitiesDetail){
        providerGroupID=providerGroupOpportunitiesDetail.providerGroupID;
        providerGroupName=providerGroupOpportunitiesDetail.providerGroupName;
        state=providerGroupOpportunitiesDetail.state;
        serviceLevel=providerGroupOpportunitiesDetail.serviceLevel;
        programYear=providerGroupOpportunitiesDetail.programYear;
        clientId=providerGroupOpportunitiesDetail.clientId;
        clientName=providerGroupOpportunitiesDetail.clientName;
        lobName=providerGroupOpportunitiesDetail.lobName;
        masterOpportunityType=providerGroupOpportunitiesDetail.masterOpportunityType;
        masterOpportunityTypePosition=providerGroupOpportunitiesDetail.masterOpportunityTypePosition;
        opportunityType=providerGroupOpportunitiesDetail.opportunityType;
        opportunityTypePosition=providerGroupOpportunitiesDetail.opportunityTypePosition;
        opportunitySubType=providerGroupOpportunitiesDetail.opportunitySubType;
        opportunitySubTypePosition=providerGroupOpportunitiesDetail.opportunitySubTypePosition;
        displayText=providerGroupOpportunitiesDetail.displayText;
        assessmentCount=providerGroupOpportunitiesDetail.assessmentCount;
        deploymentCount=providerGroupOpportunitiesDetail.deploymentCount;
        totalClientsCount=providerGroupOpportunitiesDetail.totalClientsCount;
        gapCount=providerGroupOpportunitiesDetail.gapCount;
        deployYTDActual=providerGroupOpportunitiesDetail.deployYTDActual;
        returnYTDActual=providerGroupOpportunitiesDetail.returnYTDActual;
        returnYTDActualPercentage=providerGroupOpportunitiesDetail.returnYTDActualPercentage;
        returnYTDTargetPercent=providerGroupOpportunitiesDetail.returnYTDTargetPercent;
        chartID=providerGroupOpportunitiesDetail.chartID;
        isSecondarySubmissionEligible=providerGroupOpportunitiesDetail.isSecondarySubmissionEligible;
        outlierName=providerGroupOpportunitiesDetail.outlierName;
        gapType=providerGroupOpportunitiesDetail.gapType;
        gapDesc=providerGroupOpportunitiesDetail.gapDesc;
        createdBy=providerGroupOpportunitiesDetail.createdBy;
        paymentRejectReason=providerGroupOpportunitiesDetail.paymentRejectReason;
        eligibleMembersCount=providerGroupOpportunitiesDetail.eligibleMembersCount;
        singleRejectReason=providerGroupOpportunitiesDetail.singleRejectReason;
    }
}
