package com.optum.rqns.ftm.dto.opportunities.providergrp.converter;

import com.optum.rqns.ftm.constants.ProviderGroupConstants;
import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.dto.opportunities.providergrp.MeasuresThresholdConfigurationDTO;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;


public class QualityRatingsThresholdDTOConverter implements Converter<Row, MeasuresThresholdConfigurationDTO>, DTOWrapperTypeConverter {
    @Override
    public MeasuresThresholdConfigurationDTO convert(Row row) {
        return MeasuresThresholdConfigurationDTO.builder()
                .measureId(row.get(ProviderGroupConstants.MEASURE_ID, String.class))
                .programYear(getPrimitiveIntegerValue(row, ProviderGroupConstants.PROGRAM_YEAR))
                .starsThreshold1(getPrimitiveIntegerValue(row, ProviderGroupConstants.QUALITY_RATINGS_THRESHOLD_1))
                .starsThreshold2(getPrimitiveIntegerValue(row, ProviderGroupConstants.QUALITY_RATINGS_THRESHOLD_2))
                .starsThreshold3(getPrimitiveIntegerValue(row, ProviderGroupConstants.QUALITY_RATINGS_THRESHOLD_3))
                .starsThreshold4(getPrimitiveIntegerValue(row, ProviderGroupConstants.QUALITY_RATINGS_THRESHOLD_4))
                .starsThreshold5(getPrimitiveIntegerValue(row, ProviderGroupConstants.QUALITY_RATINGS_THRESHOLD_5))
                .build();
    }
}
