package com.optum.rqns.ftm.model.goals.client;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class GoalDetailValues {
    private Double eligibleMembers;
    private Double goalValue;
    private Double eligiblePercentage;
    private Double stretchGoal;
    private Double stretchGoalEligiblePercentage;
}
