package com.optum.rqns.ftm.controller.practiceassist.providerdashboard;

import com.optum.rqns.ftm.configuration.ApplicationR2dbcConfiguration;
import com.optum.rqns.ftm.customannotation.CustomApiResponse;
import com.optum.rqns.ftm.dto.practiceassist.providerdashboard.ProviderJobStatusDTO;
import com.optum.rqns.ftm.dto.practiceassist.providerdashboard.SuperUserProviderGroupDataResponse;
import com.optum.rqns.ftm.enums.TypeEnum;
import com.optum.rqns.ftm.exception.APIErrorCode;
import com.optum.rqns.ftm.exception.ProgramPerformanceException;
import com.optum.rqns.ftm.model.practiceassist.providerdashboard.*;
import com.optum.rqns.ftm.response.ListResponse;
import com.optum.rqns.ftm.service.practiceassist.providerdashboard.ProviderDashboardService;
import com.optum.rqns.ftm.util.ProgramPerformanceUtil;
import com.optum.rqns.ftm.util.StargateStandardResponseUtilV2;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.http.*;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.util.List;


@Profile("rqnsFtmApi")
@RestController
@RequestMapping("/v1/provider-dashboard")
@Slf4j
@CustomApiResponse
public class ProviderDashboardController {

    @Autowired
    private ProviderDashboardService providerDashboardService;

    @Autowired
    StargateStandardResponseUtilV2<Object, Object> stargateStandardResponseUtilV2;

    @Autowired
    private ThreadPoolTaskExecutor taskExecutor;

    @PostMapping("/aggregation")
    public Mono<ListResponse> getProviderDashboardData(@RequestBody ProviderDashboardAggrRequest providerDashboardAggrRequest){
        log.info("Enter into Provider Dashboard count calculation process: {}", ProgramPerformanceUtil.toJson(providerDashboardAggrRequest));
        if (!providerDashboardService.isValidRequest(providerDashboardAggrRequest)) {
            return Mono.error(new ProgramPerformanceException(HttpStatus.BAD_REQUEST, APIErrorCode.INVALID_PROVIDER_GROUP_HEALTHSYS_ID));
        }
        String traceId = providerDashboardService.validateAndGetTraceId(providerDashboardAggrRequest);
        providerDashboardService.saveProviderDashboardDataInCache(providerDashboardAggrRequest, traceId)
                .publishOn(Schedulers.fromExecutor(taskExecutor));
        return stargateStandardResponseUtilV2.generateStargateStandardResponse(Mono.just("Success"), TypeEnum.MONO,
                new ListResponse()).cast(ListResponse.class);
    }


    @PostMapping(path = "/aggregation-data", produces = {MediaType.APPLICATION_JSON_VALUE})
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = ProviderDashboardResponse.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<ListResponse> getProviderRedisData(@RequestBody ProviderDashboardAggrRequest providerDashboardAggrRequest) {
        log.info("Getting Provider Dashboard details from Cache: {}", ProgramPerformanceUtil.toJson(providerDashboardAggrRequest));
        if (!providerDashboardService.isValidRequest(providerDashboardAggrRequest)) {
            return Mono.error(new ProgramPerformanceException(HttpStatus.BAD_REQUEST, APIErrorCode.INVALID_PROVIDER_GROUP_HEALTHSYS_ID));
        }
        String traceId = providerDashboardService.validateAndGetTraceId(providerDashboardAggrRequest);

        if (providerDashboardService.isDataReadyInCache(traceId)){
            return stargateStandardResponseUtilV2.generateStargateStandardResponse(Mono.just(providerDashboardService.
                    getProviderRedisData(traceId)), TypeEnum.MONO, new ListResponse()).cast(ListResponse.class);
        }else {
            return stargateStandardResponseUtilV2.generateStargateStandardResponse(providerDashboardService.
                    saveProviderDashboardDataInCache(providerDashboardAggrRequest, traceId)
                            .publishOn(Schedulers.fromExecutor(taskExecutor)), TypeEnum.MONO,
                    new ListResponse()).cast(ListResponse.class);
        }
    }

    @PostMapping(path = "/aggregation-data/delete")
    public Mono<Long> deleteProviderCacheData(@RequestBody ProviderJobStatusDTO providerJobStatusDTO){
        log.info("Delete Provider Dashboard cache data request : {}", ProgramPerformanceUtil.toJson(providerJobStatusDTO));
        return providerDashboardService.deleteProviderCacheData(providerJobStatusDTO);
    }

    @PostMapping(path = "/super-user", produces = {MediaType.APPLICATION_JSON_VALUE})
    @ApiResponse(responseCode = "200", description = "Success Request", content = @Content(schema =
    @Schema(implementation = String.class), mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<SuperUserProviderGroupDataResponse> findSuperUserProvGrpId(@RequestBody ProviderDashboardAggrRequest providerDashboardAggrRequest){
        log.info("Getting first Provider Group Id for Super User : {}", ProgramPerformanceUtil.toJson(providerDashboardAggrRequest));
        if (!providerDashboardService.isValidateSuperUserRequest(providerDashboardAggrRequest)) {
            return Mono.error(new ProgramPerformanceException(HttpStatus.BAD_REQUEST, APIErrorCode.INVALID_SUPER_USER_PROVIDER_GROUP_ID));
        }
        return stargateStandardResponseUtilV2.generateStargateStandardResponse(providerDashboardService.
                findSuperUserProvGrpId(providerDashboardAggrRequest).publishOn(Schedulers.fromExecutor(taskExecutor)),
                TypeEnum.MONO, new SuperUserProviderGroupDataResponse())
                .cast(SuperUserProviderGroupDataResponse.class);
    }

    @GetMapping(path = "/refresh/super-user-data")
    public Mono<ListResponse> calcSuperUserProvGrp(){
        log.info("Refresh Super user provider data started");
        Integer refreshDataCount = providerDashboardService.calcSuperUserProvGrp();
        return stargateStandardResponseUtilV2.generateStargateStandardResponse(Mono.just(refreshDataCount), TypeEnum.MONO,
                new ListResponse()).cast(ListResponse.class);
    }

    @PostMapping(path = "/clearCache", produces = {MediaType.APPLICATION_JSON_VALUE})
    public Mono<String> clearCache(@RequestParam String uuid){
        String cacheStatus = "No Cache or cache cleared already for the UUID: ";
        log.info("Clearing the cache started for UUID : {}", uuid);
        List<String> traceIds = providerDashboardService.getTraceIds(uuid);

        if (!CollectionUtils.isEmpty(traceIds)) {
            cacheStatus = providerDashboardService.clearTraceIds(traceIds);
            cacheStatus = cacheStatus.concat(uuid);
        } else {
            cacheStatus = cacheStatus.concat(uuid);
            return Mono.just(cacheStatus);
        }
        return Mono.just(cacheStatus);
    }
}
