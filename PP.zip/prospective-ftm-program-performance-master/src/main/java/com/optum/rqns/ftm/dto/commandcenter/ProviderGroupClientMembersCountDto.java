package com.optum.rqns.ftm.dto.commandcenter;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class ProviderGroupClientMembersCountDto {
    private String name;
    private Long totalMembership;
    private Long eligibleMembership;
    private Long programEligibleMembercount;
    private List<LineOfBusinessDto> lobs = new ArrayList<>();
    public void addToLobs(LineOfBusinessDto lob) {
        List<LineOfBusinessDto> newLobs = new ArrayList<>();
        if (lobs != null && !lobs.isEmpty())
            newLobs.addAll(lobs);
        if (lob != null)
            newLobs.add(lob);
        lobs = newLobs;
    }
    @Getter
    @Setter
    @ToString
    public static class LineOfBusinessDto {
        private String lob;
        private Long totalMembership;
        private Long eligibleMembership;
        private int isIdmTarget;
        private Long programEligibleMembercount;
    }
}