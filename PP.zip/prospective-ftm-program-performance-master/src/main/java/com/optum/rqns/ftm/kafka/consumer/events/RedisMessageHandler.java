package com.optum.rqns.ftm.kafka.consumer.events;

import org.springframework.data.redis.connection.Message;
import org.springframework.data.redis.connection.MessageListener;
import org.springframework.lang.Nullable;

public interface RedisMessageHandler extends MessageListener {
     void handleMessage(String jobEvent);

}
