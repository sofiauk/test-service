package com.optum.rqns.ftm.kafka.producer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.rqns.ftm.enums.ExecutionWeek;
import com.optum.rqns.ftm.enums.GroupsToExecute;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.exception.APIErrorCode;
import com.optum.rqns.ftm.exception.ProgramPerformanceException;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.common.KafkaException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.kafka.core.KafkaProducerException;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Component;
import org.springframework.util.concurrent.ListenableFuture;

import java.util.Objects;
import java.util.UUID;

import java.time.Instant;
import java.util.stream.Stream;


@Component
@Slf4j
public class JobEventProducer {

    private KafkaTemplate<String, JobEvent> jobEventKafkaTemplate;

    @Value("${spring.gcpkafka.properties.topics.jobEvent}")
    public String topicName;

    @Autowired
    private StringRedisTemplate redisTemplate;

    @Autowired
    ObjectMapper mapper;

    public JobEventProducer(KafkaTemplate<String, JobEvent> kafkaTemplate) {
        this.jobEventKafkaTemplate = kafkaTemplate;
    }

    public boolean postToMsgQue(JobEvent jobEvent){
        if(!"REDIS".equalsIgnoreCase(jobEvent.getEventType().toString()))
         return this.postToKafka(jobEvent);
        else
         return this.postToRedis(jobEvent);
    }
    public boolean postToKafka(JobEvent jobEvent) {

        jobEvent.setTimeStamp (Instant.now ());

        JobName jobName = Stream.of (JobName.values ())
                .filter (v -> v.getValue ().equals (jobEvent.getJobName ()))
                .findFirst ()
                .orElse (null);

        this.validateJob(jobName,jobEvent);

        try {
            String uuid = UUID.randomUUID ().toString (); // random uuid as message key
            ListenableFuture<SendResult<String, JobEvent>> result = jobEventKafkaTemplate.send (topicName, jobName.getPartitionId (), uuid, jobEvent);
            jobEventKafkaTemplate.flush ();
            log.info ("Job Name: {} | Message Key {} | Send message success: {}.", jobName.getValue (), uuid, result.isDone ());
            return result.isDone ();
        } catch (KafkaProducerException ex) {
            log.error ("Job Name: {} | KafkaProducerException occurred while sending message to kafka topic {}.", jobName.getValue (), ex);
            throw new ProgramPerformanceException (HttpStatus.NOT_ACCEPTABLE, APIErrorCode.KAFKA_PRODUCER_EXCEPTION);
        } catch (KafkaException ex) {
            log.error ("Job Name: {} | KafkaException occurred while sending message to kafka topic {}.", jobName.getValue (), ex);
            throw new ProgramPerformanceException (HttpStatus.NOT_ACCEPTABLE, APIErrorCode.KAFKA_EXCEPTION);
        } catch (Exception ex) {
            log.error ("Job Name: {} | Exception occurred while sending message to kafka topic {}.", jobName.getValue (), ex);
        }
        return false;
    }

    public boolean postToRedis(JobEvent jobEvent){

        JobName jobName = Stream.of (JobName.values ())
                .filter (v -> v.getValue ().equals (jobEvent.getJobName ()))
                .findFirst ()
                .orElse (null);

        this.validateJob(jobName,jobEvent);
        try {
        redisTemplate.convertAndSend(jobName.getValue(),convertJobEventToString(jobEvent));
        return true;
        } catch (Exception ex) {
            log.error ("Job Name: {} | Exception occurred while sending message to redis channel {}.", jobName.getValue (), ex);
        }
        return false;
    }
private void validateJob(JobName jobName,JobEvent jobEvent){
    if (jobName == null) {
        log.error ("Job name {} is not part of Provider Group Opportunities - Job Name list, message can't be sent.", jobEvent.getJobName ());
        throw new ProgramPerformanceException (HttpStatus.NOT_ACCEPTABLE, APIErrorCode.INVALID_JOB_NAME);
    }
    if (jobEvent.getGroupsToExecute ().length () > 0) {
        if (!Stream.of (GroupsToExecute.values ()).anyMatch (v -> v.getValue ().equals (jobEvent.getGroupsToExecute ()))) {
            log.error ("Job Name: {} | GroupsToExecute {} is not part of Provider Group Opportunities - GroupsToExecute list, message can't be sent.", jobName.getValue (), jobEvent.getGroupsToExecute ());
            throw new ProgramPerformanceException (HttpStatus.NOT_ACCEPTABLE, APIErrorCode.INVALID_GROUPS_TO_EXECUTE);
        }
    }

    if (jobEvent.getExecutionWeek ().length () > 0) {
        if (!Stream.of (ExecutionWeek.values ()).anyMatch (v1 -> v1.getValue ().equals (jobEvent.getExecutionWeek ()))) {
            log.error ("Job Name: {} | ExecutionWeek {} is not part of Provider Group Opportunities - ExecutionWeek list, message can't be sent", jobName.getValue (), jobEvent.getExecutionWeek ());
            throw new ProgramPerformanceException (HttpStatus.NOT_ACCEPTABLE, APIErrorCode.INVALID_EXECUTION_WEEK);
        }
    }
}
    private String convertJobEventToString(JobEvent event) throws JsonProcessingException {
        com.optum.rqns.ftm.model.job.JobEvent eventObj = new com.optum.rqns.ftm.model.job.JobEvent(
                Objects.isNull(event.getJobName()) ? "":event.getJobName().toString(),
                Objects.isNull(event.getProgramYear()) ? 0:event.getProgramYear(),
                Objects.isNull(event.getStatus()) ? "":event.getStatus().toString(),
                Objects.isNull(event.getGroupsToExecute()) ? "":event.getGroupsToExecute().toString(),
                Objects.isNull(event.getExecutionWeek()) ? "":event.getExecutionWeek().toString(),
                null,
                Objects.isNull(event.getCascadeEvents()) ? null:event.getCascadeEvents(),
                Objects.isNull(event.getJobInput()) ? "":event.getJobInput().toString(),
                Objects.isNull(event.getFrequency()) ? "":event.getFrequency().toString(),
                Objects.isNull(event.getEventType()) ? "":event.getEventType().toString()
        );
        return mapper.writeValueAsString(eventObj);
    }
}