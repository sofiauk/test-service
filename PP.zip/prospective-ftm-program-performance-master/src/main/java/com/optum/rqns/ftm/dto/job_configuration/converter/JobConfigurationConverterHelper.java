package com.optum.rqns.ftm.dto.job_configuration.converter;

import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.Status;
import io.r2dbc.spi.Row;

import static com.optum.rqns.ftm.constants.JobConfigurationConstants.JOB_NAME;
import static com.optum.rqns.ftm.constants.JobConfigurationConstants.STATUS;

public class JobConfigurationConverterHelper {
    JobName getJobName(Row row){
        String jobName = row.get(JOB_NAME,String.class);
        return JobName.fromString(jobName);
    }
    Status getStatus(Row row){
        String status = row.get(STATUS,String.class);
        return Status.fromString(status);
    }
}
