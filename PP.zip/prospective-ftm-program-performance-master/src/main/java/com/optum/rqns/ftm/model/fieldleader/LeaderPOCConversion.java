package com.optum.rqns.ftm.model.fieldleader;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Builder
public class LeaderPOCConversion {
    private String firstName;
    private String lastName;
    private String uuid;
    private String parentUUID;
    private String role;
    private String regionMarket;
    private Double prevMonthConversionRateNew;
    private Double currentMonthConversionRateNew;
    private Double monthOverMonthChangeNew;
    private Double prevMonthConversionRateExisting;
    private Double currentMonthConversionRateExisting;
    private Double monthOverMonthChangeExisting;
    private LocalDateTime lastUpdatedDate;
}
