package com.optum.rqns.ftm.repository.memberDeploymentUpdates;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

import java.util.List;


@Slf4j
@Repository
public class PAFxMemberDeploymentUpdatesRepositoryImpl implements  PAFxMemberDeploymentUpdatesRepository {

    private DatabaseClient client;

    public PAFxMemberDeploymentUpdatesRepositoryImpl(DatabaseClient client) {
        this.client = client;
    }

    private static final String UPDATE_PAFX_MEMBER_ASSESSMENT = ";WITH PAFX_BATCH AS ( " +
            "SELECT IsDeployed " +
            ", IsProviderAssociated " +
            ", updatedDate " +
            ", updatedBy " +
            ", PafMasterUpdatedDate " +
            ", ProviderAssociationUpdatedDate " +
            ", ValidationStatus " +
            ", AssociationValidFrom " +
            ", AssociationValidTo " +
            ", ProviderGroupId " +
            ", ProviderId " +
            ", ProviderState " +
            ", ClientId " +
            ", LobName " +
            ", ProgramYear " +
            ", GlobalMemberId " +
            "FROM ProgPerf.PafExMemberAssessment " +
            "WHERE id BETWEEN :BeginId " +
            "AND :EndId ) " +
            "UPDATE PAFX_BATCH " +
            "SET IsDeployed = ( " +
            "CASE " +
            "WHEN MA.ID IS NULL " +
            "THEN 'false' " +
            "ELSE 'true' " +
            "END " +
            ") " +
            ", IsProviderAssociated = PRV_GRP_ASN.IsAssociated " +
            ", updatedDate = getUtcDate() " +
            ", updatedBy = :updatedBy  " +
            ", PafMasterUpdatedDate = getUtcDate() " +
            ", ProviderAssociationUpdatedDate = getUtcDate() " +
            ", ValidationStatus = PRV_GRP_ASN.validationStatus " +
            ", AssociationValidFrom = PRV_GRP_ASN.ValidatedDate " +
            ", AssociationValidTo = PRV_GRP_ASN.ExpirationDate " +
            "FROM PAFX_BATCH  " +
            "LEFT JOIN ProgPerf.MemberAssessment AS MA WITH (NOLOCK) " +
            "ON PAFX_BATCH.ProviderGroupId = MA.prov_group_id " +
            "AND PAFX_BATCH.ProviderState = MA.providerstate " +
            "AND PAFX_BATCH.ClientId = MA.clientid " +
            "AND PAFX_BATCH.LobName = MA.lob2 " +
            "AND PAFX_BATCH.ProgramYear = MA.project_year " +
            "AND PAFX_BATCH.GlobalMemberId = MA.mbr_glb_id " +
            "AND MA.deriveddeployed = 1 " +
            "AND UPPER(MA.RecordChangeType) <> 'DELETED' " +
            "LEFT JOIN ProgPerf.ProviderGroupAssociation AS PRV_GRP_ASN WITH (NOLOCK) " +
            "ON PAFX_BATCH.ProviderGroupId = PRV_GRP_ASN.ProviderGroupId " +
            "AND PAFX_BATCH.ProviderId = PRV_GRP_ASN.ProviderId ";

    private static final String GET_BEGIN_END_ID_RANGES =   "SELECT   " +
            "MIN(id) AS ID   " +
            "FROM   " +
            "ProgPerf.PafExMemberAssessment with (NOLOCK)   " +
            "UNION   " +
            "SELECT id AS ID FROM   " +
            "(   " +
            "SELECT   " +
            "id, ROW_NUMBER() OVER (   " +
            "ORDER BY id) AS rownum   " +
            "FROM   " +
            "ProgPerf.PafExMemberAssessment with (NOLOCK) ) AS t   " +
            "WHERE   " +
            "t.rownum % :BatchSize = 0   " +
            "UNION   " +
            "SELECT   " +
            "MAX(id) AS ID   " +
            "FROM   " +
            "ProgPerf.PafExMemberAssessment with (NOLOCK)   ";


    @AllArgsConstructor
    @Getter
    public enum ColumnNames {
        ISDEPLOYED("isDeployed"),
        IS_PROVIDER_ASSOCIATED("isproviderAssociated"),
        PROVIDERGROUP_ID("ProviderGroupId"),
        PROVIDER_STATE("ProviderState"),
        PROVIDER_ID("ProviderId"),
        CLIENT_ID("ClientId"),
        LOB_NAME("LobName"),
        PROGRAM_YEAR("ProgramYear"),
        GLOBAL_MEMBER_ID("GlobalMemberId"),
        VALIDATION_STATUS("ValidationStatus"),
        ASSOCIATION_VALID_FROM("AssociationValidFrom"),
        ASSOCIATION_VALID_TO("AssociationValidTo");

        private String columnName;
    }

    @Override
    public Mono<Integer> updateIsDeployedAndProviderGroupAssociated(Integer currentBeginId, List<Integer> batchesList) {
        log.info("updateIsDeployedAndProviderGroupAssociated   currentBeginId  {},  indexOf  {} , CurrentEndId {}  ", currentBeginId, batchesList.indexOf(currentBeginId)
                , batchesList.get(batchesList.indexOf(currentBeginId) + 1));
        return client
                .execute(UPDATE_PAFX_MEMBER_ASSESSMENT)
                .bind("updatedBy", "PAFDeployUpdate")
                .bind("BeginId", currentBeginId)
                .bind("EndId", batchesList.get(batchesList.indexOf(currentBeginId) + 1))
                .fetch()
                .rowsUpdated();
    }

    @Override
    public Mono<List<Integer>> getBeginEndIdsRangesForBatching(int batchSize) {
        log.info("getBeginEndIdsRangesForBatching batchSize:: {} ",batchSize);
        return client
                .execute(GET_BEGIN_END_ID_RANGES)
                .bind("BatchSize",batchSize)
                .as(Integer.class)
                .fetch()
                .all()
                .collectList();
    }
}
