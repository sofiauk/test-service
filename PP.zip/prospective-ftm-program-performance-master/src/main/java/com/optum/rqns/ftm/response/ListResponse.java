package com.optum.rqns.ftm.response;

import com.optum.rqns.ftm.wrapper.Meta;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
@AllArgsConstructor
@Builder
public class ListResponse<T> {
	private Meta meta;
	private List<T> data;

	public ListResponse() {
		this.meta = new Meta();
		this.data = new ArrayList<>();
	}
}
