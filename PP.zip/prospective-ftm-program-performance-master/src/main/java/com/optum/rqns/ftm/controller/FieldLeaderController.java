package com.optum.rqns.ftm.controller;

import com.optum.rqns.ftm.constants.FTMHeaders;
import com.optum.rqns.ftm.customannotation.CustomApiResponse;
import com.optum.rqns.ftm.dto.fieldleader.*;
import com.optum.rqns.ftm.enums.TypeEnum;
import com.optum.rqns.ftm.exception.APIErrorCode;
import com.optum.rqns.ftm.exception.ProgramPerformanceException;
import com.optum.rqns.ftm.model.UserInfo;
import com.optum.rqns.ftm.service.fieldleader.FieldLeaderService;
import com.optum.rqns.ftm.util.ProgramPerformanceUtil;
import com.optum.rqns.ftm.util.StargateStandardResponseUtilV2;
import com.optum.rqns.ftm.wrapper.Pagination;
import com.optum.rqns.ftm.wrapper.StargateStandardResponse;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestParam;
import reactor.core.publisher.Mono;
import java.util.List;

@Profile("rqnsFtmApi")
@RestController
@RequestMapping("/v1/field-leader")
@Slf4j
@CustomApiResponse
public class FieldLeaderController {

    @Autowired
    private FieldLeaderService fieldLeaderService;

    @Autowired
    StargateStandardResponseUtilV2<Object, Object> stargateStandardResponseUtilV2;

    @GetMapping("/leader-performance")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = IOAPerformanceDTO.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<StargateStandardResponse> getLeaderPerformance(
            @RequestHeader(value = FTMHeaders.X_USER_DETAILS) String userDetailsJson,
            @RequestParam(value = "program-year") int programYear,
            @RequestParam(value = "type") String type
    ) {
        UserInfo userInfo = (UserInfo) ProgramPerformanceUtil.jsonToPojo(userDetailsJson, UserInfo.class);
        log.info("Getting IOA Performance YTD for uuid {}", userInfo.getUuid());

        return stargateStandardResponseUtilV2
                .generateStargateStandardResponse(
                        fieldLeaderService.getLeaderPerformance(programYear, userInfo.getUuid(), type),
                        TypeEnum.MONO, new StargateStandardResponse())
                .cast(StargateStandardResponse.class);
    }

    @GetMapping("/leader-performance-rates")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = IOAPerformanceRatesDTO.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<StargateStandardResponse> getLeaderPerformanceRates(
            @RequestHeader(value = FTMHeaders.X_USER_DETAILS) String userDetailsJson,
            @RequestParam(value = "program-year") int programYear
    ) {
        UserInfo userInfo = (UserInfo) ProgramPerformanceUtil.jsonToPojo(userDetailsJson, UserInfo.class);
        log.info("Getting IOA Performance Rates for uuid {}", userInfo.getUuid());

        return stargateStandardResponseUtilV2
                .generateStargateStandardResponse(
                        fieldLeaderService.getLeaderPerformanceRates(userInfo.getUuid(), programYear),
                        TypeEnum.MONO, new StargateStandardResponse())
                .cast(StargateStandardResponse.class);
    }

    @GetMapping("/leader-poc-conversion-rates")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = POCConversionRatesDTO.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<StargateStandardResponse> getLeaderPOCConversionRates(
            @RequestHeader(value = FTMHeaders.X_USER_DETAILS) String userDetailsJson,
            @RequestParam(value = "program-year") int programYear
    ) {
        UserInfo userInfo = (UserInfo) ProgramPerformanceUtil.jsonToPojo(userDetailsJson, UserInfo.class);
        log.info("Getting POC Conversion Rates for uuid {}", userInfo.getUuid());

        return stargateStandardResponseUtilV2
                .generateStargateStandardResponse(
                        fieldLeaderService.getLeaderPOCConversionRates(userInfo.getUuid(), programYear),
                        TypeEnum.MONO, new StargateStandardResponse())
                .cast(StargateStandardResponse.class);
    }

    @GetMapping("/leader-growth-rates")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = GrowthRatesDTO.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<StargateStandardResponse> getLeaderGrowthRates(
            @RequestHeader(value = FTMHeaders.X_USER_DETAILS) String userDetailsJson,
            @RequestParam(value = "program-year") int programYear,
            @RequestParam(value = "is-my-team") boolean isMyTeam,
            @RequestParam(value = "service-levels", required = false) List<String> serviceLevels
    ) {
        UserInfo userInfo = (UserInfo) ProgramPerformanceUtil.jsonToPojo(userDetailsJson, UserInfo.class);
        log.info("Getting Growth Rates for uuid {}", userInfo.getUuid());

        return stargateStandardResponseUtilV2
                .generateStargateStandardResponse(
                        fieldLeaderService.getLeaderGrowthRates(userInfo.getUuid(), programYear, isMyTeam, serviceLevels),
                        TypeEnum.MONO, new StargateStandardResponse())
                .cast(StargateStandardResponse.class);
    }

    @GetMapping("/leader-e-modality")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = EModalityDTO.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<StargateStandardResponse> getLeaderEModality(
            @RequestHeader(value = FTMHeaders.X_USER_DETAILS) String userDetailsJson,
            @RequestParam(value = "program-year") int programYear
    ) {
        UserInfo userInfo = (UserInfo) ProgramPerformanceUtil.jsonToPojo(userDetailsJson, UserInfo.class);
        log.info("Getting E-Modality for uuid {}", userInfo.getUuid());

        return stargateStandardResponseUtilV2
                .generateStargateStandardResponse(
                        fieldLeaderService.getLeaderEModality(userInfo.getUuid(), programYear),
                        TypeEnum.MONO, new StargateStandardResponse())
                .cast(StargateStandardResponse.class);
    }

    @GetMapping("/risk-quality-gaps-summary")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = RiskQualityGapsSummaryDTO.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<StargateStandardResponse> getRiskQualityGapsSummary(
            @RequestHeader(value = FTMHeaders.X_USER_DETAILS) String userDetailsJson,
            @RequestParam("program-year") int programYear
    ) {

        UserInfo userInfo = (UserInfo) ProgramPerformanceUtil.jsonToPojo(userDetailsJson, UserInfo.class);
        log.info("Getting Risk Quality Gaps Summary for uuid {} and program year {}", userInfo.getUuid(), programYear);

        return stargateStandardResponseUtilV2
                .generateStargateStandardResponse(
                        fieldLeaderService.getRiskQualityGapsSummary(userInfo.getUuid(),programYear),
                        TypeEnum.FLUX,
                        new StargateStandardResponse()
                )
                .cast(StargateStandardResponse.class);
    }

    @GetMapping("/quality-gaps")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = QualityGapsDTO.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<StargateStandardResponse> getQualityGaps(
            @RequestHeader(value = FTMHeaders.X_USER_DETAILS) String userDetailsJson,
            @RequestParam("program-year") int programYear,
            @RequestParam("sort-column") String sortColumn,
            @RequestParam("sort-order") String sortOrder,
            @RequestParam("offset") int offset,
            @RequestParam("limit") int limit
    ) {

        UserInfo userInfo = (UserInfo) ProgramPerformanceUtil.jsonToPojo(userDetailsJson, UserInfo.class);
        log.info("Getting Quality Gaps for uuid {} and program year {}", userInfo.getUuid(), programYear);

        Pagination pagination = new Pagination();

        if (!ProgramPerformanceUtil.isValidByQualityGapSort(sortColumn) || (!sortOrder.equals("ASC") && !sortOrder.equals("DESC"))) {
            return stargateStandardResponseUtilV2.generateStargateStandardResponse(
                    Mono.error(new ProgramPerformanceException(HttpStatus.OK, APIErrorCode.INVALID_SORT_OPTION)), TypeEnum.MONO, new StargateStandardResponse())
                    .cast(StargateStandardResponse.class);
        }

        return stargateStandardResponseUtilV2
                .generateStargateStandardResponse(
                        fieldLeaderService.getQualityGaps(userInfo.getUuid(),programYear,sortColumn,sortOrder,offset,limit),
                        TypeEnum.FLUX,
                        new StargateStandardResponse()
                )
                .cast(StargateStandardResponse.class)
                .flatMap(stargateStandardResponseGenerated ->
                        fieldLeaderService.getQualityGapsCount(userInfo.getUuid(),programYear)
                                .doOnNext(qualityGapsCount -> {
                                    pagination.setTotalResults(qualityGapsCount);
                                    pagination.setOffset(offset);
                                    pagination.setLimit(limit);
                                    pagination.setTotalPageCount(qualityGapsCount % limit == 0 ?
                                            (qualityGapsCount / limit) : (qualityGapsCount / limit) + 1);
                                    stargateStandardResponseGenerated.getMeta().setPagination(pagination);
                                })
                                .then(Mono.just(stargateStandardResponseGenerated))
                );
    }

    @GetMapping("/annual-care-visits")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = AnnualCareVisitsDTO.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<StargateStandardResponse> getAnnualCareVisits(
            @RequestHeader(value = FTMHeaders.X_USER_DETAILS) String userDetailsJson,
            @RequestParam("program-year") int programYear
    ) {

        UserInfo userInfo = (UserInfo) ProgramPerformanceUtil.jsonToPojo(userDetailsJson, UserInfo.class);
        log.info("Getting Annual Care Visits for uuid {} and program year {}", userInfo.getUuid(), programYear);

        return stargateStandardResponseUtilV2
                .generateStargateStandardResponse(
                        fieldLeaderService.getAnnualCareVisits(userInfo.getUuid(),programYear),
                        TypeEnum.FLUX,
                        new StargateStandardResponse()
                )
                .cast(StargateStandardResponse.class);
    }

    @GetMapping("/suspect-conditions")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = SuspectConditionsDTO.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<StargateStandardResponse> getSuspectConditions(
            @RequestHeader(value = FTMHeaders.X_USER_DETAILS) String userDetailsJson,
            @RequestParam("program-year") int programYear
    ) {

        UserInfo userInfo = (UserInfo) ProgramPerformanceUtil.jsonToPojo(userDetailsJson, UserInfo.class);
        log.info("Getting Suspect Conditions for uuid {} and program year {}", userInfo.getUuid(), programYear);

        return stargateStandardResponseUtilV2
                .generateStargateStandardResponse(
                        fieldLeaderService.getSuspectConditions(userInfo.getUuid(),programYear),
                        TypeEnum.FLUX,
                        new StargateStandardResponse()
                )
                .cast(StargateStandardResponse.class);
    }

    @GetMapping(value = "/leader-ioa-performance", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = SuspectConditionsDTO.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<StargateStandardResponse> getLeaderIOAPerformance(
            @RequestHeader(value = FTMHeaders.X_USER_DETAILS) String userDetailsJson,
            @RequestParam("program-year") int programYear,
            @RequestParam("client-name") List<String> clientName,
            @RequestParam("lob") List<String> lob,
            @RequestParam("service-level") List<String> serviceLevel
    ) {
        UserInfo userInfo = (UserInfo) ProgramPerformanceUtil.jsonToPojo(userDetailsJson, UserInfo.class);
        log.info("Getting IOA Leader Performance for uuid {} and program year {}", userInfo.getUuid(), programYear);

        return stargateStandardResponseUtilV2
                .generateStargateStandardResponse(
                        fieldLeaderService.getLeaderIOAPerformance(userInfo.getUuid(), programYear, clientName, lob, serviceLevel),
                        TypeEnum.FLUX,
                        new StargateStandardResponse()
                )
                .cast(StargateStandardResponse.class);

    }

    @GetMapping("/leader-ioa-performance-region")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = SuspectConditionsDTO.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<StargateStandardResponse> getLeaderIOAPerformanceRegion(
            @RequestParam("program-year") int programYear,
            @RequestParam("region") String region,
            @RequestParam("offset") int offset,
            @RequestParam("limit") int limit,
            @RequestParam("client-name") List<String> clientName,
            @RequestParam("lob") List<String> lob,
            @RequestParam("service-level") List<String> serviceLevel
    ) {

        log.info("Getting IOA Leader Performance Region for region {} and program year {}", region, programYear);

        Pagination pagination = new Pagination();

        return stargateStandardResponseUtilV2
                .generateStargateStandardResponse(
                        fieldLeaderService.getLeaderIOAPerformanceRegion(region, programYear, offset, limit, clientName, lob, serviceLevel),
                        TypeEnum.FLUX,
                        new StargateStandardResponse()
                )
                .cast(StargateStandardResponse.class)
                .flatMap(stargateStandardResponseGenerated ->
                        fieldLeaderService.getLeaderIOAPerformanceRegionCount(region, programYear, clientName, lob, serviceLevel)
                                .doOnNext(qualityGapsCount -> {
                                    pagination.setTotalResults(qualityGapsCount);
                                    pagination.setOffset(offset);
                                    pagination.setLimit(limit);
                                    pagination.setTotalPageCount(qualityGapsCount % limit == 0 ?
                                            (qualityGapsCount / limit) : (qualityGapsCount / limit) + 1);
                                    stargateStandardResponseGenerated.getMeta().setPagination(pagination);
                                })
                                .then(Mono.just(stargateStandardResponseGenerated))
                );

    }

    @GetMapping(value = "/leader-ioa-performance-team", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = SuspectConditionsDTO.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<StargateStandardResponse> getLeaderIOAPerformanceMyTeam(
            @RequestHeader(value = FTMHeaders.X_USER_DETAILS) String userDetailsJson,
            @RequestParam("program-year") int programYear,
            @RequestParam("client-name") List<String> clientName,
            @RequestParam("lob") List<String> lob,
            @RequestParam("service-level") List<String> serviceLevel
    ) {

        UserInfo userInfo = (UserInfo) ProgramPerformanceUtil.jsonToPojo(userDetailsJson, UserInfo.class);
        log.info(
                "Getting My Team's IOA Leader Performance for uuid {} and program year {}",
                userInfo.getUuid(),
                programYear
        );

        return stargateStandardResponseUtilV2
                .generateStargateStandardResponse(
                        fieldLeaderService.getLeaderIOAPerformanceMyTeam(
                                userInfo.getUuid(),
                                programYear,
                                clientName,
                                lob,
                                serviceLevel
                        ),
                        TypeEnum.FLUX,
                        new StargateStandardResponse()
                )
                .cast(StargateStandardResponse.class);
    }

    @GetMapping("/leader-poc-conversion")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = SuspectConditionsDTO.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<StargateStandardResponse> getLeaderPOCConversion(
            @RequestHeader(value = FTMHeaders.X_USER_DETAILS) String userDetailsJson,
            @RequestParam("program-year") int programYear,
            @RequestParam(value = "applied-filters", required = false) List<String> appliedFilters
    ) {

        UserInfo userInfo = (UserInfo) ProgramPerformanceUtil.jsonToPojo(userDetailsJson, UserInfo.class);
        log.info("Getting Leader POC Conversion for uuid {} and program year {}", userInfo.getUuid(), programYear);

        return stargateStandardResponseUtilV2
                .generateStargateStandardResponse(
                        fieldLeaderService.getLeaderPOCConversion(programYear, userInfo.getUuid(), appliedFilters),
                        TypeEnum.FLUX,
                        new StargateStandardResponse()
                )
                .cast(StargateStandardResponse.class);

    }

    @GetMapping("/leader-poc-conversion-region")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = SuspectConditionsDTO.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<StargateStandardResponse> getLeaderPOCConversionRegion(
            @RequestParam("program-year") int programYear,
            @RequestParam("region") String region,
            @RequestParam(value = "applied-filters", required = false) List<String> appliedFilters
    ) {

        log.info("Getting Leader POC Conversion Region for region {} and program year {}", region, programYear);

        return stargateStandardResponseUtilV2
                .generateStargateStandardResponse(
                        fieldLeaderService.getLeaderPOCConversionRegion(programYear,region,appliedFilters),
                        TypeEnum.FLUX,
                        new StargateStandardResponse()
                )
                .cast(StargateStandardResponse.class);

    }

    @GetMapping("/leader-poc-conversion-team")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = SuspectConditionsDTO.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<StargateStandardResponse> getLeaderPOCConversionMyTeam(
            @RequestHeader(value = FTMHeaders.X_USER_DETAILS) String userDetailsJson,
            @RequestParam("program-year") int programYear,
            @RequestParam(value = "applied-filters", required = false) List<String> appliedFilters
    ) {

        UserInfo userInfo = (UserInfo) ProgramPerformanceUtil.jsonToPojo(userDetailsJson, UserInfo.class);
        log.info("Getting My Team's Leader POC Conversion for uuid {} and program year {}", userInfo.getUuid(), programYear);

        return stargateStandardResponseUtilV2
                .generateStargateStandardResponse(
                        fieldLeaderService.getLeaderPOCConversionMyTeam(programYear, userInfo.getUuid(), appliedFilters),
                        TypeEnum.FLUX,
                        new StargateStandardResponse()
                )
                .cast(StargateStandardResponse.class);

    }

    @GetMapping("/leader-filter")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = SuspectConditionsDTO.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<StargateStandardResponse> getLeaderFilter(
            @RequestHeader(value = FTMHeaders.X_USER_DETAILS) String userDetailsJson,
            @RequestParam("program-year") int programYear,
            @RequestParam("resource") String resource,
            @RequestParam("type") String type
    ) {

        UserInfo userInfo = (UserInfo) ProgramPerformanceUtil.jsonToPojo(userDetailsJson, UserInfo.class);
        log.info("Getting Service Level filter values for uuid {} and program year {}", userInfo.getUuid(), programYear);

        return stargateStandardResponseUtilV2
                .generateStargateStandardResponse(
                        fieldLeaderService.getLeaderFilter(programYear, resource, type),
                        TypeEnum.FLUX,
                        new StargateStandardResponse()
                )
                .cast(StargateStandardResponse.class);

    }

    @GetMapping(value = "/leader-e-modality-details", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = LeaderEModalityDTO.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<StargateStandardResponse> getLeaderEModalityDetails(
            @RequestHeader(value = FTMHeaders.X_USER_DETAILS) String userDetailsJson,
            @RequestParam("program-year") int programYear,
            @RequestParam("client-name") List<String> clientName,
            @RequestParam("lob") List<String> lob,
            @RequestParam("service-level") List<String> serviceLevel
    ) {
        UserInfo userInfo = (UserInfo) ProgramPerformanceUtil.jsonToPojo(userDetailsJson, UserInfo.class);
        log.info("Getting E-Modality Details for uuid {} and program year {}", userInfo.getUuid(), programYear);

        return stargateStandardResponseUtilV2
                .generateStargateStandardResponse(
                        fieldLeaderService.getLeaderEModalityDetails(userInfo.getUuid(), programYear, clientName, lob, serviceLevel),
                        TypeEnum.FLUX,
                        new StargateStandardResponse()
                )
                .cast(StargateStandardResponse.class);

    }

    @GetMapping(value = "/leader-e-modality-details-region", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = LeaderEModalityDTO.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<StargateStandardResponse> getLeaderEModalityDetailsByRegion(
            @RequestHeader(value = FTMHeaders.X_USER_DETAILS) String userDetailsJson,
            @RequestParam("program-year") int programYear,
            @RequestParam("region") String region,
            @RequestParam("client-name") List<String> clientName,
            @RequestParam("lob") List<String> lob,
            @RequestParam("service-level") List<String> serviceLevel
    ) {
        UserInfo userInfo = (UserInfo) ProgramPerformanceUtil.jsonToPojo(userDetailsJson, UserInfo.class);
        log.info("Getting E-Modality Details By Region for uuid {} and program year {}", userInfo.getUuid(), programYear);

        return stargateStandardResponseUtilV2
                .generateStargateStandardResponse(
                        fieldLeaderService.getLeaderEModalityDetailsByRegion(userInfo.getUuid(), programYear, clientName, lob, serviceLevel, region),
                        TypeEnum.FLUX,
                        new StargateStandardResponse()
                )
                .cast(StargateStandardResponse.class);

    }

    @GetMapping(value = "/leader-e-modality-details-team", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = LeaderEModalityDTO.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<StargateStandardResponse> getLeaderEModalityDetailsByTeam(
            @RequestHeader(value = FTMHeaders.X_USER_DETAILS) String userDetailsJson,
            @RequestParam("program-year") int programYear,
            @RequestParam("client-name") List<String> clientName,
            @RequestParam("lob") List<String> lob,
            @RequestParam("service-level") List<String> serviceLevel
    ) {
        UserInfo userInfo = (UserInfo) ProgramPerformanceUtil.jsonToPojo(userDetailsJson, UserInfo.class);
        log.info("Getting E-Modality Details By Team for uuid {} and program year {}", userInfo.getUuid(), programYear);

        return stargateStandardResponseUtilV2
                .generateStargateStandardResponse(
                        fieldLeaderService.getLeaderEModalityDetailsByTeam(userInfo.getUuid(), programYear, clientName, lob, serviceLevel),
                        TypeEnum.FLUX,
                        new StargateStandardResponse()
                )
                .cast(StargateStandardResponse.class);

    }
}
