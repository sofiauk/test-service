package com.optum.rqns.ftm.model.fieldleader;

import lombok.Builder;
import lombok.Data;
import org.springframework.data.relational.core.mapping.Table;

import java.time.LocalDateTime;

@Data
@Builder
@Table("ProgPerf.LeaderGrowthRatePOCEModality")
public class LeaderEModality {
    private Integer returnNetCnaActualPer;
    private Integer retrievedByOPAF;
    private Integer retrievedByOptumUpload;
    private Integer retrievedByOgm;
    private Integer retrievedByEdata;
    private LocalDateTime updatedDate;
}
