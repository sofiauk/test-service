package com.optum.rqns.ftm.repository.roleBasedAccess;


import com.optum.rqns.ftm.enums.RoleType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

@Repository
public class RoleBasedAccessRepositoryImpl implements RoleBasedAccessRepository {

    @Autowired
    private DatabaseClient client;

    private final static String TOLL_GATE_ACCESS = "select     " +
            "    case when count(A.GroupId)>0 then 1 else 0 end     " +
            "from       " +
            "    ProgPerf.Accounts A        " +
            "inner Join ProgPerf.AccountOwner AO on     " +
            "    A.AccountId = AO.AccountId     " +
            "where          " +
            "    AO.OwnerUUID = :LoggedInUserUUID       " +
            "    and        " +
            "    GroupId = :ProviderGroupID     " +
            "    and State = :State        ";

    private final static String TOLL_GATE_ACCESS_MANAGER = "    SELECT  " +
            "case when count(A.GroupId)>0 then 1 else 0 end  " +
            "FROM  " +
            "ProgPerf.Accounts A  " +
            "INNER JOIN ProgPerf.AccountOwner AO ON  " +
            "A.AccountId = AO.AccountId " +
            "INNER JOIN ProgPerf.Users U ON     " +
            "AO.OwnerUUID = U.UUID      " +
            "WHERE      " +
            "GroupId = :ProviderGroupID     " +
            "AND State = :State     " +
            "AND U.ManagerUuid = :LoggedInUserUUID      " +
            "   AND JSON_VALUE(u.[Role] , '$[0].name') in ('HCA', 'PSC')    ";


    @Override
    public Mono<Boolean> isTollgateAccessible(String uuid, String groupId, String state, String role) {

        String final_query = null;

        if( RoleType.HCA.equals(RoleType.fromString(role)) || RoleType.PSC.equals(RoleType.fromString(role)) ){
            final_query= TOLL_GATE_ACCESS;
        }
        else if (RoleType.MANAGER.equals(RoleType.fromString(role))) {
            final_query = TOLL_GATE_ACCESS_MANAGER;
        }
        return client.execute(final_query)
                .bind("LoggedInUserUUID",uuid)
                .bind("ProviderGroupID",groupId)
                .bind("State",state)
                .as(Boolean.class)
                .fetch()
                .one();
    }

}
