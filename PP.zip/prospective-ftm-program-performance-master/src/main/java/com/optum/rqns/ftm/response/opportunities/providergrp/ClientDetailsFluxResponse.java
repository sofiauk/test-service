package com.optum.rqns.ftm.response.opportunities.providergrp;

import com.optum.rqns.ftm.model.opportunities.providergrp.ClientLobFilterDetails;
import com.optum.rqns.ftm.wrapper.Meta;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.ToString;

import java.util.ArrayList;
import java.util.List;



@Data
@ToString
@AllArgsConstructor
@Builder
public class ClientDetailsFluxResponse{
    private Meta meta;

    private List<ClientLobFilterDetails> data;
    public ClientDetailsFluxResponse(){
        this.meta = new Meta();
        this.data = new ArrayList<>();
    }

}
