package com.optum.rqns.ftm.dto.export.converter;

import com.optum.rqns.ftm.enums.DocumentType;
import com.optum.rqns.ftm.enums.ExportStatus;
import com.optum.rqns.ftm.enums.ProcessSubType;
import com.optum.rqns.ftm.enums.ProcessType;
import io.r2dbc.spi.Row;
import lombok.extern.slf4j.Slf4j;

import static com.optum.rqns.ftm.repository.exports.ExportRepositoryImpl.Columns.DOCUMENT_TYPE;
import static com.optum.rqns.ftm.repository.exports.ExportRepositoryImpl.Columns.EXPORT_STATUS;
import static com.optum.rqns.ftm.repository.exports.ExportRepositoryImpl.Columns.PROCESS_SUB_TYPE;
import static com.optum.rqns.ftm.repository.exports.ExportRepositoryImpl.Columns.PROCESS_TYPE;


@Slf4j
class ExportsDTOConverterHelper {

    ProcessType getProcessType(Row row) {
        String sProcessType = row.get(PROCESS_TYPE.getValue(), String.class);
        return ProcessType.fromString(sProcessType);
    }

    ProcessSubType getProcessSubType(Row row) {
        String sProcessSubType = row.get(PROCESS_SUB_TYPE.getValue(), String.class);
        return ProcessSubType.fromString(sProcessSubType);
    }

    DocumentType getDocumentType(Row row) {
        String sDocumentType = row.get(DOCUMENT_TYPE.getValue(), String.class);
        return DocumentType.fromString(sDocumentType);
    }

    ExportStatus getExportStatus(Row row) {
        String sExportStatus = row.get(EXPORT_STATUS.getValue(), String.class);
        return ExportStatus.fromString(sExportStatus);
    }
}
