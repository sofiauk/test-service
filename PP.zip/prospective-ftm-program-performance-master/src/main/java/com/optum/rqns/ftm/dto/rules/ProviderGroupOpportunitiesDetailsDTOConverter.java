package com.optum.rqns.ftm.dto.rules;

import com.optum.rqns.ftm.repository.rules.RuleRepositoryImpl;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;

import java.time.LocalDateTime;

public class ProviderGroupOpportunitiesDetailsDTOConverter implements Converter<Row, ProviderGroupOpportunitiesDetailsDTO> {
    @Override
    public ProviderGroupOpportunitiesDetailsDTO convert(Row rs) {
        return ProviderGroupOpportunitiesDetailsDTO.builder()
                .opportunityDetailID(rs.get(RuleRepositoryImpl.ColumnNames.ID.getColumnName(), Integer.class))
                .serviceLevel(rs.get(RuleRepositoryImpl.ColumnNames.SERVICELEVEL.getColumnName(), String.class))
                .clientId(rs.get(RuleRepositoryImpl.ColumnNames.CLIENT_ID.getColumnName(), String.class))
                .lobName(rs.get(RuleRepositoryImpl.ColumnNames.LOBNAME.getColumnName(), String.class))
                .clientName(rs.get(RuleRepositoryImpl.ColumnNames.CLIENTNAME.getColumnName(), String.class))
                .opportunityType(rs.get(RuleRepositoryImpl.ColumnNames.OPPORTUNITYTYPE.getColumnName(), String.class))
                .opportunitySubType(rs.get(RuleRepositoryImpl.ColumnNames.OPPORTUNITYSUBTYPE.getColumnName(), String.class))
                .opportunityTypePosition(rs.get(RuleRepositoryImpl.ColumnNames.OPPORTUNITYTYPEPOSITION.getColumnName(), Integer.class))
                .opportunitySubTypePosition(rs.get(RuleRepositoryImpl.ColumnNames.OPPORTUNITYSUBTYPEPOSITION.getColumnName(), Integer.class))
                .latestUpdatedDate(rs.get(RuleRepositoryImpl.ColumnNames.LATESTUPDATEDDATE.getColumnName(), LocalDateTime.class))
                .displayText(rs.get(RuleRepositoryImpl.ColumnNames.DISPLAYTEXT.getColumnName(), String.class))
                .assessmentCount(rs.get(RuleRepositoryImpl.ColumnNames.ASSESSMENTCOUNT.getColumnName(), Integer.class))
                .deploymentCount(rs.get(RuleRepositoryImpl.ColumnNames.DEPLOYMENTCOUNT.getColumnName(), Integer.class))
                .gapCount(rs.get(RuleRepositoryImpl.ColumnNames.GAPCOUNT.getColumnName(), Integer.class))
                .build();

    }
}