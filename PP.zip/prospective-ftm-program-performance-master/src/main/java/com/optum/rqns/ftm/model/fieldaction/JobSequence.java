package com.optum.rqns.ftm.model.fieldaction;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;


@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class JobSequence {

    private List<JobDetails> cascadedJobs;

}
