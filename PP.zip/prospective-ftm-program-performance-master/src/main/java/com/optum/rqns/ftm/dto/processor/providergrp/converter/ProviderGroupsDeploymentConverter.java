package com.optum.rqns.ftm.dto.processor.providergrp.converter;

import com.optum.rqns.ftm.constants.ProviderGroupConstants;
import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.model.providergrpdeployment.ProviderGroupsDeployment;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;

public class ProviderGroupsDeploymentConverter implements Converter<Row, ProviderGroupsDeployment>, DTOWrapperTypeConverter {
    @Override
    public ProviderGroupsDeployment convert(Row row) {

        return ProviderGroupsDeployment.builder()
                .providerGroupID(row.get(ProviderGroupConstants.PROVIDER_GROUP_ID, String.class))
                .state(row.get(ProviderGroupConstants.PROVIDER_STATE, String.class))
                .programYear(row.get(ProviderGroupConstants.PROGRAM_YEAR, Integer.class))
                .deploymentsCount(row.get(ProviderGroupConstants.DEPLOYMENTS_COUNT, Integer.class))
                .returnsCount(row.get(ProviderGroupConstants.RETURNS_COUNT, Integer.class))
                .returnsNetCnaCount(row.get(ProviderGroupConstants.RETURNSNETCNA_COUNT, Integer.class))
                .build();
    }
}

