package com.optum.rqns.ftm.repository.processor.providergrp;

import com.optum.rqns.ftm.dto.processor.providergrp.ProgramYearCalendarDTO;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface ProviderGroupHistoricalYTDActualProcessorRepository {
    Flux<ProgramYearCalendarDTO> getAllProgramYearDurations(int programYear);
    Flux<ProgramYearCalendarDTO> getPrevoiusYearLastWeekDuration(int programYear);
    Mono<Integer> calculateActual(ProgramYearCalendarDTO dto, boolean isAllProviderGroups);
    Mono<Integer> calculatePGPWeeklyActual(ProgramYearCalendarDTO dto, boolean isAllProviderGroups);
    Mono<Integer> calculateCurrentWeekActuals(ProgramYearCalendarDTO dto);
    Mono<Integer> calculatePreviousWeekActuals(ProgramYearCalendarDTO dto);
    Mono<Integer> calculateCCPActual(ProgramYearCalendarDTO dto);
    Mono<Integer> resetZeroedDeployments(ProgramYearCalendarDTO programYearCalendarDTO);
}
