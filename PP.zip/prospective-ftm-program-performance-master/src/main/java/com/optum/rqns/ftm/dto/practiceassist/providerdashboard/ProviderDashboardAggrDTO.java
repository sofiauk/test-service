package com.optum.rqns.ftm.dto.practiceassist.providerdashboard;

import lombok.Data;

import java.util.List;

@Data
public class ProviderDashboardAggrDTO {

    private String pgmAsesYr;
    private List<String> provGrpId;
    private List<String> healthSystemIds;
    private List<String> pcpId;
    private List<String> stCd;
    private List<Integer> subCliSk;
    private List<String> clientId;
}
