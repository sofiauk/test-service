package com.optum.rqns.ftm.dto.fieldleader;


import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Builder
public class LeaderEModalityDTO {
    private String firstName;
    private String lastName;
    private String uuid;
    private String parentUUID;
    private String role;
    private String regionMarket;
    private Double currentYearOpaf;
    private Double currentYearOptumUpload;
    private Double currentYearOgm;
    private Double currentYearEData;
    private Double previousYearOpaf;
    private Double previousYearOptumUpload;
    private Double previousYearOgm;
    private Double previousYearEData;
    private LocalDateTime lastUpdatedDate;
}
