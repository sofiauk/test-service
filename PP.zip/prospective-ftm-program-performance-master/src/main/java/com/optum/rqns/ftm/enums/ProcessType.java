package com.optum.rqns.ftm.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum ProcessType {
    OUTLIERS("Outliers"),
    MEMBER_ASSESSMENT("MemberAssessment"),
    QUALITY_GAPS("Quality Gaps"),
    SUSPECT_CONDITIONS("Suspect Conditions"),
    ANNUAL_CARE_VISITS("Annual Care Visits"),
    MEDICATION_ADHERENCE("Medication Adherence");
    String value;

    public static ProcessType fromString(String text) {
        for (ProcessType processType : ProcessType.values()) {
            if (processType.value.equalsIgnoreCase(text)) {
                return processType;
            }
        }
        return null;
    }
}
