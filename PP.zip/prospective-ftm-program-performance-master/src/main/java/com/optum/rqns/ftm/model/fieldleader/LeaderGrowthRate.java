package com.optum.rqns.ftm.model.fieldleader;

import lombok.Builder;
import lombok.Data;
import org.springframework.data.relational.core.mapping.Table;

import java.time.LocalDateTime;

@Data
@Builder
@Table("ProgPerf.LeaderGrowthRatePOCEModality")
public class LeaderGrowthRate {
    private String parentScope;
    private String scope;
    private String firstName;
    private String lastName;
    private String role;
    private boolean isCurrentYear;
    private Integer totalGroupsSum;
    private Integer agreedParticipateSum;
    private Integer engagedParticipateSum;
    private LocalDateTime updatedDate;
}
