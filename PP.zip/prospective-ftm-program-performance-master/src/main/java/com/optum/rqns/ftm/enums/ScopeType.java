package com.optum.rqns.ftm.enums;

public enum ScopeType {
    NATIONAL,
    CURRENT_USER,
    MY_TEAM,
    REGION_AND_STATE
}
