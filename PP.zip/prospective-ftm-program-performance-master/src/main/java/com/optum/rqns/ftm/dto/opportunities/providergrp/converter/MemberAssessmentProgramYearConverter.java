package com.optum.rqns.ftm.dto.opportunities.providergrp.converter;

import com.optum.rqns.ftm.constants.ProviderGroupConstants;
import com.optum.rqns.ftm.model.opportunities.providergrp.MemberAssessmentProgramYears;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;

public class MemberAssessmentProgramYearConverter implements Converter<Row, MemberAssessmentProgramYears> {

    @Override
    public MemberAssessmentProgramYears convert(Row row) {
        return MemberAssessmentProgramYears.builder()
                .programYear(row.get(ProviderGroupConstants.PROGRAM_YEAR, Integer.class))
                .build();
    }
}
