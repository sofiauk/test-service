package com.optum.rqns.ftm.repository.opportunities.providergrp;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Repository;

import com.optum.rqns.ftm.constants.ProviderGroupConstants;
import com.optum.rqns.ftm.dto.opportunities.providergrp.MeasuresThresholdConfigurationDTO;
import com.optum.rqns.ftm.dto.opportunities.providergrp.MemberACVDTO;
import com.optum.rqns.ftm.dto.opportunities.providergrp.MemberAssessmentDTO;
import com.optum.rqns.ftm.dto.opportunities.providergrp.MemberQualityGapDTO;
import com.optum.rqns.ftm.dto.opportunities.providergrp.MemberSuspectConditionDTO;
import com.optum.rqns.ftm.dto.opportunities.providergrp.MemberSuspectPatientsDTO;
import com.optum.rqns.ftm.dto.opportunities.providergrp.OpportunitiesDetailsDTO;
import com.optum.rqns.ftm.dto.opportunities.providergrp.OpportunityConfigurationDTO;
import com.optum.rqns.ftm.enums.ServiceLevel;
import com.optum.rqns.ftm.model.opportunities.exports.CategoryMasterConfigDTO;
import com.optum.rqns.ftm.model.opportunities.providergrp.ClientsFilterDetails;
import com.optum.rqns.ftm.model.opportunities.providergrp.ClientsRequestBody;
import com.optum.rqns.ftm.model.opportunities.providergrp.DetailsRequestBody;
import com.optum.rqns.ftm.model.opportunities.providergrp.LobFilterDetails;
import com.optum.rqns.ftm.model.opportunities.providergrp.MemberAssessment;
import com.optum.rqns.ftm.model.opportunities.providergrp.MemberAssessmentClients;
import com.optum.rqns.ftm.model.opportunities.providergrp.MemberAssessmentLobs;
import com.optum.rqns.ftm.model.opportunities.providergrp.MemberAssessmentOpportunitySubTypes;
import com.optum.rqns.ftm.model.opportunities.providergrp.MemberAssessmentProgramYears;
import com.optum.rqns.ftm.model.opportunities.providergrp.OpportunitiesDetails;
import com.optum.rqns.ftm.model.opportunities.providergrp.OpportunitiesSummaryDetails;
import com.optum.rqns.ftm.model.opportunities.providergrp.PAConfigDetails;
import com.optum.rqns.ftm.model.opportunities.providergrp.ProviderGroupMemberGaps;
import com.optum.rqns.ftm.model.opportunities.providergrp.QFOHealthSystemDetailsRequestBody;
import com.optum.rqns.ftm.model.opportunities.providergrp.QFOHealthSystemOpportunitiesDetails;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.optum.rqns.ftm.constants.ProviderGroupConstants.*;

@Slf4j
@Repository
public class OpportunitiesRepositoryImpl implements OpportunitiesRepository {

    private static final Integer BATCH_SIZE = 1000;

    private final DatabaseClient opportunityClient;

    public OpportunitiesRepositoryImpl(DatabaseClient client) {
        this.opportunityClient = client;
    }

    private static final String MQ_CLIENT_ID =" AND mq.CLIENT_ID in(";
    private static final String MQ_LOB_NAME = " AND mq.LOB_NAME in(";
    private static final String QFO_LOB_NAME = " AND LINE_OF_BUSINESS in(";
    private static final String AND = " AND ";

    private static final String SELECT_MEMBER_ASSESSMENTS_COUNTS = "SELECT count(m.mem_id) as count FROM  PROGPERF.MemberAssessment M WITH (NOLOCK), " +
            "PROGPERF.MemberAssessmentOpportunity MO WHERE MO.CHARTID = M.CHART_ID AND MO.PROGRAMYEAR = M.PROJECT_YEAR AND MO.MasterOpportunityType=:OPPORTUNITYTYPE " +
            "AND MO.PROVIDERGROUPID=:PROVIDERGROUPID AND MO.STATE=:STATE AND MO.SERVICELEVEL=:SERVICELEVEL %s";
    /* Enable count query when require overlapping years */
    /*private static final String SELECT_MEMBER_ASSESSMENTS_WITH_MEMHISTORY_COUNTS = "SELECT count(MH.mem_id) as count FROM PROGPERF.MemberAssessmentHistory MH WITH (NOLOCK), " +
            "PROGPERF.MemberAssessmentOpportunity MO WHERE MO.CHARTID = MH.CHART_ID AND MO.MasterOpportunityType=:OPPORTUNITYTYPE " +
            "AND MO.PROVIDERGROUPID=:PROVIDERGROUPID AND MO.STATE=:STATE AND MO.SERVICELEVEL=:SERVICELEVEL %s";*/

    private static final String SELECT_MEMBER_ASSESSMENTS = "SELECT MSO.LOBName as lobname,MSO.programyear as programyear ,MS.CHART_ID as CHARTID, MS.deployDate as DEPLOYDATE, MS.retrieval_date as RETURNDATE, " +
            "MS.mem_id as MEMBERID, MS.dob as MEMBERDOB, MS.provname as PROVIDERNAME, MS.ClientNameOFCStandard as CLIENT, " +
            "CONCAT(UPPER(LEFT(MS.mbrlastname,1))+LOWER(SUBSTRING(MS.mbrlastname,2,LEN(MS.mbrlastname))), ', ', UPPER(LEFT(MS.mbrfirstname,1))+LOWER(SUBSTRING(MS.mbrfirstname,2,LEN(MS.mbrfirstname)))) AS MEMBERNAME," +
            "MS.IsSecondarySubmissionEligible as ISSECONDARYSUBMISSION, MS.IsGAThresholdMet as ISGAMET, MS.IsDVThresholdMet as ISDVMET, MS.IsCGapCriteriaMet as ISCGAPMET, " +
            "MSO.OpportunityType as OPPORTUNITYTYPE, MSO.OpportunitySubType as OPPORTUNITYREASON, MS.EligibleProgramType as ELIGIBLEPROGRAMTYPE, MS.CPG as CPG" +
            " FROM  PROGPERF.MemberAssessment MS, PROGPERF.MemberAssessmentOpportunity MSO  WITH (NOLOCK) " +
            " WHERE MSO.CHARTID = MS.CHART_ID AND MSO.PROGRAMYEAR = MS.PROJECT_YEAR AND MSO.MasterOpportunityType=:OPPORTUNITYTYPE" +
            " AND MSO.PROVIDERGROUPID=:PROVIDERGROUPID AND MSO.STATE=:STATE AND MSO.SERVICELEVEL=:SERVICELEVEL AND MSO.PROGRAMYEAR=:programYear %s ";
    /* Enable MA query when require overlapping years */
    /*private static final String SELECT_MEMBER_ASSESSMENTS_WITH_MEMHISTORY  = " SELECT MSH.CHART_ID as CHARTID, MSH.deployDate as DEPLOYDATE, MSH.retrieval_date as RETURNDATE, MSH.mem_id as MEMBERID, " +
            "MSH.dob as MEMBERDOB, MSH.provname as PROVIDERNAME, MSH.client as CLIENT, " +
            "CONCAT(UPPER(LEFT(MSH.mbrlastname,1))+LOWER(SUBSTRING(MSH.mbrlastname,2,LEN(MSH.mbrlastname))), ', ', UPPER(LEFT(MSH.mbrfirstname,1))+LOWER(SUBSTRING(MSH.mbrfirstname,2,LEN(MSH.mbrfirstname)))) AS MEMBERNAME," +
            " MSH.IsSecondarySubmissionEligible as ISSECONDARYSUBMISSION, MSH.IsGAThresholdMet as ISGAMET, " +
            "MSH.IsDVThresholdMet as ISDVMET, MSH.IsCGapCriteriaMet as ISCGAPMET, MSO.OpportunityType as OPPORTUNITYTYPE, MSO.OpportunitySubType as OPPORTUNITYREASON  " +
            "FROM  PROGPERF.MemberAssessmentHistory MSH WITH (NOLOCK), " +
            "PROGPERF.MemberAssessmentOpportunity MSO WHERE MSO.CHARTID = MSH.CHART_ID AND MSO.MasterOpportunityType=:OPPORTUNITYTYPE" +
            " AND MSO.PROVIDERGROUPID=:PROVIDERGROUPID AND MSO.STATE=:STATE AND MSO.SERVICELEVEL=:SERVICELEVEL %s ";*/

    private static final String SELECT_MEMBER_GAPS = "SELECT LOBName as lobname,programyear as programyear, ChartID as CHARTID, ProviderName as PROVIDERNAME, ClientName as CLIENT, MemberId as MEMBERID, MemberDob as MEMBERDOB, CONCAT(UPPER(LEFT(MemberLastName,1))+LOWER(SUBSTRING(MemberLastName,2,LEN(MemberLastName))), ', '," +
            " UPPER(LEFT(MemberFirstName,1))+LOWER(SUBSTRING(MemberFirstName,2,LEN(MemberFirstName)))) AS MEMBERNAME," +
            "IsSecondarySubmissionEligible as ISSECONDARYSUBMISSION, OpportunityType as OPPORTUNITYTYPE, OpportunitySubType as OPPORTUNITYREASON," +
            "GapType as GAPTYPE, GapStatus as GAPSTATUS, GapDesc as GAPDESC, CoverSheetResponse as COVERSHEETRESPONSE, CPG as CPG, EligibleProgramType as EligibleProgramType FROM  PROGPERF.MemberAssessmentGap WITH (NOLOCK) WHERE PROVIDERGROUPID=:PROVIDERGROUPID" +
            " AND STATE=:STATE %s %s";

    private static final String SELECT_MEMBER_GAPS_COUNTS = "SELECT count(MemberID) as count FROM  PROGPERF.MemberAssessmentGap WITH (NOLOCK) WHERE PROVIDERGROUPID=:PROVIDERGROUPID" +
            " AND STATE=:STATE %s %s ";

    private static final String OPPORTUNITIES_SUMMARY_QUERY = "SELECT ID, ProviderGroupID, ProviderGroupName, State, ServiceLevel, ProgramYear, MasterLevelOpportunity, MasterLevelOpportunityPosition, TotalAssessmentsCount, TotalGapsCount, LastUpdatedDate, TotalClientsCount FROM ProgPerf.ProviderGroupOpportunitiesSummary WITH (NOLOCK) "
            + " where ProviderGroupID = :providerGroupID and State = :state and ProgramYear = :programYear order by MasterLevelOpportunityPosition Asc ";

    private static final String OPPORTUNITIES_DETAILS_QUERY = "select  " +
            "  pgs.ProviderGroupID as ProviderGroupID,  " +
            "  pgs.State as State,  " +
            "  pgs.ProgramYear as ProgramYear,  " +
            "  ClientName,  " +
            "  OpportunityType,  " +
            "  OpportunitySubType,  " +
            "  OpportunityTypePosition,  " +
            "  OpportunitySubTypePosition,  " +
            "  DisplayText,  " +
            "  SUM(AssessmentCount) as AssessmentCount,  " +
            "  SUM(DeploymentCount) as DeploymentCount,  " +
            "  SUM(GapCount) as GapCount,  " +
            "  MasterOpportunityType,  " +
            "  MasterOpportunityTypePosition ,  " +
            "  TotalAssessmentsCount,  " +
            "  TotalGapsCount,  " +
            "  MAX(pgs.LastUpdatedDate) as OpportunityLastUpdatedDate ,  " +
            "  TotalClientsCount  " +
            "from  " +
            "  ProgPerf.ProviderGroupOpportunitiesSummary pgs WITH (NOLOCK)  " +
            "join ProgPerf.ProviderGroupOpportunitiesDetail pgd WITH (NOLOCK) on  " +
            "  pgs.providergroupid = pgd.providergroupid  " +
            "  and pgs.state = pgd.state  " +
            "  and pgs.MasterLevelOpportunity = pgd.MasterOpportunityType  " +
            "  and pgs.ProgramYear = pgd.ProgramYear  " +
            "where  " +
            "  pgs.providergroupid = :providerGroupID  " +
            "  and pgs.state = :state  " +
            "  and pgs.ProgramYear = :programYear  " +
            "GROUP BY   " +
            "  pgs.ProviderGroupID,  " +
            "  pgs.State,  " +
            "  pgs.ProgramYear,  " +
            "  ClientName,  " +
            "  OpportunityType,  " +
            "  OpportunitySubType,  " +
            "  OpportunityTypePosition,  " +
            "  OpportunitySubTypePosition,  " +
            "  DisplayText,  " +
            "  MasterOpportunityType,  " +
            "  MasterOpportunityTypePosition ,  " +
            "  TotalAssessmentsCount,  " +
            "  TotalGapsCount,  " +
            "  TotalClientsCount  " +
            "order by  " +
            "  MasterOpportunityType Asc";
	
    private static final String SELECT_OPPORTUNITY_SUB_TYPES_BY_PROVIDER_GROUP_ID = "SELECT DISTINCT OpportunitySubType FROM PROGPERF.MemberAssessmentOpportunity MSO  WHERE " +
            " MSO.PROVIDERGROUPID=:PROVIDERGROUPID AND MSO.STATE=:STATE  AND MSO.MasterOpportunityType = :masterOpportunityType AND MSO.SERVICELEVEL=:serviceLevel  AND MSO.PROGRAMYEAR=:programYear AND OpportunitySubType IS NOT NULL ORDER BY OpportunitySubType ASC ";

    private static final String SELECT_PROGRAM_YEAR_BY_PROVIDER_GROUP_ID = "SELECT DISTINCT ProgramYear FROM PROGPERF.MemberAssessmentOpportunity MSO  WHERE " +
            " MSO.PROVIDERGROUPID=:PROVIDERGROUPID AND MSO.STATE=:STATE AND MSO.MasterOpportunityType = :masterOpportunityType AND MSO.SERVICELEVEL=:serviceLevel AND PROGRAMYEAR IS NOT NULL ORDER BY PROGRAMYEAR DESC";

    private static final String SELECT_LOB_NAME_BY_PROVIDER_GROUP_ID = "SELECT DISTINCT LOBName FROM PROGPERF.MemberAssessmentOpportunity MSO  WHERE " +
            " MSO.PROVIDERGROUPID=:PROVIDERGROUPID AND MSO.STATE=:STATE AND MSO.MasterOpportunityType = :masterOpportunityType AND MSO.SERVICELEVEL = :serviceLevel AND MSO.PROGRAMYEAR =:programYear AND LOBName IS NOT NULL %s ORDER BY LOBName ASC";

    private static final String SELECT_CLIENT_NAME_BY_PROVIDER_GROUP_ID = "SELECT DISTINCT ClientName FROM PROGPERF.MemberAssessmentOpportunity MSO  WHERE " +
            " MSO.PROVIDERGROUPID=:PROVIDERGROUPID AND MSO.STATE=:STATE AND MSO.MasterOpportunityType = :masterOpportunityType AND MSO.SERVICELEVEL=:serviceLevel  AND MSO.PROGRAMYEAR=:programYear AND ClientName IS NOT NULL ORDER BY ClientName ASC";

    private static final String SELECT_GAP_CLIENT_NAME_BY_PROVIDER_GROUP_ID = "SELECT DISTINCT ClientName FROM PROGPERF.MemberAssessmentGap MSO  WHERE " +
            " PROVIDERGROUPID=:PROVIDERGROUPID AND STATE=:STATE AND MasterOpportunityType = :masterOpportunityType AND PROGRAMYEAR=:programYear AND ClientName IS NOT NULL ORDER BY ClientName ASC";

    private static final String SELECT_GAP_OPPORTUNITY_SUB_TYPES_BY_PROVIDER_GROUP_ID = "SELECT DISTINCT OpportunitySubType FROM PROGPERF.MemberAssessmentGap MSO  WHERE " +
            " PROVIDERGROUPID=:PROVIDERGROUPID AND STATE=:STATE  AND MasterOpportunityType = :masterOpportunityType AND PROGRAMYEAR=:programYear  AND OpportunitySubType IS NOT NULL ORDER BY OpportunitySubType ASC ";

    private static final String SELECT_GAP_PROGRAM_YEAR_BY_PROVIDER_GROUP_ID = "SELECT DISTINCT ProgramYear FROM PROGPERF.MemberAssessmentGap  WHERE " +
            " PROVIDERGROUPID=:PROVIDERGROUPID AND STATE=:STATE AND MasterOpportunityType = :masterOpportunityType AND PROGRAMYEAR IS NOT NULL ORDER BY PROGRAMYEAR DESC";

    private static final String SELECT_GAP_LOB_NAME_BY_PROVIDER_GROUP_ID = "SELECT DISTINCT LOBName FROM PROGPERF.MemberAssessmentGap   WHERE " +
            " PROVIDERGROUPID=:PROVIDERGROUPID AND STATE=:STATE AND MasterOpportunityType = :masterOpportunityType %s AND PROGRAMYEAR= :programYear AND  LOBName IS NOT NULL ORDER BY LOBName ASC";

    private static final String FILTER_OFFSHORE_RESTRICTED_LOBS = " AND NOT LOBName = 'MEDICAID'";

    private static final String SELECT_MEMBER_GAPS_WITH_OFFSET = " WHILE @iterator< @count " +
            " BEGIN " +
            " SELECT LOBName as lobname,programyear as programyear, ChartID as CHARTID, ProviderName as PROVIDERNAME, ClientName as CLIENT, MemberId as MEMBERID, MemberDob as MEMBERDOB, CONCAT(UPPER(LEFT(MemberLastName,1))+LOWER(SUBSTRING(MemberLastName,2,LEN(MemberLastName))), ', ', +" +
            "             UPPER(LEFT(MemberFirstName,1))+LOWER(SUBSTRING(MemberFirstName,2,LEN(MemberFirstName)))) AS MEMBERNAME, +" +
            "            IsSecondarySubmissionEligible as ISSECONDARYSUBMISSION, OpportunityType as OPPORTUNITYTYPE, OpportunitySubType as OPPORTUNITYREASON, +" +
            "            GapType as GAPTYPE, GapStatus as GAPSTATUS, GapDesc as GAPDESC, CoverSheetResponse as COVERSHEETRESPONSE FROM  PROGPERF.MemberAssessmentGap WITH (NOLOCK) WHERE PROVIDERGROUPID=:PROVIDERGROUPID "+
            "             AND STATE=:STATE %s %s %s" +
            " OFFSET @initialOffset ROWS " +
            "    FETCH NEXT :BATCH_SIZE ROWS ONLY " +
            "    SET @initialOffset += :BATCH_SIZE " +
            "    SET @iterator += :BATCH_SIZE " +
            "END";

    private static final String FILTER_SPECIFIC_LOB=" AND NOT LOBName='%s'";

    private static final String NEW_OPPORTUNITIES_DETAILS_QUERY_MONTHLY = "SELECT   " +
            "  pgd.ProviderGroupID AS ProviderGroupID,    " +
            "  pgd.State AS State,    " +
            "  pgd.ProgramYear AS ProgramYear,   " +
            "  pgd.MasterOpportunityType,    " +
            "  pgd.MasterOpportunityTypePosition,  " +
            "  pgd.OpportunityType,    " +
            "  pgd.OpportunityTypePosition,    " +
            "  pgd.MeasureID,    " +
            "  SUM(pgd.AssessmentCount) AS AssessmentCount,    " +
            "  SUM(pgd.EligibleMemberCount) AS DeploymentCount,    " +
            "  SUM(pgd.GapCount) AS GapCount,   " +
            "  CONVERT(int, CEILING(SUM(pgd.MembersToAchieveFiveStarRatings))) AS MembersToAchieveFiveStarRatings," +
            "  SUM(pgd.CompliantMembers) AS CompliantMembers," +
            "  max(pgd.UpdatedDate) AS UpdatedDate  " +
            "FROM    " +
            "  ProgPerf.ProvGroupRiskQualityOppDetailsMonthly pgd WITH (NOLOCK)    " +
            "WHERE    " +
            "  pgd.providergroupid = :PROVIDERGROUPID    " +
            "  AND pgd.ProgramYear = :PROGRAMYEAR    " +
            "  AND pgd.MasterOpportunityType IN (:MASTEROPPORTUNITYTYPE)    " +
            "  AND pgd.TeamType = :TEAMTYPE    " +
            "  AND pgd.IsCurrentMonth = 1  " +
            "  %s     " +
            "GROUP BY  " +
            "  pgd.ProviderGroupID,    " +
            "  pgd.State,     " +
            "  pgd.ProgramYear,   " +
            "  pgd.OpportunityType,    " +
            "  pgd.OpportunityTypePosition,    " +
            "  pgd.MasterOpportunityType,    " +
            "  pgd.MeasureID,  " +
            "  pgd.MasterOpportunityTypePosition  " +
            "ORDER BY    " +
            "  pgd.opportunityTypePosition Asc";

    private static final String SELECT_RISK_QUALITY_CLIENTS_DETAILS_QUERY_MONTHLY = "SELECT  " +
            "  DISTINCT pgod.ClientName,  pgod.ClientId  " +
            "   from " +
            "  ProgPerf.ProvGroupRiskQualityOppDetailsMonthly pgod  WITH (NOLOCK)  " +
            "   where " +
            "  pgod.MasterOpportunityType IN (:masterOpportunityType) AND pgod.ClientName IS NOT NULL AND pgod.ClientName !='' " +
            "  AND pgod.ClientId IS NOT NULL AND pgod.ClientId !='' " +
            "  AND pgod.isCurrentMonth= 1    " +
            "  AND pgod.ProviderGroupID =:providerGroupID  " +
            "  AND pgod.ProgramYear =:programYear " +
            "  AND pgod.TeamType =:TEAMTYPE  " +
            "  %s    ";

    private static final String SELECT_IOA_IHA_CLIENTS_DETAILS_QUERY = " SELECT " +
            "   DISTINCT  pgpw.ClientName,  pgpw.ClientId  " +
            "    from  " +
            "  ProgPerf.ProviderGroupPerformanceWeekly pgpw  WITH (NOLOCK)  " +
            "    where " +
            "  pgpw.ClientName IS NOT NULL AND pgpw.ClientName !='' " +
            "  AND pgpw.ProviderGroupID =:providerGroupID " +
            "  AND pgpw.ProgramYear =:programYear " +
            "  AND pgpw.State = :STATE";

    private static final String SELECT_RISK_QUALITY_LOB_DETAILS_QUERY_MONTHLY = " SELECT  " +
            "  DISTINCT  pgod.LobName " +
            "    from " +
            "  ProgPerf.ProvGroupRiskQualityOppDetailsMonthly pgod WITH (NOLOCK) " +
            "   where  " +
            " pgod.MasterOpportunityType IN (:masterOpportunityType) AND pgod.LobName IS NOT NULL AND pgod.LobName !=''  " +
            "  AND pgod.ProgramYear =:programYear" +
            "  AND pgod.TeamType = :TEAMTYPE  " +
            "  AND pgod.isCurrentMonth= 1    " +
            " %s        ";

    private static final String SELECT_IOA_IHA_LOBS_DETAILS_QUERY = " SELECT   " +
            "   DISTINCT pgpw.LobName " +
            "   from  " +
            "  ProgPerf.ProviderGroupPerformanceWeekly pgpw  WITH (NOLOCK)  " +
            "    where  " +
            "  pgpw.LobName IS NOT NULL AND pgpw.LobName !='' " +
            "  AND pgpw.ProviderGroupID =:providerGroupID " +
            "  AND pgpw.ProgramYear =:programYear" +
            "  AND pgpw.State = :STATE";

    private static final String SELECT_OPPORTUNITIES_CONFIGURATION_BY_MASTER_OPPORTUNITY_NAME = "SELECT Id," +
            " MasterOpportunityName, OpportunityName, MasterOpportunityDisplayOrder," +
            " OpportunityDisplayOrder, DatabaseLogic, IsActive, WhereClauseCondition, " +
            " SelectClauseCondition, IsSummaryAggregationRequired " +
            " FROM ProgPerf.OpportunitiesConfigurations opc where opc.ProgramYear=:programYear and opc.TeamType= :teamType %s ";
    private static final String SELECT_OPPORTUNITIES_CONFIGURATION_BY_MASTER_OPPORTUNITY_NAME_AND_OPPORTUNITIES_NAME = "SELECT Id, MasterOpportunityName, OpportunityName, MasterOpportunityDisplayOrder, OpportunityDisplayOrder, " +
            "DatabaseLogic, IsActive, WhereClauseCondition, SelectClauseCondition, IsSummaryAggregationRequired FROM ProgPerf.OpportunitiesConfigurations opc " +
            "where opc.OpportunityName in( :opportunityNames) and opc.ProgramYear=:programYear and opc.TeamType= :teamType %s ";
    private static final String SELECT_MEMBER_QUALITY_GAP_DETAILS = "select mq.GAP_YR ProgramYear,MBR_CARD_ID PatientCardId,MBR_FST_NM patientFirstName,MBR_LST_NM patientLastName,MBR_DOB_DT patientDOB,  (CASE WHEN MBR_GDR_CD ='F' THEN 'Female'  ELSE 'Male' END) gender ,INSURANCE_CARRIER insuranceCarrier,CPG carePriorityGroup, :CareOpportunity CareOpportunity,'Open' careOpportunityStatus,LINE_OF_BUSINESS lobName,(ASSOC_PROV_LST_NM +' '+ ASSOC_PROV_FST_NM) primaryCareProviderName, ASSOC_PROV_NPI_NUM pcpNpi,MBR_ANNL_CARE_VST_DT annualCareVisitDate,MBR_ANNL_CARE_VST_DT_HC houseCallsVisitDate,MBR_INCNT_PGM_IND incentiveProgram,   (CASE   WHEN HIGH_PRTY_MBR_FLG ='Y' THEN 'Yes'    ELSE 'No' END) highPriorityPatient from ProgPerf.MemberQuality mq  " +
            " where %s mq.GAP_YR = :programYear and mq.ASSOC_PROV_GRP_ID = :providerGroupID %providerState and mq.IS_ACTIVE = 'Y' And %teamTypeCondition   %s ";
    private static final String FETCH_MEMBER_INDICATOR ="SELECT distinct Value from ProgPerf.CategoryMasterConfiguration where Name = :MEMBER_INC_PROGRAM_INDICATOR ";
    private static final String FETCH_CATEGORY_MASTER_CONFIGURATION ="SELECT distinct Name, Value from ProgPerf.CategoryMasterConfiguration where Name in (%s)";
    private static final String SELECT_MEMBER_SUSPECT_CONDITION_DETAILS = "select ms.GAP_YR ProgramYear,MBR_CARD_ID PatientCardId,MBR_FST_NM patientFirstName,MBR_LST_NM patientLastName,MBR_DOB_DT patientDOB,  (CASE WHEN MBR_GDR_CD ='F' THEN 'Female'  ELSE 'Male' END) gender ,INSURANCE_CARRIER insuranceCarrier,CPG carePriorityGroup, GAP_DESCRIPTION condition, GAP_RSN suspectDetails, DW_INSRT_DTTM suspectConditionDateAdded, ASSESSMENT_STATUS disposition," +
            " ASSESSMENT_DOS dateOfAssessment, LINE_OF_BUSINESS lobName,(ASSOC_PROV_LST_NM +' '+ ASSOC_PROV_FST_NM) primaryCareProviderName, ASSOC_PROV_NPI_NUM pcpNpi,MBR_ANNL_CARE_VST_DT annualCareVisitDate,MBR_ANNL_CARE_VST_DT_HC houseCallsVisitDate,MBR_INCNT_PGM_IND incentiveProgram,   (CASE   WHEN HIGH_PRTY_MBR_FLG ='Y' THEN 'Yes'    ELSE 'No' END) highPriorityPatient from ProgPerf.MemberSuspect ms with(nolock)  " +
            " where %s  ms.GAP_YR = :programYear and ms.ASSOC_PROV_GRP_ID = :providerGroupID %providerstate  AND MBR_INCNT_PGM_IND IS NOT NULL " +
            " AND MBR_INCNT_PGM_IND != '' " +
            " AND IS_ACTIVE = 'Y' %qfoTeamTypeCondition  %s";

    private static final String FETCH_STAR_THRESHOLD = "select MeasureId, ProgramYear, StarsThreshold1, StarsThreshold2, StarsThreshold3, StarsThreshold4, StarsThreshold5 FROM ProgPerf.MeasuresThresholdConfiguration where TeamType = :TEAMTYPE and ProgramYear = :programYear ";

    private static final String FETCH_MIN_ELIGIBLE_MEMBERS = " select value as minEligibleMemberCount " +
            "FROM ProgPerf.MasterConfiguration WITH (NOLOCK) " +
            "WHERE code = 'MinEligibleMembersCount' ";

    private static final String SELECT_ACV_NOT_COMPLETED_DETAILS = "SELECT mq.MBR_PGM_YEAR as programYear, mq.MBR_CARD_ID as PatientCardId, "+
            "mq.MBR_FST_NM as  PatientFirstName,mq.MBR_LST_NM as  PatientLastName, mq.MBR_DOB_DT as PatientDOB,(CASE WHEN mq.MBR_GDR_CD ='F' THEN 'Female'  ELSE 'Male' END) Gender, " +
            "mq.INSURANCE_CARRIER as InsuranceCarrier, mq.CPG as CarePriorityGroup, mq.LOB_NAME as lobName,(mq.ASSOC_PROV_LST_NM +' '+ mq.ASSOC_PROV_FST_NM) primaryCareProviderName, " +
            "mq.ASSOC_PROV_NPI_NUM as  pcpNpi, mq.MBR_ANNL_CARE_VST_DT as AnnualCareVisitDate, mq.MBR_ANNL_CARE_VST_DT_HC as HouseCallsVisitDate, mq.MBR_INCNT_PGM_IND IncentiveProgram, mq.HIGH_PRTY_MBR_FLG as HighPriorityPatient from ProgPerf.MemberSummary  mq with(nolock) " +
            "WHERE %s mq.MBR_INCNT_PGM_IND IS NOT NULL AND mq.MBR_INCNT_PGM_IND !='' AND mq.IS_ACTIVE='Y' " +
            "AND mq.ASSOC_PROV_GRP_ID = :providerGroupID %providerstate AND mq.MBR_PGM_YEAR = :programYear " +
            " %qfoTeamTypeCondition %s ";

    private static final String SELECT_MEMBER_SUSPECT_NOT_FULLY_ASSESSED_DETAILS = "select DISTINCT ms.GAP_YR ProgramYear,MBR_CARD_ID PatientCardId, " +
            "MBR_FST_NM patientFirstName,MBR_LST_NM patientLastName,MBR_DOB_DT patientDOB, " +
            "(CASE WHEN MBR_GDR_CD ='F' THEN 'Female'  ELSE 'Male' END) gender , " +
            "INSURANCE_CARRIER insuranceCarrier,CPG carePriorityGroup, LINE_OF_BUSINESS lobName, " +
            "(ASSOC_PROV_LST_NM +' '+ ASSOC_PROV_FST_NM) primaryCareProviderName, ASSOC_PROV_NPI_NUM pcpNpi, " +
            "MBR_ANNL_CARE_VST_DT annualCareVisitDate,MBR_ANNL_CARE_VST_DT_HC houseCallsVisitDate,MBR_INCNT_PGM_IND incentiveProgram, " +
            "  (CASE   WHEN HIGH_PRTY_MBR_FLG ='Y' THEN 'Yes'    ELSE 'No' END) highPriorityPatient from ProgPerf.MemberSuspect ms " +
            " where " +
            " MBR_INCNT_PGM_IND IS NOT NULL " +
            " AND MBR_INCNT_PGM_IND != '' " +
            " AND IS_ACTIVE = 'Y' AND" +
            " %s  " +
            "  ASSOC_PROV_GRP_ID = :providerGroupID " +
            " %providerstate " +
            " AND GAP_YR = :programYear %qfoTeamTypeCondition  %s" ;

    private static final String SELECT_OPPORTUNITY_BY_COUNT=" select DISTINCT  pgrqod.OpportunityType from ProgPerf.ProvGroupRiskQualityOppDetails pgrqod  where pgrqod.MasterOpportunityType= 'Quality Gaps' and pgrqod.AssessmentCount >0 %state and pgrqod.ProviderGroupID = :providerGroupID and pgrqod.ProgramYear = :programYear and pgrqod.TeamType = :teamType %s";

    private static final String QFO_HEALTH_SYSTEM_OPPORTUNITIES_DETAILS_QUERY = " SELECT     "+
            "  hsrqodm.HealthSystemId AS HealthSystemId,    "+
            "  hsrqodm.ProgramYear AS ProgramYear,     "+
            "  hsrqodm.MasterOpportunityType  ,  "+
            "  hsrqodm.MasterOpportunityTypePosition,    "+
            "  hsrqodm.OpportunityType  ,  "+
            "  hsrqodm.OpportunityTypePosition  ,  "+
            "  hsrqodm.MeasureID  ,  "+
            "  SUM(hsrqodm.AssessmentCount) AS AssessmentCount  ,  "+
            "  SUM(hsrqodm.EligibleMemberCount) AS DeploymentCount  ,  "+
            "  SUM(hsrqodm.GapCount) AS GapCount,     "+
            "  CONVERT(int, CEILING(SUM(hsrqodm.MembersToAchieveFiveStarRatings))) AS MembersToAchieveFiveStarRatings,  "+
            "  SUM(hsrqodm.CompliantMembers) AS CompliantMembers,  "+
            "  max(hsrqodm.UpdatedDate) AS UpdatedDate    "+
            "FROM      "+
            "  ProgPerf.ProvGroupRiskQualityOppDetailsMonthly hsrqodm  WITH (NOLOCK)      " +
            "WHERE      "+
            " hsrqodm.HealthSystemId = :HEALTHSYSTEMID  "+
            "  AND hsrqodm.IsCurrentMonth = 1  " +
            "  AND hsrqodm.ProgramYear = :PROGRAMYEAR      "+
            "  AND hsrqodm.MasterOpportunityType IN (:MASTEROPPORTUNITYTYPE)      "+
            "  AND hsrqodm.TeamType = 'QFO'   %s   "+
            "GROUP BY    "+
            "  hsrqodm.HealthSystemId,  "+
            "  hsrqodm.ProgramYear,     "+
            "  hsrqodm.OpportunityType  ,  "+
            "  hsrqodm.OpportunityTypePosition  ,  "+
            "  hsrqodm.MasterOpportunityType  ,  "+
            "  hsrqodm.MeasureID,    "+
            "  hsrqodm.MasterOpportunityTypePosition    ";

    private static final String QFO_LOBS_QUERY = "SELECT value from ProgPerf.CategoryMasterConfiguration where [key] = 'QFO_LOB'";

    private static final String OFC_PA_INTEGRATION_CONFIG_QUERY =   "SELECT Name,[Key], Value from ProgPerf.CategoryMasterConfiguration where IsActive = 1 AND IsDeleted = 0 AND Name Like 'OFCPAIntegrationFilter%'";

    @Override
    public Flux<MemberAssessmentDTO> getMemberAssessments(MemberAssessment memberAssessment, boolean enablePagination, boolean offshoreRestricted) {
        String filterQuery = memberAssessmentFilterQuery(memberAssessment);
        String paginationCondition = getPaginationCondition(memberAssessment);
        StringBuilder memberAssessments = new StringBuilder();
        String query = SELECT_MEMBER_ASSESSMENTS;
        if(offshoreRestricted) {
        	query += FILTER_OFFSHORE_RESTRICTED_LOBS;
        }
        memberAssessments.append(String.format(query,filterQuery));
        /* Enable count query when require overlapping years */
        /*memberAssessments.append(" UNION ALL ");
        memberAssessments.append(String.format(SELECT_MEMBER_ASSESSMENTS_WITH_MEMHISTORY,filterQuery));*/
        memberAssessments.append(enablePagination?paginationCondition:(" order by  "+memberAssessment.getSort()+" "));
        log.info ("Running query {} with Params OpportunityType={} ProviderGroupID={} State={} ServiceLevel={}", memberAssessments.toString(), memberAssessment.getOpportunityType()
            ,memberAssessment.getProviderGroupId(),memberAssessment.getProviderState(),memberAssessment.getServiceLevel() );
        return opportunityClient.execute(memberAssessments.toString())
                .bind(ProviderGroupConstants.OPPORTUNITY_TYPE, memberAssessment.getOpportunityType())
                .bind(ProviderGroupConstants.PROVIDER_GROUP_ID, memberAssessment.getProviderGroupId())
                .bind(ProviderGroupConstants.STATE, memberAssessment.getProviderState())
                .bind(ProviderGroupConstants.SERVICE_LEVEL, ServiceLevel.getPerformanceMSServiceLevel(memberAssessment.getServiceLevel()))
                .bind(ProviderGroupConstants.PROGRAM_YEAR, memberAssessment.getProgramYear())
                .as(MemberAssessmentDTO.class)
                .fetch()
                .all();
    }

    @Override
    public Mono<Long> getMemberAssessmentsCounts(MemberAssessment memberAssessment, boolean offshoreRestricted) {
        String filterQuery = memberCountsAssessmentFilterQuery(memberAssessment);
        StringBuilder memberAssessmentCount = new StringBuilder();
        /* Enable count query when require overlapping years */
        /*memberAssessmentCount.append("(");*/
        String query = SELECT_MEMBER_ASSESSMENTS_COUNTS;
        if(offshoreRestricted) {
        	query += " AND MO.LOBNAME != 'Medicaid'";
        }
        memberAssessmentCount.append(String.format(query,filterQuery));
        /* Enable count query when require overlapping years */
        /*memberAssessmentCount.append(" UNION ALL ");
        memberAssessmentCount.append(String.format(SELECT_MEMBER_ASSESSMENTS_WITH_MEMHISTORY_COUNTS,filterQuery));
        memberAssessmentCount.append(") x");*/
        return opportunityClient.execute(memberAssessmentCount.toString())
                .bind(ProviderGroupConstants.OPPORTUNITY_TYPE, memberAssessment.getOpportunityType())
                .bind(ProviderGroupConstants.PROVIDER_GROUP_ID, memberAssessment.getProviderGroupId())
                .bind(ProviderGroupConstants.STATE, memberAssessment.getProviderState())
                .bind(ProviderGroupConstants.SERVICE_LEVEL, ServiceLevel.getPerformanceMSServiceLevel(memberAssessment.getServiceLevel()))
                .as(Long.class)
                .fetch()
                .first();
    }

    private String getPaginationCondition(MemberAssessment memberAssessment) {
        StringBuilder stringBuilder = new StringBuilder();
        return stringBuilder.append("order by ")
                .append(memberAssessment.getSort())
                .append(" asc")
                .append(" offset ")
                .append(memberAssessment.getOffset())
                .append(" rows")
                .append(" fetch next ")
                .append(memberAssessment.getLimit())
                .append(" rows only")
                .toString();
    }

    @Override
    public Flux<ProviderGroupMemberGaps> getMemberGaps(MemberAssessment memberAssessment,boolean enablePagination, boolean offshoreRestricted) {

        String disableMedicaidLobfilterQuery = disableMedicaidLobForOffshoreUsersFilterQuery(offshoreRestricted);
        String filterQuery = memberGapFilterQuery(memberAssessment);
        StringBuilder memberGap = new StringBuilder();
        memberGap.append(String.format(SELECT_MEMBER_GAPS,disableMedicaidLobfilterQuery,filterQuery));
        String paginationCondition = getPaginationCondition(memberAssessment);
        memberGap.append(enablePagination?paginationCondition :(" order by "+memberAssessment.getSort() + " "));
        return opportunityClient.execute(memberGap.toString())
                .bind(ProviderGroupConstants.PROVIDER_GROUP_ID, memberAssessment.getProviderGroupId())
                .bind(ProviderGroupConstants.STATE, memberAssessment.getProviderState())
                .as(ProviderGroupMemberGaps.class)
                .fetch()
                .all();
    }

    @Override
    public Mono<Long> getMemberAssessmentsGapCounts(MemberAssessment memberAssessment, boolean offshoreRestricted) {
        String disableMedicaidLobfilterQuery = disableMedicaidLobForOffshoreUsersFilterQuery(offshoreRestricted);
        String filterQuery = memberGapFilterQuery(memberAssessment);
        StringBuilder memberGapCount = new StringBuilder();
          memberGapCount.append(String.format(SELECT_MEMBER_GAPS_COUNTS,disableMedicaidLobfilterQuery,filterQuery));
        return opportunityClient.execute(memberGapCount.toString())
                .bind(ProviderGroupConstants.PROVIDER_GROUP_ID, memberAssessment.getProviderGroupId())
                .bind(ProviderGroupConstants.STATE, memberAssessment.getProviderState())
                .as(Long.class)
                .fetch()
                .first();
    }

    private String memberGapFilterQuery(MemberAssessment memberAssessment) {
        String oppSubTypeParameter = " AND OpportunitySubType='%s' ";
        String clientNameParameter = " AND clientName='%s' ";
        String lobNameParameter = " AND lobName='%s' ";
        String programYearParameter = " AND programYear='%s' ";
        String programTypeParameter = " AND ProgramType='%s' ";
        String query = StringUtils.EMPTY;

        if (StringUtils.isNotBlank(memberAssessment.getOpportunitySubtype()) && !ALL.equalsIgnoreCase(memberAssessment.getOpportunitySubtype())) {
            query = String.format(oppSubTypeParameter, memberAssessment.getOpportunitySubtype());
        }


        if (StringUtils.isNotBlank(memberAssessment.getClientName()) && !ALL.equalsIgnoreCase(memberAssessment.getClientName())) {
            query = query + String.format(clientNameParameter, memberAssessment.getClientName());
        }


        if (StringUtils.isNotBlank(memberAssessment.getLobName()) && !ALL.equalsIgnoreCase(memberAssessment.getLobName())) {
            query = query + String.format(lobNameParameter, memberAssessment.getLobName());
        }

        if (memberAssessment.getProgramYear() > 0) {
            query = query + String.format(programYearParameter, memberAssessment.getProgramYear());
        }


        if (StringUtils.isNotBlank(memberAssessment.getProgramType()) && !ALL.equalsIgnoreCase(memberAssessment.getProgramType())) {
            query = query + String.format(programTypeParameter, memberAssessment.getProgramType());
        }

        return query;
    }

    private String memberAssessmentFilterQuery(MemberAssessment memberAssessment){
        String oppSubTypeParameter = " AND MSO.OpportunitySubType='%s' ";
        String clientNameParameter = " AND MSO.clientName='%s' ";
        String lobNameParameter = " AND MSO.lobName='%s' ";
        String programYearParameter = " AND MSO.programYear='%s' ";
        String query = StringUtils.EMPTY;

        if (StringUtils.isNotBlank(memberAssessment.getOpportunitySubtype()) && !ALL.equalsIgnoreCase(memberAssessment.getOpportunitySubtype())) {
            query = String.format(oppSubTypeParameter, memberAssessment.getOpportunitySubtype());
        }

        if (StringUtils.isNotBlank(memberAssessment.getClientName()) && !ALL.equalsIgnoreCase(memberAssessment.getClientName())) {
            query = query + String.format(clientNameParameter, memberAssessment.getClientName());
        }

        if (StringUtils.isNotBlank(memberAssessment.getLobName()) && !ALL.equalsIgnoreCase(memberAssessment.getLobName())) {
            query = query + String.format(lobNameParameter, memberAssessment.getLobName());
        }

        if(memberAssessment.getProgramYear() > 0){
            query = query + String.format(programYearParameter,memberAssessment.getProgramYear());
        }else{
            query = query + " AND MSO.PROGRAMYEAR=(select mc.value from ProgPerf.MasterConfiguration mc WITH (NOLOCK) where mc.code='CurrentProgramYear')";
        }
        return query;
    }

    private String memberCountsAssessmentFilterQuery(MemberAssessment memberAssessment){
        String oppSubTypeParameter = "AND MO.OpportunitySubType='%s' ";
        String clientNameParameter = "AND MO.clientName='%s' ";
        String lobNameParameter = "AND MO.lobName='%s' ";
        String programYearParameter = "AND MO.programYear='%s' ";
        String query = StringUtils.EMPTY;

        if (StringUtils.isNotBlank(memberAssessment.getOpportunitySubtype()) && !ALL.equalsIgnoreCase(memberAssessment.getOpportunitySubtype())) {
            query = String.format(oppSubTypeParameter, memberAssessment.getOpportunitySubtype().trim().toUpperCase());
        }


        if (StringUtils.isNotBlank(memberAssessment.getClientName()) && !ALL.equalsIgnoreCase(memberAssessment.getClientName())) {
            query = query + String.format(clientNameParameter, memberAssessment.getClientName().trim().toUpperCase());
        }


        if (StringUtils.isNotBlank(memberAssessment.getLobName()) && !ALL.equalsIgnoreCase(memberAssessment.getLobName())) {
            query = query + String.format(lobNameParameter, memberAssessment.getLobName().trim().toUpperCase());
        }

        if(memberAssessment.getProgramYear() > 0){
            query = query + String.format(programYearParameter,memberAssessment.getProgramYear());
        }else{
            query = query + " AND MO.PROGRAMYEAR=(select mc.value from ProgPerf.MasterConfiguration mc WITH (NOLOCK) where mc.code='CurrentProgramYear')";
        }
        return query;
    }

    @Override
    public Flux<OpportunitiesSummaryDetails> getOpportunitiesSummary(String providerGroupId, String state, String serviceLevel, int programYear) {
        return opportunityClient.execute(OPPORTUNITIES_SUMMARY_QUERY)
                .bind(ProviderGroupConstants.OPPORTUNITY_PROVIDER_GROUP_ID, providerGroupId)
                .bind(ProviderGroupConstants.OPPORTUNITY_STATE, state)
                .bind(ProviderGroupConstants.PROGRAM_YEAR, programYear)
                .as(OpportunitiesSummaryDetails.class)
                .fetch()
                .all();
    }

    @Override
    public Flux<OpportunitiesDetailsDTO> getOpportunitiesDetails(String providerGroupId, String state, String serviceLevel, String programYear) {
        return opportunityClient.execute(OPPORTUNITIES_DETAILS_QUERY)
                .bind(ProviderGroupConstants.OPPORTUNITY_PROVIDER_GROUP_ID, providerGroupId)
                .bind(ProviderGroupConstants.OPPORTUNITY_STATE, state)
                .bind(ProviderGroupConstants.PROGRAM_YEAR, programYear)
                .as(OpportunitiesDetailsDTO.class)
                .fetch()
                .all();
    }

    @Override
    public Flux<MemberAssessmentOpportunitySubTypes> getMemberAssessmentOpportunitySubTypes(String providerGroupId, String state, String type, String serviceLevel ,int programYear) {
        return opportunityClient.execute(SELECT_OPPORTUNITY_SUB_TYPES_BY_PROVIDER_GROUP_ID)
                .bind(ProviderGroupConstants.PROVIDER_GROUP_ID, providerGroupId)
                .bind(ProviderGroupConstants.STATE, state)
                .bind(ProviderGroupConstants.MASTER_OPPORTUNITY_TYPE, type)
                .bind(ProviderGroupConstants.OPPORTUNITY_SERVICE_LEVEL, serviceLevel)
                .bind(ProviderGroupConstants.PROGRAM_YEAR, programYear)
                .as(MemberAssessmentOpportunitySubTypes.class)
                .fetch()
                .all();
    }

    @Override
    public Flux<MemberAssessmentProgramYears> getMemberAssessmentProgramYears(String providerGroupId, String state, String type, String serviceLevel) {
        return opportunityClient.execute(SELECT_PROGRAM_YEAR_BY_PROVIDER_GROUP_ID)
                .bind(ProviderGroupConstants.PROVIDER_GROUP_ID, providerGroupId)
                .bind(ProviderGroupConstants.STATE, state)
                .bind(ProviderGroupConstants.MASTER_OPPORTUNITY_TYPE, type)
                .bind(ProviderGroupConstants.OPPORTUNITY_SERVICE_LEVEL, serviceLevel)
                .as(MemberAssessmentProgramYears.class)
                .fetch()
                .all();
    }

    @Override
    public Flux<MemberAssessmentLobs> getMemberAssessmentLobs(String providerGroupId, String state, String type, String serviceLevel, boolean offshoreRestricted, int programYear) {
    	 String query = SELECT_LOB_NAME_BY_PROVIDER_GROUP_ID;
    	 String filterQuery = "";
			if (offshoreRestricted) {
				filterQuery = FILTER_OFFSHORE_RESTRICTED_LOBS;
			}
    	 query = String.format(query,filterQuery);
        return opportunityClient.execute(query)
                .bind(ProviderGroupConstants.PROVIDER_GROUP_ID, providerGroupId)
                .bind(ProviderGroupConstants.STATE, state)
                .bind(ProviderGroupConstants.MASTER_OPPORTUNITY_TYPE, type)
                .bind(ProviderGroupConstants.OPPORTUNITY_SERVICE_LEVEL, serviceLevel)
                .bind(ProviderGroupConstants.PROGRAM_YEAR, programYear)
                .as(MemberAssessmentLobs.class)
                .fetch()
                .all();
    }

    @Override
    public Flux<MemberAssessmentClients> getMemberAssessmentClients(String providerGroupId, String state, String type, String serviceLevel, int programYear) {
        return opportunityClient.execute(SELECT_CLIENT_NAME_BY_PROVIDER_GROUP_ID)
                .bind(ProviderGroupConstants.PROVIDER_GROUP_ID, providerGroupId)
                .bind(ProviderGroupConstants.STATE, state)
                .bind(ProviderGroupConstants.MASTER_OPPORTUNITY_TYPE, type)
                .bind(ProviderGroupConstants.OPPORTUNITY_SERVICE_LEVEL, serviceLevel)
                .bind(ProviderGroupConstants.PROGRAM_YEAR, programYear)
                .as(MemberAssessmentClients.class)
                .fetch()
                .all();
    }

    @Override
    public Flux<String> getMemberGapAssessmentOpportunitySubTypes(String providerGroupId, String state, String type, int programYear) {
        return opportunityClient.execute(SELECT_GAP_OPPORTUNITY_SUB_TYPES_BY_PROVIDER_GROUP_ID)
                .bind(ProviderGroupConstants.PROVIDER_GROUP_ID, providerGroupId)
                .bind(ProviderGroupConstants.STATE, state)
                .bind(ProviderGroupConstants.MASTER_OPPORTUNITY_TYPE, type)
                .bind(ProviderGroupConstants.PROGRAM_YEAR, programYear)
                .as(String.class)
                .fetch()
                .all();
    }

    @Override
    public Flux<Integer> getMemberGapAssessmentProgramYears(String providerGroupId, String state, String type) {
        return opportunityClient.execute(SELECT_GAP_PROGRAM_YEAR_BY_PROVIDER_GROUP_ID)
                .bind(ProviderGroupConstants.PROVIDER_GROUP_ID, providerGroupId)
                .bind(ProviderGroupConstants.STATE, state)
                .bind(ProviderGroupConstants.MASTER_OPPORTUNITY_TYPE, type)
                .as(Integer.class)
                .fetch()
                .all();
    }

    @Override
    public Flux<String> getMemberGapAssessmentLobs(String providerGroupId, String state, String type,boolean offshoreRestricted, int programYear) {
        String disableMedicaidLobfilterQuery = disableMedicaidLobForOffshoreUsersFilterQuery(offshoreRestricted);
        StringBuilder memberGapCount = new StringBuilder();
        memberGapCount.append(String.format(SELECT_GAP_LOB_NAME_BY_PROVIDER_GROUP_ID,disableMedicaidLobfilterQuery));
        return opportunityClient.execute(memberGapCount.toString())
                .bind(ProviderGroupConstants.PROVIDER_GROUP_ID, providerGroupId)
                .bind(ProviderGroupConstants.STATE, state)
                .bind(ProviderGroupConstants.MASTER_OPPORTUNITY_TYPE, type)
                .bind(ProviderGroupConstants.PROGRAM_YEAR, programYear)
                .as(String.class)
                .fetch()
                .all();
    }


    @Override
    public Flux<String> getMemberGapAssessmentClients(String providerGroupId, String state, String type, int programYear) {
        return opportunityClient.execute(SELECT_GAP_CLIENT_NAME_BY_PROVIDER_GROUP_ID)
                .bind(ProviderGroupConstants.PROVIDER_GROUP_ID, providerGroupId)
                .bind(ProviderGroupConstants.STATE, state)
                .bind(ProviderGroupConstants.MASTER_OPPORTUNITY_TYPE, type)
                .bind(ProviderGroupConstants.PROGRAM_YEAR, programYear)
                .as(String.class)
                .fetch()
                .all();
    }

    @Override
    public Flux<ProviderGroupMemberGaps> getMemberGapsForExport(MemberAssessment memberAssessment,boolean enablePagination, boolean isOffsetChangeNeeded,boolean offshoreRestricted ) {
        String filterQuery = memberGapFilterQuery(memberAssessment);
        String paginationCondition = getPaginationCondition(memberAssessment);
        StringBuilder memberGap = new StringBuilder();
        memberGap.append(String.format(SELECT_MEMBER_GAPS_WITH_OFFSET,filterQuery, disableMedicaidLobForOffshoreUsersFilterQuery(offshoreRestricted),enablePagination?paginationCondition :(" order by "+memberAssessment.getSort() + " ")));
        if(isOffsetChangeNeeded) {
            return opportunityClient.execute(memberGap.toString())
                    .bind(ProviderGroupConstants.PROVIDER_GROUP_ID, memberAssessment.getProviderGroupId())
                    .bind(ProviderGroupConstants.STATE, memberAssessment.getProviderState())
                    .bind("iterator", 0)
                    .bind("initialOffset", 0)
                    .bind("count", memberAssessment.getLimit())
                    .bind("BATCH_SIZE", BATCH_SIZE)
                    .as(ProviderGroupMemberGaps.class)
                    .fetch()
                    .all();
        } else {
            return getMemberGaps(memberAssessment, enablePagination,offshoreRestricted);
        }
    }

    @Override
    public Flux<OpportunitiesDetails> getRiskQualityOpportunitiesDetails(DetailsRequestBody detailsRequestBody) {
        StringBuilder clientIds = new StringBuilder();
        StringBuilder lobNames = new StringBuilder();
        StringBuilder finalFilterChecks = new StringBuilder();
        if (!Objects.isNull(detailsRequestBody.getClientIds())&&!detailsRequestBody.getClientIds().isEmpty()) {
            detailsRequestBody.getClientIds().stream().forEach(client -> clientIds.append("'" + client + "',"));
            finalFilterChecks.append(" AND pgd.ClientId IN (" + clientIds.deleteCharAt(clientIds.length() - 1) + " ) ");
        }
        if (!Objects.isNull(detailsRequestBody.getLobs())&&!detailsRequestBody.getLobs().isEmpty()) {
            detailsRequestBody.getLobs().stream().forEach(lob -> lobNames.append("'" + lob + "',"));
            finalFilterChecks.append(" AND pgd.LobName IN (" + lobNames.deleteCharAt(lobNames.length() - 1) + " ) ");
        }

        if(!Objects.isNull(detailsRequestBody.getTeamType())&&!(detailsRequestBody.getTeamType().equalsIgnoreCase(TEAMTYPE_QFO))){
            finalFilterChecks.append("AND pgd.State = '" + detailsRequestBody.getProviderState() + "'");
        }
	    
        String finalQuery = String.format(NEW_OPPORTUNITIES_DETAILS_QUERY_MONTHLY, finalFilterChecks);

        log.info("Details Request Body :: {}    RiskQualityOpportunitiesDetail Query Query :: {}", detailsRequestBody, finalQuery);
        return opportunityClient.execute(finalQuery)
                .bind("PROVIDERGROUPID", detailsRequestBody.getProviderGroupId())
                .bind("PROGRAMYEAR", detailsRequestBody.getProgramYear())
                .bind("MASTEROPPORTUNITYTYPE", detailsRequestBody.getOpportunityTypes())
                .bind(ProviderGroupConstants.TEAMTYPE,detailsRequestBody.getTeamType())
                .as(OpportunitiesDetails.class)
                .fetch()
                .all();
    }

    private String disableMedicaidLobForOffshoreUsersFilterQuery(boolean isOffshoreRestricted) {
        String query = StringUtils.EMPTY;
        if (StringUtils.isNotBlank(ProviderGroupConstants.MEDICAID) && isOffshoreRestricted && !ALL.equalsIgnoreCase(ProviderGroupConstants.MEDICAID)) {

            query = query + String.format(FILTER_SPECIFIC_LOB, ProviderGroupConstants.MEDICAID.trim().toUpperCase());

        }

        return query;
    }

    @Override
    public  Flux<ClientsFilterDetails> getRiskQualityOpportunitiesClientDetails(ClientsRequestBody clientsRequestBody) {
        String query;

        if(!Objects.isNull(clientsRequestBody.getTeamType())&&clientsRequestBody.getTeamType().equalsIgnoreCase(TEAMTYPE_QFO)){
            query = String.format(SELECT_RISK_QUALITY_CLIENTS_DETAILS_QUERY_MONTHLY,ProviderGroupConstants.WHITE_SPACE);
        }
        else{
            query = String.format(SELECT_RISK_QUALITY_CLIENTS_DETAILS_QUERY_MONTHLY," AND pgod.State = '" + clientsRequestBody.getProviderState() + "'");
        }
        return opportunityClient.execute(query)
                .bind(ProviderGroupConstants.OPPORTUNITY_PROVIDER_GROUP_ID, clientsRequestBody.getProviderGroupId())
                .bind(ProviderGroupConstants.MASTER_OPPORTUNITY_TYPE, clientsRequestBody.getMasterOpportunityTypes())
                .bind(ProviderGroupConstants.PROGRAM_YEAR, clientsRequestBody.getProgramYear())
                .bind(ProviderGroupConstants.TEAMTYPE,clientsRequestBody.getTeamType())
                .as(ClientsFilterDetails.class)
                .fetch()
                .all();

    }

    @Override
    public  Flux<ClientsFilterDetails> getIhaIoaClientList(ClientsRequestBody clientsRequestBody) {
        String query = SELECT_IOA_IHA_CLIENTS_DETAILS_QUERY;
        log.info("IOA-IHA Clients query = {}", query);
        return opportunityClient.execute(query)
                .bind(ProviderGroupConstants.OPPORTUNITY_PROVIDER_GROUP_ID, clientsRequestBody.getProviderGroupId())
                .bind(ProviderGroupConstants.PROGRAM_YEAR, clientsRequestBody.getProgramYear())
                .bind(ProviderGroupConstants.STATE,clientsRequestBody.getProviderState())
                .as(ClientsFilterDetails.class)
                .fetch()
                .all();

    }

    @Override
    public Flux<LobFilterDetails> getRiskQualityOpportunitiesLobDetails(ClientsRequestBody clientsRequestBody) {
        String query;

        if(!Objects.isNull(clientsRequestBody.getTeamType())&&clientsRequestBody.getTeamType().equalsIgnoreCase(TEAMTYPE_QFO)){
            if(Objects.isNull(clientsRequestBody.getHealthSystemId())){
                query = String.format(SELECT_RISK_QUALITY_LOB_DETAILS_QUERY_MONTHLY,"  AND pgod.ProviderGroupID =  '" + clientsRequestBody.getProviderGroupId() + "'");
            }else{
                query = String.format(SELECT_RISK_QUALITY_LOB_DETAILS_QUERY_MONTHLY,"  AND pgod.HealthSystemId =  '" + clientsRequestBody.getHealthSystemId() + "'");
            }
        }
        else{
            query = String.format(SELECT_RISK_QUALITY_LOB_DETAILS_QUERY_MONTHLY,"  AND pgod.ProviderGroupID =  '" + clientsRequestBody.getProviderGroupId() + "' " + " AND pgod.State = '" + clientsRequestBody.getProviderState() + "'");
        }
        return opportunityClient.execute(query)
                .bind(ProviderGroupConstants.MASTER_OPPORTUNITY_TYPE, clientsRequestBody.getMasterOpportunityTypes())
                .bind(ProviderGroupConstants.PROGRAM_YEAR, clientsRequestBody.getProgramYear())
                .bind(ProviderGroupConstants.TEAMTYPE, clientsRequestBody.getTeamType())
                .as(LobFilterDetails.class)
                .fetch()
                .all();

    }

    @Override
    public Flux<LobFilterDetails> getIhaIoaLobList(ClientsRequestBody clientsRequestBody) {
        String query = SELECT_IOA_IHA_LOBS_DETAILS_QUERY;
        log.info("IOA-IHA LOB query = {}", query);
        return opportunityClient.execute(query)
                .bind(ProviderGroupConstants.OPPORTUNITY_PROVIDER_GROUP_ID, clientsRequestBody.getProviderGroupId())
                .bind(ProviderGroupConstants.PROGRAM_YEAR, clientsRequestBody.getProgramYear())
                .bind(ProviderGroupConstants.STATE,clientsRequestBody.getProviderState())
                .as(LobFilterDetails.class)
                .fetch()
                .all();

    }

    @Override
    public Flux<OpportunityConfigurationDTO> getAllOpportunitiesConfigurationsByMasterOpportunityName(String masterOpportunityName, Integer programYear,String teamType) {
        String masterOppName = "";
        if(masterOpportunityName.equalsIgnoreCase("Quality Gaps") && teamType.equalsIgnoreCase(TEAMTYPE_QFO)){
            masterOppName = " AND MasterOpportunityName in ('Quality Gaps', 'Medication Adherence') ";
        }else{
            masterOppName = " AND MasterOpportunityName ='"+masterOpportunityName+"'";
        }
        return opportunityClient.execute(String.format(SELECT_OPPORTUNITIES_CONFIGURATION_BY_MASTER_OPPORTUNITY_NAME, masterOppName))
                .bind(ProviderGroupConstants.PROGRAM_YEAR,programYear)
                .bind(ProviderGroupConstants.TEAM_TYPE,teamType)
                .as(OpportunityConfigurationDTO.class)
                .fetch()
                .all();
    }

    @Override
    public Flux<OpportunityConfigurationDTO> getOpportunitiesConfigurationsByMasterOpportunityNameAndOpportunities(String masterOpportunityName, Set<String> opportunities, Integer programYear,String teamType) {
        String masterOppName = "";
        if(masterOpportunityName.equalsIgnoreCase("Quality Gaps") && teamType.equalsIgnoreCase(TEAMTYPE_QFO)){
            masterOppName = " AND ( MasterOpportunityName = 'Quality Gaps' OR MasterOpportunityName = 'Medication Adherence' ) ";
        }else{
            masterOppName = " AND MasterOpportunityName = '"+masterOpportunityName+"'";
        }
        return opportunityClient.execute(String.format(SELECT_OPPORTUNITIES_CONFIGURATION_BY_MASTER_OPPORTUNITY_NAME_AND_OPPORTUNITIES_NAME, masterOppName))
                .bind(ProviderGroupConstants.OPPORTUNITY_NAMES,opportunities)
                .bind(ProviderGroupConstants.PROGRAM_YEAR,programYear)
                .bind(ProviderGroupConstants.TEAM_TYPE,teamType)
                .as(OpportunityConfigurationDTO.class)
                .fetch()
                .all();
    }

    @Override
    public Flux<MemberQualityGapDTO> getMemberQualityGapDetailsByOpportunity(OpportunityConfigurationDTO opportunityConfigurationDTO, MemberAssessment memberAssessment, String memberIndicatorValues, boolean exclude) {

        StringBuilder clientIds = new StringBuilder();
        StringBuilder lobNames = new StringBuilder();
        StringBuilder finalFilterChecks = new StringBuilder();
        String teamType = memberAssessment.getTeamType();
        String[] memberIndicatorValueList = memberIndicatorValues.split(","); 
        String memberIndicators = getMemberIndicatorsCondition(memberIndicatorValueList, teamType);
        if (!Objects.isNull(memberAssessment.getClientIds())&&!memberAssessment.getClientIds().isEmpty()) {
            memberAssessment.getClientIds().stream().forEach(client -> clientIds.append("'" + client + "',"));
            finalFilterChecks.append(MQ_CLIENT_ID + clientIds.deleteCharAt(clientIds.length() - 1) + " ) ");
        }
        if (!Objects.isNull(memberAssessment.getLobs())&&!memberAssessment.getLobs().isEmpty()) {
            memberAssessment.getLobs().stream().forEach(lob -> lobNames.append("'" + lob + "',"));
            finalFilterChecks.append((teamType.equalsIgnoreCase(TEAMTYPE_QFO)?QFO_LOB_NAME: MQ_LOB_NAME ) + lobNames.deleteCharAt(lobNames.length() - 1) + " ) ");
        }
        String excluedMedicaid = "";
        if (exclude) {
            excluedMedicaid = " AND NOT mq.LOB_NAME ='" + ProviderGroupConstants.MEDICAID + "'";
        }
        String query = SELECT_MEMBER_QUALITY_GAP_DETAILS;
        if(teamType.equalsIgnoreCase(TEAMTYPE_QFO)) {
        	query = query.replace("%providerState", "");
        	String qfoIndicator = " mq.PCOR_MBR_FLAG = 'Y'  AND LEN(mq.ASSOC_PROV_GRP_ID) > 0 AND LEN(mq.CLIENT_ID) > 0 AND LEN(mq.LINE_OF_BUSINESS) > 0 AND MBR_INCNT_PGM_IND IS NOT NULL AND MBR_INCNT_PGM_IND !='' ";
        	if(Objects.isNull(memberAssessment.getLobs()) || memberAssessment.getLobs().isEmpty()) {
        		qfoIndicator = qfoIndicator + " AND mq.LINE_OF_BUSINESS IN ( "+getQFOLobs()+" ) ";
        	}
        	query = query.replace("%teamTypeCondition", qfoIndicator);
        }
        else {
        	query = query.replace("%providerState", "and mq.ASSOC_PROV_ADR_ST_CD = "+"'"+memberAssessment.getProviderState()+"'");
        	query = query.replace("%teamTypeCondition", " MBR_INCNT_PGM_IND IS NOT NULL AND MBR_INCNT_PGM_IND !='' ");


        }

        return opportunityClient.execute(String.format(query,memberIndicators,( " And " + opportunityConfigurationDTO.getWhereClauseCondition()+ excluedMedicaid + " and "+opportunityConfigurationDTO.getSelectClauseCondition() + finalFilterChecks.toString())))
                .bind(ProviderGroupConstants.PROGRAM_YEAR,memberAssessment.getProgramYear())
                .bind(ProviderGroupConstants.CARE_OPPORTUNITY,opportunityConfigurationDTO.getOpportunityName())
                .bind(ProviderGroupConstants.OPPORTUNITY_PROVIDER_GROUP_ID,memberAssessment.getProviderGroupId())
                .as(MemberQualityGapDTO.class)
                .fetch()
                .all();
    }

    @Override
    public Mono<String> getMemberIndicator(String name) {
        return opportunityClient.execute(FETCH_MEMBER_INDICATOR)
                .bind(ProviderGroupConstants.MEMBER_INC_PROGRAM_INDICATOR,name)
                .as(String.class)
                .fetch()
                .first();
    }

    @Override
    public Flux<MemberSuspectConditionDTO> getMemberSuspectConditionDetailsByOpportunity(OpportunityConfigurationDTO opportunityConfigurationDTO, MemberAssessment memberAssessment,Map<String,String> masterConfigValues,boolean excludeRecords) {
        StringBuilder clientIds = new StringBuilder();
        StringBuilder lobNames = new StringBuilder();
        StringBuilder finalFilterChecks = new StringBuilder();
        String teamType = memberAssessment.getTeamType();
        String memberIncProgramIndicator = teamType.equalsIgnoreCase(TEAMTYPE_QFO)?ProviderGroupConstants.QFO_SUSPECT_MEMBERINCPROGRAMINDICATOR:ProviderGroupConstants.MEMBER_INC_PROGRAM_INDICATOR_NAME;
        String[] memberIndicatorValueList = masterConfigValues.get(memberIncProgramIndicator).split(",");
        String memberIndicators = getMemberIndicatorsCondition(memberIndicatorValueList, teamType);
        if (!Objects.isNull(memberAssessment.getClientIds())&&!memberAssessment.getClientIds().isEmpty()) {
            memberAssessment.getClientIds().stream().forEach(client -> clientIds.append("'" + client + "',"));
            finalFilterChecks.append(" AND CLIENT_ID in(" + clientIds.deleteCharAt(clientIds.length() - 1) + " ) ");
        }
        if (!Objects.isNull(memberAssessment.getLobs())&&!memberAssessment.getLobs().isEmpty()) {
            memberAssessment.getLobs().stream().forEach(lob -> lobNames.append("'" + lob + "',"));
            finalFilterChecks.append((teamType.equalsIgnoreCase(TEAMTYPE_QFO)?QFO_LOB_NAME: " AND LOB_NAME in(" ) + lobNames.deleteCharAt(lobNames.length() - 1) + " ) ");
        }

        StringBuilder selectClauseCondition = new StringBuilder();
        if(teamType.equalsIgnoreCase(TEAMTYPE_QFO)) {
            if(opportunityConfigurationDTO.getSelectClauseCondition() != null) {
                selectClauseCondition.append(AND + opportunityConfigurationDTO.getSelectClauseCondition());
            }
        }else {
            String formattedNotAssessedStatus = Arrays.stream(masterConfigValues.get(ProviderGroupConstants.SUSPECT_OPEN_GAP_STATUS_VALUES).split(",")).map(status -> "'" + status + "'"
            ).collect(Collectors.joining(","));
            selectClauseCondition.append(AND + " ASSESSMENT_STATUS in (" + formattedNotAssessedStatus + ") ");
        }

        String excluedMedicaid = "";
        if (excludeRecords) {
            excluedMedicaid = " AND NOT LOB_NAME= '" + ProviderGroupConstants.MEDICAID + "'";
        }
        String query = SELECT_MEMBER_SUSPECT_CONDITION_DETAILS;
        query = includeQFOTeamTypeCondition(query, memberAssessment);
        
        return opportunityClient.execute(String.format(query, memberIndicators,( selectClauseCondition + excluedMedicaid + finalFilterChecks.toString())))
                .bind(ProviderGroupConstants.PROGRAM_YEAR,memberAssessment.getProgramYear())
                .bind(ProviderGroupConstants.OPPORTUNITY_PROVIDER_GROUP_ID,memberAssessment.getProviderGroupId())
                .as(MemberSuspectConditionDTO.class)
                .fetch()
                .all();
    }

    @Override
    public Flux<MeasuresThresholdConfigurationDTO> getStarThreshold(String teamType, int programYear){
        log.info("Fetching threshold values from MeasuresThresholdConfiguration table using Query {}", FETCH_STAR_THRESHOLD);
        return opportunityClient.execute(FETCH_STAR_THRESHOLD)
                .bind(ProviderGroupConstants.TEAMTYPE, teamType)
                .bind(ProviderGroupConstants.PROGRAM_YEAR, programYear)
                .as(MeasuresThresholdConfigurationDTO.class)
                .fetch()
                .all();
    }

    @Override
    public Flux<String> getMinEligibleMembersCount(){
        log.info("Fetching Min Eligible Member Count from Master Config using Query {}", FETCH_MIN_ELIGIBLE_MEMBERS);
        return opportunityClient.execute(FETCH_MIN_ELIGIBLE_MEMBERS)
                .as(String.class)
                .fetch()
                .all();
    }

    @Override
    public Flux<MemberACVDTO> getACVNotCompleted(OpportunityConfigurationDTO opportunityConfigurationDTO, MemberAssessment memberAssessment, String memberIndicatorValues,boolean excludeRecords) {

        StringBuilder clientIds = new StringBuilder();
        StringBuilder lobNames = new StringBuilder();
        StringBuilder finalFilterChecks = new StringBuilder();
        String[] memberIndicatorValueList = memberIndicatorValues.split(",");
        StringBuilder whereClauseCondition = new StringBuilder();
        StringBuilder selectClauseCondition = new StringBuilder();

        String teamType = memberAssessment.getTeamType();
        String memberIndicators = getMemberIndicatorsCondition(memberIndicatorValueList, teamType);



        if (!Objects.isNull(memberAssessment.getClientIds())&&!memberAssessment.getClientIds().isEmpty()) {
            memberAssessment.getClientIds().stream().forEach(client -> clientIds.append("'" + client + "',"));
            finalFilterChecks.append(MQ_CLIENT_ID + clientIds.deleteCharAt(clientIds.length() - 1) + " ) ");
        }
        if (!Objects.isNull(memberAssessment.getLobs())&&!memberAssessment.getLobs().isEmpty()) {
            memberAssessment.getLobs().stream().forEach(lob -> lobNames.append("'" + lob + "',"));
            finalFilterChecks.append((teamType.equalsIgnoreCase(TEAMTYPE_QFO)?QFO_LOB_NAME: MQ_LOB_NAME ) + lobNames.deleteCharAt(lobNames.length() - 1) + " ) ");
        }

        if(memberAssessment.getTeamType().equalsIgnoreCase(TEAMTYPE_QFO) && opportunityConfigurationDTO.getOpportunityName().equalsIgnoreCase("Pre-visit Planning Confirmations Missing for Patients with an ACV Completed")){
            selectClauseCondition.append(AND + " ( (mq.MBR_ANNL_CARE_VST_DT is not null) AND (FORMAT (mq.MBR_ANNL_CARE_VST_DT, 'yyyy') = :calendarYear )) " );
        }else{
            selectClauseCondition.append(AND+ " ( (mq.MBR_ANNL_CARE_VST_DT is null) OR (FORMAT (mq.MBR_ANNL_CARE_VST_DT,'yyyy')!= :calendarYear )) ");
        }

        if(opportunityConfigurationDTO.getWhereClauseCondition()!=null){
            whereClauseCondition.append(AND + opportunityConfigurationDTO.getWhereClauseCondition());

        }

        String excluedMedicaid = "";
        if (excludeRecords) {
            excluedMedicaid = " AND NOT LOB_NAME='" + ProviderGroupConstants.MEDICAID + "'";
        }
//        StringBuilder finalfilter = selectClauseCondition.append(whereClauseCondition).append(finalFilterChecks);

        log.info("query");
        String query = SELECT_ACV_NOT_COMPLETED_DETAILS;
        query = includeQFOTeamTypeCondition(query, memberAssessment);
        log.info(String.format(query,memberIndicators, ( excluedMedicaid + selectClauseCondition + whereClauseCondition + finalFilterChecks.toString() )));

        int calendarYear = LocalDate.now().getYear();
        return opportunityClient.execute(String.format(query,memberIndicators, ( excluedMedicaid + selectClauseCondition + whereClauseCondition + finalFilterChecks.toString() )))
                .bind(ProviderGroupConstants.PROGRAM_YEAR, memberAssessment.getProgramYear())
                .bind(ProviderGroupConstants.OPPORTUNITY_PROVIDER_GROUP_ID,memberAssessment.getProviderGroupId())
                .bind(ProviderGroupConstants.CALENDAR_YEAR, calendarYear)
                .as(MemberACVDTO.class)
                .fetch()
                .all();
    }

    @Override
    public Flux<MemberSuspectPatientsDTO> getMemberNotFullyAssessedDetails(OpportunityConfigurationDTO opportunityConfigurationDTO, MemberAssessment memberAssessment, Map<String,String> masterConfigValues,boolean excludeRecords) {
        StringBuilder clientIds = new StringBuilder();
        StringBuilder lobNames = new StringBuilder();
        StringBuilder finalFilterChecks = new StringBuilder();
        String teamType = memberAssessment.getTeamType();
        String memberIncProgramIndicator = teamType.equalsIgnoreCase(TEAMTYPE_QFO)?ProviderGroupConstants.QFO_SUSPECT_MEMBERINCPROGRAMINDICATOR:ProviderGroupConstants.MEMBER_INC_PROGRAM_INDICATOR_NAME;
        String[] memberIndicatorValueList = masterConfigValues.get(memberIncProgramIndicator).split(",");
        String memberIndicators = getMemberIndicatorsCondition(memberIndicatorValueList, teamType);
        if (!Objects.isNull(memberAssessment.getClientIds())&&!memberAssessment.getClientIds().isEmpty()) {
            memberAssessment.getClientIds().stream().forEach(client -> clientIds.append("'" + client + "',"));
            finalFilterChecks.append(" AND CLIENT_ID in (" + clientIds.deleteCharAt(clientIds.length() - 1) + " ) ");
        }
        if (!Objects.isNull(memberAssessment.getLobs())&&!memberAssessment.getLobs().isEmpty()) {
            memberAssessment.getLobs().stream().forEach(lob -> lobNames.append("'" + lob + "',"));
            finalFilterChecks.append((teamType.equalsIgnoreCase(TEAMTYPE_QFO)?QFO_LOB_NAME:" AND LOB_NAME in (" ) + lobNames.deleteCharAt(lobNames.length() - 1) + " ) ");
        }


        StringBuilder selectClauseCondition = new StringBuilder();
        if(teamType.equalsIgnoreCase(TEAMTYPE_QFO)){
            if(opportunityConfigurationDTO.getSelectClauseCondition() != null) {
                selectClauseCondition.append(AND + opportunityConfigurationDTO.getSelectClauseCondition());
            }
        }else{
            String formattedNotAssessedStatus = Arrays.stream(masterConfigValues.get(ProviderGroupConstants.SUSPECT_OPEN_GAP_STATUS_VALUES).split(",")).map(status -> "'" + status + "'"
            ).collect(Collectors.joining(","));
            selectClauseCondition.append(AND + " ASSESSMENT_STATUS in (" + formattedNotAssessedStatus + ") ");
        }

        String excluedMedicaid = "";
        if (excludeRecords) {
            excluedMedicaid = " AND NOT LOB_NAME='" + ProviderGroupConstants.MEDICAID + "'";
        }
        String query = SELECT_MEMBER_SUSPECT_NOT_FULLY_ASSESSED_DETAILS;
        
        query = includeQFOTeamTypeCondition(query, memberAssessment);
        log.info("Member suspect Not fully Assessed query {}",String.format(query, memberIndicators,( selectClauseCondition +  excluedMedicaid + finalFilterChecks.toString())));
        return opportunityClient.execute(String.format(query, memberIndicators,( selectClauseCondition +  excluedMedicaid + finalFilterChecks.toString())))
                .bind(ProviderGroupConstants.PROGRAM_YEAR,memberAssessment.getProgramYear())
                .bind(ProviderGroupConstants.OPPORTUNITY_PROVIDER_GROUP_ID,memberAssessment.getProviderGroupId())
                .as(MemberSuspectPatientsDTO.class)
                .fetch()
                .all();
    }

    @Override
    public Flux<String> getQualityGapOpportunitiesDetailsByCount( MemberAssessment memberAssessment) {

        StringBuilder clientIds = new StringBuilder();
        StringBuilder lobNames = new StringBuilder();
        StringBuilder finalFilterChecks = new StringBuilder();


        if (!Objects.isNull(memberAssessment.getClientIds())&&!memberAssessment.getClientIds().isEmpty()) {
            memberAssessment.getClientIds().stream().forEach(client -> clientIds.append("'" + client + "',"));
            finalFilterChecks.append(" and pgrqod.ClientId in(" + clientIds.deleteCharAt(clientIds.length() - 1) + " ) ");
        }
        if (!Objects.isNull(memberAssessment.getLobs())&&!memberAssessment.getLobs().isEmpty()) {
            memberAssessment.getLobs().stream().forEach(lob -> lobNames.append("'" + lob + "',"));
            finalFilterChecks.append(" and pgrqod.LobName in(" + lobNames.deleteCharAt(lobNames.length() - 1) + " ) ");
        }

        String query = SELECT_OPPORTUNITY_BY_COUNT;
        if(memberAssessment.getTeamType().equalsIgnoreCase("QFO")) {
        	query =query.replace("%state", "");
        }
        else {
        	query = query.replace("%state", " and pgrqod.State = '"+memberAssessment.getProviderState()+"'");
        }

        return opportunityClient.execute(String.format(query, finalFilterChecks.toString()))
                .bind(ProviderGroupConstants.PROGRAM_YEAR,memberAssessment.getProgramYear())
                .bind(ProviderGroupConstants.OPPORTUNITY_PROVIDER_GROUP_ID,memberAssessment.getProviderGroupId())
                .bind(ProviderGroupConstants.TEAM_TYPE,memberAssessment.getTeamType())
                .as(String.class)
                .fetch()
                .all();
    }

    @Override
    public Mono<Map<String, String>> getMasterConfigurationValues() {
        Map<String,String> configMap = new HashMap<>();
        return opportunityClient.execute(String.format(FETCH_CATEGORY_MASTER_CONFIGURATION,
                Stream.of(ProviderGroupConstants.MEMBER_INC_PROGRAM_INDICATOR_NAME, ProviderGroupConstants.SUSPECT_OPEN_GAP_STATUS_VALUES, ProviderGroupConstants.QFO_SUSPECT_MEMBERINCPROGRAMINDICATOR, ProviderGroupConstants.QFO_ACV_MEMBERINCPROGRAMINDICATOR).collect(Collectors.joining("','", "'", "'"))))
                .map((row, rowMetadata) -> CategoryMasterConfigDTO.builder()
                        .name(row.get("Name", String.class))
                        .value(row.get("Value", String.class))
                        .build()
                )
                .all()
                .doOnNext(masterConfigDto->{
                    switch (masterConfigDto.getName()) {
                        case ProviderGroupConstants.MEMBER_INC_PROGRAM_INDICATOR_NAME:
                            configMap.put(ProviderGroupConstants.MEMBER_INC_PROGRAM_INDICATOR_NAME, masterConfigDto.getValue());
                            break;
                        case ProviderGroupConstants.SUSPECT_OPEN_GAP_STATUS_VALUES:
                            configMap.put(ProviderGroupConstants.SUSPECT_OPEN_GAP_STATUS_VALUES, masterConfigDto.getValue());
                            break;
                        case ProviderGroupConstants.QFO_SUSPECT_MEMBERINCPROGRAMINDICATOR:
                            configMap.put(ProviderGroupConstants.QFO_SUSPECT_MEMBERINCPROGRAMINDICATOR, masterConfigDto.getValue());
                            break;
                        case ProviderGroupConstants.QFO_ACV_MEMBERINCPROGRAMINDICATOR:
                            configMap.put(ProviderGroupConstants.QFO_ACV_MEMBERINCPROGRAMINDICATOR, masterConfigDto.getValue());
                            break;
                        default:
                            break;
                    }
                })
                .then(Mono.just(configMap));
    }

    @Override
    public Flux<QFOHealthSystemOpportunitiesDetails> getQFOHealthSystemRiskQualityOpportunitiesDetails(QFOHealthSystemDetailsRequestBody qfoHealthSystemDetailsRequestBody) {
        StringBuilder lobNames = new StringBuilder();
        StringBuilder finalFilterChecks = new StringBuilder();

        if (!Objects.isNull(qfoHealthSystemDetailsRequestBody.getLobs())&&!qfoHealthSystemDetailsRequestBody.getLobs().isEmpty()) {
            qfoHealthSystemDetailsRequestBody.getLobs().stream().forEach(lob -> lobNames.append("'" + lob + "',"));
            finalFilterChecks.append(" AND hsrqodm.LobName IN (" + lobNames.deleteCharAt(lobNames.length() - 1) + " ) ");
        }

        String finalQuery = String.format(QFO_HEALTH_SYSTEM_OPPORTUNITIES_DETAILS_QUERY, finalFilterChecks);
        log.info("Details Request Body :: {}  QFO HealthSystem  RiskQualityOpportunitiesDetail Query Query :: {}", qfoHealthSystemDetailsRequestBody, finalQuery);
        return opportunityClient.execute(finalQuery)
                .bind("HEALTHSYSTEMID", qfoHealthSystemDetailsRequestBody.getHealthSystemId())
                .bind("PROGRAMYEAR", qfoHealthSystemDetailsRequestBody.getProgramYear())
                .bind("MASTEROPPORTUNITYTYPE", qfoHealthSystemDetailsRequestBody.getOpportunityTypes())
                .as(QFOHealthSystemOpportunitiesDetails.class)
                .fetch()
                .all();
    }
    
	public String getQFOLobs() {
     String[] lobs = opportunityClient.execute(QFO_LOBS_QUERY).as(String.class).fetch().one().block().split(",");
	 return Arrays.stream(lobs).map(lob -> "'" + lob + "'").collect(Collectors.joining(","));

	}
	
	private String includeQFOTeamTypeCondition(String query, MemberAssessment memberAssessment) {
		 if(memberAssessment.getTeamType().equalsIgnoreCase(TEAMTYPE_QFO)) {
             String qfoTeamTypeCondition = " AND PCOR_MBR_FLAG = 'Y' AND LEN(ASSOC_PROV_GRP_ID) > 0 AND LEN(CLIENT_ID) > 0 AND LEN(LINE_OF_BUSINESS) > 0 ";
             if(Objects.isNull(memberAssessment.getLobs()) || memberAssessment.getLobs().isEmpty()) {
                 qfoTeamTypeCondition = qfoTeamTypeCondition + " AND LINE_OF_BUSINESS IN ( "+getQFOLobs()+" ) ";
             }
             query = query.replace("%qfoTeamTypeCondition", qfoTeamTypeCondition);
             query = query.replace("%providerstate", "");
         }
         else {
             query = query.replace("%qfoTeamTypeCondition", "");
             query = query.replace("%providerstate", "and ASSOC_PROV_ADR_ST_CD = "+"'"+memberAssessment.getProviderState()+"'");
        }
    	return query;
	}
	
	private String getMemberIndicatorsCondition(String [] memberIndicatorValueList, String teamType ) {
	    String incentiveProgramCondition = teamType.equalsIgnoreCase(TEAMTYPE_QFO) ?"MBR_INCNT_PGM_IND LIKE":"MBR_INCNT_PGM_IND NOT LIKE";
		String conditionalOperator = teamType.equalsIgnoreCase(TEAMTYPE_QFO)?"OR":"AND";
		StringBuilder memberIndicators = new StringBuilder("( ");
		 for(String memberIndicator: memberIndicatorValueList) {
	            memberIndicators.append(incentiveProgramCondition +"  '%" + memberIndicator.trim() + "%' "+conditionalOperator+" ");
	        }
		    memberIndicators.delete(memberIndicators.length()-(conditionalOperator.length()+1), memberIndicators.length());
		    memberIndicators.append(" )");
		    memberIndicators.append(" ");
		    memberIndicators.append("AND");
		    memberIndicators.append(" ");
	        return memberIndicators.toString();
	}


    @Override
    public Flux<PAConfigDetails> getOFCPAMasterConfigurationValues() {
            log.info("Getting OFC-PA config values ");
            return opportunityClient.execute(OFC_PA_INTEGRATION_CONFIG_QUERY)
                                .as(PAConfigDetails.class)
                                .fetch()
                                .all();
        }
    
}
