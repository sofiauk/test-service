package com.optum.rqns.ftm.controller;

import com.optum.rqns.ftm.customannotation.CustomApiResponse;
import com.optum.rqns.ftm.response.processor.providergrp.CalculateActualResponse;
import com.optum.rqns.ftm.service.processor.providergrp.ProviderGroupProcessorServiceImpl;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;
import org.springframework.context.annotation.Profile;

@Profile("rqnsFtmApi")
@RestController
@RequestMapping("/v1/provider-groups/processors")
@Slf4j
@CustomApiResponse
public class ProviderGroupProcessorController {

    @Autowired
    ProviderGroupProcessorServiceImpl providerGroupProcessorService;

    @ApiResponse(responseCode = "200", description = "Success Request", content = @Content(schema = @Schema(implementation = CalculateActualResponse.class),mediaType = MediaType.APPLICATION_JSON_VALUE))
    @GetMapping("/till-date-current-values/{program-year}")
    public Mono<CalculateActualResponse> generateAndUpdateYTDReturnActual(
            @PathVariable("program-year") int programYear
            , @RequestParam(name = "all-provider-groups", required = false) boolean isAllProviderGroups
    ) {
        log.debug("Update YTD Actual for the given year: {}, {}",
                programYear, isAllProviderGroups);
        return providerGroupProcessorService
                        .updateYTDActual(programYear,true,true);
//                        .map(cn-> "total Count:::"+cn)
    }
}
