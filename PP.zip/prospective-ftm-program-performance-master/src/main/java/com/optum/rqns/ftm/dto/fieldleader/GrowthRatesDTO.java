package com.optum.rqns.ftm.dto.fieldleader;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class GrowthRatesDTO {

    private List<GrowthRate> national;
    private List<GrowthRate> currentUser;
    private List<GrowthRate> myTeam;
    private List<GrowthRate> regions;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class GrowthRate {
        private String parentScope;
        private String scope;
        private String firstName;
        private String lastName;
        private String role;
        private boolean isCurrentYear;
        private Integer totalGroupsSum;
        private Integer agreedParticipateSum;
        private Integer engagedParticipateSum;
        private LocalDateTime updatedDate;
    }
}
