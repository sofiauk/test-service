package com.optum.rqns.ftm.model.providergrpdeployment;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class ClientDetail {
    private String uniqueKey;
    private String clientId;
    private String clientName;
    private PerformanceStats performanceStats;
    private List<ClientChannelDetail> clientChannels;
}
