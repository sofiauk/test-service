package com.optum.rqns.ftm.dto.rules;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.time.LocalDateTime;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ProviderGroupOpportunitiesDetailsDTO {

    int opportunityDetailID;
    String serviceLevel;
    String clientId;
    String clientName;
    String lobName;
    String opportunityType;
    String opportunitySubType;
    int opportunityTypePosition;
    int opportunitySubTypePosition;
    LocalDateTime latestUpdatedDate;
    String displayText;
    int assessmentCount;
    int deploymentCount;
    int gapCount;
}
