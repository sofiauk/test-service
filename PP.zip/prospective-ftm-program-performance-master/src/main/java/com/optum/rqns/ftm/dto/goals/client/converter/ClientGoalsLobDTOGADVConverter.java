package com.optum.rqns.ftm.dto.goals.client.converter;

import com.optum.rqns.ftm.dto.goals.client.RegionGADVDTO;
import com.optum.rqns.ftm.repository.goals.client.ClientGoalsReactiveRepositoryImpl;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;

public class ClientGoalsLobDTOGADVConverter implements Converter<Row, RegionGADVDTO>,DTOConverter {
    @Override
    public RegionGADVDTO convert(Row rs) {
     return  RegionGADVDTO.builder()
             .clientName(rs.get(ClientGoalsReactiveRepositoryImpl.ColumnNames.CLIENTNAME.getColumnName(), String.class))
             .region(rs.get(ClientGoalsReactiveRepositoryImpl.ColumnNames.REGIONNAME.getColumnName(), String.class))
             .lob(rs.get(ClientGoalsReactiveRepositoryImpl.ColumnNames.LOBNAME.getColumnName(), String.class))
             .clientId(getIntegerValue(rs, ClientGoalsReactiveRepositoryImpl.ColumnNames.CLIENTID.getColumnName()))
             .state(rs.get(ClientGoalsReactiveRepositoryImpl.ColumnNames.STATENAME.getColumnName(), String.class))
             .stateId(rs.get(ClientGoalsReactiveRepositoryImpl.ColumnNames.STATEID.getColumnName(), String.class))
             .regionId(rs.get(ClientGoalsReactiveRepositoryImpl.ColumnNames.REGIONID.getColumnName(), String.class))
             .hcfa(rs.get(ClientGoalsReactiveRepositoryImpl.ColumnNames.HCFA.getColumnName(), String.class))
             .secondarySubmission(getIntegerValue(rs,ClientGoalsReactiveRepositoryImpl.ColumnNames.SECONDARYSUBMISSION.getColumnName()))
             .gaRisk(getFloatValue(rs,ClientGoalsReactiveRepositoryImpl.ColumnNames.GARISK.getColumnName()))
             .gaQuality(getFloatValue(rs, ClientGoalsReactiveRepositoryImpl.ColumnNames.GAQUALITY.getColumnName()))
             .dvRisk(getFloatValue(rs, ClientGoalsReactiveRepositoryImpl.ColumnNames.DVRISK.getColumnName()))
             .dvQuality(getFloatValue(rs, ClientGoalsReactiveRepositoryImpl.ColumnNames.DVQUALITY.getColumnName()))
             .riskGapClosure(getFloatValue(rs, ClientGoalsReactiveRepositoryImpl.ColumnNames.RISKGAPCLOSURE.getColumnName()))
             .diagnosedVerified(getFloatValue(rs, ClientGoalsReactiveRepositoryImpl.ColumnNames.DIAGNOSEDVERIFIED.getColumnName()))
             .build();
    }
}
