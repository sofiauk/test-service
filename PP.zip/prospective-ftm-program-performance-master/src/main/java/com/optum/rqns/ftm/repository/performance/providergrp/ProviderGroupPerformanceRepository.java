package com.optum.rqns.ftm.repository.performance.providergrp;

import com.optum.rqns.ftm.dto.performance.providergrp.AssignedProviderGroupPerformanceDTO;
import com.optum.rqns.ftm.dto.performance.providergrp.ProviderGroupLobPerformanceDTO;
import com.optum.rqns.ftm.enums.RoleType;
import com.optum.rqns.ftm.model.performance.providergrp.AssignedProviderGroupOpportunities;
import com.optum.rqns.ftm.dto.performance.providergrp.ProviderGroupPerformanceYTDGraphDTO;
import com.optum.rqns.ftm.model.performance.providergrp.ProviderGroupStateDerivedDeployments;
import com.optum.rqns.ftm.model.performance.providergrp.ProviderGroupStateReturnsNetCNA;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface ProviderGroupPerformanceRepository {
    Flux<ProviderGroupLobPerformanceDTO> getProviderGroupPerformance(String providerGroupId, String state, String serviceLevel, int programYear);
    Flux<ProviderGroupLobPerformanceDTO> getProviderGroupPerformanceRules(String providerGroupId, String state, String serviceLevel, int programYear);

    Mono<AssignedProviderGroupPerformanceDTO> getAssignedProviderGroupsPerformance(String providerGroupIds, int programYear, RoleType roleType);

    Flux<String> getCurrentProgramYear(String userRole);

    Flux<AssignedProviderGroupOpportunities> getAssignedProviderGroupOpportunities(String uuid, RoleType roleType);

    Flux<ProviderGroupPerformanceYTDGraphDTO> getProviderGroupsPerformanceYTDReturns(String uuid, RoleType roleType, int programYear);

    Flux<ProviderGroupStateDerivedDeployments> getProviderGroupsStateDerivedDeploymentCounts(int programYear, String type, String name, String state, String serviceLevel, int offset, int limit);

    Flux<ProviderGroupStateReturnsNetCNA> getProviderGroupsStateReturnsNetCNACounts(int programYear, String type, String name, String state, String serviceLevel, int offset, int limit);
}
