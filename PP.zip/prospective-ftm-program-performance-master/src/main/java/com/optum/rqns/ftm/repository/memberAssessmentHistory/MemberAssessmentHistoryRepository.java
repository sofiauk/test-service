package com.optum.rqns.ftm.repository.memberAssessmentHistory;

import com.optum.rqns.ftm.dto.memberassessment.MemberAssessmentHistory;
import reactor.core.publisher.Flux;

public interface MemberAssessmentHistoryRepository {
    Flux<MemberAssessmentHistory> getMemberAssessmentHistoryDetails(String providerGroupId);
}
