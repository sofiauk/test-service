package com.optum.rqns.ftm.dto.commandcenter;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class GrowthRateDTO {

    private Integer agreedYTD;
    private Integer agreedTarget;
    private Double agreedYTDPercent;
    private Integer engagedYTD;
    private Integer engagedTarget;
    private Double engagedYTDPercent;
}
