package com.optum.rqns.ftm.repository.common;

import com.optum.rqns.ftm.constants.ProviderGroupConstants;
import com.optum.rqns.ftm.constants.RuleConstants;
import com.optum.rqns.ftm.dto.job_configuration.CategoryUpdatedDetailDTO;
import com.optum.rqns.ftm.dto.job_configuration.JobConfigurationDTO;
import com.optum.rqns.ftm.dto.job_configuration.JobConfigurationRequestBody;
import com.optum.rqns.ftm.dto.job_configuration.PafOverAllStatusDetailDTO;
import com.optum.rqns.ftm.dto.processor.providergrp.JobRunConfigurationDTO;
import com.optum.rqns.ftm.dto.processor.providergrp.ProgramYearCalendarDTO;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.repository.processor.providergrp.ProviderGroupYTDActualProcessorRepositoryImpl;
import com.optum.rqns.ftm.util.ProgramPerformanceUtil;
import io.r2dbc.spi.Batch;
import io.r2dbc.spi.ConnectionFactory;
import io.r2dbc.spi.Result;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.r2dbc.connectionfactory.ConnectionFactoryUtils;
import org.springframework.data.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

@Repository
@Slf4j
public class CommonRepositoryImpl implements CommonRepository {

    private static final String INSERT_QUERY = "insertQuery";
    private static final String ROWS_UPDATE = "rowsUpdate";
    private static final String JOB_NAME = "JOB_NAME";


    public enum ColumnNames {
        JOB_NAME ("JobName"),
        JOB_DESCRIPTION ("JobDescription"),
        LAST_RUN_DATE ("LastRunDate"),
        STATUS ("Status"),
        JOB_START ("JobStart"),
        JOB_END ("JobEnd"),
        LAST_SUCCESSFUL_RUN_DATE ("LastSuccessfulRunDate"),
        AFFECTED_ROWS ("AffectedRows"),
        MODIFIED_BY ("ModifiedBy"),
        ERROR_MESSAGE ("errorMessage"),
        JOB_EVENT ("jobEvent"),
        MESSAGE_KEY ("messageKey"),
        MESSAGE ("message"),
        IS_ACTIVE ("isActive"),
        PROGRAM_YEAR ("program-year"),
        DURATIONVALUE ("DurationValue"),
        STARTDATE ("StartDate"),
        ENDDATE ("EndDate"),
        CURRENTPROGRAMYEAR ("CurrentProgramYear");


        private String columnName;

        ColumnNames(String columnName) {
            this.columnName = columnName;
        }

        public String getColumnName() {
            return this.columnName;
        }
    }

    private static final String LOG_LITERAL_RUNNING_QUERY = "Running query";
    private static final String BIND_PARAM_EXECUTION_STATUS = "EXECUTION_STATUS";

    private static final String COMMA = ",";
    private static final String GET_DATE_STR = "getUTCDate()";
    private static final String EQUAL_STR = "=";

    private final ConnectionFactory connectionFactory;
    private final DatabaseClient databaseClient;

    private static final String JOB_RUN_CONFIGURATION_INSERT = "insert into progperf.jobrunconfiguration" +
            " (JobName,JobDescription,LastRunDate,Status,CreatedBy,CreatedDate,ModifiedBy,ModifiedDate,JobStart)" +
            " values('%s',%s,getUTCDate(),'%s','%s',getUTCDate(),'System',getUTCDate(),getUTCDate())";
    private static final String JOB_RUN_CONFIGURATION_UPDATE = "update progperf.jobrunconfiguration set " +
            "ModifiedDate=getUTCDate() " +
            "%s " +
            "where jobName='%s'";

    private static final String GET_JOB_ISACTIVE_BY_NAME = "SELECT isActive FROM [ProgPerf].[JobRunConfiguration] WHERE JobName = :JOB_NAME";

    private static final String GET_JOB_ID_BY_NAME = "SELECT ID FROM [ProgPerf].[JobRunConfiguration] WHERE JobName = :JOB_NAME";

    private static final String INSERT_JOB_HISTORY = "INSERT INTO  [ProgPerf].[JobExecutionHistory] ( [JobID], [Status], [ErrorMessage], [AffectedRows], [JobStart], [JobEvent], [MessageKey])  " +
            "VALUES (:JOB_ID, :EXECUTION_STATUS, :ERROR_MESSAGE, :AFFECTED_ROWS, getUTCDate(), :JOB_EVENT, :MESSAGE_KEY)";

    private static final String GET_LATEST_IDENTITY_FOR_JOB_HISTORY = "SELECT max(ID) FROM ProgPerf.JobExecutionHistory  WHERE [JobID] = :JOB_ID";

    private static final String UPDATE_JOB_HISTORY_COMPLETE_SUCCESS = "UPDATE [ProgPerf].[JobExecutionHistory] " +
            "SET  " +
            "[Status] = :EXECUTION_STATUS, " +
            "[JobEnd] = getUTCDate(), " +
            "[Message] =  CONCAT([Message], ' | ', :MESSAGE_TEXT) " +
            "%s" +
            "WHERE [ID] = :EXECUTION_HISTORY_ID";

    private static final String UPDATE_JOB_HISTORY_ROWS_AFFECTED = ", [AffectedRows] = %s ";

    private static final String UPDATE_JOB_HISTORY_COMPLETE_FAILURE = "UPDATE [ProgPerf].[JobExecutionHistory] " +
            "SET  " +
            "[Status] = :EXECUTION_STATUS, " +
            "[JobEnd] = getUTCDate(), " +
            "[ErrorMessage] =  CONCAT([ErrorMessage], ' | ', :MESSAGE_TEXT) " +
            "WHERE [ID] = :EXECUTION_HISTORY_ID";

    private static final String GET_COUNT_OF_JOB_HISTORY_BY_MESSAGE_KEY = "SELECT COUNT(ID) FROM [ProgPerf].[JobExecutionHistory] WHERE JobID = %s  AND [messageKey] = '%s'";

    private static final String GET_COUNT_OF_JOB_HISTORY_BY_TIME = "SELECT COUNT(ID) FROM [ProgPerf].[JobExecutionHistory] WHERE JobID = %s  AND [JobStart] > DATEADD(MINUTE, -%s, GETUTCDATE())";

    private static final String UPDATE_AFFECTEDROW_JOB_RUN_CONFIG = "update ProgPerf.JobRunConfiguration set AffectedRows =:AffectedRows " +
            "where JobName =:JobName ";

    private static final String UPDATE_AFFECTEDROW_JOB_EXECUTION_HISTORY = "UPDATE ProgPerf.JobExecutionHistory set AffectedRows =:AffectedRows " +
            " where id = (select  max(id) from ProgPerf.JobExecutionHistory " +
            " where JobID  =(select id from ProgPerf.JobRunConfiguration  where JobName =:JobName)) ";

    private static final String GET_ALL_JOBS_CONFIGURATION =
            "select A.ID as JobID,C.ID,A.JobName, A.JobDescription, A.LastRunDate, A.CreatedBy, " +
                    "A.CreatedDate, A.ModifiedBy, A.ModifiedDate, A.LastSuccessfulRunDate, " +
                    "A.messageKey, A.jobEvent, A.message, A.isActive, " +
                    "C.JobID, C.Status,C.ErrorMessage,C.AffectedRows,C.JobStart,C.JobEnd " +
                    "FROM ProgPerf.JobRunConfiguration as A " +
                    "inner join " +
                    "    ( select ID,JobID,JobStart,JobEnd,ErrorMessage,AffectedRows,Status  " +
                    "    from (select ID,JobID,JobStart,JobEnd,ErrorMessage,AffectedRows,Status, " +
                    "    row_number() over (PARTITION by  JobID ORDER by ID desc) as job_rank  " +
                    "    from ProgPerf.JobExecutionHistory) job_history " +
                    "    WHERE job_rank = 1 ) " +
                    "    as C on A.ID = C.JobID " +
                    "ORDER by C.ID DESC";

    private static final String GET_JOB_CONFIGURATION_BY_NAME =
            "select top 1 A.ID as JobID, A.JobName, A.JobDescription, A.LastRunDate, A.CreatedBy, " +
                    "A.CreatedDate, A.ModifiedBy, A.ModifiedDate, A.LastSuccessfulRunDate, " +
                    "A.messageKey, A.jobEvent, A.message, A.isActive, " +
                    "C.ID, C.Status,C.ErrorMessage,C.AffectedRows,C.JobStart,C.JobEnd " +
                    "FROM ProgPerf.JobRunConfiguration as A with (nolock)" +
                    "inner join " +
                    "    ProgPerf.JobExecutionHistory " +
                    "    as C on A.ID = C.JobID " +
                    "where A.JobName = :JOB_NAME " +
                    "ORDER by C.ID DESC";

    private static final String UPDATE_JOB_RUN_CONFIGURATION_UPDATE = "update progperf.jobrunconfiguration set " +
            "ModifiedDate=getUTCDate() " +
            "%s " +
            "where UPPER(jobName) = UPPER('%s')";

    private static final String ELIGIBLE_MEMBER_COUNT_INPUTMAP = "SELECT  " +
            "  DurationValue,  " +
            "  CONVERT(varchar, StartDate, 20) as StartDate,  " +
            "  CONVERT(varchar, EndDate, 20) as EndDate,  " +
            "  (  " +
            "  SELECT  " +
            "    CAST(value AS varchar)  " +
            "  FROM  " +
            "    ProgPerf.MasterConfiguration WITH (NOLOCK)  " +
            "  WHERE  " +
            "    code = 'CurrentProgramYear') AS CurrentProgramYear,  " +
            "  (  " +
            "  SELECT   " +
            "    CONVERT(varchar, jrc.LastSuccessfulRunDate, 20) AS LastSuccessfulRunDate  " +
            "  FROM  " +
            "    ProgPerf.JobRunConfiguration jrc WITH (NOLOCK)  " +
            "  WHERE  " +
            "    jrc.JobName = 'RunEligibleMemberCount')AS LastSuccessfulRunDate  " +
            "FROM  " +
            "  ProgPerf.ProgramYearCalendar WITH (NOLOCK)  " +
            "where  " +
            "  DurationType = 'WEEK'  " +
            "  and StartDate <= (  " +
            "  SELECT    " +
            "    CAST( getUTCDate() AS Date ))  " +
            "  AND EndDate >= (  " +
            "  SELECT  " +
            "    CAST( getUTCDate() AS Date ))";

    private static final String SELECT_PAF_OVER_ALL_STATUS_COUNT = "SELECT project_id AS projectId, overall_status AS overallStatus , count(*) as count " +
            " FROM ProgPerf.PAFM_MASTER pm  WITH (NOLOCK)" +
            " Where project_year = :PROGRAM_YEAR" +
            " GROUP BY " +
            " project_id , " +
            " overall_status ";

    private static final String SELECT_JOBS_UPDATED_DATE = "SELECT  DISTINCT MAX(UpdateDate) AS updateDate ,'Payments' AS category FROM ProgPerf.PafAsfPayment  WITH (NOLOCK) " +
            " UNION ALL " +
            " Select DISTINCT MAX(UpdatedDate)  AS updateDate,  'Secondary Submission' as category from ProgPerf.MemberAssessment ma WITH (NOLOCK) " +
            " where ma.SecondarySubmissionUpdateFlag  IS NOT Null AND ma.project_year = :PROGRAM_YEAR " +
            " UNION ALL " +
            " Select  DISTINCT MAX(mag.RefreshDate)  AS updateDate,  'Outliers' as category from ProgPerf.MemberAssessmentGap mag WITH (NOLOCK) " +
            "Where mag.ProgramYear = :PROGRAM_YEAR";

    private static final String GET_CASCADED_JOBS=  "SELECT convert(varchar(4000), jrc.cascadedEvents) as cascadedEvents from ProgPerf.JobRunConfiguration jrc where jrc.JobName =:JOB_NAME";

    private static final String GET_JOB_FREQUENCY_CHECK=  "Select (case when (jrc.Frequency is null or jrc.Frequency ='')  then 'ALL' else jrc.Frequency end) as  Frequency  from ProgPerf.JobRunConfiguration jrc where jrc.JobName=:JOB_NAME and jrc.isActive=1 ;";

    private static final String UPDATE_REGION_QUERY = "update %s  " +
            "set Region  = ht.location " +
            "FROM %s PGP  " +
            "join ProgPerf.GeographicalHierarchy gh on gh.Location = PGP.State and  gh.LocationType ='State' " +
            "join ProgPerf.GeographicalHierarchy ht on ht.[Level] = gh.Level.GetAncestor(2) " +
            "WHERE PGP.DurationValue =:DurationValue " +
            "and gh.Location = PGP.State " +
            "AND PGP.ProgramYear =:ProgramYear " +
            "and ht.LocationType ='Region' " +
            "and ht.DeletedDate  is null " +
            "and gh.DeletedDate  is null ";

    private static final String GET_CLIENTS = "SELECT DISTINCT CLIENTNAME FROM ProgPerf.CLIENT ORDER BY CLIENTNAME ASC";

    private static final String GET_VALUE_FORM_CONFIG = "SELECT cmc.value FROM ProgPerf.CategoryMasterConfiguration cmc where cmc.key=:key";


    public CommonRepositoryImpl(ConnectionFactory connectionFactory, DatabaseClient databaseClient) {
        this.connectionFactory = connectionFactory;
        this.databaseClient = databaseClient;
    }

    @Override
    public Mono<Long> updateBatchQueries(List<String> updateQueries) {
        return ConnectionFactoryUtils.getConnection (this.connectionFactory)
                .doOnError (e -> log.error ("Unable connect to DB in batch Update", e))
                .flatMapMany (connection -> {
                    if (Objects.isNull (updateQueries) || updateQueries.isEmpty ()) {
                        return Mono.empty ();
                    }
                    Batch batch = connection
                            .createBatch ();
                    updateQueries.forEach (batch::add);
                    updateQueries.clear ();
                    return Flux.from (batch
                            .execute ())
                            .flatMap (Result::getRowsUpdated)
                            .filter (v -> v.longValue () != 0)
                            .doFinally (signalType -> ConnectionFactoryUtils.doCloseConnection (connection, connectionFactory));
                })
                .count ();
    }

    @Override
    public Mono<Integer> upsertJobRunConfiguration(JobRunConfigurationDTO jobRunConfigurationDTO) {

        StringBuilder updateQuerySB = new StringBuilder ();
        String modifiedBy = jobRunConfigurationDTO.getModifiedBy ();
        if (StringUtils.isEmpty (modifiedBy)) {
            modifiedBy = jobRunConfigurationDTO.getJobName ().getValue ();
        }

        updateQuerySB.append (addCondition (jobRunConfigurationDTO.getJobDescription (), ColumnNames.JOB_DESCRIPTION));
        updateQuerySB.append (addCondition (jobRunConfigurationDTO.getStatus ().getValue (), ColumnNames.STATUS));
        updateQuerySB.append (addCondition (modifiedBy, ColumnNames.MODIFIED_BY));
        if (jobRunConfigurationDTO.isUpdateErrorMessage ()) {
            if (Objects.nonNull (jobRunConfigurationDTO.getErrorMessage ()) && StringUtils.isNotEmpty (jobRunConfigurationDTO.getErrorMessage ())) {
                jobRunConfigurationDTO.setErrorMessage (
                        StringUtils.left (
                                ProgramPerformanceUtil.getQuotedString (jobRunConfigurationDTO.getErrorMessage ())
                                , 253));
                String errorQuery = "CASE WHEN ErrorMessage IS NULL THEN '%1$s' " +
                        "WHEN ErrorMessage = '' THEN '%1$s' " +
                        "ELSE CONCAT([ErrorMessage], ' | ', '%1$s') END";
                String errorValue = String.format (errorQuery, jobRunConfigurationDTO.getErrorMessage ());

                updateQuerySB.append (addConditionWithoutQuote (errorValue, ColumnNames.ERROR_MESSAGE));
            } else {
                updateQuerySB.append (addCondition ("", ColumnNames.ERROR_MESSAGE));
            }
        }

        if (jobRunConfigurationDTO.isUpdateAffectedRows ()) {
            updateQuerySB.append (addConditionWithoutQuote (jobRunConfigurationDTO.getAffectedRows (), ColumnNames.AFFECTED_ROWS));
        }

        updateStringBuilder (jobRunConfigurationDTO, updateQuerySB);

        String updateQuery = String.format (JOB_RUN_CONFIGURATION_UPDATE
                , updateQuerySB.toString ()
                , jobRunConfigurationDTO.getJobName ().getValue ()
        );
        log.info ("Job Run Configuration Update Query is {}", updateQuery);
        return this
                .databaseClient
                .execute (updateQuery)
                .fetch ()
                .rowsUpdated ()
                .flatMap (rowsUpdate -> {
                    Map<String, String> map = new HashMap<> ();
                    if (rowsUpdate == 0) {
                        String createdBy = jobRunConfigurationDTO.getCreatedBy ();
                        if (StringUtils.isEmpty (createdBy)) {
                            createdBy = jobRunConfigurationDTO.getJobName ().getValue ();
                        }
                        String insertQuery = String.format (JOB_RUN_CONFIGURATION_INSERT
                                , jobRunConfigurationDTO.getJobName ().getValue ()
                                , getStringValue (jobRunConfigurationDTO.getJobDescription ())
                                , jobRunConfigurationDTO.getStatus ().getValue ()
                                , createdBy
                        );
                        log.info ("Job Run Configuration Insert Query is {}", insertQuery);
                        map.put (INSERT_QUERY, insertQuery);
                        map.put (ROWS_UPDATE, "0");
                        return Mono.just (map);
                    }
                    map.put (INSERT_QUERY, StringUtils.EMPTY);
                    map.put (ROWS_UPDATE, String.valueOf (rowsUpdate));
                    return Mono.just (map);
                }).flatMap (inputMap -> {
                    if ("0".equalsIgnoreCase (inputMap.get (ROWS_UPDATE))) {
                        return this.databaseClient
                                .execute (inputMap.get (INSERT_QUERY))
                                .fetch ()
                                .rowsUpdated ();
                    }
                    return Mono.just (Integer.parseInt (inputMap.get (ROWS_UPDATE)));
                });
    }

    private void updateStringBuilder(JobRunConfigurationDTO jobRunConfigurationDTO, StringBuilder updateQuerySB) {
        if (jobRunConfigurationDTO.isUpdateJobEnd ()) {
            updateQuerySB.append (addConditionWithoutQuote (GET_DATE_STR, ColumnNames.JOB_END));
        } else {
            updateQuerySB.append (addConditionWithoutQuote (null, ColumnNames.JOB_END));
        }
        if (jobRunConfigurationDTO.isUpdateJobStart ()) {
            updateQuerySB.append (addConditionWithoutQuote (GET_DATE_STR, ColumnNames.JOB_START));
        }
        if (jobRunConfigurationDTO.isUpdateLastSuccessfulRun ()) {
            updateQuerySB.append (addConditionWithoutQuote (String.format ("[%s]", ColumnNames.JOB_START.getColumnName ()), ColumnNames.LAST_SUCCESSFUL_RUN_DATE));
        }
        if (jobRunConfigurationDTO.isUpdateLastRun ()) {
            updateQuerySB.append (addConditionWithoutQuote (GET_DATE_STR, ColumnNames.LAST_RUN_DATE));
        }
        if (jobRunConfigurationDTO.isUpdateJobEvent ()) {
            // @ gave error No parameters bound for query
            updateQuerySB.append (addCondition (jobRunConfigurationDTO.getJobEvent ().replace ("@", "||"), ColumnNames.JOB_EVENT));
        }
        if (jobRunConfigurationDTO.isUpdateMessageKey ()) {
            updateQuerySB.append (addCondition (jobRunConfigurationDTO.getMessageKey (), ColumnNames.MESSAGE_KEY));
        }
        if (jobRunConfigurationDTO.isUpdateMessage ()) {
            updateQuerySB.append (addCondition (jobRunConfigurationDTO.getMessage (), ColumnNames.MESSAGE));
        }
    }

    @Override
    public int getBatchSize() {
        return ProviderGroupConstants.DB_BATCH_SIZE;
    }

    private String addConditionWithoutQuote(Object value, ColumnNames columnNames) {
        return String.format ("%s %s %s %s", COMMA, columnNames.getColumnName (), EQUAL_STR, value);
    }

    private String addCondition(String value, ColumnNames columnNames) {
        if (Objects.nonNull (value)) {
            return String.format (", %s = '%s'", columnNames.getColumnName (), value);
        }
        return "";
    }

    private String getStringValue(Object object) {
        return Objects.isNull (object) ? null
                : String.format ("'%s'", object);
    }

    @Override
    public Mono<Boolean> getJobIsActiveByName(String jobName) {
        log.info ("{} {} With Params - jobName : {} ", LOG_LITERAL_RUNNING_QUERY, GET_JOB_ISACTIVE_BY_NAME, jobName);
        return databaseClient.execute (GET_JOB_ISACTIVE_BY_NAME)
                .bind (JOB_NAME, jobName)
                .as (Boolean.class)
                .fetch ()
                .one ();
    }

    @Override
    public Mono<Integer> getJobIdByName(String jobName) {
        log.info ("{} {} With Params - jobName : {} ", LOG_LITERAL_RUNNING_QUERY, GET_JOB_ID_BY_NAME, jobName);
        return databaseClient.execute (GET_JOB_ID_BY_NAME)
                .bind (JOB_NAME, jobName)
                .as (Integer.class)
                .fetch ()
                .one ();
    }

    @Override
    public Mono<Integer> updateJobExecutionHistoryAsJobStart(Integer jobConfigId, String correlationKey, String jobEvent, String errorMessage) {
        log.info ("{} {} With Params - jobID: {}; messageKey: {}; jobEvent: {}; errorMessage: {};", LOG_LITERAL_RUNNING_QUERY, INSERT_JOB_HISTORY, jobConfigId, correlationKey, jobEvent, errorMessage);
        return databaseClient.execute (INSERT_JOB_HISTORY)
                .bind ("JOB_ID", jobConfigId)
                .bind (BIND_PARAM_EXECUTION_STATUS, Status.IN_PROGRESS.getValue ())
                .bind ("ERROR_MESSAGE", errorMessage)
                .bind ("AFFECTED_ROWS", 0)
                .bind ("JOB_EVENT", jobEvent)
                .bind ("MESSAGE_KEY", correlationKey)
                .fetch ().rowsUpdated ()
                .flatMap (none -> {
                    log.info ("{} {} ", LOG_LITERAL_RUNNING_QUERY, GET_LATEST_IDENTITY_FOR_JOB_HISTORY);

                    return databaseClient.execute (GET_LATEST_IDENTITY_FOR_JOB_HISTORY)
                            .bind ("JOB_ID", jobConfigId)
                            .as (Integer.class)
                            .fetch ().one ();
                });
    }

    @Override
    public Mono<Integer> updateJobExecutionHistoryAsJobEnd(Integer jobExecutionId, Status status, String errorMessage, String message, Boolean updateAffectedRowsOnSuccess, Long rowsAffected) {
        if (status == Status.SUCCESS) {
            return updateJobExecutionHistoryAsJobSuccess (jobExecutionId, message, updateAffectedRowsOnSuccess, rowsAffected);
        } else {
            return updateJobExecutionHistoryAsJobFailure (jobExecutionId, errorMessage);
        }
    }

    @Override
    public Mono<Integer> getJobExecutionHistoryByMessageKey(Integer jobId, String messageKey) {
        String getHistoryCountQuery = String.format (GET_COUNT_OF_JOB_HISTORY_BY_MESSAGE_KEY, jobId, messageKey);
        log.info ("{} {}  ", LOG_LITERAL_RUNNING_QUERY, getHistoryCountQuery);
        return databaseClient.execute (getHistoryCountQuery)
                .as (Integer.class)
                .fetch ().one ();
    }

    @Override
    public Mono<Integer> getJobExecutionHistoryByTime(Integer jobId, Integer thresholdInMinutes) {
        String getHistoryCountQuery = String.format (GET_COUNT_OF_JOB_HISTORY_BY_TIME, jobId, thresholdInMinutes);
        log.info ("{} {}", LOG_LITERAL_RUNNING_QUERY, getHistoryCountQuery);
        return databaseClient.execute (getHistoryCountQuery)
                .as (Integer.class)
                .fetch ().one ();
    }

    @Override
    public Flux<JobConfigurationDTO> getAllJobConfigurations() {
        log.info ("Getting all jobs configurations");
        return databaseClient.execute (GET_ALL_JOBS_CONFIGURATION)
                .as (JobConfigurationDTO.class)
                .fetch ()
                .all ();
    }

    @Override
    public Mono<JobConfigurationDTO> getJobConfigurationByName(JobName jobName) {
        log.info ("Getting job configurations for :: {} ", jobName);
        log.info ("query for getJobConfigurationByName :: {} ", GET_JOB_CONFIGURATION_BY_NAME);
        return databaseClient.execute (GET_JOB_CONFIGURATION_BY_NAME)
                .bind (JOB_NAME, jobName.getValue ())
                .as (JobConfigurationDTO.class)
                .fetch ()
                .one ();
    }

    private Mono<Integer> updateJobExecutionHistoryAsJobSuccess(Integer jobExecutionId, String successMessage, Boolean updateAffectedRows, Long affectedRows) {
        String message = successMessage.replace ("'", "''");
        String updateAffectedRowsColumn = "";
        if (updateAffectedRows)
            updateAffectedRowsColumn = String.format (UPDATE_JOB_HISTORY_ROWS_AFFECTED, affectedRows);
        String updateQuery = String.format (UPDATE_JOB_HISTORY_COMPLETE_SUCCESS, updateAffectedRowsColumn);
        log.info ("{} {} With Params - executionHistoryId: {}; message: {};", LOG_LITERAL_RUNNING_QUERY, updateQuery, jobExecutionId, successMessage);
        return databaseClient.execute (updateQuery)
                .bind ("EXECUTION_HISTORY_ID", jobExecutionId)
                .bind (BIND_PARAM_EXECUTION_STATUS, Status.SUCCESS.getValue ())
                .bind ("MESSAGE_TEXT", message)
                .fetch ().rowsUpdated ();
    }

    private Mono<Integer> updateJobExecutionHistoryAsJobFailure(Integer jobExecutionId, String errorMessage) {
        String message = errorMessage.replace ("'", "''"); // Escaping sql for single quote; otherwise sql query formation may fail.
        log.info ("{} {} With Params - executionHistoryId: {} and errorMessage {}", LOG_LITERAL_RUNNING_QUERY, UPDATE_JOB_HISTORY_COMPLETE_FAILURE, jobExecutionId, message);
        return databaseClient.execute (UPDATE_JOB_HISTORY_COMPLETE_FAILURE)
                .bind ("EXECUTION_HISTORY_ID", jobExecutionId)
                .bind (BIND_PARAM_EXECUTION_STATUS, Status.FAILURE.getValue ())
                .bind ("MESSAGE_TEXT", message)
                .fetch ().rowsUpdated ();
    }

    @Override
    public Mono<Integer> updateAffectedRowsCountForJob(String jobName, Long affectedRowCount) {
        log.info ("{} {} with params jobname={} and affectedRow={}", LOG_LITERAL_RUNNING_QUERY, UPDATE_AFFECTEDROW_JOB_RUN_CONFIG, jobName, affectedRowCount);
        return databaseClient.execute (UPDATE_AFFECTEDROW_JOB_RUN_CONFIG)
                .bind (ColumnNames.AFFECTED_ROWS.getColumnName (), affectedRowCount)
                .bind (ColumnNames.JOB_NAME.getColumnName (), jobName)
                .fetch ()
                .rowsUpdated ()
                .flatMap (count -> {
                    log.info ("{} {} with params jobname={} and affectedRow={}", LOG_LITERAL_RUNNING_QUERY, UPDATE_AFFECTEDROW_JOB_EXECUTION_HISTORY, jobName, affectedRowCount);
                    return databaseClient.execute (UPDATE_AFFECTEDROW_JOB_EXECUTION_HISTORY)
                            .bind (ColumnNames.AFFECTED_ROWS.getColumnName (), affectedRowCount)
                            .bind (ColumnNames.JOB_NAME.getColumnName (), jobName)
                            .fetch ()
                            .rowsUpdated ();
                });
    }

    @Override
    public Mono<Integer> jobConfigurationUpdates(JobConfigurationRequestBody jobConfiguration) {
        StringBuilder updateQuerySB = new StringBuilder ();
        if (jobConfiguration.getIsActive () != null && jobConfiguration.getLastSuccessfulRunDate () != null) {
            updateQuerySB.append (String.format (", %s = %s, %s = '%s' ", ColumnNames.IS_ACTIVE.getColumnName (), jobConfiguration.getIsActive () ? 1 : 0, ColumnNames.LAST_SUCCESSFUL_RUN_DATE.getColumnName (), jobConfiguration.getLastSuccessfulRunDate ()));
        } else if (jobConfiguration.getIsActive () != null) {
            updateQuerySB.append (String.format (", %s = %s ", ColumnNames.IS_ACTIVE.getColumnName (), jobConfiguration.getIsActive () ? 1 : 0));
        } else if (jobConfiguration.getLastSuccessfulRunDate () != null) {
            updateQuerySB.append (String.format (", %s = '%s' ", ColumnNames.LAST_SUCCESSFUL_RUN_DATE.getColumnName (), jobConfiguration.getLastSuccessfulRunDate ()));
        }
        String updateQuery = String.format (UPDATE_JOB_RUN_CONFIGURATION_UPDATE
                , updateQuerySB.toString ()
                , jobConfiguration.getJobName ()
        );
        log.info ("Job Run Configuration Update Query is {}", updateQuery);
        return this
                .databaseClient
                .execute (updateQuery)
                .fetch ()
                .rowsUpdated ();
    }

    @Override
    public Mono<Map<String, String>> getEligibleMemberCountInputMap() {
        return databaseClient
                .execute (ELIGIBLE_MEMBER_COUNT_INPUTMAP)
                .map ((row, rowMetadata) -> {
                    Map<String, String> eligibleMemberCountInputMap = new ConcurrentHashMap<> ();
                    eligibleMemberCountInputMap.put (RuleConstants.DURATIONVALUE, row.get (ColumnNames.DURATIONVALUE.getColumnName (), String.class));
                    eligibleMemberCountInputMap.put (RuleConstants.CURRENTPROGRAMYEAR, row.get (ColumnNames.CURRENTPROGRAMYEAR.getColumnName (), String.class));
                    eligibleMemberCountInputMap.put (RuleConstants.LAST_SUCCESSFUL_RUN_DATE, row.get (ColumnNames.LAST_SUCCESSFUL_RUN_DATE.getColumnName (), String.class));
                    eligibleMemberCountInputMap.put (RuleConstants.STARTDATE, row.get (ColumnNames.STARTDATE.getColumnName (), String.class));
                    eligibleMemberCountInputMap.put (RuleConstants.ENDDATE, row.get (ColumnNames.ENDDATE.getColumnName (), String.class));
                    return eligibleMemberCountInputMap;
                })
                .one ();
    }

    @Override
    public Flux<PafOverAllStatusDetailDTO> getOverAllStatusDetails(int programYear) {
        return databaseClient.execute (SELECT_PAF_OVER_ALL_STATUS_COUNT)
                .bind ("PROGRAM_YEAR", programYear)
                .as (PafOverAllStatusDetailDTO.class)
                .fetch ()
                .all ();
    }

    @Override
    public Flux<CategoryUpdatedDetailDTO> getUpdatedCategoryDetails(int programYear) {
        return databaseClient.execute (SELECT_JOBS_UPDATED_DATE)
                .bind ("PROGRAM_YEAR", programYear)
                .as (CategoryUpdatedDetailDTO.class)
                .fetch ()
                .all ();
    }

    @Override
    public Mono<Integer> updateRegionValues(ProgramYearCalendarDTO programYearCalendarDTO, String table) {
        String query= String.format(UPDATE_REGION_QUERY, table,table);
        return databaseClient.execute(query)
                .bind(ProviderGroupYTDActualProcessorRepositoryImpl.ColumnNames.DURATIONVALUE.getColumnName(), programYearCalendarDTO.getDurationValue())
                .bind(ProviderGroupYTDActualProcessorRepositoryImpl.ColumnNames.PROGRAMYEAR.getColumnName(), programYearCalendarDTO.getProgramYear())
                .fetch()
                .rowsUpdated()
                .doOnNext(integer -> log.info("updated Region records {} {} {}", integer, programYearCalendarDTO,table));
    }

    public Mono<String> getCascadedJobs(String jobName){
        return databaseClient
                .execute(GET_CASCADED_JOBS)
                .bind(JOB_NAME, jobName)
                .as(String.class)
                .fetch()
                .one();
    }

    public Mono<String> getJobFrequency(String jobName){
        return databaseClient
                .execute(GET_JOB_FREQUENCY_CHECK)
                .bind(JOB_NAME, jobName)
                .as(String.class)
                .fetch()
                .one();
    }

    @Override
    public Flux<String> getClients() {
        return databaseClient
                .execute(GET_CLIENTS)
                .as(String.class)
                .fetch()
                .all();
    }

    @Override
    public Mono<String> getValueFromConfiguration(String key) {
        return databaseClient
                .execute(GET_VALUE_FORM_CONFIG)
                .bind("key",key)
                .as(String.class)
                .fetch()
                .first();
    }

}
