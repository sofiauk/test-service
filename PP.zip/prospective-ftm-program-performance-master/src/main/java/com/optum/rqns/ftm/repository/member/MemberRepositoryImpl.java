package com.optum.rqns.ftm.repository.member;

import com.optum.rqns.ftm.constants.RuleConstants;
import com.optum.rqns.ftm.enums.GroupsToExecute;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

import java.util.Map;

@Repository
@Slf4j
public class MemberRepositoryImpl implements MemberRepository {

    @Autowired
    private DatabaseClient databaseClient;

    public enum ColumnNames {

        DURATIONVALUE ("DURATIONVALUE"),
        PROGRAMYEAR ("PROGRAMYEAR"),
        LASTUPDATEDDATE ("LASTUPDATEDDATE"),
        BATCH_OFFSET ("BATCH_OFFSET"),
        BATCH_SIZE ("BATCH_SIZE"),
        STARTDATE ("STARTDATE"),
        ENDDATE ("ENDDATE");

        private String columnName;

        ColumnNames(String columnName) {
            this.columnName = columnName;
        }

        public String getColumnName() {
            return this.columnName;
        }
    }


    private static final String BASELINE_QUERY = "MERGE INTO ProgPerf.ProviderGroupExtended AS pge   " +
            "USING (  " +
            "SELECT ProviderGroupID,State,ProgramYear,sum(EligibleDeployableMemberCount) as EligibleDeployableMemberCount  " +
            "from ProgPerf.ProviderGroupPerformance pgp with (nolock)  " +
            "where pgp.ClientName = 'ALL' and ServiceLevel = 'ALL' and ProgramYear = :PROGRAMYEAR and DurationValue =:DURATIONVALUE  " +
            " group by ProviderGroupId, State,ProgramYear  " +
            " having sum(EligibleDeployableMemberCount)  >=0  " +
            ") AS sources  " +
            "ON (  " +
            "    pge.ProviderGroupID = sources.providerGroupID  " +
            "    AND pge.STATE = sources.State  " +
            "    and pge.ProgramYear = sources.ProgramYear  " +
            ")  " +
            "WHEN NOT MATCHED  " +
            "    THEN  " +
            "        INSERT (ProviderGroupID , State, ProgramYear, baseline ,IsActionSent  " +
            "        , CreatedBy, CreatedDate  " +
            "        , UpdatedBy , UpdatedDate )  " +
            "        VALUES (sources.providerGroupID,  sources.State, sources.programYear  " +
            "        ,  sources.EligibleDeployableMemberCount ,  0  " +
            "        , 'RunEligibleMemberCount', getUTCDate() , 'RunEligibleMemberCount' ,  getUTCDate())  " +
            "WHEN MATCHED and baseline is null " +
            "    THEN  " +
            "        UPDATE SET Baseline = sources.EligibleDeployableMemberCount , IsActionSent = 0  " +
            "        , UpdatedDate = getUTCDate()  " +
            "        , UpdatedBy = 'RunEligibleMemberCount' " +
            ";";


    private static final String UPDATE_ELIGIBLE_MEMBER_COUNT_QUERY = "MERGE ProgPerf.ProviderGroupPerformance AS TARGET   " +
            "  USING (   " +
            "SELECT   " +
            "  PA.ProviderGroupID, PA.ProviderState, PA.LobName, PA.ProgramYear, Count(PA.Id) AS EligiblePreferredMemberCount, COUNT(CASE WHEN (PA.IsProviderAssociated <> 'No' OR PA.IsProviderAssociated IS NULL) THEN 1 END) AS EligibleDeployableMemberCount   " +
            "FROM   " +
            "  ProgPerf.PafExMemberAssessment PA WITH (NOLOCK)   " +
            "WHERE   " +
            "  PA.IsSuppressed = 'N'   " +
            "  AND UPPER(PA.RecordStatus) <> 'DELETED'   " +
            "  AND PA.ProgramYear = :PROGRAMYEAR   " +
            "  AND LEN(PA.ProviderGroupId) > 0   " +
            "  AND LEN(PA.ProviderState) > 0   " +
            "  AND LEN(PA.LobName) > 0   " +
            "  AND LEN(PA.ClientName) > 0   " +
            "  AND LEN(PA.ProgramYear) > 0    " +
            "  %s   " +
            "GROUP BY   " +
            "  PA.ProviderGroupID, PA.ProviderState, PA.LobName, PA.ProgramYear ) AS SOURCE ON   " +
            "(TARGET.ProviderGroupID = SOURCE.ProviderGroupId )   " +
            "AND (TARGET.State = SOURCE.ProviderState )   " +
            "AND (TARGET.LobName = SOURCE.LobName )   " +
            "AND (TARGET.ProgramYear = SOURCE.ProgramYear )   " +
            "AND (TARGET.DurationValue = :DURATIONVALUE)   " +
            "AND (UPPER(TARGET.ServiceLevel) = 'ALL')   " +
            "AND (UPPER(TARGET.ClientName) = 'ALL')   " +
            "WHEN MATCHED THEN   " +
            "UPDATE   " +
            "SET   " +
            "  TARGET.EligibleMemberCountLastUpdated = GETUTCDATE(),   " +
            "  TARGET.EligibleDeployableMemberCount = SOURCE.EligibleDeployableMemberCount ,   " +
            "  TARGET.EligiblePreferredMemberCount = SOURCE.EligiblePreferredMemberCount ,   " +
            "  TARGET.DurationValue = :DURATIONVALUE ,  " +
            "  TARGET.DurationStartDate = :STARTDATE ,  " +
            "  TARGET.DurationEndDate = :ENDDATE ,  " +
            "  TARGET.UpdatedBy = 'EligibleMemberCountJob',   " +
            "  TARGET.UpdatedDate = GETUTCDATE()   " +
            "WHEN NOT MATCHED BY TARGET THEN   " +
            "INSERT   " +
            "  (ProviderGroupID, State, ServiceLevel, ClientName, LobName, ProgramYear, DurationValue, DurationStartDate, DurationEndDate, CreatedBy, CreatedDate, UpdatedBy, UpdatedDate, EligibleMemberCountLastUpdated, EligibleDeployableMemberCount, EligiblePreferredMemberCount)   " +
            "VALUES(SOURCE.ProviderGroupID, SOURCE.ProviderState, 'All','All', SOURCE.LobName, SOURCE.ProgramYear, :DURATIONVALUE, :STARTDATE, :ENDDATE, 'EligibleMemberCountJob', GETUTCDATE(), 'EligibleMemberCountJob', GETUTCDATE(), GETUTCDATE(), SOURCE.EligibleDeployableMemberCount, SOURCE.EligiblePreferredMemberCount);  ";



    private static final String NOT_DELETED_PGPW_GET_ROW_COUNT = "SELECT Count(1) TotalRecordsCount FROM " +
            " ( SELECT DISTINCT PA.ProviderGroupId, PA.ProviderState, PA.ClientName, PA.LobName, PA.ProgramYear " +
            " FROM ProgPerf.PafExMemberAssessment PA WITH (NOLOCK)  " +
            " WHERE PA.ProgramYear = :PROGRAMYEAR " + //* PASS ProgramYear AS PARAM *
            "AND UPPER(PA.RecordStatus) <> 'DELETED') AS DISTINCT_SET;";

    private static final String UPDATE_ELIGIBLE_MEMBER_WEEKLY_COUNT_QUERY = "MERGE ProgPerf.ProviderGroupPerformanceWeekly AS tgt" +
            " USING ( " +
            "        SELECT PA.ProviderGroupID " +
            "               ,  PA.ProviderState " +
            "               ,  PA.LobName " +
            "               ,  PA.ClientName " +
            "               , PA.ProgramYear " +
            "               , Count(CASE  " +
            "                              WHEN (UPPER(PA.RecordStatus) <> 'DELETED') " +
            "                                     THEN 1 " +
            "                              END) AS PreferredMemberCount " +
            "               , Count(CASE  " +
            "                              WHEN (PA.IsSuppressed = 'N' AND UPPER(PA.RecordStatus) <> 'DELETED') " +
            "                                     THEN 1 " +
            "                              END) AS EligiblePreferredMemberCount " +
            "               , COUNT(CASE  " +
            "                              WHEN ( " +
            "                                             PA.IsSuppressed = 'N' AND UPPER(PA.RecordStatus) <> 'DELETED' " +
            "                                             AND ( " +
            "                                                     PA.IsProviderAssociated IS NULL " +
            "                                                     OR PA.IsProviderAssociated <> 'No' " +
            "                                                     ) " +
            "                                             ) " +
            "                                      THEN  1 " +
            "                              END) AS EligibleDeployableMemberCount " +
            "               , COUNT(CASE  " +
            "                              WHEN ( " +
            "                                             (PA.IsSuppressed = 'N') AND UPPER(PA.RecordStatus) <> 'DELETED' " +
            "                                             AND ( " +
            "                                                     PA.IsProviderAssociated IS NULL " +
            "                                                     OR PA.IsProviderAssociated <> 'No' " +
            "                                                     ) " +
            "                                             AND PA.IsDeployed = 0 " +
            "                                             ) " +
            "                                       THEN  1  " +
            "                              END) AS DeploymentOpportunityCount " +
            " , COUNT(CASE WHEN ( UPPER(PA.RecordStatus) <> 'DELETED' AND PA.IsSuppressed = 'N' AND ( PA.IsProviderAssociated IS NULL OR PA.IsProviderAssociated <> 'No' ) and PA.MemberChangedFromIHA = 1 and isDeployed = 0 ) THEN 1 END) as MemberChangedFromIHACount " +
            " , COUNT(CASE WHEN ( UPPER(PA.RecordStatus) <> 'DELETED' AND PA.IsSuppressed = 'N' AND ( PA.IsProviderAssociated IS NULL OR PA.IsProviderAssociated <> 'No' ) and (PA.MbrPopType like '%IOA%' AND PA.MbrPopType not like '%IHA%') ) THEN 1 END ) as MemberIOACount " +
            " , COUNT(CASE WHEN ( UPPER(PA.RecordStatus) <> 'DELETED' AND PA.IsSuppressed = 'N' AND ( PA.IsProviderAssociated IS NULL OR PA.IsProviderAssociated <> 'No' ) and PA.MbrPopType = 'IHA' ) THEN 1 END ) as MemberIHACount " +
            " , COUNT(CASE WHEN ( UPPER(PA.RecordStatus) <> 'DELETED' AND PA.IsSuppressed = 'N' AND ( PA.IsProviderAssociated IS NULL OR PA.IsProviderAssociated <> 'No' ) and (PA.MbrPopType like '%IOA%' AND PA.MbrPopType like '%IHA%' ) ) THEN 1 END ) as MemberIOAIHACount " +
            "        FROM ProgPerf.PafExMemberAssessment PA WITH (NOLOCK) " +
            "        WHERE PA.ProgramYear = :PROGRAMYEAR  " + //*PARAM*
            "               AND LEN(PA.ProviderGroupId) > 0 " +
            "               AND LEN(PA.ProviderState) > 0 " +
            "               AND LEN(PA.LobName) > 0 " +
            "               AND LEN(PA.ClientName) > 0 " +
            "               AND LEN(PA.ProgramYear) > 0 " +
            "        GROUP BY PA.ProviderGroupID " +
            "               , PA.ProviderState  " +
            "               , PA.LobName  " +
            "               , PA.ClientName  " +
            "               , PA.ProgramYear " +
            "        ORDER BY PA.ProviderGroupId " +
            "               , PA.ProviderState   " +
            "               ,  PA.ClientName  " +
            "               ,  PA.LobName " +
            "               , PA.ProgramYear OFFSET :BATCH_OFFSET  ROWS FETCH NEXT :BATCH_SIZE  ROWS ONLY " + /*PARAM*/ /*PARAM*/
            "        ) AS src " +
            "        ON tgt.ProviderGroupID = src.ProviderGroupId " +
            "               AND tgt.[STATE] = src.ProviderState " +
            "               AND UPPER(tgt.ClientName) = UPPER(src.ClientName) " +
            "               AND tgt.LobName = src.LobName " +
            "               AND tgt.ProgramYear = src.ProgramYear " +
            "               AND tgt.DurationValue = :DURATIONVALUE " + /*PARAM*/
            "               AND UPPER(tgt.ServiceLevel) = 'ALL' " +
            " WHEN MATCHED " +
            "        THEN " +
            "               UPDATE " +
            "               SET tgt.PreferredMemberCount = src.PreferredMemberCount " +
            "                       , tgt.EligiblePreferredMemberCount = src.EligiblePreferredMemberCount " +
            "                       , tgt.EligibleDeployableMemberCount = src.EligibleDeployableMemberCount " +
            "                       , tgt.DeploymentsOpportunityAssessmentCount = src.DeploymentOpportunityCount " +
            "                       , tgt.EligibleMemberCountLastUpdated = GETUTCDATE() " +
            "                       , tgt.DeploymentsOpportunityUpdatedDate = GETUTCDATE() " +
            "                       , tgt.DurationValue = :DURATIONVALUE  " + /*PARAM*/
            "                       , tgt.DurationStartDate = :STARTDATE  " + /*PARAM*/
            "                       , tgt.DurationEndDate = :ENDDATE  " + /*PARAM*/
            "                       , tgt.UpdatedBy = 'EligibleMemberCountJob' " +
            "                       , tgt.UpdatedDate = GETUTCDATE() " +
            "                       , tgt.MemberChangedFromIHACount = src.MemberChangedFromIHACount " +
            "                       , tgt.MemberIOACount = src.MemberIOACount " +
            "                       , tgt.MemberIHACount = src.MemberIHACount " +
            "                       , tgt.MemberIOAIHACount = src.MemberIOAIHACount " +
            "                       , tgt.MemberIOAIHALastUpdatedDate = GETUTCDATE() " +
            " WHEN NOT MATCHED BY TARGET " +
            "        THEN " +
            "               INSERT ( " +
            "                       ProviderGroupID " +
            "                       , [STATE] " +
            "                       , ServiceLevel " +
            "                       , ClientName " +
            "                       , LobName " +
            "                       , ProgramYear " +
            "                       , DurationValue " +
            "                       , DurationStartDate " +
            "                       , DurationEndDate " +
            "                       , PreferredMemberCount " +
            "                       , EligiblePreferredMemberCount " +
            "                       , EligibleDeployableMemberCount " +
            "                       , DeploymentsOpportunityAssessmentCount " +
            "                       , EligibleMemberCountLastUpdated " +
            "                       , DeploymentsOpportunityUpdatedDate " +
            "                       , CreatedBy " +
            "                       , CreatedDate " +
            "                       , UpdatedBy " +
            "                       , UpdatedDate " +
            "                       , MemberChangedFromIHACount " +
            "                       , MemberIOACount " +
            "                       , MemberIHACount " +
            "                       , MemberIOAIHACount " +
            "                       , MemberIOAIHALastUpdatedDate " +
            "                       ,IsCurrentWeekForPerformance "+
            "                       ) " +
            "               VALUES ( " +
            "                       src.ProviderGroupID " +
            "                       , src.ProviderState " +
            "                       , 'All' " +
            "                       , src.ClientName " +
            "                       , src.LobName " +
            "                       , src.ProgramYear " +
            "                       , :DURATIONVALUE  " + /*PARAM*/
            "                       , :STARTDATE  " + /*PARAM*/
            "                       , :ENDDATE  " + /*PARAM*/
            "                       , src.PreferredMemberCount " +
            "                       , src.EligiblePreferredMemberCount " +
            "                       , src.EligibleDeployableMemberCount " +
            "                       , src.DeploymentOpportunityCount " +
            "                       ,  GETUTCDATE() " +
            "                       , GETUTCDATE()  " +
            "                       , 'EligibleMemberCountJob' " +
            "                       ,  GETUTCDATE()  " +
            "                       , 'EligibleMemberCountJob' " +
            "                       ,   GETUTCDATE()   " +
            "                       ,   src.MemberChangedFromIHACount   " +
            "                       ,   src.MemberIOACount   " +
            "                       ,   src.MemberIHACount   " +
            "                       ,   src.MemberIOAIHACount   " +
            "                       ,   GETUTCDATE()   " +
            "                       ,   0  " +
            "                       );";

    @Override
    public Mono<Integer> updateEligibleMemberCount(JobEvent jobEvent, Map<String, String> inputMap){
        log.info ("Bind params - DurationValue={}, CurrentProgramYear={}, LastSuccessfulRunDate={}, DurationStartDate={}, DurationEndDate={}.",
                 inputMap.get(RuleConstants.DURATIONVALUE), Integer.parseInt(inputMap.get(RuleConstants.CURRENTPROGRAMYEAR)), inputMap.get(RuleConstants.LAST_SUCCESSFUL_RUN_DATE),
                inputMap.get(RuleConstants.STARTDATE), inputMap.get(RuleConstants.ENDDATE));
        if(GroupsToExecute.MODIFIED.getValue().equalsIgnoreCase(jobEvent.getGroupsToExecute().toString())){
            return databaseClient.execute(getFinalEligibleMemberCountQuery(true))
                    .bind(ColumnNames.DURATIONVALUE.getColumnName(), inputMap.get(RuleConstants.DURATIONVALUE))
                    .bind(ColumnNames.PROGRAMYEAR.getColumnName(), Integer.parseInt(inputMap.get(RuleConstants.CURRENTPROGRAMYEAR)))
                    .bind(ColumnNames.LASTUPDATEDDATE.getColumnName(), String.valueOf(inputMap.get(RuleConstants.LAST_SUCCESSFUL_RUN_DATE)))
                    .bind(ColumnNames.STARTDATE.getColumnName(), String.valueOf(inputMap.get(RuleConstants.STARTDATE)))
                    .bind(ColumnNames.ENDDATE.getColumnName(), String.valueOf(inputMap.get(RuleConstants.ENDDATE)))
                    .fetch().rowsUpdated();
        }else {
            return databaseClient.execute(getFinalEligibleMemberCountQuery(false))
                    .bind(ColumnNames.DURATIONVALUE.getColumnName(), inputMap.get(RuleConstants.DURATIONVALUE))
                    .bind(ColumnNames.PROGRAMYEAR.getColumnName(), Integer.parseInt(inputMap.get(RuleConstants.CURRENTPROGRAMYEAR)))
                    .bind(ColumnNames.STARTDATE.getColumnName(), String.valueOf(inputMap.get(RuleConstants.STARTDATE)))
                    .bind(ColumnNames.ENDDATE.getColumnName(), String.valueOf(inputMap.get(RuleConstants.ENDDATE)))
                    .fetch().rowsUpdated();
        }
    }

    @Override
    public Mono<Integer> upsertBaseline(Map<String, String> inputMap) {
        return databaseClient.execute(BASELINE_QUERY)
                .bind(ColumnNames.DURATIONVALUE.getColumnName(), inputMap.get(RuleConstants.DURATIONVALUE))
                .bind(ColumnNames.PROGRAMYEAR.getColumnName(), Integer.parseInt(inputMap.get(RuleConstants.CURRENTPROGRAMYEAR)))
                .fetch().rowsUpdated();
    }


    private String getFinalEligibleMemberCountQuery(boolean isModified) {

        if(isModified){
            return String.format(UPDATE_ELIGIBLE_MEMBER_COUNT_QUERY, "    AND PA.ProviderGroupId + PA.ProviderState + CAST (PA.ProgramYear AS Varchar) IN (  " +
                    "    SELECT  " +
                    "      DISTINCT pem.ProviderGroupId + pem.ProviderState + CAST (pem.ProgramYear AS Varchar)  " +
                    "    FROM  " +
                    "      ProgPerf.PafExMemberAssessment pem WITH (NOLOCK)  " +
                    "    WHERE  " +
                    "      pem.PafxMemberUpdatedDate > :LASTUPDATEDDATE  " +
                    "      OR pem.ProviderAssociationUpdatedDate > :LASTUPDATEDDATE ) ");
        }

        else{
            return String.format(UPDATE_ELIGIBLE_MEMBER_COUNT_QUERY, " ");
        }
    }


    @Override
    public Mono<Integer> getTotalRecordsCountForNotDeletedPGPWeekly(String programYear) {
            String countQuery = String.format (NOT_DELETED_PGPW_GET_ROW_COUNT);
            log.info ("Count query for PGPW : [{}]. Bind params - ProgramYear={}.",
                    countQuery, programYear);
            return databaseClient.execute (countQuery)
                    .bind (ColumnNames.PROGRAMYEAR.getColumnName (), programYear)
                    .as (Integer.class)
                    .fetch ()
                    .one ();
    }

    @Override
    public Mono<Integer> updateEligibleMemDeploymentPreferredCountForPGPWeekly(Integer batchOffset, Integer batchSize, Map<String, String> inputMap) {

            String mergeQuery = UPDATE_ELIGIBLE_MEMBER_WEEKLY_COUNT_QUERY;
            log.info ("Merge query for PGPW(Deployments, Preferred and Eligible Members : [{}]. " +
                            "Bind params - ProgramYear={}, BatchOffset={}, BatchSize={}, Duration={}, DurationStartDate={}, DurationEndDate={}.",
                    mergeQuery, Integer.parseInt(inputMap.get(RuleConstants.CURRENTPROGRAMYEAR)), batchOffset, batchSize, inputMap.get(RuleConstants.DURATIONVALUE),inputMap.get(RuleConstants.STARTDATE), inputMap.get(RuleConstants.ENDDATE));
            return databaseClient.execute (mergeQuery)
                    .bind (ColumnNames.PROGRAMYEAR.getColumnName (), Integer.parseInt(inputMap.get(RuleConstants.CURRENTPROGRAMYEAR)))
                    .bind (ColumnNames.BATCH_OFFSET.getColumnName (), batchOffset)
                    .bind (ColumnNames.BATCH_SIZE.getColumnName (), batchSize)
                    .bind (ColumnNames.DURATIONVALUE.getColumnName (), inputMap.get(RuleConstants.DURATIONVALUE))
                    .bind(ColumnNames.STARTDATE.getColumnName(), String.valueOf(inputMap.get(RuleConstants.STARTDATE)))
                    .bind(ColumnNames.ENDDATE.getColumnName(), String.valueOf(inputMap.get(RuleConstants.ENDDATE)))
                    .fetch ()
                    .rowsUpdated ();
    }

}
