package com.optum.rqns.ftm.dto.qfo.performance.healthSystem.converter;

import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.dto.qfo.performance.healthSystem.HealthSystemPerformanceDetailsDTO;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class HealthSystemPerformanceDetailsDTOConverter implements Converter<Row, HealthSystemPerformanceDetailsDTO>, DTOWrapperTypeConverter {
    @Override
    public HealthSystemPerformanceDetailsDTO convert(Row row) {
        return HealthSystemPerformanceDetailsDTO.builder()
                .mapCpiAnnualCareVisits(getPrimitiveLongValue(row, "MapCpiAnnualCareVisits"))
                .mapCpiEligiblePatients(getPrimitiveLongValue(row, "MapCpiEligiblePatients"))
                .mapCpiStarRating(row.get("MapCpiStarRating", BigDecimal.class))
                .mapCpiPatientExperience(row.get("MapCpiPatientExperience", String.class))
                .mcaipFullyAssessed(getPrimitiveLongValue(row, "McaipFullyAssessed"))
                .mcaipSuspectMedicalConditions(getPrimitiveLongValue(row, "McaipSuspectMedicalConditions"))
                .overAllStarRating(row.get("OverAllStarRating", BigDecimal.class))
                .mapCpiPartDStarRating(row.get("MapCpiPartDStarRating", BigDecimal.class))
                .healthSystemId(row.get("HealthSystemId", String.class))
                .healthSystemName(row.get("HealthSystemName", String.class))
                .acpStarRating(row.get("AcpStarRating", BigDecimal.class))
                .teamType("QFO")
                .durationValue(row.get("DurationValue", String.class))
               // .incentiveProgram(row.get("incentiveProgram", String.class))
                .suspectConditionAssessedTotal(getPrimitiveLongValue(row, "SuspectConditionAssessedTotal"))
                .suspectConditionsTotal(getPrimitiveLongValue(row, "SuspectConditionsTotal"))
                .suspectDiagnosed(getPrimitiveLongValue(row, "SuspectDiagnosed"))
                .suspectNotAssessed(getPrimitiveLongValue(row, "SuspectNotAssessed"))
                .suspectUndiagnosed(getPrimitiveLongValue(row, "SuspectUndiagnosed"))
                .totalPatients(getPrimitiveLongValue(row, "TotalPatients"))
                .mcaipTotalPatients(getPrimitiveLongValue(row, "McaipTotalPatients"))
                .updatedDate(row.get("UpdatedDate", LocalDateTime.class))
                .mcaipLastUpdated(row.get("McaipLastUpdated", LocalDateTime.class))
                .mapCpiLastUpdated(row.get("MapCpiLastUpdated", LocalDateTime.class))
                .build();
    }
}
