package com.optum.rqns.ftm.dto.qfo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.time.LocalDateTime;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class QFOPatientsCoveredDTO {
	private Integer patients;
	private Integer openSuspects;
	private Integer qualityGaps;
	private LocalDateTime lastUpdatedDate;
}
