package com.optum.rqns.ftm.response.performance.providergrp;

import com.optum.rqns.ftm.model.performance.providergrp.AssignedProviderGroupOpportunities;
import com.optum.rqns.ftm.wrapper.Meta;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
@AllArgsConstructor
@Builder
public class AssignedProviderGroupOpportunitiesResponse {
    private Meta meta;

    private List<AssignedProviderGroupOpportunities> data;

    public AssignedProviderGroupOpportunitiesResponse() {
        this.meta = new Meta();
        this.data = new ArrayList<>();
    }
}
