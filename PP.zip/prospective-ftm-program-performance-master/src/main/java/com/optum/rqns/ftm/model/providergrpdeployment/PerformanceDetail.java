package com.optum.rqns.ftm.model.providergrpdeployment;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;


@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class PerformanceDetail {
    private int returnsNetCNACount;
    private int returnsCount;
    private int deploymentsCount;
    private List<LobDetail> clientStats;
}