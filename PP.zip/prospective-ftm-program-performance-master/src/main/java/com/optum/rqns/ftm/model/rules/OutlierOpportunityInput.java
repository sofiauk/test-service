package com.optum.rqns.ftm.model.rules;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OutlierOpportunityInput implements OpportunityInput {
    String  providerGroupId ;
    String  providerGroupName ;
    String providerState;
    String serviceLevel;
    int projectYear;
    String client;
    String clientId;
    String lobName;
    String chartID;
    String outlierName;
    String gapType;
    String gapDesc;

    @Override
    public int getDeployYTDActual() {
        return 0;
    }

    @Override
    public int getReturnYTDActual() {
        return 0;
    }

    @Override
    public int getReturnYTDActualPercentage() {
        return 0;
    }

    @Override
    public int getReturnYTDTargetPercent() {
        return 0;
    }

    @Override
    public String getPaymentRejectReason() {
        return null;
    }

    @Override
    public String getSingleRejectReason() {
        return null;
    }

    @Override
    public String getIsSecondarySubmissionEligible() {
        return null;
    }

    @Override
    public String getOverAllStatus() {
        return null;
    }

    @Override
    public int getEligibleMembersCount() {
        return 0;
    }

}
