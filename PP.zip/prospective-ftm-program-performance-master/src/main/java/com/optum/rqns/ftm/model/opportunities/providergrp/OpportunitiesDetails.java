package com.optum.rqns.ftm.model.opportunities.providergrp;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.optum.rqns.ftm.constants.ProviderGroupConstants;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OpportunitiesDetails {
    private String opportunityDetailsId;
    private String providerGroupID;
    private String providerGroupName;
    private String state;
    private String serviceLevel;
    private int programYear;
    private String clientName;
    private String opportunityType;
    private String opportunitySubType;
    private int opportunityTypePosition;
    private int opportunitySubTypePosition;
    private String displayText;
    private int assessmentCount;
    private int deploymentCount;
    private int gapCount;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = ProviderGroupConstants.PERFORMANCE_DATE_FORMAT)
    private LocalDate lastUpdatedDate;
    private String masterOpportunityType;
    private int masterOpportunityTypePosition;
    private int membersToAchieveFiveStarRatings;
    private int compliantMembers;
    private int qualityRatings;
    private String measureId;
    private LocalDateTime updatedDate;
}
