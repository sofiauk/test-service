package com.optum.rqns.ftm.repository;

import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

@Repository
@Log4j2
public class RedisRepository {

    @Value("${rqns.ftm.redis.keyExpiration}")
    private int EXPIRATION_IN_MINS ;

    public static final String KEY = "PROGRAM_PERFORMANCE_CACHE";
    private HashOperations<String, String, ObjectNode> hashOperations;

    private static final ScheduledExecutorService ses = Executors.newSingleThreadScheduledExecutor();

    @Autowired
    private RedisTemplate<String, ObjectNode> redisTemplate;

    @PostConstruct
    public void init() {
        this.hashOperations = redisTemplate.opsForHash();
        redisTemplate.expire(KEY, EXPIRATION_IN_MINS, TimeUnit.MINUTES);
        ses.scheduleAtFixedRate(() -> {
            log.info("In queue:"+this.hashOperations.entries(KEY).size()+" keys");
            Set<String> keys = this.hashOperations.entries(KEY).entrySet().stream()
                    .filter(m -> (m.getValue().get("ttl").longValue() + 60000 * EXPIRATION_IN_MINS) < System.currentTimeMillis())
                    .map(Map.Entry::getKey).collect(Collectors.toSet());
            String []toDelete= keys.stream().collect(Collectors.toSet()).toArray(new String[0]);
            if(toDelete.length>0){
               long deleted=this.hashOperations.delete(KEY, toDelete);
               log.info("deleted {} stalled keys",deleted);
            }
            log.debug("deleted keys: {}", String.join(", ", keys));
        }, EXPIRATION_IN_MINS, EXPIRATION_IN_MINS, TimeUnit.MINUTES);
    }

    @PreDestroy
    public void cleanup() {
        ses.shutdown();
    }

    public ObjectNode save(ObjectNode data, String key) {
        this.hashOperations.put(KEY, key, data);
        return data;
    }

    public long size() {
        return this.hashOperations.size(KEY);
    }

    public Boolean hasKey(String key) {
        return this.hashOperations.hasKey(KEY, key);
    }

    public ObjectNode get(String key) {
        return this.hashOperations.get(KEY, key);
    }

    public long delete(String... key) {
        return this.hashOperations.delete(KEY, (Object[]) key);
    }

    public List<ObjectNode> getAll() {
        return this.hashOperations.values(KEY);
    }

    public Set<String> getAllKeys() {
        return this.hashOperations.keys(KEY);
    }

    public int getExpirationInMins(){
        return EXPIRATION_IN_MINS;
    }

 }