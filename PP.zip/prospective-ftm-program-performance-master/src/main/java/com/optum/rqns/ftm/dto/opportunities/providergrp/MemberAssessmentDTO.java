package com.optum.rqns.ftm.dto.opportunities.providergrp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.time.LocalDateTime;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MemberAssessmentDTO {

    private String memberName;
    private String memberId;
    private String chartId;
    private String secondarySubmission;
    private String client;
    private String providerName;
    private String gaMet;
    private String dvMet;
    private String cGapMet;
    private String opportunityReason;
    private LocalDateTime memberDob;
    private LocalDateTime deployDate;
    private LocalDateTime returnDate;
    private String lobName;
    private int programYear;
    private String eligibleProgramType;
    private String cpg;

}
