package com.optum.rqns.ftm.response.opportunities.providergrp;

import com.optum.rqns.ftm.model.opportunities.providergrp.MemberAssessmentClients;
import com.optum.rqns.ftm.wrapper.Meta;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.ToString;

import java.util.ArrayList;
import java.util.List;

@Data
@ToString
@AllArgsConstructor
@Builder
public class MemberAssessmentClientResponse {
    private Meta meta;

    private List<MemberAssessmentClients> data;

    public MemberAssessmentClientResponse() {
        this.meta = new Meta();
        this.data = new ArrayList<>();
    }
}
