package com.optum.rqns.ftm.dto.opportunities.providergrp.converter;

import com.optum.rqns.ftm.constants.ProviderGroupConstants;
import com.optum.rqns.ftm.model.opportunities.providergrp.MemberAssessmentOpportunitySubTypes;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;


public class MemberAssessmentOpportunitySubTypeConverter implements Converter<Row, MemberAssessmentOpportunitySubTypes> {

    @Override
    public MemberAssessmentOpportunitySubTypes convert(Row row) {
        return MemberAssessmentOpportunitySubTypes.builder()
                .opportunitySubType(row.get(ProviderGroupConstants.OPPORTUNITY_SUB_TYPES, String.class))
                .build();
    }
}
