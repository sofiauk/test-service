package com.optum.rqns.ftm.dto.personnelhierarchy;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class PersonnelHierarchyRequest {
    private PersonnelHierarchyUpdateDTO data;
    private String reason;
}
