package com.optum.rqns.ftm.dto.rules;


import com.optum.rqns.ftm.model.rules.MemberAssessmentOpportunity;
import com.optum.rqns.ftm.model.rules.ProviderGroup;
import com.optum.rqns.ftm.repository.rules.RuleRepositoryImpl;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;

public class MemberAssessmentOpportunityConverter implements Converter<Row, MemberAssessmentOpportunity> {

    @Override
    public MemberAssessmentOpportunity convert(Row rs) {

        return MemberAssessmentOpportunity.builder()
                .providerGroupID(rs.get(RuleRepositoryImpl.ColumnNames.PROVIDERGROUPID.getColumnName(), String.class))
                .state(rs.get(RuleRepositoryImpl.ColumnNames.STATE.getColumnName(), String.class))
                .serviceLevel(rs.get(RuleRepositoryImpl.ColumnNames.SERVICELEVEL.getColumnName(), String.class))
                .programYear(rs.get(RuleRepositoryImpl.ColumnNames.PROGRAMYEAR.getColumnName(),Integer.class))
                .masterOpportunityType(rs.get(RuleRepositoryImpl.ColumnNames.MASTEROPPORTUNITYTYPE.getColumnName(), String.class))
                .opportunityType(rs.get(RuleRepositoryImpl.ColumnNames.OPPORTUNITYTYPE.getColumnName(), String.class))
                .opportunitySubType(rs.get(RuleRepositoryImpl.ColumnNames.OPPORTUNITYSUBTYPE.getColumnName(), String.class))
                .chartID(rs.get(RuleRepositoryImpl.ColumnNames.CHARTID.getColumnName(), String.class))
                .lobName(rs.get(RuleRepositoryImpl.ColumnNames.LOBNAME.getColumnName(), String.class))
                .clientName(rs.get(RuleRepositoryImpl.ColumnNames.CLIENTNAME.getColumnName(), String.class))
                .build();
    }
}
