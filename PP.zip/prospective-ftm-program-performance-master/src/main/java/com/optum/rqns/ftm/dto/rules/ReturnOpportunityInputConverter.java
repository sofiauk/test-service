package com.optum.rqns.ftm.dto.rules;

import com.optum.rqns.ftm.constants.ProviderGroupConstants;
import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.model.rules.ReturnOpportunityInput;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;

public class ReturnOpportunityInputConverter  implements Converter<Row, ReturnOpportunityInput>, DTOWrapperTypeConverter {

    @Override
    public ReturnOpportunityInput convert(Row row) {

        return ReturnOpportunityInput.builder()
                .projectYear(getPrimitiveIntegerValue(row, ProviderGroupConstants.PROGRAM_YEAR))
                .client(row.get(ProviderGroupConstants.CLIENTNAME,String.class))
                .clientId(row.get(ProviderGroupConstants.CLIENT_ID,String.class))
                .providerGroupId(row.get(ProviderGroupConstants.OPPORTUNITY_PROVIDER_GROUP_ID,String.class))
                .providerGroupName(row.get(ProviderGroupConstants.PROVIDER_GROUP_NAME,String.class))
                .lobName(row.get(ProviderGroupConstants.LOB_NAME,String.class))
                .providerState(row.get(ProviderGroupConstants.OPPORTUNITY_STATE,String.class))
                .deployYTDActual(getPrimitiveIntegerValue(row, ProviderGroupConstants.DEPLOY_YTD_ACTUAL))
                .returnYTDActual(getPrimitiveIntegerValue(row, ProviderGroupConstants.RETURN_YTD_ACTUAL))
                .returnYTDActualPercentage(getPrimitiveIntegerValue(row, ProviderGroupConstants.RETURN_YTD_ACTUAL_PERCENTAGE))
                .returnYTDTargetPercent(row.get(ProviderGroupConstants.RETURN_YTD_TARGET_PERCENTAGE,Integer.class))
                .build();
    }
}
