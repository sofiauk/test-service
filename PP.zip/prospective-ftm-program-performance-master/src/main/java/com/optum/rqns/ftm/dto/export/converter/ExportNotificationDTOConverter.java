package com.optum.rqns.ftm.dto.export.converter;

import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.model.export.ExportNotification;
import io.r2dbc.spi.Row;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.convert.converter.Converter;

import static com.optum.rqns.ftm.repository.exports.ExportRepositoryImpl.Columns.FILE_NAME;
import static com.optum.rqns.ftm.repository.exports.ExportRepositoryImpl.Columns.IS_ACTIVE;
import static com.optum.rqns.ftm.repository.exports.ExportRepositoryImpl.Columns.IS_NOTIFIED;
import static com.optum.rqns.ftm.repository.exports.ExportRepositoryImpl.Columns.OPTUM_UUID;
import static com.optum.rqns.ftm.repository.exports.ExportRepositoryImpl.Columns.TRANSACTION_ID;

@Slf4j
public class ExportNotificationDTOConverter extends ExportsDTOConverterHelper implements Converter<Row, ExportNotification>, DTOWrapperTypeConverter {

    @Override
    public ExportNotification convert(Row row) {

        return ExportNotification.builder()
                .optumUuid(row.get(OPTUM_UUID.getValue(), String.class))
                .transactionId(getPrimitiveLongValue(row, TRANSACTION_ID.getValue()))
                .processType(getProcessType(row))
                .processSubType(getProcessSubType(row))
                .fileName(row.get(FILE_NAME.getValue(), String.class))
                .exportStatus(getExportStatus(row))
                .isNotified(hasBooleanValue(row, IS_NOTIFIED.getValue()))
                .isActive(hasBooleanValue(row, IS_ACTIVE.getValue()))
                .build();
    }
}
