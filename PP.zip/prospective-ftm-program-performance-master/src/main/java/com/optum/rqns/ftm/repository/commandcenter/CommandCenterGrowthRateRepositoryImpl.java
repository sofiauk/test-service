package com.optum.rqns.ftm.repository.commandcenter;

import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.model.providergrpdeployment.GrowthRate;
import io.r2dbc.spi.Row;
import org.springframework.data.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Repository
public class CommandCenterGrowthRateRepositoryImpl implements CommandCenterGrowthRateRepository, DTOWrapperTypeConverter {


    private final DatabaseClient client;

    private final static String PROGRAM_YEAR = "ProgramYear";
    private final static String MONTH = "Month";
    private final static String MERGE_CC_GROWTH_TARGET_RATES = "MERGE ProgPerf.CommandCenterGrowthRate as tgt using(  " +
            "select " +
            "   :ProgramYear as CurrentProgramYear, ProgramYear , month, max( " +
            "   case " +
            "      when " +
            "         mc.code = 'CommandCenterGrowthRateAgreedPercentage' " +
            "      then " +
            "         ROUND(ccgr.AgreedYTD + (ccgr.AgreedYTD*mc.value / 100),0)  " +
            "      else " +
            "         0  " +
            "   end " +
            ") AgreedTarget, max( " +
            "   case " +
            "      when " +
            "         mc.code = 'CommandCenterGrowthRateEngagedPercentage' " +
            "      then " +
            "         ROUND(ccgr.EngagedYTD + (ccgr.EngagedYTD*mc.value / 100),0 )   " +
            "      else " +
            "         0  " +
            "   end " +
            ") as EngagedTarget  " +
            "from " +
            "   ProgPerf.CommandCenterGrowthRate ccgr , ProgPerf.MasterConfiguration mc  " +
            "where " +
            "   ( " +
            "      mc.code = 'CommandCenterGrowthRateEngagedPercentage'  " +
            "      or mc.code = 'CommandCenterGrowthRateAgreedPercentage' " +
            "   ) " +
            "   and ccgr.ProgramYear =  " +
            "   ( " +
            "      :ProgramYear - 1 " +
            "   ) " +
            "group by " +
            "   ccgr.ProgramYear , ccgr.month )as src  " +
            "   on( tgt.ProgramYear = src.CurrentProgramYear  " +
            "   AND tgt.month = src.month )  " +
            "   WHEN " +
            "      MATCHED  " +
            "   THEN " +
            "      UPDATE " +
            "      SET " +
            "         tgt.AgreedTarget = src.AgreedTarget, tgt.EngagedTarget = src.EngagedTarget , tgt.UpdatedBy = 'RunCommandCenterGrowthRatePercentages', tgt.UpdatedDate = GETUTCDATE()   " +
            "      WHEN " +
            "         NOT MATCHED  " +
            "      THEN " +
            "        INSERT (ProgramYear, Month, AgreedTarget, EngagedTarget,CreatedBy,UpdatedBy,CreatedDate,UpdatedDate)   " +
            "      VALUES " +
            "         ( " +
            "            src.CurrentProgramYear, src.Month, src.AgreedTarget, src.EngagedTarget,'RunCommandCenterGrowthRatePercentages','RunCommandCenterGrowthRatePercentages',GETUTCDATE(),GETUTCDATE() " +
            "         ) ;";

    private static final String COMMAND_CENTER_GROWTH_RATE =
            "SELECT ProgramYear, [Month], AgreedYTD, AgreedTarget, AgreedYTDPercent, EngagedYTD, EngagedTarget, EngagedYTDPercent " +
                    "FROM ProgPerf.CommandCenterGrowthRate " +
                    "WHERE ProgramYear = :ProgramYear " +
                    "AND UPPER([Month]) = UPPER(:Month)";

    CommandCenterGrowthRateRepositoryImpl(DatabaseClient client) {
        this.client = client;
    }

    @Override
    public Mono<Integer> calculateCCTargetGrowthRates(int projectYear) {
        return client.execute(MERGE_CC_GROWTH_TARGET_RATES)
                .bind(PROGRAM_YEAR, projectYear)
                .fetch()
                .rowsUpdated();
    }

    public Mono<GrowthRate> getCommandCenterGrowthRate(int programYear, String month) {

        return client.execute(COMMAND_CENTER_GROWTH_RATE)
                .bind(PROGRAM_YEAR, programYear)
                .bind(MONTH, month)
                .as(GrowthRate.class)
                .map((row, rowMetadata) -> GrowthRate
                        .builder()
                        .programYear(getPrimitiveIntegerValue(row,PROGRAM_YEAR))
                        .month(getStringValue(row, MONTH))
                        .agreedYTD(getDoubleValueAsInt(row,"AgreedYTD"))
                        .engagedYTD((getDoubleValueAsInt(row, "EngagedYTD")))
                        .agreedTarget(getDoubleValueAsInt(row, "AgreedTarget"))
                        .engagedTarget(getDoubleValueAsInt(row, "EngagedTarget"))
                        .agreedYTDPercent(getDoubleValue(row, "AgreedYTDPercent"))
                        .engagedYTDPercent(getDoubleValue(row, "EngagedYTDPercent"))
                        .build()
                )
                .one();
    }

    String getStringValue(Row row, String columnName) {
        return getValue(row, columnName, String.class);
    }

    private Integer getDoubleValueAsInt(Row row, String columName) {
        Double value = getDoubleValue(row, columName);
        return value != null ? value.intValue() : null;
    }
}
