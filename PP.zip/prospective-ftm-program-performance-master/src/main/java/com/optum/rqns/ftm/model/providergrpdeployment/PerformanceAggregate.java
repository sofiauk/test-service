package com.optum.rqns.ftm.model.providergrpdeployment;

import lombok.Builder;
import lombok.Data;
import org.springframework.data.relational.core.mapping.Table;


@Data
@Builder
@Table("ProgPerf.CommandCenterPerformanceAggregates")
public class PerformanceAggregate {
    private String name;
    private String value;
}
