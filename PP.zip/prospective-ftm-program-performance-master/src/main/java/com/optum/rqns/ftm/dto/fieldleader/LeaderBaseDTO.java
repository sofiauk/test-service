package com.optum.rqns.ftm.dto.fieldleader;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.LocalDateTime;
import java.util.List;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class LeaderBaseDTO<T> {
	private String firstName;
	private String lastName;
	private String uuid;
	private String parentUUID;
	private String role;
	private String regionMarket;
	private List<T> children;
	private LocalDateTime lastUpdatedDate;
}
