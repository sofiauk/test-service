package com.optum.rqns.ftm.dto.performance.providergrp.converter;

import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.dto.performance.providergrp.ProviderGroupLobPerformanceDTO;
import com.optum.rqns.ftm.repository.performance.providergrp.ProviderGroupPerformanceRepositoryImpl.ColumnNames;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class ProviderGroupLobPerformanceDTOConverter implements Converter<Row, ProviderGroupLobPerformanceDTO>, DTOWrapperTypeConverter {

    public ProviderGroupLobPerformanceDTO convert(Row resultSet) {

        return ProviderGroupLobPerformanceDTO.builder()
                .programYear(getPrimitiveIntegerValue(resultSet, ColumnNames.PROGRAM_YEAR.getColumnName()))
                .providerGroupId(resultSet.get(ColumnNames.PROVIDER_GROUP_ID.getColumnName(),String.class))
                .providerGroupName(resultSet.get(ColumnNames.PROVIDER_GROUP_NAME.getColumnName(),String.class))
                .state(resultSet.get(ColumnNames.STATE.getColumnName(),String.class))
                .serviceLevel(resultSet.get(ColumnNames.SERVICE_LEVEL.getColumnName(),String.class))
                .clientName(resultSet.get(ColumnNames.CLIENT_NAME.getColumnName(),String.class))
                .lobName(resultSet.get(ColumnNames.LOB_NAME.getColumnName(),String.class))
                .deployYTDActual(getLongValue(resultSet, ColumnNames.DEPLOY_YTD_ACTUAL.getColumnName()))
                .deployYeTarget(getLongValue(resultSet,ColumnNames.DEPLOY_YE_TARGET.getColumnName()))
                .returnYETargetPercent(getDoubleValue(resultSet, ColumnNames.RETURN_YE_TARGET_PERCENT.getColumnName()))
                .returnYTDActual(getLongValue(resultSet, ColumnNames.RETURN_YTD_ACTUAL.getColumnName()))
                .returnYTDTargetPercent(getDoubleValue(resultSet, ColumnNames.RETURN_YTD_TARGET_PERCENT.getColumnName()))
                .returnYETarget(getLongValue(resultSet, ColumnNames.RETURN_YE_TARGET.getColumnName()))
                .returnYTDTarget(getLongValue(resultSet, ColumnNames.RETURN_YTD_TARGET.getColumnName()))
                .durationEndDate(resultSet.get(ColumnNames.DURATION_END_DATE.getColumnName(),LocalDate.class))
                .deploymentStartDate(resultSet.get(ColumnNames.DEPLOYMENT_START_DATE.getColumnName(), LocalDate.class))
                .lastDeploymentDate(resultSet.get(ColumnNames.LAST_DEPLOYMENT_DATE.getColumnName(), LocalDate.class))
                .eligibleDeployableMemberCount(getLongValue(resultSet, ColumnNames.ELIGIBLE_DEPLOYABLE_MEMBER_COUNT.getColumnName()))
                .deployYtdTarget(getLongValue(resultSet, ColumnNames.DEPLOY_YTD_TARGET.getColumnName()))
                .lastUpdatedDate(resultSet.get(ColumnNames.UPDATED_DATE.getColumnName(), LocalDateTime.class) != null? resultSet.get(ColumnNames.UPDATED_DATE.getColumnName(), LocalDateTime.class).toLocalDate(): null)
                .eligiblePreferredMemberCount(getLongValue(resultSet, ColumnNames.ELIGIBLE_PREFERRED_MEMBER_COUNT.getColumnName()))
                .returnedNetCnaYtdActual(getLongValue(resultSet, ColumnNames.RETURNED_NET_CNA_ACTUAL.getColumnName()))
                .lastReturnedDate(resultSet.get(ColumnNames.LAST_RETURNED_DATE.getColumnName(), LocalDate.class))
                .returnedStartDate(resultSet.get(ColumnNames.RETURNED_START_DATE.getColumnName(), LocalDate.class))
                .build();
    }
}

