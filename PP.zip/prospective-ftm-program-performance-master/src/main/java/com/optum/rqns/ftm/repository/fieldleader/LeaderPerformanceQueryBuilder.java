package com.optum.rqns.ftm.repository.fieldleader;

import com.optum.rqns.ftm.enums.ScopeType;
import com.optum.rqns.ftm.enums.LeaderPerformanceType;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class LeaderPerformanceQueryBuilder {
    private static final LeaderPerformanceQueryBuilder INSTANCE = new LeaderPerformanceQueryBuilder();
    private LeaderPerformanceQueryBuilder() {}
    public static Builder builder() { return INSTANCE.new Builder(); }
    public class Builder {

        private static final String MAX_DATE = " MAX(lgrp.updatedDate) AS UpdatedDate ";
        private static final String SERVICE_LEVEL_NATIONAL = "'PSC-B,PSC-P,HCA'";
        private static final String SERVICE_LEVEL_ALL = "'HCA', 'PSC-B', 'PSC-P'";
        private static final String SERVICE_LEVEL_HCA = "'HCA'";
        private static final String MODALITY = " ProgPerf.LeaderGrowthRatePOCEModality lgrp ";
        private static final String PERFORMANCE = " ProgPerf.LeaderPerformance ";
        private static final String BY_UUID = " AND UUID = '%s' ";
        private static final String BY_PROGRAM_YEAR = " AND ProgramYear = :ProgramYear ";
        private static final String BY_PROGRAM_YEAR_GROWTH_RATE = " AND (ProgramYear = :ProgramYear OR ProgramYear = :ProgramYear - 1) ";
        private static final String SERVICE_LEVEL= "ServiceLevel";
        private static final String CLIENT_NAME = "ClientName";
        private static final String LOB = "lob";
        private static final String AND = " AND ";
        private static final String AND_IS_ACTIVE = "AND IsActive = 1 ";
        private static final String CURRENT_MONTH_CHECK = "[Month] = LEFT(DATENAME(month, getdate()), 3) ";
        private static final String ALL = "'All'";

        //NATIONAL LEVEL PERFORMANCE ROLLUPS
        private static final String NATIONAL_WHERE =
                " AND UUID = 'National' AND Region != 'All' AND State != 'All' ";
        private static final String REGION_WHERE =
                " AND UUID = 'National' " +
                "AND Region IS NOT NULL " +
                "AND Region != 'All' " +
                "AND State IS NOT NULL " +
                "AND State != 'All' ";
        private static final String STATE_WHERE =
                " AND UUID = 'National' AND Region IN ( :Region ) AND State IS NOT NULL AND State <> 'All' ";

        private static final String FIELD_IN =
                " %s IN (%s) ";

        private static final String SELECT_LEADER_FILTER_FIELDS =
                " DISTINCT %s ";

        private static final String FROM_LEADER_FILTER_FIELDS =
                "FROM %s WHERE ProgramYear = :ProgramYear " +
                AND_IS_ACTIVE +
                "AND %s != 'All' " +
                "AND %s NOT LIKE ('%%,%%') ";

        private static final String LEADER_PERFORMANCE =
                "MAX(updatedDate) AS UpdatedDate, " +
                "MAX(DurationStartDate) AS DurationStartDate, " +
                "MAX(DurationEndDate) AS DurationEndDate, " +
                "SUM(CAST(DeployActualPerf AS BIGINT)) AS DeployActualPerf, " +
                "SUM(CAST(DeployActualGoal AS BIGINT)) AS DeployActualGoal, " +
                "SUM(CAST(DeployGoalYTD AS BIGINT)) AS DeployGoalYTD, " +
                "SUM(CAST(ReturnNetCnaActualPerf AS BIGINT)) AS ReturnNetCnaActualPerf, " +
                "SUM(CAST(ReturnNetCnaActualGoal AS BIGINT)) AS ReturnNetCnaActualGoal, " +
                "SUM(CAST(ReturnGoalYTD AS BIGINT)) AS ReturnGoalYTD, " +
                "SUM(CAST(CompletedAssessmentActualPerf AS BIGINT)) AS CompletedAssessmentActualPerf, " +
                "SUM(CAST(CompletedAssessmentActualGoal AS BIGINT)) AS CompletedAssessmentActualGoal, " +
                "SUM(CAST(EligibleDeployableMembers AS BIGINT)) AS EligibleDeployableMembers, " +
                "SUM(CAST(Rejects AS BIGINT)) AS Rejects, " +
                "SUM(CAST(CGAPClosedSuspect AS BIGINT)) AS CGAPClosedSuspect, " +
                "SUM(CAST(CGAPTotalSuspect AS BIGINT)) AS CGAPTotalSuspect ";

        private static final String LEADER_POC_CONVERSION_RATE =
                "(CASE WHEN (MONTH = :CurrentMonth) THEN 1 ELSE 0 END) AS CurrentMonth, " +
                "SUM(CASE WHEN :IsCurrentProgramYear = 0 OR (:IsCurrentProgramYear = 1 AND :CurrentMonth <> 'Feb') THEN POCExistingGroups " +
                "    ELSE CASE WHEN :CurrentMonth = 'Feb' AND [Month] = 'Feb' THEN POCExistingGroups ELSE NULL END END ) AS ExistingGroups, " +
                "SUM(CASE WHEN :IsCurrentProgramYear = 0 OR (:IsCurrentProgramYear = 1 AND :CurrentMonth <> 'Feb') THEN POCExistingTotalGroups " +
                "    ELSE CASE WHEN :CurrentMonth = 'Feb' AND [Month] = 'Feb' THEN POCExistingTotalGroups ELSE NULL END END ) AS ExistingTotalGroups, " +
                "SUM(CASE WHEN :IsCurrentProgramYear = 0 OR (:IsCurrentProgramYear = 1 AND :CurrentMonth <> 'Feb') THEN POCNewGroups " +
                "    ELSE CASE WHEN :CurrentMonth = 'Feb' AND [Month] = 'Feb' THEN POCNewGroups ELSE NULL END END ) AS NewGroups, " +
                "SUM(CASE WHEN :IsCurrentProgramYear = 0 OR (:IsCurrentProgramYear = 1 AND :CurrentMonth <> 'Feb') THEN POCNewTotalGroups " +
                "    ELSE CASE WHEN :CurrentMonth = 'Feb' AND [Month] = 'Feb' THEN POCNewTotalGroups ELSE NULL END END ) AS NewTotalGroups, " +
                MAX_DATE;

        private static final String FROM_MY_TEAM_USERS_JOIN = "FROM (" +
                "SELECT ph1.* FROM ProgPerf.PersonnelHierarchy ph1 " +
                "     WHERE ph1.DeletedDate IS NULL AND ph1.UUID = '%s' " +
                "     UNION ALL " +
                "     SELECT ph2.* FROM ProgPerf.PersonnelHierarchy ph1 " +
                "     INNER JOIN ProgPerf.PersonnelHierarchy ph2 " +
                "     ON ph1.PersonnelHierarchyId = ph2.ParentId  " +
                "     WHERE ph1.DeletedDate IS NULL AND ph2.DeletedDate IS NULL AND ph1.UUID = '%s' " +
                "     UNION ALL " +
                "     SELECT ph3.* FROM ProgPerf.PersonnelHierarchy ph1 " +
                "     INNER JOIN ProgPerf.PersonnelHierarchy ph2 " +
                "     ON ph1.PersonnelHierarchyId = ph2.ParentId  " +
                "     INNER JOIN ProgPerf.PersonnelHierarchy ph3 " +
                "     ON ph2.PersonnelHierarchyId = ph3.ParentId  " +
                "     WHERE ph1.DeletedDate IS NULL AND ph2.DeletedDate IS NULL AND ph3.DeletedDate IS NULL AND ph1.UUID = '%s'" +
                ") mt INNER JOIN ProgPerf.Users u " +
                "ON mt.UUID = u.UUID AND mt.DeletedDate IS NULL LEFT JOIN (SELECT * %s) lgrp";

        private static final String LEADER_GROWTH_RATE =
                "%s" +
                "MAX(Region) AS Region, " +
                "MAX(State) AS State, " +
                "(CASE WHEN ProgramYear = :ProgramYear THEN 1 ELSE 0 END) AS IsCurrentYear, " +
                "SUM(CASE WHEN ProgramYear = :ProgramYear THEN GrowthRateTotalGroups ELSE NULL END) AS TotalGroupsSumCur, " +
                "SUM(CASE WHEN ProgramYear = :ProgramYear THEN AgreedParticipate ELSE NULL END) AS AgreedParticipateSumCur, " +
                "SUM(CASE WHEN ProgramYear = :ProgramYear THEN EngagedParticipate ELSE NULL END) AS EngagedParticipateSumCur, " +
                "SUM(CASE WHEN ProgramYear = :ProgramYear - 1 THEN GrowthRateTotalGroups ELSE NULL END) AS TotalGroupsSumPrev, " +
                "SUM(CASE WHEN ProgramYear = :ProgramYear - 1 THEN AgreedParticipate ELSE NULL END) AS AgreedParticipateSumPrev, " +
                "SUM(CASE WHEN ProgramYear = :ProgramYear - 1 THEN EngagedParticipate ELSE NULL END) AS EngagedParticipateSumPrev, " +
                MAX_DATE;

        private static final String LEADER_GROWTH_RATE_OUTER =
                "%s" +
                "t.Region, " +
                "t.State, " +
                "t.IsCurrentYear, " +
                "(CASE " +
                "   WHEN t.IsCurrentYear = 1  " +
                "   THEN t.TotalGroupsSumCur " +
                "   ELSE t.TotalGroupsSumPrev " +
                "   END " +
                ") AS TotalGroupsSum, " +
                "(CASE  " +
                "   WHEN t.IsCurrentYear = 1 " +
                "   THEN t.AgreedParticipateSumCur " +
                "   ELSE t.AgreedParticipateSumPrev " +
                "   END  " +
                ") AS AgreedParticipateSum, " +
                "(CASE   " +
                "   WHEN t.IsCurrentYear = 1 " +
                "   THEN t.EngagedParticipateSumCur " +
                "   ELSE t.EngagedParticipateSumPrev " +
                "   END " +
                ") AS EngagedParticipateSum, " +
                "t.UpdatedDate FROM ( SELECT ";

        private static final String LEADER_GROWTH_RATE_USER =
                "MAX(mt.UUID) AS UUID," +
                "(SELECT UUID " +
                "FROM ProgPerf.PersonnelHierarchy " +
                "WHERE PersonnelHierarchyId = MAX(mt.ParentId)) " +
                "AS ParentUUID, " +
                "MAX(u.FirstName) AS FirstName, " +
                "MAX(u.LastName) AS LastName, " +
                "MAX(JSON_VALUE(u.[Role],'$[0].name')) AS Role, ";

        private static final String LEADER_GROWTH_RATE_USER_OUTER =
                "t.UUID, " +
                "t.ParentUUID, " +
                "t.FirstName, " +
                "t.LastName, " +
                "t.Role, ";

        private static final String MY_TEAM_GROWTH_RATE_ON = " ON mt.UUID = lgrp.UUID ";

        private static final String GROUP_BY_PY = " GROUP BY ProgramYear";

        private static final String LEADER_E_MODALITY =
                "SUM(CAST(ReturnNetCnaActualPer AS BIGINT)) AS ReturnNetCnaActualPer, " +
                "SUM(CAST(RetrievedByOPAF AS BIGINT)) AS RetrievedByOPAF, " +
                "SUM(CAST(RetrievedByOptumUpload AS BIGINT)) AS RetrievedByOptumUpload, " +
                "SUM(CAST(RetrievedByOgm AS BIGINT)) AS RetrievedByOgm, " +
                "SUM(CAST(RetrievedByEdata AS BIGINT)) AS RetrievedByEdata, " +
                MAX_DATE;

        private static final String SELECT_COMMON_LEADER_IOA_OUTER =
                "(CASE WHEN DeployGoalYE > 0 THEN CONVERT(FLOAT,DeployActualPerf) / CONVERT(FLOAT,DeployGoalYE) * 100 ELSE NULL END) AS PctToDeployGoalEOY, " +
                "(CASE WHEN EligibleDeployableMembers > 0 THEN CONVERT(FLOAT,DeployActualPerf) / CONVERT(FLOAT,EligibleDeployableMembers) * 100  ELSE NULL END) AS DeploymentPct, " +
                "(CASE WHEN ReturnGoalYE > 0 THEN CONVERT(FLOAT,ReturnNetCnaActualPerf) / CONVERT(FLOAT,ReturnGoalYE) * 100  ELSE NULL END) AS PctToReturnGoalEOY, " +
                "(CASE WHEN DeployActualPerf > 0 THEN CONVERT(FLOAT,ReturnNetCnaActualPerf) / CONVERT(FLOAT,DeployActualPerf) * 100 ELSE NULL END) AS ReturnPct, " +
                "(CASE WHEN ReturnNetCnaActualPerf > 0 THEN CONVERT(FLOAT,Rejects) / CONVERT(FLOAT,ReturnNetCnaActualPerf) * 100  ELSE NULL END) AS RejectPct, " +
                "(CASE WHEN CGAPTotalSuspect > 0 THEN CONVERT(FLOAT,CGAPClosedSuspect) / CONVERT(FLOAT,CGAPTotalSuspect) * 100 ELSE NULL END) AS CGAPClosurePct, " +
                "UpdatedDate AS UpdatedDate ";

        private static final String SELECT_COMMON_LEADER_IOA_INNER =
                "ISNULL(SUM(CAST(DeployGoalYE AS BIGINT)),0) AS DeployGoalYE, " +
                "ISNULL(SUM(CAST(DeployActualPerf AS BIGINT)),0) AS DeployActualPerf, " +
                "ISNULL(SUM(CAST(EligibleDeployableMembers AS BIGINT)),0) AS EligibleDeployableMembers, " +
                "ISNULL(SUM(CAST(ReturnGoalYE AS BIGINT)),0) AS ReturnGoalYE, " +
                "ISNULL(SUM(CAST(ReturnNetCnaActualPerf AS BIGINT)),0) AS ReturnNetCnaActualPerf, " +
                "ISNULL(SUM(CAST(Rejects AS BIGINT)),0) AS Rejects, " +
                "ISNULL(SUM(CAST(CGAPClosedSuspect AS BIGINT)),0) AS CGAPClosedSuspect, " +
                "ISNULL(SUM(CAST(CGAPTotalSuspect AS BIGINT)),0) AS CGAPTotalSuspect, " +
                "MAX(lp.updatedDate) AS UpdatedDate ";

        private static final String FROM_COMMON_IOA =
                "FROM ProgPerf.LeaderPerformance lp " +
                "WHERE IsCurrentWeek = 1 " +
                AND_IS_ACTIVE +
                "AND ProgramYear = :ProgramYear ";

        //SL DEFAULT: ServiceLevel = 'PSC-B,PSC-P,HCA'
        private static final String FROM_IOA_NATIONAL = FROM_COMMON_IOA + NATIONAL_WHERE + " %s ";

        //SL DEFAULT: ServiceLevel IN ('HCA','PSC-P','PSC-B')
        private static final String FROM_IOA_USER = FROM_COMMON_IOA + " AND UUID = :UUID %s ";

        //SL DEFAULT: ServiceLevel IN ('HCA','PSC-P','PSC-B')
        private static final String FROM_IOA_REGIONS = FROM_COMMON_IOA + REGION_WHERE + " %s GROUP BY Region ";

        //SL DEFAULT: ServiceLevel IN ('HCA','PSC-P','PSC-B')
        private static final String FROM_IOA_STATES = FROM_COMMON_IOA + STATE_WHERE + " %s GROUP BY Region, State ";

        private static final String FROM_MY_TEAM =
                "FROM " +
				"    MyTeam mt " +
				"INNER JOIN ProgPerf.Users u ON " +
				"    mt.UUID = u.UUID " +
				"LEFT JOIN ( " +
				"    SELECT * " +
				"    FROM " +
				"        ProgPerf.LeaderPerformance lp " +
				"    WHERE " +
				"        lp.IsCurrentWeek = 1 " +
				"        AND lp.IsActive = 1 " +
				"        AND lp.ProgramYear = :ProgramYear " +
				"        %s " +
				"    ) lp ON mt.UUID = lp.UUID " +
				"GROUP BY " +
				"    mt.UUID, " +
				"    FirstName, " +
				"    LastName, " +
				"    u.[Role] ";

        private static final String FROM_COMMON = " FROM %s WHERE IsActive = 1 ";

        private static final String FROM_LEADER_PERFORMANCE = FROM_COMMON + BY_PROGRAM_YEAR;

        private static final String FROM_POC_CONVERSION =
                FROM_COMMON +
                BY_PROGRAM_YEAR +
                " AND MONTH IN ( :CurrentMonth, :PreviousMonth ) ";

        private static final String FROM_MODALITY = FROM_COMMON + BY_PROGRAM_YEAR;

        private static final String FROM_GROWTH_RATE = FROM_COMMON + BY_PROGRAM_YEAR_GROWTH_RATE;

		private static final String WITH_MY_TEAM =
				"WITH MyTeam (UUID, PersonnelHierarchyId, ParentId, Depth, DeletedDate) AS " +
						"( " +
						"   SELECT " +
						"       UUID, " +
						"       PersonnelHierarchyId, " +
						"       ParentId, " +
						"       0 AS Depth, " +
						"       DeletedDate " +
						"   FROM ProgPerf.PersonnelHierarchy " +
						"   WHERE UUID = :UUID " +
						"   UNION ALL " +
						"   SELECT " +
						"       ph.UUID, " +
						"       ph.PersonnelHierarchyId, " +
						"       ph.ParentId, " +
						"       (mt.Depth + 1) AS Depth, " +
						"       ph.DeletedDate " +
						"   FROM ProgPerf.PersonnelHierarchy ph " +
						"   INNER JOIN MyTeam mt " +
						"   ON ph.ParentId = mt.PersonnelHierarchyId " +
						"   AND mt.Depth < 2 " +
						"   AND ph.DeletedDate IS NULL " +
						") ";

		private static final String FROM_MY_TEAM_USER_LEADER_JOIN =
				"FROM " +
				"    (SELECT mt.UUID, " +
				"        (SELECT UUID FROM ProgPerf.PersonnelHierarchy ph2 WHERE ph2.PersonnelHierarchyId = max(mt.parentId)) AS ParentUUID, " +
				"        FirstName, " +
				"        LastName, " +
				"        JSON_VALUE(u.[Role], '$[0].name') AS Role, ";

        private boolean isLeaderPerformance = false;
        private boolean isLeaderPOCConversionRate = false;
        private boolean isLeaderGrowthRate = false;
        private boolean isLeaderEModality = false;
        private boolean isLeaderIOAPerformance = false;
        private boolean isLeaderIOAPerformanceRegion = false;
        private boolean isLeaderIOAPerformanceTeam = false;
        private boolean isLeaderServiceLevelFilter = false;
        private boolean isLeaderClietNameFilter = false;
        private boolean isLeaderLOBFilter = false;
        private boolean isCount = false;
        private String filterConditions = "";
        private String filterConditionsNational = "";
        private String filterResource = "";
        private String leaderPerformanceType = "";
        private String uuid = "";
        private ScopeType scopeType;
        private final List<String> DEFAULT_IOA_PERFORMANCE_SERVICE_LEVELS = Arrays.asList("HCA", "PSC-B", "PSC-P");

        Builder asLeaderPerformance(String uuid, String type) {
            this.isLeaderPerformance = true;
            this.leaderPerformanceType = type;
            this.uuid = uuid != null ? uuid : "";
            return this;
        }

        Builder asLeaderPOCConversionRate(String uuid) {
            this.isLeaderPOCConversionRate = true;
            this.uuid = uuid != null ? uuid : "";
            return this;
        }

        Builder asLeaderGrowthRates(ScopeType scopeType, String uuid, List<String> serviceLevels) {
            setFilterConditions(serviceLevels);
            this.isLeaderGrowthRate = true;
            this.scopeType = scopeType;
            this.uuid = uuid != null ? uuid : "";
            return this;
        }

        Builder asLeaderEModality(String uuid) {
            this.isLeaderEModality = true;
            this.uuid = uuid != null ? uuid : "";
            return this;
        }

        Builder asLeaderIOAPerformance(List<String> clientName, List<String> lob, List<String> serviceLevel) {
            this.isLeaderIOAPerformance = true;
            setFilterConditions(clientName, lob, serviceLevel);
            return this;
        }

        Builder asLeaderIOAPerformanceRegion(List<String> clientName, List<String> lob, List<String> serviceLevel) {
            setFilterConditions(clientName, lob, serviceLevel);
            this.isLeaderIOAPerformanceRegion = true;
            return this;
        }

        Builder asLeaderIOAPerformanceTeam(List<String> clientName, List<String> lob, List<String> serviceLevel) {
            setFilterConditions(clientName, lob, serviceLevel);
            this.isLeaderIOAPerformanceTeam = true;
            return this;
        }

        Builder asLeaderServiceLevelFilter(String resource) {
            filterResource = resource;
            this.isLeaderServiceLevelFilter = true;
            return this;
        }

        Builder asLeaderClietNameFilter(String resource) {
            filterResource = resource;
            this.isLeaderClietNameFilter = true;
            return this;
        }

        Builder asLeaderLOBFilter(String resource) {
            filterResource = resource;
            this.isLeaderLOBFilter = true;
            return this;
        }

        Builder asCount() {
            this.isCount = true;
            return this;
        }

        public String build() {
            StringBuilder sb = new StringBuilder();
            sb.append("SELECT ");
            if (isLeaderPerformance) {
                buildLeaderPerformance(sb);
            } else if (isLeaderPOCConversionRate) {
                buildLeaderPOCConversionRate(sb);
            } else if (isLeaderGrowthRate) {
                buildLeaderGrowthRate(sb);
            } else if (isLeaderEModality) {
                buildLeaderEModality(sb);
            } else if (isLeaderIOAPerformance) {
                buildLeaderIOAPerformance(sb);
            } else if (isLeaderIOAPerformanceRegion) {
                buildLeaderIOAPerformanceRegion(sb);
            } else if (isLeaderIOAPerformanceTeam) {
            	sb.setLength(0);
                buildLeaderIOAPerformanceTeam(sb);
            } else if (isLeaderServiceLevelFilter || isLeaderClietNameFilter || isLeaderLOBFilter) {
                buildLeaderFilter(sb);
            } else {
                sb.setLength(0);
            }
            return sb.toString();
        }

        private void buildLeaderFilter(StringBuilder sb) {
            String filterField = "";
            if (isLeaderServiceLevelFilter) {
                filterField = SERVICE_LEVEL;
            } else if (isLeaderClietNameFilter) {
                filterField = CLIENT_NAME;
            } else if (isLeaderLOBFilter) {
                filterField = LOB;
            }

            if (filterField.equals("")) {
                return;
            }

            sb.append(String.format(SELECT_LEADER_FILTER_FIELDS, filterField));
            if (filterResource.equalsIgnoreCase("LeaderPerformance")) {
                sb.append(String.format(FROM_LEADER_FILTER_FIELDS, "ProgPerf.LeaderPerformance ", filterField, filterField));
            }
            else if (filterResource.equalsIgnoreCase("LeaderGrowthRatePOCEModality")) {
                sb.append(String.format(FROM_LEADER_FILTER_FIELDS, "ProgPerf.LeaderGrowthRatePOCEModality ", filterField, filterField));
            }
        }

        private void buildLeaderPerformance(StringBuilder sb) { //no binding
            sb.append(LEADER_PERFORMANCE)
                    .append(String.format(FROM_LEADER_PERFORMANCE,PERFORMANCE))
                    .append(LeaderPerformanceType.CURRENT.getValue().equalsIgnoreCase(leaderPerformanceType) ? " AND IsCurrentWeek = 1 " : "");
                    if (!uuid.isEmpty()) {
                        sb.append(String.format(BY_UUID, this.uuid))
                                .append(AND)
                                .append(String.format(FIELD_IN, SERVICE_LEVEL, SERVICE_LEVEL_ALL));
                    } else {
                        sb.append(NATIONAL_WHERE)
                                .append(AND)
                                .append(String.format(FIELD_IN, SERVICE_LEVEL, SERVICE_LEVEL_ALL));
                    }
                    sb.append(" GROUP BY DurationStartDate, DurationEndDate ORDER BY DurationStartDate, DurationEndDate ");
        }

        private void buildLeaderPOCConversionRate(StringBuilder sb) { //bind prog year
            sb.append(LEADER_POC_CONVERSION_RATE)
                    .append(String.format(FROM_POC_CONVERSION,MODALITY));
                    if (!uuid.isEmpty()) {
                        sb.append(String.format(BY_UUID, this.uuid))
                                .append(AND)
                                .append(String.format(FIELD_IN, SERVICE_LEVEL, SERVICE_LEVEL_HCA));
                    } else {
                        sb.append(NATIONAL_WHERE)
                                .append(AND)
                                .append(String.format(FIELD_IN, SERVICE_LEVEL, SERVICE_LEVEL_HCA));
                    }
                    sb.append(" GROUP BY ProgramYear, MONTH ");
        }

        private void buildLeaderGrowthRate(StringBuilder sb) { //bind prog year
            String serviceLevel = filterConditions != null && filterConditions.equals("") ? SERVICE_LEVEL_ALL : filterConditions;
            if (scopeType == ScopeType.CURRENT_USER || scopeType == ScopeType.MY_TEAM) {
                String leaderGrowthRateFrom = String.format(FROM_GROWTH_RATE, MODALITY) + AND +
                        String.format(FIELD_IN, SERVICE_LEVEL, serviceLevel) + AND + CURRENT_MONTH_CHECK;

                sb.append(String.format(LEADER_GROWTH_RATE_OUTER, LEADER_GROWTH_RATE_USER_OUTER))
                        .append(String.format(LEADER_GROWTH_RATE, LEADER_GROWTH_RATE_USER))
                        .append(String.format(FROM_MY_TEAM_USERS_JOIN, uuid, uuid, uuid, leaderGrowthRateFrom))
                        .append(MY_TEAM_GROWTH_RATE_ON)
                        .append(scopeType == ScopeType.CURRENT_USER ? String.format(" AND mt.UUID = '%s' ", uuid) : "")
                        .append(GROUP_BY_PY)
                        .append(", mt.UUID ) t ");
            }
            else {
                sb.append(String.format(LEADER_GROWTH_RATE_OUTER,""))
                        .append(String.format(LEADER_GROWTH_RATE, ""))
                        .append(String.format(FROM_GROWTH_RATE, MODALITY));
                        if (scopeType == ScopeType.NATIONAL) {
                            sb.append(NATIONAL_WHERE)
                                    .append(AND)
                                    .append(String.format(FIELD_IN, SERVICE_LEVEL, serviceLevel))
                                    .append(AND)
                                    .append(CURRENT_MONTH_CHECK);
                        } else {
                            sb.append(REGION_WHERE)
                                    .append(AND)
                                    .append(String.format(FIELD_IN, SERVICE_LEVEL, serviceLevel))
                                    .append(AND)
                                    .append(CURRENT_MONTH_CHECK);
                        }
                        sb.append(GROUP_BY_PY);
                        if (scopeType == ScopeType.REGION_AND_STATE ) {
                            sb.append(", Region, State ) t ORDER BY Region, State ");
                        } else {
                            sb.append(") t");
                        }
            }
        }

        private void buildLeaderEModality(StringBuilder sb) { //bind prog year
            sb.append(LEADER_E_MODALITY)
                    .append(String.format(FROM_MODALITY,MODALITY));
            if (!uuid.isEmpty()) {
                sb.append(String.format(BY_UUID, this.uuid))
                        .append(AND)
                        .append("Region != 'All' ")
                        .append(AND)
                        .append("State != 'All' ")
                        .append(AND)
                        .append("ClientName != 'All' ")
                        .append(AND)
                        .append(CURRENT_MONTH_CHECK)
                        .append(AND)
                        .append(String.format(FIELD_IN, SERVICE_LEVEL, SERVICE_LEVEL_ALL));
            } else {
                sb.append(NATIONAL_WHERE)
                        .append(AND)
                        .append(CURRENT_MONTH_CHECK)
                        .append(AND)
                        .append(String.format(FIELD_IN, SERVICE_LEVEL, SERVICE_LEVEL_ALL));
            }
        }

        private void buildLeaderIOAPerformance(StringBuilder sb) { //bind prog year, uuid
            sb.setLength(0);
            sb.append("SELECT * FROM (")
                    .append("SELECT 0 AS FixedOrder, 'National' AS RegionMarket, ")
                    .append(SELECT_COMMON_LEADER_IOA_OUTER)
                    .append("FROM ( SELECT ")
                    .append(SELECT_COMMON_LEADER_IOA_INNER)
                    .append(String.format(FROM_IOA_NATIONAL, filterConditionsNational))
                    .append(") t UNION SELECT 1 AS FixedOrder, ")
                    .append("(SELECT CONCAT(FirstName, ' ', LastName) FROM ProgPerf.Users u WHERE u.UUID = :UUID) AS RegionMarket, ")
                    .append(SELECT_COMMON_LEADER_IOA_OUTER)
                    .append("FROM ( SELECT ")
                    .append(SELECT_COMMON_LEADER_IOA_INNER)
                    .append(String.format(FROM_IOA_USER, filterConditions))
                    .append(") t UNION SELECT 2 AS FixedOrder, Region AS RegionMarket, ")
                    .append(SELECT_COMMON_LEADER_IOA_OUTER)
                    .append("FROM ( SELECT Region, ")
                    .append(SELECT_COMMON_LEADER_IOA_INNER)
                    .append(String.format(FROM_IOA_REGIONS, filterConditions))
                    .append(") t ) v ORDER BY FixedOrder, RegionMarket");
        }

        private void buildLeaderIOAPerformanceRegion(StringBuilder sb) { //bind progYear, region, offset (if count), limit (if count)
            if (isCount) {
                sb.setLength(0);
                sb.append("SELECT COUNT(*) FROM ( SELECT ");
            }
            sb.append("State AS RegionMarket, ")
                    .append(SELECT_COMMON_LEADER_IOA_OUTER)
                    .append("FROM ( SELECT Region, State, ")
                    .append(SELECT_COMMON_LEADER_IOA_INNER)
                    .append(String.format(FROM_IOA_STATES, filterConditions));
            if (isCount) {
                sb.append(") t ) v");
            } else {
                sb.append("ORDER BY State OFFSET :Offset ROWS FETCH NEXT :Limit ROWS ONLY ")
                        .append(") t");
            }
        }

        private void buildLeaderIOAPerformanceTeam(StringBuilder sb) { //bind progYear, UUID
            if (isCount) {
                sb.setLength(0);
                sb.append("SELECT COUNT(*) FROM ( SELECT ");
            }
            sb.append(WITH_MY_TEAM)
            		.append("SELECT FirstName AS FirstName, LastName AS LastName, t.UUID AS UUID, t.ParentUUID as ParentUUID, Role as Role, ")
                    .append("CONCAT(FirstName, ' ', LastName) AS RegionMarket, ")
                    .append(SELECT_COMMON_LEADER_IOA_OUTER)
                    .append(FROM_MY_TEAM_USER_LEADER_JOIN)
                    .append(SELECT_COMMON_LEADER_IOA_INNER)
                    .append(String.format(FROM_MY_TEAM, filterConditions));
            if (isCount) {
                sb.append(") t ) v");
            } else {
                sb.append(") t");
            }
        }

        private void setFilterConditions(List<String> appliedFilters) {
            if (appliedFilters == null || appliedFilters.isEmpty()) {
                return;
            }
            filterConditions = appliedFilters.stream()
                    .map(filter -> String.format("'%s'", filter))
                    .collect(Collectors.joining(","));
        }

        private void setFilterConditions(List<String> clientName, List<String> lob, List<String> serviceLevel) {
            if (clientName != null || lob != null || serviceLevel != null) {
                setServiceLevelConditions(serviceLevel);
                setClientNameConditions(clientName);
                setLobConditions(lob);
            }
            else {
                filterConditions += AND + String.format(FIELD_IN, SERVICE_LEVEL, SERVICE_LEVEL_ALL);
                filterConditionsNational += AND + String.format(FIELD_IN, SERVICE_LEVEL, SERVICE_LEVEL_ALL);
            }
        }

        private void setServiceLevelConditions(List<String> serviceLevel) {
            if (serviceLevel != null) {
                if (!serviceLevel.isEmpty()) {
                    filterConditions += AND + getCondition(SERVICE_LEVEL, serviceLevel, false);
                    filterConditionsNational += AND + getCondition(SERVICE_LEVEL, serviceLevel, true);
                } else {
                    filterConditions += AND + String.format(FIELD_IN, SERVICE_LEVEL, SERVICE_LEVEL_ALL);
                    filterConditionsNational += AND + String.format(FIELD_IN, SERVICE_LEVEL, SERVICE_LEVEL_ALL);
                }
            }
        }

        private void setClientNameConditions(List<String> clientName) {
            if (clientName != null && !clientName.isEmpty()) {
                filterConditions += AND + getCondition(CLIENT_NAME, clientName, false);
                filterConditionsNational += AND + getCondition(CLIENT_NAME, clientName, true);
            }
        }

        private void setLobConditions(List<String> lob) {
            if (lob != null && !lob.isEmpty()) {
                filterConditions += AND + getCondition(LOB, lob, false);
                filterConditionsNational += AND + getCondition(LOB, lob, true);
            }
        }

        private String getCondition(String filterType, List<String> filter, boolean isNational) {
            String targetValues = "";
            if (!filter.isEmpty()) {
                targetValues += "'" + filter.get(0) + "'";

                for (int i = 1; i < filter.size(); i++) {
                    targetValues += ", '" + filter.get(i) + "'";
                }
            }

            return String.format(FIELD_IN, filterType, targetValues.replace("[", "").replace("]", ""));
        }
    }
}
