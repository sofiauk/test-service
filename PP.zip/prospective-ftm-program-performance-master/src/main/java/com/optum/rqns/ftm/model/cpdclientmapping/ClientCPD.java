package com.optum.rqns.ftm.model.cpdclientmapping;

import lombok.Builder;
import lombok.Data;
import org.springframework.data.relational.core.mapping.Table;

import java.time.LocalDateTime;


@Data
@Builder
@Table("ProgPerf.CpdClientMapping")
public class ClientCPD {
    private String name;
    private String uuid;
}
