package com.optum.rqns.ftm.dto.qfo.performance.healthSystem.converter;

import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.dto.qfo.performance.healthSystem.QFOHealthSystemPerformanceDetailsDTO;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class QFOHealthSystemPerformanceDetailsDTOConverter implements Converter<Row, QFOHealthSystemPerformanceDetailsDTO>, DTOWrapperTypeConverter {
    @Override
    public QFOHealthSystemPerformanceDetailsDTO convert(Row row) {
        return QFOHealthSystemPerformanceDetailsDTO.healthSystemPerformanceDetailsBuilder()

                .mapCpiAnnualCareVisits(getPrimitiveLongValue(row, "MapCpiAnnualCareVisits"))
                .mapCpiEligiblePatients(getPrimitiveLongValue(row, "MapCpiEligiblePatients"))
                .mapCpiStarRating(row.get("MapCpiStarRating", BigDecimal.class))
                .mapCpiPatientExperience(row.get("MapCpiPatientExperience", String.class))
                .mcaipFullyAssessed(getPrimitiveLongValue(row, "McaipPatientsFullyAssessed"))
                .mcaipSuspectMedicalConditions(getPrimitiveLongValue(row, "McaipSuspectMedicalConditions"))
                .overAllStarRating(row.get("OverAllStarRating", BigDecimal.class))
                .mapCpiPartDStarRating(row.get("MapCpiPartDStarRating", BigDecimal.class))
                .healthSystemId(row.get("HealthSystemId", String.class))
                .healthSystemName(row.get("HealthSystemName", String.class))
                .acpStarRating(row.get("AcpStarRating", BigDecimal.class))
                .teamType(row.get("teamType", String.class))
                .durationValue(row.get("DurationValue", String.class))
                //.incetiveProgram(row.get("incentiveProgram", String.class))
                .suspectConditionAssessedTotal(getPrimitiveLongValue(row, "SuspectConditionsAssessedTotal"))
                .suspectConditionsTotal(getPrimitiveLongValue(row, "SuspectConditionsTotal"))
                .suspectDiagnosed(getPrimitiveLongValue(row, "SuspectConditionsAssessedDiagnosed"))
                .suspectNotAssessed(getPrimitiveLongValue(row, "SuspectConditionsNotAssessed"))
                .suspectUndiagnosed(getPrimitiveLongValue(row, "SuspectConditionsAssessedUndiagnosed"))
                .totalPatients(getPrimitiveLongValue(row, "TotalPatients"))
                .programYear(getPrimitiveIntegerValue(row, "ProgramYear"))
                .updatedDate(row.get("UpdatedDate", LocalDateTime.class))
                .mcaipLastUpdated(row.get("McaipLastUpdated", LocalDateTime.class))
                .mapCpiLastUpdated(row.get("MapCpiLastUpdated", LocalDateTime.class))
                .month(row.get("Month", String.class))
                .maPCPiStarRatingTarget(convertStringToFloat(row,"MA-PCPi_Star_Rating_Target"))
                .overallStarRatingTarget(convertStringToFloat(row,"Overall_Star_Rating_Target"))
                .annualCareVisitsTarget(convertStringToInt(row,"Annual_Care_Visits_Target"))
                .suspectConditionsTarget(convertStringToInt(row,"Suspect_Conditions_Target"))
                .partDStarRatingTarget(convertStringToFloat(row, "Part_D_Star_Rating_Target"))
                .assessedAndUnableToDiagnoseTarget(convertStringToInt(row,"Assessed_And_Unable_To_Diagnose_Target"))
                .mapCpiPartDStarRating(row.get("MapCpiPartDStarRating", BigDecimal.class))
                .mcaipTotalPatients(getPrimitiveLongValue(row, "McaipTotalPatients"))
                .startDate(row.get("StartDate", LocalDate.class))
                .build();
    }
}
