package com.optum.rqns.ftm.controller;

import com.optum.rqns.ftm.customannotation.CustomApiResponse;
import com.optum.rqns.ftm.dto.masterconfig.MasterConfigValueDTO;
import com.optum.rqns.ftm.dto.masterconfig.MasterConfigurationDTO;
import com.optum.rqns.ftm.dto.masterconfig.MasterConfigurationRequest;
import com.optum.rqns.ftm.dto.masterconfig.MasterConfigDTO;
import com.optum.rqns.ftm.dto.masterconfig.MasterConfigMultipleRequest;
import com.optum.rqns.ftm.enums.TypeEnum;
import com.optum.rqns.ftm.exception.APIErrorCode;
import com.optum.rqns.ftm.exception.ProgramPerformanceException;
import com.optum.rqns.ftm.model.UserInfo;
import com.optum.rqns.ftm.repository.masterconfigrepository.MasterConfigRepository;
import com.optum.rqns.ftm.service.masterconfigservice.MasterConfigService;
import com.optum.rqns.ftm.util.ProgramPerformanceHeaders;
import com.optum.rqns.ftm.util.StargateStandardResponseUtilV2;
import com.optum.rqns.ftm.util.UserInfoUtil;
import com.optum.rqns.ftm.wrapper.GenericWrapper;
import com.optum.rqns.ftm.wrapper.SingleResponseWrapper;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.util.Arrays;
import java.util.List;

import static com.optum.rqns.ftm.util.UserInfoUtil.isAdmin;

@Profile("rqnsFtmApi")
@RestController
@RequestMapping("/v1/master-configurations")
@Slf4j
@CustomApiResponse
public class MasterConfigurationController {

    @Autowired
    private MasterConfigRepository masterConfigRepository;

    @Autowired
    private MasterConfigService masterConfigService;

    @Autowired
    private StargateStandardResponseUtilV2<Object, Object> stargateStandardResponseUtilV2;

    @PutMapping("/{code}")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = Integer.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<SingleResponseWrapper<MasterConfigValueDTO>> updateConfigValue(
            @RequestHeader(value = ProgramPerformanceHeaders.X_USER_DETAILS_HEADER) String userDetails,
            @PathVariable String code,
            @RequestBody MasterConfigurationRequest request
    ) {
        UserInfo userInfo = UserInfoUtil.parseUserInfo(userDetails);
        if(isAdmin(userInfo)) {
            log.info("Updating the configuration value for {}", code);
            String value = request.getData().getValue();

            if (code != null && isValidFieldLeaderThreshold(code) ) {
                return masterConfigService.updateConfigurations(code,request,userInfo.getUuid());
            } else if (code != null && code.substring(0, 3).equals("FLL")) {
                if (!isValidValue(value))
                    return Mono.error(new ProgramPerformanceException(HttpStatus.BAD_REQUEST, APIErrorCode.INVALID_PAYLOAD_REQUEST));
            }
            return masterConfigService.updateConfigurations(code,request,userInfo.getUuid());
        }
        return Mono.error(new ProgramPerformanceException(HttpStatus.BAD_REQUEST, APIErrorCode.INVALID_USER_HEADER));
    }

    @GetMapping("/admin")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = MasterConfigurationDTO.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<GenericWrapper> getAdminConfigurationList() {
        log.info("Getting master configuration items");

        GenericWrapper wrapper = new GenericWrapper();
        return stargateStandardResponseUtilV2.generateStargateStandardResponse(masterConfigRepository.getAdminConfigurationList(), TypeEnum.FLUX, wrapper).cast(GenericWrapper.class)
                .onErrorMap(e -> {
                    log.error("Exception occurred in fetching master configuration items");
                    return new ProgramPerformanceException(HttpStatus.OK, APIErrorCode.DATA_ACCESS_EXCEPTION);
                })
                .switchIfEmpty(Mono.error(new ProgramPerformanceException(HttpStatus.OK, APIErrorCode.NO_CONTENT)));
    }

    @GetMapping("/{code}")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = MasterConfigurationDTO.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<GenericWrapper> getConfigurationByCode(@PathVariable("code") String code) {
        log.info("Getting master configuration item for code: {}", code);

        GenericWrapper wrapper = new GenericWrapper();
        return stargateStandardResponseUtilV2.generateStargateStandardResponse(masterConfigService.getConfigurationByCode(code), TypeEnum.FLUX, wrapper).cast(GenericWrapper.class)
                .onErrorMap(e -> {
                    log.error("Exception occurred in fetching master configuration item for code: {}", code);
                    return new ProgramPerformanceException(HttpStatus.OK, APIErrorCode.DATA_ACCESS_EXCEPTION);
                })
                .switchIfEmpty(Mono.error(new ProgramPerformanceException(HttpStatus.OK, APIErrorCode.NO_CONTENT)));
    }

    @GetMapping("/admin-program-years")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = MasterConfigurationDTO.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<GenericWrapper> getCurrentProgramYears(
            @RequestHeader(value = ProgramPerformanceHeaders.X_USER_DETAILS_HEADER) String userDetails) {
        log.info("Getting master configuration items");

        UserInfo userInfo = UserInfoUtil.parseUserInfo(userDetails);
        if(isAdmin(userInfo)) {
            GenericWrapper wrapper = new GenericWrapper();
            return stargateStandardResponseUtilV2.generateStargateStandardResponse(masterConfigRepository.getProgramYears(), TypeEnum.FLUX, wrapper).cast(GenericWrapper.class)
                    .onErrorMap(e -> {
                        log.error("Exception occurred in fetching master configuration items");
                        return new ProgramPerformanceException(HttpStatus.OK, APIErrorCode.DATA_ACCESS_EXCEPTION);
                    })
                    .switchIfEmpty(Mono.error(new ProgramPerformanceException(HttpStatus.OK, APIErrorCode.NO_CONTENT)));
        }
        return Mono.error(new ProgramPerformanceException(HttpStatus.BAD_REQUEST, APIErrorCode.INVALID_USER_HEADER));
    }

    @PutMapping("/admin-program-years")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = Integer.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<SingleResponseWrapper<List<MasterConfigDTO>>> updateCurrentProgramYears(
            @RequestHeader(value = ProgramPerformanceHeaders.X_USER_DETAILS_HEADER) String userDetails,
            @RequestBody MasterConfigMultipleRequest request
    ) {
        UserInfo userInfo = UserInfoUtil.parseUserInfo(userDetails);
        if(isAdmin(userInfo)) {
            log.info("Updating the configuration values for program years");
                return masterConfigService.updateProgramYears(request, userInfo.getUuid())
                    .onErrorMap(e -> {
                        log.error("Exception occurred in updating master configuration items");
                        return new ProgramPerformanceException(HttpStatus.BAD_REQUEST, APIErrorCode.INVALID_PAYLOAD_REQUEST);
                    });
        }
        return Mono.error(new ProgramPerformanceException(HttpStatus.BAD_REQUEST, APIErrorCode.INVALID_USER_HEADER));
    }

    @GetMapping("/admin-qfo-star-ratings")
    @ApiResponse(responseCode = "200", description = "Success Request",
        content = @Content(schema = @Schema(implementation = MasterConfigurationDTO.class),
        mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<GenericWrapper> getQfoStarRatings(
        @RequestHeader(value = ProgramPerformanceHeaders.X_USER_DETAILS_HEADER) String userDetails) {
        log.info("Getting star rating items");
        UserInfo userInfo = UserInfoUtil.parseUserInfo(userDetails);
        if(isAdmin(userInfo)) {
            GenericWrapper wrapper = new GenericWrapper();
            return stargateStandardResponseUtilV2.generateStargateStandardResponse(masterConfigService.getQfoStarRatings(), TypeEnum.MONO, wrapper)
                .cast(GenericWrapper.class)
                .onErrorMap(e -> {
                    log.error("Exception occurred in fetching master configuration QFO Star Ratings");
                    return new ProgramPerformanceException(HttpStatus.OK, APIErrorCode.DATA_ACCESS_EXCEPTION);
                })
                .switchIfEmpty(Mono.error(new ProgramPerformanceException(HttpStatus.OK, APIErrorCode.NO_CONTENT)));
        }
        return Mono.error(new ProgramPerformanceException(HttpStatus.BAD_REQUEST, APIErrorCode.INVALID_USER_HEADER));
    }

    @PutMapping("/admin-qfo-star-ratings")
    @ApiResponse(responseCode = "200", description = "Success Request",
        content = @Content(schema = @Schema(implementation = Integer.class),
        mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<SingleResponseWrapper<MasterConfigMultipleRequest>> updateQfoStarRatings(
        @RequestHeader(value = ProgramPerformanceHeaders.X_USER_DETAILS_HEADER) String userDetails,
        @RequestBody MasterConfigMultipleRequest request
    ) {
        UserInfo userInfo = UserInfoUtil.parseUserInfo(userDetails);
        if(isAdmin(userInfo)) {
            log.info("Updating star rating items");
            return masterConfigService.updateQfoStarRatings(request, userInfo.getUuid())
                                      .onErrorMap(e -> {
                                          log.error("Exception occurred in updating master configuration QFO Star Ratings");
                                          return new ProgramPerformanceException(HttpStatus.BAD_REQUEST, APIErrorCode.INVALID_PAYLOAD_REQUEST);
                                      });
        }
        return Mono.error(new ProgramPerformanceException(HttpStatus.BAD_REQUEST, APIErrorCode.INVALID_USER_HEADER));
    }

    private boolean isValidValue(String value) {
        if (value != null) {
            String[] values = value.split(",", 4);
            // Ensure there are 3 values exactly
            if (values.length != 3) {
                return false;
            }
            // Ensure that each value is a number
            for (String number : values) {
                if (!number.matches("[-><=]?\\d+"))
                    return false;
            }
            return true;
        }
        return false;
    }

    private boolean isValidFieldLeaderThreshold(String code) {
        for (String prefix : getFieldLeaderThresholdsPrefixes()) {
            if (code.contains(prefix)) {
                return true;
            }
        }
        return false;
    }

    private List<String> getFieldLeaderThresholdsPrefixes() {
        return Arrays.asList("FLL_IOA_Performance",
                "FLL_My_Team_IOA_Performance",
                "FLL_POC_Conversion_Rate",
                "FLL_My_Team_POC_Conversion_Rate",
                "FLL_Growth_Rate",
                "FLL_My_Team_Growth_Rate",
                "FLL_EModality_Adoption_Rate",
                "FLL_My_Team_EModality_Adoption_Rate"
        );
    }

}