package com.optum.rqns.ftm.dto.opportunities.providergrp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OpportunitiesDetailsDTO {
    private String providerGroupID;
    private String state;
    private int programYear;
    private String clientName;
    private String opportunityType;
    private String opportunitySubType;
    private int opportunityTypePosition;
    private int opportunitySubTypePosition;
    private String displayText;
    private int assessmentCount;
    private int deploymentCount;
    private int gapCount;
    private LocalDate opportunityLastUpdatedDate;
    private String masterOpportunityType;
    private int masterOpportunityTypePosition;
    private int totalAssessmentsCount;
    private int totalGapsCount;
    private int totalClientsCount;
}
