package com.optum.rqns.ftm.dto.performance.providergrp;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.ToString;

import java.time.LocalDate;

@Getter
@Builder
@EqualsAndHashCode
@NoArgsConstructor
@ToString
@AllArgsConstructor
public class ProviderGroupLobPerformanceDTO {
    private String providerGroupId;
    private String providerGroupName;
    private String state;
    private String serviceLevel;
    private String clientName;
    private String lobName;
    private int programYear;
    private Double returnYTDTargetPercent;
    private Double returnYETargetPercent;
    private Long deployYTDActual;
    private Long returnYTDActual;
    private Long returnYTDTarget;
    private Long returnYETarget;
    private Long deployYeTarget;
    private LocalDate deploymentStartDate;
    private LocalDate lastDeploymentDate;
    private LocalDate durationEndDate;
    private String durationValue;
    private Long eligibleDeployableMemberCount;
    private Long deployYtdTarget;
    private LocalDate lastUpdatedDate;
    private Long eligiblePreferredMemberCount;
    private Long returnedNetCnaYtdActual;
    private LocalDate returnedStartDate;
    private LocalDate lastReturnedDate;
}
