package com.optum.rqns.ftm.dto.opportunities.providergrp.converter;

import com.optum.rqns.ftm.constants.ProviderGroupConstants;
import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;

import com.optum.rqns.ftm.model.opportunities.providergrp.OpportunitiesSummaryDetails;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;

import java.time.LocalDate;

public class OpportunitiesSummaryConverter implements Converter<Row, OpportunitiesSummaryDetails>,DTOWrapperTypeConverter {
    @Override
    public OpportunitiesSummaryDetails convert(Row row) {

        return OpportunitiesSummaryDetails.builder()
                .opportunitySummaryId(convertIntToString(row,ProviderGroupConstants.ID))
                .lastUpdatedDate(row.get(ProviderGroupConstants.LAST_UPDATED_DATE, LocalDate.class))
                .masterOpportunityType(row.get(ProviderGroupConstants.MASTER_LEVEL_OPPORTUNITY,String.class))
                .masterOpportunityTypePosition(getPrimitiveIntegerValue(row, ProviderGroupConstants.MASTER_LEVEL_OPPORTUNITY_POSITION))
                .programYear(getPrimitiveIntegerValue(row, ProviderGroupConstants.PROGRAM_YEAR))
                .providerGroupID(row.get(ProviderGroupConstants.OPPORTUNITY_PROVIDER_GROUP_ID,String.class))
                .providerGroupName(row.get(ProviderGroupConstants.PROVIDER_GROUP_NAME,String.class))
                .serviceLevel(row.get(ProviderGroupConstants.OPPORTUNITY_SERVICE_LEVEL,String.class))
                .state(row.get(ProviderGroupConstants.OPPORTUNITY_STATE,String.class))
                .totalAssessmentsCount(getPrimitiveIntegerValue(row, ProviderGroupConstants.TOTAL_ASSESSMENTS_COUNT))
                .totalClientsCount(getPrimitiveIntegerValue(row, ProviderGroupConstants.TOTAL_CLIENTS_COUNT))
                .totalGapsCount(getPrimitiveIntegerValue(row, ProviderGroupConstants.TOTAL_GAPS_COUNT))
                .build();

    }
}
