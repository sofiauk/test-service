package com.optum.rqns.ftm.dto.export.converter;

import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.enums.DocumentType;
import com.optum.rqns.ftm.enums.ExportStatus;
import com.optum.rqns.ftm.model.export.ExportTransaction;
import io.r2dbc.spi.Row;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.convert.converter.Converter;

import static com.optum.rqns.ftm.repository.exports.ExportRepositoryImpl.Columns.DOCUMENT_TYPE;
import static com.optum.rqns.ftm.repository.exports.ExportRepositoryImpl.Columns.EXPORT_STATUS;
import static com.optum.rqns.ftm.repository.exports.ExportRepositoryImpl.Columns.FILE_NAME;
import static com.optum.rqns.ftm.repository.exports.ExportRepositoryImpl.Columns.TRANSACTION_ID;
import static com.optum.rqns.ftm.repository.exports.ExportRepositoryImpl.Columns.OPTUM_UUID;

@Slf4j
public class ExportTransactionConverter implements Converter<Row, ExportTransaction>, DTOWrapperTypeConverter {
    @Override
    public ExportTransaction convert(Row row) {
        return ExportTransaction
                .builder()
                .documentType(getDocumentType(row))
                .exportStatus(getExportStatus(row))
                .fileName(row.get(FILE_NAME.getValue(), String.class))
                .transactionId(row.get(TRANSACTION_ID.getValue(), Long.class))
                .uuid(row.get(OPTUM_UUID.getValue(), String.class))
                .build();
    }

    private ExportStatus getExportStatus(Row row) {
        String sExportStatus = row.get(EXPORT_STATUS.getValue(), String.class);
        return ExportStatus.fromString(sExportStatus);
    }

    DocumentType getDocumentType(Row row) {
        String sDocumentType = row.get(DOCUMENT_TYPE.getValue(), String.class);
        return DocumentType.fromString(sDocumentType);
    }
}
