package com.optum.rqns.ftm.batch.quartz.config;

import com.optum.rqns.ftm.batch.quartz.jobs.*;

import org.quartz.JobDetail;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.quartz.CronTriggerFactoryBean;
import org.springframework.scheduling.quartz.JobDetailFactoryBean;
import org.springframework.context.annotation.Profile;

@Profile("rqnsFtmJobs")
@Configuration
public class QuartzSubmitJobs {
    @Value("${rqns.ftm.schedulerCron.memberAssessmentDataSyncTarget}")
    private String memberAssessmentDataSyncCronExpression;
    @Value("${rqns.ftm.schedulerCron.runOutliersRulesJob}")
    private String outlierRulesJobCronExpression;
    @Value("${rqns.ftm.schedulerCron.runSecondarySubmissionRulesJob}")
    private String secondarySubmissionRulesJobCronExpression;
    @Value("${rqns.ftm.schedulerCron.runRunPaymentRulesJob}")
    private String paymentRulesJobCronExpression;
    @Value("${rqns.ftm.schedulerCron.runWeeklyJobs}")
    private String runWeeklyJobsCronExpression;

    @Bean(name = "RunWeeklyJobs")
    public JobDetailFactoryBean runWeeklyJobs() {
        return QuartzConfig
                .createJobDetail(RunWeeklyJobs.class, "RunWeeklyJobs");
    }

    @Bean(name = "RunWeeklyJobsTrigger")
    public CronTriggerFactoryBean triggerrunWeeklyJobs(@Qualifier("RunWeeklyJobs") JobDetail jobDetail) {
        return QuartzConfig
                .createCronTrigger(jobDetail, runWeeklyJobsCronExpression, "RunWeeklyJobsTrigger");
    }

    @Bean(name = "LoadMemberAssessment")
    public JobDetailFactoryBean loadMemberAssessmentJob() {
        return QuartzConfig
                .createJobDetail(MemberAssessmentDataSyncNotifier.class, "LoadMemberAssessment Job");
    }

    @Bean(name = "LoadMemberAssessmentTrigger")
    public CronTriggerFactoryBean triggerLoadMemberAssessment(@Qualifier("LoadMemberAssessment") JobDetail jobDetail) {
        return QuartzConfig
                .createCronTrigger(jobDetail, memberAssessmentDataSyncCronExpression, "LoadMemberAssessment Trigger");
    }

    @Bean(name = "RunOutlierRulesJob")
    public JobDetailFactoryBean runOutlierRulesJob() {
        return QuartzConfig
                .createJobDetail(OutlierRulesJob.class, "RunOutlierRules Job");
    }

    @Bean(name = "RunOutlierRulesJobTrigger")
    public CronTriggerFactoryBean triggerOutlierRulesJob(@Qualifier("RunOutlierRulesJob") JobDetail jobDetail) {
        return QuartzConfig
                .createCronTrigger(jobDetail, outlierRulesJobCronExpression, "OutlierRulesJob Trigger");
    }

    @Bean(name = "RunSecondarySubmissionRulesJob")
    public JobDetailFactoryBean runSecondarySubmissionRulesJob() {
        return QuartzConfig
                .createJobDetail(SecondarySubmissionRulesJob.class, "RunSecondarySubmissionRules Job");
    }

    @Bean(name = "RunSecondarySubmissionRulesJobTrigger")
    public CronTriggerFactoryBean triggerSecondarySubmissionRulesJob(@Qualifier("RunSecondarySubmissionRulesJob") JobDetail jobDetail) {
        return QuartzConfig
                .createCronTrigger(jobDetail, secondarySubmissionRulesJobCronExpression, "SecondarySubmissionRulesJob Trigger");
    }


    @Bean(name = "RunPaymentRulesJob")
    public JobDetailFactoryBean runRunPaymentRulesJob() {
        return QuartzConfig
                .createJobDetail(PaymentRulesJob.class, "RunPaymentRules Job");
    }

    @Bean(name = "RunPaymentRulesJobTrigger")
    public CronTriggerFactoryBean triggerRunPaymentRulesJob(@Qualifier("RunPaymentRulesJob") JobDetail jobDetail) {
        return QuartzConfig
                .createCronTrigger(jobDetail, paymentRulesJobCronExpression, "RunPaymentRulesJob Trigger");
    }
}
