package com.optum.rqns.ftm.model.job;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.Getter;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class JobProcessingResponse {
    int affectedRows;
    String message;
}
