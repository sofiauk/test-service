package com.optum.rqns.ftm.dto.performance.providergrp.converter.qfo;

import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.dto.performance.providergrp.qfo.ProviderGroupPerformanceDetailsDTO;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class ProviderGroupPerformanceDetailsDTOConverter implements Converter<Row, ProviderGroupPerformanceDetailsDTO>, DTOWrapperTypeConverter {
    @Override
    public ProviderGroupPerformanceDetailsDTO convert(Row row) {
        return ProviderGroupPerformanceDetailsDTO.builder()
                .mapCpiAnnualCareVisits(getPrimitiveLongValue(row, "MapCpiAnnualCareVisits"))
                .mapCpiEligiblePatients(getPrimitiveLongValue(row, "MapCpiEligiblePatients"))
                .mapCpiStarRating(row.get("MapCpiStartRating", BigDecimal.class))
                .mcaipFullyAssessed(getPrimitiveLongValue(row, "McaipFullyAssessed"))
                .mcaipSuspectMedicalConditions(getPrimitiveLongValue(row, "McaipSuspectMedicalConditions"))
                .overAllStarRating(row.get("OverAllStartRating", BigDecimal.class))
                .pCpiPartDRating(row.get("MapCpiPartDRating", BigDecimal.class))
                .providerGroupId(row.get("ProviderGroupId", String.class))
                .suspectConditionAssessedTotal(getPrimitiveLongValue(row, "SuspectConditionAssessedTotal"))
                .suspectConditionsTotal(getPrimitiveLongValue(row, "SuspectConditionsTotal"))
                .suspectDiagnosed(getPrimitiveLongValue(row, "SuspectDiagnosed"))
                .suspectNotAssessed(getPrimitiveLongValue(row, "SuspectNotAssessed"))
                .suspectUndiagnosed(getPrimitiveLongValue(row, "SuspectUndiagnosed"))
                .totalPatients(getPrimitiveLongValue(row, "TotalPatients"))
                .mcaipTotalPatients(getPrimitiveLongValue(row, "McaipTotalPatients"))
                .updatedDate(row.get("UpdatedDate", LocalDateTime.class))
                .mcaipLastUpdated(row.get("McaipLastUpdated", LocalDateTime.class))
                .mapCpiLastUpdated(row.get("MapCpiLastUpdated", LocalDateTime.class))
                .build();
    }
}
