package com.optum.rqns.ftm.controller;

import com.optum.rqns.ftm.customannotation.CustomApiResponse;
import com.optum.rqns.ftm.dto.goals.client.Response.ClientGoalSnapshotResponse;
import com.optum.rqns.ftm.dto.goals.client.Response.ClientGoalYearsResponse;
import com.optum.rqns.ftm.dto.goals.client.Response.ClientGoalsAggregateResponse;
import com.optum.rqns.ftm.dto.goals.client.Response.ClientLobGoalValuesResponse;
import com.optum.rqns.ftm.dto.goals.client.Response.LobResponse;
import com.optum.rqns.ftm.dto.goals.client.Response.RegionResponse;
import com.optum.rqns.ftm.enums.TypeEnum;
import com.optum.rqns.ftm.model.goals.client.ClientGoalTypeRequestBody;
import com.optum.rqns.ftm.model.goals.client.RegionGoalTypeRequestBody;
import com.optum.rqns.ftm.model.goals.client.RegionsRequestBody;
import com.optum.rqns.ftm.service.ClientGoalsService;
import com.optum.rqns.ftm.util.StargateStandardResponseUtilV2;
import com.optum.rqns.ftm.wrapper.GenericWrapper;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;
import org.springframework.context.annotation.Profile;

@Profile("rqnsFtmApi")
@RestController
@RequestMapping("/v1/goals/clients")
@Slf4j
@CustomApiResponse
public class ClientGoalsController {
    @Autowired
    ClientGoalsService clientGoalsService;

    @Autowired
    StargateStandardResponseUtilV2<Object,Object> stargateStandardResponseUtilV2;

    @ApiResponse(responseCode = "200", description = "Sucess Request", content = @Content(schema = @Schema(implementation = ClientGoalSnapshotResponse.class),mediaType = MediaType.APPLICATION_JSON_VALUE))
    @GetMapping
    public Mono<ClientGoalSnapshotResponse> getClientGoals(@RequestParam int year) {
        log.debug("Getting Clients Goals for the Year: {}", year);
        return stargateStandardResponseUtilV2.generateStargateStandardResponse(clientGoalsService.getClientSnapshotGoals(year), TypeEnum.FLUX, new ClientGoalSnapshotResponse()).cast(ClientGoalSnapshotResponse.class);
    }

    @ApiResponse(responseCode = "200", description = "Sucess Request", content = @Content(schema = @Schema(implementation = ClientGoalsAggregateResponse.class),mediaType = MediaType.APPLICATION_JSON_VALUE))
    @GetMapping("/aggregates")
    public Mono<ClientGoalsAggregateResponse> getAllClientGoals(@RequestParam int year) {
        log.debug("Getting All Clients Goals for the Year: {}", year);
        return stargateStandardResponseUtilV2.generateStargateStandardResponse(clientGoalsService.getClientGoalsAggregate(year), TypeEnum.MONO, new ClientGoalsAggregateResponse()).cast(ClientGoalsAggregateResponse.class);
    }

    @ApiResponse(responseCode = "200", description = "Sucess Request", content = @Content(schema = @Schema(implementation = ClientGoalYearsResponse.class),mediaType = MediaType.APPLICATION_JSON_VALUE))
    @GetMapping("/years")
    public Mono<ClientGoalYearsResponse> getClientGoalsYears() {
        log.debug("Getting years for all the clients data");
        return stargateStandardResponseUtilV2.generateStargateStandardResponse(clientGoalsService.getClientGoalYears(), TypeEnum.MONO, new ClientGoalYearsResponse()).cast(ClientGoalYearsResponse.class);
    }

    @ApiResponse(responseCode = "202", description = "Sucess Request", content = @Content(schema = @Schema(implementation = ClientLobGoalValuesResponse.class),mediaType = MediaType.APPLICATION_JSON_VALUE))
    @PostMapping("/{client-id}/lobs/{lob-id}/goals")
    public Mono<ClientLobGoalValuesResponse> getClientLobRegionGoals(@PathVariable("client-id") int clientId, @PathVariable("lob-id") int lobId, @RequestBody ClientGoalTypeRequestBody clientGoalTypeRequestBody) {
        log.debug("Getting Client Lob level Goals Details: clientId: {}, lob: {}, request body: {}", clientId, lobId, clientGoalTypeRequestBody);
        return stargateStandardResponseUtilV2.generateStargateStandardResponse(clientGoalsService.getClientLobGoalValues(clientId, lobId, clientGoalTypeRequestBody), TypeEnum.FLUX, new ClientLobGoalValuesResponse()).cast(ClientLobGoalValuesResponse.class);
    }

    @ApiResponse(responseCode = "202", description = "Sucess Request", content = @Content(schema = @Schema(implementation = ClientLobGoalValuesResponse.class),mediaType = MediaType.APPLICATION_JSON_VALUE))
    @PostMapping("/{client-id}/lobs/{lob-id}/regions")
    public Mono<ClientLobGoalValuesResponse> getRegionGoals(@PathVariable("client-id") long clientId
            , @PathVariable("lob-id") long lobId, @RequestBody RegionGoalTypeRequestBody regionGoalTypeRequestBody) {
        log.debug("Getting All Regions Goals for the Client: {}, lob:{}, goalType: {}", clientId, lobId, regionGoalTypeRequestBody.getGoalType());
        return stargateStandardResponseUtilV2.generateStargateStandardResponse(clientGoalsService.getRegionGoalsResponse(clientId, lobId, regionGoalTypeRequestBody), TypeEnum.MONO, new ClientLobGoalValuesResponse()).cast(ClientLobGoalValuesResponse.class);
    }

    @ApiResponse(responseCode = "202", description = "Sucess Request", content = @Content(schema = @Schema(implementation = ClientLobGoalValuesResponse.class),mediaType = MediaType.APPLICATION_JSON_VALUE))
    @PostMapping("/{client-id}/lobs/{lob-id}/regions/{region-id}/states")
    public Mono<ClientLobGoalValuesResponse> getRegionGoalsByState(@RequestBody RegionGoalTypeRequestBody regionGoalTypeRequestBody, @PathVariable("client-id") long clientId
            , @PathVariable("lob-id") long lobId, @PathVariable("region-id") String regionId) {
        return stargateStandardResponseUtilV2.generateStargateStandardResponse(clientGoalsService.getRegionGoalsResponseByState(clientId, lobId, regionId, regionGoalTypeRequestBody), TypeEnum.MONO, new ClientLobGoalValuesResponse()).cast(ClientLobGoalValuesResponse.class);
    }

    /**
     * Api endpoint returns all the plain months in string format
     *
     * @return list of all months
     */
    @ApiResponse(responseCode = "200", description = "Sucess Request", content = @Content(schema = @Schema(implementation = GenericWrapper.class), mediaType = MediaType.APPLICATION_JSON_VALUE))
        @GetMapping("/months/{program-year}")
        public Mono<GenericWrapper> getMonths(@PathVariable("program-year") int programYear) {
        log.debug("Fetching all the months");
        GenericWrapper wrapper = new GenericWrapper();
        return stargateStandardResponseUtilV2.generateStargateStandardResponse(clientGoalsService.getMonths(programYear), TypeEnum.MONO, wrapper).cast(GenericWrapper.class);
    }


    /**
     * Api endpoint returns all the plain weeks in string format
     *
     * @return list of all weeks
     */
    @ApiResponse(responseCode = "200", description = "Sucess Request", content = @Content(schema = @Schema(implementation = GenericWrapper.class), mediaType = MediaType.APPLICATION_JSON_VALUE))
    @GetMapping("/weeks")
    public Mono<GenericWrapper> getWeeks(@RequestParam Integer year) {
        log.debug("Fetching all the weeks for the year: {}", year);
        GenericWrapper wrapper = new GenericWrapper();
        return stargateStandardResponseUtilV2.generateStargateStandardResponse(clientGoalsService.getWeeksInAYear(year), TypeEnum.MONO,wrapper).cast(GenericWrapper.class);
    }

    /**
     * Api endpoint returns all the plain weeks in string format
     *
     * @return list of lobs
     */
    @ApiResponse(responseCode = "200", description = "Sucess Request", content = @Content(schema = @Schema(implementation = LobResponse.class),mediaType = MediaType.APPLICATION_JSON_VALUE))
    @GetMapping("/lobs")
    public Mono<LobResponse> getLobForClientId(@RequestParam("client-id") Integer clientId) {
        log.debug("Fetching lob for the clientId: {}", clientId);
        LobResponse lobResponse = new LobResponse();
        return stargateStandardResponseUtilV2.generateStargateStandardResponse(clientGoalsService.getLobForClientId(clientId), TypeEnum.FLUX, lobResponse).cast(LobResponse.class);
    }



    /**
     * Api endpoint returns all the plain months in string format
     *
     * @return list of all quarters
     */
    @ApiResponse(responseCode = "200", description = "Sucess Request", content = @Content(schema = @Schema(implementation = GenericWrapper.class), mediaType = MediaType.APPLICATION_JSON_VALUE))
    @GetMapping("/quarters/{program-year}")
    public Mono<GenericWrapper> getAllQuarters(@PathVariable("program-year") int programYear) {
        log.debug("Fetching all the quarters");
        GenericWrapper wrapper = new GenericWrapper();
        return stargateStandardResponseUtilV2.generateStargateStandardResponse(clientGoalsService.getAllQuarters(programYear), TypeEnum.MONO, wrapper).cast(GenericWrapper.class);
    }


    /**
     * Api endpoint returns all the regions for a given clientId
     *
     * @return returns regions
     */
    @ApiResponse(responseCode = "200", description = "Sucess Request", content = @Content(schema = @Schema(implementation = RegionResponse.class),mediaType = MediaType.APPLICATION_JSON_VALUE))
    @GetMapping("/{client-id}/lobs/{lob-id}/regions")
    public Mono<RegionResponse> getRegionsForClientId(@PathVariable("client-id") int clientId
            , @PathVariable("lob-id") int lobId, @RequestParam int year) {
        log.debug("Fetching region for the clientId: {}", clientId);
        RegionResponse regionResponse = new RegionResponse();
        return stargateStandardResponseUtilV2.generateStargateStandardResponse(clientGoalsService.getRegionsForClientId(clientId, lobId, year), TypeEnum.FLUX, regionResponse).cast(RegionResponse.class);
    }

    /**
     * returns list of all the regions for the below params
     * @param clientId clientId
     * @param  lobId lobId
     * @param regionsRequestBody regionsRequestBody @see{RegionsRequestBody}
     * @return list of all the regions for the mentioned params
     */
    @ApiResponse(responseCode = "202", description = "Success Request", content = @Content(schema = @Schema(implementation = RegionResponse.class),mediaType = MediaType.APPLICATION_JSON_VALUE))
    @PostMapping("/{client-id}/lobs/{lob-id}/regions/lists")
    public Mono<RegionResponse> getRegionsForRequestType(@PathVariable("client-id") int clientId
            , @PathVariable("lob-id") int lobId, @RequestBody RegionsRequestBody regionsRequestBody) {
        log.debug("Fetching region for the clientId: {}", clientId);
        return stargateStandardResponseUtilV2.generateStargateStandardResponse(clientGoalsService.getRegionsForRequestType(clientId, lobId, regionsRequestBody), TypeEnum.FLUX, new RegionResponse()).cast(RegionResponse.class);
    }

}
