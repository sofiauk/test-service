package com.optum.rqns.ftm.dto.opportunities.providergrp.converter;

import com.optum.rqns.ftm.constants.ProviderGroupConstants;
import com.optum.rqns.ftm.model.opportunities.providergrp.MemberAssessmentLobs;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;

public class MemberAssessmentLobConverter implements Converter<Row, MemberAssessmentLobs> {

    @Override
    public MemberAssessmentLobs convert(Row row) {
        return MemberAssessmentLobs.builder()
                .lobName(row.get(ProviderGroupConstants.LOB_NAME, String.class))
                .build();
    }
}
