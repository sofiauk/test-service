package com.optum.rqns.ftm.dto.qfo.performance.healthSystem;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@EqualsAndHashCode
@NoArgsConstructor
@ToString
@AllArgsConstructor
public class QFOHealthSystemPerformanceDetailsDTO extends HealthSystemPerformanceDetailsDTO {

    private String month;
    private int annualCareVisitsTarget;
    private float maPCPiStarRatingTarget;
    private float overallStarRatingTarget;
    private float partDStarRatingTarget;
    private int suspectConditionsTarget;
    private BigDecimal mapCpiPartDStarRating;
    private int assessedAndUnableToDiagnoseTarget;
    private LocalDate startDate;

    @Builder(builderMethodName = "healthSystemPerformanceDetailsBuilder")
    public QFOHealthSystemPerformanceDetailsDTO(String month, int annualCareVisitsTarget, float maPCPiStarRatingTarget, float overallStarRatingTarget, float partDStarRatingTarget, int suspectConditionsTarget, BigDecimal mapCpiPartDStarRating, String healthSystemId,Long totalPatients,BigDecimal overAllStarRating, Long mapCpiEligiblePatients,BigDecimal mapCpiStarRating,BigDecimal mapCpiPartDRating, Long mapCpiAnnualCareVisits ,Long suspectConditionsTotal, Long suspectConditionAssessedTotal, Long suspectDiagnosed, Long suspectUndiagnosed, Long suspectNotAssessed, Long mcaipFullyAssessed, Long mcaipSuspectMedicalConditions, LocalDateTime updatedDate, LocalDateTime mapCpiLastUpdated, LocalDateTime mcaipLastUpdated,int assessedAndUnableToDiagnoseTarget, String healthSystemName,int programYear, String mapCpiPatientExperience,BigDecimal acpStarRating, String incetiveProgram, String teamType, Long mcaipTotalPatients, String durationValue , LocalDate startDate
    ) {
        super(healthSystemId,healthSystemName,programYear,totalPatients,mcaipTotalPatients,overAllStarRating,mapCpiEligiblePatients,mapCpiStarRating,mapCpiPatientExperience,mapCpiPartDStarRating,acpStarRating,mapCpiAnnualCareVisits,suspectConditionsTotal,suspectConditionAssessedTotal,suspectDiagnosed,suspectUndiagnosed,suspectNotAssessed,mcaipFullyAssessed,mcaipSuspectMedicalConditions,teamType,durationValue, updatedDate,mapCpiLastUpdated,mcaipLastUpdated);
        this.month = month;
        this.annualCareVisitsTarget = annualCareVisitsTarget;
        this.maPCPiStarRatingTarget = maPCPiStarRatingTarget;
        this.overallStarRatingTarget = overallStarRatingTarget;
        this.partDStarRatingTarget = partDStarRatingTarget;
        this.suspectConditionsTarget = suspectConditionsTarget;
        this.mapCpiPartDStarRating = mapCpiPartDStarRating;
        this.assessedAndUnableToDiagnoseTarget = assessedAndUnableToDiagnoseTarget;
        this.startDate = startDate;

    }
}
