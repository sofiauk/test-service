package com.optum.rqns.ftm.model.opportunities.exports;

import com.optum.rqns.ftm.model.UserInfo;
import com.optum.rqns.ftm.model.opportunities.providergrp.MemberAssessment;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class MemberAssessmentInputs {
    String requestID;
    MemberAssessment exportParams;
    UserInfo userInfo;
    boolean offshoreRestricted;
    
}
