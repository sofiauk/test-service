package com.optum.rqns.ftm.dto.opportunities.providergrp.converter;

import com.optum.rqns.ftm.constants.ProviderGroupConstants;
import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.dto.opportunities.providergrp.OpportunityConfigurationDTO;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;

public class OpportunityConfigurationDTOConverter implements Converter<Row, OpportunityConfigurationDTO>, DTOWrapperTypeConverter {
    @Override
    public OpportunityConfigurationDTO convert(Row row) {
        return OpportunityConfigurationDTO.builder()
                .databaseLogic(row.get(ProviderGroupConstants.DATABASE_LOGIC, String.class))
                .id(getPrimitiveIntegerValue(row, ProviderGroupConstants.ID))
                .isActive(row.get(ProviderGroupConstants.IS_ACTIVE, Boolean.class))
                .isSummaryAggregationRequired(row.get(ProviderGroupConstants.IS_SUMMARY_AGGREGATION_REQUIRED, Boolean.class))
                .masterOpportunityDisplayOrder(getPrimitiveIntegerValue(row, ProviderGroupConstants.MASTER_OPPORTUNITY_DISPLAY_ORDER))
                .masterOpportunityName(row.get(ProviderGroupConstants.MASTER_OPPORTUNITY_TYPE_NAME, String.class))
                .opportunityDisplayOrder(getPrimitiveIntegerValue(row, ProviderGroupConstants.OPPORTUNITY_DISPLAY_ORDER))
                .opportunityName(row.get(ProviderGroupConstants.OPPORTUNITY_NAME, String.class))
                .selectClauseCondition(row.get(ProviderGroupConstants.SELECT_CLAUSE_CONDITION, String.class))
                .whereClauseCondition(row.get(ProviderGroupConstants.WHERE_CLAUSE_CONDITION, String.class))
                .build();
    }
}
