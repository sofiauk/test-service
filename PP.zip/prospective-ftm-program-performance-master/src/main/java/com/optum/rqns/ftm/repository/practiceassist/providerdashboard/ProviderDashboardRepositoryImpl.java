package com.optum.rqns.ftm.repository.practiceassist.providerdashboard;

import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.dto.practiceassist.providerdashboard.ProviderDashboardAggrDTO;
import com.optum.rqns.ftm.model.practiceassist.providerdashboard.MedAdherenceAggregationDO;
import com.optum.rqns.ftm.model.practiceassist.providerdashboard.QualityAggregationDO;
import com.optum.rqns.ftm.model.practiceassist.providerdashboard.SuperUserProvDashDO;
import com.optum.rqns.ftm.model.practiceassist.providerdashboard.ProviderDashboardAggrRequest;
import com.optum.rqns.ftm.model.practiceassist.providerdashboard.UserProfile;
import com.optum.rqns.ftm.dto.practiceassist.providerdashboard.SuperUserProviderGroupData;
import io.r2dbc.spi.Row;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.time.StopWatch;
import org.springframework.data.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Repository;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import static com.optum.rqns.ftm.constants.practiceassist.providerdashboard.PracticeAssistConstant.PA_SUPER_USER_JOB;
import static com.optum.rqns.ftm.constants.practiceassist.providerdashboard.PracticeAssistConstant.PROVIDER_GROUP_ID;

@Repository
@Slf4j
public class ProviderDashboardRepositoryImpl implements ProviderDashboardRepository, DTOWrapperTypeConverter {

    private DatabaseClient databaseClient;

    @AllArgsConstructor
    @Getter
    public enum ColumnNames {
        PROV_GRP_ID("ProviderGroupID"), HLTH_SYS_ID("HealthSystemID"), SUB_CLI_SK("SubClientSk"),
        ST_CD("ProviderState"), PGM_YR("ProgramYear"), PCP_ID("ProviderID"), CLIENT_ID("ClientID"), IS_ACTIVE("IsActive");

        private String columnName;
    }

    public ProviderDashboardRepositoryImpl(DatabaseClient databaseClient) {
        this.databaseClient = databaseClient;
    }

    private static final String AND_KEY = " and ";
    private static final String OR_KEY = " or ";
    private static final String EQUAL_KEY = "  = ";
    private static final String OPEN_BRACE = " ( ";
    private static final String CLOSE_BRACE = " ) ";
    private static final String SINGLE_QUOTE = "'";


    private static StringBuilder QUALITY_AGGR_SUM = new StringBuilder()
            .append("select sum(A1CCount) as a1CCount, sum(OMWCount) as oMWCount, sum(NewPatient7Count) as newPatient7Count,")
            .append("sum(NewPatient30Count) as newPatient30Count, sum(NewPatient90Count) as newPatient90Count, ")
            .append("sum(AnnualCareVisitNotCompleteCount) as annualCareVisitNotCompleteCount, sum(NoCurrFluVaccCount) as noCurrFluVaccCount,")
            .append("sum(HighPriorityCount) as highPriorityCount from ProgPerf.QualityAggregation with (nolock) where ");

    private static StringBuilder MEDADHERENCE_AGGR_SUM = new StringBuilder()
            .append("select sum(AbsFailDateCount) as absFailDateCount, sum(rxFillOppurtunityCount) as rxFillOppurtunityCount from ProgPerf.MedAdherenceAggregation with (nolock)  where ");

    private static StringBuilder CALC_SUPER_USER_PROV_GRP = new StringBuilder()
            .append("WITH groups AS (SELECT ProviderGroupID as providerGroupID, ProviderGroupName as providerGroupName, ")
            .append("SubClientSk as subClientSk, ProgramYear as programYear, ROW_NUMBER() OVER (PARTITION BY SubClientSk, ")
            .append("ProgramYear ORDER BY ProviderGroupName  ASC ) AS [ROW NUMBER] FROM ProgPerf.MemberSummaryAggregation ")
            .append("WHERE IsActive  = 1) SELECT * FROM groups WHERE groups.[ROW NUMBER] = 1");

    private static StringBuilder UPSERT_SUPER_USER_PROV_GRP = new StringBuilder()
            .append("MERGE INTO ProgPerf.SuperUserProviderGroup AS TARGET ")
            .append("USING( VALUES(:providerGroupId, :providerGroupName, :subClientSk, :programYear)) AS SOURCE ")
            .append("(ProviderGroupID, ProviderGroupName, SubClientSk, ProgramYear) ON ")
            .append("(TARGET.SubClientSk = SOURCE.subClientSk and TARGET.ProgramYear = SOURCE.programYear ) ")
            .append(" WHEN MATCHED THEN ")
            .append("UPDATE ")
            .append("SET ProviderGroupID =:providerGroupId, ProviderGroupName =:providerGroupName, ")
            .append("UpdatedBy = :updatedBy, UpdatedDate = GETUTCDATE() ")
            .append("WHEN NOT MATCHED BY TARGET THEN ")
            .append("INSERT ")
            .append("(ProviderGroupID, ProviderGroupName, SubClientSk, ProgramYear, CreatedBy, CreatedDate, UpdatedBy,")
            .append(" UpdatedDate) ")
            .append("VALUES(:providerGroupId, :providerGroupName, :subClientSk, :programYear, :createdBy, GETUTCDATE(),")
            .append(":updatedBy, GETUTCDATE());");

    public static StringBuilder GET_SUPER_USER_PROVIDER_GROUP = new StringBuilder()
            .append("select top 1 ProviderGroupId as providerGroupId from ProgPerf.SuperUserProviderGroup with (nolock) ")
            .append("where ");

    @Override
    public Mono<QualityAggregationDO> getQualityAggr(ProviderDashboardAggrRequest providerDashboardAggrRequest) {
        log.info("In ProviderDashboardRepositoryImpl.getQualityAggr started");
        return databaseClient.execute(aggregateQuery(QUALITY_AGGR_SUM, providerDashboardAggrRequest).toString()).
                as(QualityAggregationDO.class).map((row, rowMetadata) -> buildQualityAggr(row)).one();
    }

    public QualityAggregationDO buildQualityAggr(Row row) {
        return QualityAggregationDO.builder()
                .a1CCount(getPrimitiveIntegerValue(row, "a1CCount"))
                .oMWCount(getPrimitiveIntegerValue(row, "oMWCount"))
                .newPatient7Count(getPrimitiveIntegerValue(row, "newPatient7Count"))
                .newPatient30Count(getPrimitiveIntegerValue(row, "newPatient30Count"))
                .newPatient90Count(getPrimitiveIntegerValue(row, "newPatient90Count"))
                .annualCareVisitNotCompleteCount(getPrimitiveIntegerValue(row, "annualCareVisitNotCompleteCount"))
                .noCurrFluVaccCount(getPrimitiveIntegerValue(row, "noCurrFluVaccCount"))
                .highPriorityCount(getPrimitiveIntegerValue(row, "highPriorityCount"))
                .build();
    }

    @Override
    public Mono<MedAdherenceAggregationDO> getMedAdherenceAggr(ProviderDashboardAggrRequest providerDashboardAggrRequest) {
        log.info("In ProviderDashboardRepositoryImpl.getMedAdherenceAggr started");
        return databaseClient.execute(aggregateQuery(MEDADHERENCE_AGGR_SUM, providerDashboardAggrRequest).toString()).
                as(MedAdherenceAggregationDO.class).map((row, rowMetadata) -> buildMedAdherenceAggr(row)).one();
    }

    public MedAdherenceAggregationDO buildMedAdherenceAggr(Row row) {
        return MedAdherenceAggregationDO.builder()
                .absFailDateCount(getPrimitiveIntegerValue(row, "absFailDateCount"))
                .rxFillOppurtunityCount(getPrimitiveIntegerValue(row, "rxFillOppurtunityCount"))
                .build();
    }

    private StringBuilder aggregateQuery(StringBuilder baseQuery, ProviderDashboardAggrRequest providerDashboardAggrRequest) {
        StringBuilder mainQuery = new StringBuilder(baseQuery);
        mainQuery.append(ColumnNames.PGM_YR.getColumnName() + EQUAL_KEY + providerDashboardAggrRequest.getPgmAsesYr());
        mainQuery.append(AND_KEY);
        StringBuilder query = new StringBuilder();
        query.append(OPEN_BRACE);
        Integer queryCount = 0;
        for (UserProfile userProfile : providerDashboardAggrRequest.getPrvGrps()) {
            queryCount = 0;
            if (query.length() > 5){
                query.append(OR_KEY);
            }
            query.append(OPEN_BRACE);
            queryCount = populateInClause(userProfile.getProvGrpId(), query, ColumnNames.PROV_GRP_ID.getColumnName(), queryCount);

            queryCount = populateInClause(userProfile.getHealthSystemIds(), query, ColumnNames.HLTH_SYS_ID.getColumnName(), queryCount);

            queryCount = populateInClause(userProfile.getPcpId(), query, ColumnNames.PCP_ID.getColumnName(), queryCount);

            queryCount = populateInClause(userProfile.getStCd(), query, ColumnNames.ST_CD.getColumnName(), queryCount);

            populateInClause(userProfile.getClientId(), query, ColumnNames.CLIENT_ID.getColumnName(), queryCount);

            if (!CollectionUtils.isEmpty(Arrays.asList(userProfile.getSubCliSk())) && userProfile.getSubCliSk().length > 0) {
                query.append(AND_KEY + ColumnNames.SUB_CLI_SK.columnName + " in ( ");
                query.append(Arrays.asList(userProfile.getSubCliSk()).stream().map(String::valueOf).collect(Collectors.joining(",")));
                query.append(CLOSE_BRACE);
            }
            query.append(CLOSE_BRACE);
        }
        query.append(CLOSE_BRACE);
        mainQuery.append(query);
        applyAcoFilter(mainQuery, providerDashboardAggrRequest);
        applyHlthSysIdFilter(mainQuery, providerDashboardAggrRequest);
        mainQuery.append(AND_KEY).append(ColumnNames.IS_ACTIVE.getColumnName()).append(EQUAL_KEY).append("1");
        return mainQuery;
    }

    private void applyHlthSysIdFilter(StringBuilder mainQuery, ProviderDashboardAggrRequest providerDashboardAggrRequest){
        if (!ObjectUtils.isEmpty(providerDashboardAggrRequest.getHealthSystemId())){
            mainQuery.append(AND_KEY).append(ColumnNames.HLTH_SYS_ID.getColumnName()).append(EQUAL_KEY).append(SINGLE_QUOTE)
                    .append(providerDashboardAggrRequest.getHealthSystemId()).append(SINGLE_QUOTE);
        }
    }

    private void applyAcoFilter(StringBuilder mainQuery, ProviderDashboardAggrRequest providerDashboardAggrRequest){
        if (!ObjectUtils.isEmpty(providerDashboardAggrRequest.getAcoProvGrpId()) && providerDashboardAggrRequest.getAcoProvGrpId().length > 0){
            mainQuery.append(AND_KEY);
            populateInClause(providerDashboardAggrRequest.getAcoProvGrpId(), mainQuery, ColumnNames.PROV_GRP_ID.getColumnName(), 0);
        }
    }

    private Integer populateInClause(String[] data, StringBuilder query, String colNm, Integer queryCount) {

        if (!ObjectUtils.isEmpty(data)){
            if (queryCount > 0){
                query.append(AND_KEY);
            }
            if (!CollectionUtils.isEmpty(Arrays.asList(data)) && data.length > 0) {
                query.append( colNm + " in ('" + String.join("','", data) + "')");
                queryCount ++;
            }
        }

        return queryCount;
    }

    public Flux<SuperUserProvDashDO> calcSuperUserProvGrp(){
        log.info("In ProviderDashboardRepositoryImpl.calcSuperUserProvGrp is started");
        return databaseClient.execute(CALC_SUPER_USER_PROV_GRP.toString()).map((row, rowMetadata) ->
                buildSuperUserProvDashDO(row)).all();
    }

    public SuperUserProvDashDO buildSuperUserProvDashDO(Row row){
        return SuperUserProvDashDO.builder()
                .providerGroupID(getValue(row, "providerGroupID", String.class))
                .programYear(getPrimitiveIntegerValue(row, "programYear"))
                .providerGroupName(getValue(row, "providerGroupName", String.class))
                .subClientSk(getPrimitiveIntegerValue(row, "subClientSk"))
                .build();
    }

    @Override
    public Mono<Integer> upsertSuperUserProvGrp(List<SuperUserProvDashDO> superUserProvDashDOList) {
        StopWatch stopWatch = StopWatch.createStarted();
        log.info("Executing upsertSuperUserProvGrp::");

        for (SuperUserProvDashDO superUserProvDashDO : superUserProvDashDOList) {
            String providerGroupName = "";
            if (!StringUtils.isEmpty(superUserProvDashDO.getProviderGroupName())){
                providerGroupName = superUserProvDashDO.getProviderGroupName();
            }
            databaseClient.execute(UPSERT_SUPER_USER_PROV_GRP.toString())
                    .bind(PROVIDER_GROUP_ID, superUserProvDashDO.getProviderGroupID())
                    .bind("providerGroupName", providerGroupName)
                    .bind("subClientSk",  superUserProvDashDO.getSubClientSk())
                    .bind("programYear", superUserProvDashDO.getProgramYear())
                    .bind("createdBy", PA_SUPER_USER_JOB)
                    .bind("updatedBy", PA_SUPER_USER_JOB).fetch().rowsUpdated().subscribe();
        }

        log.info("execution completed for {} upsertSuperUserProvGrp: {} seconds", superUserProvDashDOList.size(),
                stopWatch.getTime(TimeUnit.SECONDS));
        return Mono.just(superUserProvDashDOList.size());
    }

    @Override
    public Mono<SuperUserProviderGroupData> findSuperUserProvGrpId(ProviderDashboardAggrDTO providerDashboardAggrDTO) {
        log.info("In ProviderDashboardRepositoryImpl.findSuperUserProvGrpId is started");
        return databaseClient.execute(getSuperUserProvQuery(GET_SUPER_USER_PROVIDER_GROUP, providerDashboardAggrDTO).toString()).
                as(SuperUserProviderGroupData.class).map((row, rowMetadata) -> buildSuperUserProvId(row)).one();
    }

    private StringBuilder getSuperUserProvQuery(StringBuilder baseQuery, ProviderDashboardAggrDTO providerDashboardAggrDTO) {
        StringBuilder query = new StringBuilder(baseQuery);
        query.append(ColumnNames.PGM_YR.getColumnName() + EQUAL_KEY + providerDashboardAggrDTO.getPgmAsesYr());
        query.append(AND_KEY + ColumnNames.SUB_CLI_SK.columnName + " in ( ");
        query.append(providerDashboardAggrDTO.getSubCliSk().stream().map(String::valueOf)
                .collect(Collectors.joining(",")));
        query.append(") order by ProviderGroupName asc ");
        return query;
    }

    public SuperUserProviderGroupData buildSuperUserProvId(Row row) {
        return SuperUserProviderGroupData.builder()
                .providerGroupId(getValue(row, PROVIDER_GROUP_ID, String.class)).build();
    }
}