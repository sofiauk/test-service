package com.optum.rqns.ftm.dto.rules;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.time.LocalDateTime;
import java.util.List;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ProviderGroupOpportunitiesSummaryDTO {
    int opportunityID;
    String providerGroupID;
    String providerGroupName;
    String state;
    int programYear;
    String masterOpportunityType;
    int masterOpportunityTypePosition;
    int totalAssessmentsCount;
    int totalClientsCount;
    int totalGapsCount;
    String createdBy;
    LocalDateTime createdDate;
    String rowAction;
    List<ProviderGroupOpportunitiesDetailsDTO> details;
}