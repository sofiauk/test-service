package com.optum.rqns.ftm.enums;


public enum OpportunityType {
    REJECTS("Rejects"), RETURNS("Returns"),SECONDARY_SUBMISSIONS("Secondary Submissions"),
    OUTLERS("Outliers"),FINANCIAL_INFORMATION("Financial Information"),DEPLOYMENTS("Deployments"),EMPTY("");;
    private String value;

    private OpportunityType(String value) {
        this.value = value;
    }

    public String getValue(){
        return value;
    }

}
