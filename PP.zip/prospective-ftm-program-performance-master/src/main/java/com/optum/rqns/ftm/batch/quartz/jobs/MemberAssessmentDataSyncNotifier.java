package com.optum.rqns.ftm.batch.quartz.jobs;

import java.time.Instant;

import com.optum.rqns.ftm.constants.CommandCenterConstants;
import com.optum.rqns.ftm.enums.ExecutionWeek;
import com.optum.rqns.ftm.enums.GroupsToExecute;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.repository.common.CommonRepository;
import org.joda.time.LocalDate;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.optum.rqns.ftm.service.masterconfigservice.MasterConfigService;

import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.producer.JobEventProducer;

import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Profile;
import reactor.core.publisher.Flux;

@Profile("rqnsFtmJobs")
@Slf4j
@Component
@DisallowConcurrentExecution
public class MemberAssessmentDataSyncNotifier implements Job {
    @Autowired
    private JobEventProducer jobEventProducer;
    @Autowired
    private MasterConfigService masterConfigService;
    @Autowired
    private CommonRepository commonRepository;

    private static final String JOB_NAME = JobName.LOAD_MEMBER_ASSESSMENT.getValue (); //"LoadMemberAssessment";
    private static final String GROUPS_TO_EXECUTE = GroupsToExecute.MODIFIED.getValue ();//"Modified";
    private static final String EXECUTION_WEEK = ExecutionWeek.CURRENT.getValue (); //"Current";
    private static final String STATUS = Status.IN_PROGRESS.getValue (); //"Start";
    private static final String DESCRIPTION = "notification to load member assessment data job";

    @Override
    public void execute(JobExecutionContext context) {
        log.info ("Job ** {} ** starting @ {}", context.getJobDetail ().getKey ().getName (), context.getFireTime ());
        notifyMemberAssessmentDataSyncJob (context, buildJobEvent ());
    }

    private JobEvent buildJobEvent() {
        //2. Read Current Project year from Master configuration table.
        Flux<String> currentProgramYearMono = masterConfigService.getCurrentProgramYear ()
                .onErrorMap (err ->
                {
                    String errorMessage = err.getMessage ();
                    log.error ("Failed to fetch current program year from master configuration. {}", errorMessage);
                    throw new RuntimeException (errorMessage);
                });
        String currentProjectYear = currentProgramYearMono.blockFirst ();
        int projectYear = Integer.parseInt (currentProjectYear);
        log.info ("current project from master config: {}", projectYear);
        return JobEvent.newBuilder ().setJobName (JOB_NAME).setGroupsToExecute (GROUPS_TO_EXECUTE)
                .setExecutionWeek (EXECUTION_WEEK).setStatus (STATUS).setProgramYear (projectYear)
                .setTimeStamp (Instant.now ()).build ();
    }

    private void notifyMemberAssessmentDataSyncJob(JobExecutionContext context, JobEvent jobEvent) {
        try {
            String value =  commonRepository.getValueFromConfiguration("EnableRedisJobFlow").block();
            if ("true".equalsIgnoreCase(value)){
                jobEvent.setEventType("REDIS");
            }
            boolean sent = jobEventProducer.postToMsgQue(jobEvent);
            if (!sent) {
                log.error ("Failed to send {}", DESCRIPTION);
            } else {
                log.info ("Successfully sent {}", DESCRIPTION);
            }
        } catch (Exception e) {
            log.error ("Job Failed!! Job ** {} ** starting @ {}  with Exception ## {} ",
                    context.getJobDetail ().getKey ().getName (), context.getFireTime (), e.getMessage ());

        }
    }

}


