package com.optum.rqns.ftm.dto.performance.providergrp.qfo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@EqualsAndHashCode
@NoArgsConstructor
@ToString
@AllArgsConstructor
public class QFOProviderGroupPerformanceDetailsDTO extends ProviderGroupPerformanceDetailsDTO {

    private String month;
    private int annualCareVisitsTarget;
    private float maPCPiStarRatingTarget;
    private float overallStarRatingTarget;
    private int partDStarRatingTarget;
    private int suspectConditionsTarget;
    private BigDecimal mapCpiPartDStarRating;
    private int assessedAndUnableToDiagnoseTarget;
    LocalDate startDate;

    @Builder(builderMethodName = "providerGroupPerformanceDetailsBuilder")
    public QFOProviderGroupPerformanceDetailsDTO(String month, int annualCareVisitsTarget, float maPCPiStarRatingTarget, float overallStarRatingTarget, int partDStarRatingTarget, int suspectConditionsTarget, BigDecimal mapCpiPartDStarRating, String providerGroupId, Long totalPatients, BigDecimal overAllStarRating, Long mapCpiEligiblePatients, BigDecimal mapCpiStarRating, BigDecimal pCpiPartDRating, Long mapCpiAnnualCareVisits, Long suspectConditionsTotal, Long suspectConditionAssessedTotal, Long suspectDiagnosed, Long suspectUndiagnosed, Long suspectNotAssessed, Long mcaipFullyAssessed, Long mcaipSuspectMedicalConditions, Long mcaipTotalPatients, LocalDateTime updatedDate, LocalDateTime mapCpiLastUpdated, LocalDateTime mcaipLastUpdated, int assessedAndUnableToDiagnoseTarget, LocalDate startDate) {
        super(providerGroupId, totalPatients, overAllStarRating,mapCpiEligiblePatients,mapCpiStarRating,pCpiPartDRating, mapCpiAnnualCareVisits, suspectConditionsTotal, suspectConditionAssessedTotal, suspectDiagnosed, suspectUndiagnosed, suspectNotAssessed, mcaipFullyAssessed, mcaipSuspectMedicalConditions, mcaipTotalPatients, updatedDate, mapCpiLastUpdated, mcaipLastUpdated);
        this.month = month;
        this.annualCareVisitsTarget = annualCareVisitsTarget;
        this.maPCPiStarRatingTarget = maPCPiStarRatingTarget;
        this.overallStarRatingTarget = overallStarRatingTarget;
        this.partDStarRatingTarget = partDStarRatingTarget;
        this.suspectConditionsTarget = suspectConditionsTarget;
        this.mapCpiPartDStarRating = mapCpiPartDStarRating;
        this.assessedAndUnableToDiagnoseTarget = assessedAndUnableToDiagnoseTarget;
        this.startDate = startDate;
    }
}
