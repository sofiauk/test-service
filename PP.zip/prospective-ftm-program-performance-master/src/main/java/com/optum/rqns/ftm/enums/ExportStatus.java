package com.optum.rqns.ftm.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum ExportStatus {
    SUCCESS("Success"),
    FAILED("Failed"),
    CANCELLED("Cancelled"),
    IN_PROGRESS("InProgress"),
    NOTIFIED("Notified"),
    NON_NOTIFIED("NonNotified"),
    READ("Read"),
    UNREAD("Unread"),
    DELETED("Deleted");
    String value;

    public static ExportStatus fromString(String text) {
        for (ExportStatus exportStatus : ExportStatus.values()) {
            if (exportStatus.value.equalsIgnoreCase(text)) {
                return exportStatus;
            }
        }
        return null;
    }

}
