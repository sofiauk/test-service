package com.optum.rqns.ftm.model.rules;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FinancialInformationOpportunityInput implements OpportunityInput {
    String providerGroupId ;
    String providerGroupName ;
    String providerState;
    String serviceLevel;
    int projectYear;
    String paymentRejectReason;

    @Override
    public String getClient() {
        return null;
    }

    @Override
    public String getLobName() {
        return null;
    }

    @Override
    public String getClientId() {
        return null;
    }


    @Override
    public int getDeployYTDActual() {
        return 0;
    }

    @Override
    public int getReturnYTDActual() {
        return 0;
    }

    @Override
    public int getReturnYTDActualPercentage() {
        return 0;
    }

    @Override
    public int getReturnYTDTargetPercent() {
        return 0;
    }

    @Override
    public String getSingleRejectReason() {
        return null;
    }

    @Override
    public String getChartID() {
        return null;
    }

    @Override
    public String getOutlierName() {
        return null;
    }

    @Override
    public String getGapType() {
        return null;
    }

    @Override
    public String getGapDesc() {
        return null;
    }

    @Override
    public String getIsSecondarySubmissionEligible() {
        return null;
    }

    @Override
    public String getOverAllStatus() {
        return null;
    }

    @Override
    public int getEligibleMembersCount() {
        return 0;
    }
}
