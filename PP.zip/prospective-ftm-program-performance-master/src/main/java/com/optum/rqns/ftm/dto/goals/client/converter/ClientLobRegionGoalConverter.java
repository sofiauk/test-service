package com.optum.rqns.ftm.dto.goals.client.converter;

import com.optum.rqns.ftm.constants.ClientGoalConstants;
import com.optum.rqns.ftm.dto.goals.client.ClientLobRegionGoalValuesDTO;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;

public class ClientLobRegionGoalConverter implements Converter<Row, ClientLobRegionGoalValuesDTO>, DTOConverter {
    @Override
    public ClientLobRegionGoalValuesDTO convert(Row row) {
        String regionName = row.get(ClientGoalConstants.REGION, String.class);
        Double eligibleMembers = getDoubleValue(row, ClientGoalConstants.ELIGIBLEMEMBERS_COLUMN_NAME);
        Double goalValue = getDoubleValue(row, ClientGoalConstants.GOAL_VALUE_COLUMN_NAME);
        String goalType = row.get(ClientGoalConstants.GOAL_TYPE_COLUMN_NAME, String.class);
        boolean isClientRegion = row.get(ClientGoalConstants.IS_CLIENT_REGION_COLUMN_NAME, Boolean.class);
        int stateCount = row.get(ClientGoalConstants.STATE_COUNT_COLUMN_NAME, Integer.class);
        String regionId = row.get(ClientGoalConstants.REGION_ID, String.class);
        int clientId = row.get(ClientGoalConstants.CLIENT_ID, Integer.class);
        int lobId = row.get(ClientGoalConstants.LOB_ID, Integer.class);
        String clientName = row.get(ClientGoalConstants.CLIENT_COLUMN_NAME,String.class);
        String lob  = row.get(ClientGoalConstants.LOB,String.class);
        return ClientLobRegionGoalValuesDTO.builder().lobId(lobId).lobName(lob)
                .clientId(clientId).clientName(clientName).eligibleMembers(eligibleMembers)
                .goalType(goalType).goalValue(goalValue)
                .isClientRegion(isClientRegion)
                .regionId(regionId).regionName(regionName).stateCount(stateCount)
                .build();
    }
}
