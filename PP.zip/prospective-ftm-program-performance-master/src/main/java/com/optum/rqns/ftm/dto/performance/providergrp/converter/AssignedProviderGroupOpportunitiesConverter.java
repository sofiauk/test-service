package com.optum.rqns.ftm.dto.performance.providergrp.converter;

import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.model.performance.providergrp.AssignedProviderGroupOpportunities;
import com.optum.rqns.ftm.repository.performance.providergrp.ProviderGroupPerformanceRepositoryImpl.ColumnNames;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;

import java.time.LocalDateTime;

public class AssignedProviderGroupOpportunitiesConverter implements Converter<Row, AssignedProviderGroupOpportunities>, DTOWrapperTypeConverter {
    @Override
    public AssignedProviderGroupOpportunities convert(Row row) {
        return AssignedProviderGroupOpportunities.builder()
                .opportunitiesCount(getLongValue(row, ColumnNames.OPPORTUNITIES_COUNT.getColumnName()))
                .opportunitiesType(row.get(ColumnNames.OPPORTUNITIES_TYPE.getColumnName(), String.class))
                .gapsCount(getLongValue(row, ColumnNames.GAPS_COUNT.getColumnName()))
                .returnYTDActual(getLongValue(row, ColumnNames.RETURN_YTD_ACTUAL.getColumnName()))
                .returnYTDTargetPercent(row.get(ColumnNames.RETURN_YTD_TARGET_PERCENT.getColumnName(), Float.class) != null ? row.get(ColumnNames.RETURN_YTD_TARGET_PERCENT.getColumnName(), Float.class).longValue():null)
                .state(row.get(ColumnNames.STATE.getColumnName(), String.class))
                .tin(row.get(ColumnNames.TIN.getColumnName(), String.class))
                .lastTouchPoint(row.get(ColumnNames.LAST_ACTIVITY_DATE.getColumnName(), LocalDateTime.class) != null ? row.get(ColumnNames.LAST_ACTIVITY_DATE.getColumnName(), LocalDateTime.class).toLocalDate(): null)
                .providerGroupName(row.get(ColumnNames.PROVIDER_GROUP_NAME.getColumnName(),String.class))
                .providerGroupId(row.get(ColumnNames.PROVIDER_GROUP_ID.getColumnName(), String.class))
                .hoursAgo(row.get(ColumnNames.LAST_ACTIVITY_AGO.getColumnName(), Integer.class))
                .serviceLevel(row.get(ColumnNames.SERVICE_LEVEL.getColumnName(),String.class))
                .build();
    }
}
