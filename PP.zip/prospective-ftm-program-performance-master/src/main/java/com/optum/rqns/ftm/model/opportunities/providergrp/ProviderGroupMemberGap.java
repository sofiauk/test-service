package com.optum.rqns.ftm.model.opportunities.providergrp;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ProviderGroupMemberGap {
    private int memberGapCount;
    @JsonProperty("memberGaps")
    private List<ProviderGroupMemberGaps> providerGroupMemberGaps;
}
