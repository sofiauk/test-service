package com.optum.rqns.ftm.constants.practiceassist.providerdashboard;

public class PracticeAssistConstant {

    public static final String SUCCESS_CODE = "200";
    public static final String SUCCESS_REQUEST = "Success Request";
    public static Integer LAST_REFRESH_HOUR = 0;
    public static final String DONE = "Done";
    public static final String PA_SUPER_USER_JOB = "PA-SUPER-USER-JOB";
    public static final String PROVIDER_GROUP_ID = "providerGroupId";
}
