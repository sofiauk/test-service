package com.optum.rqns.ftm.model.opportunities.providergrp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MemberAssessmentOpportunitySubTypes {

    private String opportunitySubType;
}
