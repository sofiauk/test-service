package com.optum.rqns.ftm.model.goals.client;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.List;

/**
 * @author dvenka19
 *  This class will hold StateGoals data
 *  lombok will generate getter,setter,toString,noArgsConstructor and allArgsConstructor
 */

@Data
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ClientLobStateGoalValues {
    private String stateName;
    private String stateId;
    @JsonProperty("aggregate")
    private GoalDetailValues goalDetailValues;
    @JsonProperty("hPlans")
    private List<ClientLobHPlanGoalValues> clientLobHPlanGoalValues;
}
