package com.optum.rqns.ftm.response.providergrp;

import com.optum.rqns.ftm.model.providergrp.MembershipChangeIhaToIoa;
import com.optum.rqns.ftm.wrapper.Meta;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class MembershipChangeIhaToIoaResponse {
    private Meta meta;

    private List<MembershipChangeIhaToIoa> data;

    public MembershipChangeIhaToIoaResponse() {
        this.meta = new Meta ();
        this.data = new ArrayList<> ();
    }
}
