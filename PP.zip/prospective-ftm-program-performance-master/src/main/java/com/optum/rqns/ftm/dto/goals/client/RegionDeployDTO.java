package com.optum.rqns.ftm.dto.goals.client;

import lombok.Data;
import lombok.ToString;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Builder;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class RegionDeployDTO {
    private Integer clientId;
    private String clientName;
    private String lob;
    private Integer lobId;
    private String region;
    private String regionId;
    private String state;
    private String stateId;
    private String  hcfa;
    private String pbpId;
    private Float deployed;
    private Float returned;
    private Float completed;
    private Double eligibleMembers;
}
