package com.optum.rqns.ftm.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum DocumentType {

    EXCEL("Excel"),
    PDF("Pdf");

    String value;

    public static DocumentType fromString(String text) {
        for (DocumentType documentType : DocumentType.values()) {
            if (documentType.value.equalsIgnoreCase(text)) {
                return documentType;
            }
        }
        return null;
    }

}
