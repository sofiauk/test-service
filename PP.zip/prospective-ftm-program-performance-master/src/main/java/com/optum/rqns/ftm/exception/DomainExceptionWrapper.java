package com.optum.rqns.ftm.exception;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.rqns.ftm.repository.rules.RuleRepository;
import com.optum.rqns.ftm.wrapper.StargateStandardResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.reactive.error.DefaultErrorAttributes;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.slf4j.MDC;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Component
@Slf4j
public class DomainExceptionWrapper extends DefaultErrorAttributes {

    @Autowired
    private RuleRepository ruleRepository;


    @Override
    public Map<String, Object> getErrorAttributes(ServerRequest request, boolean includeStackTrace) {
        Map<String, Object> map = super.getErrorAttributes(request, includeStackTrace);
        StargateStandardResponse wrapper = new StargateStandardResponse();
        ObjectMapper mapper = new ObjectMapper();

        List errorList = new ArrayList<>();

        if(getError(request) instanceof RuleServiceException) {
            RuleServiceException ex = (RuleServiceException) getError(request);
            String errorMsg = ex.getErrorDetails();
            String jobName = ex.getJobName();
//            ruleRepository.updateJobRunConfigurationToFailed(jobName,errorMsg).subscribe();
        }
        if (getError(request) instanceof ProgramPerformanceException) {
            ProgramPerformanceException ex = (ProgramPerformanceException) getError(request);
            log.error(ex.getMessage());
            errorList.add(ex.getApiError());
            wrapper.setErrors(errorList);
            map = mapper.convertValue(wrapper, new TypeReference<Map<String, Object>>() {});
            map.put("status", ex.getHttpStatus().value());
            map.remove("data");
        }
        return map;
    }
}
