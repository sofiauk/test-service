package com.optum.rqns.ftm.repository.masterconfigrepository;

import com.optum.rqns.ftm.dto.masterconfig.MasterConfigDTO;
import com.optum.rqns.ftm.dto.masterconfig.MasterConfigurationDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

@Repository
@Slf4j
public class MasterConfigRepositoryImpl implements MasterConfigRepository {

    private static final String YTD_MASTER_CONFIGURATION = "SELECT mc.code,mc.value FROM PROGPERF.MasterConfiguration mc  WITH (NOLOCK)  WHERE mc.code in (:COLUMN_NAMES)";
    private final DatabaseClient client;
    private static final String VALUE_STR = "value";
    private static final List<String> ADMIN_CONFIG_LIST = Arrays.asList(
    		"CommandCenter_ReturnRate_ExistingGroupsGoalPercent",
			"CommandCenter_ReturnRate_NewGroupsGoalPercent",
			"CommandCenter_POCConversion_ExistingGoalPercent",
			"CommandCenter_POCConversion_NewGoalPercent",
			"FLL_GrowthRate_AgreedTarget",
			"FLL_GrowthRate_EngagedTarget",
			"FLL_POC_ExistingTarget",
			"FLL_POC_NewGroupTarget",
			"FLL_EModality_ReturnedNetCnaTarget",
			"FLL_IOA_Performance_DeployGoal",
			"FLL_IOA_Performance_ReturnGoal",
			"FLL_IOA_Performance_Reject",
			"FLL_IOA_Performance_CgapClosure",
			"FLL_POC_Conversion_Rate_New_Groups_Current_Month_Conversion_Rate",
			"FLL_POC_Conversion_Rate_Existing_Groups_Current_Month_Conversion_Rate",
			"FLL_My_Team_POC_Conversion_Rate_New_Groups_Current_Month_Conversion_Rate",
			"FLL_My_Team_POC_Conversion_Rate_Existing_Groups_Current_Month_Conversion_Rate",
			"FLL_Growth_Rate_YoY_Agreed_Change",
			"FLL_Growth_Rate_YoY_Engaged_Change",
			"FLL_My_Team_Growth_Rate_YoY_Agreed_Change",
			"FLL_My_Team_Growth_Rate_YoY_Engaged_Change",
			"FLL_My_Team_IOA_Performance_DeployGoal",
			"FLL_My_Team_IOA_Performance_ReturnGoal",
			"FLL_My_Team_IOA_Performance_Reject",
			"FLL_My_Team_IOA_Performance_CGAPClosure",
			"FLL_EModality_Adoption_Rate",
			"FLL_My_Team_EModality_Adoption_Rate"
	);

    private static final List<String> ADMIN_PROGRAM_YEAR_LIST = Arrays.asList(
            "CurrentProgramYear",
            "PreviousProgramYear",
            "PreviousToPreviousProgramYear",
            "QFOCurrentProgramYear",
            "QFOPreviousProgramYear",
            "QFOPreviousToPreviousProgramYear"
    );

    private static final List<String> ADMIN_STAR_RATING_LIST = Arrays.asList(
            "Overall_Star_Rating_Target",
            "Standard_Target"
    );

    @Autowired
    public MasterConfigRepositoryImpl(DatabaseClient client) {
        this.client = client;
    }

    public enum ColumnNames {
        CODE("code"),
        VALUE(VALUE_STR);

        private String columnName;

        ColumnNames(String columnName) {
            this.columnName = columnName;
        }

        public String getColumnName() {
            return this.columnName;
        }
    }

    private static final String SELECT_VALUE_BY_COLUMN_NAME = "SELECT mc.value FROM PROGPERF.MasterConfiguration mc  WITH (NOLOCK)  WHERE mc.code=:COLUMN_NAME;";
    private static final String LAST_RUN_DATE = "SELECT convert(varchar, JR.LastSuccessfulRunDate, 20) FROM PROGPERF.JobRunConfiguration JR WHERE JR.JobName=:JOBNAME;";
    private static final String PROGRAM_YEAR_START_DATE = "SELECT convert(varchar, PC.StartDate, 20) FROM PROGPERF.ProgramYearCalendar PC WHERE PC.ProgramYear=:PROGRAM_YEAR AND PC.DurationValue=:DURATION_VALUE;";

    private static final String RULES_MASTER_CONFIG =
            " SELECT mc.code AS code, mc.value AS value FROM PROGPERF.MasterConfiguration mc WITH (NOLOCK)" +
            " WHERE mc.code in (:CONFIGS)" +
            " UNION " +
            " SELECT JobName AS code, convert(varchar,JR.LastSuccessfulRunDate,20) AS value FROM PROGPERF.JobRunConfiguration JR" +
            " WHERE JR.JobName in (:JOBNAMES)";

    private static final String UPDATE_CONFIG_VALUE =
            " UPDATE PROGPERF.MasterConfiguration " +
                    " SET " + VALUE_STR + " = :" + VALUE_STR +  " " +
                    " WHERE code = :code" +
                    " AND code IN (:ConfigList)";

    private static final String SELECT_CONFIG_LIST_RECORDS =
            " SELECT id, code, value FROM PROGPERF.MasterConfiguration " +
                    " WHERE code IN (:ConfigList)";

    private static final String SELECT_CONFIG_RECORD =
            " SELECT id, code, value FROM PROGPERF.MasterConfiguration WHERE code = :code";

    private static final String SELECT_CURRENT_PROGRAM_YEARS_ADMIN =
            "SELECT code, value FROM PROGPERF.MasterConfiguration WHERE code = 'CurrentProgramYear' OR code = 'QFOCurrentProgramYear';";

    private static final String SELECT_ALL_PROGRAM_YEARS =
            "SELECT id, code, value FROM PROGPERF.MasterConfiguration WHERE code IN (:ProgramYearList);";

    private static final String UPDATE_PROGRAM_YEARS =
            "UPDATE PROGPERF.MasterConfiguration " +
            "SET value = (CASE " +
                    "WHEN code = 'CurrentProgramYear' THEN :currentProgramYear " +
                    "WHEN code = 'PreviousProgramYear' THEN :currentProgramYear - 1 " +
                    "WHEN code = 'PreviousToPreviousProgramYear' THEN :currentProgramYear - 2 " +
                    "WHEN code = 'QFOCurrentProgramYear' THEN :qfoCurrentProgramYear " +
                    "WHEN code = 'QFOPreviousProgramYear' THEN :qfoCurrentProgramYear - 1 " +
                    "WHEN code = 'QFOPreviousToPreviousProgramYear' THEN :qfoCurrentProgramYear - 2 " +
            "END) " +
            "WHERE code IN (:ProgramYearList);";

    private static final String SELECT_STAR_RATING_ADMIN =
            "SELECT id, code, value FROM PROGPERF.MasterConfiguration WHERE code = 'Overall_Star_Rating_Target' OR code = 'Standard_Target';";

    private static final String UPDATE_STAR_RATING =
            "UPDATE PROGPERF.MasterConfiguration " +
                    "SET value = (CASE " +
                    "WHEN code = 'Overall_Star_Rating_Target' THEN :Overall_Star_Rating_Target " +
                    "WHEN code = 'Standard_Target' THEN :Standard_Target " +
                    "END) " +
                    "WHERE code IN (:StarRatingList);";


    @Override
    public Flux<String> getValueFromCode(String columnName) {
        return client.execute(SELECT_VALUE_BY_COLUMN_NAME)
                .bind("COLUMN_NAME", columnName)
                .as(String.class)
                .fetch()
                .all();
    }

    public Flux<String> getLastRunDate(String jobName) {
        return client.execute(LAST_RUN_DATE)
                .bind("JOBNAME", jobName)
                .as(String.class)
                .fetch()
                .all();
    }

    @Override
    public Flux<String> getProgramYearStartDate(String programYear, String durationValue) {
        return client.execute(PROGRAM_YEAR_START_DATE)
                .bind("PROGRAM_YEAR", programYear)
                .bind("DURATION_VALUE", durationValue)
                .as(String.class)
                .fetch()
                .all();
    }

    @Override
    public Flux<MasterConfigDTO> getProgramYears(){
        return client.execute(SELECT_CURRENT_PROGRAM_YEARS_ADMIN)
                .as(MasterConfigDTO.class)
                .map((row, rowMetadata) -> MasterConfigDTO.builder()
                                .code(row.get("code", String.class))
                                .value(row.get(VALUE_STR, String.class))
                                .build()
                )
                .all();
    }

    @Override
    public Flux<MasterConfigurationDTO> getAllProgramYears(){
        return client.execute(SELECT_ALL_PROGRAM_YEARS)
                .bind("ProgramYearList", ADMIN_PROGRAM_YEAR_LIST)
                .as(MasterConfigurationDTO.class)
                .map((row, rowMetadata) -> {
                    Integer id = row.get("id", Integer.class);
                    return MasterConfigurationDTO.builder()
                        .id(id != null ? id : 0)
                        .code(row.get("code", String.class))
                        .value(row.get(VALUE_STR, String.class))
                        .build();
                    }
                )
                .all();
    }

    @Override
    public Mono<Integer> updateProgramYears(String currentProgramYearValue, String qfoCurrentProgramYearValue){
        return client.execute(UPDATE_PROGRAM_YEARS)
                .bind("currentProgramYear", currentProgramYearValue)
                .bind("qfoCurrentProgramYear", qfoCurrentProgramYearValue)
                .bind("ProgramYearList", ADMIN_PROGRAM_YEAR_LIST)
                .fetch()
                .rowsUpdated()
                .doOnNext(integer -> log.info("Updated {} row(s)", integer));
    }

    @Override
    public Flux<MasterConfigurationDTO> getQfoStarRatings(){
        return client.execute(SELECT_STAR_RATING_ADMIN)
                     .as(MasterConfigurationDTO.class)
                     .map((row, rowMetadata) -> {
                         Integer id = row.get("id", Integer.class);
                         String code = row.get("code", String.class);
                         String value = row.get(VALUE_STR, String.class);
                         return MasterConfigurationDTO.builder()
                                         .id(id != null ? id : 0)
                                         .code(code)
                                         .value(value)
                                         .build();
                        }
                     )
                     .all();
    }

    @Override
    public Mono<Integer> updateQfoStarRatings(String overallStarRatingTarget, String standardTarget) {
        return client.execute(UPDATE_STAR_RATING)
                     .bind("Overall_Star_Rating_Target", overallStarRatingTarget)
                     .bind("Standard_Target", standardTarget)
                     .bind("StarRatingList", ADMIN_STAR_RATING_LIST)
                     .fetch()
                     .rowsUpdated()
                     .doOnNext(integer -> log.info("updateQfoStarRatings updated {} row(s)", integer));
    }

  @Override
  public Flux<MasterConfigDTO> getYTDMasterConfiguration(List<String> codes) {
    return client.execute(YTD_MASTER_CONFIGURATION)
        .bind("COLUMN_NAMES", codes)
                .map((row, rowMetadata) -> MasterConfigDTO.builder()
                        .code(row.get("code", String.class))
                        .value(row.get(VALUE_STR, String.class))
                        .build()
                )
                .all();
    }

    @Override
    public Flux<MasterConfigDTO> getRulesMasterConfiguration(List<String> configs,List<String> jobNames){
        return client.execute(RULES_MASTER_CONFIG)
                .bind("CONFIGS", configs)
                .bind("JOBNAMES", jobNames)
                .map((row, rowMetadata) -> MasterConfigDTO.builder()
                        .code(row.get("code", String.class))
                        .value(row.get(VALUE_STR, String.class))
                        .build()
                )
                .all();
    }

    @Override
    public Mono<Integer> updateConfgValue(String code, String value) {
        return client.execute(UPDATE_CONFIG_VALUE)
                .bind(ColumnNames.CODE.getColumnName(), code)
                .bind(ColumnNames.VALUE.getColumnName(), value)
				.bind("ConfigList", ADMIN_CONFIG_LIST)
                .fetch()
                .rowsUpdated()
                .doOnNext(integer -> log.info("Updated {} row(s)", integer));
    }

    @Override
    public Flux<MasterConfigurationDTO> getAdminConfigurationList() {
        return client.execute(SELECT_CONFIG_LIST_RECORDS)
				.bind("ConfigList", ADMIN_CONFIG_LIST)
                .map((row, rowMetadata) -> {
                    Integer id = row.get("id", Integer.class);
                    return MasterConfigurationDTO.builder()
                            .id(id != null ? id : 0)
                            .code(row.get("code", String.class))
                            .value(row.get(VALUE_STR, String.class))
                            .build();
                        }
                )
                .all();
    }

    @Override
    public Flux<MasterConfigurationDTO> getConfigurationByCode(String code) {
        return client.execute(SELECT_CONFIG_RECORD)
                .bind(ColumnNames.CODE.getColumnName(), code)
                .map((row, rowMetadata) -> {
                            Integer id = row.get("id", Integer.class);
                            return MasterConfigurationDTO.builder()
                                    .id(id != null ? id : 0)
                                    .code(row.get("code", String.class))
                                    .value(row.get(VALUE_STR, String.class))
                                    .build();
                        }
                )
                .all();
    }
}
