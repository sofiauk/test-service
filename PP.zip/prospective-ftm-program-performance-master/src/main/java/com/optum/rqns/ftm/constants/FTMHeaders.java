package com.optum.rqns.ftm.constants;

public final class FTMHeaders {
    private FTMHeaders() {
    }

    public static final String X_USER_DETAILS = "x-userDetails";
    public static final String X_TRACE_ID = "x-trace-id";
    public static final String X_PROVIDERONSHORE = "x-providerOnshore";

}
