package com.optum.rqns.ftm.dto.providergrp;

import lombok.Builder;
import lombok.Data;
import lombok.ToString;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MembershipStatsIhaIoaDTO {
    private String providerGroupId;
    private String providerState;
    private Integer programYear;
    private Integer ihaOnlyCount;
    private Integer ioaOnlyCount;
    private Integer bothIhaIoaCount;
    private Integer membershipChangeCount;
    private LocalDateTime latestMembershipChangeDate;
}
