package com.optum.rqns.ftm.repository.commandcenter;

import com.optum.rqns.ftm.model.cpdclientmapping.ClientCPD;
import reactor.core.publisher.Mono;

public interface CpdClientMappingRepository {

    Mono<ClientCPD> getCPDOfClient(String clientName);
}
