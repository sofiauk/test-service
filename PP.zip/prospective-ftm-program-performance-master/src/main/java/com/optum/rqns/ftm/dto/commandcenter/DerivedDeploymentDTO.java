package com.optum.rqns.ftm.dto.commandcenter;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DerivedDeploymentDTO {

    private String name;
    private String state;
    private String lastUpdated;
    private DerivedDeploymentWeeksDTO deployments;
    private DerivedDeploymentYearsDTO programYear;
    private DerivedDeploymentYearsDTO ytd;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class DerivedDeploymentWeeksDTO {
        private Long ytdActual;
        private Long currentWeekCounts;
        private Long previousWeekCounts;
        private Long nextWeekForecastCounts;
        private Long opportunityCounts;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class DerivedDeploymentYearsDTO {
        private Double goal;
        private Double variance;
    }
}