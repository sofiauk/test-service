package com.optum.rqns.ftm.configuration;

import com.optum.rqns.ftm.exception.APIErrorCode;
import com.optum.rqns.ftm.exception.ProgramPerformanceException;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.reactive.function.client.WebClientCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.client.reactive.ClientHttpConnector;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;

import java.io.IOException;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
@Configuration
@Slf4j
public class SecurityConfiguration {

    @Bean
    WebClientCustomizer configureWebClient(@Value("${server-ssl.trust-store}") String trustStorePath, @Value("${server-ssl.trust-store-password}") String trustStorePass,
                                           @Value("${server-ssl.key-store}") String keyStorePath, @Value("${server-ssl.key-store-password}") String keyStorePass, @Value("${server-ssl.key-alias}") String keyAlias) {

        return (WebClient.Builder webClientBuilder) -> {
            SslContext sslContext;
            final X509Certificate[] certificates;
            InputStream keyStoreResourceInputStream = null;
            InputStream trustSourceResourceInputStream = null;
            try {
                final KeyStore trustStore;
                final KeyStore keyStore;
                trustStore = KeyStore.getInstance(KeyStore.getDefaultType());
                Resource trustSourceResource = new ClassPathResource(trustStorePath);
                Resource keyStoreResource = new ClassPathResource(keyStorePath);
                keyStoreResourceInputStream = keyStoreResource.getInputStream();
                trustSourceResourceInputStream = trustSourceResource.getInputStream();
                trustStore.load(trustSourceResourceInputStream, trustStorePass.toCharArray());
                keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
                keyStore.load(keyStoreResourceInputStream, keyStorePass.toCharArray());
                List<Certificate> certificateList = getCertificatesList(trustStore);
                certificates = certificateList.toArray(new X509Certificate[certificateList.size()]);
                sslContext = SslContextBuilder.forClient()
                        .trustManager(certificates)
                        .build();

                HttpClient httpClient = HttpClient.create()
                        .secure(sslContextSpec -> sslContextSpec.sslContext(sslContext));
                ClientHttpConnector connector = new ReactorClientHttpConnector(httpClient);
                webClientBuilder.clientConnector(connector).defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_FORM_URLENCODED_VALUE);
            } catch (CertificateException | NoSuchAlgorithmException | IOException | KeyStoreException e) {
                log.info("CertificateException | NoSuchAlgorithmException | IOException | KeyStoreException : {}",e.getMessage());
                throw new ProgramPerformanceException(HttpStatus.UNAUTHORIZED, APIErrorCode.UNAUTHORIZED);
            } finally {
                try { if(keyStoreResourceInputStream != null ) keyStoreResourceInputStream.close(); } catch (IOException e) { log.error("Exception while closing keyStoreResourceInputStream in security configuration"); }
                try { if(trustSourceResourceInputStream != null ) trustSourceResourceInputStream.close(); } catch (IOException e) { log.error("Exception while closing trustSourceResourceInputStream in security configuration"); }
            }
        };
    }

    private List<Certificate> getCertificatesList(KeyStore trustStore) throws KeyStoreException {
        return Collections.list(trustStore.aliases())
                .stream()
                .filter(t -> {
                    try {
                        return trustStore.isCertificateEntry(t);
                    } catch (KeyStoreException e1) {
                        log.info("KeyStore Exception: {}", e1.getMessage());
                        throw new ProgramPerformanceException("Error reading truststore", e1);
                    }
                })
                .map(t -> {
                    try {
                        return trustStore.getCertificate(t);
                    } catch (KeyStoreException e2) {
                        log.info("KeyStore Exception: {}", e2.getMessage());
                        throw new ProgramPerformanceException("Error reading truststore", e2);
                    }
                })
                .collect(Collectors.toList());
    }

}
