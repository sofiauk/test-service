package com.optum.rqns.ftm.repository.performance.providergrp;


public class ProviderGroupPerformanceQueryBuilder {
    private static final ProviderGroupPerformanceQueryBuilder INSTANCE =
            new ProviderGroupPerformanceQueryBuilder();

    private ProviderGroupPerformanceQueryBuilder() {}

    public static Builder builder() { return INSTANCE.new Builder(); }

    public class Builder {

        private static final String ALL = "'HCA','PSC-B','PSC-P'";
        private static final String HCA = "'HCA'";
        private static final String PSC = "'PSC-B','PSC-P'";
        private static final String LOB_NAME = "LobName";
        private static final String CLIENT_NAME = "ClientName";
        private static final String REGION = "Region";
        private static final String COUNT_PREFIX = "SELECT COUNT(*) FROM (";
        private static final String COUNT_SUFFIX = ") t";
        private static final String COMMA_SPACE = ", ";
        private static final String _SPACE = " ";

        static final String PGP_DERIVED_DEPLOYMENTS_AGGREGATION =
                "SUM(pgpw.DeployYTDActual) AS DeployYTDActual, " +
                "SUM(pgpw.CurrentWeekDeploymentsCount) AS CurrentWeekDeploymentsCount, " +
                "SUM(pgpw.PreviousWeekDeploymentsCount) AS PreviousWeekDeploymentsCount, " +
                "SUM(pgpw.NextWeekForcastDeploymentsCount) AS NextWeekForcastDeploymentsCount, " +
                "SUM(pgpw.DeploymentsOpportunityAssessmentCount) AS DeploymentsOpportunityAssessmentCount, " +
                "SUM(pgpw.DeployYETarget) AS DeployYETarget, " +
                "SUM(pgpw.DeployYETargetVariance) AS DeployYETargetVariance, " +
                "SUM(pgpw.DeployYTDTarget) AS DeployYTDTarget, " +
                "SUM(pgpw.DeployYTDTargetVariance) AS DeployYTDTargetVariance ";

        static final String PGP_RETURN_NET_CNA_AGGREGATION =
                "SUM(ReturnYTDActual) AS ReturnYTDActual, " +
                "SUM(CurrentWeekReturnsCount) AS CurrentWeekReturnsCount, " +
                "SUM(PreviousWeekReturnsCount) AS PreviousWeekReturnsCount, " +
                "SUM(NextWeekForcastReturnsCount) AS NextWeekForcastReturnsCount, " +
                "SUM(ReturnsOpportunityAssessmentCount) AS ReturnsOpportunityAssessmentCount, " +
                "SUM(ReturnYETarget) AS ReturnYETarget, " +
                "SUM(ReturnYETargetVariance) AS ReturnYETargetVariance, " +
                "SUM(ReturnYTDTarget) AS ReturnYTDTarget, " +
                "SUM(ReturnYTDTargetVariance) AS ReturnYTDTargetVariance ";

        static final String PGP_WHERE =
                "WHERE %s = :Name " +
                "AND pgpw.State = :State " +
                "AND pgpw.IsCurrentWeekForPerformance = 1 " +
                "AND pgpw.ProgramYear = :ProgramYear " +
                "AND a.ServiceLevel IN (%s) ";

        static final String PGP_WHERE_REGION =
                "WHERE pgpw.State = :State " +
                "AND pgpw.IsCurrentWeekForPerformance = 1 " +
                "AND pgpw.ProgramYear = :ProgramYear " +
                "AND a.ServiceLevel IN (%s) ";

        static final String PGP_GROUP_BY =
                "GROUP BY " +
                "%s, " +
                "pgpw.State, " +
                "pgpw.ProviderGroupID, " +
                "pg.ProviderGroupName, " +
                "a.ServiceLevel ";

        static final String PGP_GROUP_BY_REGION =
                "GROUP BY " +
                "pgpw.State, " +
                "pgpw.ProviderGroupID, " +
                "pg.ProviderGroupName, " +
                "a.ServiceLevel ";

        static final String PGP_ORDER_BY_DERIVED_DEPLOYMENTS =
                "ORDER BY " +
                "DeployYTDTargetVariance, " +
                "pg.ProviderGroupName " +
                "OFFSET :Offset ROWS FETCH NEXT :Limit ROWS ONLY";

        static final String PGP_ORDER_BY_RETURNS_NET_CNA =
                "ORDER BY " +
                "ReturnYTDTargetVariance, " +
                "pg.ProviderGroupName " +
                "OFFSET :Offset ROWS FETCH NEXT :Limit ROWS ONLY";

        //pgpw.:Type (not region) && :Name AS :Type (region)
        static final String PGP_SELECT_LIST =
                "pgpw.State, pgpw.ProviderGroupId, pg.ProviderGroupName, a.ServiceLevel";

        static final String PGP_FROM =
                "FROM ProgPerf.ProviderGroupPerformanceWeekly pgpw " +
                "INNER JOIN ProgPerf.ProviderGroup pg " +
                "ON pgpw.ProviderGroupID = pg.ProviderGroupID " +
                "AND pgpw.State = pg.State " +
                "INNER JOIN ProgPerf.Accounts a " +
                "ON pgpw.ProviderGroupID = a.GroupID " +
                "AND pgpw.State = a.State ";

        private boolean isReturnsNetCNA = false;
        private boolean isDerivedDeployment = false;
        private boolean isByRegion = false;
        private boolean isByLobName = false;
        private boolean isByClientName = false;
        private boolean isCount = false;
        private boolean isAll = false;
        private boolean isHCA = false;
        private boolean isPSC = false;

        private Builder() {}

        Builder asReturnsNetCNA() {
            this.isReturnsNetCNA = true;
            return this;
        }

        Builder asDerivedDeployment() {
            this.isDerivedDeployment = true;
            return this;
        }

        Builder asByRegion() {
            this.isByRegion = true;
            return this;
        }

        Builder asByLobName() {
            this.isByLobName = true;
            return this;
        }

        Builder asByClientName() {
            this.isByClientName = true;
            return this;
        }

        Builder asByCount() {
            this.isCount = true;
            return this;
        }

        Builder asByAll() {
            this.isAll = true;
            return this;
        }

        Builder asByHSCA() {
            this.isHCA = true;
            return this;
        }

        Builder asByPSC() {
            this.isPSC = true;
            return this;
        }

        public String build() {
            StringBuilder sb = new StringBuilder();

            if (isCount) {
                sb.append(COUNT_PREFIX);
            }
            sb.append(getSelectClause())
                    .append(getFromClause())
                    .append(getWhereClause())
                    .append(getGroupByClause());
            if (isCount) {
                sb.append(COUNT_SUFFIX);
            } else {
                sb.append(getOrderByClause());
            }
            return sb.toString();
        }

        private String getSelectClause() {
            StringBuilder sb = new StringBuilder();
            sb.append("SELECT ");
            if (isByRegion) {
                sb.append(String.format(":Name AS %s, ", REGION));
            } else {
                sb.append(getLobOrClientColumn()).append(COMMA_SPACE);
            }
            if (isCount) {
                sb.append(PGP_SELECT_LIST).append(_SPACE);
            } else {
                sb.append(PGP_SELECT_LIST)
                        .append(COMMA_SPACE)
                        .append(isDerivedDeployment ? PGP_DERIVED_DEPLOYMENTS_AGGREGATION : PGP_RETURN_NET_CNA_AGGREGATION);
            }
            return sb.toString();
        }

        private String getFromClause() {
            return PGP_FROM;
        }

        private String getWhereClause() {
            StringBuilder sb = new StringBuilder();
            if (isByRegion) {
                sb.append(String.format(
                        PGP_WHERE_REGION,
                        getServiceLevel()
                ));
            } else {
                sb.append(String.format(
                        PGP_WHERE,
                        getLobOrClientColumn(),
                        getServiceLevel()
                ));
            }
            return sb.toString();
        }

        private String getGroupByClause() {
            StringBuilder sb = new StringBuilder();
            if (isByRegion) {
                sb.append(PGP_GROUP_BY_REGION);
            } else {
                sb.append(String.format(PGP_GROUP_BY, getLobOrClientColumn()));
            }
            return sb.toString();
        }

        private String getOrderByClause() {
            return isDerivedDeployment ? PGP_ORDER_BY_DERIVED_DEPLOYMENTS : PGP_ORDER_BY_RETURNS_NET_CNA;
        }

        private String getLobOrClientColumn() {
            return "pgpw." + (isByLobName ? LOB_NAME : CLIENT_NAME);
        }

        private String getServiceLevel() {
            if (isAll) {
                return ALL;
            } else if (isHCA) {
                return HCA;
            } else if (isPSC) {
                return PSC;
            } else {
                return "";
            }
        }

    }


}
