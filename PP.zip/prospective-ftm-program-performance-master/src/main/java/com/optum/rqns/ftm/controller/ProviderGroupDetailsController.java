package com.optum.rqns.ftm.controller;

import com.optum.rqns.ftm.customannotation.CustomApiResponse;
import com.optum.rqns.ftm.enums.TypeEnum;
import com.optum.rqns.ftm.model.UserInfo;
import com.optum.rqns.ftm.model.opportunities.providergrp.ClientLobFilterDetails;
import com.optum.rqns.ftm.response.ListResponse;
import com.optum.rqns.ftm.response.providergrp.MembershipChangeIhaToIoaResponse;
import com.optum.rqns.ftm.response.providergrp.ProviderGroupDetailsResponse;
import com.optum.rqns.ftm.service.providergrp.ProviderGroupDetailsService;
import com.optum.rqns.ftm.util.ProgramPerformanceUtil;
import com.optum.rqns.ftm.util.StargateStandardResponseUtilV2;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import reactor.core.publisher.Mono;

@Profile("rqnsFtmApi")
@RestController
@RequestMapping("/v1/provider-groups")
@Slf4j
@CustomApiResponse
public class ProviderGroupDetailsController {

    @Autowired
    StargateStandardResponseUtilV2<Object, Object> stargateStandardResponseUtilV2;

    @Autowired
    ProviderGroupDetailsService providerGroupDetailsService;


    @GetMapping("/{provider-group-id}")
    @ApiResponse(responseCode = "200", description = "Sucess Request",
            content = @Content(schema = @Schema(implementation = ProviderGroupDetailsResponse.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<ProviderGroupDetailsResponse> getProviderGroupDetails(
            @PathVariable("provider-group-id") String providerGroupId,
            @RequestParam String state,
            @RequestParam("service-level") String serviceLevel
    ) {
        log.debug("Getting Provider Group Details for the Given Details: {}, {},{}", providerGroupId,state,serviceLevel);

        return stargateStandardResponseUtilV2
                .generateStargateStandardResponse(
                        providerGroupDetailsService.getProviderGroupDetails(providerGroupId, state, serviceLevel)
                        , TypeEnum.MONO
                        , new ProviderGroupDetailsResponse())
                .cast(ProviderGroupDetailsResponse.class);
    }

    @GetMapping("/check-assigned-provider-group/{provider-group-id}")
    @ApiResponse(responseCode = "200", description = "Sucess Request",
            content = @Content(schema = @Schema(implementation = ListResponse.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<ListResponse> checkProviderGroupDetails(
            @PathVariable("provider-group-id") String providerGroupId,
            @RequestParam String state,
            @RequestParam("service-level") String serviceLevel,
            @RequestHeader("x-userDetails") String userDetailsJson
    ) {
        log.debug("Check Provider Group assigned to user for the Given Details: {}, {},{}", providerGroupId,state,serviceLevel);
        UserInfo userInfo = (UserInfo) ProgramPerformanceUtil.jsonToPojo(userDetailsJson, UserInfo.class);

        return stargateStandardResponseUtilV2
                .generateStargateStandardResponse(
                        providerGroupDetailsService.checkProviderGroupDetails(providerGroupId, state, serviceLevel,userInfo.getUuid())
                        , TypeEnum.MONO
                        , new ListResponse())
                .cast(ListResponse.class);
    }


    @PostMapping("/{provider-group-id}/{state}/membership-change-stats")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = MembershipChangeIhaToIoaResponse.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<MembershipChangeIhaToIoaResponse> getMembershipChangeStats(
            @PathVariable("provider-group-id") String providerGroupId,
            @PathVariable("state") String providerState,
            @RequestBody ClientLobFilterDetails clientLobFilterRequestBody
    ) {
        log.debug ("Get IHA to IOA Membership change stats for given provider: {}, state: {} and client/lob filters: {}"
                , providerGroupId, providerState, clientLobFilterRequestBody);

        return stargateStandardResponseUtilV2
                .generateStargateStandardResponse (
                        providerGroupDetailsService.getMembershipChangeStats (providerGroupId, providerState, clientLobFilterRequestBody),
                        TypeEnum.MONO, new MembershipChangeIhaToIoaResponse ())
                .cast (MembershipChangeIhaToIoaResponse.class);
    }
}
