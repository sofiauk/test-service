package com.optum.rqns.ftm.dto.goals.client.converter;

import com.optum.rqns.ftm.dto.goals.client.Region;
import com.optum.rqns.ftm.repository.goals.client.ClientGoalsReactiveRepositoryImpl;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;

public class RegionConverter implements Converter<Row, Region> {
    @Override
    public Region convert(Row rs) {
        return Region.builder()
                .regionId(rs.get(ClientGoalsReactiveRepositoryImpl.ColumnNames.REGIONID.getColumnName(), String.class))
                .regionName(rs.get(ClientGoalsReactiveRepositoryImpl.ColumnNames.REGIONNAME.getColumnName(), String.class))
                .clientId(rs.get(ClientGoalsReactiveRepositoryImpl.ColumnNames.CLIENTID.getColumnName(), Integer.class))
                .lobId(rs.get(ClientGoalsReactiveRepositoryImpl.ColumnNames.LOBID.getColumnName(), Integer.class))
                .isClientRegion(rs.get(ClientGoalsReactiveRepositoryImpl.ColumnNames.ISCLIENTREGION.getColumnName(), Boolean.class))
                .build();
    }
}
