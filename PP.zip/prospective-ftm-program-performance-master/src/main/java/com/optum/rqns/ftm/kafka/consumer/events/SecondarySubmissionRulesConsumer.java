package com.optum.rqns.ftm.kafka.consumer.events;

import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.repository.common.CommonRepositoryImpl;
import com.optum.rqns.ftm.service.rules.RuleServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.annotation.TopicPartition;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;
import org.springframework.context.annotation.Profile;

@Profile("rqnsFtmJobs-Rules")
@Component
@Slf4j
public class SecondarySubmissionRulesConsumer extends JobEventConsumer {

    public SecondarySubmissionRulesConsumer(final RuleServiceImpl ruleService, final CommonRepositoryImpl commonRepository) {
        super(ruleService, commonRepository);
    }

    @KafkaListener(topicPartitions = {@TopicPartition(topic = "${spring.gcpkafka.properties.topics.jobEvent}", partitions = {"7"})},
            containerFactory = "jobEventKafkaListenerContainerFactory", autoStartup = "true")
    public void onMessage(ConsumerRecord<String, JobEvent> record, Acknowledgment acknowledgment) {
        log.info("{} Begin Consumer SecondarySubmission: {}", super.generateTransactionId (record), record);
        processMessage(7, record, acknowledgment);
    }
    @Override
    public void handleMessage(String jobEvent){
        processMessage(jobEvent);
    }
}






