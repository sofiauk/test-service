package com.optum.rqns.ftm.dto.performance.providergrp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;

@Builder
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class AssignedProviderGroupPerformanceDTO {
    private Long deployYTDActual;
    private Long returnYTDActual;
    private Long returnedNetCNAYTDActual;
    private Long returnYTDTarget;
    private Long returnYETarget;
    private Integer hoursAgo;
    private Long rejects;
    private int programYear;
    private Long deployYTDTarget;
    private Long deployYETarget;
}