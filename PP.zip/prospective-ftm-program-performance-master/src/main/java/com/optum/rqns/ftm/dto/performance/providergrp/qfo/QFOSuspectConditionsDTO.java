package com.optum.rqns.ftm.dto.performance.providergrp.qfo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.time.LocalDateTime;

@Data
@Builder
@EqualsAndHashCode
@NoArgsConstructor
@ToString
@AllArgsConstructor
public class QFOSuspectConditionsDTO {
    Long totalPatients;
    Long suspectConditionsTotal;
    Long suspectConditionAssessedTotal;
    Long suspectDiagnosed;
    Long suspectUndiagnosed;
    Long suspectNotAssessed;
    Long mcaipFullyAssessed;
    Long mcaipTotalPatients;
    Long mcaipSuspectMedicalConditions;
    String conditionAssessedTarget;
    LocalDateTime updatedDate;
}
