package com.optum.rqns.ftm.dto.jobalerts;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class JobAlert {
    @NotNull
    private Integer id;
    private Integer jobExecutionHistoryId;
    @NotNull
    private String jobName;
    private String jobDescription;

    @NotNull
    private String status;
    private String createdBy;
    private LocalDateTime createdDate;
    private String modifiedBy;
    private LocalDateTime modifiedDate;
    private LocalDateTime jobStart;
    private LocalDateTime jobEnd;
    private LocalDateTime lastRunDate;
    private String errorMessage;
    private Integer affectedRows;
    private LocalDateTime lastSuccessfulRunDate;
    private String messageKey;
    private String message;
    private String jobEvent;
    private boolean isActive;

}