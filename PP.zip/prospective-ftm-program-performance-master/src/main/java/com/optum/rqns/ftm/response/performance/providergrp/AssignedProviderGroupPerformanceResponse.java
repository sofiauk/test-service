package com.optum.rqns.ftm.response.performance.providergrp;

import com.optum.rqns.ftm.model.performance.providergrp.AssignedProviderGroupPerformance;
import com.optum.rqns.ftm.wrapper.Meta;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class AssignedProviderGroupPerformanceResponse {
    private Meta meta;

    private List<AssignedProviderGroupPerformance> data;

    public AssignedProviderGroupPerformanceResponse() {
        this.meta = new Meta();
        this.data = new ArrayList<>();
    }
}
