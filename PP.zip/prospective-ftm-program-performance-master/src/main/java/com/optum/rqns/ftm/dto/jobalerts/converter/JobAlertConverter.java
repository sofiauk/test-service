package com.optum.rqns.ftm.dto.jobalerts.converter;

import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.dto.jobalerts.JobAlert;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;
import java.time.LocalDateTime;

public class JobAlertConverter extends JobAlert implements Converter<Row, JobAlert>, DTOWrapperTypeConverter {
    public JobAlertConverter() {
        //No Action needed here
    }

    @Override
    public JobAlert convert(Row row) {
        return JobAlert.builder()
                .id(row.get("JobID", Integer.class))
                .jobExecutionHistoryId(row.get("ID", Integer.class))
                .jobDescription(row.get("JobDescription", String.class))
                .status(row.get("Status", String.class))
                .jobName(row.get("JobName", String.class))
                .modifiedBy(row.get("ModifiedBy", String.class))
                .modifiedDate(row.get("ModifiedDate", LocalDateTime.class))
                .createdDate(row.get("CreatedDate", LocalDateTime.class))
                .errorMessage(row.get("ErrorMessage", String.class))
                .createdDate(row.get("CreatedDate", LocalDateTime.class))
                .affectedRows(row.get("AffectedRows", Integer.class))
                .createdBy(row.get("CreatedBy", String.class))
                .jobEnd(row.get("JobEnd", LocalDateTime.class))
                .jobStart(row.get("JobStart", LocalDateTime.class))
                .lastSuccessfulRunDate(row.get("LastSuccessfulRunDate", LocalDateTime.class))
                .lastRunDate(row.get("LastRunDate", LocalDateTime.class))
                .jobEvent(row.get("JobEvent",String.class))
                .message(row.get("Message",String.class))
                .messageKey(row.get("MessageKey",String.class))
                .isActive(row.get("IsActive",Boolean.class))
                .build();
    }


}
