package com.optum.rqns.ftm.constants;

public interface Constants {
    String DATE_FORMAT = "yyyy-MM-dd";
    int BATCH_SIZE = 10000;

    String CONSUMER_JOBEVENT = "jobEvent";
    String  CONSUMER_USERROLE = "userRole";
    String LINGER_MS_CONFIG = "120000";
    String REQUEST_TIMEOUT_MS_CONFIG = "120000";

    //Schema Registry SSL
    public static final String SCHEMA_REGISTRY_SSL_TRUSTSTORE_LOCATION = "schema.registry.ssl.truststore.location";
    public static final String SCHEMA_REGISTRY_SSL_TRUSTSTORE_PASSWORD = "schema.registry.ssl.truststore.password";
    public static final String SCHEMA_REGISTRY_SSL_KEYSTORE_LOCATION = "schema.registry.ssl.keystore.location";
    public static final String SCHEMA_REGISTRY_SSL_KEYSTORE_PASSWORD = "schema.registry.ssl.keystore.password";
    public static final String SCHEMA_REGISTRY_SSL_KEY_PASSWORD = "schema.registry.ssl.key.password";

    //GCP certs for application based - naming should be puma/ofc only because certs defined in same format in yml file
    public static final String PUMA = "puma";
    public static final String OFC = "ofc";

    public static final String BOOTSTRAP_SERVERS = "bootstrap.servers";
    public static final String CLIENT_ID = "client.id";
}
