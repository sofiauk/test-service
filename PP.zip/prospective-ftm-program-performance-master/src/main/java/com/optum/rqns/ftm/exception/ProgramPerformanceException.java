package com.optum.rqns.ftm.exception;

import lombok.Getter;
import org.springframework.http.HttpStatus;

@Getter
public class ProgramPerformanceException extends RuntimeException {
    private static final long serialVersionUID = 1905122041950251207L;

    private final HttpStatus httpStatus;
    private final ApiError apiError;
    private final Throwable customException;

    public ProgramPerformanceException(HttpStatus httpStatus, APIErrorCode code) {
        super(code.getDetail());
        this.httpStatus = httpStatus;
        this.customException = null;
        this.apiError = new ApiError(code.getCode(), code.getDetail(),code.getTitle());
    }

    public ProgramPerformanceException(APIErrorCode code) {
        super(code.getDetail());
        this.httpStatus=null;
        this.customException = null;
        this.apiError = new ApiError(code.getCode(), code.getDetail(),code.getTitle());
    }

    public ProgramPerformanceException(String message) {
        this.apiError = new ApiError(APIErrorCode.GENERIC.getCode(), message,message);
        this.customException = null;
        this.httpStatus=null;
    }

    public ProgramPerformanceException(APIErrorCode code,Throwable customException) {
        super(code.getDetail());
        this.httpStatus=null;
        this.customException = customException;
        this.apiError = new ApiError(code.getCode(), code.getDetail(),code.getTitle());
    }

    public ProgramPerformanceException(String message, Throwable customException) {
        this.apiError = new ApiError(APIErrorCode.GENERIC.getCode(), message,message);
        this.customException = customException;
        this.httpStatus=null;
    }
}