package com.optum.rqns.ftm.dto.fieldleader;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Builder
public class RiskQualityGapsSummaryDTO {
    private Long qualityGaps;
    private Long annualCareVisits;
    private Long suspectConditions;
    private LocalDateTime lastUpdatedDate;
}
