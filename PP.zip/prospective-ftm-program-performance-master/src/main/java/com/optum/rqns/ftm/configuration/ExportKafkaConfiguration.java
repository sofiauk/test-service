package com.optum.rqns.ftm.configuration;

import com.optum.rqns.common.export.model.ExportRequestPayload;
import com.optum.rqns.ftm.constants.Constants;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.KafkaListenerContainerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.listener.ConcurrentMessageListenerContainer;
import org.springframework.kafka.support.serializer.JsonDeserializer;


@Configuration
@Slf4j
public class ExportKafkaConfiguration extends GCPBaseKafkaConfiguration{

    @Bean
    public KafkaTemplate<String, ExportRequestPayload> exportRequestkafkaTemplate() {
        return new KafkaTemplate<>(gcpProducerFactoryWithKeyStringAndValueJsonSerializer("exportRequest", Constants.OFC));
    }

    @Bean
    @ConditionalOnProperty(
            value="exportRequest.role",
            havingValue = "Consumer",
            matchIfMissing = false)
    public KafkaListenerContainerFactory<ConcurrentMessageListenerContainer<String, ExportRequestPayload>> exportRequestConsumerKafkaListenerContainerFactory() {
        return gcpCreateContainerFactory( new StringDeserializer(), new JsonDeserializer(ExportRequestPayload.class),
                 gcpKafkaProperties.getProperties().get("topics.exportRequest"),
                com.optum.rqns.common.export.constants.Constants.CONSUMER_EXPORT, Constants.OFC);
    }

}