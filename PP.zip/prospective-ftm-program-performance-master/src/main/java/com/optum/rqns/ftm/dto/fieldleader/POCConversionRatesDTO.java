package com.optum.rqns.ftm.dto.fieldleader;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class POCConversionRatesDTO {

    private List<POCConversionRates> nationalConversionRates;
    private List<POCConversionRates> myTeamConversionRates;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class POCConversionRates {
        private boolean currentMonth;
        private Integer existingGroups;
        private Integer existingTotalGroups;
        private Integer newGroups;
        private Integer newTotalGroups;
        private LocalDateTime updatedDate;
    }
}
