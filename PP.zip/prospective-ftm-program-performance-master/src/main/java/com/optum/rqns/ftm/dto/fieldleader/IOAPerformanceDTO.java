package com.optum.rqns.ftm.dto.fieldleader;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class IOAPerformanceDTO {

    private List<IOAPerformanceValue> nationalDerivedDeployments;
    private List<IOAPerformanceValue> nationalReturnedAssessments;
    private List<IOAPerformanceValue> nationalCompletedAssessments;
    private List<IOAPerformanceValue> myTeamDerivedDeployments;
    private List<IOAPerformanceValue> myTeamReturnedAssessments;
    private List<IOAPerformanceValue> myTeamCompletedAssessments;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class IOAPerformanceValue {
        private LocalDateTime updatedDate;
        private LocalDate startDate;
        private LocalDate endDate;
        private Integer goalCount;
        private Integer actualGoalCount;
        private Integer actualPerfCount;
        private Integer volumeVarianceCount;
        private Double volumeVariancePercent;
        private Integer deployableMembersCount;
    }
}
