package com.optum.rqns.ftm.dto.goals.client;

import com.optum.rqns.ftm.model.goals.client.ClientLobSnapshot;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Getter
@Builder
@AllArgsConstructor
@ToString
public class ClientGoalsSnapshotDTO {
    private ClientLobSnapshot clientLobSnapshot;
    private String clientName;
    private long clientId;
    private int programYear;
}
