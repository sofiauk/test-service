package com.optum.rqns.ftm.dto.performance.providergrp.converter.qfo;

import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.dto.performance.providergrp.qfo.QFOSuspectConditionsDTO;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;

import java.time.LocalDateTime;

public class QFOSuspectConditionsDTOConverter implements Converter<Row, QFOSuspectConditionsDTO>, DTOWrapperTypeConverter {

    @Override
    public QFOSuspectConditionsDTO convert(Row row) {
        return QFOSuspectConditionsDTO.builder()
                .totalPatients(getLongValue(row,"TotalPatients"))
                .suspectConditionsTotal(getLongValue(row,"SuspectConditionsTotal"))
                .suspectConditionAssessedTotal(getLongValue(row,"SuspectConditionAssessedTotal"))
                .suspectDiagnosed(getLongValue(row,"SuspectDiagnosed"))
                .suspectUndiagnosed(getLongValue(row,"SuspectUndiagnosed"))
                .suspectNotAssessed(getLongValue(row,"SuspectNotAssessed"))
                .mcaipFullyAssessed(getLongValue(row,"McaipFullyAssessed"))
                .mcaipTotalPatients(getLongValue(row,"McaipTotalPatients"))
                .mcaipSuspectMedicalConditions(getLongValue(row,"McaipSuspectMedicalConditions"))
                .conditionAssessedTarget(row.get("ConditionAssessedTarget",String.class))
                .updatedDate(row.get("UpdatedDate", LocalDateTime.class))
                .build();
    }

}
