package com.optum.rqns.ftm.repository.common;


import com.optum.rqns.ftm.dto.job_configuration.CategoryUpdatedDetailDTO;
import com.optum.rqns.ftm.dto.job_configuration.JobConfigurationDTO;
import com.optum.rqns.ftm.dto.job_configuration.JobConfigurationRequestBody;
import com.optum.rqns.ftm.dto.job_configuration.PafOverAllStatusDetailDTO;
import com.optum.rqns.ftm.dto.processor.providergrp.JobRunConfigurationDTO;
import com.optum.rqns.ftm.dto.processor.providergrp.ProgramYearCalendarDTO;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.Status;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Map;

public interface CommonRepository {
    Mono<Long> updateBatchQueries(List<String> updateQueries);

    Mono<Integer> upsertJobRunConfiguration(JobRunConfigurationDTO jobRunConfigurationDTO);

    int getBatchSize();

    Mono<Boolean> getJobIsActiveByName(String jobName);

    Mono<Integer> getJobIdByName(String jobName);

    Mono<Integer> updateJobExecutionHistoryAsJobStart(Integer jobID, String correlationKey, String jobEvent, String errorMessage);

//    Mono<Integer> updateJobExecutionHistoryAsJobEnd(Integer jobExecutionId, Status status, String errorMessage, String message);

    Mono<Integer> updateJobExecutionHistoryAsJobEnd(Integer jobExecutionId, Status status, String errorMessage, String message, Boolean updateAffectedRowsOnSuccess, Long rowsAffected);

    Mono<Integer> getJobExecutionHistoryByMessageKey(Integer jobId, String messageKey);

    Mono<Integer> getJobExecutionHistoryByTime (Integer jobId, Integer thresholdInMinutes);

    Mono<Integer> updateAffectedRowsCountForJob(String jobName, Long affectedRowCount);

    Flux<JobConfigurationDTO> getAllJobConfigurations();

    Mono<JobConfigurationDTO> getJobConfigurationByName(JobName jobName);

    Mono<Integer> jobConfigurationUpdates(JobConfigurationRequestBody jobConfiguration);

    Flux<PafOverAllStatusDetailDTO> getOverAllStatusDetails(int programYear);

    Flux<CategoryUpdatedDetailDTO> getUpdatedCategoryDetails(int programYear);

    Mono<Map<String,String>> getEligibleMemberCountInputMap();

    Mono<String> getCascadedJobs(String jobName);

    Mono<String> getJobFrequency(String jobName);

    Mono<Integer> updateRegionValues(ProgramYearCalendarDTO programYearCalendarDTO,String table);

    Flux<String> getClients();

    Mono<String> getValueFromConfiguration(String key);


}
