package com.optum.rqns.ftm.model.personnelhierarchy;

import lombok.ToString;
import lombok.Getter;
import lombok.Setter;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@ToString
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PersonnelHierarchy {
    private String uuid;
    private String firstName;
    private String lastName;
    private String role;
    private boolean isActive;
    private Integer personnelHierarchyId;
    private Integer parentId;
}
