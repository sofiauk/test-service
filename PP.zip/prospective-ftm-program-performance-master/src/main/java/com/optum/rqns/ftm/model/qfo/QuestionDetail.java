package com.optum.rqns.ftm.model.qfo;

import lombok.Data;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class QuestionDetail {
    private String qname;
    private String description;
    private Integer value;
}
