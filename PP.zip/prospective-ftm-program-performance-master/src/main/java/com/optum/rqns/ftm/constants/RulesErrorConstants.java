package com.optum.rqns.ftm.constants;

public final class RulesErrorConstants {
    private RulesErrorConstants(){}

    public static final String DATA_ACCESS_EXCEPTION = "Data Access Exception";
    public static final String EMPTY_DATA_EXCEPTION = "Empty Data Exception";
    public static final String PUBLISHING_DATA_EXCEPTION = "Publishing Data Exception";


}
