package com.optum.rqns.ftm.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum OwnerType {
    HCA("HCA"),
    PSC("PSC")
    ;
    private String value;
}
