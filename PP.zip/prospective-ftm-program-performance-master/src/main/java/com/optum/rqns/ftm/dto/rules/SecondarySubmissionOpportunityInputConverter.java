package com.optum.rqns.ftm.dto.rules;

import com.optum.rqns.ftm.model.rules.OutlierOpportunityInput;
import com.optum.rqns.ftm.model.rules.SecondarySubmissionOpportunityInput;
import com.optum.rqns.ftm.repository.rules.RuleRepositoryImpl;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;

public class SecondarySubmissionOpportunityInputConverter implements Converter<Row, SecondarySubmissionOpportunityInput> {
    @Override
    public SecondarySubmissionOpportunityInput convert(Row rs) {
        return SecondarySubmissionOpportunityInput.builder()
                .projectYear(rs.get(RuleRepositoryImpl.ColumnNames.PROJECT_YEAR.getColumnName(),Integer.class))
                .providerGroupId(rs.get(RuleRepositoryImpl.ColumnNames.PROVIDERGROUPID.getColumnName(),String.class))
                .providerState(rs.get(RuleRepositoryImpl.ColumnNames.PROVIDER_STATE.getColumnName(),String.class))
                .serviceLevel(rs.get(RuleRepositoryImpl.ColumnNames.SERVICELEVEL.getColumnName(),String.class))
                .providerGroupName(rs.get(RuleRepositoryImpl.ColumnNames.PROVIDERGROUPNAME.getColumnName(),String.class))
                .client(rs.get(RuleRepositoryImpl.ColumnNames.CLIENT.getColumnName(),String.class))
                .lobName(rs.get(RuleRepositoryImpl.ColumnNames.LOB.getColumnName(),String.class))
                .isSecondarySubmissionEligible(rs.get(RuleRepositoryImpl.ColumnNames.ISSECONDARYSUBMISSIONELIGIBLE.getColumnName(),String.class))
                .chartID(rs.get(RuleRepositoryImpl.ColumnNames.CHARTID.getColumnName(),String.class))
                .build();
    }
}