package com.optum.rqns.ftm.enums;

public enum LeaderPerformanceType {
    CURRENT("Current"), IOA_YTD("IOA-YTD");
    private String value;

    private LeaderPerformanceType(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
