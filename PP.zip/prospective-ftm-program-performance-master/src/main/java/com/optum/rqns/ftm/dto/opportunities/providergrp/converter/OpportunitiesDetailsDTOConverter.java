package com.optum.rqns.ftm.dto.opportunities.providergrp.converter;

import com.optum.rqns.ftm.constants.ProviderGroupConstants;
import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.dto.opportunities.providergrp.OpportunitiesDetailsDTO;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;

import java.time.LocalDate;

public class OpportunitiesDetailsDTOConverter implements Converter<Row, OpportunitiesDetailsDTO>,DTOWrapperTypeConverter {
    @Override
    public OpportunitiesDetailsDTO convert(Row row) {
        return OpportunitiesDetailsDTO.builder()
                .masterOpportunityType(row.get(ProviderGroupConstants.MASTER_OPPORTUNITY_TYPE,String.class))
                .masterOpportunityTypePosition(getPrimitiveIntegerValue(row, ProviderGroupConstants.MASTER_OPPORTUNITY_TYPE_POSITION))
                .programYear(getPrimitiveIntegerValue(row, ProviderGroupConstants.PROGRAM_YEAR))
                .providerGroupID(row.get(ProviderGroupConstants.OPPORTUNITY_PROVIDER_GROUP_ID,String.class))
                .state(row.get(ProviderGroupConstants.OPPORTUNITY_STATE,String.class))
                .totalAssessmentsCount(getPrimitiveIntegerValue(row, ProviderGroupConstants.TOTAL_ASSESSMENTS_COUNT))
                .totalClientsCount(getPrimitiveIntegerValue(row, ProviderGroupConstants.TOTAL_CLIENTS_COUNT))
                .totalGapsCount(getPrimitiveIntegerValue(row, ProviderGroupConstants.TOTAL_GAPS_COUNT))
                .assessmentCount(getPrimitiveIntegerValue(row, ProviderGroupConstants.ASSESSMENT_COUNT))
                .clientName(row.get(ProviderGroupConstants.CLIENT_NAME,String.class))
                .deploymentCount(getPrimitiveIntegerValue(row, ProviderGroupConstants.DEPLOYMENT_COUNT))
                .gapCount(getPrimitiveIntegerValue(row, ProviderGroupConstants.GAP_COUNT))
                .opportunitySubType(row.get(ProviderGroupConstants.OPPORTUNITY_SUB_TYPE_COLUMN,String.class))
                .opportunitySubTypePosition(getPrimitiveIntegerValue(row, ProviderGroupConstants.OPPORTUNITY_SUB_TYPE_POSITION))
                .opportunityType(row.get(ProviderGroupConstants.OPPORTUNITY_TYPE_COLUMN,String.class))
                .opportunityTypePosition(getPrimitiveIntegerValue(row, ProviderGroupConstants.OPPORTUNITY_TYPE_POSITION))
                .displayText(row.get(ProviderGroupConstants.DISPLAY_TEXT,String.class))
                .opportunityLastUpdatedDate(row.get(ProviderGroupConstants.OPPORTUNITY_LAST_UPDATED_DATE, LocalDate.class))
                .build();
    }
}
