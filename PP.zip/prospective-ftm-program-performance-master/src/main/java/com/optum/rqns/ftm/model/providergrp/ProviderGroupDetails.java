package com.optum.rqns.ftm.model.providergrp;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.optum.rqns.ftm.constants.ProviderGroupConstants;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
public class ProviderGroupDetails {
    private String providerGroupName;
    private String providerGroupId;
    private String state;
    private String serviceLevel;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = ProviderGroupConstants.PERFORMANCE_DATE_FORMAT)
    private LocalDateTime lastTouchPoint;
    private String tinId;
    private String hcaOwner;
    private String pscOwner;
    private Boolean engagementOnshoreFlag;
    private Boolean canShowPSCOwner;

}