package com.optum.rqns.ftm.dto.qfo.converter;

import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;
import com.optum.rqns.ftm.dto.qfo.PEQuestionConfigurationDTO;

public class PEQuestionConfigurationDTOConverter implements Converter<Row, PEQuestionConfigurationDTO>, DTOWrapperTypeConverter {

    @Override
    public PEQuestionConfigurationDTO convert(Row row){
        return PEQuestionConfigurationDTO.builder()
                .name(row.get("NAME",String.class))
                .key(row.get("KEY",String.class))
                .value(row.get("VALUE",String.class))
                .build();
    }
}
