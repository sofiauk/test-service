package com.optum.rqns.ftm.repository.member;

import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

import java.util.Map;

@Repository
public interface MemberRepository {
    /**
     *
     * @param jobEvent
     * @param inputMap
     * @return
     */
    Mono<Integer> updateEligibleMemberCount(JobEvent jobEvent, Map<String, String> inputMap);

    Mono<Integer> upsertBaseline(Map<String, String> inputMap);

    Mono<Integer> getTotalRecordsCountForNotDeletedPGPWeekly(String programYear);

    Mono<Integer> updateEligibleMemDeploymentPreferredCountForPGPWeekly(Integer batchOffset, Integer batchSize, Map<String, String> inputMap);
}
