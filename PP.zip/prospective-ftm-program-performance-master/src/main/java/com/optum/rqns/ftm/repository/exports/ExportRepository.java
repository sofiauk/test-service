package com.optum.rqns.ftm.repository.exports;


import com.optum.rqns.ftm.dto.opportunities.providergrp.exports.ExportRequestParamsDTO;
import com.optum.rqns.ftm.enums.DocumentType;
import com.optum.rqns.ftm.enums.ExportStatus;
import com.optum.rqns.ftm.enums.ProcessSubType;
import com.optum.rqns.ftm.enums.ProcessType;
import com.optum.rqns.ftm.model.UserInfo;
import com.optum.rqns.ftm.model.export.ExportDetail;
import com.optum.rqns.ftm.model.export.ExportNotification;
import com.optum.rqns.ftm.model.export.ExportTransaction;
import com.optum.rqns.ftm.model.opportunities.providergrp.MemberAssessment;
import com.optum.rqns.ftm.request.exports.ExportsRequestPayload;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface ExportRepository {
    Flux<ExportDetail> getExports(String traceId, String uuid, ProcessType exportType, ProcessSubType processSubType, DocumentType documentType);

    Mono<ExportTransaction> setExportStatus(String uuid, String traceId, long transactionId, ExportStatus exportStatus);

    Flux<ExportNotification> getExportNotifications(String uuid, String traceId, ExportStatus exportStatus);

    Mono<ExportTransaction> deleteExportedFile(String traceId, String uuid, long transactionId);

    Mono<ExportTransaction> updateExportIsReadStatus(String uuid, String traceId, ProcessType processType, ProcessSubType processSubType, ExportStatus exportStatus);

    Mono<ExportDetail> insertExportstRequest(ExportsRequestPayload exportsRequestPayload, MemberAssessment exportsRequest, UserInfo userDetailsJson, String requestId, String processName);

    Mono<Integer> getTransactionIdByUUIDAndFileName(String fileName, String uuid);

    /**
     *
     * @param exportRequestParams  @see{@link ExportRequestParamsDTO}
     * @param isSuccess boolean value decides whether to update status as success or failure
     * @return returns number of records updated
     */
    Mono<Integer> updateExportRequestTable(ExportRequestParamsDTO exportRequestParams, boolean isSuccess);

}
