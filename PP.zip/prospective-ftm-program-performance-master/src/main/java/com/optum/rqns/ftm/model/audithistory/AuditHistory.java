package com.optum.rqns.ftm.model.audithistory;

import lombok.Builder;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.io.Serializable;
import java.time.LocalDateTime;

@Builder
@Data
@Table("ProgPerf.AuditHistory")
public class AuditHistory implements Serializable {
    @Id
    Long id;

    @Column("TableName")
    String tableName;

    @Column("FieldName")
    String fieldName;

    @Column("OldValue")
    String oldValue;

    @Column("NewValue")
    String newValue;

    @Column("ByWhom")
    String byWhom;

    @Column("Reason")
    String reason;

    @Column("RecordId")
    Long recordId;

    @Column("UpdatedDate")
    LocalDateTime updatedDate;

}
