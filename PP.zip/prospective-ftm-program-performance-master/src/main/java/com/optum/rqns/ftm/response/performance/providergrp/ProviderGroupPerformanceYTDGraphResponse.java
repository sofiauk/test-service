package com.optum.rqns.ftm.response.performance.providergrp;

import com.optum.rqns.ftm.dto.performance.providergrp.ProviderGroupPerformanceYTDGraphDTO;
import com.optum.rqns.ftm.model.performance.providergrp.AssignedProviderGroupPerformance;
import com.optum.rqns.ftm.wrapper.Meta;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
@AllArgsConstructor
@Builder
public class ProviderGroupPerformanceYTDGraphResponse {

    private Meta meta;

    private List<ProviderGroupPerformanceYTDGraphDTO> data;

    public ProviderGroupPerformanceYTDGraphResponse() {
        this.meta = new Meta();
        this.data = new ArrayList<>();
    }
}
