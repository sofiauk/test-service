package com.optum.rqns.ftm.repository.qfo;

import com.optum.rqns.ftm.constants.ProviderGroupConstants;
import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.dto.performance.providergrp.qfo.ProviderGroupPerformanceDetailsDTO;
import com.optum.rqns.ftm.dto.performance.providergrp.qfo.QFOProviderGroupPerformanceDetailsDTO;
import com.optum.rqns.ftm.dto.performance.providergrp.qfo.QFOSuspectConditionsDTO;
import com.optum.rqns.ftm.dto.qfo.QFOGroupStarRatingDTO;
import com.optum.rqns.ftm.dto.qfo.QFOPatientsCoveredDTO;
import com.optum.rqns.ftm.model.opportunities.exports.CategoryMasterConfigDTO;
import com.optum.rqns.ftm.model.qfo.StarRating;
import com.optum.rqns.ftm.model.qfo.SuspectConditionTotal;
import com.optum.rqns.ftm.util.QueryUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Repository
public class ProviderGroupPerformanceDetailsRepositoryImpl implements ProviderGroupPerformanceDetailsRepository, DTOWrapperTypeConverter {

    @Autowired
    QueryUtil queryUtil;

    private final DatabaseClient client;
    private static final String SELECT = "SELECT ";
    private static final String WHERE = "WHERE ";
    private static final String FROM = "FROM ";
    private static final String OPEN_PARENTHESIS = "( ";

    public static final String PERFORMANCE_QUERY= "with aggregratePerformance as ( " +
            SELECT  +
            " pgp.ProviderGroupId as ProviderGroupId, " +
            " SUM(pgp.TotalPatients) as TotalPatients, " +
            " sum(pgp.MapCpiEligiblePatients) as MapCpiEligiblePatients, " +
            " SUM(pgp.MapCpiAnnualCareVisits) as MapCpiAnnualCareVisits, " +
            " SUM(pgp.SuspectConditionsTotal) as SuspectConditionsTotal, " +
            " SUM(pgp.SuspectConditionsAssessedTotal) as SuspectConditionAssessedTotal, " +
            " SUM(pgp.SuspectConditionsAssessedDiagnosed) as SuspectDiagnosed, " +
            " SUM(pgp.SuspectConditionsAssessedUndiagnosed) as SuspectUndiagnosed, " +
            " SUM(pgp.SuspectConditionsNotAssessed) as SuspectNotAssessed, " +
            " SUM(pgp.McaipPatientsFullyAssessed) as McaipFullyAssessed, " +
            " SUM(pgp.McaipSuspectMedicalConditions) as McaipSuspectMedicalConditions, " +
            " SUM(pgp.McaipTotalPatients) as McaipTotalPatients, " +
            " max(pgp.UpdatedDate) as UpdatedDate, " +
            " max(pgp.MapCpiLastUpdated) as MapCpiLastUpdated, " +
            " max(pgp.McaipLastUpdated) as McaipLastUpdated, " +
            " pgp.ProgramYear as ProgramYear , " +
            " pgp.DurationValue as DurationValue  " +
            FROM +
            " ProgPerf.ProviderGroupPerformanceDetails pgp " +
            " where  " +
            " pgp.ProgramYear = :programYear " +
            " and pgp.ProviderGroupId = :PROVIDERGROUPID " +
            " AND pgp.DurationValue = ( " +
             SELECT  +
            "  TOP 1 DurationValue " +
             FROM  +
            "  ProgPerf.CommonProgramYearCalender WITH (NOLOCK) " +
            " where " +
            "  DurationType = 'MONTH' " +
            "  AND StartDate <= ( " +
              SELECT  +
            "   CAST( getUTCDate() AS Date )) " +
            "   AND EndDate >= ( " +
              SELECT  +
            "    CAST( getUTCDate() AS Date )) " +
            "    and ProgramYear = :programYear " +
            "    and TeamType = 'QFO' ) " +
            " group by  " +
            "  pgp.ProviderGroupId , " +
            "  pgp.ProgramYear , " +
            "  pgp.DurationValue  " +
            ")  " +
            SELECT  +
            " apgp.*, " +
            " srgp.OverallRating as OverAllStartRating, " +
            " srgp.MapcpiRating as MapCpiStartRating, " +
            " srgp.PartDRating as MapCpiPartDRating  " +
            FROM +
            " aggregratePerformance apgp " +
            " inner join ProgPerf.StarRatingGlidePath srgp " +
            " on " +
            " srgp.ProgramYear = apgp.ProgramYear " +
            " and srgp.GroupId = apgp.ProviderGroupId  " +
            " and srgp.RatingType = 'GROUP' " +
            " and srgp.DurationValue =  apgp.DurationValue ";

    private static final String FETCH_CATEGORY_MASTER_CONFIGURATION ="SELECT distinct Name, [Key], Value from ProgPerf.CategoryMasterConfiguration where Name in (%s) and ProgramYear in (%s) ";

    private static final String FETCH_PROVIDERGROUP_DETAILS=
            "with temptable as ( " +
                    SELECT  +
                    "pgp.ProviderGroupId as ProviderGroupId, " +
                    "SUM(pgp.TotalPatients) as TotalPatients, " +
                    "SUM(pgp.MapCpiEligiblePatients) as MapCpiEligiblePatients, " +
                    "SUM(pgp.MapCpiAnnualCareVisits) as MapCpiAnnualCareVisits, " +
                    "MAX(pgp.MapCpiLastUpdated) as MapCpiLastUpdated, " +
                    "SUM(pgp.SuspectConditionsTotal) as SuspectConditionsTotal, " +
                    "SUM(pgp.SuspectConditionsAssessedTotal) as SuspectConditionsAssessedTotal, " +
                    "SUM(pgp.SuspectConditionsAssessedDiagnosed) as SuspectConditionsAssessedDiagnosed, " +
                    "SUM(pgp.SuspectConditionsAssessedUndiagnosed) as SuspectConditionsAssessedUndiagnosed, " +
                    "SUM(pgp.SuspectConditionsNotAssessed) as SuspectConditionsNotAssessed, " +
                    "SUM(pgp.McaipPatientsFullyAssessed) as McaipPatientsFullyAssessed, " +
                    "SUM(pgp.McaipSuspectMedicalConditions) as McaipSuspectMedicalConditions, " +
                    "MAX(pgp.McaipLastUpdated) as McaipLastUpdated, " +
                    "SUM(pgp.McaipTotalPatients) as McaipTotalPatients, " +
                    "pgp.ProgramYear as ProgramYear, " +
                    "pgp.DurationValue as DurationValue, " +
                    "MAX(pgp.UpdatedDate) as UpdatedDate " +
                    FROM  +
                    "ProgPerf.ProviderGroupPerformanceDetails pgp " +
                    WHERE +
                    "pgp.providergroupid = :PROVIDERGROUPID " +
                    "and pgp.ProgramYear =:programYear " +
                    "and pgp.TeamType = 'QFO' " +
                    "group by " +
                    "pgp.ProgramYear, " +
                    "pgp.DurationValue,pgp.ProviderGroupId) " +
                    SELECT  +
                    "t.*, " +
                    "cpyc.StartDate, " +
                    "cpyc.[Month], " +
                    "pcmc.[MA-PCPi_Star_Rating_Target], " +
                    "pcmc.[Overall_Star_Rating_Target], " +
                    "pcmc.[Annual_Care_Visits_Target], " +
                    "pcmc.[Suspect_Conditions_Target], " +
                    "pcmc.[Part_D_Star_Rating_Target], " +
                    "pcmc.[Assessed_And_Unable_To_Diagnose_Target], " +
                    "srgp.MapcpiRating as MapCpiStarRating, " +
                    "srgp.PartDRating as MapCpiPartDStarRating, " +
                    "srgp.OverallRating as OverAllStarRating from temptable t " +
                    "INNER JOIN ProgPerf.StarRatingGlidePath srgp ON " +
                    "srgp.ProgramYear = t.ProgramYear " +
                    "and srgp.GroupId = t.ProviderGroupId " +
                    "and srgp.RatingType = 'GROUP' " +
                    "and srgp.DurationValue = t.DurationValue " +
                    "right join ProgPerf.CommonProgramYearCalender cpyc on " +
                    "cpyc.ProgramYear = t.ProgramYear " +
                    "and cpyc.DurationValue = t.DurationValue " +
                    "left join ( " +
                    SELECT +
                    "* " +
                    FROM  +
                    "( " +
                    SELECT +
                    "distinct [Key], " +
                    "Value " +
                    FROM +
                    "ProgPerf.CategoryMasterConfiguration " +
                    WHERE +
                    "Name in ('QFO_RatingTargets') " +
                    "and ProgramYear =:programYear ) as cmc PIVOT ( max(value) FOR [Key] IN (Annual_Care_Visits_Target, \"MA-PCPi_Star_Rating_Target\", Overall_Star_Rating_Target, Part_D_Star_Rating_Target, Suspect_Conditions_Target, Assessed_And_Unable_To_Diagnose_Target) ) AS cc) as pcmc on " +
                    "1 = 1 " +
                    WHERE +
                    "cpyc.DurationType = 'MONTH' " +
                    "and cpyc.programyear = :programYear " +
                    "order by " +
                    "cpyc.StartDate; " +
                    "" ;

    private static final String FETCH_QFO_SUSPECT_CONDITIONS =
            SELECT +
            "   t.*, " +
            "   ( SELECT mc.Value " +
            "       FROM ProgPerf.CategoryMasterConfiguration mc " +
            "       WHERE mc.Name = 'QFO_RatingTargets' " +
            "       AND mc.[Key] = 'Suspect_Conditions_Target' " +
            "       AND mc.ProgramYear = :programYear " +
            "   ) AS ConditionAssessedTarget " +
            "FROM ( " +
                SELECT +
            "       SUM(TotalPatients) AS TotalPatients, " +
            "       SUM(SuspectConditionsTotal) as SuspectConditionsTotal, " +
            "       SUM(SuspectConditionsAssessedTotal) AS SuspectConditionAssessedTotal, " +
            "       SUM(SuspectConditionsAssessedDiagnosed) AS SuspectDiagnosed, " +
            "       SUM(SuspectConditionsAssessedUndiagnosed) AS SuspectUndiagnosed, " +
            "       SUM(SuspectConditionsNotAssessed) AS SuspectNotAssessed, " +
            "       SUM(McaipPatientsFullyAssessed) AS McaipFullyAssessed, " +
            "       SUM(McaipTotalPatients) AS McaipTotalPatients, " +
            "       SUM(McaipSuspectMedicalConditions) AS McaipSuspectMedicalConditions, " +
            "       MAX(UpdatedDate) AS UpdatedDate " +
            "   FROM ProgPerf.ProviderGroupPerformanceDetails pgpd " +
            "   WHERE ProgramYear = :programYear " +
            "   AND TeamType = :teamType " +
            "   AND DurationValue = CONCAT(:programYear, '_', LEFT(DATENAME(MONTH, GETDATE()), 3)) " +
            "   AND ProviderGroupId IN ( " +
            "       SELECT DISTINCT ugo.GroupId " +
            "       FROM ProgPerf.UHCProviderGroupOwnership ugo " +
            "       WHERE ugo.OwnerUUID = :UUID " +
            "       AND IsDeleted = 0 " +
            "   ) " +
            ") t";

    private static final String FETCH_QFO_STAR_RATINGS =
            SELECT +
                    "    SUBSTRING(DurationValue, 6, 3) AS [Month], " +
                    "    ProgramYear, " +
                    "    AVG(CAST(OverallRating AS FLOAT)) AS OverallStarRating, " +
                    "    AVG(CAST(MapCpiRating AS FLOAT)) AS MapCpiStarRating, " +
                    "    MAX(UpdatedDate) AS UpdatedDate " +
                    "FROM ProgPerf.StarRatingGlidePath " +
                    "WHERE ProgramYear = :programYear " +
                    "AND DurationValue IS NOT NULL " +
                    "AND GroupId IN ( " +
                    "    SELECT  DISTINCT ugo.GroupId " +
                    "    FROM ProgPerf.UHCProviderGroupOwnership ugo  " +
                    "    WHERE ugo.OwnerUUID = :uuid " +
                    "    AND IsDeleted = 0  " +
                    ") " +
                    "GROUP BY DurationValue, ProgramYear;";

    private static final String FETCH_QFO_SUSPECT_CONDITION_TOTALS =
            SELECT + "pgpd.*, ( " +
                SELECT + " mc.Value " +
                FROM + " ProgPerf.CategoryMasterConfiguration mc " +
                WHERE + " mc.Name = 'QFO_RatingTargets' " +
                            "AND mc.[Key] = 'Suspect_Conditions_Target' "+
                            "AND mc.ProgramYear = :programYear) AS TargetSuspect, ( " +
                SELECT + " mc.Value " +
                FROM + " ProgPerf.CategoryMasterConfiguration mc " +
                WHERE + " mc.Name = 'QFO_RatingTargets' " +
                            "AND mc.[Key] = 'Assessed_And_Unable_To_Diagnose_Target' " +
                            "AND mc.ProgramYear = :programYear) AS SuspectUndiagnosedTarget " +
            FROM + " ( " +
            SELECT + " SUBSTRING(pgpd.DurationValue, 6, 3) AS [Month], " +
                "pgpd.ProgramYear, " +
                "SUM(pgpd.SuspectConditionsTotal) as SuspectConditionsTotal, " +
                "SUM(pgpd.SuspectConditionsAssessedDiagnosed) AS SuspectConditionsAssessedDiagnosed, " +
                "SUM(pgpd.SuspectConditionsAssessedUndiagnosed) AS SuspectConditionsAssessedUndiagnosed, " +
                "MAX(pgpd.UpdatedDate) AS UpdatedDate " +
            FROM + " ProgPerf.ProviderGroupPerformanceDetails pgpd " +
            WHERE + " ProgramYear = :programYear " +
                "AND DurationValue IS NOT NULL " +
                "AND TeamType = 'QFO' " +
                "AND ProviderGroupId IN (" +
                "   SELECT DISTINCT ugo.GroupId " +
                "   FROM ProgPerf.UHCProviderGroupOwnership ugo " +
                "   WHERE ugo.OwnerUUID = :uuid " +
                "   AND IsDeleted = 0" +
                ") " +
            "GROUP BY DurationValue, ProgramYear " +
            ") as pgpd;";

    private static final String SELECT_PROVIDER_GROUP_DETAILS_GROUP_STAR_RATING =
            "   SELECT upgo.AssignedGroups as AssignedGroups, " +
            "   (CASE " +
            "       WHEN cosr.Actual > 0 THEN CONVERT(FLOAT, cosr.Actual) " +
            "       ELSE ( " +
            "           CASE WHEN upgo.AssignedGroups > 0 THEN 0 ELSE NULL END) " +
            "   END) as Actual, " +
            "   CASE " +
            "       WHEN upgo.AssignedGroups > 0 " +
            "       THEN CONVERT(FLOAT, upgo.AssignedGroups) * CONVERT(FLOAT, mc.value) / 100 " +
            "       ELSE NULL " +
            "   END as Target, " +
            "   (CASE " +
            "       WHEN upgo.AssignedGroups > 0 " +
            "       THEN CONVERT(FLOAT, cosr.Actual) / CONVERT(FLOAT, upgo.AssignedGroups) * 100 " +
            "       ELSE NULL " +
            "   END) AS Performance, ( SELECT Max(UpdatedDate) " +
            "   FROM " +
            "       (VALUES (upgo.UpdatedDate), (cosr.UpdatedDate)) AS LastUpdatedDate) " +
            "   AS LastUpdatedDate " +
            "   FROM (SELECT COUNT(DISTINCT GroupId) as AssignedGroups, " +
            "           MAX(UpdatedDate) as UpdatedDate " +
            "       FROM ProgPerf.UHCProviderGroupOwnership " +
            "       WHERE " +
            "           IsDeleted = 0   " +
            "           AND OwnerUUID = :ownerUuid) as upgo, ( SELECT value " +
            "       FROM ProgPerf.MasterConfiguration " +
            "       WHERE code = 'Standard_Target') " +
            "       as mc, ( SELECT COUNT(*) as Actual, " +
            "           MAX(srgp.UpdatedDate) as UpdatedDate " +
            "       FROM ProgPerf.StarRatingGlidePath srgp " +
            "       WHERE " +
            "           srgp.GroupId IN ( SELECT DISTINCT GroupId " +
            "               FROM ProgPerf.UHCProviderGroupOwnership " +
            "               WHERE " +
            "                   IsDeleted = 0   " +
            "                   AND OwnerUUID = :ownerUuid) " +
            "                   AND srgp.OverallRating >= :rating " +
            "                   AND srgp.ProgramYear = :programYear) " +
            "               as cosr " +
            "GROUP BY " +
            "   upgo.AssignedGroups, " +
            "   cosr.Actual, " +
            "   mc.value, " +
            "   upgo.UpdatedDate, " +
            "   cosr.UpdatedDate";

    private static final String GET_PATIENTS_COVERED_TOTAL_COUNT =
            "SELECT SUM(pgpd.TotalPatients) as PatientCount, MAX(pgpd.UpdatedDate) AS LastRiskQualityUpdatedDate " +
            "FROM ProgPerf.ProviderGroupPerformanceDetails pgpd " +
            "WHERE pgpd.ProgramYear = :programYear " +
            "AND pgpd.TeamType = :teamType " +
            "AND pgpd.DurationValue = UPPER(FORMAT(GETDATE(), 'yyyy_MMM', 'en-US')) " +
            "AND pgpd.ProviderGroupId IN ( " +
            "    SELECT DISTINCT ugo.GroupId " +
            "    FROM ProgPerf.UHCProviderGroupOwnership ugo " +
            "    WHERE ugo.OwnerUUID = :ownerUuid " +
            "    AND IsDeleted = 0 " +
            ") ";

    private static final String GET_PATIENTS_COVERED_RISK_QUALITY_COUNT =
            " SELECT " +
            "SUM(CASE WHEN pgrqodm.MasterOpportunityType IN ('Quality Gaps', 'Medication Adherence') THEN pgrqodm.AssessmentCount END) as QualityGapCount, " +
            "SUM(CASE WHEN pgrqodm.MasterOpportunityType = 'Suspect Conditions' THEN pgrqodm.TotalGapsCount END) as OpenSuspectCount, " +
            "MAX(pgrqodm.UpdatedDate) AS LastPatientUpdatedDate " +
            "FROM ProgPerf.ProvGroupRiskQualityOppDetailsMonthly pgrqodm " +
            "WHERE (:programYear IS NULL OR pgrqodm.ProgramYear = :programYear) " +
            "AND pgrqodm.TeamType = 'QFO' " +
            "AND pgrqodm.IsCurrentMonth = 1 " +
            "AND pgrqodm.MasterOpportunityType IN ('Quality Gaps', 'Medication Adherence', 'Suspect Conditions') " +
            "AND pgrqodm.ProviderGroupID IN ( " +
            "    SELECT DISTINCT ugo.GroupId " +
            "    FROM ProgPerf.UHCProviderGroupOwnership ugo " +
            "    WHERE ugo.OwnerUUID = :ownerUuid " +
            "    AND IsDeleted = 0 " +
            ") ";

    public ProviderGroupPerformanceDetailsRepositoryImpl(DatabaseClient client) {
        this.client = client;
    }


    @Override
    public Mono<QFOSuspectConditionsDTO> getQFOSuspectConditions(String uuid, int programYear) {
        return client.execute(FETCH_QFO_SUSPECT_CONDITIONS)
                .bind(ProviderGroupConstants.PROGRAM_YEAR,programYear)
                .bind("UUID",uuid)
                .bind(ProviderGroupConstants.TEAM_TYPE, ProviderGroupConstants.TEAMTYPE_QFO)
                .as(QFOSuspectConditionsDTO.class)
                .fetch()
                .one();
    }

    @Override
    public Mono<ProviderGroupPerformanceDetailsDTO> getPerformanceDetails(String providerGroupId, int programYear) {

        return client.execute(PERFORMANCE_QUERY)
                .bind(ProviderGroupConstants.PROGRAM_YEAR,programYear)
                .bind(ProviderGroupConstants.PROVIDER_GROUP_ID, providerGroupId)
                .as(ProviderGroupPerformanceDetailsDTO.class)
                .fetch()
                .one();
    }

    @Override
    public Mono<Map<String, String>> getConfigurationValues(int programYear) {
        Map<String,String> configMap = new HashMap<>();
        return client.execute(String.format(FETCH_CATEGORY_MASTER_CONFIGURATION,
                Stream.of(ProviderGroupConstants.QFO_RATING_TARGETS).collect(Collectors.joining("','", "'", "'")), programYear))
                .map((row, rowMetadata) -> CategoryMasterConfigDTO.builder()
                        .name(row.get("Key", String.class))
                        .value(row.get("Value", String.class))
                        .build()
                )
                .all()
                .doOnNext(masterConfigDto->{
                    switch (masterConfigDto.getName()) {
                        case ProviderGroupConstants.OVERALL_STAR_RATING_TARGET:
                            configMap.put(ProviderGroupConstants.OVERALL_STAR_RATING_TARGET, masterConfigDto.getValue());
                            break;
                        case ProviderGroupConstants.MAP_PCPI_STAR_RATING_TARGET:
                            configMap.put(ProviderGroupConstants.MAP_PCPI_STAR_RATING_TARGET, masterConfigDto.getValue());
                            break;
                        case ProviderGroupConstants.PART_D_STAR_RATING_TARGET:
                            configMap.put(ProviderGroupConstants.PART_D_STAR_RATING_TARGET, masterConfigDto.getValue());
                            break;
                        case ProviderGroupConstants.ANNUAL_CARE_VISITS_TARGET:
                            configMap.put(ProviderGroupConstants.ANNUAL_CARE_VISITS_TARGET, masterConfigDto.getValue());
                            break;
                        case ProviderGroupConstants.SUSPECT_CONDITIONS_TARGET:
                            configMap.put(ProviderGroupConstants.SUSPECT_CONDITIONS_TARGET, masterConfigDto.getValue());
                            break;
                        default:
                            break;
                    }
                })
                .then(Mono.just(configMap));
    }

    @Override
    public Flux<QFOProviderGroupPerformanceDetailsDTO> getPerformanceDetailsByYear(String providerGroupId, int programYear) {
        return client.execute(FETCH_PROVIDERGROUP_DETAILS)
                .bind(ProviderGroupConstants.PROGRAM_YEAR,programYear)
                .bind(ProviderGroupConstants.PROVIDER_GROUP_ID, providerGroupId)
                .as(QFOProviderGroupPerformanceDetailsDTO.class)
                .fetch()
                .all();
    }

    @Override
    public Flux<StarRating> getStarRatings(String uuid, int programYear) {
        return client.execute(FETCH_QFO_STAR_RATINGS)
                .bind(ProviderGroupConstants.PROGRAM_YEAR, programYear)
                .bind(ProviderGroupConstants.UUID, uuid)
                .as(StarRating.class)
                .map((row, metadata) -> StarRating
                        .builder()
                        .programYear(getValue(row, ProviderGroupConstants.PROGRAM_YEAR, Integer.class))
                        .month(getValue(row, "Month", String.class))
                        .overallStarRating(getFloatValue(row, "OverallStarRating"))
                        .mapCpiStarRating(getFloatValue(row, "MapCpiStarRating"))
                        .updatedDate(getValue(row, "UpdatedDate", LocalDateTime.class))
                        .build()
                )
                .all();
    }

    @Override
    public Flux<SuspectConditionTotal> getSuspectConditionTotals(String uuid, int programYear) {
        return client.execute(FETCH_QFO_SUSPECT_CONDITION_TOTALS)
                .bind(ProviderGroupConstants.PROGRAM_YEAR, programYear)
                .bind(ProviderGroupConstants.UUID, uuid)
                .as(SuspectConditionTotal.class)
                .map((row, metadata) -> SuspectConditionTotal
                        .builder()
                        .programYear(getValue(row, ProviderGroupConstants.PROGRAM_YEAR, Integer.class))
                        .month(getValue(row, "Month", String.class))
                        .suspectConditionsTotal(getValue(row, "SuspectConditionsTotal", Long.class))
                        .suspectConditionsAssessedDiagnosed(getValue(row, "SuspectConditionsAssessedDiagnosed", Long.class))
                        .suspectConditionsAssessedUndiagnosed(getValue(row, "SuspectConditionsAssessedUndiagnosed", Long.class))
                        .targetSuspect(getValue(row, "TargetSuspect", String.class))
                        .suspectUndiagnosedTarget(getValue(row, "SuspectUndiagnosedTarget", String.class))
                        .updatedDate(getValue(row, "UpdatedDate", LocalDateTime.class))
                        .build()
                )
                .all();
    }

    public Mono<QFOGroupStarRatingDTO> getGroupsStarRatingDetails(String uuid, int programYear, int rating) {
        return client.execute(SELECT_PROVIDER_GROUP_DETAILS_GROUP_STAR_RATING)
                .bind(ProviderGroupConstants.PROGRAM_YEAR, programYear)
                .bind(ProviderGroupConstants.OWNER_UUID, uuid)
                .bind(ProviderGroupConstants.RATING, rating)
                .as(QFOGroupStarRatingDTO.class)
                .fetch()
                .one();
    }

    @Override
    public Mono<QFOPatientsCoveredDTO> getQFOPatientsCoveredDetails(String uuid, int programYear, String teamType) {
        String joinedQueries = queryUtil.joinSQLQueries(Arrays.asList(
                GET_PATIENTS_COVERED_TOTAL_COUNT,
                GET_PATIENTS_COVERED_RISK_QUALITY_COUNT));
        return client.execute(joinedQueries)
                .bind(ProviderGroupConstants.PROGRAM_YEAR, programYear)
                .bind(ProviderGroupConstants.TEAM_TYPE, teamType)
                .bind(ProviderGroupConstants.OWNER_UUID, uuid)
                .as(QFOPatientsCoveredDTO.class)
                .fetch()
                .one();
    }

}
