package com.optum.rqns.ftm;

import com.optum.eis.event.model.logClass;
import com.optum.eis.event.model.outcome;
import com.optum.eis.event.model.severity;
import com.optum.rqns.ftm.model.LogField;
import com.optum.rqns.ftm.service.NessLoggerService;
import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.event.EventListener;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.EnableScheduling;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

@SpringBootApplication
@ComponentScan("com.optum.rqns")
@EnableAutoConfiguration
@Slf4j
@EnableEncryptableProperties
@EnableScheduling
public class Application {
	@Autowired
	private NessLoggerService nessLoggerService;
	@Autowired
	private Environment env;
	public static void main(String[] args) {

		new SpringApplicationBuilder(Application.class).properties("spring.config.name=application")
				.run(args);

		log.info("\n\n----------------------------------------------------------\n\t"
				+ "FTM Program Performance Service Started Successfully"
				+ "\n----------------------------------------------------------\n");
	}

	@EventListener(ApplicationReadyEvent.class)
	public void onStart() {
		publishStartStopEventToNess("started");
	}

	@PreDestroy
	public void onExit() {
		publishStartStopEventToNess("stopped");
	}

	private void publishStartStopEventToNess(String event) {
		try {
		    String profiles = Arrays.toString(env.getActiveProfiles());
			String message = "RQNS FTM Program Performance application with the profiles "+profiles+ " "+event;
	        Map<LogField, Object> config = new HashMap<>();
			config.put(LogField.LOGCLASS, logClass.SECURITY_AUDIT);
			config.put(LogField.SEVERITY, severity.INFO);
			config.put(LogField.OUTCOME, outcome.SUCCESS);
			nessLoggerService.publishNessLog(config, message);
		}
		catch(Exception e) {
			log.error("Exception while trying to publish app "+event+" event",e);
		}
	}

	@PostConstruct
	public void setNettyConnecctionPool(){
		System.setProperty("reactor.netty.pool.maxConnections", "1000");
	}

}