package com.optum.rqns.ftm.constants;

public final class DerivedDeploymentReturnNetCNAConstants {
    private DerivedDeploymentReturnNetCNAConstants() {}
    public static final String SERVICE_LEVEL_ALL = "All";
    public static final String SERVICE_LEVEL_HCA = "HCA";
    public static final String SERVICE_LEVEL_PSC = "PSC";
    public static final String TYPE_REGION = "Region";
    public static final String TYPE_LOB_NAME = "LobName";
    public static final String TYPE_CLIENT_NAME = "ClientName";
}
