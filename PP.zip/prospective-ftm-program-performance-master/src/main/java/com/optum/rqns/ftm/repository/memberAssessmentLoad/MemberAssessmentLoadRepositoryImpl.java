package com.optum.rqns.ftm.repository.memberAssessmentLoad;

import com.optum.rqns.ftm.constants.JobConfigurationConstants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

@Repository
@Slf4j
public class MemberAssessmentLoadRepositoryImpl implements MemberAssessmentLoadRepository {

    @Autowired
    private DatabaseClient dbClient;

    private DateTimeFormatter formatter = DateTimeFormatter.ofPattern ("yyyy-MM-dd HH:mm:ss.SSS");//2020-08-25 00:56:45.487

    private final String MEMBER_ASSESSMENT_MERGE = "MERGE INTO [ProgPerf].[MemberAssessment] AS MEMBER " +
            "USING  " +
            "(SELECT  " +
            "[chart_id]" +
            ",[request_id]" +
            ",[parentid]" +
            ",[parentid2]" +
            ",[barcode]" +
            ",[pafm_uid]" +
            ",[chart_dup_id]" +
            ",[project_id]" +
            ",[project_year]" +
            ",[projectid_type]" +
            ",[engagementchannel]" +
            ",[distributionchannel]" +
            ",[distribution_method]" +
            ",[form_type]" +
            ",[projecttype]" +
            ",[reimbursement_type]" +
            ",[source]" +
            ",[review_type]" +
            ",[tfname]" +
            ",[completeness]" +
            ",[run_date]" +
            ",[datepscdeployed]" +
            ",[deploydate]" +
            ",[actualdeployed]" +
            ",[netdeployed]" +
            ",[deriveddeployed]" +
            ",[chart_status]" +
            ",[overall_status]" +
            ",[opaf_suppressed]" +
            ",[paf_suppress_reason]" +
            ",[retrieval_date]" +
            ",[retrieval_date_clean]" +
            ",[returned]" +
            ",[returnednetcna]" +
            ",[retrievedby]" +
            ",[prep_date]" +
            ",[cnaon]" +
            ",[cnareason]" +
            ",[cnareasondesc]" +
            ",[released_for_coding_date]" +
            ",[pended_date]" +
            ",[prep_reject_date]" +
            ",[coding_reject_date]" +
            ",[reject_code]" +
            ",[rejectreason]" +
            ",[rejreasonnote]" +
            ",[screeningrejecton]" +
            ",[screeningrejectcode]" +
            ",[screeningrejectreason]" +
            ",[screenrejreasonnote]" +
            ",[singlerejectdate]" +
            ",[singlerejectreason]" +
            ",[coding_date]" +
            ",[codingvendor]" +
            ",[codinglocation]" +
            ",[codoverreadon]" +
            ",[raorlocation]" +
            ",[extract_date]" +
            ",[screeningstate]" +
            ",[screeningdate]" +
            ",[coded_for_risk]" +
            ",[coded_for_quality]" +
            ",[daysout]" +
            ",[hic_num]" +
            ",[mem_id]" +
            ",[mbrlastname]" +
            ",[mbrfirstname]" +
            ",[dob]" +
            ",[mbridkey]" +
            ",[mbr_glb_id]" +
            ",[levelcode]" +
            ",[carepriority]" +
            ",[mbr_card_id]" +
            ",[mbr_gdr_cd]" +
            ",[mbr_addr1]" +
            ",[mbr_addr2]" +
            ",[mbr_city]" +
            ",[mbr_state]" +
            ",[mbr_zip]" +
            ",[mbr_phone]" +
            ",[mbr_email]" +
            ",[mbr_cont_enrl]" +
            ",[prov_id]" +
            ",[prov_fname]" +
            ",[prov_lname]" +
            ",[provname]" +
            ",[provideraddress1]" +
            ",[provideraddress2]" +
            ",[providercity]" +
            ",[providerstate]" +
            ",[providerzip]" +
            ",[prov_group_id]" +
            ",[prov_group_type]" +
            ",[prov_group_name]" +
            ",[group_name_current]" +
            ",[cs_group_id]" +
            ",[insite_group_id]" +
            ",[insite_group_name]" +
            ",[tin]" +
            ",[site_id]" +
            ",[market_outreach_rep]" +
            ",[hca]" +
            ",[director]" +
            ",[optumregion]" +
            ",[contracted_payment]" +
            ",[timelypmt]" +
            ",[latepmt]" +
            ",[cgappmt]" +
            ",[completenesspmt]" +
            ",[pmtsource]" +
            ",[gapgrpexcl]" +
            ",[hcfa_contract_number]" +
            ",[pbp]" +
            ",[pbp_state]" +
            ",[client]" +
            ",[client1]" +
            ",[subclient]" +
            ",[lob2]" +
            ",[clientregion]" +
            ",[clientstate]" +
            ",[businessunit]" +
            ",[lob]" +
            ",[health_plan]" +
            ",[ProgPerf].[PAFM_MASTER].[clientid]" +
            ",[hpid]" +
            ",[maxdos]" +
            ",[encounter_type]" +
            ",[cnt_telehealth]" +
            ",[cnt_encounters]" +
            ",[2018include]" +
            ",[2018parentid]" +
            ",[2018deduped]" +
            ",[userdefinedcategory1]" +
            ",[userdefinedcategory2]" +
            ",[userdefineddate1]" +
            ",[userdefineddate2]" +
            ",[userdefinednumber1]" +
            ",[userdefinednumber2]" +
            ",[refresh_date]" +
            ",[wk_nbr]" +
            ",[run_yr]" +
            ",[CreatedDate]" +
            ",[UpdatedDate]" +
            ",[RecordChangeType]" +
            ", [ProgPerf].[ClientConfiguration].[ClientName] AS ClientNameOFCStandard " +
            " FROM [ProgPerf].[PAFM_MASTER] " +
            " INNER JOIN [ProgPerf].[ClientConfiguration] " +
            " ON [ProgPerf].[PAFM_MASTER].[clientid] = [ProgPerf].[ClientConfiguration].[ClientId] " +
            "WHERE [project_year] = :PROEJECT_YEAR " +
            "AND ( [UpdatedDate] > CONVERT(datetime, :LAST_SYNC_DATE)  AND [UpdatedDate] < CONVERT(datetime, :CURRENT_SYNC_DATE) )" +
            "ORDER BY [chart_id] " +
            "OFFSET :BATCH_OFFSET ROWS FETCH NEXT :BATCH_SIZE ROWS ONLY " +
            ") AS SRC " +
            "ON SRC.[chart_id] = MEMBER.[chart_id] " +
            "AND SRC.[project_year] = MEMBER.[project_year] " +

            "WHEN MATCHED " +
            "THEN " +
            "UPDATE SET  " +
            "[chart_id] = SRC.[chart_id]" +
            ",[request_id] = SRC.[request_id]" +
            ",[parentid] = SRC.[parentid]" +
            ",[parentid2] = SRC.[parentid2]" +
            ",[barcode] = SRC.[barcode]" +
            ",[pafm_uid] = SRC.[pafm_uid]" +
            ",[chart_dup_id] = SRC.[chart_dup_id]" +
            ",[project_id] = SRC.[project_id]" +
            ",[project_year] = SRC.[project_year]" +
            ",[projectid_type] = SRC.[projectid_type]" +
            ",[engagementchannel] = SRC.[engagementchannel]" +
            ",[distributionchannel] = SRC.[distributionchannel]" +
            ",[distribution_method] = SRC.[distribution_method]" +
            ",[form_type] = SRC.[form_type]" +
            ",[projecttype] = SRC.[projecttype]" +
            ",[reimbursement_type] = SRC.[reimbursement_type]" +
            ",[source] = SRC.[source]" +
            ",[review_type] = SRC.[review_type]" +
            ",[tfname] = SRC.[tfname]" +
            ",[completeness] = SRC.[completeness]" +
            ",[run_date] = SRC.[run_date]" +
            ",[datepscdeployed] = SRC.[datepscdeployed]" +
            ",[deploydate] = SRC.[deploydate]" +
            ",[actualdeployed] = SRC.[actualdeployed]" +
            ",[netdeployed] = SRC.[netdeployed]" +
            ",[deriveddeployed] = SRC.[deriveddeployed]" +
            ",[chart_status] = SRC.[chart_status]" +
            ",[overall_status] = SRC.[overall_status]" +
            ",[opaf_suppressed] = SRC.[opaf_suppressed]" +
            ",[paf_suppress_reason] = SRC.[paf_suppress_reason]" +
            ",[retrieval_date] = SRC.[retrieval_date]" +
            ",[retrieval_date_clean] = SRC.[retrieval_date_clean]" +
            ",[returned] = SRC.[returned]" +
            ",[returnednetcna] = SRC.[returnednetcna]" +
            ",[retrievedby] = SRC.[retrievedby]" +
            ",[prep_date] = SRC.[prep_date]" +
            ",[cnaon] = SRC.[cnaon]" +
            ",[cnareason] = SRC.[cnareason]" +
            ",[cnareasondesc] = SRC.[cnareasondesc]" +
            ",[released_for_coding_date] = SRC.[released_for_coding_date]" +
            ",[pended_date] = SRC.[pended_date]" +
            ",[prep_reject_date] = SRC.[prep_reject_date]" +
            ",[coding_reject_date] = SRC.[coding_reject_date]" +
            ",[reject_code] = SRC.[reject_code]" +
            ",[rejectreason] = SRC.[rejectreason]" +
            ",[rejreasonnote] = SRC.[rejreasonnote]" +
            ",[screeningrejecton] = SRC.[screeningrejecton]" +
            ",[screeningrejectcode] = SRC.[screeningrejectcode]" +
            ",[screeningrejectreason] = SRC.[screeningrejectreason]" +
            ",[screenrejreasonnote] = SRC.[screenrejreasonnote]" +
            ",[singlerejectdate] = SRC.[singlerejectdate]" +
            ",[singlerejectreason] = SRC.[singlerejectreason]" +
            ",[coding_date] = SRC.[coding_date]" +
            ",[codingvendor] = SRC.[codingvendor]" +
            ",[codinglocation] = SRC.[codinglocation]" +
            ",[codoverreadon] = SRC.[codoverreadon]" +
            ",[raorlocation] = SRC.[raorlocation]" +
            ",[extract_date] = SRC.[extract_date]" +
            ",[screeningstate] = SRC.[screeningstate]" +
            ",[screeningdate] = SRC.[screeningdate]" +
            ",[coded_for_risk] = SRC.[coded_for_risk]" +
            ",[coded_for_quality] = SRC.[coded_for_quality]" +
            ",[daysout] = SRC.[daysout]" +
            ",[hic_num] = SRC.[hic_num]" +
            ",[mem_id] = SRC.[mem_id]" +
            ",[mbrlastname] = SRC.[mbrlastname]" +
            ",[mbrfirstname] = SRC.[mbrfirstname]" +
            ",[dob] = SRC.[dob]" +
            ",[mbridkey] = SRC.[mbridkey]" +
            ",[mbr_glb_id] = SRC.[mbr_glb_id]" +
            ",[levelcode] = SRC.[levelcode]" +
            ",[carepriority] = SRC.[carepriority]" +
            ",[mbr_card_id] = SRC.[mbr_card_id]" +
            ",[mbr_gdr_cd] = SRC.[mbr_gdr_cd]" +
            ",[mbr_addr1] = SRC.[mbr_addr1]" +
            ",[mbr_addr2] = SRC.[mbr_addr2]" +
            ",[mbr_city] = SRC.[mbr_city]" +
            ",[mbr_state] = SRC.[mbr_state]" +
            ",[mbr_zip] = SRC.[mbr_zip]" +
            ",[mbr_phone] = SRC.[mbr_phone]" +
            ",[mbr_email] = SRC.[mbr_email]" +
            ",[mbr_cont_enrl] = SRC.[mbr_cont_enrl]" +
            ",[prov_id] = SRC.[prov_id]" +
            ",[prov_fname] = SRC.[prov_fname]" +
            ",[prov_lname] = SRC.[prov_lname]" +
            ",[provname] = SRC.[provname]" +
            ",[provideraddress1] = SRC.[provideraddress1]" +
            ",[provideraddress2] = SRC.[provideraddress2]" +
            ",[providercity] = SRC.[providercity]" +
            ",[providerstate] = SRC.[providerstate]" +
            ",[providerzip] = SRC.[providerzip]" +
            ",[prov_group_id] = SRC.[prov_group_id]" +
            ",[prov_group_type] = SRC.[prov_group_type]" +
            ",[prov_group_name] = SRC.[prov_group_name]" +
            ",[group_name_current] = SRC.[group_name_current]" +
            ",[cs_group_id] = SRC.[cs_group_id]" +
            ",[insite_group_id] = SRC.[insite_group_id]" +
            ",[insite_group_name] = SRC.[insite_group_name]" +
            ",[tin] = SRC.[tin]" +
            ",[site_id] = SRC.[site_id]" +
            ",[market_outreach_rep] = SRC.[market_outreach_rep]" +
            ",[hca] = SRC.[hca]" +
            ",[director] = SRC.[director]" +
            ",[optumregion] = SRC.[optumregion]" +
            ",[contracted_payment] = SRC.[contracted_payment]" +
            ",[timelypmt] = SRC.[timelypmt]" +
            ",[latepmt] = SRC.[latepmt]" +
            ",[cgappmt] = SRC.[cgappmt]" +
            ",[completenesspmt] = SRC.[completenesspmt]" +
            ",[pmtsource] = SRC.[pmtsource]" +
            ",[gapgrpexcl] = SRC.[gapgrpexcl]" +
            ",[hcfa_contract_number] = SRC.[hcfa_contract_number]" +
            ",[pbp] = SRC.[pbp]" +
            ",[pbp_state] = SRC.[pbp_state]" +
            ",[client] = SRC.[client]" +
            ",[client1] = SRC.[client1]" +
            ",[subclient] = SRC.[subclient]" +
            ",[lob2] = SRC.[lob2]" +
            ",[clientregion] = SRC.[clientregion]" +
            ",[clientstate] = SRC.[clientstate]" +
            ",[businessunit] = SRC.[businessunit]" +
            ",[lob] = SRC.[lob]" +
            ",[health_plan] = SRC.[health_plan]" +
            ",[clientid] = SRC.[clientid]" +
            ",[hpid] = SRC.[hpid]" +
            ",[maxdos] = SRC.[maxdos]" +
            ",[encounter_type] = SRC.[encounter_type]" +
            ",[cnt_telehealth] = SRC.[cnt_telehealth]" +
            ",[cnt_encounters] = SRC.[cnt_encounters]" +
            ",[2018include] = SRC.[2018include]" +
            ",[2018parentid] = SRC.[2018parentid]" +
            ",[2018deduped] = SRC.[2018deduped]" +
            ",[userdefinedcategory1] = SRC.[userdefinedcategory1]" +
            ",[userdefinedcategory2] = SRC.[userdefinedcategory2]" +
            ",[userdefineddate1] = SRC.[userdefineddate1]" +
            ",[userdefineddate2] = SRC.[userdefineddate2]" +
            ",[userdefinednumber1] = SRC.[userdefinednumber1]" +
            ",[userdefinednumber2] = SRC.[userdefinednumber2]" +
            ",[refresh_date] = SRC.[refresh_date]" +
            ",[wk_nbr] = SRC.[wk_nbr]" +
            ",[run_yr] = SRC.[run_yr]" +
            ",[UpdatedDate] = GETUTCDATE() " +
            ",[PAFUpdatedDate] = SRC.[UpdatedDate]" +
            ",[RecordChangeType] = SRC.[RecordChangeType]" +
            " ,[ClientNameOFCStandard] = SRC.[ClientNameOFCStandard] " +

            "WHEN NOT MATCHED BY TARGET " +
            "THEN " +
            "INSERT (" +
            "[chart_id]" +
            ",[request_id]" +
            ",[parentid]" +
            ",[parentid2]" +
            ",[barcode]" +
            ",[pafm_uid]" +
            ",[chart_dup_id]" +
            ",[project_id]" +
            ",[project_year]" +
            ",[projectid_type]" +
            ",[engagementchannel]" +
            ",[distributionchannel]" +
            ",[distribution_method]" +
            ",[form_type]" +
            ",[projecttype]" +
            ",[reimbursement_type]" +
            ",[source]" +
            ",[review_type]" +
            ",[tfname]" +
            ",[completeness]" +
            ",[run_date]" +
            ",[datepscdeployed]" +
            ",[deploydate]" +
            ",[actualdeployed]" +
            ",[netdeployed]" +
            ",[deriveddeployed]" +
            ",[chart_status]" +
            ",[overall_status]" +
            ",[opaf_suppressed]" +
            ",[paf_suppress_reason]" +
            ",[retrieval_date]" +
            ",[retrieval_date_clean]" +
            ",[returned]" +
            ",[returnednetcna]" +
            ",[retrievedby]" +
            ",[prep_date]" +
            ",[cnaon]" +
            ",[cnareason]" +
            ",[cnareasondesc]" +
            ",[released_for_coding_date]" +
            ",[pended_date]" +
            ",[prep_reject_date]" +
            ",[coding_reject_date]" +
            ",[reject_code]" +
            ",[rejectreason]" +
            ",[rejreasonnote]" +
            ",[screeningrejecton]" +
            ",[screeningrejectcode]" +
            ",[screeningrejectreason]" +
            ",[screenrejreasonnote]" +
            ",[singlerejectdate]" +
            ",[singlerejectreason]" +
            ",[coding_date]" +
            ",[codingvendor]" +
            ",[codinglocation]" +
            ",[codoverreadon]" +
            ",[raorlocation]" +
            ",[extract_date]" +
            ",[screeningstate]" +
            ",[screeningdate]" +
            ",[coded_for_risk]" +
            ",[coded_for_quality]" +
            ",[daysout]" +
            ",[hic_num]" +
            ",[mem_id]" +
            ",[mbrlastname]" +
            ",[mbrfirstname]" +
            ",[dob]" +
            ",[mbridkey]" +
            ",[mbr_glb_id]" +
            ",[levelcode]" +
            ",[carepriority]" +
            ",[mbr_card_id]" +
            ",[mbr_gdr_cd]" +
            ",[mbr_addr1]" +
            ",[mbr_addr2]" +
            ",[mbr_city]" +
            ",[mbr_state]" +
            ",[mbr_zip]" +
            ",[mbr_phone]" +
            ",[mbr_email]" +
            ",[mbr_cont_enrl]" +
            ",[prov_id]" +
            ",[prov_fname]" +
            ",[prov_lname]" +
            ",[provname]" +
            ",[provideraddress1]" +
            ",[provideraddress2]" +
            ",[providercity]" +
            ",[providerstate]" +
            ",[providerzip]" +
            ",[prov_group_id]" +
            ",[prov_group_type]" +
            ",[prov_group_name]" +
            ",[group_name_current]" +
            ",[cs_group_id]" +
            ",[insite_group_id]" +
            ",[insite_group_name]" +
            ",[tin]" +
            ",[site_id]" +
            ",[market_outreach_rep]" +
            ",[hca]" +
            ",[director]" +
            ",[optumregion]" +
            ",[contracted_payment]" +
            ",[timelypmt]" +
            ",[latepmt]" +
            ",[cgappmt]" +
            ",[completenesspmt]" +
            ",[pmtsource]" +
            ",[gapgrpexcl]" +
            ",[hcfa_contract_number]" +
            ",[pbp]" +
            ",[pbp_state]" +
            ",[client]" +
            ",[client1]" +
            ",[subclient]" +
            ",[lob2]" +
            ",[clientregion]" +
            ",[clientstate]" +
            ",[businessunit]" +
            ",[lob]" +
            ",[health_plan]" +
            ",[clientid]" +
            ",[hpid]" +
            ",[maxdos]" +
            ",[encounter_type]" +
            ",[cnt_telehealth]" +
            ",[cnt_encounters]" +
            ",[2018include]" +
            ",[2018parentid]" +
            ",[2018deduped]" +
            ",[userdefinedcategory1]" +
            ",[userdefinedcategory2]" +
            ",[userdefineddate1]" +
            ",[userdefineddate2]" +
            ",[userdefinednumber1]" +
            ",[userdefinednumber2]" +
            ",[refresh_date]" +
            ",[wk_nbr]" +
            ",[run_yr]" +
            ",[IsSecondarySubmissionEligible]" +
            ",[IsGAThresholdMet]" +
            ",[IsDVThresholdMet] " +
            ",[IsCGapCriteriaMet] " +
            ",[ModifiedDate]" +
            ",[CreatedDate]" +
            ",[UpdatedDate]" +
            ",[PAFCreatedDate]" +
            ",[PAFUpdatedDate]" +
            ",[RecordChangeType]" +
            " ,[ClientNameOFCStandard]" +
            ") " +
            "VALUES (" +
            "SRC.[chart_id]" +
            ",SRC.[request_id]" +
            ",SRC.[parentid]" +
            ",SRC.[parentid2]" +
            ",SRC.[barcode]" +
            ",SRC.[pafm_uid]" +
            ",SRC.[chart_dup_id]" +
            ",SRC.[project_id]" +
            ",SRC.[project_year]" +
            ",SRC.[projectid_type]" +
            ",SRC.[engagementchannel]" +
            ",SRC.[distributionchannel]" +
            ",SRC.[distribution_method]" +
            ",SRC.[form_type]" +
            ",SRC.[projecttype]" +
            ",SRC.[reimbursement_type]" +
            ",SRC.[source]" +
            ",SRC.[review_type]" +
            ",SRC.[tfname]" +
            ",SRC.[completeness]" +
            ",SRC.[run_date]" +
            ",SRC.[datepscdeployed]" +
            ",SRC.[deploydate]" +
            ",SRC.[actualdeployed]" +
            ",SRC.[netdeployed]" +
            ",SRC.[deriveddeployed]" +
            ",SRC.[chart_status]" +
            ",SRC.[overall_status]" +
            ",SRC.[opaf_suppressed]" +
            ",SRC.[paf_suppress_reason]" +
            ",SRC.[retrieval_date]" +
            ",SRC.[retrieval_date_clean]" +
            ",SRC.[returned]" +
            ",SRC.[returnednetcna]" +
            ",SRC.[retrievedby]" +
            ",SRC.[prep_date]" +
            ",SRC.[cnaon]" +
            ",SRC.[cnareason]" +
            ",SRC.[cnareasondesc]" +
            ",SRC.[released_for_coding_date]" +
            ",SRC.[pended_date]" +
            ",SRC.[prep_reject_date]" +
            ",SRC.[coding_reject_date]" +
            ",SRC.[reject_code]" +
            ",SRC.[rejectreason]" +
            ",SRC.[rejreasonnote]" +
            ",SRC.[screeningrejecton]" +
            ",SRC.[screeningrejectcode]" +
            ",SRC.[screeningrejectreason]" +
            ",SRC.[screenrejreasonnote]" +
            ",SRC.[singlerejectdate]" +
            ",SRC.[singlerejectreason]" +
            ",SRC.[coding_date]" +
            ",SRC.[codingvendor]" +
            ",SRC.[codinglocation]" +
            ",SRC.[codoverreadon]" +
            ",SRC.[raorlocation]" +
            ",SRC.[extract_date]" +
            ",SRC.[screeningstate]" +
            ",SRC.[screeningdate]" +
            ",SRC.[coded_for_risk]" +
            ",SRC.[coded_for_quality]" +
            ",SRC.[daysout]" +
            ",SRC.[hic_num]" +
            ",SRC.[mem_id]" +
            ",SRC.[mbrlastname]" +
            ",SRC.[mbrfirstname]" +
            ",SRC.[dob]" +
            ",SRC.[mbridkey]" +
            ",SRC.[mbr_glb_id]" +
            ",SRC.[levelcode]" +
            ",SRC.[carepriority]" +
            ",SRC.[mbr_card_id]" +
            ",SRC.[mbr_gdr_cd]" +
            ",SRC.[mbr_addr1]" +
            ",SRC.[mbr_addr2]" +
            ",SRC.[mbr_city]" +
            ",SRC.[mbr_state]" +
            ",SRC.[mbr_zip]" +
            ",SRC.[mbr_phone]" +
            ",SRC.[mbr_email]" +
            ",SRC.[mbr_cont_enrl]" +
            ",SRC.[prov_id]" +
            ",SRC.[prov_fname]" +
            ",SRC.[prov_lname]" +
            ",SRC.[provname]" +
            ",SRC.[provideraddress1]" +
            ",SRC.[provideraddress2]" +
            ",SRC.[providercity]" +
            ",SRC.[providerstate]" +
            ",SRC.[providerzip]" +
            ",SRC.[prov_group_id]" +
            ",SRC.[prov_group_type]" +
            ",SRC.[prov_group_name]" +
            ",SRC.[group_name_current]" +
            ",SRC.[cs_group_id]" +
            ",SRC.[insite_group_id]" +
            ",SRC.[insite_group_name]" +
            ",SRC.[tin]" +
            ",SRC.[site_id]" +
            ",SRC.[market_outreach_rep]" +
            ",SRC.[hca]" +
            ",SRC.[director]" +
            ",SRC.[optumregion]" +
            ",SRC.[contracted_payment]" +
            ",SRC.[timelypmt]" +
            ",SRC.[latepmt]" +
            ",SRC.[cgappmt]" +
            ",SRC.[completenesspmt]" +
            ",SRC.[pmtsource]" +
            ",SRC.[gapgrpexcl]" +
            ",SRC.[hcfa_contract_number]" +
            ",SRC.[pbp]" +
            ",SRC.[pbp_state]" +
            ",SRC.[client]" +
            ",SRC.[client1]" +
            ",SRC.[subclient]" +
            ",SRC.[lob2]" +
            ",SRC.[clientregion]" +
            ",SRC.[clientstate]" +
            ",SRC.[businessunit]" +
            ",SRC.[lob]" +
            ",SRC.[health_plan]" +
            ",SRC.[clientid]" +
            ",SRC.[hpid]" +
            ",SRC.[maxdos]" +
            ",SRC.[encounter_type]" +
            ",SRC.[cnt_telehealth]" +
            ",SRC.[cnt_encounters]" +
            ",SRC.[2018include]" +
            ",SRC.[2018parentid]" +
            ",SRC.[2018deduped]" +
            ",SRC.[userdefinedcategory1]" +
            ",SRC.[userdefinedcategory2]" +
            ",SRC.[userdefineddate1]" +
            ",SRC.[userdefineddate2]" +
            ",SRC.[userdefinednumber1]" +
            ",SRC.[userdefinednumber2]" +
            ",SRC.[refresh_date]" +
            ",SRC.[wk_nbr]" +
            ",SRC.[run_yr]" +
            ", NULL" +
            ", NULL" +
            ", NULL" +
            ", NULL" +
            ",GETUTCDATE() " +
            ",GETUTCDATE() " +
            ",GETUTCDATE() " +
            ",SRC.[CreatedDate] " +
            ",SRC.[UpdatedDate] " +
            ",SRC.[RecordChangeType] " +
            " ,SRC.[ClientNameOFCStandard] " +
            " );";

    private final String MEMBER_ASSESSMENT_HISTORY_MERGE = "MERGE INTO [ProgPerf].[MemberAssessmentHISTORY] AS MEMBER_HISTORY " +
            "USING  " +
            "(SELECT  " +
            "[chart_id]" +
            ",[request_id]" +
            ",[parentid]" +
            ",[parentid2]" +
            ",[barcode]" +
            ",[pafm_uid]" +
            ",[chart_dup_id]" +
            ",[project_id]" +
            ",[project_year]" +
            ",[projectid_type]" +
            ",[engagementchannel]" +
            ",[distributionchannel]" +
            ",[distribution_method]" +
            ",[form_type]" +
            ",[projecttype]" +
            ",[reimbursement_type]" +
            ",[source]" +
            ",[review_type]" +
            ",[tfname]" +
            ",[completeness]" +
            ",[run_date]" +
            ",[datepscdeployed]" +
            ",[deploydate]" +
            ",[actualdeployed]" +
            ",[netdeployed]" +
            ",[deriveddeployed]" +
            ",[chart_status]" +
            ",[overall_status]" +
            ",[opaf_suppressed]" +
            ",[paf_suppress_reason]" +
            ",[retrieval_date]" +
            ",[retrieval_date_clean]" +
            ",[returned]" +
            ",[returnednetcna]" +
            ",[retrievedby]" +
            ",[prep_date]" +
            ",[cnaon]" +
            ",[cnareason]" +
            ",[cnareasondesc]" +
            ",[released_for_coding_date]" +
            ",[pended_date]" +
            ",[prep_reject_date]" +
            ",[coding_reject_date]" +
            ",[reject_code]" +
            ",[rejectreason]" +
            ",[rejreasonnote]" +
            ",[screeningrejecton]" +
            ",[screeningrejectcode]" +
            ",[screeningrejectreason]" +
            ",[screenrejreasonnote]" +
            ",[singlerejectdate]" +
            ",[singlerejectreason]" +
            ",[coding_date]" +
            ",[codingvendor]" +
            ",[codinglocation]" +
            ",[codoverreadon]" +
            ",[raorlocation]" +
            ",[extract_date]" +
            ",[screeningstate]" +
            ",[screeningdate]" +
            ",[coded_for_risk]" +
            ",[coded_for_quality]" +
            ",[daysout]" +
            ",[hic_num]" +
            ",[mem_id]" +
            ",[mbrlastname]" +
            ",[mbrfirstname]" +
            ",[dob]" +
            ",[mbridkey]" +
            ",[mbr_glb_id]" +
            ",[levelcode]" +
            ",[carepriority]" +
            ",[mbr_card_id]" +
            ",[mbr_gdr_cd]" +
            ",[mbr_addr1]" +
            ",[mbr_addr2]" +
            ",[mbr_city]" +
            ",[mbr_state]" +
            ",[mbr_zip]" +
            ",[mbr_phone]" +
            ",[mbr_email]" +
            ",[mbr_cont_enrl]" +
            ",[prov_id]" +
            ",[prov_fname]" +
            ",[prov_lname]" +
            ",[provname]" +
            ",[provideraddress1]" +
            ",[provideraddress2]" +
            ",[providercity]" +
            ",[providerstate]" +
            ",[providerzip]" +
            ",[prov_group_id]" +
            ",[prov_group_type]" +
            ",[prov_group_name]" +
            ",[group_name_current]" +
            ",[cs_group_id]" +
            ",[insite_group_id]" +
            ",[insite_group_name]" +
            ",[tin]" +
            ",[site_id]" +
            ",[market_outreach_rep]" +
            ",[hca]" +
            ",[director]" +
            ",[optumregion]" +
            ",[contracted_payment]" +
            ",[timelypmt]" +
            ",[latepmt]" +
            ",[cgappmt]" +
            ",[completenesspmt]" +
            ",[pmtsource]" +
            ",[gapgrpexcl]" +
            ",[hcfa_contract_number]" +
            ",[pbp]" +
            ",[pbp_state]" +
            ",[client]" +
            ",[client1]" +
            ",[subclient]" +
            ",[lob2]" +
            ",[clientregion]" +
            ",[clientstate]" +
            ",[businessunit]" +
            ",[lob]" +
            ",[health_plan]" +
            ",[ProgPerf].[PAFM_MASTER].[clientid]" +
            ",[hpid]" +
            ",[maxdos]" +
            ",[encounter_type]" +
            ",[cnt_telehealth]" +
            ",[cnt_encounters]" +
            ",[2018include]" +
            ",[2018parentid]" +
            ",[2018deduped]" +
            ",[userdefinedcategory1]" +
            ",[userdefinedcategory2]" +
            ",[userdefineddate1]" +
            ",[userdefineddate2]" +
            ",[userdefinednumber1]" +
            ",[userdefinednumber2]" +
            ",[refresh_date]" +
            ",[wk_nbr]" +
            ",[run_yr]" +
            ",[CreatedDate]" +
            ",[UpdatedDate]" +
            ",[RecordChangeType]" +
            " ,[ProgPerf].[ClientConfiguration].[ClientName] AS ClientNameOFCStandard " +
            "FROM [ProgPerf].[PAFM_MASTER] " +
            " INNER JOIN [ProgPerf].[ClientConfiguration] " +
            " ON [ProgPerf].[PAFM_MASTER].[clientid] = [ProgPerf].[ClientConfiguration].[ClientId] " +
            "WHERE [project_year] < :PROEJECT_YEAR " +
            "AND ( [UpdatedDate] > CONVERT(datetime, :LAST_SYNC_DATE) AND [UpdatedDate] < CONVERT(datetime, :CURRENT_SYNC_DATE) ) " +
            "ORDER BY [chart_id] " +
            "OFFSET :BATCH_OFFSET ROWS FETCH NEXT :BATCH_SIZE ROWS ONLY " +
            ") AS SRC " +
            "ON SRC.[chart_id] = MEMBER_HISTORY.[chart_id] " +
            "AND SRC.[project_year] = MEMBER_HISTORY.[project_year] " +

            "WHEN MATCHED " +
            "THEN " +
            "UPDATE SET  " +
            "[chart_id] = SRC.[chart_id]" +
            ",[request_id] = SRC.[request_id]" +
            ",[parentid] = SRC.[parentid]" +
            ",[parentid2] = SRC.[parentid2]" +
            ",[barcode] = SRC.[barcode]" +
            ",[pafm_uid] = SRC.[pafm_uid]" +
            ",[chart_dup_id] = SRC.[chart_dup_id]" +
            ",[project_id] = SRC.[project_id]" +
            ",[project_year] = SRC.[project_year]" +
            ",[projectid_type] = SRC.[projectid_type]" +
            ",[engagementchannel] = SRC.[engagementchannel]" +
            ",[distributionchannel] = SRC.[distributionchannel]" +
            ",[distribution_method] = SRC.[distribution_method]" +
            ",[form_type] = SRC.[form_type]" +
            ",[projecttype] = SRC.[projecttype]" +
            ",[reimbursement_type] = SRC.[reimbursement_type]" +
            ",[source] = SRC.[source]" +
            ",[review_type] = SRC.[review_type]" +
            ",[tfname] = SRC.[tfname]" +
            ",[completeness] = SRC.[completeness]" +
            ",[run_date] = SRC.[run_date]" +
            ",[datepscdeployed] = SRC.[datepscdeployed]" +
            ",[deploydate] = SRC.[deploydate]" +
            ",[actualdeployed] = SRC.[actualdeployed]" +
            ",[netdeployed] = SRC.[netdeployed]" +
            ",[deriveddeployed] = SRC.[deriveddeployed]" +
            ",[chart_status] = SRC.[chart_status]" +
            ",[overall_status] = SRC.[overall_status]" +
            ",[opaf_suppressed] = SRC.[opaf_suppressed]" +
            ",[paf_suppress_reason] = SRC.[paf_suppress_reason]" +
            ",[retrieval_date] = SRC.[retrieval_date]" +
            ",[retrieval_date_clean] = SRC.[retrieval_date_clean]" +
            ",[returned] = SRC.[returned]" +
            ",[returnednetcna] = SRC.[returnednetcna]" +
            ",[retrievedby] = SRC.[retrievedby]" +
            ",[prep_date] = SRC.[prep_date]" +
            ",[cnaon] = SRC.[cnaon]" +
            ",[cnareason] = SRC.[cnareason]" +
            ",[cnareasondesc] = SRC.[cnareasondesc]" +
            ",[released_for_coding_date] = SRC.[released_for_coding_date]" +
            ",[pended_date] = SRC.[pended_date]" +
            ",[prep_reject_date] = SRC.[prep_reject_date]" +
            ",[coding_reject_date] = SRC.[coding_reject_date]" +
            ",[reject_code] = SRC.[reject_code]" +
            ",[rejectreason] = SRC.[rejectreason]" +
            ",[rejreasonnote] = SRC.[rejreasonnote]" +
            ",[screeningrejecton] = SRC.[screeningrejecton]" +
            ",[screeningrejectcode] = SRC.[screeningrejectcode]" +
            ",[screeningrejectreason] = SRC.[screeningrejectreason]" +
            ",[screenrejreasonnote] = SRC.[screenrejreasonnote]" +
            ",[singlerejectdate] = SRC.[singlerejectdate]" +
            ",[singlerejectreason] = SRC.[singlerejectreason]" +
            ",[coding_date] = SRC.[coding_date]" +
            ",[codingvendor] = SRC.[codingvendor]" +
            ",[codinglocation] = SRC.[codinglocation]" +
            ",[codoverreadon] = SRC.[codoverreadon]" +
            ",[raorlocation] = SRC.[raorlocation]" +
            ",[extract_date] = SRC.[extract_date]" +
            ",[screeningstate] = SRC.[screeningstate]" +
            ",[screeningdate] = SRC.[screeningdate]" +
            ",[coded_for_risk] = SRC.[coded_for_risk]" +
            ",[coded_for_quality] = SRC.[coded_for_quality]" +
            ",[daysout] = SRC.[daysout]" +
            ",[hic_num] = SRC.[hic_num]" +
            ",[mem_id] = SRC.[mem_id]" +
            ",[mbrlastname] = SRC.[mbrlastname]" +
            ",[mbrfirstname] = SRC.[mbrfirstname]" +
            ",[dob] = SRC.[dob]" +
            ",[mbridkey] = SRC.[mbridkey]" +
            ",[mbr_glb_id] = SRC.[mbr_glb_id]" +
            ",[levelcode] = SRC.[levelcode]" +
            ",[carepriority] = SRC.[carepriority]" +
            ",[mbr_card_id] = SRC.[mbr_card_id]" +
            ",[mbr_gdr_cd] = SRC.[mbr_gdr_cd]" +
            ",[mbr_addr1] = SRC.[mbr_addr1]" +
            ",[mbr_addr2] = SRC.[mbr_addr2]" +
            ",[mbr_city] = SRC.[mbr_city]" +
            ",[mbr_state] = SRC.[mbr_state]" +
            ",[mbr_zip] = SRC.[mbr_zip]" +
            ",[mbr_phone] = SRC.[mbr_phone]" +
            ",[mbr_email] = SRC.[mbr_email]" +
            ",[mbr_cont_enrl] = SRC.[mbr_cont_enrl]" +
            ",[prov_id] = SRC.[prov_id]" +
            ",[prov_fname] = SRC.[prov_fname]" +
            ",[prov_lname] = SRC.[prov_lname]" +
            ",[provname] = SRC.[provname]" +
            ",[provideraddress1] = SRC.[provideraddress1]" +
            ",[provideraddress2] = SRC.[provideraddress2]" +
            ",[providercity] = SRC.[providercity]" +
            ",[providerstate] = SRC.[providerstate]" +
            ",[providerzip] = SRC.[providerzip]" +
            ",[prov_group_id] = SRC.[prov_group_id]" +
            ",[prov_group_type] = SRC.[prov_group_type]" +
            ",[prov_group_name] = SRC.[prov_group_name]" +
            ",[group_name_current] = SRC.[group_name_current]" +
            ",[cs_group_id] = SRC.[cs_group_id]" +
            ",[insite_group_id] = SRC.[insite_group_id]" +
            ",[insite_group_name] = SRC.[insite_group_name]" +
            ",[tin] = SRC.[tin]" +
            ",[site_id] = SRC.[site_id]" +
            ",[market_outreach_rep] = SRC.[market_outreach_rep]" +
            ",[hca] = SRC.[hca]" +
            ",[director] = SRC.[director]" +
            ",[optumregion] = SRC.[optumregion]" +
            ",[contracted_payment] = SRC.[contracted_payment]" +
            ",[timelypmt] = SRC.[timelypmt]" +
            ",[latepmt] = SRC.[latepmt]" +
            ",[cgappmt] = SRC.[cgappmt]" +
            ",[completenesspmt] = SRC.[completenesspmt]" +
            ",[pmtsource] = SRC.[pmtsource]" +
            ",[gapgrpexcl] = SRC.[gapgrpexcl]" +
            ",[hcfa_contract_number] = SRC.[hcfa_contract_number]" +
            ",[pbp] = SRC.[pbp]" +
            ",[pbp_state] = SRC.[pbp_state]" +
            ",[client] = SRC.[client]" +
            ",[client1] = SRC.[client1]" +
            ",[subclient] = SRC.[subclient]" +
            ",[lob2] = SRC.[lob2]" +
            ",[clientregion] = SRC.[clientregion]" +
            ",[clientstate] = SRC.[clientstate]" +
            ",[businessunit] = SRC.[businessunit]" +
            ",[lob] = SRC.[lob]" +
            ",[health_plan] = SRC.[health_plan]" +
            ",[clientid] = SRC.[clientid]" +
            ",[hpid] = SRC.[hpid]" +
            ",[maxdos] = SRC.[maxdos]" +
            ",[encounter_type] = SRC.[encounter_type]" +
            ",[cnt_telehealth] = SRC.[cnt_telehealth]" +
            ",[cnt_encounters] = SRC.[cnt_encounters]" +
            ",[2018include] = SRC.[2018include]" +
            ",[2018parentid] = SRC.[2018parentid]" +
            ",[2018deduped] = SRC.[2018deduped]" +
            ",[userdefinedcategory1] = SRC.[userdefinedcategory1]" +
            ",[userdefinedcategory2] = SRC.[userdefinedcategory2]" +
            ",[userdefineddate1] = SRC.[userdefineddate1]" +
            ",[userdefineddate2] = SRC.[userdefineddate2]" +
            ",[userdefinednumber1] = SRC.[userdefinednumber1]" +
            ",[userdefinednumber2] = SRC.[userdefinednumber2]" +
            ",[refresh_date] = SRC.[refresh_date]" +
            ",[wk_nbr] = SRC.[wk_nbr]" +
            ",[run_yr] = SRC.[run_yr]" +
            ",[UpdatedDate] = GETUTCDATE() " +
            ",[PAFUpdatedDate] = SRC.[UpdatedDate]" +
            ",[RecordChangeType] = SRC.[RecordChangeType]" +
            " ,[ClientNameOFCStandard] = SRC.[ClientNameOFCStandard]" +

            "WHEN NOT MATCHED BY TARGET " +
            "THEN " +
            "INSERT (" +
            "[chart_id]" +
            ",[request_id]" +
            ",[parentid]" +
            ",[parentid2]" +
            ",[barcode]" +
            ",[pafm_uid]" +
            ",[chart_dup_id]" +
            ",[project_id]" +
            ",[project_year]" +
            ",[projectid_type]" +
            ",[engagementchannel]" +
            ",[distributionchannel]" +
            ",[distribution_method]" +
            ",[form_type]" +
            ",[projecttype]" +
            ",[reimbursement_type]" +
            ",[source]" +
            ",[review_type]" +
            ",[tfname]" +
            ",[completeness]" +
            ",[run_date]" +
            ",[datepscdeployed]" +
            ",[deploydate]" +
            ",[actualdeployed]" +
            ",[netdeployed]" +
            ",[deriveddeployed]" +
            ",[chart_status]" +
            ",[overall_status]" +
            ",[opaf_suppressed]" +
            ",[paf_suppress_reason]" +
            ",[retrieval_date]" +
            ",[retrieval_date_clean]" +
            ",[returned]" +
            ",[returnednetcna]" +
            ",[retrievedby]" +
            ",[prep_date]" +
            ",[cnaon]" +
            ",[cnareason]" +
            ",[cnareasondesc]" +
            ",[released_for_coding_date]" +
            ",[pended_date]" +
            ",[prep_reject_date]" +
            ",[coding_reject_date]" +
            ",[reject_code]" +
            ",[rejectreason]" +
            ",[rejreasonnote]" +
            ",[screeningrejecton]" +
            ",[screeningrejectcode]" +
            ",[screeningrejectreason]" +
            ",[screenrejreasonnote]" +
            ",[singlerejectdate]" +
            ",[singlerejectreason]" +
            ",[coding_date]" +
            ",[codingvendor]" +
            ",[codinglocation]" +
            ",[codoverreadon]" +
            ",[raorlocation]" +
            ",[extract_date]" +
            ",[screeningstate]" +
            ",[screeningdate]" +
            ",[coded_for_risk]" +
            ",[coded_for_quality]" +
            ",[daysout]" +
            ",[hic_num]" +
            ",[mem_id]" +
            ",[mbrlastname]" +
            ",[mbrfirstname]" +
            ",[dob]" +
            ",[mbridkey]" +
            ",[mbr_glb_id]" +
            ",[levelcode]" +
            ",[carepriority]" +
            ",[mbr_card_id]" +
            ",[mbr_gdr_cd]" +
            ",[mbr_addr1]" +
            ",[mbr_addr2]" +
            ",[mbr_city]" +
            ",[mbr_state]" +
            ",[mbr_zip]" +
            ",[mbr_phone]" +
            ",[mbr_email]" +
            ",[mbr_cont_enrl]" +
            ",[prov_id]" +
            ",[prov_fname]" +
            ",[prov_lname]" +
            ",[provname]" +
            ",[provideraddress1]" +
            ",[provideraddress2]" +
            ",[providercity]" +
            ",[providerstate]" +
            ",[providerzip]" +
            ",[prov_group_id]" +
            ",[prov_group_type]" +
            ",[prov_group_name]" +
            ",[group_name_current]" +
            ",[cs_group_id]" +
            ",[insite_group_id]" +
            ",[insite_group_name]" +
            ",[tin]" +
            ",[site_id]" +
            ",[market_outreach_rep]" +
            ",[hca]" +
            ",[director]" +
            ",[optumregion]" +
            ",[contracted_payment]" +
            ",[timelypmt]" +
            ",[latepmt]" +
            ",[cgappmt]" +
            ",[completenesspmt]" +
            ",[pmtsource]" +
            ",[gapgrpexcl]" +
            ",[hcfa_contract_number]" +
            ",[pbp]" +
            ",[pbp_state]" +
            ",[client]" +
            ",[client1]" +
            ",[subclient]" +
            ",[lob2]" +
            ",[clientregion]" +
            ",[clientstate]" +
            ",[businessunit]" +
            ",[lob]" +
            ",[health_plan]" +
            ",[clientid]" +
            ",[hpid]" +
            ",[maxdos]" +
            ",[encounter_type]" +
            ",[cnt_telehealth]" +
            ",[cnt_encounters]" +
            ",[2018include]" +
            ",[2018parentid]" +
            ",[2018deduped]" +
            ",[userdefinedcategory1]" +
            ",[userdefinedcategory2]" +
            ",[userdefineddate1]" +
            ",[userdefineddate2]" +
            ",[userdefinednumber1]" +
            ",[userdefinednumber2]" +
            ",[refresh_date]" +
            ",[wk_nbr]" +
            ",[run_yr]" +
            ",[IsSecondarySubmissionEligible]" +
            ",[IsGAThresholdMet]" +
            ",[IsDVThresholdMet] " +
            ",[IsCGapCriteriaMet] " +
            ",[ModifiedDate]" +
            ",[CreatedDate]" +
            ",[UpdatedDate]" +
            ",[PAFCreatedDate]" +
            ",[PAFUpdatedDate]" +
            ",[RecordChangeType]" +
            " ,[ClientNameOFCStandard] " +
            ") " +
            "VALUES (" +
            "SRC.[chart_id]" +
            ",SRC.[request_id]" +
            ",SRC.[parentid]" +
            ",SRC.[parentid2]" +
            ",SRC.[barcode]" +
            ",SRC.[pafm_uid]" +
            ",SRC.[chart_dup_id]" +
            ",SRC.[project_id]" +
            ",SRC.[project_year]" +
            ",SRC.[projectid_type]" +
            ",SRC.[engagementchannel]" +
            ",SRC.[distributionchannel]" +
            ",SRC.[distribution_method]" +
            ",SRC.[form_type]" +
            ",SRC.[projecttype]" +
            ",SRC.[reimbursement_type]" +
            ",SRC.[source]" +
            ",SRC.[review_type]" +
            ",SRC.[tfname]" +
            ",SRC.[completeness]" +
            ",SRC.[run_date]" +
            ",SRC.[datepscdeployed]" +
            ",SRC.[deploydate]" +
            ",SRC.[actualdeployed]" +
            ",SRC.[netdeployed]" +
            ",SRC.[deriveddeployed]" +
            ",SRC.[chart_status]" +
            ",SRC.[overall_status]" +
            ",SRC.[opaf_suppressed]" +
            ",SRC.[paf_suppress_reason]" +
            ",SRC.[retrieval_date]" +
            ",SRC.[retrieval_date_clean]" +
            ",SRC.[returned]" +
            ",SRC.[returnednetcna]" +
            ",SRC.[retrievedby]" +
            ",SRC.[prep_date]" +
            ",SRC.[cnaon]" +
            ",SRC.[cnareason]" +
            ",SRC.[cnareasondesc]" +
            ",SRC.[released_for_coding_date]" +
            ",SRC.[pended_date]" +
            ",SRC.[prep_reject_date]" +
            ",SRC.[coding_reject_date]" +
            ",SRC.[reject_code]" +
            ",SRC.[rejectreason]" +
            ",SRC.[rejreasonnote]" +
            ",SRC.[screeningrejecton]" +
            ",SRC.[screeningrejectcode]" +
            ",SRC.[screeningrejectreason]" +
            ",SRC.[screenrejreasonnote]" +
            ",SRC.[singlerejectdate]" +
            ",SRC.[singlerejectreason]" +
            ",SRC.[coding_date]" +
            ",SRC.[codingvendor]" +
            ",SRC.[codinglocation]" +
            ",SRC.[codoverreadon]" +
            ",SRC.[raorlocation]" +
            ",SRC.[extract_date]" +
            ",SRC.[screeningstate]" +
            ",SRC.[screeningdate]" +
            ",SRC.[coded_for_risk]" +
            ",SRC.[coded_for_quality]" +
            ",SRC.[daysout]" +
            ",SRC.[hic_num]" +
            ",SRC.[mem_id]" +
            ",SRC.[mbrlastname]" +
            ",SRC.[mbrfirstname]" +
            ",SRC.[dob]" +
            ",SRC.[mbridkey]" +
            ",SRC.[mbr_glb_id]" +
            ",SRC.[levelcode]" +
            ",SRC.[carepriority]" +
            ",SRC.[mbr_card_id]" +
            ",SRC.[mbr_gdr_cd]" +
            ",SRC.[mbr_addr1]" +
            ",SRC.[mbr_addr2]" +
            ",SRC.[mbr_city]" +
            ",SRC.[mbr_state]" +
            ",SRC.[mbr_zip]" +
            ",SRC.[mbr_phone]" +
            ",SRC.[mbr_email]" +
            ",SRC.[mbr_cont_enrl]" +
            ",SRC.[prov_id]" +
            ",SRC.[prov_fname]" +
            ",SRC.[prov_lname]" +
            ",SRC.[provname]" +
            ",SRC.[provideraddress1]" +
            ",SRC.[provideraddress2]" +
            ",SRC.[providercity]" +
            ",SRC.[providerstate]" +
            ",SRC.[providerzip]" +
            ",SRC.[prov_group_id]" +
            ",SRC.[prov_group_type]" +
            ",SRC.[prov_group_name]" +
            ",SRC.[group_name_current]" +
            ",SRC.[cs_group_id]" +
            ",SRC.[insite_group_id]" +
            ",SRC.[insite_group_name]" +
            ",SRC.[tin]" +
            ",SRC.[site_id]" +
            ",SRC.[market_outreach_rep]" +
            ",SRC.[hca]" +
            ",SRC.[director]" +
            ",SRC.[optumregion]" +
            ",SRC.[contracted_payment]" +
            ",SRC.[timelypmt]" +
            ",SRC.[latepmt]" +
            ",SRC.[cgappmt]" +
            ",SRC.[completenesspmt]" +
            ",SRC.[pmtsource]" +
            ",SRC.[gapgrpexcl]" +
            ",SRC.[hcfa_contract_number]" +
            ",SRC.[pbp]" +
            ",SRC.[pbp_state]" +
            ",SRC.[client]" +
            ",SRC.[client1]" +
            ",SRC.[subclient]" +
            ",SRC.[lob2]" +
            ",SRC.[clientregion]" +
            ",SRC.[clientstate]" +
            ",SRC.[businessunit]" +
            ",SRC.[lob]" +
            ",SRC.[health_plan]" +
            ",SRC.[clientid]" +
            ",SRC.[hpid]" +
            ",SRC.[maxdos]" +
            ",SRC.[encounter_type]" +
            ",SRC.[cnt_telehealth]" +
            ",SRC.[cnt_encounters]" +
            ",SRC.[2018include]" +
            ",SRC.[2018parentid]" +
            ",SRC.[2018deduped]" +
            ",SRC.[userdefinedcategory1]" +
            ",SRC.[userdefinedcategory2]" +
            ",SRC.[userdefineddate1]" +
            ",SRC.[userdefineddate2]" +
            ",SRC.[userdefinednumber1]" +
            ",SRC.[userdefinednumber2]" +
            ",SRC.[refresh_date]" +
            ",SRC.[wk_nbr]" +
            ",SRC.[run_yr]" +
            ", NULL" +
            ", NULL" +
            ", NULL" +
            ", NULL" +
            ",GETUTCDATE() " +
            ",GETUTCDATE() " +
            ",GETUTCDATE() " +
            ",SRC.[CreatedDate] " +
            ",SRC.[UpdatedDate] " +
            ",SRC.[RecordChangeType] " +
            " ,SRC.[ClientNameOFCStandard]" +
            " );";

    private final String GET_JOB_START_AND_LAST_SUCCESSFUL_DATE = "SELECT [JobStart], ISNULL([LastSuccessfulRunDate],'1900-01-01') AS LastSuccessfulRunDate FROM [ProgPerf].[JobRunConfiguration] WHERE ID = :JOB_ID";

    private final String UPDATE_BATCH_JOB_CONFIG = "UPDATE [ProgPerf].[JobRunConfiguration] " +
            "SET [AffectedRows] = ISNULL([AffectedRows],0) + :AFFECTED_ROWS_COUNT " +
            "WHERE [ID] = :JOB_ID";

    private final String UPDATE_BATCH_HISTORY = "UPDATE [ProgPerf].[JobExecutionHistory] " +
            "SET [AffectedRows] = ISNULL([AffectedRows],0) + :AFFECTED_ROWS_COUNT " +
            "WHERE ID = :EXECUTION_HISTORY_ID";

    private final String GET_COUNT_MEMBER_ASSESSMENT_CURRENT = "SELECT COUNT([chart_id]) " +
            "FROM [ProgPerf].[PAFM_MASTER] " +
            "WHERE [project_year] = :PROJECT_YEAR " +
            "AND [UpdatedDate] > CONVERT(DATETIME, :LAST_SYNC_DATE) " +
            "AND [UpdatedDate] < CONVERT(DATETIME, :CURRENT_SYNC_DATE)";

    private final String GET_COUNT_MEMBER_ASSESSMENT_HISTORY = "SELECT COUNT([chart_id]) " +
            "FROM [ProgPerf].[PAFM_MASTER] " +
            "WHERE project_year < :PROJECT_YEAR " +
            "AND [UpdatedDate] > CONVERT(DATETIME, :LAST_SYNC_DATE) " +
            "AND [UpdatedDate] < CONVERT(DATETIME, :CURRENT_SYNC_DATE)";

    private final String GET_JOB_ID_BY_NAME = "SELECT ID FROM [ProgPerf].[JobRunConfiguration] WHERE JobName = :JOB_NAME";

    private final String GET_CURRENT_JOB_HISTORY_ID = "SELECT MAX(ID) FROM [ProgPerf].[JobExecutionHistory] WHERE JobID = :JOB_ID";

    private final String BIND_PARAM_JOB_ID = "JOB_ID";
    private final String BIND_PARAM_LAST_SYNC_DATE = "LAST_SYNC_DATE";
    private final String BIND_PARAM_CURRENT_SYNC_DATE = "CURRENT_SYNC_DATE";

    @Override
    public Mono<Integer> getJobIdByJobName(String jobName) {

        log.info ("Running query {} With Params - jobName : {}", GET_JOB_ID_BY_NAME, jobName);

        return dbClient.execute (GET_JOB_ID_BY_NAME)
                .bind ("JOB_NAME", jobName)
                .as (Integer.class)
                .fetch ()
                .one ();
    }

    @Override
    public Mono<Map<String,LocalDateTime>> getJobStartAndLastSuccessDateForMemberAssessmentDataSync(int jobConfigId) {
        log.info ("Running query {} With Params - jobID : {}", GET_JOB_START_AND_LAST_SUCCESSFUL_DATE, jobConfigId);
        return dbClient.execute (GET_JOB_START_AND_LAST_SUCCESSFUL_DATE)
                .bind (BIND_PARAM_JOB_ID, jobConfigId)
                .map((row, rowMetadata) ->
                {
                    Map<String,LocalDateTime> jobStartAndLastRunDateMap = new HashMap<> ();
                    jobStartAndLastRunDateMap.put (JobConfigurationConstants.JOB_START, row.get("JobStart", LocalDateTime.class));
                    jobStartAndLastRunDateMap.put (JobConfigurationConstants.LAST_SUCCESSFUL_RUN_DATE, row.get("LastSuccessfulRunDate", LocalDateTime.class));
                    return jobStartAndLastRunDateMap;
                })
                .one ();
    }

    @Override
    public Mono<Integer> executeMemberAssessmentDataSyncForBatch(int projectYear, LocalDateTime lastSyncDate, LocalDateTime currentSyncDate, int batchOffset, int batchSize) {

        log.info ("Executing Merge for MemberAssessment query; With Params - projectYear: {}; lastSyncDate: {}; currentSyncDate: {}; batchOffset: {}; batchSize: {}; ", projectYear, lastSyncDate, currentSyncDate, batchOffset, batchSize);

        return dbClient.execute (MEMBER_ASSESSMENT_MERGE)
                .bind (BIND_PARAM_LAST_SYNC_DATE, lastSyncDate.format (formatter))
                .bind (BIND_PARAM_CURRENT_SYNC_DATE, currentSyncDate.format (formatter))
                .bind ("PROEJECT_YEAR", projectYear)
                .bind ("BATCH_OFFSET", batchOffset)
                .bind ("BATCH_SIZE", batchSize)
                .as (Integer.class)
                .fetch ()
                .rowsUpdated ()
                .switchIfEmpty (Mono.just (0));
    }

    @Override
    public Mono<Integer> executeMemberAssessmentHistoryDataSyncForBatch(int projectYear, LocalDateTime lastSyncDate, LocalDateTime currentSyncDate, int batchOffset, int batchSize) {

        log.info ("Executing Merge for Member Assessment History query; With Params - projectYear: {}; lastSyncDate: {}; currentSyncDate: {}; batchOffset: {}; batchSize: {}; ", projectYear, lastSyncDate, currentSyncDate, batchOffset, batchSize);

        return dbClient.execute (MEMBER_ASSESSMENT_HISTORY_MERGE)
                .bind (BIND_PARAM_LAST_SYNC_DATE, lastSyncDate)
                .bind (BIND_PARAM_CURRENT_SYNC_DATE, currentSyncDate)
                .bind ("PROEJECT_YEAR", projectYear)
                .bind ("BATCH_OFFSET", batchOffset)
                .bind ("BATCH_SIZE", batchSize)
                .as (Integer.class)
                .fetch ()
                .rowsUpdated ()
                .switchIfEmpty (Mono.just (0));
    }

    @Override
    public Mono<Integer> getTotalCountToSyncForMemberAssessment(int projectYear, String formattedLastSyncDate, String formattedCurrentSyncDate) {

        log.info ("Running query {} With Params - projectYear: {}; lastRunDate: {}; syncDate: {};", GET_COUNT_MEMBER_ASSESSMENT_CURRENT, projectYear, formattedLastSyncDate, formattedCurrentSyncDate);

        return dbClient.execute (GET_COUNT_MEMBER_ASSESSMENT_CURRENT)
                .bind ("PROJECT_YEAR", projectYear)
                .bind (BIND_PARAM_LAST_SYNC_DATE, formattedLastSyncDate)
                .bind (BIND_PARAM_CURRENT_SYNC_DATE, formattedCurrentSyncDate)
                .as (Integer.class)
                .fetch ()
                .one ();
    }

    @Override
    public Mono<Integer> getTotalCountToSyncForMemberAssessmentHistory(int projectYear, String formattedLastSyncDate, String formattedCurrentSyncDate) {

        log.info ("Running query {} With Params - projectYear: {}; lastRunDate: {}; syncDate: {};", GET_COUNT_MEMBER_ASSESSMENT_HISTORY, projectYear, formattedLastSyncDate, formattedCurrentSyncDate);

        return dbClient.execute (GET_COUNT_MEMBER_ASSESSMENT_HISTORY)
                .bind ("PROJECT_YEAR", projectYear)
                .bind (BIND_PARAM_LAST_SYNC_DATE, formattedLastSyncDate)
                .bind (BIND_PARAM_CURRENT_SYNC_DATE, formattedCurrentSyncDate)
                .as (Integer.class)
                .fetch ()
                .one ();
    }

    @Override
    public Mono<Integer> updateJobRunConfigurationWithBatchProgress(int jobConfigId, int executionHistoryId, int completedRowsCount) {
        log.info ("Running query {} With Params - jobID : {}; executionHistoryId: {}; rowsCount: {}", UPDATE_BATCH_JOB_CONFIG, jobConfigId, executionHistoryId, completedRowsCount);
        return dbClient.execute (UPDATE_BATCH_JOB_CONFIG)
                .bind (BIND_PARAM_JOB_ID, jobConfigId)
                .bind ("AFFECTED_ROWS_COUNT", completedRowsCount)
                .fetch ()
                .rowsUpdated ()
                .then (Mono.just (completedRowsCount));
    }

    @Override
    public Mono<Integer> updateJobExecutionHistoryWithBatchProgress(int jobConfigId, int executionHistoryId, int completedRowsCount) {
        log.info ("Running query {} With Params - jobID : {}; executionHistoryId: {}; rowsCount: {}", UPDATE_BATCH_HISTORY, jobConfigId, executionHistoryId, completedRowsCount);
        return dbClient.execute (UPDATE_BATCH_HISTORY)
                .bind ("EXECUTION_HISTORY_ID", executionHistoryId)
                .bind ("AFFECTED_ROWS_COUNT", completedRowsCount)
                .fetch ()
                .rowsUpdated ()
                .then (Mono.just (completedRowsCount));
    }

    @Override
    public Mono<Integer> getCurrentJobExecutionHistoryID(int jobConfigId) {
        log.info ("Running query {} With Params - jobID : {}", GET_CURRENT_JOB_HISTORY_ID, jobConfigId);
        return dbClient.execute (GET_CURRENT_JOB_HISTORY_ID)
                .bind (BIND_PARAM_JOB_ID, jobConfigId)
                .as (Integer.class)
                .fetch ()
                .one ();
    }

}
