package com.optum.rqns.ftm.repository.fieldleader;

import java.util.List;

public class LeaderEModalityQueryBuilder {

    private static final LeaderEModalityQueryBuilder INSTANCE =
            new LeaderEModalityQueryBuilder();

    private LeaderEModalityQueryBuilder() {}

    public static LeaderEModalityQueryBuilder.Builder builder() { return INSTANCE.new Builder(); }

    public class Builder {
        private static final String SERVICE_LEVEL_ALL = "'HCA', 'PSC-B', 'PSC-P'";
        private static final String SERVICE_LEVEL= "ServiceLevel";
        private static final String CLIENT_NAME = "ClientName";
        private static final String LOB= "lob";
        private static final String AND= " AND ";
        private static final String FIELD_IN = " %s IN (%s) ";

        private static final String SELECT_OUTER =
                "SELECT x.FixedOrder, x.RegionMarket, " +
                        "CurrentYearOpaf, CurrentYearOptumUpload, CurrentYearOgm, CurrentYearEData, " +
                        "PreviousYearOpaf, PreviousYearOptumUpload, PreviousYearOgm, PreviousYearEData, " +
                        "(SELECT MAX(updatedDate) FROM ProgPerf.LeaderGrowthRatePOCEModality) AS UpdatedDate FROM ( ";

        private static final String SELECT_OUTER_SUFFIX =
                ") x ";

        private static final String SELECT_NATIONAL =
                "SELECT 0 AS FixedOrder, " +
                        "'National' AS RegionMarket, ";

        private static final String SELECT_LOGGED_IN =
                "SELECT 1 AS FixedOrder, " +
                        "( " +
                        "   SELECT CONCAT(FirstName, ' ', LastName) " +
                        "   FROM ProgPerf.Users us " +
                        "   WHERE us.UUID = :UUID" +
                        ") AS RegionMarket, ";

        private static final String SELECT_REGION =
                "SELECT 2 AS FixedOrder, " +
                        "Region AS RegionMarket, ";

        private static final String SELECT_STATE =
                "SELECT 0 AS FixedOrder, State AS RegionMarket, ";

        private static final String OUTER_APPLY = "OUTER APPLY ( SELECT ";
        private static final String OUTER_APPLY_SUFFIX = ") y ";

        private static final String LEFT_JOIN = "LEFT JOIN ( ";
        private static final String LEFT_JOIN_SUFFIX = ") y ON y.RegionMarket = x.RegionMarket ";

        private static final String CURRENT_PROGRAM_YEAR = "AND ProgramYear = :ProgramYear ";
        private static final String PREVIOUS_PROGRAM_YEAR = "AND ProgramYear = (:ProgramYear - 1) ";

        private static final String NATIONAL_UUID = "AND UUID = 'National' ";

        private static final String CURRENT_YEAR_AGGREGATE =
                "CASE WHEN SUM(CAST(RetrievedByOPAF AS BIGINT)) > 0 AND SUM(CAST(ReturnNetCnaActualPer AS BIGINT)) > 0 " +
                        "            THEN CONVERT(FLOAT, SUM(CAST(RetrievedByOPAF AS BIGINT))) / CONVERT(FLOAT, SUM(CAST(ReturnNetCnaActualPer AS BIGINT))) * 100 ELSE NULL END AS CurrentYearOpaf, " +
                        "            CASE WHEN SUM(CAST(RetrievedByOptumUpload AS BIGINT)) > 0 AND SUM(CAST(ReturnNetCnaActualPer AS BIGINT)) > 0 " +
                        "            THEN CONVERT(FLOAT, SUM(CAST(RetrievedByOptumUpload AS BIGINT))) / CONVERT(FLOAT, SUM(CAST(ReturnNetCnaActualPer AS BIGINT))) * 100 ELSE NULL END AS CurrentYearOptumUpload, " +
                        "            CASE WHEN SUM(CAST(RetrievedByOgm AS BIGINT)) > 0 AND SUM(CAST(ReturnNetCnaActualPer AS BIGINT)) > 0 " +
                        "            THEN CONVERT(FLOAT, SUM(CAST(RetrievedByOgm AS BIGINT))) / CONVERT(FLOAT, SUM(CAST(ReturnNetCnaActualPer AS BIGINT))) * 100 ELSE NULL END AS CurrentYearOgm, " +
                        "            CASE WHEN SUM(CAST(RetrievedByEdata AS BIGINT)) > 0 AND SUM(CAST(ReturnNetCnaActualPer AS BIGINT)) > 0 " +
                        "            THEN CONVERT(FLOAT, SUM(CAST(RetrievedByEdata AS BIGINT))) / CONVERT(FLOAT, SUM(CAST(ReturnNetCnaActualPer AS BIGINT))) * 100 ELSE NULL END AS CurrentYearEData ";

        private static final String PREVIOUS_YEAR_AGGREGATE =
                "CASE WHEN SUM(CAST(RetrievedByOPAF AS BIGINT)) > 0 AND SUM(CAST(ReturnNetCnaActualPer AS BIGINT)) > 0 " +
                        "            THEN CONVERT(FLOAT, SUM(CAST(RetrievedByOPAF AS BIGINT))) / CONVERT(FLOAT, SUM(CAST(ReturnNetCnaActualPer AS BIGINT))) * 100 ELSE NULL END AS PreviousYearOpaf, " +
                        "            CASE WHEN SUM(CAST(RetrievedByOptumUpload AS BIGINT)) > 0 AND SUM(CAST(ReturnNetCnaActualPer AS BIGINT)) > 0 " +
                        "            THEN CONVERT(FLOAT, SUM(CAST(RetrievedByOptumUpload AS BIGINT))) / CONVERT(FLOAT, SUM(CAST(ReturnNetCnaActualPer AS BIGINT))) * 100 ELSE NULL END AS PreviousYearOptumUpload, " +
                        "            CASE WHEN SUM(CAST(RetrievedByOgm AS BIGINT)) > 0 AND SUM(CAST(ReturnNetCnaActualPer AS BIGINT)) > 0 " +
                        "            THEN CONVERT(FLOAT, SUM(CAST(RetrievedByOgm AS BIGINT))) / CONVERT(FLOAT, SUM(CAST(ReturnNetCnaActualPer AS BIGINT))) * 100 ELSE NULL END AS PreviousYearOgm, " +
                        "            CASE WHEN SUM(CAST(RetrievedByEdata AS BIGINT)) > 0 AND SUM(CAST(ReturnNetCnaActualPer AS BIGINT)) > 0 " +
                        "            THEN CONVERT(FLOAT, SUM(CAST(RetrievedByEdata AS BIGINT))) / CONVERT(FLOAT, SUM(CAST(ReturnNetCnaActualPer AS BIGINT))) * 100 ELSE NULL END AS PreviousYearEData ";

        private static final String STANDARD_FROM =
                "FROM ProgPerf.LeaderGrowthRatePOCEModality " +
                        "           WHERE IsActive = 1 %s";

        private static final String NATIONAL_CONDITIONAL =
                NATIONAL_UUID +
                        "           AND Region != 'All' " +
                        "           AND Region IS NOT NULL " +
                        "           AND State != 'All'  " +
                        "           AND ClientName != 'All' " +
                        "           AND LOB != 'All' ";

        private static final String LOGGED_IN_CONDITIONAL =
                "AND UUID = :UUID ";

        private static final String REGION_CONDITIONAL =
                NATIONAL_UUID +
                        "           AND Region != 'All' " +
                        "           AND Region IS NOT NULL " +
                        "           AND State != 'All' ";

        private static final String STATE_CONDITIONAL =
                NATIONAL_UUID +
                        "           AND Region IN (:Region) " +
                        "           AND State != 'All' " +
                        "           AND State IS NOT NULL ";

        private static final String REGION_GROUP_BY =
                "GROUP BY Region ";

        private static final String STATE_GROUP_BY =
                "GROUP BY Region, State ";

        private static final String MY_TEAM_WITH =
                "WITH MyTeam (UUID, PersonnelHierarchyId, ParentId, Depth, DeletedDate) AS " +
                        "( " +
                        "   SELECT " +
                        "       UUID, " +
                        "       PersonnelHierarchyId, " +
                        "       ParentId, " +
                        "       0 AS Depth, " +
                        "       DeletedDate " +
                        "   FROM ProgPerf.PersonnelHierarchy " +
                        "   WHERE UUID = :UUID " +
                        "   UNION ALL " +
                        "   SELECT " +
                        "       ph.UUID, " +
                        "       ph.PersonnelHierarchyId, " +
                        "       ph.ParentId, " +
                        "       (mt.Depth + 1) AS Depth, " +
                        "       ph.DeletedDate " +
                        "   FROM ProgPerf.PersonnelHierarchy ph " +
                        "   INNER JOIN MyTeam mt " +
                        "   ON ph.ParentId = mt.PersonnelHierarchyId " +
                        "   AND mt.Depth < 2 " +
                        "   AND ph.DeletedDate IS NULL " +
                        ") ";

        private static final String MY_TEAM_SELECT_OUTER =
                "SELECT " +
                        "    FirstName, LastName, x.UUID, ParentUUID, Role AS Role, NULL AS RegionMarket, " +
                        "    CurrentYearOpaf, CurrentYearOptumUpload, CurrentYearOgm, CurrentYearEData, " +
                        "    PreviousYearOpaf, PreviousYearOptumUpload, PreviousYearOgm, PreviousYearEData, " +
                        "    (SELECT MAX(updatedDate) FROM ProgPerf.LeaderGrowthRatePOCEModality) AS UpdatedDate ";

        private static final String MY_TEAM_FROM =
                "FROM ( ";

        private static final String MY_TEAM_FROM_SUFFIX =
                ") x ";

        private static final String MY_TEAM_LEFT_JOIN =
                "LEFT JOIN ( ";

        private static final String MY_TEAM_LEFT_JOIN_SUFFIX =
                ") y ON y.UUID = x.UUID ";

        private static final String MY_TEAM_SELECT_INNER_MAIN =
                "SELECT " +
                        "        mt.UUID, " +
                        "        (SELECT UUID FROM ProgPerf.PersonnelHierarchy WHERE PersonnelHierarchyId = MAX(mt.ParentId)) AS ParentUUID, " +
                        "        FirstName, " +
                        "        LastName, " +
                        "        JSON_VALUE(u.[Role],'$[0].name') AS Role, ";

        private static final String MY_TEAM_SELECT_INNER_LEFT_JOIN =
                "SELECT mt.UUID, ";

        private static final String MY_TEAM_FROM_INNER_BEGIN =
                "FROM MyTeam mt " +
                        "    INNER JOIN ProgPerf.Users u " +
                        "    ON mt.UUID = u.UUID " +
                        "    LEFT JOIN  ( " +
                        "        SELECT * ";

        private static final String MY_TEAM_FROM_INNER_END =
                "    ) lgrp " +
                        "    ON mt.UUID = lgrp.UUID " +
                        "    GROUP BY mt.UUID, FirstName, LastName, u.[Role]";

        private static final String CURRENT_MONTH_CHECK = "AND [Month] = LEFT(DATENAME(month, getdate()), 3) ";

        private static final String MY_TEAM_FROM_CURRENT_YEAR =
                MY_TEAM_FROM_INNER_BEGIN + STANDARD_FROM + CURRENT_MONTH_CHECK + CURRENT_PROGRAM_YEAR + MY_TEAM_FROM_INNER_END;

        private static final String MY_TEAM_FROM_PREVIOUS_YEAR =
                MY_TEAM_FROM_INNER_BEGIN + STANDARD_FROM + CURRENT_MONTH_CHECK + PREVIOUS_PROGRAM_YEAR + MY_TEAM_FROM_INNER_END;



        private boolean isStandard = false;
        private boolean isRegion = false;
        private boolean isTeam = false;

        private String filterConditions = "";

        Builder asStandard(List<String> clientName, List<String> lob, List<String> serviceLevel) {
            setFilterConditions(clientName, lob, serviceLevel);
            this.isStandard = true;
            return this;
        }

        Builder asRegion(List<String> clientName, List<String> lob, List<String> serviceLevel) {
            setFilterConditions(clientName, lob, serviceLevel);
            this.isRegion = true;
            return this;
        }

        Builder asTeam(List<String> clientName, List<String> lob, List<String> serviceLevel) {
            setFilterConditions(clientName, lob, serviceLevel);
            this.isTeam = true;
            return this;
        }

        public String build() {
            StringBuilder sb = new StringBuilder();
            if (isStandard) {
                sb.append(SELECT_OUTER)
                        .append(SELECT_NATIONAL)
                        .append(CURRENT_YEAR_AGGREGATE)
                        .append(String.format(STANDARD_FROM, filterConditions))
                        .append(NATIONAL_CONDITIONAL)
                        .append(CURRENT_MONTH_CHECK)
                        .append(CURRENT_PROGRAM_YEAR)
                        .append(SELECT_OUTER_SUFFIX)
                        .append(OUTER_APPLY)
                        .append(PREVIOUS_YEAR_AGGREGATE)
                        .append(String.format(STANDARD_FROM, filterConditions))
                        .append(NATIONAL_CONDITIONAL)
                        .append(CURRENT_MONTH_CHECK)
                        .append(PREVIOUS_PROGRAM_YEAR)
                        .append(OUTER_APPLY_SUFFIX)
                        .append("UNION ")
                        .append(SELECT_OUTER)
                        .append(SELECT_LOGGED_IN)
                        .append(CURRENT_YEAR_AGGREGATE)
                        .append(String.format(STANDARD_FROM, filterConditions))
                        .append(LOGGED_IN_CONDITIONAL)
                        .append(CURRENT_MONTH_CHECK)
                        .append(CURRENT_PROGRAM_YEAR)
                        .append(SELECT_OUTER_SUFFIX)
                        .append(OUTER_APPLY)
                        .append(PREVIOUS_YEAR_AGGREGATE)
                        .append(String.format(STANDARD_FROM, filterConditions))
                        .append(LOGGED_IN_CONDITIONAL)
                        .append(CURRENT_MONTH_CHECK)
                        .append(PREVIOUS_PROGRAM_YEAR)
                        .append(OUTER_APPLY_SUFFIX)
                        .append("UNION ")
                        .append(SELECT_OUTER)
                        .append(SELECT_REGION)
                        .append(CURRENT_YEAR_AGGREGATE)
                        .append(String.format(STANDARD_FROM, filterConditions))
                        .append(REGION_CONDITIONAL)
                        .append(CURRENT_MONTH_CHECK)
                        .append(CURRENT_PROGRAM_YEAR)
                        .append(REGION_GROUP_BY)
                        .append(SELECT_OUTER_SUFFIX)
                        .append(LEFT_JOIN)
                        .append(SELECT_REGION)
                        .append(PREVIOUS_YEAR_AGGREGATE)
                        .append(String.format(STANDARD_FROM, filterConditions))
                        .append(REGION_CONDITIONAL)
                        .append(CURRENT_MONTH_CHECK)
                        .append(PREVIOUS_PROGRAM_YEAR)
                        .append(REGION_GROUP_BY)
                        .append(LEFT_JOIN_SUFFIX);
            } else if (isRegion) {
                sb.append(SELECT_OUTER)
                        .append(SELECT_STATE)
                        .append(CURRENT_YEAR_AGGREGATE)
                        .append(String.format(STANDARD_FROM, filterConditions))
                        .append(STATE_CONDITIONAL)
                        .append(CURRENT_MONTH_CHECK)
                        .append(CURRENT_PROGRAM_YEAR)
                        .append(STATE_GROUP_BY)
                        .append(SELECT_OUTER_SUFFIX)
                        .append(LEFT_JOIN)
                        .append(SELECT_STATE)
                        .append(PREVIOUS_YEAR_AGGREGATE)
                        .append(String.format(STANDARD_FROM, filterConditions))
                        .append(STATE_CONDITIONAL)
                        .append(CURRENT_MONTH_CHECK)
                        .append(PREVIOUS_PROGRAM_YEAR)
                        .append(STATE_GROUP_BY)
                        .append(LEFT_JOIN_SUFFIX);
            } else if (isTeam) {
                sb.append(MY_TEAM_WITH)
                        .append(MY_TEAM_SELECT_OUTER)

                        .append(MY_TEAM_FROM)
                        .append(MY_TEAM_SELECT_INNER_MAIN)
                        .append(CURRENT_YEAR_AGGREGATE)
                        .append(String.format(MY_TEAM_FROM_CURRENT_YEAR, filterConditions))
                        .append(MY_TEAM_FROM_SUFFIX)

                        .append(MY_TEAM_LEFT_JOIN)
                        .append(MY_TEAM_SELECT_INNER_LEFT_JOIN)
                        .append(PREVIOUS_YEAR_AGGREGATE)
                        .append(String.format(MY_TEAM_FROM_PREVIOUS_YEAR, filterConditions))
                        .append(MY_TEAM_LEFT_JOIN_SUFFIX);
            } else {
                sb.setLength(0);
            }
            return sb.toString();
        }

        private void setFilterConditions(List<String> clientName, List<String> lob, List<String> serviceLevel) {
            if (clientName != null || lob != null || serviceLevel != null) {
                if (serviceLevel != null && !serviceLevel.isEmpty()) {
                    filterConditions += AND + getCondition(SERVICE_LEVEL, serviceLevel);
                }

                if (clientName != null && !clientName.isEmpty()) {
                    filterConditions += AND + getCondition(CLIENT_NAME, clientName);
                }

                if (lob != null && !lob.isEmpty()) {
                    filterConditions += AND + getCondition(LOB, lob);
                }
            }
            else {
                filterConditions += AND + String.format(FIELD_IN, SERVICE_LEVEL, SERVICE_LEVEL_ALL);
            }
        }

        private String getCondition(String filterType, List<String> filter) {
            String targetValues = "";
            if (filter.size() > 0) {
                targetValues += "'" + filter.get(0) + "'";

                for (int i = 1; i < filter.size(); i++) {
                    targetValues += ", '" + filter.get(i) + "'";
                }
            }

            return String.format(FIELD_IN, filterType, targetValues.replace("[", "").replace("]", ""));
        }
    }
}
