package com.optum.rqns.ftm.model.rules;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ReturnOpportunityInput implements OpportunityInput {
    private String providerGroupId;
    private String providerGroupName;
    private String providerState;
    private String serviceLevel;
    private int projectYear;
    private String client;
    private String clientId;
    private String lobName;
    private int deployYTDActual;
    private int returnYTDActual;
    private int returnYTDActualPercentage;
    private int returnYTDTargetPercent;

    @Override
    public String getPaymentRejectReason() {return null;}

    @Override
    public String getSingleRejectReason() {
        return null;
    }

    @Override
    public String getChartID() {
        return null;
    }

    @Override
    public String getOutlierName() {
        return null;
    }

    @Override
    public String getGapType() {
        return null;
    }

    @Override
    public String getGapDesc() {
        return null;
    }

    @Override
    public String getIsSecondarySubmissionEligible() {
        return null;
    }

    @Override
    public String getOverAllStatus() {
        return null;
    }

    @Override
    public int getEligibleMembersCount() {
        return 0;
    }

}
