package com.optum.rqns.ftm.model.opportunities.providergrp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ProviderGroupMemberGaps {

    private String memberName;
    private String memberId;
    private String chartId;
    private String client;
    private String secondarySubmission;
    private String providerName;
    private String gapDescription;
    private String gapType;
    private String gapStatus;
    private String coverSheetResponse;
    private String outlierType;
    private LocalDate memberDob;
    private String lobName;
    private int programYear;
    private String eligibleProgramType;
    private String cpg;
}
