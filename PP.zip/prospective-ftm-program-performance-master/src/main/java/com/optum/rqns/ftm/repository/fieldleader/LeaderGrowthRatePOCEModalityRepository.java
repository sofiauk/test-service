package com.optum.rqns.ftm.repository.fieldleader;

import com.optum.rqns.ftm.model.fieldleader.LeaderPOCConversion;
import com.optum.rqns.ftm.model.programyearcalendar.CurrentPreviousMonth;
import reactor.core.publisher.Flux;

import java.util.List;

public interface LeaderGrowthRatePOCEModalityRepository {
    Flux<LeaderPOCConversion> getLeaderPOCConversion(int programYear, CurrentPreviousMonth currentPreviousMonth, String uuid, List<String> appliedFilters);
    Flux<LeaderPOCConversion> getLeaderPOCConversionRegion(String region, int programYear, CurrentPreviousMonth currentPreviousMonth, List<String> appliedFilters);
    Flux<LeaderPOCConversion> getLeaderPOCConversionMyTeam(int programYear, CurrentPreviousMonth currentPreviousMonth, String uuid, List<String> appliedFilters);
}
