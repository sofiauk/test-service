package com.optum.rqns.ftm.repository.fieldleader;

import com.optum.rqns.ftm.dto.fieldleader.LeaderEModalityDTO;
import reactor.core.publisher.Flux;

import java.util.List;

public interface LeaderEModalityRepository {
    Flux<LeaderEModalityDTO> getLeaderEModality(String uuid, int programYear, List<String> clientName, List<String> lob, List<String> serviceLevel);
    Flux<LeaderEModalityDTO> getLeaderEModalityByRegion(String uuid, int programYear, List<String> clientName, List<String> lob, List<String> serviceLevel, String region);
    Flux<LeaderEModalityDTO> getLeaderEModalityByTeam(String uuid, int programYear, List<String> clientName, List<String> lob, List<String> serviceLevel);
}
