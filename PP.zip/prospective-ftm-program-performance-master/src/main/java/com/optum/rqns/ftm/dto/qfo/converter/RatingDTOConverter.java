package com.optum.rqns.ftm.dto.qfo.converter;

import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.dto.qfo.RatingDTO;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.ReadingConverter;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

@Component
@ReadingConverter
public class RatingDTOConverter implements Converter<Row, RatingDTO>, DTOWrapperTypeConverter {

	@Override
	public RatingDTO convert(Row row) {
			return RatingDTO.builder()
					.overallStarRating(getFloatValue(row, "OverallStarRating"))
					.gettingNeededCare(getFloatValue(row, "GettingNeededCare"))
					.careCoordination(getFloatValue(row, "CareCoordination"))
					.doctorConversations(getFloatValue(row, "DoctorConversations"))
					.lastUpdatedDate(getValue(row, "LastUpdatedDate", LocalDateTime.class))
					.build();
	}
}
