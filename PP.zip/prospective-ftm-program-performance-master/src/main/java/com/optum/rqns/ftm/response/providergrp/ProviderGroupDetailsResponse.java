package com.optum.rqns.ftm.response.providergrp;

import com.optum.rqns.ftm.model.providergrp.ProviderGroupDetails;
import com.optum.rqns.ftm.wrapper.Meta;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class ProviderGroupDetailsResponse {
    private Meta meta;

    private List<ProviderGroupDetails> data;

    public ProviderGroupDetailsResponse() {
        this.meta = new Meta();
        this.data = new ArrayList<>();
    }
}
