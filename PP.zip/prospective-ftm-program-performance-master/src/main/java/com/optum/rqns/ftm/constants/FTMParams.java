package com.optum.rqns.ftm.constants;

public final class FTMParams {

    private FTMParams() {
    }

    public static final String PROCESS_TYPE = "process-type";
    public static final String PROCESS_SUB_TYPE = "process-sub-type";
    public static final String DOCUMENT_TYPE = "document-type";
    public static final String EXPORT_ID = "export-id";
    public static final String EXPORT_STATUS = "status";
    public static final String FILE_NAME = "file-name";
}
