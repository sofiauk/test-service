package com.optum.rqns.ftm.controller;

import com.optum.rqns.ftm.customannotation.CustomApiResponse;
import com.optum.rqns.ftm.dto.job_configuration.JobConfigurationRequestBody;
import com.optum.rqns.ftm.dto.job_configuration.JobConfigurationDTO;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.TypeEnum;
import com.optum.rqns.ftm.exception.APIErrorCode;
import com.optum.rqns.ftm.exception.ProgramPerformanceException;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.producer.JobEventProducer;
import com.optum.rqns.ftm.response.processor.providergrp.CategoryUpdateDateDetailResponse;
import com.optum.rqns.ftm.response.processor.providergrp.JobConfigurationResponse;
import com.optum.rqns.ftm.response.processor.providergrp.PafOverAllStatusResponse;
import com.optum.rqns.ftm.service.jobConfiguration.JobConfigurationService;
import com.optum.rqns.ftm.util.StargateStandardResponseUtilV2;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.util.Objects;

@Profile("rqnsFtmApi")
@RestController
@RequestMapping("/v1/job-events")
@Slf4j
@CustomApiResponse
public class JobEventController {

    private JobEventProducer jobEventProducer;

    @Autowired
    private JobConfigurationService jobConfigurationService;

    @Autowired
    StargateStandardResponseUtilV2<Object, Object> stargateStandardResponseUtilV2;

    public JobEventController(JobEventProducer jobEventProducer) {
        this.jobEventProducer = jobEventProducer;
    }

    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = String.class), mediaType = MediaType.APPLICATION_JSON_VALUE))
    @PostMapping("/posts")
    public boolean invokeJobEventProducer(@RequestBody JobEvent jobEvent) {
        boolean messageSent = false;
        try {
            messageSent = jobEventProducer.postToMsgQue(jobEvent);
        } catch (Exception e) {
            String message = "Exception occurred during sending message to kafka: " + e.getMessage();
            log.error(message);
        }
        return messageSent;
    }


    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = JobConfigurationDTO.class), mediaType = MediaType.APPLICATION_JSON_VALUE))
    @GetMapping("/jobs")
    public Mono<JobConfigurationResponse> getAllJobConfigurations() {
        log.info("Getting All Job Configurations");
        return stargateStandardResponseUtilV2
                .generateStargateStandardResponse(
                        jobConfigurationService.getAllJobsConfigurations()
                        , TypeEnum.FLUX
                        , new JobConfigurationResponse())
                .cast(JobConfigurationResponse.class);
    }

    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = JobConfigurationDTO.class), mediaType = MediaType.APPLICATION_JSON_VALUE))
    @GetMapping("/jobs/{name}")
    public Mono<JobConfigurationResponse> getJobConfigurationByName(@PathVariable String name) {
        log.info("Getting Job Configurations for {}", name);
        JobName jobName = null;
        if (Objects.nonNull(name)) {
            jobName = JobName.fromString(name);
            if (Objects.isNull(jobName)) {
                log.error("Invalid Job Name : {}",name);
                return Mono.error(new ProgramPerformanceException(HttpStatus.OK, APIErrorCode.INVALID_JOB_NAME));
            }
        }
        return stargateStandardResponseUtilV2.generateStargateStandardResponse(
                jobConfigurationService.getJobConfigurationByName(jobName),
                TypeEnum.MONO,
                new JobConfigurationResponse()
        ).cast(JobConfigurationResponse.class);
    }

    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = String.class), mediaType = MediaType.APPLICATION_JSON_VALUE))
    @PostMapping("/job-configuration-updates")
    public Mono<Boolean> jobConfigurationUpdates(@RequestBody JobConfigurationRequestBody jobConfiguration) {
        log.info("update job configuration details {} {} {}", jobConfiguration.getJobName(),jobConfiguration.getLastSuccessfulRunDate(),jobConfiguration.getIsActive());
        if(Objects.nonNull(jobConfiguration.getJobName())) {
            return jobConfigurationService.jobConfigurationUpdates(jobConfiguration).flatMap(val -> {
                if(val != 0 ){
                    return Mono.just(true);
                }else{
                    return Mono.just(false);
                }
            });
        }else{
            return Mono.error(new ProgramPerformanceException(HttpStatus.OK, APIErrorCode.INVALID_JOB_NAME_INPUT));
        }
    }

    @GetMapping("/updated-category-details")
    @ApiResponse(responseCode = "200", description = "Success Request", content = @Content(schema = @Schema(implementation = CategoryUpdateDateDetailResponse.class), mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<CategoryUpdateDateDetailResponse> getCategoryUpdatedDateDetails(@RequestParam("program-year") int programYear) {
        return stargateStandardResponseUtilV2.generateStargateStandardResponse(jobConfigurationService.getCategoryUpdatedDateDetails(programYear), TypeEnum.FLUX, new CategoryUpdateDateDetailResponse()).cast(CategoryUpdateDateDetailResponse.class);
    }


    @GetMapping("/paf-overall-status")
    @ApiResponse(responseCode = "200", description = "Success Request", content = @Content(schema = @Schema(implementation = PafOverAllStatusResponse.class), mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<PafOverAllStatusResponse> getPafOverStatusDetails(@RequestParam("program-year") int programYear) {
        return stargateStandardResponseUtilV2.generateStargateStandardResponse(jobConfigurationService.getPafOverStatusDetails(programYear), TypeEnum.FLUX, new PafOverAllStatusResponse()).cast(PafOverAllStatusResponse.class);
    }

}
