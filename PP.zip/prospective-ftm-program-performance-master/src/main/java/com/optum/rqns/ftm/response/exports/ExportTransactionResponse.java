package com.optum.rqns.ftm.response.exports;

import com.optum.rqns.ftm.wrapper.Meta;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@AllArgsConstructor
@Builder
@Data
public class ExportTransactionResponse<T> {

    private Meta meta;
    private List<T> data;

    public ExportTransactionResponse() {
        this.meta = new Meta();
        this.data = new ArrayList<>();
    }
}
