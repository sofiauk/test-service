package com.optum.rqns.ftm.dto.commandcenter;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
public class ReturnRatesDTO {

    private ReturnRateValues newFirstHalfOfYear;
    private ReturnRateValues newSecondHalfOfYear;
    private Double newGoalPercent;
    private ReturnRateValues existingFirstHalfOfYear;
    private ReturnRateValues existingSecondHalfOfYear;
    private Double existingGoalPercent;

    public ReturnRatesDTO() {
        newFirstHalfOfYear = new ReturnRateValues();
        newSecondHalfOfYear = new ReturnRateValues();
        existingFirstHalfOfYear = new ReturnRateValues();
        existingSecondHalfOfYear = new ReturnRateValues();
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ReturnRateValues {
        private Integer deployCount;
        private Integer returnCount;
    }
}
