package com.optum.rqns.ftm.dto.processor.providergrp;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Version;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import java.time.LocalDate;

@Data
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProgramYearCalendarDTO {


    private Long id;
    private String durationType;
    private String durationValue;
    private LocalDate startDate;
    private LocalDate endDate;
    private int programYear;

}
