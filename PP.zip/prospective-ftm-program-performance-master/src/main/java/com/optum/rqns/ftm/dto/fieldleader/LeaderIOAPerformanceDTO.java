package com.optum.rqns.ftm.dto.fieldleader;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class LeaderIOAPerformanceDTO extends LeaderBaseDTO<LeaderIOAPerformanceDTO> {
    private Double pctToDeployGoalEOY;
    private Double deploymentPct;
    private Double pctToReturnGoalEOY;
    private Double returnPct;
    private Double rejectPct;
    private Double cGAPClosurePct;
}
