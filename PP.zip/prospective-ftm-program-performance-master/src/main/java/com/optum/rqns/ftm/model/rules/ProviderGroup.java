package com.optum.rqns.ftm.model.rules;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ProviderGroup {
    private String providerGroupID;
    private String state;
    private String serviceLevel;
    private boolean isNew;
}
