package com.optum.rqns.ftm.model.performance.providergrp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class ProviderGroupStateReturnsNetCNA {
    private String name;
    private String providerGroupId;
    private String providerGroupName;
    private String serviceLevel;
    private String state;
    private Long ytdActual;
    private Long currentWeekCounts;
    private Long previousWeekCounts;
    private Long nextWeekForecastCounts;
    private Long opportunityCounts;
    private Double programYearGoal;
    private Double programYearVariance;
    private Double ytdGoal;
    private Double ytdVariance;
}
