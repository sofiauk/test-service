package com.optum.rqns.ftm.dto.opportunities.providergrp.converter;

import com.optum.rqns.ftm.constants.ProviderGroupConstants;
import com.optum.rqns.ftm.model.opportunities.providergrp.ProviderGroupMemberGaps;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;

import java.time.LocalDate;

public class MemberGapConverter implements Converter<Row, ProviderGroupMemberGaps> {
    @Override
    public ProviderGroupMemberGaps convert(Row row) {
        return ProviderGroupMemberGaps.builder()
                .chartId(row.get(ProviderGroupConstants.CHARTID, String.class))
                .memberId(row.get(ProviderGroupConstants.MEMBERID, String.class))
                .client(row.get(ProviderGroupConstants.CLIENT,String.class))
                .coverSheetResponse(row.get(ProviderGroupConstants.COVER_SHEET_RESPONSE,String.class))
                .gapDescription(row.get(ProviderGroupConstants.GAP_DESC,String.class))
                .gapStatus(row.get(ProviderGroupConstants.GAP_STATUS,String.class))
                .gapType(row.get(ProviderGroupConstants.GAP_TYPE,String.class))
                .secondarySubmission(row.get(ProviderGroupConstants.IS_SECONDARY_SUBMISSION, String.class))
                .memberDob(row.get(ProviderGroupConstants.MEMBER_DOB, LocalDate.class))
                .memberName(row.get(ProviderGroupConstants.MEMBER_NAME,String.class))
                .outlierType(row.get(ProviderGroupConstants.OPPORTUNITY_SUB_TYPE, String.class))
                .providerName(row.get(ProviderGroupConstants.PROVIDER_NAME, String.class))
                .programYear(row.get(ProviderGroupConstants.PROGRAM_YEAR, Integer.class))
                .lobName(row.get(ProviderGroupConstants.LOB_NAME, String.class))
                .eligibleProgramType(row.get(ProviderGroupConstants.ELIGIBLE_PROGRAM_TYPE,String.class))
                .cpg(row.get(ProviderGroupConstants.CPG,String.class))
                .build();
    }
}
