package com.optum.rqns.ftm.model.fieldleader;

import lombok.Builder;
import lombok.Data;
import org.springframework.data.relational.core.mapping.Table;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@Builder
@Table("ProgPerf.LeaderPerformance")
public class LeaderPerformance {
    private LocalDateTime updatedDate;
    private LocalDate startDate;
    private LocalDate endDate;
    private Integer deployActualPerf;
    private Integer deployActualGoal;
    private Integer deployGoalYTD;
    private Integer returnActualPerf;
    private Integer returnActualGoal;
    private Integer returnGoalYTD;
    private Integer completeActualPerf;
    private Integer completeActualGoal;
    private Integer eligibleDeployableMembers;
    private Integer rejects;
    private Integer returnNetCnaActualPerf;
    private Integer cGAPClosedSuspect;
    private Integer cGAPTotalSuspect;
}
