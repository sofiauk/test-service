package com.optum.rqns.ftm.dto.personnelhierarchy;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;


@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PersonnelHierarchyDTO {
    private List<PersonnelHierarchyUser> assignedUsers = new ArrayList<>();
    private List<PersonnelHierarchyUser> unassignedUsers = new ArrayList<>();

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class PersonnelHierarchyUser {
        private String uuid;
        private String firstName;
        private String lastName;
        private String role;
        private boolean isActive;
        private Integer userId;
        private Integer parentId;
        private List<PersonnelHierarchyUser> children = new ArrayList<>();
    }
}
