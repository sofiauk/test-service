package com.optum.rqns.ftm.repository.opportunities.providergrp;

import com.optum.rqns.ftm.model.opportunities.providergrp.OpportunitiesLogging;
import reactor.core.publisher.Mono;

import java.util.List;

public interface OpportunitiesLoggingRepository {

    Mono<Long> batchQueriesExecuteForInsertOpportunitiesLogging(List<OpportunitiesLogging> opportunitiesLoggings);

}
