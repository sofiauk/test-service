package com.optum.rqns.ftm.dto;

import com.optum.rqns.ftm.constants.ClientGoalConstants;
import com.optum.rqns.ftm.util.ProgramPerformanceUtil;
import io.r2dbc.spi.Row;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

public interface DTOWrapperTypeConverter {

    // Slf4j is not supporting Slf4j so implementing like this.
    @Slf4j
    final class LogHolder {
    }

    default Double getDoublePercentageValue(Row resultSet, String columnName) {
        return getPercentage(getDoubleValue(resultSet, columnName));
    }

    default String getLastUpdatedString(Row resultSet, String columnName) {
        final LocalDateTime value = getValue(resultSet, columnName, LocalDateTime.class);
        return Objects.isNull(value) ? null :
                value.toLocalDate()
                        .format(DateTimeFormatter.ofPattern(ClientGoalConstants.SNAPSHOT_DATE_FORMAT));
    }

    default Double getDoubleValue(Row resultSet, String columnName) {
        return getValue(resultSet, columnName, Double.class);
    }

    default Long getLongValue(Row resultSet, String columnName) {
        return getValue(resultSet, columnName, Long.class);
    }

    default long getPrimitiveLongValue(Row resultSet, String columnName) {
        final Long value = getValue(resultSet, columnName, Long.class);
        return Objects.isNull(value) ? 0 : value;
    }

    default int getPrimitiveIntegerValue(Row resultSet, String columnName) {
        final Integer value = getValue(resultSet, columnName, Integer.class);
        return Objects.isNull(value) ? 0 : value;
    }

    default Integer getIntegerValue(Row row, String columnName) {
        return getValue(row, columnName, Integer.class);
    }

    default boolean hasBooleanValue(Row resultSet, String columnName) {
        final Boolean value = getValue(resultSet, columnName, Boolean.class);
        return Objects.nonNull(value) && value;
    }

    default Double getPercentage(Double percentageValue) {
        if (percentageValue == null) {
            return null;
        }
        long percentage = Math.round(percentageValue * 100);
        return (double) percentage;
    }

    default String convertIntToString(Row resultSet, String columnName) {
        return getPrimitiveIntegerValue(resultSet, columnName) + "";
    }

    default Float getFloatValue(Row resultSet, String columnName){
        return getValue(resultSet, columnName, Float.class);
    }

    default <T> T getValue(Row resultSet, String columnName, Class<T> type) {
        try {
            return resultSet.get(columnName, type);
        } catch (Exception e) {
            LogHolder.log.error(ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier() + " Unable to get the value from DB ColumnName:" + columnName + " Type is:" + type, e);
            LogHolder.log.info("{} Suppressed the exception returning null ", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier());
            return null;
        }
    }
    default int convertStringToInt(Row resultSet, String columnName){
        final String value = getValue(resultSet, columnName, String.class);
        return Objects.isNull(value) || "".equalsIgnoreCase(value) ? 0 : Integer.parseInt(value);
    }

    default float convertStringToFloat(Row resultSet, String columnName){
        final String value = getValue(resultSet, columnName, String.class);
        return Objects.isNull(value) || "".equalsIgnoreCase(value) ? 0 : Float.parseFloat(value);
    }
}
