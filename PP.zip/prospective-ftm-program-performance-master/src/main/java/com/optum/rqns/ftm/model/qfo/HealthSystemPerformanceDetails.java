package com.optum.rqns.ftm.model.qfo;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
public class HealthSystemPerformanceDetails {
	
	String healthSystemId;
	String healthSystemName;
    Long  totalPatients;
    BigDecimal overAllStarRating;
    Long mapCpiEligiblePatients;
    BigDecimal mapCpiStarRating;
    BigDecimal pCpiPartDRating;
    Long mapcpiAnnualVisitsPercentage;
    Long suspectConditionsTotal;
    Long suspectConditionAssessedTotal;
    Long suspectDiagnosed;
    Long suspectUndiagnosed;
    Long suspectNotAssessed;
    Long mcaipTotalPatients;
    Long mcaipFullyAssessed;
    Long mcaipSuspectMedicalConditions;
    Double overAllStarRatingTarget;
    Double mapcpiRatingTarget;
    Double partDStarRatingTarget;
    Long annualCareVisitsTarget;
    Long conditionAssessedTarget;
    Boolean overAllStarRatingMeetsTarget;
    Boolean mapcpiRatingMeetsTarget;
    Boolean starDRatingMeetsTarget;
    Boolean annualCareVisitsMeetsTarget;
    Boolean conditionAssessedMeetsTarget;
    Long conditionAssessedPercentage;
    Long mcaipAssessedPatientsPercentage;
    Long suspectDiagnosedPercentage;
    Long suspectUndiagnosedPercentage;
    Long suspectNotAssessedPercentage;
    LocalDateTime updatedDate;
    LocalDateTime mapCpiLastUpdated;
    LocalDateTime mcaipLastUpdated;
    String durationValue;
    Integer programYear;

}
