package com.optum.rqns.ftm.repository.processor.providergrp;

import com.optum.rqns.ftm.dto.processor.providergrp.ProgramYearCalendarDTO;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.util.ProgramPerformanceUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

import java.util.List;

import static com.optum.rqns.ftm.constants.ProviderGroupConstants.ALL;
import static com.optum.rqns.ftm.constants.ProviderGroupConstants.EMPTY_STR;
import static com.optum.rqns.ftm.constants.ProviderGroupConstants.RECORD_TYPE_NOT_CHANGE_IN_LIST;

@Repository
@Slf4j
public class ProviderGroupYTDActualProcessorRepositoryImpl implements ProviderGroupYTDActualProcessorRepository {

    public static final String LOB = "Lob";
    private static final String ACTUAL_JOB_NAME = "ActualJobName";

    private final DatabaseClient client;

    private static final String WEEKLY_TABLE = "ProgPerf.ProviderGroupPerformanceWeekly";
    private static final String CLIENT_STR = " A.ClientNameOFCStandard ";
    private static final String COMMA_CLIENT = " ,A.ClientNameOFCStandard ";
    private static final String QUOTED_ALL = "'" + ALL + "'";
    private static final String PERFORMANCE_TABLE = "ProgPerf.ProviderGroupPerformance";
    private static final String AGGREGATE_JOB = "TargetsAggregateJob";
    private static final String RECORD_TYPE_NOT_CHANGE_IN = "recordChangeTypeNotIn";
    private static final String SUM_COMPLETED_DELETED = ",sum(case  when A.overall_status = 'Complete' and A.chart_dup_id =1 then 1 else 0 end) as completedAssesmentCount " +
            "  ,sum(case  when A.overall_status = 'Rejected' and A.chart_dup_id =1 then 1 else 0 end) as rejectedAssesmentCount ";
    private static final String UPDATE_SUM_COMPLETED_DELETED = " ,Completed = sources.completedAssesmentCount "+
            "        , Rejects = sources.rejectedAssesmentCount ";
    private static final String INSERT_COLUMN_NAME_SUM_COMPLETED_DELETED =",Completed,Rejects " ;
    private static final String INSERT_COLUMN_VALUES_SUM_COMPLETED_DELETED =",sources.completedAssesmentCount,sources.rejectedAssesmentCount " ;


    public ProviderGroupYTDActualProcessorRepositoryImpl(DatabaseClient client) {
        this.client = client;
    }

    public enum ColumnNames {
        ID("id"), DEPLOYYTDACTUAL("DeployYTDActual"), RETURNYTDACTUAL("ReturnYTDActual"),
        RETURNYTDTARGET("ReturnYTDTarget"), RETURNYETARGET("ReturnYETarget"),
        PROJECTYEAR("projectYear"), DEPLOYED("deployed"), RETURNED("returned"), LOB("lob"), LOBNAME("LobName"),
        PROVIDERSTATE("providerState"), GROUPID("groupId"), ENAGAGEMENTCHANNEL("engagementChannel"),
        PROVIDERGROUPID("ProviderGroupID"), PROVIDERGROUPNAME("ProviderGroupName"), STATE("State"),
        SERVICELEVEL("ServiceLevel"), ISNEW("IsNew"), PROGRAMYEAR("ProgramYear"), DURATIONVALUE("DurationValue"),
        PERCENTAGE("percentage"), CLIENT("client"), CLIENTNAME("ClientName"),
        RETURNYETARGETPERCENTAGE("ReturnYETargetPercent"), DURATIONENDDATE("DurationEndDate"), DURATIONSTARTDATE("DurationStartDate"),
        MIN_DEPLOY_DATE("MinDeployDate"), MAX_DEPLOY_DATE("MaxDeployDate"),
        RETURNYTDTARGETPERCENTAGE("ReturnYTDTargetPercent"), COMPLETEDASSESSMENT("Completed"), REJECTEDASSESSMENT("Rejects");

        private String columnName;

        ColumnNames(String columnName) {
            this.columnName = columnName;
        }

        public String getColumnName() {
            return this.columnName;
        }
    }

    private static final String FETCH_YTD_DURATION_VALUE_WITH_YEAR = "SELECT TOP 1 id,DurationValue,StartDate,EndDate,DurationType,ProgramYear FROM ProgPerf.ProgramYearCalendar  " +
            "WITH (NOLOCK) where  DurationType ='WEEK' and   " +
            "StartDate <= (SELECT CAST( getUTCDate() AS Date )) AND " +
            "EndDate >= (SELECT CAST( getUTCDate() AS Date )) and ProgramYear = :ProgramYear";

    private static final String FETCH_PREVIOUS_YEAR_LAST_WEEK_DURATION_VALUE = "SELECT TOP 1 id,DurationValue,StartDate,EndDate,DurationType,ProgramYear FROM ProgPerf.ProgramYearCalendar  " +
            "WITH (NOLOCK) where  DurationType ='WEEK' and   " +
            "ProgramYear = :ProgramYear ORDER BY EndDate DESC";

    private static final String UPDATE_IS_CURRENT_WEEK_PERFORMANCE_FLAG = "UPDATE %s" +
            "  set isCurrentWeekForPerformance = 1, UpdatedDate = GetUtcDate(), UpdatedBy = :ActualJobName" +
            "  where DurationValue = :DurationValue and ProgramYear = :ProgramYear and (isCurrentWeekForPerformance is null or isCurrentWeekForPerformance !=1)";

    private static final String VARIANCE_QUERY = "UPDATE ProgPerf.ProviderGroupPerformanceWeekly " +
            "SET " +
            "   DeployYETargetVariance  = ISNULL(DeployYTDActual,0) - ISNULL(DeployYETarget ,0), " +
            "   DeployYTDTargetVariance = ISNULL(DeployYTDActual,0) - ISNULL(DeployYTDTarget ,0), " +
            "   ReturnYETargetVariance  = ISNULL(ReturnYTDActual ,0) - ISNULL(ReturnYETarget ,0), " +
            "   ReturnYTDTargetVariance = ISNULL(ReturnYTDActual,0) - ISNULL(ReturnYTDTarget ,0), " +
            "   UpdatedBy  = :ActualJobName, " +
            "   UpdatedDate = getUtcDate() " +
            "WHERE ProgramYear =:ProgramYear " +
            "AND DurationValue=:DurationValue ;";

    public static final String PG_PERFORMANCE_UPDATED_MERGE_QUERY = "MERGE INTO %s AS pgp  " +
            "USING ( " +
            "  SELECT  " +
            "  A.Prov_Group_ID as ProviderGroupID ,  A.providerstate as State,  " +
            "  %s as ClientName, :All as ServiceLevel," +
            "  A.LOB2 as LobName,  " +
            "  A.Project_Year as ProgramYear,  " +
            "  :DurationValue AS DurationValue," +
            "  sum(case  when a.project_year =:ProgramYear then 1 else 0 end) as DeployYTDActual,  " +
            "  sum(case  when a.project_year =:ProgramYear and A.Returned =1 then 1 else 0 end) as ReturnYTDActual,  " +
            "  sum(case  when a.project_year =:ProgramYear and A.returnednetcna =1 then 1 else 0 end) as ReturnedNetCna,  " +
            "  min(a.deploydate) AS DeploymentStartDate, max(a.deploydate) AS LastDeploymentDate," +
            "  min(case when A.Returned = 1 then a.retrieval_date_clean else null end) AS ReturnedStartDate, " +
            "  max(case when A.Returned = 1 then a.retrieval_date_clean else null end) AS LastReturnedDate " +
            " %s "+
            "  FROM  " +
            "  ProgPerf.MemberAssessment A WITH (NOLOCK) " +
            "  WHERE  " +
            "  A.DerivedDeployed = 1 " +
            "  and A.Project_Year =:ProgramYear  " +
            "  and A.LOB2 in (:Lob)  " +
            "  and LEN(A.Prov_Group_ID) > 0 and LEN(A.providerstate) > 0 and LEN(A.LOB2)> 0 %s" +
            "  and Upper(A.RecordChangeType) not in (:recordChangeTypeNotIn) " +
            "  GROUP BY  " +
            "  A.Project_Year, A.LOB2, A.providerstate, A.Prov_Group_ID %s " +
            ") AS sources " +
            "ON ( " +
            "    pgp.ProviderGroupID = sources.providerGroupID " +
            "    AND pgp.STATE = sources.State " +
            "    AND pgp.ServiceLevel = :All" +
            "    AND pgp.DurationValue = sources.durationValue " +
            "    AND pgp.ProgramYear = sources.programYear " +
            "    AND pgp.ClientName = sources.ClientName " +
            "    AND pgp.LobName = sources.lobName " +
            ") " +
            "WHEN MATCHED " +
            "    THEN" +
            "        UPDATE " +
            "        SET DeployYTDActual = sources.DeployYTDActual" +
            "        , ReturnYTDActual = sources.ReturnYTDActual " +
            "        , ReturnedNetCnaYtdActual = sources.ReturnedNetCna " +
            "        , UpdatedDate = getUTCDate() " +
            "        , UpdatedBy = :ActualJobName" +
            "        , isCurrentWeekForPerformance = 1 " +
            "        , DeploymentStartDate = sources.DeploymentStartDate" +
            "        , LastDeploymentDate = sources.LastDeploymentDate " +
            "        , DurationEndDate = :DurationEndDate" +
            "        , DurationStartDate = :DurationStartDate" +
            "        , ReturnedStartDate = sources.ReturnedStartDate" +
            "        , LastReturnedDate = sources.LastReturnedDate " +
            " %s "+
            "WHEN NOT MATCHED THEN " +
            "        INSERT (ProviderGroupID , State, ServiceLevel " +
            "        , ClientName , LobName , ProgramYear, DurationValue , DeployYTDActual " +
            "        , ReturnYTDActual, ReturnedNetCnaYtdActual" +
            "        , DurationEndDate, DurationStartDate, CreatedBy, CreatedDate " +
            "        , UpdatedBy , UpdatedDate , isCurrentWeekForPerformance " +
            "        , DeploymentStartDate, LastDeploymentDate,ReturnedStartDate,LastReturnedDate  %s ) " +
            "        VALUES (sources.providerGroupID,  sources.State,  :All, sources.ClientName,  sources.lobName ,  sources.programYear " +
            "        ,  sources.durationValue ,  sources.DeployYTDActual, sources.ReturnYTDActual, sources.ReturnedNetCna " +
            "        , :DurationEndDate " +
            "        , :DurationStartDate " +
            "        , :ActualJobName, getUTCDate() , :ActualJobName ,  getUTCDate(), 1, sources.DeploymentStartDate,sources.LastDeploymentDate " +
            "        , sources.ReturnedStartDate,sources.LastReturnedDate  %s  );";

    private static final String FORECAST_QUERY= "with rs as ( " +
            " SELECT " +
            " pgpw.ProviderGroupID,pgpw.State,pgpw.ServiceLevel ,pgpw.ClientName,pgpw.LobName,pgpw.ProgramYear " +
            " , round(cast(sum(pgpw.CurrentWeekDeploymentsCount) as decimal)/4,0) as DeployForeCast, round(cast(sum(pgpw.CurrentWeekReturnsCount) as decimal)/4,0) as ReturnForeCast " +
            " from ProgPerf.ProviderGroupPerformanceWeekly pgpw WITH (NOLOCK)" +
            " where " +
            " ProgramYear = :ProgramYear and " +
            " DurationValue in ( " +
            "  SELECT DurationValue " +
            "  from ProgPerf.ProgramYearCalendar pyc " +
            "  where DurationType = 'week' and ProgramYear = :ProgramYear " +
            "  and EndDate <= :DurationEndDate " +
            "  and :DurationStartDate >= (select StartDate from ProgPerf.ProgramYearCalendar where DurationType = 'week'" +
            "  and ProgramYear = :ProgramYear  order by StartDate asc offset 4 rows fetch next 1 row only) " +
            "  order by StartDate DESC offset 1 rows fetch next 4 rows only" +
            " )" +
            " GROUP  by pgpw.ProviderGroupID,pgpw.State,pgpw.ServiceLevel ,pgpw.ClientName,pgpw.LobName,pgpw.ProgramYear" +
            ") " +
            "update ProgPerf.ProviderGroupPerformanceWeekly " +
            "set " +
            "NextWeekForcastDeploymentsCount = rs.DeployForeCast " +
            ", NextWeekForcastReturnsCount = rs.ReturnForeCast " +
            ", UpdatedBy  = :ActualJobName " +
            ", UpdatedDate = getUtcDate() " +
            "from ProgPerf.ProviderGroupPerformanceWeekly pgpw WITH (NOLOCK) " +
            "join rs on " +
            "pgpw.ProviderGroupID = rs.ProviderGroupID " +
            "and pgpw.State = rs.State " +
            "and pgpw.ServiceLevel = rs.ServiceLevel " +
            "and pgpw.ClientName = rs.ClientName " +
            "and pgpw.LobName = rs.LobName " +
            "and pgpw.ProgramYear = rs.ProgramYear " +
            "and pgpw.DurationValue = :DurationValue";

    private static final String UPDATE_RETURNS_OPPORTUNITY_QUERY =
            " UPDATE ProgPerf.ProviderGroupPerformanceWeekly SET " +
            " ReturnsOpportunityAssessmentCount  = ISNULL(DeployYTDActual,0) - ISNULL(ReturnYTDActual ,0), " +
            " ReturnsOpportunityUpdatedDate = getUtcDate() " +
            " WHERE ProgramYear =:ProgramYear " +
            " AND DurationValue=:DurationValue ;";

    private static final String AGGREGATE_TARGETS_PERFORMANCEWEEKLY_TO_PERFORMANCE="MERGE " +
            "INTO " +
            "ProgPerf.ProviderGroupPerformance AS pgp " +
            "USING ( " +
            "SELECT " +
            "CAST(ROUND(sum(pgpw.DeployYETarget), 0) AS INT) as DeployYETarget, " +
            "CAST(ROUND(sum(pgpw.DeployYTDTarget), 0) AS INT) as DeployYTDTarget, " +
            "CAST(ROUND(sum(pgpw.ReturnYETarget), 0) AS INT) as ReturnYETarget, " +
            "CAST(ROUND(sum(pgpw.ReturnYTDTarget), 0) AS INT) as ReturnYTDTarget, " +
            "pgpw.ProviderGroupID , " +
            "pgpw.State , " +
            "pgpw.LobName, " +
            "pgpw.DurationValue, " +
            "pgpw.ProgramYear " +
            "from " +
            "ProgPerf.ProviderGroupPerformanceWeekly pgpw " +
            "where " +
            "pgpw.DurationValue =:DurationValue " +
            "and pgpw.ProgramYear =:ProgramYear " +
            " group by " +
            "pgpw .ProviderGroupID , " +
            "pgpw.State , " +
            "pgpw .LobName , " +
            "pgpw.DurationValue, " +
            "pgpw .ProgramYear ORDER by pgpw.ProviderGroupID ,pgpw .State ,pgpw .LobName " +
            "OFFSET :offset ROWS FETCH NEXT :batchsize ROWS ONLY) AS sources ON " +
            "( pgp.ProviderGroupID = sources.providerGroupID " +
            "AND pgp.STATE = sources.State " +
            "AND pgp.DurationValue = sources.durationValue " +
            "AND pgp.ProgramYear = sources.programYear " +
            "and pgp.LobName = sources.LobName " +
            "and pgp.ServiceLevel=:All " +
            "and pgp.ClientName=:All " +
            ") " +
            "WHEN MATCHED THEN " +
            "UPDATE " +
            "SET " +
            "DeployYETarget = sources.DeployYETarget , " +
            "DeployYTDTarget = sources.DeployYTDTarget , " +
            "ReturnYETarget = sources.ReturnYETarget , " +
            "ReturnYTDTarget = sources.ReturnYTDTarget , " +
            "UpdatedDate = getUTCDate() , " +
            "UpdatedBy = :ActualJobName , " +
            "PnODeployYETarget = sources.DeployYETarget , " +
            "PnODeployYTDTarget = sources.DeployYTDTarget , " +
            "PnOReturnYETarget = sources.ReturnYETarget , " +
            "PnOReturnYTDTarget = sources.ReturnYTDTarget " +
            "WHEN NOT MATCHED THEN " +
            "INSERT " +
            "(ProviderGroupID , " +
            "State, " +
            "ServiceLevel , " +
            "ClientName , " +
            "LobName , " +
            "ProgramYear, " +
            "DurationValue , " +
            "DurationEndDate, " +
            "DurationStartDate, " +
            "CreatedBy, " +
            "CreatedDate , " +
            "UpdatedBy , " +
            "UpdatedDate , " +
            "isCurrentWeekForPerformance , " +
            "DeployYETarget , " +
            "DeployYTDTarget, " +
            "ReturnYETarget, " +
            "ReturnYTDTarget , " +
            "PnODeployYETarget , " +
            "PnODeployYTDTarget, " +
            "PnOReturnYETarget, " +
            "PnOReturnYTDTarget ) " +
            "VALUES (sources.providerGroupID, " +
            "sources.State, " +
            ":All, " +
            ":All, " +
            "sources.lobName , " +
            "sources.programYear , " +
            "sources.durationValue , " +
            ":DurationEndDate , " +
            ":DurationStartDate , " +
            ":ActualJobName, " +
            "getUTCDate() , " +
            ":ActualJobName , " +
            "getUTCDate(), " +
            "1 , " +
            "sources.DeployYETarget, " +
            "sources.DeployYTDTarget, " +
            "sources.ReturnYETarget, " +
            "sources.ReturnYTDTarget , " +
            "sources.DeployYETarget, " +
            "sources.DeployYTDTarget, " +
            "sources.ReturnYETarget, " +
            "sources.ReturnYTDTarget); ";
    private static final String SPECIAL_ROLLUP_FOR_WITH_ZEROTARGETS ="with master_targets as (SELECT " +
            "dart.ServiceLevel + '_' + dart.LOB as keys , " +
            "dart.AnnualReturnTargetPercentage as value " +
            "from " +
            "ProgPerf.DefaultAnnualReturnTargets dart " +
            "union ( " +
            "select " +
            "durationValue as keys , " +
            "weeklyReturnPercent as value " +
            "from " +
            "ProgPerf.GlidepathPercentageIDM " +
            "where " +
            "durationValue = :DurationValue )) " +
            ", performance_special as ( " +
            "SELECT DeployYTDActual,PnODeployYETarget,PnODeployYTDTarget, " +
            "PnOReturnYETarget,PnOReturnYTDTarget,ReturnYETarget, " +
            "ProviderGroupID ,State ,ServiceLevel ,LobName ,ClientName ,DurationValue " +
            "from ProgPerf.ProviderGroupPerformance pgp " +
            "where pgp.DurationValue =:DurationValue AND PGP.ProgramYear =:ProgramYear " +
            "and (PGP.PnODeployYETarget = 0 OR  PGP.PnODeployYETarget IS NULL) and PGP.DeployYTDActual >0 " +
            "ORDER by PGP.ProviderGroupID ,PGP .State ,PGP .LobName " +
            "OFFSET :offset ROWS FETCH NEXT :batchsize ROWS ONLY " +
            ") " +
            "update performance_special " +
            "set performance_special.PnODeployYETarget =performance_special.DeployYTDActual, " +
            "performance_special.PnODeployYTDTarget=performance_special.DeployYTDActual , " +
            "performance_special.PnOReturnYETarget= CAST(ROUND((performance_special.DeployYTDActual* (select m.value from master_targets m where "+
            " m.keys=   a.ServiceLevel +'_'+LOBName)),0) as INT) "+
            ",performance_special.PnOReturnYTDTarget= CAST(ROUND(((performance_special.DeployYTDActual* (select m.value from master_targets m where  " +
            "m.keys=   a.ServiceLevel +'_'+LOBName)) * (select m.value from master_targets m where " +
            "m.keys= :DurationValue )) , 0) AS INT) " +
            "FROM performance_special " +
            "JOIN  ProgPerf.Accounts a " +
            "ON GroupId =performance_special.ProviderGroupID " +
            "AND a.State=performance_special.state; ";


    private static final String GET_TOTAL_COUNT_ROLLUP="SELECT count(DISTINCT  pgpw.ProviderGroupID + pgpw .State + pgpw .LobName) from ProgPerf.ProviderGroupPerformanceWeekly pgpw "+
            " where pgpw.DurationValue =:DurationValue ";

    private static final String GET_TOTAL_COUNT_SEPCIAL_ROLLUP="SELECT count(*)  from ProgPerf.ProviderGroupPerformance pgp  " +
            "where pgp.DurationValue =:DurationValue AND PGP.ProgramYear =:ProgramYear  " +
            "and (PGP.DeployYETarget = 0 OR  PGP.DeployYETarget IS NULL) and PGP.DeployYTDActual >0  ";
    
    
    @Override
    public Mono<Integer> updatePerformanceTableActualValues(int programYear, ProgramYearCalendarDTO programYearCalendarDTO, List<String> lobs) {


        final String query = String.format(PG_PERFORMANCE_UPDATED_MERGE_QUERY,
                PERFORMANCE_TABLE, QUOTED_ALL,EMPTY_STR, EMPTY_STR, EMPTY_STR,EMPTY_STR,EMPTY_STR,EMPTY_STR);
        log.info("{} Query is {},{},{},{},{}", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier(), query,
                programYear, programYearCalendarDTO, lobs, RECORD_TYPE_NOT_CHANGE_IN_LIST);

        return client.execute(query)
                .bind(ALL, ALL)
                .bind(ColumnNames.DURATIONVALUE.getColumnName(), programYearCalendarDTO.getDurationValue())
                .bind(ColumnNames.DURATIONSTARTDATE.getColumnName(), programYearCalendarDTO.getStartDate())
                .bind(ColumnNames.DURATIONENDDATE.getColumnName(), programYearCalendarDTO.getEndDate())
                .bind(ColumnNames.PROGRAMYEAR.getColumnName(), programYear)
                .bind(LOB, lobs)
                .bind(RECORD_TYPE_NOT_CHANGE_IN, RECORD_TYPE_NOT_CHANGE_IN_LIST)
                .bind(ACTUAL_JOB_NAME, JobName.LOAD_LOB_TARGET_VALUES_AND_ACTUALS.getValue())
                .fetch()
                .rowsUpdated()
                .doOnNext(integer -> log.info("(*(*(*(*(* rows Updated {}", integer));
    }

    @Override
    public Mono<ProgramYearCalendarDTO> getYTDDurationValue(int programYear, boolean isPreviousProgramYear) {
        String query;
        if (isPreviousProgramYear) {
            query = FETCH_PREVIOUS_YEAR_LAST_WEEK_DURATION_VALUE;
        } else {
            query = FETCH_YTD_DURATION_VALUE_WITH_YEAR;
        }
        log.info("{} Duration Query is {},{}", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier(), query, programYear);
        return client
                .execute(query)
                .bind(ColumnNames.PROGRAMYEAR.getColumnName(), programYear)
                .as(ProgramYearCalendarDTO.class)
                .fetch()
                .one()
                .switchIfEmpty(Mono.error(new RuntimeException("Duration Value is null")));
    }

    @Override
    public Mono<Integer> updatePerformanceWeeklyTableActualValues(int programYear, ProgramYearCalendarDTO programYearCalendarDTO, List<String> lobs) {

        final String query = String.format(PG_PERFORMANCE_UPDATED_MERGE_QUERY,
                WEEKLY_TABLE, CLIENT_STR,SUM_COMPLETED_DELETED, " and LEN(A.ClientNameOFCStandard) > 0", COMMA_CLIENT,UPDATE_SUM_COMPLETED_DELETED
                ,INSERT_COLUMN_NAME_SUM_COMPLETED_DELETED,INSERT_COLUMN_VALUES_SUM_COMPLETED_DELETED);
        log.info("{} Query is {},{},{},{},{}", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier(), query,
                programYear, programYearCalendarDTO, lobs, RECORD_TYPE_NOT_CHANGE_IN_LIST);

        return client.execute(query)
                .bind(ALL, ALL)
                .bind(ColumnNames.DURATIONVALUE.getColumnName(), programYearCalendarDTO.getDurationValue())
                .bind(ColumnNames.DURATIONSTARTDATE.getColumnName(), programYearCalendarDTO.getStartDate())
                .bind(ColumnNames.DURATIONENDDATE.getColumnName(), programYearCalendarDTO.getEndDate())
                .bind(ColumnNames.PROGRAMYEAR.getColumnName(), programYear)
                .bind(LOB, lobs)
                .bind(RECORD_TYPE_NOT_CHANGE_IN, RECORD_TYPE_NOT_CHANGE_IN_LIST)
                .bind(ACTUAL_JOB_NAME, JobName.LOAD_LOB_TARGET_VALUES_AND_ACTUALS.getValue())
                .fetch()
                .rowsUpdated()
                .doOnNext(integer -> log.info("(*(*(*(*(* rows Updated {}", integer));
    }

    @Override
    public Mono<Integer> setIsCurrentWeekForPerformanceToTrue(ProgramYearCalendarDTO programYearCalendarDTO, boolean isWeeklyTable) {

        String query = String.format(UPDATE_IS_CURRENT_WEEK_PERFORMANCE_FLAG, isWeeklyTable ? WEEKLY_TABLE : PERFORMANCE_TABLE);

        return client.execute(query)
                .bind(ColumnNames.DURATIONVALUE.getColumnName(), programYearCalendarDTO.getDurationValue())
                .bind(ColumnNames.PROGRAMYEAR.getColumnName(), programYearCalendarDTO.getProgramYear())
                .bind(ACTUAL_JOB_NAME, JobName.LOAD_LOB_TARGET_VALUES_AND_ACTUALS.getValue())
                .fetch()
                .rowsUpdated()
                .doOnNext(integer -> log.info("Is Current Week For Performance for duration:{}  Updated rows  {}", programYearCalendarDTO, integer));
    }

    @Override
    public Mono<Integer> calculateForecastColumnValues(ProgramYearCalendarDTO programYearCalendarDTO) {

        return client.execute(FORECAST_QUERY)
                .bind(ColumnNames.DURATIONVALUE.getColumnName(), programYearCalendarDTO.getDurationValue())
                .bind(ColumnNames.PROGRAMYEAR.getColumnName(), programYearCalendarDTO.getProgramYear())
                .bind(ColumnNames.DURATIONSTARTDATE.getColumnName(),programYearCalendarDTO.getStartDate())
                .bind(ColumnNames.DURATIONENDDATE.getColumnName(),programYearCalendarDTO.getEndDate())
                .bind(ACTUAL_JOB_NAME, JobName.LOAD_LOB_TARGET_VALUES_AND_ACTUALS.getValue())
                .fetch()
                .rowsUpdated()
                .doOnNext(integer -> log.info("ForeCast updated record count {} {}", integer, programYearCalendarDTO));
    }

    @Override
    public Mono<Integer> calculateVarianceValues(ProgramYearCalendarDTO programYearCalendarDTO) {

        return client.execute(VARIANCE_QUERY)
                .bind(ColumnNames.DURATIONVALUE.getColumnName(), programYearCalendarDTO.getDurationValue())
                .bind(ColumnNames.PROGRAMYEAR.getColumnName(), programYearCalendarDTO.getProgramYear())
                .bind(ACTUAL_JOB_NAME, JobName.LOAD_LOB_TARGET_VALUES_AND_ACTUALS.getValue())
                .fetch()
                .rowsUpdated()
                .doOnNext(integer -> log.info(" Updated Variance records count {} {}", integer, programYearCalendarDTO));
    }


    @Override
    public Mono<Integer> calculateReturnsOpportunityValues(ProgramYearCalendarDTO programYearCalendarDTO) {

        return client.execute(UPDATE_RETURNS_OPPORTUNITY_QUERY)
                .bind(ColumnNames.DURATIONVALUE.getColumnName(), programYearCalendarDTO.getDurationValue())
                .bind(ColumnNames.PROGRAMYEAR.getColumnName(), programYearCalendarDTO.getProgramYear())
                .fetch()
                .rowsUpdated()
                .doOnNext(integer -> log.info(" Updated Returns Opportunity records count {} {}", integer, programYearCalendarDTO));
    }

    @Override
    public Mono<Integer>  getTotalCountforAggerateTargetsRollup(int programYear, ProgramYearCalendarDTO programYearCalendarDTO) {
        log.info("getTotalCountforAggerateTargetsRollup  programYear : {} , programYearCalendarDTO : {} ",programYear,programYearCalendarDTO);
        return client
                .execute(GET_TOTAL_COUNT_ROLLUP)
                .bind("DurationValue",programYearCalendarDTO.getDurationValue())
                .as(Integer.class)
                .fetch()
                .one();
    }

    @Override
    public Mono<Integer> upsertPerformanceTableWithAggregatedTargets(int programYear, ProgramYearCalendarDTO programYearCalendarDTO, Integer currentBeginId, Integer batchSize) {
        log.info("upsertPerformanceTableWithAggregatedTargets  programYear : {} , programYearCalendarDTO : {} ",programYear,programYearCalendarDTO);
        return client.execute(AGGREGATE_TARGETS_PERFORMANCEWEEKLY_TO_PERFORMANCE)
                .bind(ColumnNames.DURATIONVALUE.getColumnName(), programYearCalendarDTO.getDurationValue())
                .bind(ColumnNames.PROGRAMYEAR.getColumnName(), programYearCalendarDTO.getProgramYear())
                .bind(ACTUAL_JOB_NAME, AGGREGATE_JOB)
                .bind(ALL, ALL)
                .bind(ColumnNames.DURATIONSTARTDATE.getColumnName(), programYearCalendarDTO.getStartDate())
                .bind("offset", currentBeginId)
                .bind("batchsize", batchSize)
                .bind(ColumnNames.DURATIONENDDATE.getColumnName(), programYearCalendarDTO.getEndDate())
                .fetch()
                .rowsUpdated()
                .doOnNext(rowsAffectedCount -> log.info(" Updated Aggregate Targets records for OffSet:{},batchsize:{},  count: {}, programYearCalendarDTO::{}",
                        currentBeginId,batchSize,rowsAffectedCount, programYearCalendarDTO));
    }

    @Override
    public Mono<Integer> getTotalCountforSpecialRollup(int programYear, ProgramYearCalendarDTO programYearCalendarDTO) {
        log.info("getTotalCountforSpecialRollup  programYear : {} , programYearCalendarDTO : {} ",programYear,programYearCalendarDTO);
        return client
                .execute(GET_TOTAL_COUNT_SEPCIAL_ROLLUP)
                .bind(ColumnNames.DURATIONVALUE.getColumnName(), programYearCalendarDTO.getDurationValue())
                .bind(ColumnNames.PROGRAMYEAR.getColumnName(), programYearCalendarDTO.getProgramYear())
                .as(Integer.class)
                .fetch()
                .one();
    }

    @Override
    public Mono<Integer> updatePerformanceTableWithSpecialPnoTargets(int programYear, ProgramYearCalendarDTO programYearCalendarDTO, Integer currentBeginId, int batchSize) {
        log.info("upsertPerformanceTableWithAggregatedTargets  programYear : {} , programYearCalendarDTO : {} ",programYear,programYearCalendarDTO);
        return client.execute(SPECIAL_ROLLUP_FOR_WITH_ZEROTARGETS)
                .bind(ColumnNames.DURATIONVALUE.getColumnName(), programYearCalendarDTO.getDurationValue())
                .bind(ColumnNames.PROGRAMYEAR.getColumnName(), programYearCalendarDTO.getProgramYear())
                .bind("offset", currentBeginId)
                .bind("batchsize", batchSize)
                .fetch()
                .rowsUpdated()
                .doOnNext(rowsAffectedCount -> log.info(" Updated Special Targets records for OffSet:{},batchsize:{},  count: {}, programYearCalendarDTO::{}",
                        currentBeginId,batchSize,rowsAffectedCount, programYearCalendarDTO));
    }

}