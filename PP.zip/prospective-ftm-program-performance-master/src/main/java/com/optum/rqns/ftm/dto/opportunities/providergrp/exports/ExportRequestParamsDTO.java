package com.optum.rqns.ftm.dto.opportunities.providergrp.exports;

import com.optum.rqns.ftm.model.UserInfo;
import com.optum.rqns.ftm.request.exports.ExportsRequestPayloadInputs;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ExportRequestParamsDTO {
    ExportsRequestPayloadInputs exportsRequestPayloadInputs;
    UserInfo userInfo;
    long timeTakenToExport;
    long fileSize;
    int totalRecordsCount;
    String fileName;
}
