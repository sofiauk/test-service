package com.optum.rqns.ftm.request.exports;

public interface IGenericExportRequestInput {
    /**
     * Need to implement this method in implemented classes & return class name for ex: getClass().getName().
     * For example @see{@link com.optum.rqns.ftm.model.opportunities.providergrp.MemberAssessment}
     * and @see{@link com.optum.rqns.ftm.service.opportunities.exports.IGenericExportRequestInputDeserializer}
     * @return className
     */
    String getClassName();
}
