package com.optum.rqns.ftm.dto.goals.client;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class LobGoalDTO {
    private Integer clientId;
    private String clientName;
    private String lob;
    private Integer lobId;
    private String region;
    private String regionId;
    private String state;
    private String stateId;
    private String  hcfa;
    private String pbpId;
    private Float deployed;
    private Float returned;
    private Float completed;
    private Double eligibleMembers;
    private Integer secondarySubmission;
    private Float gaRisk;
    private Float gaQuality;
    private Float dvRisk;
    private Float dvQuality;
    private Float riskGapClosure;
    private Float diagnosedVerified;
    private Float cGapRisk;
    private Float cGapQuality;
}
