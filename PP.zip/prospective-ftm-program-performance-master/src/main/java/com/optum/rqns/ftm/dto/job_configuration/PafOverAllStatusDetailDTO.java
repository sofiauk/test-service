package com.optum.rqns.ftm.dto.job_configuration;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class PafOverAllStatusDetailDTO {
    private String projectId;
    private String overallStatus;
    private Long count;

}
