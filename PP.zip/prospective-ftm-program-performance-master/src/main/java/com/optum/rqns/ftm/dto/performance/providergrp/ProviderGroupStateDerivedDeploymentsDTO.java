package com.optum.rqns.ftm.dto.performance.providergrp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ProviderGroupStateDerivedDeploymentsDTO {

    private String name;
    private String state;
    private String providerGroupId;
    private String providerGroupName;
    private String serviceLevel;
    private DerivedDeploymentWeeksDTO deployments;
    private DerivedDeploymentYearsDTO programYear;
    private DerivedDeploymentYearsDTO ytd;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class DerivedDeploymentWeeksDTO {
        private Long ytdActual;
        private Long currentWeekCounts;
        private Long previousWeekCounts;
        private Long nextWeekForecastCounts;
        private Long opportunityCounts;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class DerivedDeploymentYearsDTO {
        private Double goal;
        private Double variance;
    }
}
