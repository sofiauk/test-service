package com.optum.rqns.ftm.repository.fieldleader;

import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.dto.fieldleader.LeaderIOAPerformanceDTO;
import com.optum.rqns.ftm.enums.ScopeType;
import com.optum.rqns.ftm.model.fieldleader.LeaderEModality;
import com.optum.rqns.ftm.model.fieldleader.LeaderGrowthRate;
import com.optum.rqns.ftm.model.fieldleader.LeaderIOAPerformance;
import com.optum.rqns.ftm.model.fieldleader.LeaderPOCConversionRate;
import com.optum.rqns.ftm.model.fieldleader.LeaderPerformance;
import com.optum.rqns.ftm.model.programyearcalendar.CurrentPreviousMonth;
import io.r2dbc.spi.Row;
import org.springframework.data.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public class LeaderPerformanceRepositoryImpl implements LeaderPerformanceRepository, DTOWrapperTypeConverter {

    private static final String UPDATED_DATE = "UpdatedDate";
    private static final String SERVICE_LEVEL = "ServiceLevel";
    private static final String CLIENT_NAME = "ClientName";
    private static final String LOB = "LOB";
    private static final String PARENT_UUID = "ParentUUID";

    private final DatabaseClient client;

    LeaderPerformanceRepositoryImpl(DatabaseClient client) {
        this.client = client;
    }

    public enum ColumnNames {

        UUID("UUID"),
        PROGRAM_YEAR("ProgramYear"),
        REGION("Region"),
        CURRENT_MONTH("CurrentMonth"),
        PREVIOUS_MONTH("PreviousMonth"),
        IS_CURRENT_PROGRAM_YEAR("IsCurrentProgramYear");

        private String columnName;

        ColumnNames(String columnName) {
            this.columnName = columnName;
        }

        public String getColumnName() {
            return this.columnName;
        }
    }

    @Override
    public Flux<LeaderPerformance> getLeaderPerformance(String currentUUID, String type, int programYear) {
        LeaderPerformanceQueryBuilder.Builder b = LeaderPerformanceQueryBuilder.builder();
        b.asLeaderPerformance(currentUUID, type);
        return client.execute(b.build())
                .bind(ColumnNames.PROGRAM_YEAR.getColumnName(), programYear)
                .as(LeaderPerformance.class)
                .map((row, rowMetadata) -> LeaderPerformance
                        .builder()
                        .updatedDate(getDateValue(row, UPDATED_DATE))
                        .startDate(LocalDate.parse(row.get("DurationStartDate").toString()))
                        .endDate(LocalDate.parse(row.get("DurationEndDate").toString()))
                        .deployActualPerf(getIntegerValue(row, "DeployActualPerf"))
                        .deployActualGoal(getIntegerValue(row, "DeployActualGoal"))
                        .deployGoalYTD(getIntegerValue(row, "DeployGoalYTD"))
                        .returnActualPerf(getIntegerValue(row, "ReturnNetCnaActualPerf"))
                        .returnActualGoal(getIntegerValue(row, "ReturnNetCnaActualGoal"))
                        .returnGoalYTD(getIntegerValue(row, "ReturnGoalYTD"))
                        .completeActualPerf(getIntegerValue(row, "CompletedAssessmentActualPerf"))
                        .completeActualGoal(getIntegerValue(row, "CompletedAssessmentActualGoal"))
                        .eligibleDeployableMembers(getIntegerValue(row, "EligibleDeployableMembers"))
                        .rejects(getIntegerValue(row, "Rejects"))
                        .returnNetCnaActualPerf(getIntegerValue(row, "ReturnNetCnaActualPerf"))
                        .cGAPClosedSuspect(getIntegerValue(row, "CGAPClosedSuspect"))
                        .cGAPTotalSuspect(getIntegerValue(row, "CGAPTotalSuspect"))
                        .build()
                )
                .all();

    }

    @Override
    public Flux<LeaderPOCConversionRate> getLeaderPOCConversionRate(String currentUUID, int programYear, CurrentPreviousMonth currentPreviousMonth) {
        LeaderPerformanceQueryBuilder.Builder b = LeaderPerformanceQueryBuilder.builder();
        b.asLeaderPOCConversionRate(currentUUID);
        return client.execute(b.build())
                .as(LeaderPOCConversionRate.class)
                .bind(ColumnNames.PROGRAM_YEAR.getColumnName(), programYear)
                .bind(ColumnNames.IS_CURRENT_PROGRAM_YEAR.getColumnName(), currentPreviousMonth.getIsCurrentProgramYear())
                .bind(ColumnNames.CURRENT_MONTH.getColumnName(), currentPreviousMonth.getCurrentMonth())
                .bind(ColumnNames.PREVIOUS_MONTH.getColumnName(), currentPreviousMonth.getPreviousMonth())
                .map((row, rowMetadata) -> LeaderPOCConversionRate
                        .builder()
                        .currentMonth(getBooleanValue(row,"CurrentMonth"))
                        .existingGroups(getIntegerValue(row, "ExistingGroups"))
                        .existingTotalGroups(getIntegerValue(row, "ExistingTotalGroups"))
                        .newGroups(getIntegerValue(row, "NewGroups"))
                        .newTotalGroups(getIntegerValue(row, "NewTotalGroups"))
                        .updatedDate(getDateValue(row, UPDATED_DATE))
                        .build()
                )
                .all();

    }

    @Override
    public Flux<LeaderGrowthRate> getLeaderGrowthRates(int programYear, ScopeType scopeType, String currentUUID, List<String> serviceLevels) {
        LeaderPerformanceQueryBuilder.Builder b = LeaderPerformanceQueryBuilder.builder();
        b.asLeaderGrowthRates(scopeType, currentUUID, serviceLevels);
        boolean isUsers = (scopeType == ScopeType.MY_TEAM || scopeType == ScopeType.CURRENT_USER);
        return client.execute(b.build())
                .as(LeaderGrowthRate.class)
                .bind(ColumnNames.PROGRAM_YEAR.getColumnName(), programYear)
                .map((row, rowMetadata) -> LeaderGrowthRate
                        .builder()
                        .parentScope(getScopeStringValue(row, scopeType, true))
                        .scope(getScopeStringValue(row, scopeType, false))
                        .firstName(isUsers ? getStringValue(row, "FirstName") : null)
                        .lastName(isUsers ? getStringValue(row, "LastName") : null)
                        .role(isUsers ? getStringValue(row,"Role") : null)
                        .isCurrentYear(getBooleanValue(row, "IsCurrentYear"))
                        .totalGroupsSum(getIntegerValue(row, "TotalGroupsSum"))
                        .agreedParticipateSum(getIntegerValue(row, "AgreedParticipateSum"))
                        .engagedParticipateSum(getIntegerValue(row, "EngagedParticipateSum"))
                        .updatedDate(getDateValue(row, UPDATED_DATE))
                        .build()
                )
                .all();
    }

    @Override
    public Flux<LeaderEModality> getLeaderEModality(String currentUUID, int programYear) {
        LeaderPerformanceQueryBuilder.Builder b = LeaderPerformanceQueryBuilder.builder();
        b.asLeaderEModality(currentUUID);
        return client.execute(b.build())
                .as(LeaderEModality.class)
                .bind(ColumnNames.PROGRAM_YEAR.getColumnName(), programYear)
                .map((row, rowMetadata) -> LeaderEModality
                        .builder()
                        .returnNetCnaActualPer(getIntegerValue(row, "ReturnNetCnaActualPer"))
                        .retrievedByOPAF(getIntegerValue(row, "RetrievedByOPAF"))
                        .retrievedByOptumUpload(getIntegerValue(row, "RetrievedByOptumUpload"))
                        .retrievedByOgm(getIntegerValue(row, "RetrievedByOgm"))
                        .retrievedByEdata(getIntegerValue(row, "RetrievedByEdata"))
                        .updatedDate(getDateValue(row, UPDATED_DATE))
                        .build()
                )
                .all();

    }

    @Override
    public Flux<LeaderIOAPerformance> getLeaderIOAPerformance(String uuid, int programYear, List<String> clientName, List<String> lob, List<String> serviceLevel) {
        LeaderPerformanceQueryBuilder.Builder b = LeaderPerformanceQueryBuilder.builder();
        b.asLeaderIOAPerformance(clientName, lob, serviceLevel);
        return client.execute(b.build())
                .bind(ColumnNames.PROGRAM_YEAR.getColumnName(), programYear)
                .bind(ColumnNames.UUID.getColumnName(), uuid)
                .as(LeaderIOAPerformance.class)
                .map((row, rowMetadata) -> {
                    LeaderIOAPerformance.LeaderIOAPerformanceBuilder leaderBuilder =
                            buildCommonLeaderIOAPerformanceValues(row);
                    return leaderBuilder.build();
                })
                .all();
    }

    @Override
    public Flux<LeaderIOAPerformance> getLeaderIOAPerformanceRegion(String region, int programYear, int offset, int limit, List<String> clientName, List<String> lob, List<String> serviceLevel) {
        LeaderPerformanceQueryBuilder.Builder b = LeaderPerformanceQueryBuilder.builder();
        b.asLeaderIOAPerformanceRegion(clientName, lob, serviceLevel);
        return client.execute(b.build())
                .bind(ColumnNames.PROGRAM_YEAR.getColumnName(), programYear)
                .bind(ColumnNames.REGION.getColumnName(), region)
                .bind("Offset",offset)
                .bind("Limit",limit)
                .as(LeaderIOAPerformance.class)
                .map((row, rowMetadata) -> {
                    LeaderIOAPerformance.LeaderIOAPerformanceBuilder leaderBuilder =
                            buildCommonLeaderIOAPerformanceValues(row);
                    return leaderBuilder.build();
                })
                .all();
    }

    @Override
    public Mono<Long> getLeaderIOAPerformanceRegionCount(String region, int programYear, List<String> clientName, List<String> lob, List<String> serviceLevel) {
        LeaderPerformanceQueryBuilder.Builder b = LeaderPerformanceQueryBuilder.builder();
        b.asLeaderIOAPerformanceRegion(clientName, lob, serviceLevel).asCount();
        return client.execute(b.build())
                .bind(ColumnNames.PROGRAM_YEAR.getColumnName(), programYear)
                .bind(ColumnNames.REGION.getColumnName(), region)
                .as(Long.class)
                .fetch()
                .one();
    }

    @Override
    public Flux<LeaderIOAPerformance> getLeaderIOAPerformanceMyTeam(String uuid, int programYear, List<String> clientName, List<String> lob, List<String> serviceLevel) {
        LeaderPerformanceQueryBuilder.Builder b = LeaderPerformanceQueryBuilder.builder();
        b.asLeaderIOAPerformanceTeam(clientName, lob, serviceLevel);
        return client.execute(b.build())
                .bind(ColumnNames.PROGRAM_YEAR.getColumnName(), programYear)
                .bind(ColumnNames.UUID.getColumnName(), uuid)
                .as(LeaderIOAPerformanceDTO.class)
                .map((row, rowMetadata) -> {
                    LeaderIOAPerformance.LeaderIOAPerformanceBuilder leaderBuilder =
                            buildCommonLeaderIOAPerformanceValues(row);
                    return leaderBuilder
                            .firstName(getStringValue(row,"FirstName"))
                            .lastName(getStringValue(row,"LastName"))
                            .uuid(getStringValue(row,"UUID"))
                            .parentUUID(getStringValue(row, PARENT_UUID))
                            .role(getStringValue(row, "Role"))
                            .build();
                })
                .all();
    }

    private LeaderIOAPerformance.LeaderIOAPerformanceBuilder buildCommonLeaderIOAPerformanceValues(Row row) {
        return LeaderIOAPerformance.builder()
                .regionMarket(getStringValue(row,"RegionMarket"))
                .pctToDeployGoalEOY(getDoubleValue(row,"PctToDeployGoalEOY"))
                .deploymentPct(getDoubleValue(row,"DeploymentPct"))
                .pctToReturnGoalEOY(getDoubleValue(row,"PctToReturnGoalEOY"))
                .returnPct(getDoubleValue(row,"ReturnPct"))
                .rejectPct(getDoubleValue(row,"RejectPct"))
                .cGAPClosurePct(getDoubleValue(row,"CGAPClosurePct"))
                .lastUpdatedDate(getValue(row, UPDATED_DATE, java.time.LocalDateTime.class));
    }

    public Flux<String> getLeaderFilter(int programYear, String resource, String type) {
        LeaderPerformanceQueryBuilder.Builder b = LeaderPerformanceQueryBuilder.builder();
        if (type.equalsIgnoreCase(SERVICE_LEVEL)) {
            b.asLeaderServiceLevelFilter(resource);
        } else if (type.equalsIgnoreCase(CLIENT_NAME)) {
            b.asLeaderClietNameFilter(resource);
        } else if (type.equalsIgnoreCase(LOB)) {
            b.asLeaderLOBFilter(resource);
        }

        return client.execute(b.build())
                .bind(ColumnNames.PROGRAM_YEAR.getColumnName(), programYear)
                .as(String.class)
                .fetch()
                .all();
    }
  
    private String getScopeStringValue(Row row, ScopeType scopeType, boolean isParent) {
        if (scopeType == null) {
            return null;
        }
        String scopeColumn = null;
        switch (scopeType) {
            case NATIONAL:
                return isParent ? null : "National";
            case CURRENT_USER:
                scopeColumn = isParent ? PARENT_UUID : "UUID";
                break;
            case MY_TEAM:
                scopeColumn = isParent ? PARENT_UUID : "UUID";
                break;
            case REGION_AND_STATE:
                scopeColumn = isParent ? "Region" : "State";
                break;
        }
        return scopeColumn != null ? getStringValue(row, scopeColumn) : null;
    }

    private Boolean getBooleanValue(Row row, String columnName) {
        return getValue(row, columnName, Boolean.class);
    }

    private LocalDateTime getDateValue(Row row, String columnName) { return getValue(row, columnName, LocalDateTime.class);  }

    private String getStringValue(Row row, String columnName) {
        return getValue(row, columnName, String.class);
    }

}
