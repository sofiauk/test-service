package com.optum.rqns.ftm.model.opportunities.exports;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ExportsRequest {
    private String processName;
    private String processSubType;
    private String exportType;
    private String submittedBy;
    private String traceId;
    private String requestPayLoad;
    private int recordsCount;
    private int programYear;
    private String status;
    private boolean isRead;
    private boolean isDeleted;
    private boolean isCancelled;
    private boolean deletedByUser;
    private boolean cancelledByUser;
    private boolean isNotified;
    private Long fileSize;
    private String documentType;
    private boolean isActive;
    private int timeTakenInMilliSeconds;
    private String createdBy;
    private LocalDateTime createdDate;
    private String updatedBy;
    private LocalDateTime updatedDate;
    private String messageId;
}
