package com.optum.rqns.ftm.dto.qfo.converter;

import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.dto.qfo.QFOPatientsCoveredDTO;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.ReadingConverter;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@Component
@ReadingConverter
public class QFOPatientsCoveredDTOConverter implements Converter<Row, QFOPatientsCoveredDTO>, DTOWrapperTypeConverter {

	@Override
	public QFOPatientsCoveredDTO convert(Row row) {
		List<LocalDateTime> lastUpdatedDates = Arrays.asList(
				getValue(row, "LastPatientUpdatedDate", LocalDateTime.class),
				getValue(row, "LastRiskQualityUpdatedDate", LocalDateTime.class));
		Optional<LocalDateTime> lastUpdatedDate = lastUpdatedDates.stream()
				.filter(localDateTime -> localDateTime != null)
				.max(LocalDateTime::compareTo);
		return QFOPatientsCoveredDTO.builder()
				.patients(getIntegerValue(row, "PatientCount"))
				.qualityGaps(getIntegerValue(row, "QualityGapCount"))
				.openSuspects(getIntegerValue(row, "OpenSuspectCount"))
				.lastUpdatedDate(lastUpdatedDate.isPresent() ? lastUpdatedDate.get() : null)
				.build();
	}
}
