package com.optum.rqns.ftm.dto.goals.client.converter;

import com.optum.rqns.ftm.dto.goals.client.LobDTO;
import com.optum.rqns.ftm.repository.goals.client.ClientGoalsReactiveRepositoryImpl.ColumnNames;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;

public class LobClientConverter implements Converter<Row, LobDTO> {
    @Override
    public LobDTO convert(Row rs) {
        return LobDTO.builder()
                .lobId(rs.get(ColumnNames.LOBID.getColumnName(), Integer.class))
                .lobName(rs.get(ColumnNames.LOBNAME.getColumnName(), String.class))
                .build();
    }
}
