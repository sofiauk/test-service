package com.optum.rqns.ftm.repository.qfo;

import com.optum.rqns.ftm.constants.ProviderGroupConstants;
import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.dto.qfo.PEQuestionConfigurationDTO;
import com.optum.rqns.ftm.dto.qfo.PatientExpScoreDTO;
import com.optum.rqns.ftm.dto.qfo.RatingDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Repository
public class PatientExpScoreRepositoryImpl implements PatientExpScoreRepository, DTOWrapperTypeConverter {

    @Autowired
    private DatabaseClient client;

    public static final String  CATEGORY_MASTER_CONFIGURATION_MAPPING_QUERY="SELECT  NAME,  [KEY],  [VALUE] FROM  PROGPERF.CATEGORYMASTERCONFIGURATION CMC WHERE  DESCRIPTION = 'PATIENT EXPERIENCE'  AND ISACTIVE = 1";

    public static final String PATIENT_EXPERIENCE_SCORE_QUERY="SELECT  " +
            " TOP 1 GNCRATE,  " +
            " COORATE,  " +
            " DPCRATE,  " +
            " SCOREQUESTION1,  " +
            " SCOREQUESTION2,  " +
            " SCOREQUESTION3,  " +
            " SCOREQUESTION4,  " +
            " SCOREQUESTION5,  " +
            " SCOREQUESTION6,  " +
            " SCOREQUESTION8,  " +
            " SCOREQUESTION9,  " +
            " SCOREQUESTION10, " +
            " UPDATEDDATE " +
            "FROM  " +
            " PROGPERF.PATIENTEXPERIENCESCORE PES  " +
            "WHERE  " +
            " HEALTHORGID =:PROVIDERGROUPID  " +
            " AND HEALTHORGIDTYPE = :HEALTHSYSTEMIDTYPE  " +
            " AND PROGRAMYEAR =:programYear " +
            "ORDER BY  " +
            " RPT_MO_KEY DESC";

    private static final String FETCH_RATINGS =
            "SELECT " +
            "   srgp3.OverallStarRating, " +
            "   pes2.GettingNeededCare, " +
            "   pes2.CareCoordination, " +
            "   pes2.DoctorConversations, " +
            "   (  " +
            "   SELECT " +
            "       Max(UpdatedDate) " +
            "   FROM " +
            "       ( " +
            "       VALUES ( " +
            "           MAX(pes2.UpdatedDate) " +
            "       ), " +
            "       ( " +
            "           MAX(srgp3.UpdatedDate) " +
            "       ) " +
            "       ) AS LastUpdatedDate(UpdatedDate) " +
            "   ) AS LastUpdatedDate " +
            "FROM " +
            "   ( " +
            "       SELECT " +
            "           CAST(AVG(srgp.OverallRating) AS Float) AS OverallStarRating, " +
            "           MAX(srgp.UpdatedDate) AS UpdatedDate " +
            "       FROM " +
            "           ProgPerf.StarRatingGlidePath srgp " +
            "       WHERE " +
            "           srgp.ProgramYear = :programYear " +
            "           AND srgp.GroupId IN ( " +
            "               SELECT DISTINCT " +
            "                   GroupId " +
            "               FROM  " +
            "                   ProgPerf.UHCProviderGroupOwnership ugo " +
            "               WHERE  " +
            "                   ugo.OwnerUUID = :uuid " +
            "                   AND IsDeleted = 0 " +
            "           )  " +
            "           AND srgp.CreatedDate = ( " +
            "               SELECT " +
            "                   MAX(srgp2.CreatedDate) " +
            "               FROM " +
            "                   ProgPerf.StarRatingGlidePath srgp2 " +
            "               WHERE " +
            "                   srgp.GroupId = srgp2.GroupId " +
            "           ) " +
            "   ) srgp3, " +
            "   ( " +
            "       SELECT " +
            "           CAST(AVG(pes.GncRate) AS Float) AS GettingNeededCare, " +
            "           CAST(AVG(pes.CooRate) AS Float) AS CareCoordination, " +
            "           CAST(AVG(pes.DpcRate) AS Float) AS DoctorConversations, " +
            "           MAX(pes.UpdatedDate) AS UpdatedDate " +
            "       FROM " +
            "           ProgPerf.PatientExperienceScore pes " +
            "       WHERE " +
            "           pes.HealthOrgIdType = 'PG' " +
            "           AND pes.ProgramYear = :programYear " +
            "           AND pes.HealthOrgId IN ( " +
            "               SELECT DISTINCT " +
            "                   GroupId " +
            "               FROM " +
            "                   ProgPerf.UHCProviderGroupOwnership ugo " +
            "               WHERE " +
            "                   ugo.OwnerUUID = :uuid " +
            "                   AND IsDeleted = 0 " +
            "           ) " +
            "   ) pes2 " +
            "GROUP BY " +
            "   srgp3.OverallStarRating, " +
            "   pes2.GettingNeededCare, " +
            "   pes2.CareCoordination, " +
            "   pes2.DoctorConversations";

    @Override
    public Flux<PEQuestionConfigurationDTO> getQuestionMapping(){
        return client.execute(CATEGORY_MASTER_CONFIGURATION_MAPPING_QUERY)
                .as(PEQuestionConfigurationDTO.class)
                .fetch()
                .all();
    }

    @Override
    public Mono<PatientExpScoreDTO> getPatientExpScoreDetails(String groupId, int programYear,String healthOrgIdType){
        return client.execute(PATIENT_EXPERIENCE_SCORE_QUERY)
                .bind(ProviderGroupConstants.PROGRAM_YEAR,programYear)
                .bind(ProviderGroupConstants.PROVIDER_GROUP_ID, groupId)
                .bind(ProviderGroupConstants.HEALTH_SYSTEM_ID_TYPE,healthOrgIdType)
                .as(PatientExpScoreDTO.class)
                .fetch()
                .one();
    }

    @Override
    public Mono<RatingDTO> getOverallRatingsByUUID(String uuid, int programYear) {
        return client.execute(FETCH_RATINGS)
                .bind(ProviderGroupConstants.PROGRAM_YEAR, programYear)
                .bind(ProviderGroupConstants.UUID, uuid)
                .as(RatingDTO.class)
                .fetch()
                .one();
    }
}
