package com.optum.rqns.ftm.dto.qfo.converter;

import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.dto.qfo.PatientExpScoreDTO;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class PatientExpScoreDTOConverter implements Converter<Row, PatientExpScoreDTO>, DTOWrapperTypeConverter {

    @Override
    public PatientExpScoreDTO convert(Row row) {
        return PatientExpScoreDTO.builder()
                .gncRate(getFloatValue(row,"GNCRATE"))
                .cooRate(getFloatValue(row,"COORATE"))
                .dpcRate(getFloatValue(row,"DPCRATE"))
                .scoreQuestion1(getFloatValue(row,"SCOREQUESTION1"))
                .scoreQuestion2(getFloatValue(row,"SCOREQUESTION2"))
                .scoreQuestion3(getFloatValue(row,"SCOREQUESTION3"))
                .scoreQuestion4(getFloatValue(row,"SCOREQUESTION4"))
                .scoreQuestion5(getFloatValue(row,"SCOREQUESTION5"))
                .scoreQuestion6(getFloatValue(row,"SCOREQUESTION6"))
                .scoreQuestion8(getFloatValue(row,"SCOREQUESTION8"))
                .scoreQuestion9(getFloatValue(row,"SCOREQUESTION9"))
                .scoreQuestion10(getFloatValue(row,"SCOREQUESTION10"))
                .updatedDate(getValue(row,"UPDATEDDATE",LocalDateTime.class).format(DateTimeFormatter.ofPattern("dd MMM yyyy")))
                .build();
    }
}
