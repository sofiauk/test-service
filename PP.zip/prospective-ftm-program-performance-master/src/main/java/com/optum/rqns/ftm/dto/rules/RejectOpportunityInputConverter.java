package com.optum.rqns.ftm.dto.rules;

import com.optum.rqns.ftm.model.rules.RejectOpportunityInput;
import com.optum.rqns.ftm.repository.rules.RuleRepositoryImpl;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;

public class RejectOpportunityInputConverter implements Converter<Row, RejectOpportunityInput> {
    @Override
    public RejectOpportunityInput convert(Row rs) {
        return RejectOpportunityInput.builder()
                .projectYear(rs.get(RuleRepositoryImpl.ColumnNames.PROJECT_YEAR.getColumnName(),Integer.class))
                .providerGroupId(rs.get(RuleRepositoryImpl.ColumnNames.PROVIDERGROUPID.getColumnName(),String.class))
                .providerState(rs.get(RuleRepositoryImpl.ColumnNames.PROVIDER_STATE.getColumnName(),String.class))
                .serviceLevel(rs.get(RuleRepositoryImpl.ColumnNames.SERVICELEVEL.getColumnName(),String.class))
                .providerGroupName(rs.get(RuleRepositoryImpl.ColumnNames.PROVIDERGROUPNAME.getColumnName(),String.class))
                .client(rs.get(RuleRepositoryImpl.ColumnNames.CLIENT.getColumnName(),String.class))
                .lobName(rs.get(RuleRepositoryImpl.ColumnNames.LOB.getColumnName(),String.class))
                .singleRejectReason(rs.get(RuleRepositoryImpl.ColumnNames.SINGLE_REJECT_REASON.getColumnName(),String.class))
                .chartID(rs.get(RuleRepositoryImpl.ColumnNames.CHARTID.getColumnName(),String.class))
                .overAllStatus(rs.get(RuleRepositoryImpl.ColumnNames.OVERALL_STATUS.getColumnName(),String.class))
                .build();
    }
}
