package com.optum.rqns.ftm.constants;

public final class RuleConstants {
    private RuleConstants(){}

    public static final String PROGRAM_YEAR = "ProgramYear";
    public static final String PREVIOUS_PROGRAM_YEAR = "PreviousProgramYear";
    public static final String SERVICE_LEVEL = "ServiceLevel";
    public static final String PROJECT_ID_TYPE = "ProjectIDType";
    public static final String OVER_ALL_STATUS_IN = "OverAllStatusIn";
    public static final String OVER_ALL_STATUS_NOT_IN = "OverAllStatusNotIn";
    public static final String LOBS = "LOB";
    public static final String REJECT_LAST_RUN_DATE = "Rejects";
    public static final String RETURN_LAST_RUN_DATE = "Returns";
    public static final String FINANCIAL_INFORMATION_LAST_RUN_DATE = "Financial Information";
    public static final String DEPLOYMENTS_LAST_RUN_DATE = "Deployments";
    public static final String LOAD_LOB_TARGET_VALUES_AND_ACTUALS = "Actuals";
    public static final String OVERLAP_ENABLED_FOR_REJECTS = "OverlapEnabledForRejects";
    public static final String OVERLAP_ENABLED_FOR_OUTLIERS = "OverlapEnabledForOutliers";
    public static final String ACTIVE = "Active";


    public static final String SYSTEM = "System";

    public static final String SUMMARY = "summary";
    public static final String DETAIL = "detail";
    public static final String SUMMARY_LIST = "summaryList";
    public static final String DETAIL_LIST = "detailList";
    public static final String ASSESSMENTS = "assessments";
    public static final String DEFAULT_STRING = "default";
    public static final String WEEK_START_NUMBER = "_WEEK1";


    public static final String ISSECONDARYSUBMISSIONELIGIBLE = "yes";
    public static final String OUTLIERS = "Outliers";
    public static final String ALL = "All";
    public static final String RULES_XLSX_FILE_NAME = "Rules.xlsx";
    public static final String SECONDARY_SUBMISSION_NO_SPACE = "SecondarySubmission";
    public static final String FINANCIAL_INFORMATION_NO_SPACE = "FinancialInformation";

    public static final String NOT_APPLICABLE = "NA";
    public static final String DELETED = "Deleted";

    public static final String PROVIDERGROUPOPPORTUNITIESSUMMARY = "PROVIDERGROUPOPPORTUNITIESSUMMARY";
    public static final String PROVIDERGROUPOPPORTUNITIESDETAIL = "PROVIDERGROUPOPPORTUNITIESDETAIL";
    public static final String MEMBERASSESSMENTOPPORTUNITY = "MEMBERASSESSMENTOPPORTUNITY";

    public static final String LAST_SUCCESSFUL_RUN_DATE = "LastSuccessfulRunDate";
    public static final String DURATIONVALUE = "DurationValue";
    public static final String CURRENTPROGRAMYEAR = "CurrentProgramYear ";
    public static final String STARTDATE = "StartDate ";
    public static final String ENDDATE = "EndDate ";

    public static final String OPPORTUNITY="Opportunity";

}
