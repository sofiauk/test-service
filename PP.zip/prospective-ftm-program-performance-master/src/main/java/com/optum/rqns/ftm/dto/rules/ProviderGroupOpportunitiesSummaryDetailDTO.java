package com.optum.rqns.ftm.dto.rules;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.time.LocalDateTime;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ProviderGroupOpportunitiesSummaryDetailDTO {

    int opportunityID;
    String providerGroupID;
    String providerGroupName;
    String state;
    int programYear;
    String masterOpportunityType;
    int masterOpportunityTypePosition;
    int totalAssessmentsCount;
    int totalClientsCount;
    int totalGapsCount;
    String createdBy;
    LocalDateTime createdDate;
    String rowAction;
    // details section
    int opportunityDetailID;
    String serviceLevel;
    String clientId;
    String clientName;
    String lobName;
    String opportunityType;
    String opportunitySubType;
    int opportunityTypePosition;
    int opportunitySubTypePosition;
    LocalDateTime latestUpdatedDate;
    String displayText;
    int assessmentCount;
    int deploymentCount;
    int gapCount;
}
