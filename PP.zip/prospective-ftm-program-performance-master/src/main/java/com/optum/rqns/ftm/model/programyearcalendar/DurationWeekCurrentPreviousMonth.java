package com.optum.rqns.ftm.model.programyearcalendar;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DurationWeekCurrentPreviousMonth {
    private String currentWeek; //ProgramYearCalendar - current week
    private String lastWeekPreviousMonth; //ProgramYearCalendar - last week of previous month
}
