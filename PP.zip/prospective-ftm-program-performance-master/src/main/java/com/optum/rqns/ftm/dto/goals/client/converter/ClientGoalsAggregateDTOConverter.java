package com.optum.rqns.ftm.dto.goals.client.converter;

import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.dto.goals.client.ClientGoalsAggregateDTO;
import com.optum.rqns.ftm.model.goals.client.SnapshotValues;
import com.optum.rqns.ftm.repository.goals.client.ClientGoalsReactiveRepositoryImpl.ColumnNames;
import com.optum.rqns.ftm.util.ClientGoalsUtil;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;

public class ClientGoalsAggregateDTOConverter implements Converter<Row, ClientGoalsAggregateDTO>, DTOWrapperTypeConverter {

    public ClientGoalsAggregateDTO convert(Row resultSet) {

        final Double deployValue = getDoubleValue(resultSet, ColumnNames.DEPLOYED.getColumnName());
        final Double returnValue = getDoubleValue(resultSet, ColumnNames.RETURNED.getColumnName());
        final Double completedValue = getDoubleValue(resultSet, ColumnNames.COMPLETED.getColumnName());
        final Long secondarySubmission = getLongValue(resultSet, ColumnNames.SECONDARYSUBMISSION.getColumnName());

        return ClientGoalsAggregateDTO.builder()
                .programYear(getPrimitiveIntegerValue(resultSet, ColumnNames.PROGRAMYEAR.getColumnName()))
                .snapshotValues(
                        SnapshotValues.builder()
                                .deployValue(deployValue)
                                .eligibleMembers(getDoubleValue(resultSet, ColumnNames.ELIGIBLEMEMBERS.getColumnName()))
                                .deployPercentage(ClientGoalsUtil.getWrapperPercentageValue(deployValue, getDoubleValue(resultSet, ColumnNames.ELIGIBLEMEMBERS.getColumnName())))
                                .returnValue(returnValue)
                                .returnPercentage(ClientGoalsUtil.getWrapperPercentageValue(returnValue, deployValue))
                                .completedValue(completedValue)
                                .completedPercentage(ClientGoalsUtil.getWrapperPercentageValue(completedValue, returnValue))
                                .secondarySubmissionValue(secondarySubmission)
                                .secondarySubmissionPercentage(ClientGoalsUtil.getWrapperPercentageValue(secondarySubmission, returnValue))
                                .riskGapAssessmentPercentage(getDoublePercentageValue(resultSet, ColumnNames.GARISK.getColumnName()))
                                .qualityGapAssessmentPercentage(getDoublePercentageValue(resultSet, ColumnNames.GAQUALITY.getColumnName()))
                                .riskDocumentVerificationPercentage(getDoublePercentageValue(resultSet, ColumnNames.DVRISK.getColumnName()))
                                .qualityDocumentVerificationPercentage(getDoublePercentageValue(resultSet, ColumnNames.DVQUALITY.getColumnName()))
                                .riskGapClosurePercentage(getDoublePercentageValue(resultSet, ColumnNames.RISKGAPCLOSURE.getColumnName()))
                                .diagnosedVerifiedPercentage(getDoublePercentageValue(resultSet, ColumnNames.DIAGNOSEDVERIFIED.getColumnName()))
                                .build()
                )
                .build();
    }
}