package com.optum.rqns.ftm.response.opportunities.providergrp;

import com.optum.rqns.ftm.model.opportunities.providergrp.QFOHealthSystemOpportunitiesDetails;
import com.optum.rqns.ftm.wrapper.Meta;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.ToString;

import java.util.ArrayList;
import java.util.List;

@Data
@ToString
@AllArgsConstructor
@Builder
public class QFOHealthSystemOpportunitiesDetailsResponse {
    private Meta meta;

    private List<QFOHealthSystemOpportunitiesDetails> data;

    public QFOHealthSystemOpportunitiesDetailsResponse() {
        this.meta = new Meta();
        this.data = new ArrayList<>();
    }
}
