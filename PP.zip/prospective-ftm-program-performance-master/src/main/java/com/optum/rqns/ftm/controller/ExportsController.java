package com.optum.rqns.ftm.controller;


import com.optum.rqns.common.export.model.AddExportResponse;
import com.optum.rqns.common.export.model.ExportDetails;
import com.optum.rqns.common.export.model.ExportInfo;
import com.optum.rqns.common.export.model.ExportRequest;
import com.optum.rqns.common.export.service.ExportRequestService;
import com.optum.rqns.ftm.constants.FTMHeaders;
import com.optum.rqns.ftm.constants.FTMParams;
import com.optum.rqns.ftm.customannotation.CustomApiResponse;
import com.optum.rqns.ftm.enums.DocumentType;
import com.optum.rqns.ftm.enums.ExportStatus;
import com.optum.rqns.ftm.enums.ProcessSubType;
import com.optum.rqns.ftm.enums.ProcessType;
import com.optum.rqns.ftm.enums.TypeEnum;
import com.optum.rqns.ftm.exception.APIErrorCode;
import com.optum.rqns.ftm.exception.ApiError;
import com.optum.rqns.ftm.exception.ProgramPerformanceException;
import com.optum.rqns.ftm.model.UserInfo;
import com.optum.rqns.ftm.response.exports.ExportDetailsResponse;
import com.optum.rqns.ftm.response.exports.ExportNotificationResponse;
import com.optum.rqns.ftm.response.exports.ExportTransactionResponse;
import com.optum.rqns.ftm.util.ProgramPerformanceUtil;
import com.optum.rqns.ftm.util.StargateStandardResponseUtilV2;
import com.optum.rqns.ftm.wrapper.Meta;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.nio.ByteBuffer;
import java.util.Map;
import java.util.Objects;

@Profile("exportRequest")
@Log4j2
@RestController
@RequestMapping("/v1/exports")
@CustomApiResponse
public class ExportsController {


    @Autowired
    private ExportRequestService exportRequestService;

    @Autowired
    StargateStandardResponseUtilV2<Object, Object> stargateStandardResponseUtilV2;

    public class ExportDetailsWrapper extends ExportDetailsResponse<ExportDetails>{}
    @GetMapping()
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Success Request",
                    content = @Content(schema = @Schema(implementation = ExportDetailsWrapper.class),
                            mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "400", description = "Error Response",
                    content = @Content(schema = @Schema(implementation = ApiError.class),
                            mediaType = MediaType.APPLICATION_PROBLEM_JSON_VALUE))
    })
    public Mono<ExportDetailsResponse<ExportDetails>> getExports(
            @RequestParam(name = FTMParams.PROCESS_TYPE, required = false) String stringProcessType,
            @RequestParam(name = FTMParams.PROCESS_SUB_TYPE, required = false) String stringProcessSubType,
            @RequestParam(name = FTMParams.DOCUMENT_TYPE, required = false) String stringDocumentType,
            @RequestHeader(value = FTMHeaders.X_USER_DETAILS, required = true) String userDetailsJson,
            @RequestHeader(value = FTMHeaders.X_TRACE_ID, required = false) String traceId
    ) {
        log.info("TraceId :: {} Getting exports : {}, {} , {}, {} ", traceId, stringProcessType, stringProcessSubType, stringDocumentType, userDetailsJson);
        UserInfo userInfo = (UserInfo) ProgramPerformanceUtil.jsonToPojo(userDetailsJson, UserInfo.class);
        ProcessType processType = null;
        ProcessSubType processSubType = null;
        DocumentType documentType = null;

        if (Objects.nonNull(stringProcessType)) {
            processType = ProcessType.fromString(stringProcessType);
            if (Objects.isNull(processType)) {
                log.error("TraceId :: {} Invalid Process type : {}", traceId, stringProcessType);
                return Mono.error(new ProgramPerformanceException(HttpStatus.OK, APIErrorCode.INVALID_PROCESS_TYPE));
            }
        }else{
            throw new ProgramPerformanceException(HttpStatus.BAD_REQUEST, APIErrorCode.INVALID_PROCESS_TYPE);
        }
        if (Objects.nonNull(stringProcessSubType)) {
            processSubType = ProcessSubType.fromString(stringProcessSubType);
            if (Objects.isNull(processSubType)) {
                log.error("TraceId :: {} Invalid Process Sub type : {}", traceId, stringProcessSubType);
                return Mono.error(new ProgramPerformanceException(HttpStatus.OK, APIErrorCode.INVALID_PROCESS_SUB_TYPE));
            }
        }else{
            throw new ProgramPerformanceException(HttpStatus.BAD_REQUEST, APIErrorCode.INVALID_PROCESS_SUB_TYPE);
        }
        if (Objects.nonNull(stringDocumentType)) {
            documentType = DocumentType.fromString(stringDocumentType);
            if (Objects.isNull(documentType)) {
                log.error("TraceId :: {} Invalid Document type : {}", traceId, stringDocumentType);
                return Mono.error(new ProgramPerformanceException(HttpStatus.OK, APIErrorCode.INVALID_DOCUMENT_TYPE));
            }
        }else{
            throw new ProgramPerformanceException(HttpStatus.BAD_REQUEST, APIErrorCode.INVALID_DOCUMENT_TYPE);

        }

        Meta meta = new Meta();
        return Flux.fromIterable(exportRequestService.getExports(traceId, userInfo.getUuid(), processType.getValue(), processSubType.getValue(), documentType.getValue()))
                .collectList().map(list -> ExportDetailsResponse.<ExportDetails>builder().data(list).meta(meta).build());
    }
    @DeleteMapping("/exports-deletes/{export-id}")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Success Request",
                    content = @Content(schema = @Schema(implementation = ExportTransactionResponse.class),
                            mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "400", description = "Error Response",
                    content = @Content(schema = @Schema(implementation = ApiError.class),
                            mediaType = MediaType.APPLICATION_PROBLEM_JSON_VALUE))})
    public Mono<ExportTransactionResponse> deleteExportedFile(
            @PathVariable(FTMParams.EXPORT_ID) long transactionId,
            @RequestHeader(FTMHeaders.X_USER_DETAILS) String userDetailsJson,
            @RequestHeader(value = FTMHeaders.X_TRACE_ID, required = false) String traceId
    ) {
        log.info("TraceId :: {} Delete Exported File for the given transaction : {} , {}", traceId, transactionId, userDetailsJson);

        if (Objects.isNull(traceId)) {
            throw new ProgramPerformanceException(HttpStatus.NOT_FOUND, APIErrorCode.INVALID_TRACE_ID);
        }
        return stargateStandardResponseUtilV2
                .generateStargateStandardResponse(
                        Mono.just(exportRequestService.deleteExport(traceId,transactionId))
                        , TypeEnum.MONO
                        , new ExportTransactionResponse<Boolean>())
                .cast(ExportTransactionResponse.class);
    }

    @PostMapping("/posts")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "202", description = "Success Request", content = @Content(schema = @Schema(implementation = ExportTransactionResponse.class), mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "400", description = "Error Response", content = @Content(schema = @Schema(implementation = ApiError.class), mediaType = MediaType.APPLICATION_PROBLEM_JSON_VALUE)) })
    public Mono<ExportTransactionResponse> addExportRequest(@RequestBody(required = true) ExportRequest exportRequest,
                                                                    @RequestHeader(FTMHeaders.X_USER_DETAILS) String userDetailsJson,
                                                                    @RequestHeader(value = FTMHeaders.X_TRACE_ID, required = false) String traceId, ServerHttpResponse serverHttpResponse) {

        com.optum.rqns.common.export.model.UserInfo userInfo = (com.optum.rqns.common.export.model.UserInfo) ProgramPerformanceUtil.jsonToPojo(userDetailsJson,
                com.optum.rqns.common.export.model.UserInfo.class);
        log.info("TraceId :: {} Adding export request : {}, {} , {} ", traceId, userInfo, exportRequest);

        if (Objects.isNull(traceId)) {
            throw new ProgramPerformanceException(HttpStatus.BAD_REQUEST, APIErrorCode.INVALID_TRACE_ID);
        }
        exportRequest.setTraceId(traceId);
        exportRequest.setOffshoreRestricted(false);


        return stargateStandardResponseUtilV2
                .generateStargateStandardResponse(
                        Mono.just(exportRequestService.addExportRequest(exportRequest, userInfo))
                        , TypeEnum.MONO
                        , new ExportTransactionResponse<AddExportResponse>())
                .cast(ExportTransactionResponse.class);
    }

    @GetMapping("/downloads")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "202", description = "Success Request", content = @Content(schema = @Schema(implementation = ResponseEntity.class))),
            @ApiResponse(responseCode = "400", description = "Error Response", content = @Content(schema = @Schema(implementation = ApiError.class), mediaType = MediaType.APPLICATION_PROBLEM_JSON_VALUE)) })
    public Mono<ResponseEntity<ByteBuffer>> download(
            @RequestHeader(FTMHeaders.X_USER_DETAILS) String userDetailsJson,
            @RequestHeader(value = FTMHeaders.X_TRACE_ID, required = false) String traceId,
            @RequestParam(required = true,value ="fileName") String fileName,
            @RequestParam(required = true,value ="exportRequestId") int exportRequestId) {

        log.info("TraceId :: {} Downloading File : {}, ExportRequestId: {} ", traceId, fileName, exportRequestId);
        UserInfo userInfo = (UserInfo) ProgramPerformanceUtil.jsonToPojo(userDetailsJson, UserInfo.class);
        return Mono.fromFuture(exportRequestService.downloadFile(fileName, exportRequestId, userInfo.getUuid()))
                .onErrorMap(exception -> {
                    log.info("exception while downloading", exception);
                    return new ProgramPerformanceException(HttpStatus.INTERNAL_SERVER_ERROR, APIErrorCode.DOWNLOAD_FAILED);
                })
                .map(objectStorageFile ->
                        ResponseEntity.ok()
                                .header(HttpHeaders.CONTENT_TYPE, objectStorageFile.getContentType())
                                .header(HttpHeaders.CONTENT_LENGTH, Long.toString(objectStorageFile.getContentLength()))
                                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileName + "\"")
                                .body(objectStorageFile.getContent()));
    }
    private class ExportInfoWrapper extends ExportNotificationResponse<ExportInfo>{}
    @GetMapping("/notifications")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Success Request",
                    content = @Content(schema = @Schema(implementation = ExportInfoWrapper.class),
                            mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "400", description = "Error Response",
                    content = @Content(schema = @Schema(implementation = ApiError.class),
                            mediaType = MediaType.APPLICATION_PROBLEM_JSON_VALUE))})
    public Mono<ExportNotificationResponse<ExportInfo>> getExportNotifications(
            @RequestParam(name = FTMParams.EXPORT_STATUS, required = true) String stringExportStatus,
            @RequestHeader(FTMHeaders.X_USER_DETAILS) String userDetailsJson,
            @RequestHeader(value = FTMHeaders.X_TRACE_ID, required = false) String traceId
    ) {
        log.info("TraceId :: {} Getting Export notifications started {} ExportStatus {}", traceId, userDetailsJson, stringExportStatus);
        UserInfo userInfo = (UserInfo) ProgramPerformanceUtil.jsonToPojo(userDetailsJson, UserInfo.class);
        ExportStatus exportStatus = ExportStatus.fromString(stringExportStatus);
        if (!ExportStatus.NON_NOTIFIED.equals(exportStatus)|| Objects.isNull(exportStatus)) {
            throw new ProgramPerformanceException(HttpStatus.BAD_REQUEST, APIErrorCode.INVALID_TRACE_ID);
        }

        Meta meta = new Meta();
        return Flux.fromIterable(exportRequestService.getExportNotifications(userInfo.getUuid(), traceId, exportStatus.getValue()))
                .collectList().map(list -> ExportNotificationResponse.<ExportInfo>builder().meta(meta).data(list).build());
    }

    @PutMapping("/exports-updates/{export-id}")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "202", description = "Success Request",
                    content = @Content(schema = @Schema(implementation = ExportTransactionResponse.class),
                            mediaType = MediaType.APPLICATION_JSON_VALUE)),
            @ApiResponse(responseCode = "400", description = "Error Response",
                    content = @Content(schema = @Schema(implementation = ApiError.class),
                            mediaType = MediaType.APPLICATION_PROBLEM_JSON_VALUE))})
    public Mono<ExportTransactionResponse> updateExportTransaction(
            @PathVariable(FTMParams.EXPORT_ID) int transactionId,
            @RequestHeader(FTMHeaders.X_USER_DETAILS) String userDetailsJson,
            @RequestHeader(value = FTMHeaders.X_TRACE_ID, required = false) String traceId,
            @RequestBody Map<String, Object> payload
    ) {

        ExportStatus exportStatus = ExportStatus.fromString(String.valueOf(payload.get("exportStatus")));
        if (Objects.isNull(traceId)) {
            throw new ProgramPerformanceException(HttpStatus.NOT_FOUND, APIErrorCode.INVALID_TRACE_ID);
        }
        return stargateStandardResponseUtilV2
                .generateStargateStandardResponse(
                        Mono.just(exportRequestService.updateExport(traceId, transactionId, exportStatus.getValue()))
                        , TypeEnum.MONO
                        , new ExportTransactionResponse())
                .cast(ExportTransactionResponse.class);
    }

}
