package com.optum.rqns.ftm.dto.opportunities.providergrp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MeasuresThresholdConfigurationDTO {
    private String measureId;
    private int programYear;
    private int starsThreshold1;
    private int starsThreshold2;
    private int starsThreshold3;
    private int starsThreshold4;
    private int starsThreshold5;
}
