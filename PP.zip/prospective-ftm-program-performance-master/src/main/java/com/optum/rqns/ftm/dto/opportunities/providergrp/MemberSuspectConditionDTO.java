package com.optum.rqns.ftm.dto.opportunities.providergrp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MemberSuspectConditionDTO {
    private String programYear;
    private String patientCardId;
    private String patientFirstName;
    private String patientLastName;
    private LocalDate patientDOB;
    private String gender;
    private String insuranceCarrier;
    private String carePriorityGroup;
    private String condition;
    private String suspectDetails;
    private LocalDate suspectConditionDateAdded;
    private String disposition;
    private LocalDate dateOfAssessment;
    private String lob;
    private String primaryCareProviderName;
    private String pcpNpi;
    private LocalDate annualCareVisitDate;
    private LocalDate houseCallsVisitDate;
    private String incentiveProgram;
    private String highPriorityPatient;
}
