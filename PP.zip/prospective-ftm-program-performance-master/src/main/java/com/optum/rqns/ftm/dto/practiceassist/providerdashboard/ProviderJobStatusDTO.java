package com.optum.rqns.ftm.dto.practiceassist.providerdashboard;

import lombok.Data;

@Data
public class ProviderJobStatusDTO {

    private String mbrSummary;
    private String mbrHospitalEvents;
    private String mbrQuality;
    private String mbrSuspect;
    private String mbrMedAdherence;
    private Boolean isForceRefresh;

}
