package com.optum.rqns.ftm.dto.providergrp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ProviderGroupDTO {
    private String providerGroupId;
    private String state;
    private boolean isNewForDeployment;
    private Double eligiblePreferredMembers;
    private int programYear;
}