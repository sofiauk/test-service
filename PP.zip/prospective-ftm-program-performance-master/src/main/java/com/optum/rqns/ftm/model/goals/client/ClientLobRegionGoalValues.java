package com.optum.rqns.ftm.model.goals.client;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ClientLobRegionGoalValues {
    private String regionName;
    private String regionId;
    private boolean isClientRegion;
    private int stateCount;
    @JsonProperty("aggregate")
    private GoalDetailValues goalDetailValues;
    @JsonProperty("states")
    private List<ClientLobStateGoalValues> clientLobStateGoalValues;
}
