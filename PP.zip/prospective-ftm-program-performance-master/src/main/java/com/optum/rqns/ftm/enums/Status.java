package com.optum.rqns.ftm.enums;

public enum Status {
    SUCCESS("Success"),
    IN_PROGRESS("InProgress"),
    STARTED("Started"),
    FAILURE("Failure");

    private String value;

    Status(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public static Status fromString(String text){
        for (Status status : Status.values()) {
            if (status.value.equalsIgnoreCase(text)) {
                return status;
            }
        }
        return null;
    }

}
