
package com.optum.rqns.ftm.model.performance.providergrp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AssignedProviderGroupPerformance {
    private String uuid;
    private Long deploymentYtdActual;
    private Long returnYtdActual;
    private Long returnCNAYtdActual;
    private Long returnedNetCnaYtdActual;
    private Long returnYtdTarget;
    private Long returnYeTarget;
    private Long rejects;
    private Double annualReturnPerformance;
    private Double returnPerformanceToTarget;
    private Double returnRate;
    private Double rejectRate;
    private String lastUpdated;
    private int programYear;
    private Long deployYtdTarget;
    private Double deployPerformanceToTarget;
    private Double annualDeployPerformance;
    private Long deployYeTarget;
}