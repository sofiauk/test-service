package com.optum.rqns.ftm.model.goals.client;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 *  @author dvenka19
 *  This class will hold Hplans data
 *  lombok will generate getter,setter,toString,noArgsConstructor and allArgsConstructor
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ClientLobHPlanGoalValues {
    private String planName;
    @JsonProperty("aggregate")
    private GoalDetailValues goalDetailValues;
    @JsonProperty("pbp")
    private List<ClientLobPbpGoalValues> pbpGoalValues;

}
