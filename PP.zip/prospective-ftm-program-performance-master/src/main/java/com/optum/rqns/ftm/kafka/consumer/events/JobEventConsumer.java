package com.optum.rqns.ftm.kafka.consumer.events;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.rqns.ftm.dto.processor.providergrp.JobRunConfigurationDTO;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.exception.ProgramPerformanceException;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.producer.JobEventProducer;
import com.optum.rqns.ftm.model.fieldaction.JobDetails;
import com.optum.rqns.ftm.model.fieldaction.JobSequence;
import com.optum.rqns.ftm.repository.common.CommonRepository;
import com.optum.rqns.ftm.repository.jobalerts.PrometheusJobAlertRepositoryImpl;
import com.optum.rqns.ftm.service.jobalerts.PrometheusJobAlertServiceImpl;
import com.optum.rqns.ftm.service.masterconfigservice.MasterConfigService;
import com.optum.rqns.ftm.service.rules.IJob;
import com.optum.rqns.ftm.util.ProgramPerformanceUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.data.redis.connection.Message;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.lang.Nullable;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.lang.management.ManagementFactory;
import java.lang.management.RuntimeMXBean;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.UUID;
import java.util.stream.Stream;

@Profile({"rqnsFtmJobs", "rqnsFtmJobs-TargetsActuals", "rqnsFtmJobs-Rules"})
@Slf4j
public abstract class JobEventConsumer implements RedisMessageHandler{

    private IJob jobService;
    private CommonRepository commonRepository;

    @Value("${jobs.concurrencyThresholdTime}")
    public int jobConcurrencyThresholdTime; //int minutes

    private final String consumerUUID = UUID.randomUUID().toString();

    protected Boolean updateJobConfigurationOnSuccess = true;
    protected Boolean checkForDuplicateJobExecutionBasedOnThresholdTime = true;
    protected Boolean updateAffectedRowsOnSuccess = true;

    @Value("${ftm-job-alert-enabled}")
    private boolean isJobAlertEnabled; // Prometheus Custom Job Alerts
    @Value("${ftm-job-alert-exclusions}")
    private String jobAlertExclusionList; //Alerts excluded for these jobs
    @Autowired
    private PrometheusJobAlertRepositoryImpl jobAlertRepository;
    @Autowired
    private PrometheusJobAlertServiceImpl prometheusJobAlertService;

    @Autowired
    private JobEventProducer jobEventProducer;
    @Autowired
    private MasterConfigService masterConfigService;
    @Autowired
    private ObjectMapper mapper;

    public JobEventConsumer(IJob jobService, CommonRepository commonRepository) {
        this.jobService = jobService;
        this.commonRepository = commonRepository;
    }

    protected String generateTransactionId(ConsumerRecord<String, JobEvent> record) {
        String messageKey = record.key();
        String jobName = record.value().getJobName().toString();
       return generateTransactionId(jobName,messageKey);
    }

    protected String generateTransactionId(String jobName,String messageKey) {

        StringBuilder transactionIdBuilder = new StringBuilder();
        transactionIdBuilder.append(String.format("Job Name: %s | ", jobName));
        transactionIdBuilder.append(String.format("Message Key: %s | ", messageKey));
        transactionIdBuilder.append(String.format("Processor ID: %s | ", consumerUUID));
        String transactionId = transactionIdBuilder.toString();
        ProgramPerformanceUtil.TransactionIdLogger.setTransactionIdentifier(transactionId);
        ProgramPerformanceUtil.TransactionIdLogger.setMessageIdIdentifier(messageKey);

        return transactionId;
    }

    public void processMessage(int partitionId, ConsumerRecord<String, JobEvent> record, Acknowledgment acknowledgment) {
        MDC.put("messageId", record.key());
        if (record == null) {
            acknowledgment.acknowledge();
            return;
        }

        JobEvent jobEvent = record.value();

        JobName jobName = Stream.of(JobName.values())
                .filter(v -> v.getValue().equals(jobEvent.getJobName().toString()))
                .findFirst()
                .orElse(null);

        if (jobName == null) {
            acknowledgment.acknowledge();
            return;
        }

        acknowledgment.acknowledge();
        StringBuilder msgBuilder = new StringBuilder();
        msgBuilder.append(String.format("JobEvent record received from DataSync.Program.Performance.JobEvent topic and partition %d | ", partitionId));
        msgBuilder.append(String.format("with offset %s | ", record.offset()));
        this.processJobEvent(jobEvent,record.key(),msgBuilder);
    }
    public void processMessage(String event){
        JobEvent jobEvent = this.convertStringToJobEvent(event);
        if(jobEvent == null){
            return;
        }
        //TODO: add time stamp to uuid
        UUID uuid = UUID.randomUUID();
        String messageKey = uuid.toString();
        MDC.put("Redis channel", jobEvent.getJobName().toString());
        MDC.put("Generated Message Key",messageKey);
        JobName jobName = Stream.of(JobName.values())
                .filter(v -> v.getValue().equals(jobEvent.getJobName().toString()))
                .findFirst()
                .orElse(null);

        if (jobName == null) {
            return;
        }
        log.info("{} Begin Consumer Run Weekly Jobs : {}", generateTransactionId (jobEvent.getJobName().toString(),messageKey), jobEvent);

        StringBuilder msgBuilder = new StringBuilder();
        msgBuilder.append(String.format("JobEvent record received from DataSync.Program.Performance.JobEvent Redis Channel %s | ", jobEvent.getJobName().toString()));
       //msgBuilder.append(String.format("with offset %s | ", record.offset()));
        this.processJobEvent(jobEvent,messageKey,msgBuilder);
    }

    private void processJobEvent(JobEvent jobEvent,String messageKey ,StringBuilder msgBuilder){


        JobName jobName = Stream.of(JobName.values())
                .filter(v -> v.getValue().equals(jobEvent.getJobName().toString()))
                .findFirst()
                .orElse(null);

        msgBuilder.append(String.format("Job event Detail %s.", jobEvent.toString()));
        log.info(ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier().concat(msgBuilder.toString()));
        // check if given job is active
        checkIsActive(jobName.getValue()).flatMap(isActive -> {
            log.info("{} JobName : {} - isActive : {}", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier(), jobEvent.getJobName(), isActive);
            if (isActive) {
                Mono<Integer> executeOrAbort = CheckIfJobExecutionAlreadyRegistered(jobName.getValue(), messageKey, jobConcurrencyThresholdTime)
                        .flatMap(historyCount ->
                        {
                            if (historyCount > 0) {
                                log.warn("{} Another instance of this job is already running. Aborting current process.", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier());
                                return Mono.empty();
                            } else {
                                log.info("{} Update job configuration table as Job Started.", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier());
                                commonRepository.upsertJobRunConfiguration(
                                        JobRunConfigurationDTO.builder()
                                                .jobName(jobName)
                                                .updateJobEvent(true)
                                                .updateMessageKey(true)
                                                .updateMessage(true)
                                                .updateJobStart(true)
                                                .updateAffectedRows(true)
                                                .jobEvent(jobEvent.toString())
                                                .messageKey(messageKey)
                                                .message("")
                                                .createdBy("System")
                                                .modifiedBy("System")
                                                .status(Status.IN_PROGRESS)
                                                .errorMessage("")
                                                .affectedRows(0L)
                                                .build()
                                ).doOnError(err -> {
                                    log.error("{} Failed to update job configuration table. Error message: {}", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier(), err.getMessage());
                                }).flatMap(rowsUpdated -> commonRepository.getJobIdByName(jobName.getValue())
                                        .doOnError(err -> {
                                            String errorMessage = err.getMessage();
                                            log.error("{} Failed to fetch job id. Error Details: {}", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier(), errorMessage);
                                            commonRepository.upsertJobRunConfiguration(
                                                    JobRunConfigurationDTO.builder()
                                                            .jobName(jobName)
                                                            .updateJobEnd(true)
                                                            .updateJobStart(false)
                                                            .updateLastSuccessfulRun(false)
                                                            .updateLastRun(true)
                                                            .updateAffectedRows(false)
                                                            .errorMessage(jobName.getValue().concat(" has erred out with " + errorMessage))
                                                            .modifiedBy("System")
                                                            .status(Status.FAILURE)
                                                            .build()
                                            ).subscribe();
                                        })
                                        .flatMap(jobId -> {
                                            log.info("{} Adding new record into jobExecutionHistory table.", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier());
                                            return commonRepository.updateJobExecutionHistoryAsJobStart(jobId, messageKey, jobEvent.toString(), "")
                                                    .doOnError(err -> {
                                                        String errorMessage = err.getMessage();
                                                        log.error("{} Failed to add new record in job execution history. Error message: {}", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier(), errorMessage);
                                                        commonRepository.upsertJobRunConfiguration(
                                                                JobRunConfigurationDTO.builder()
                                                                        .jobName(jobName)
                                                                        .updateJobEnd(true)
                                                                        .updateJobStart(false)
                                                                        .updateLastSuccessfulRun(false)
                                                                        .updateLastRun(true)
                                                                        .updateAffectedRows(false)
                                                                        .errorMessage(jobName.getValue().concat(" has erred out " + errorMessage))
                                                                        .modifiedBy("System")
                                                                        .status(Status.FAILURE)
                                                                        .build()
                                                        ).subscribe();
                                                    })
                                                    .flatMap(execId -> jobService.executeJob(jobEvent)
                                                            .doOnError(err -> {
                                                                //ProgramPerformanceException gives null when we do err.getMessage();
                                                                //hence trying to retrieve core exception that was thrown
                                                                Throwable coreError = getCoreError(err);
                                                                String errorMessage = coreError.getMessage();
                                                                log.error("{} Exception occurred while executing JobEvent. Error: {}", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier(), coreError);
                                                                if(jobEvent.getCascadeEvents()){
                                                                    processCascadedJobs(jobEvent,true);
                                                                    log.info("processed cascade jobs on Error {}",jobEvent);

                                                                }

                                                                commonRepository
                                                                        .updateJobExecutionHistoryAsJobEnd(execId, Status.FAILURE, errorMessage, "", false, 0L)
                                                                        .subscribe();
                                                                commonRepository.upsertJobRunConfiguration(
                                                                                JobRunConfigurationDTO.builder()
                                                                                        .jobName(jobName)
                                                                                        .updateJobEnd(true)
                                                                                        .updateJobStart(false)
                                                                                        .updateLastSuccessfulRun(false)
                                                                                        .updateLastRun(true)
                                                                                        .updateAffectedRows(false)
                                                                                        .errorMessage(jobName.getValue().concat(" has erred out " + errorMessage))
                                                                                        .modifiedBy("System")
                                                                                        .status(Status.FAILURE)
                                                                                        .build())
                                                                        .subscribe();
                                                            })
                                                            .flatMap(processingResponse -> commonRepository
                                                                    .updateJobExecutionHistoryAsJobEnd(execId, Status.SUCCESS, "", processingResponse.getMessage (), updateAffectedRowsOnSuccess, (long)processingResponse.getAffectedRows ())
                                                                    .flatMap(updatedRows ->
                                                                            {
                                                                                if(jobEvent.getCascadeEvents()){
                                                                                    processCascadedJobs(jobEvent, false);
                                                                                    log.info("processed cascade jobs {}",jobEvent);

                                                                                }
                                                                                return  commonRepository.upsertJobRunConfiguration(
                                                                                        JobRunConfigurationDTO.builder()
                                                                                                .jobName(jobName)
                                                                                                .updateJobEnd(true)
                                                                                                .updateJobStart(false)
                                                                                                .updateLastSuccessfulRun(true)
                                                                                                .updateMessage(true)
                                                                                                .message (processingResponse.getMessage ())
                                                                                                .updateLastRun(true)
                                                                                                .updateErrorMessage(false)
                                                                                                .updateAffectedRows(updateAffectedRowsOnSuccess)
                                                                                                .affectedRows ((long)processingResponse.getAffectedRows ())
                                                                                                .modifiedBy("System")
                                                                                                .status(Status.SUCCESS)
                                                                                                .build()
                                                                                );
                                                                            }
                                                                    )
                                                            )
                                                            .doFinally(signalType -> {
                                                                System.gc();
                                                                System.runFinalization();
                                                            })
                                                    );

                                        })).subscribe(consumer -> {
                                    log.info("{} Job completed.", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier());
                                    if (isJobAlertEnabled) {
                                        boolean isJobInExlcusionList = false;
                                        if (!jobAlertExclusionList.isEmpty() && jobAlertExclusionList != null) {
                                            String[] jobList = jobAlertExclusionList.split(",");
                                            isJobInExlcusionList = isJobinList(jobEvent.getJobName().toString(), jobList);
                                        }
                                        if (!isJobInExlcusionList) {
                                            Mono<String> result = sendPrometheusAlerts(jobEvent.getJobName().toString());
                                            result.subscribe(status -> {
                                                if (status.equals("SUCCESS")) {
                                                    log.info("Job Alerts sent to Prometheus Successfully", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier(), status);
                                                } else {
                                                    log.warn("Sending alerts to Prometheus failed", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier(), status);
                                                }
                                            });
                                        } else
                                            log.info("{} Job is mentioned in exclusion list.Prometheus alerts are not sent", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier());

                                    } else
                                        log.info("{} Prometheus Job Alert Service is disabled", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier());

                                });
                                return Mono.empty();
                            }
                        });
                executeOrAbort.subscribe();
            } else {
                log.info("Job {} is not active", jobName.getValue());
            }
            return Mono.empty();
        }).subscribe(val ->
                log.info("{} JobName : {} - isActive : {}", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier(), jobEvent.getJobName(), val));

    }
    private Throwable getCoreError(Throwable error) {
        //ProgramPerformanceException gives null when we do error.getMessage();
        //hence trying to retrieve core exception that was thrown
        if (!(error instanceof ProgramPerformanceException)) {
            return error;
        }
        //Custom exception is set to null, while creating program performance exception with API error code.
        else if (((ProgramPerformanceException) error).getCustomException() == null)
            return new RuntimeException(error.getMessage());
        else {
            return getCoreError(((ProgramPerformanceException) error).getCustomException());
        }
    }

    private Mono<Boolean> checkIsActive(String jobName) {
        return commonRepository.getJobIsActiveByName(jobName)
                .doOnError(err -> {
                    String errorMessage = err.getMessage();
                    log.error("{} Failed to fetch isActive: {}", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier(), errorMessage);
                });
    }

    private Mono<Integer> CheckIfJobExecutionAlreadyRegistered(String jobName, String messageKey, Integer thresholdTime) {

        LoggingForConsumerIdentity();//This is temporary logging step for debugging stage issue - multiple instance of jobs running simultaneously.

        return commonRepository.getJobIdByName(jobName)
                .doOnError(err -> {
                    String errorMessage = err.getMessage();
                    log.error("{} Failed to fetch job id. {}", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier(), errorMessage);
                })
                .flatMap(jobId -> {
                    log.info("{} Check if job execution is already registered by another instance/thread.", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier());
                    return checkByLastRunTime(jobId, thresholdTime)
                            .doOnError(err ->
                                    {
                                        log.error("{} Error while trying to retrieve history count by time threshold. Error details: ", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier(), err);
                                    }
                            )
                            .flatMap(historyCount ->
                            {
                                log.info("{} Evaluating history count by time threshold.", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier());
                                if (historyCount == 0) {
                                    return checkByMessageKey(messageKey, jobId)
                                            .doOnError(err ->
                                                    {
                                                        log.error("{} Error while trying to retrieve history count by message key. Error details: ", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier(), err);
                                                    }
                                            );
                                } else {
                                    return Mono.just(historyCount);
                                }
                            });
                });
    }

    private Mono<Integer> checkByMessageKey(String messageKey, Integer jobId) {
        MDC.put("messageId", messageKey);
        log.info("{} Check for job id {} by message key {}", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier(), jobId, messageKey);
        return commonRepository.getJobExecutionHistoryByMessageKey(jobId, messageKey)
                .switchIfEmpty(Mono.just(0))
                .onErrorMap(err -> {
                    String errorMessage = err.getMessage();
                    log.error("{} Failed to get job execution history by message key. Error details: {}", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier(), err);
                    return new ProgramPerformanceException(errorMessage);
                })
                .flatMap(historyCount -> {
                            log.info("{} History count By message key is {}", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier(), historyCount);
                            if (historyCount > 0) {
                                log.info("{} Job execution history already registered by another instance/thread.", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier());
                            }
                            return Mono.just(historyCount);
                        }
                );
    }

    private Mono<Integer> checkByLastRunTime(Integer jobId, Integer thresholdInMinutes) {
        MDC.put("messageId", ProgramPerformanceUtil.TransactionIdLogger.getMessageIdIdentifier());
        if (!this.checkForDuplicateJobExecutionBasedOnThresholdTime) {
            log.info("{} Check job execution history by time for this job is: {}, hence skipping.", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier(), this.checkForDuplicateJobExecutionBasedOnThresholdTime);
            return Mono.just(0);
        }
        log.info("{} Check for job id {} by time {}", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier(), jobId, thresholdInMinutes);
        return commonRepository.getJobExecutionHistoryByTime(jobId, thresholdInMinutes)
                .switchIfEmpty(Mono.just(0))
                .onErrorMap(err -> {
                    String errorMessage = err.getMessage();
                    log.error("{} Failed to get job execution history by time. Error details: {}", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier(), err);
                    return new ProgramPerformanceException(errorMessage);
                })
                .flatMap(historyCount -> {
                            log.info("{} History count By time threshold is {}", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier(), historyCount);
                            if (historyCount > 0) {
                                log.info("{} Job execution history already registered by another instance/thread within past {} minutes", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier(), thresholdInMinutes);
                            }
                            return Mono.just(historyCount);
                        }
                );
    }

    private void LoggingForConsumerIdentity() {
        MDC.put("messageId", ProgramPerformanceUtil.TransactionIdLogger.getMessageIdIdentifier());
        StringBuilder logMessage = new StringBuilder();
        long threadID = Thread.currentThread().getId();
        logMessage.append(String.format("Thread Name: %s | ", Thread.currentThread().getName()));
        logMessage.append(String.format("Thread ID: %s | ", threadID));
        long pid = getProcessID();
        logMessage.append(String.format("Process ID: %s.", pid));

        log.info("Process tracker: {} {}", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier(), logMessage.toString());
    }

    private long getProcessID() {
        RuntimeMXBean bean = ManagementFactory.getRuntimeMXBean();
        // Get name representing the running Java virtual machine.
        // It returns something like 35892@LHTU05CG834148Q. Where the value
        // before the @ symbol is the PID.
        String jvmName = bean.getName();
        log.info("{} process running with BeanName: {}", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier(), jvmName);
        // Extract the PID by splitting the string returned by the
        // bean.getName() method.
        long pid = Long.valueOf(jvmName.split("@")[0]);
        return pid;
    }

    //Sending the jobAlertDTO details to alert manager through prometheus
    private Mono<String> sendPrometheusAlerts(String jobName) {
        log.info("Sending JobAlertDTO data to alert manager service");
        return jobAlertRepository.getJobAlertByName(jobName)
                .doOnError(err -> {
                    log.error("{} Failed to get job alert DTO details by jobName . Error details: {}", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier(), err);
                })
                .flatMap(dto -> {
                    log.info("{} JobAlertDTO details fetched {}", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier());
                    Mono<String> status = prometheusJobAlertService.sendAlerts(dto);
                    status.doOnError(err -> {
                        log.error("{} Error encountered while calling prometheus service {}", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier(), err);
                    })
                            .doOnNext(result -> {
                                log.info("{} Prometheus Alerts Status {}", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier(), result);

                            });

                    return status;
                });
    }

    // Method to check if the JOb is in the exclusion list for sending alerts
    private boolean isJobinList(String jobName, String[] jobList) {
        boolean isJobInList = false;
        for (String job : jobList) {
            if (jobName.equals(job)) isJobInList = true;

        }
        return isJobInList;
    }

    private Mono<JobEvent> getJobEventForCascadedJobs(JobEvent jobEvent, String jobName, String jobInput) {
        if(JobName.LOAD_HISTORICAL_LOB_TARGET_VALUES_AND_ACTUALS.getValue().equals(jobName)){
            return   masterConfigService.getCurrentProgramYear()
                    .onErrorMap (exception -> {
                        log.error ("Error while  getProjectYear  ", exception);
                        return new Exception (ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier () + " Error while  getProjectYear()  " + exception.getMessage ());
                    })
                    .next ()
                    .flatMap (currentProgramYear -> {
                        log.info ("{} currentProgramYear {}", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier (), currentProgramYear);
                        return Mono.just(JobEvent.newBuilder()
                                .setJobName(jobName)
                                .setGroupsToExecute(jobEvent.getGroupsToExecute().toString())
                                .setExecutionWeek(jobEvent.getExecutionWeek().toString())
                                .setStatus(Status.SUCCESS.getValue())
                                .setProgramYear(Integer.parseInt(currentProgramYear))
                                .setJobInput(jobInput)
                                .setTimeStamp(Instant.now())
                                .setCascadeEvents(jobEvent.getCascadeEvents())
                                .build());
                    });
        }else{
            return Mono.just(JobEvent.newBuilder()
                    .setJobName(jobName)
                    .setGroupsToExecute(jobEvent.getGroupsToExecute().toString())
                    .setExecutionWeek(jobEvent.getExecutionWeek().toString())
                    .setStatus(Status.SUCCESS.getValue())
                    .setProgramYear(jobEvent.getProgramYear())
                    .setTimeStamp(Instant.now())
                    .setJobInput(jobInput)
                    .setCascadeEvents(jobEvent.getCascadeEvents())
                    .build());
        }
    }

    private void processCascadedJobs(JobEvent jobEvent, boolean onError) {
        log.info("{} started processing the cascaded Jobs", jobEvent.getJobName());
        getChildJobs(jobEvent)
                .flatMap(jobSeq -> {
                    log.info("{} child JobSequence ",jobSeq.toString());
                    return Flux.fromIterable(jobSeq.getCascadedJobs())
                            .flatMap(jobDetails -> {
                                log.info("CascadedJobs:: {} for parentJob :: {} ", jobDetails.toString(),jobEvent.getJobName());
                                return checkFrequencyMatchAndOnErrorTrigger(jobDetails,onError).flatMap(freqMatches -> {
                                    if (freqMatches) {
                                        log.info("parentJob:: {} triggering cascaded child job :: {} ", jobEvent.getJobName(),jobDetails.getJobName());
                                        getJobEventForCascadedJobs(jobEvent, jobDetails.getJobName(),jobDetails.getJobInput()).flatMap(childJobEvent -> {
                                           if("REDIS".equalsIgnoreCase(jobEvent.getEventType().toString()))
                                           {
                                               childJobEvent.setEventType("REDIS");
                                           }
                                            jobEventProducer.postToMsgQue(childJobEvent);

                                            return Mono.just(0l);
                                        }).subscribe();
                                    } else {
                                        log.info("{} child frequency or Onerror doesnt match", jobDetails.getJobName());
                                    }
                                    return Mono.just(0l);
                                }).onErrorMap(err -> {
                                    String errorMessage = err.getMessage();
                                    log.error("{} Failed to frequencyCheckMatches. Error details: {}", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier(), err.getMessage());
                                    return new ProgramPerformanceException(errorMessage);
                                });
                            }).reduce(Long::sum).onErrorMap(err -> {
                                String errorMessage = err.getMessage();
                                log.error("{} Failed to Flux.fromIterable. Error details: {}", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier(), err.getMessage());
                                return new ProgramPerformanceException(errorMessage);
                            });
                }).onErrorMap(err -> {
            String errorMessage = err.getMessage();
            log.error("{} Failed or no cascaded Jobs to processCascadedJobs. Error details: {}", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier(), err.getLocalizedMessage());
            return new ProgramPerformanceException(errorMessage);
        }).subscribe();
    }

    public Mono<JobSequence> getChildJobs(JobEvent jobEvent) {
        return  commonRepository.getCascadedJobs(jobEvent.getJobName().toString())
                .switchIfEmpty(Mono.error(new ProgramPerformanceException("No Child Jobs Found")))
                .flatMap(childVal -> {
                    return Mono.just((JobSequence) ProgramPerformanceUtil.jsonToPojo(childVal, JobSequence.class));
                });
    }

    public Mono<Boolean> checkFrequencyMatchAndOnErrorTrigger(JobDetails jobDetails, boolean onError) {
        LocalDateTime dateTime = LocalDateTime.ofInstant(Instant.now(), ZoneOffset.UTC);
        return commonRepository.getJobFrequency(jobDetails.getJobName()).flatMap(freq -> {
            if (freq!=null && (freq.equalsIgnoreCase("ALL") || freq.equalsIgnoreCase(dateTime.getDayOfWeek().toString()))) {
                if( (onError && jobDetails.isTriggerOnError() )  || !onError)
                        return Mono.just(true);
                else
                    return Mono.just(false);
            } else {
                return Mono.just(false);
            }
        }).onErrorMap(err -> {
            String errorMessage = err.getMessage();
            log.error("{} Failed to checkFrequencyMatchAndOnErrorTrigger (String jobName). Error details: {}", ProgramPerformanceUtil.TransactionIdLogger.getTransactionIdentifier(), err);
            return new ProgramPerformanceException(errorMessage);
        });
    }

    private JobEvent convertStringToJobEvent(String event)  {
        try {
            return mapper.readValue(event, JobEvent.class);
        }catch(Exception e){
            log.error(" Failed to convert the Job Event {}",e);
        }
        return null;
    }

    @Override
    public void onMessage(Message message, @Nullable byte[] var2){
        this.handleMessage(new String(message.getBody()));
    }
}

