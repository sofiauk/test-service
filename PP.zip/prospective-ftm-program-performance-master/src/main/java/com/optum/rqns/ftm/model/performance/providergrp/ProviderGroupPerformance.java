package com.optum.rqns.ftm.model.performance.providergrp;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@JsonPropertyOrder({"providerGroupId","serviceLevel","state","programYear","aggregate","lobs"})
public class ProviderGroupPerformance {
    private String providerGroupId;
    private String serviceLevel;
    private String state;
    private int programYear;
    @JsonProperty("aggregate")
    private ProviderGroupPerformanceData providerGroupPerformanceData;
    @JsonProperty("lobs")
    private List<ProviderGroupLobPerformance> providerGroupLobs;
}
