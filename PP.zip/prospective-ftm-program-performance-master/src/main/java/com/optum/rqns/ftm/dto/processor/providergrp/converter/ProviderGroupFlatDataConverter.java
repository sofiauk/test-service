package com.optum.rqns.ftm.dto.processor.providergrp.converter;

import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.model.providergrpdeployment.ProviderGroupFlatData;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;

import java.time.LocalDateTime;

public class ProviderGroupFlatDataConverter implements Converter<Row, ProviderGroupFlatData>, DTOWrapperTypeConverter {
    @Override
    public ProviderGroupFlatData convert(Row row) {

        return ProviderGroupFlatData.builder().
                providerGroupID(row.get("providerGroupID", String.class))
                .providerGroupName(row.get("providerGroupName",String.class))
                .state(row.get("state", String.class))
                .programYear(row.get("programYear", Integer.class))
                .clientId(row.get("clientId", String.class))
                .clientName(row.get("clientName", String.class))
                .lob(row.get("lob", String.class))
                .distributionChannel(row.get("distributionChannel", String.class))
                .retrievalChannel(row.get("retrievalChannel", String.class) != null ? row.get("retrievalChannel", String.class).toString() : null)
                .lastReturnDate(row.get("lastReturnDate", LocalDateTime.class) != null ? row.get("lastReturnDate", LocalDateTime.class) : null)
                .deploymentsCount(row.get("deploymentsCount", Integer.class))
                .returnsCount(row.get("returnsCount", Integer.class))
                .returnsNetCNACount(row.get("returnsNetCNACount", Integer.class))
                .build();
    }
}
