package com.optum.rqns.ftm.dto.masterconfig;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class MasterConfigurationRequest {
    private MasterConfigValueDTO data;
    private String reason;
}
