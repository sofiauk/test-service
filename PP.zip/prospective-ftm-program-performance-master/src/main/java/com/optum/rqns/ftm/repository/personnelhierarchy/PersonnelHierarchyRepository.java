package com.optum.rqns.ftm.repository.personnelhierarchy;

import com.optum.rqns.ftm.model.personnelhierarchy.PersonnelHierarchy;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;

@Repository
public interface PersonnelHierarchyRepository {
    Flux<PersonnelHierarchy> getPersonnelHierarchy();
    Flux<PersonnelHierarchy> getPersonnelHierarchyNode(String uuid);
    Mono<Integer> createPersonnelHierarchy(String uuid, Integer parentUuid);
    Mono<Integer> updatePersonnelHierarchy(String uuid, Integer parentUuid);
    Mono<Integer> removePersonnelHierarchy(String uuid, LocalDateTime deletedDate);
}
