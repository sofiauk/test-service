package com.optum.rqns.ftm.model.practiceassist.providerdashboard;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserProfile {

	private String[] provGrpId;
	private String[] healthSystemIds;
	private String[] stCd;
	private String[] pcpId;
	private Long[] lobCd;
	private String[] clientId;
	private String[] healthPlanName;
	private String[] provGrpType;
	private String[] provType;
	private String filterType;
	private Integer[] subCliSk;
	private boolean superUser;

	public UserProfile() {
		//Do Nothing
	}
}
