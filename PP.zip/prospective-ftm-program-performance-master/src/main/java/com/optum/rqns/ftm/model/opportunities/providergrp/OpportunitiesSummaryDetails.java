package com.optum.rqns.ftm.model.opportunities.providergrp;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.optum.rqns.ftm.constants.ProviderGroupConstants;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.ArrayList;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OpportunitiesSummaryDetails {

    private String opportunitySummaryId;
    private String providerGroupID;
    private String providerGroupName;
    private String state;
    private String serviceLevel;
    private int programYear;
    private String masterOpportunityType;
    private int masterOpportunityTypePosition;
    private int totalAssessmentsCount;
    private int totalGapsCount;
    private int totalClientsCount;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = ProviderGroupConstants.PERFORMANCE_DATE_FORMAT)
    private LocalDate lastUpdatedDate;
    @JsonProperty("opportunities")
    private ArrayList<OpportunitiesDetails> opportunitiesDetails;

}
