package com.optum.rqns.ftm.repository.goals.client;

import com.optum.rqns.ftm.constants.ClientGoalConstants;
import com.optum.rqns.ftm.dto.goals.client.ClientGoalsAggregateDTO;
import com.optum.rqns.ftm.dto.goals.client.ClientGoalsSnapshotDTO;
import com.optum.rqns.ftm.dto.goals.client.ClientLobRegionGoalValuesDTO;
import com.optum.rqns.ftm.dto.goals.client.LobDTO;
import com.optum.rqns.ftm.dto.goals.client.LobGoalDTO;
import com.optum.rqns.ftm.dto.goals.client.Region;
import com.optum.rqns.ftm.dto.goals.client.RegionDeployDTO;
import com.optum.rqns.ftm.model.goals.client.ClientGoalTypeRequestBody;
import com.optum.rqns.ftm.model.goals.client.RegionGoalTypeRequestBody;
import com.optum.rqns.ftm.model.goals.client.RegionsRequestBody;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;

@Repository
public class ClientGoalsReactiveRepositoryImpl implements ClientGoalsReactiveRepository {

    private final DatabaseClient client;

    public ClientGoalsReactiveRepositoryImpl(DatabaseClient client) {
        this.client = client;
    }

    public enum ColumnNames {
        DEPLOYED("DEPLOYED"), RETURNED("RETURNED"), COMPLETED("COMPLETED"), YEAR("YEAR"), PROGRAMYEAR("PROGRAMYEAR"), LASTUPDATEDDATE("LASTUPDATEDDATE"),
        SECONDARYSUBMISSION("SECONDARYSUBMISSION"), GARISK("GARISK"), GAQUALITY("GAQUALITY"),
        DVRISK("DVRISK"), DVQUALITY("DVQUALITY"), RISKGAPCLOSURE("RISKGAPCLOSURE"),
        DIAGNOSEDVERIFIED("DIAGNOSEDVERIFIED"), STATUS("STATUS"), CLIENTID("CLIENTID"),
        CLIENTNAME("CLIENTNAME"), LOBID("LOBID"), LOBNAME("LOBNAME"), ELIGIBLEMEMBERS("ELIGIBLEMEMBERS"),
        REGION("REGION"), GOALTYPE("GOALTYPE"), GOALVALUE("GOALVALUE"), ISCLIENTREGION("ISCLIENTREGION"), STATECOUNT("STATECOUNT"),
        REGIONID("REGIONID"), STATENAME("STATENAME"),
        REGIONNAME("REGIONNAME"), HCFA("HCFA"), PBPID("PBPID"), STATEID("STATEID"), CGAPRISK("CGAPRISK"), CGAPQUALITY("CGAPQUALITY"),
        WEEKSTARTDATE("WEEKSTARTDATE");

        private String columnName;

        ColumnNames(String columnName) {
            this.columnName = columnName;
        }

        public String getColumnName() {
            return this.columnName;
        }
    }


    private static final String SELECT_ALL_YEARS = "SELECT DISTINCT PROGRAMYEAR FROM  PROGPERF.GOALS_DEPLOYMENT WITH (NOLOCK) WHERE PROGRAMYEAR IS NOT NULL ORDER BY PROGRAMYEAR DESC";

    private static final String SELECT_ALL_WEEKS = "SELECT DISTINCT WEEK,WEEKDATE as WEEKSTARTDATE  from ProgPerf.GOALS_DEPLOYMENT WITH (NOLOCK) where PROGRAMYEAR=:YEAR and WEEKDATE IS NOT NULL order by WEEK asc;";

    private static final String SELECT_LOBNAME_ID_BY_CLIENT_ID = "SELECT lob.LOBID,lob.LOBNAME from ProgPerf.LOB as lob WITH (NOLOCK) INNER JOIN ProgPerf.LOB_CLIENT as lobclient ON lob.LOBID=lobclient.LOBID and lobclient.CLIENTID=:CLIENTID";

    /**
     * @deprecated (when, why, refactoring advice...)
     */
    @Deprecated
    private static final String SELECT_REGIONS_BY_CLIENT_ID = "SELECT DISTINCT(REGIONID) AS REGIONID,REGION AS REGIONNAME,LOBID,ISCLIENTREGION,CLIENTID FROM  PROGPERF.GOALS_DEPLOYMENT WITH (NOLOCK) WHERE PROGRAMYEAR=:YEAR AND LOBID=:LOBID AND CLIENTID=:CLIENTID";

    private static final String SELECT_REGIONS_BY_PARAMS = "SELECT DISTINCT(REGIONID) AS REGIONID, ISNULL(REGION,'NULL') AS REGIONNAME,LOBID,ISCLIENTREGION,CLIENTID FROM  PROGPERF.GOALS_DEPLOYMENT GD WITH (NOLOCK) WHERE PROGRAMYEAR=:PROGRAMYEAR AND GD.LOBID=:LOBID AND GD.CLIENTID=:CLIENTID %s ";


    private static final String SELECT_CLIENT_SNAPSHOT = "" +
            "SELECT  " +
            "RS.CLIENTID, RS.CLIENTNAME, RS.LOBNAME, RS.LOBID, RS.PROGRAMYEAR " +
            ",CASE WHEN GDS.ISFINAL = 1 THEN 'Final' ELSE 'Estimate' END AS STATUS, GDS.MODIFIEDDATE AS LASTUPDATEDDATE  " +
            ",SUM(RS.DEPLOYED) AS DEPLOYED,SUM(RS.RETURNED) AS RETURNED,SUM(RS.COMPLETED) AS COMPLETED   " +
            ",SUM(GDERS.ELIGIBLEMEMBERS) AS ELIGIBLEMEMBERS,SUM(RS.SECONDARYSUBMISSION) AS SECONDARYSUBMISSION   " +
            ",SUM(RS.GARISK) AS GARISK,SUM(RS.GAQUALITY) AS GAQUALITY ,SUM(RS.DVRISK)AS DVRISK,SUM(RS.DVQUALITY) AS DVQUALITY " +
            ",SUM(RS.RISKGAPCLOSURE) AS RISKGAPCLOSURE, SUM(RS.DIAGNOSEDVERIFIED) AS DIAGNOSEDVERIFIED " +
            "FROM (  " +
            "  SELECT GD.CLIENTID, GD.CLIENT AS CLIENTNAME, GD.LOB AS LOBNAME, GD.LOBID, GD.PROGRAMYEAR " +
            "   ,SUM(GD.DEPLOYED) AS DEPLOYED,SUM(GD.RETURNED) AS RETURNED,SUM(GD.COMPLETED) AS COMPLETED   " +
            "   ,null AS SECONDARYSUBMISSION, null AS GARISK " +
            "   ,null AS GAQUALITY,NULL AS DVRISK, NULL AS DVQUALITY, NULL AS RISKGAPCLOSURE,NULL AS DIAGNOSEDVERIFIED " +
            "   FROM PROGPERF.GOALS_DEPLOYMENT GD WITH (NOLOCK)" +
            "   WHERE GD.PROGRAMYEAR =:PROGRAMYEAR " +
            "   GROUP BY GD.CLIENTID,GD.CLIENT, GD.LOB, GD.LOBID, GD.PROGRAMYEAR " +
            "  UNION " +
            "  SELECT GADV.CLIENTID, GADV.CLIENT AS CLIENTNAME, GADV.LOB AS LOBNAME, GADV.LOBID, GADV.PROGRAMYEAR " +
            "   ,NULL AS DEPLOYED,NULL AS RETURNED,NULL AS COMPLETED  " +
            "   ,SUM(GADV.SECONDARYSUBMISSION) AS SECONDARYSUBMISSION, AVG(GADV.GARISK) AS GARISK " +
            "   ,AVG(GADV.GAQUALITY) AS GAQUALITY,AVG(GADV.DVRISK)AS DVRISK,AVG(GADV.DVQUALITY) AS DVQUALITY " +
            "   ,AVG(GADV.RISKGAPCLOSURE) AS RISKGAPCLOSURE, AVG(GADV.DIAGNOSEDVERIFIED) AS DIAGNOSEDVERIFIED " +
            "   FROM PROGPERF.GOALS_GADV GADV WITH (NOLOCK) " +
            "   WHERE GADV.QUARTER='YE' AND GADV.PROGRAMYEAR=:PROGRAMYEAR " +
            "   GROUP BY GADV.CLIENTID,GADV.CLIENT, GADV.LOB, GADV.LOBID, GADV.PROGRAMYEAR " +
            " ) AS RS " +
            "LEFT JOIN PROGPERF.GOALS_DEPLOYMENT_STATUS GDS WITH (NOLOCK) ON RS.CLIENTID=GDS.CLIENTID AND RS.LOBID=GDS.LOBID AND RS.PROGRAMYEAR=GDS.YEAR AND GDS.YEAR=:PROGRAMYEAR " +
            "LEFT JOIN ( SELECT GDE.CLIENTID,GDE.LOBID,GDE.PROGRAMYEAR,SUM(GDE.CURRENT_NON_SUPPRESSED_MBR) AS ELIGIBLEMEMBERS " +
            "            FROM ProgPerf.GOALS_DEPLOYMENT_ESTIMATES GDE  WITH (NOLOCK) " +
            "            WHERE PROGRAMYEAR=:PROGRAMYEAR " +
            "            GROUP BY GDE.CLIENTID,GDE.LOBID,GDE.PROGRAMYEAR " +
            "          ) AS GDERS on RS.CLIENTID = GDERS.CLIENTID AND RS.LOBID = GDERS.LOBID AND RS.PROGRAMYEAR = GDERS.PROGRAMYEAR "+
            "GROUP BY RS.CLIENTID,RS.CLIENTNAME,RS.LOBNAME,RS.LOBID,RS.PROGRAMYEAR,GDS.ISFINAL,GDS.MODIFIEDDATE " +
            "ORDER BY RS.CLIENTNAME,RS.LOBNAME;";

    private static final String SELECT_CLIENT_GOALS_AGGREGATE = "" +
            "SELECT  " +
            "RS.PROGRAMYEAR " +
            ",SUM(RS.DEPLOYED) AS DEPLOYED,SUM(RS.RETURNED) AS RETURNED,SUM(RS.COMPLETED) AS COMPLETED   " +
            ",(SELECT SUM(CURRENT_NON_SUPPRESSED_MBR) FROM PROGPERF.GOALS_DEPLOYMENT_ESTIMATES WHERE PROGRAMYEAR=:PROGRAMYEAR)  AS ELIGIBLEMEMBERS " +
            ",SUM(RS.SECONDARYSUBMISSION) AS SECONDARYSUBMISSION   " +
            ",AVG(RS.GARISK) AS GARISK,AVG(RS.GAQUALITY) AS GAQUALITY ,AVG(RS.DVRISK)AS DVRISK,AVG(RS.DVQUALITY) AS DVQUALITY " +
            ",AVG(RS.RISKGAPCLOSURE) AS RISKGAPCLOSURE, AVG(RS.DIAGNOSEDVERIFIED) AS DIAGNOSEDVERIFIED " +
            "FROM (  " +
            "  SELECT GD.CLIENTID, GD.CLIENT AS CLIENTNAME, GD.LOB AS LOBNAME, GD.LOBID, GD.PROGRAMYEAR " +
            "   ,SUM(GD.DEPLOYED) AS DEPLOYED,SUM(GD.RETURNED) AS RETURNED,SUM(GD.COMPLETED) AS COMPLETED   " +
            "   , null AS SECONDARYSUBMISSION, null AS GARISK " +
            "   ,null AS GAQUALITY,NULL AS DVRISK, NULL AS DVQUALITY, NULL AS RISKGAPCLOSURE,NULL AS DIAGNOSEDVERIFIED " +
            "   FROM PROGPERF.GOALS_DEPLOYMENT GD WITH (NOLOCK)" +
            "   WHERE GD.PROGRAMYEAR =:PROGRAMYEAR " +
            "   GROUP BY GD.CLIENTID,GD.CLIENT, GD.LOB, GD.LOBID, GD.PROGRAMYEAR " +
            "  UNION " +
            "  SELECT GADV.CLIENTID, GADV.CLIENT AS CLIENTNAME, GADV.LOB AS LOBNAME, GADV.LOBID, GADV.PROGRAMYEAR " +
            "   ,NULL AS DEPLOYED,NULL AS RETURNED,NULL AS COMPLETED " +
            "   ,SUM(GADV.SECONDARYSUBMISSION) AS SECONDARYSUBMISSION, AVG(GADV.GARISK) AS GARISK " +
            "   ,AVG(GADV.GAQUALITY) AS GAQUALITY,AVG(GADV.DVRISK)AS DVRISK,AVG(GADV.DVQUALITY) AS DVQUALITY " +
            "   ,AVG(GADV.RISKGAPCLOSURE) AS RISKGAPCLOSURE, AVG(GADV.DIAGNOSEDVERIFIED) AS DIAGNOSEDVERIFIED " +
            "   FROM PROGPERF.GOALS_GADV GADV WITH (NOLOCK)" +
            "   WHERE GADV.QUARTER='YE' AND GADV.PROGRAMYEAR=:PROGRAMYEAR " +
            "   GROUP BY GADV.CLIENTID,GADV.CLIENT, GADV.LOB, GADV.LOBID, GADV.PROGRAMYEAR " +
            " ) AS RS " +
            "GROUP BY RS.PROGRAMYEAR;";

    /*private static final String DEPOLYMENT_QUERY = "SELECT GD.CLIENT AS CLIENTNAME,GD.LOB AS LOBNAME,GD.LOBID, GD.CLIENTID, GD.REGION AS REGIONNAME, GD.REGIONID, GD.STATE AS STATENAME, GD.STATEID, GD.HCFA, GD.PBPID,GD.PROGRAMYEAR,GD.ELIGIBLEMEMBERS, " +
            "GD.DEPLOYED, GD.RETURNED, GD.COMPLETED FROM PROGPERF.GOALS_DEPLOYMENT GD WITH (NOLOCK) " +
            "WHERE GD.PROGRAMYEAR=:YEAR AND GD.CLIENTID=:CLIENTID AND GD.LOBID=:LOBID %s";

    private static final String REGION_DEPOLYMENT_QUERY = "SELECT GD.CLIENT AS CLIENTNAME,GD.LOB AS LOBNAME,GD.LOBID, GD.CLIENTID, GD.REGION AS REGIONNAME, GD.REGIONID, GD.STATE AS STATENAME, GD.STATEID, GD.HCFA, GD.PBPID,GD.PROGRAMYEAR,GD.ELIGIBLEMEMBERS, " +
            "GD.DEPLOYED, GD.RETURNED, GD.COMPLETED FROM PROGPERF.GOALS_DEPLOYMENT GD WITH (NOLOCK) " +
            "WHERE GD.PROGRAMYEAR=:YEAR AND GD.CLIENTID=:CLIENTID AND GD.LOBID=:LOBID AND GD.REGIONID=:REGIONID %s";*/

    /*
     * @ This query is newly created and updated as part of US667123: [Tech] Display Membership Volume in State Details Screen - API
     * @ author Balakrishna C
     * @ Returns the EligibleMembers from Goals deploymentestimates rest goals deployment
     */
    private static final String DEPOLYMENT_QUERY = "SELECT DISTINCT GD.CLIENT AS CLIENTNAME, GD.LOB AS LOBNAME, GD.LOBID, GD.CLIENTID, ISNULL(GD.REGION,'NULL') AS REGIONNAME, GD.REGIONID, ISNULL(GD.STATE,'NULL') AS STATENAME, GD.STATEID, GD.HCFA, GD.PBPID, GD.PROGRAMYEAR, (" +
            "              SELECT SUM(ISNULL(GDE.CURRENT_NON_SUPPRESSED_MBR,0)) AS ELIGIBLEMEMBERS " +
            "FROM ProgPerf.GOALS_DEPLOYMENT_ESTIMATES gde " +
            "WHERE GD.HCFA = GDE.HCFA_CONTRACT_NUMBER " +
            "       AND GD.PBPID = GDE.PBPID " +
            "       AND ISNULL(GD.STATE,'-') = ISNULL(GDE.STATE,'-') " +
            "       AND ISNULL(GD.REGION,'-') = ISNULL(GDE.REGION,'-') " +
            "       AND (LTRIM(RTRIM(ISNULL(GDE.HCFA_CONTRACT_NUMBER,''))) != '') " +
            "       AND (LTRIM(RTRIM(ISNULL(GDE.PBPID,''))) != '') " +
            "       AND (ISNULL(GDE.CURRENT_NON_SUPPRESSED_MBR,0) != 0) " +
            "GROUP BY LTRIM(RTRIM(GDE.HCFA_CONTRACT_NUMBER)), LTRIM(RTRIM(GDE.PBPID)) " +
            "              ) AS ELIGIBLEMEMBERS, " +
            "              SUM(GD.DEPLOYED) AS DEPLOYED, SUM(GD.RETURNED) AS RETURNED, SUM(GD.COMPLETED) AS COMPLETED " +
            "FROM PROGPERF.GOALS_DEPLOYMENT GD WITH (NOLOCK) " +
            "WHERE GD.PROGRAMYEAR=:YEAR AND GD.CLIENTID=:CLIENTID AND GD.LOBID=:LOBID %s " +
            "GROUP BY GD.CLIENT, GD.LOB, GD.LOBID, GD.CLIENTID, GD.REGION, GD.REGIONID, GD.STATE, GD.STATEID, GD.HCFA, GD.PBPID, GD.PROGRAMYEAR, ELIGIBLEMEMBERS";

    private static final String REGION_DEPOLYMENT_QUERY = "SELECT DISTINCT GD.CLIENT AS CLIENTNAME, GD.LOB AS LOBNAME, GD.LOBID, GD.CLIENTID, ISNULL(GD.REGION,'NULL') AS REGIONNAME, GD.REGIONID, ISNULL(GD.STATE,'NULL') AS STATENAME, GD.STATEID, GD.HCFA, GD.PBPID, GD.PROGRAMYEAR, (" +
            "              SELECT SUM(ISNULL(GDE.CURRENT_NON_SUPPRESSED_MBR,0)) AS ELIGIBLEMEMBERS " +
            "FROM ProgPerf.GOALS_DEPLOYMENT_ESTIMATES gde " +
            "WHERE GD.HCFA = GDE.HCFA_CONTRACT_NUMBER " +
            "       AND GD.PBPID = GDE.PBPID\n" +
            "       AND ISNULL(GD.STATE,'-') = ISNULL(GDE.STATE,'-') " +
            "       AND ISNULL(GD.REGION,'-') = ISNULL(GDE.REGION,'-') " +
            "       AND (LTRIM(RTRIM(ISNULL(GDE.HCFA_CONTRACT_NUMBER,''))) != '') " +
            "       AND (LTRIM(RTRIM(ISNULL(GDE.PBPID,''))) != '') " +
            "       AND (ISNULL(GDE.CURRENT_NON_SUPPRESSED_MBR,0) != 0) " +
            "GROUP BY LTRIM(RTRIM(GDE.HCFA_CONTRACT_NUMBER)), LTRIM(RTRIM(GDE.PBPID)) " +
            "              ) AS ELIGIBLEMEMBERS, " +
            "              SUM(GD.DEPLOYED) AS DEPLOYED, SUM(GD.RETURNED) AS RETURNED, SUM(GD.COMPLETED) AS COMPLETED " +
            "FROM PROGPERF.GOALS_DEPLOYMENT GD WITH (NOLOCK) " +
            "WHERE GD.PROGRAMYEAR=:YEAR AND GD.CLIENTID=:CLIENTID AND GD.LOBID=:LOBID AND GD.REGIONID=:REGIONID %s " +
            "GROUP BY GD.CLIENT, GD.LOB, GD.LOBID, GD.CLIENTID, GD.REGION, GD.REGIONID, GD.STATE, GD.STATEID, GD.HCFA, GD.PBPID, GD.PROGRAMYEAR, ELIGIBLEMEMBERS";

    private static final String SELECT_CLIENT_GOAL_DETAILS = "SELECT GD.LOB, GD.LOBID, GD.CLIENT, ISNULL(GD.REGION,'NULL') as REGION, GD.REGIONID, GD.CLIENTID, GD.PROGRAMYEAR, GD.ISCLIENTREGION, " +
            "SUM( GOALVALUE) AS GOALVALUE, GOALTYPE,COUNT(DISTINCT ISNULL(STATE,0)) AS STATECOUNT" +
            " %s "+
            " WHERE GD.CLIENTID=:CLIENTID and GD.PROGRAMYEAR=:PROGRAMYEAR and GD.LOBID=:LOBID %s  " +
            " GROUP BY GD.LOB, GD.LOBID, GD.CLIENT, GD.REGION, GD.REGIONID, GD.CLIENTID, GD.PROGRAMYEAR, GD.ISCLIENTREGION %s,GD.GOALTYPE " +
            "  UNION ALL " +
            " SELECT LOB, LOBID, CLIENT, REGION, REGIONID, CLIENTID, PROGRAMYEAR, ISCLIENTREGION, CASE WHEN GOALTYPE = 'SECONDARYSUBMISSION' THEN SUM(GOALVALUE) ELSE AVG(GOALVALUE) END AS GOALVALUE, GOALTYPE, " +
            " (SELECT 0 as ELIGIBLEMEMBERS) as ELIGIBLEMEMBERS, COUNT(DISTINCT STATE) AS STATECOUNT   FROM PROGPERF.GOALS_GADV WITH (NOLOCK) " +
            " CROSS APPLY (VALUES (CAST( SECONDARYSUBMISSION AS FLOAT))) AS CA (SECONDARYSUBMISSION) UNPIVOT (GOALVALUE FOR GOALTYPE  IN " +
            " (GARISK, GAQUALITY, DVRISK, DVQUALITY, RISKGAPCLOSURE, DIAGNOSEDVERIFIED,CA.SECONDARYSUBMISSION)) AS E " +
            " WHERE CLIENTID=:CLIENTID and PROGRAMYEAR=:PROGRAMYEAR and LOBID=:LOBID  %s GROUP BY LOB, LOBID, CLIENT, REGION, REGIONID, CLIENTID, PROGRAMYEAR,   ISCLIENTREGION, GOALTYPE";

    @Override
    public Flux<Integer> getClientGoalYears() {
        return client.execute(SELECT_ALL_YEARS)
                .as(Integer.class)
                .fetch()
                .all();
    }

    @Override
    public Flux<ClientGoalsSnapshotDTO> clientLobSnapshotValues(int year) {
        return client.execute(SELECT_CLIENT_SNAPSHOT)
                .bind(ColumnNames.PROGRAMYEAR.getColumnName(), year)
                .as(ClientGoalsSnapshotDTO.class)
                .fetch()
                .all();
    }

    @Override
    public Flux<LobGoalDTO> clientAllRegionGoals(long clientId, long lobId, RegionGoalTypeRequestBody regionGoalTypeRequestBody) {
        switch (regionGoalTypeRequestBody.getGoalType().toUpperCase()) {
            case ClientGoalConstants.DEPLOYED:
            case ClientGoalConstants.RETURNED:
            case ClientGoalConstants.COMPLETED: {
                String filterQuery = getFilterQuery(regionGoalTypeRequestBody);
                return client.execute(String.format(DEPOLYMENT_QUERY, filterQuery))
                        .bind(ClientGoalConstants.YEAR, regionGoalTypeRequestBody.getProgramYear())
                        .bind(ClientGoalConstants.LOB_ID, lobId)
                        .bind(ClientGoalConstants.CLIENT_ID, clientId)
                        .as(RegionDeployDTO.class)
                        .fetch()
                        .all()
                        .map(dto -> {
                            return LobGoalDTO.builder()
                                    .regionId(dto.getRegionId()).clientId(dto.getClientId()).clientName(dto.getClientName())
                                    .hcfa(dto.getHcfa()).lob(dto.getLob()).region(dto.getRegion()).state(dto.getState())
                                    .stateId(dto.getStateId()).deployed(dto.getDeployed()).returned(dto.getReturned())
                                    .completed(dto.getCompleted()).eligibleMembers(dto.getEligibleMembers())
                                    .pbpId(dto.getPbpId()).lobId(dto.getLobId())
                                    .build();
                        });
            }
            default:
                return Flux.empty();
        }
    }

    @Override
    public Flux<LobGoalDTO> clientRegionGoals(long clientId, long lobId, String regionId, RegionGoalTypeRequestBody regionGoalTypeRequestBody) {
        switch (regionGoalTypeRequestBody.getGoalType().toUpperCase()) {
            case ClientGoalConstants.DEPLOYED:
            case ClientGoalConstants.RETURNED:
            case ClientGoalConstants.COMPLETED: {
                String filterQuery = getFilterQuery(regionGoalTypeRequestBody);
                return client.execute(String.format(REGION_DEPOLYMENT_QUERY,filterQuery))
                        .bind(ClientGoalConstants.YEAR, regionGoalTypeRequestBody.getProgramYear())
                        .bind(ClientGoalConstants.LOB_ID, lobId)
                        .bind(ClientGoalConstants.CLIENT_ID, clientId)
                        .bind(ClientGoalConstants.REGION_ID, regionId)
                        .as(RegionDeployDTO.class)
                        .fetch()
                        .all()
                        .map(dto -> {
                            return LobGoalDTO.builder()
                                    .regionId(dto.getRegionId()).clientId(dto.getClientId()).clientName(dto.getClientName())
                                    .hcfa(dto.getHcfa()).lob(dto.getLob()).region(dto.getRegion()).state(dto.getState())
                                    .stateId(dto.getStateId()).deployed(dto.getDeployed()).returned(dto.getReturned())
                                    .completed(dto.getCompleted()).eligibleMembers(dto.getEligibleMembers())
                                    .pbpId(dto.getPbpId()).lobId(dto.getLobId())
                                    .build();
                        });
            }
            default:
                return Flux.empty();
        }
    }

    @Override
    public Flux<LocalDateTime> getWeeksInaYear(Integer year) {
        return client.execute(SELECT_ALL_WEEKS)
                .bind(ClientGoalConstants.YEAR, year)
                .map((row, rowMetadata) -> row.get(ColumnNames.WEEKSTARTDATE.getColumnName(), LocalDateTime.class))
                .all();
    }

    @Override
    public Flux<LobDTO> getLobForClientId(Integer clientId) {
        return client.execute(SELECT_LOBNAME_ID_BY_CLIENT_ID)
                .bind(ClientGoalConstants.CLIENT_ID, clientId)
                .as(LobDTO.class)
                .fetch()
                .all();
    }

    @Override
    public Flux<ClientLobRegionGoalValuesDTO> getClientLobGoalValues(int clientId, int lobId, ClientGoalTypeRequestBody clientGoalTypeRequestBody) {
        String quarterlyParameter = " and Quarter=:filtervalue and year=:YEAR ";
        String monthlyParameter = " and Month=:filtervalue and year=:YEAR ";
        String withoutEliglibleMembersQuery = ",null as ELIGIBLEMEMBERS FROM PROGPERF.GOALS_DEPLOYMENT WITH (NOLOCK) UNPIVOT (goalValue FOR goalType In (DEPLOYED, RETURNED, COMPLETED)) as GD ";
        String query;
        if (ClientGoalConstants.MONTHLY.equalsIgnoreCase(clientGoalTypeRequestBody.getIntervalType())) {
            query = String.format(SELECT_CLIENT_GOAL_DETAILS, withoutEliglibleMembersQuery, monthlyParameter, "", monthlyParameter);
        } else if (ClientGoalConstants.QUARTERLY.equalsIgnoreCase(clientGoalTypeRequestBody.getIntervalType())) {
            query = String.format(SELECT_CLIENT_GOAL_DETAILS, withoutEliglibleMembersQuery, quarterlyParameter, "", quarterlyParameter);
        } else {
            //For only Yearly need to get EligibleMembers from Estimates table, othercases blank
            String yearlyElgigbleMemberQuery = ", (CASE WHEN GOALTYPE = 'DEPLOYED' THEN GDE.ELIGIBLEMEMBERS ELSE NULL END) AS ELIGIBLEMEMBERS " +
                    " FROM PROGPERF.GOALS_DEPLOYMENT "+
                    " WITH (NOLOCK) UNPIVOT (GOALVALUE FOR GOALTYPE IN (DEPLOYED, RETURNED, COMPLETED)) AS GD" +
                    " LEFT JOIN " +
                    " (SELECT CLIENTID,LOBID,REGIONID,PROGRAMYEAR,SUM(CURRENT_NON_SUPPRESSED_MBR) AS ELIGIBLEMEMBERS FROM PROGPERF.GOALS_DEPLOYMENT_ESTIMATES  WITH (NOLOCK) " +
                    " WHERE CLIENTID=:CLIENTID and PROGRAMYEAR=:PROGRAMYEAR and LOBID=:LOBID GROUP BY CLIENTID,LOBID,REGIONID,PROGRAMYEAR) AS GDE " +
                    " ON GD.PROGRAMYEAR = GDE.PROGRAMYEAR AND GD.CLIENTID = GDE.CLIENTID AND GD.LOBID = GDE.LOBID AND GD.REGIONID = GDE.REGIONID";

            query = String.format(SELECT_CLIENT_GOAL_DETAILS, yearlyElgigbleMemberQuery, "", ",GDE.ELIGIBLEMEMBERS", " and (Quarter=:filtervalue and year <> :YEAR )  ");
            clientGoalTypeRequestBody.setIntervalValue("YE");
            clientGoalTypeRequestBody.setYear(0);
        }

        return client.execute(query)
                .bind(ClientGoalConstants.PROGRAM_YEAR, clientGoalTypeRequestBody.getProgramYear())
                .bind(ClientGoalConstants.LOB_ID, lobId)
                .bind(ClientGoalConstants.CLIENT_ID, clientId)
                .bind(ClientGoalConstants.FILTER_VALUE, clientGoalTypeRequestBody.getIntervalValue())
                .bind(ClientGoalConstants.YEAR,clientGoalTypeRequestBody.getYear())
                .as(ClientLobRegionGoalValuesDTO.class)
                .fetch()
                .all();
    }

    @Override
    public Mono<ClientGoalsAggregateDTO> getClientGoalsAggregate(int year) {
        return client.execute(SELECT_CLIENT_GOALS_AGGREGATE)
                .bind(ColumnNames.PROGRAMYEAR.getColumnName(), year)
                .as(ClientGoalsAggregateDTO.class)
                .fetch()
                .one();
    }

    /**
     * @deprecated (when, why, refactoring advice...)
     */
    @Override
    @Deprecated
    public Flux<Region> getRegionsForClientId(Integer clientId,Integer lobId, Integer year) {
        return client.execute(SELECT_REGIONS_BY_CLIENT_ID)
                .bind(ClientGoalConstants.YEAR, year)
                .bind(ClientGoalConstants.LOB_ID, lobId)
                .bind(ClientGoalConstants.CLIENT_ID, clientId)
                .as(Region.class)
                .fetch()
                .all();
    }

    @Override
    public Flux<Region> getRegionsForRequestType(Integer clientId, Integer lobId, RegionsRequestBody regionsRequestBody) {
        String filterQuery = getFilterQueryForRegionsRequestType(regionsRequestBody);
        return client.execute(String.format(SELECT_REGIONS_BY_PARAMS,filterQuery))
                .bind(ClientGoalConstants.PROGRAM_YEAR,regionsRequestBody.getProgramYear())
                .bind(ClientGoalConstants.LOB_ID, lobId)
                .bind(ClientGoalConstants.CLIENT_ID, clientId)
                .as(Region.class)
                .fetch()
                .all();
    }

    private String getFilterQuery(RegionGoalTypeRequestBody regionGoalTypeRequestBody) {
        String quarterlyParameter = " AND GD.Quarter='%s' AND GD.YEAR=%s ";
        String monthlyParameter = " AND GD.Month='%s' AND GD.YEAR=%s ";
        String query ;
        if(ClientGoalConstants.MONTHLY.equalsIgnoreCase(regionGoalTypeRequestBody.getIntervalType())){
            query = String.format(monthlyParameter,regionGoalTypeRequestBody.getIntervalValue(), regionGoalTypeRequestBody.getYear());
        }else if(ClientGoalConstants.QUARTERLY.equalsIgnoreCase(regionGoalTypeRequestBody.getIntervalType())){
            query = String.format(quarterlyParameter,regionGoalTypeRequestBody.getIntervalValue(), regionGoalTypeRequestBody.getYear());
        } else {
            query = StringUtils.EMPTY;
        }
        return query;
    }

    private String getFilterQueryForRegionsRequestType(RegionsRequestBody regionsRequestBody) {
        String quarterlyParameter = " AND GD.Quarter='%s' AND GD.YEAR=%s";
        String monthlyParameter = " AND GD.Month='%s' AND GD.YEAR=%s";
        String query;
        if(ClientGoalConstants.MONTHLY.equalsIgnoreCase(regionsRequestBody.getIntervalType())){
            query = String.format(monthlyParameter,regionsRequestBody.getIntervalValue(), regionsRequestBody.getYear());
        }else if(ClientGoalConstants.QUARTERLY.equalsIgnoreCase(regionsRequestBody.getIntervalType())){
            query = String.format(quarterlyParameter,regionsRequestBody.getIntervalValue(), regionsRequestBody.getYear());
        }else{
            query = StringUtils.EMPTY;
        }
        return query;
    }
}

