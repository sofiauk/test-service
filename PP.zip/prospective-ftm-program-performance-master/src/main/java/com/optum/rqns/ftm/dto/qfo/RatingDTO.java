package com.optum.rqns.ftm.dto.qfo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RatingDTO {
	private Float overallStarRating;
	private Float gettingNeededCare;
	private Float careCoordination;
	private Float doctorConversations;
	private LocalDateTime lastUpdatedDate;
}
