package com.optum.rqns.ftm.repository.performance.providergrp;

import com.optum.rqns.ftm.constants.DerivedDeploymentReturnNetCNAConstants;
import com.optum.rqns.ftm.enums.RoleType;
import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.dto.performance.providergrp.AssignedProviderGroupPerformanceDTO;
import com.optum.rqns.ftm.dto.performance.providergrp.ProviderGroupLobPerformanceDTO;
import com.optum.rqns.ftm.dto.performance.providergrp.ProviderGroupPerformanceYTDGraphDTO;
import com.optum.rqns.ftm.model.performance.providergrp.AssignedProviderGroupOpportunities;
import com.optum.rqns.ftm.model.performance.providergrp.ProviderGroupStateDerivedDeployments;
import com.optum.rqns.ftm.model.performance.providergrp.ProviderGroupStateReturnsNetCNA;
import com.optum.rqns.ftm.util.ProgramPerformanceUtil;
import io.r2dbc.spi.Row;
import org.springframework.data.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import static com.optum.rqns.ftm.constants.ProviderGroupConstants.*;


@Repository
public class ProviderGroupPerformanceRepositoryImpl implements ProviderGroupPerformanceRepository, DTOWrapperTypeConverter {

    private final DatabaseClient client;

    public ProviderGroupPerformanceRepositoryImpl(DatabaseClient client) {
        this.client = client;
    }

    public enum ColumnNames {
        PROVIDER_GROUP_ID("ProviderGroupId"), STATE("State"), PROVIDER_GROUP_NAME("ProviderGroupName"),
        SERVICE_LEVEL("ServiceLevel"), LOB_NAME("LobName"), PROGRAM_YEAR("ProgramYear"), CLIENT_NAME("ClientName"),
        RETURN_YE_TARGET_PERCENT("ReturnYETargetPercent"), RETURN_YTD_TARGET("ReturnYTDTarget"),
        RETURN_YTD_TARGET_PERCENT("ReturnYTDTargetPercent"), DEPLOY_YTD_ACTUAL("DeployYTDActual"),
        RETURN_YTD_ACTUAL("ReturnYTDActual"), RETURN_NET_CNA_YTD_ACTUAL("ReturnedNetCNAYTDActual"),
        DEPLOYMENT_START_DATE("DeploymentStartDate"), LAST_DEPLOYMENT_DATE("LastDeploymentDate"),
        RETURN_YE_TARGET("ReturnYETarget"), DURATION_END_DATE("DurationEndDate"), OWNER_UUID("OwnerUUID"),
        REJECTS("Rejects"), JOB_NAMES("JobNames"), LAST_ACTIVITY_AGO("LastActivityAgo"),
        PROVIDER_GROUP_IDS("PROVIDER_GROUP_IDS"), RETURNS("Returns"), OUTLIERS("Outliers"),
        SECONDARY_SUBMISSION("SecondarySubmission"), FINANCIAL_INFORMATION("FinancialInformation"), TIN("Tin"),
        OPPORTUNITIES_COUNT("OpportunitiesCount"), OPPORTUNITIES_TYPE("OpportunitiesType"), GAPS_COUNT("GapsCount"),
        LAST_ACTIVITY_DATE("LastActivityDate"), UUID("UUID"), MONTH("month"), YEAR("year"),
        DURATION_VALUE("durationValue"), START_DATE("startDate"), END_DATE("endDate"),
        DEPLOY_YE_TARGET("DeployYETarget"), ELIGIBLE_DEPLOYABLE_MEMBER_COUNT("EligibleDeployableMemberCount"),
        DEPLOY_YTD_TARGET("DeployYTDTarget"), UPDATED_DATE("UpdatedDate"),
        RETURNED_NET_CNA_ACTUAL("ReturnedNetCnaYtdActual"),
        ELIGIBLE_PREFERRED_MEMBER_COUNT("EligiblePreferredMemberCount"), RETURNED_START_DATE("ReturnedStartDate"),
        LAST_RETURNED_DATE("LastReturnedDate"), TYPE("Type"), NAME("Name"), OFFSET("Offset"), LIMIT("Limit");

        private String columnName;

        ColumnNames(String columnName) {
            this.columnName = columnName;
        }

        public String getColumnName() {
            return this.columnName;
        }
    }

    private static final String PROVIDER_GROUP_PERFORMANCE =
            "select ProviderGroupID,ProviderGroupName,State,ServiceLevel,LobName,ClientName," +
                    " ProgramYear,ReturnYETargetPercent,ReturnYTDTargetPercent, PnODeployYETarget as DeployYETarget,DeployYTDActual,ReturnYTDActual," +
                    " PnOReturnYTDTarget as ReturnYTDTarget, PnOReturnYETarget as ReturnYETarget,DeploymentStartDate,LastDeploymentDate,DurationEndDate,EligibleDeployableMemberCount, PnODeployYTDTarget as DeployYTDTarget,UpdatedDate," +
                    " EligiblePreferredMemberCount, ReturnedNetCnaYtdActual, ReturnedStartDate, LastReturnedDate" +
                    " from ProgPerf.ProviderGroupPerformance  WITH (NOLOCK) " +
                    " where ProviderGroupID = upper(RTRIM(LTRIM(:ProviderGroupId)))" +
                    "   and State= upper(RTRIM(LTRIM(:State)))" +
                    "   and ClientName=:ClientName" +
                    "   and ServiceLevel=upper(RTRIM(LTRIM(:ServiceLevel)))" +
                    "   and ProgramYear = :ProgramYear" +
                    "   and isCurrentWeekForPerformance = 1" +
                    "   and LobName is not null" +
                    "   and RTRIM(LTRIM(LobName)) != ''" +
                    " order by LobName asc";


    private static final String PROVIDER_GROUP_PERFORMANCE_RULES =
            "select ProviderGroupID,ProviderGroupName,State,ServiceLevel,LobName,ClientName," +
                    " ProgramYear,ReturnYETargetPercent,ReturnYTDTargetPercent,DeployYTDActual,ReturnYTDActual," +
                    " ReturnYTDTarget,ReturnYETarget,DeploymentStartDate,LastDeploymentDate,DurationEndDate" +
                    " from ProgPerf.ProviderGroupPerformance  WITH (NOLOCK) " +
                    " where ProviderGroupID = upper(RTRIM(LTRIM(:ProviderGroupId)))" +
                    "   and State= upper(RTRIM(LTRIM(:State)))" +
                    "   and ServiceLevel=upper(RTRIM(LTRIM(:ServiceLevel)))" +
                    "   and ProgramYear = :ProgramYear" +
                    "   and isCurrentWeekForRules = 1" +
                    "   and LobName is not null" +
                    " order by LobName asc";

    private static final String ASSIGNED_PROVIDER_GROUP_PERFORMANCE =
            "with pjIds as (select distinct a.GroupId as pgGrpId, a.State   from ProgPerf.Accounts a WITH (NOLOCK)" +
                    " join ProgPerf.AccountOwner AO on AO.AccountId= a.AccountId" +
                    " and ao.OwnerUUID = :OwnerUUID %s )" +
                    " select LastActivityAgo,rejects,PerformanceDetails.*" +
                    " from " +
                    "  (select sum(pgos.TotalAssessmentsCount) as rejects" +
                    " from ProgPerf.ProviderGroupOpportunitiesSummary pgos with (NOLOCK) " +
                    "  join pjIds on pgos.ProviderGroupID = pjIds.pgGrpId and pgos.state = pjIds.state " +
                    "  and MasterLevelOpportunity =:Rejects and ProgramYear = :ProgramYear" +
                    " ) as rejectsCount," +
                    " (select sum(DeployYTDActual) as DeployYTDActual,sum(ReturnYTDActual) as ReturnYTDActual, sum(ReturnedNetCNAYTDActual) as ReturnedNetCNAYTDActual " +
                    " ,sum(ReturnYTDTarget) as ReturnYTDTarget,sum(ReturnYETarget) as ReturnYETarget" +
                    " , sum(DeployYTDTarget) as DeployYTDTarget, sum(DeployYETarget) DeployYETarget,  datediff(hour, getUTCDate(),max(p.UpdatedDate ))  as LastActivityAgo" +
                    " from ProgPerf.ProviderGroupPerformance p WITH (NOLOCK) " +
                    "  join pjIds on p.ProviderGroupID = pjIds.pgGrpId and p.state = pjIds.state " +
                    "  and p.ServiceLevel = :All " +
                    " where  ClientName= :All " +
                    "  and ProgramYear = :ProgramYear" +
                    "  and isCurrentWeekForPerformance = 1" +
                    " ) as PerformanceDetails";

    private static final String ASSIGNED_PROVIDER_GROUP_OPPORTUNITIES = "select pg.*,p.ReturnYTDActual,p.ReturnYTDTargetPercent,pos.MasterLevelOpportunity as OpportunitiesType, pos.TotalAssessmentsCount as OpportunitiesCount,pos.TotalGapsCount as GapsCount," +
            " (select datediff(hour, max(CreatedDate),getUTCDate()) as LastActivityAgo from " +
            " ProgPerf.ProviderGroupOpportunitiesSummary summary where summary.ProviderGroupID in ( select a.GroupId from ProgPerf.ProviderGroup pg, ProgPerf.Accounts a, ProgPerf.AccountOwner AO " +
            " where pg.ProviderGroupID = a.GroupId and pg.state = a.state and AO.AccountId= a.AccountId " +
            " and ao.OwnerUUID = :UUID )) as LastActivityAgo from " +
            "(select TOP 3 a.GroupId as ProviderGroupId, pg.ProviderGroupName as ProviderGroupName,  a.state as State, CONVERT(int, pg.Priority) as Priority, a.ServiceLevel, " +
            " pg.TaxId as Tin, a.LastActivityDate as LastActivityDate from ProgPerf.ProviderGroup pg, ProgPerf.Accounts a, ProgPerf.AccountOwner AO " +
            " where pg.ProviderGroupID = a.GroupId and pg.state = a.state and AO.AccountId= a.AccountId " +
            " and ao.OwnerUUID = :UUID %s  order by case when Priority is null then 1 else 0 end, Priority, pg.providerGroupName " +
            " ) pg " +
            " left join (SELECT ProviderGroupID , state, ServiceLevel, IsCurrentWeekForPerformance, ClientName, ProgramYear, sum(ReturnYTDActual) as ReturnYTDActual, round(CAST(sum(ReturnYTDActual) AS float)/CAST(sum(DeployYTDActual) AS float)*100,0) as ReturnYTDTargetPercent from ProgPerf.ProviderGroupPerformance group by ProviderGroupID , state,IsCurrentWeekForPerformance, ClientName, ProgramYear, ServiceLevel) as p " +
            " ON p.ProviderGroupID = pg.ProviderGroupId and p.state = pg.State and p.IsCurrentWeekForPerformance=1 and p.ClientName='All' and p.ServiceLevel = 'ALL' and p.ProgramYear = (select mc.value from ProgPerf.MasterConfiguration mc WITH (NOLOCK) where mc.code='CurrentProgramYear') " +
            " left join ProgPerf.ProviderGroupOpportunitiesSummary pos on pos.providergroupid = pg.providergroupid and pos.state = pg.state " +
            " left join ProgPerf.ProviderGroupOpportunitiesSummary pos1 on pos1.providergroupid = pg.providergroupid and pos1.state = pg.state "+
            " group by pg.ProviderGroupId, pg.state, pg.ServiceLevel, pg.Tin, pg.LastActivityDate, pg.ProviderGroupName,p.ReturnYTDActual,p.ReturnYTDTargetPercent,pos.MasterLevelOpportunity,pos.TotalAssessmentsCount,pos.TotalGapsCount, pos.LastUpdatedDate, pg.Priority  order by case when pg.Priority is null then 1 else 0 end, pg.Priority,pg.ProviderGroupName " ;

    private static final String PROVIDER_GROUP_PERFORMANCE_YTD_GRAPH =
            ";WITH CTE_ProgramYear " +
                    "AS ( " +
                    "       SELECT StartDate " +
                    "             , EndDate " +
                    "             , DurationValue " +
                    "             , ProgramYear " +
                    "       FROM ProgPerf.ProgramYearCalendar pyc WITH (NOLOCK) " +
                    "       WHERE pyc.ProgramYear = :ProgramYear " +
                    "             AND pyc.DurationType = 'WEEK' " +
                    "       ) " +
                    "       , CTE_AccoutOwner " +
                    "AS (" +
                    "       SELECT AccountId " +
                    "       FROM ProgPerf.AccountOwner acct_owner WITH (NOLOCK) " +
                    "       WHERE acct_owner.OwnerUUID = :OwnerUUID " +
                    "       ) " +
                    "       , CTE_Accounts " +
                    "AS (" +
                    "       SELECT GroupId " +
                    "             , STATE " +
                    "             , ServiceLevel " +
                    "       FROM ProgPerf.Accounts accts WITH (NOLOCK) " +
                    "       INNER JOIN CTE_AccoutOwner  " +
                    "       ON accts.AccountId = CTE_AccoutOwner.AccountId " +
                    "       WHERE accts.ServiceLevel NOT IN (%s) " +
                    "       ) " +
                    "SELECT sum(pg_perf.EligibleDeployableMemberCount) AS EligibleDeployableMemberCount " +
                    "       , sum(pg_perf.DeployYETarget) AS DeployYETarget, sum(pg_perf.DeployYTDTarget) AS DeployYTDTarget,sum(pg_perf.DeployYTDActual) AS DeployYTDActual " +
                    "       , sum(pg_perf.ReturnYTDTarget) AS ReturnYTDTarget, sum(pg_perf.ReturnYETarget) AS ReturnYETarget,sum(pg_perf.ReturnYTDActual) AS ReturnYTDActual " +
                    "       , sum(pg_perf.ReturnedNetCnaYtdActual) AS ReturnedNetCnaYtdActual " +
                    "       , CTE_ProgramYear.startdate AS startdate, CTE_ProgramYear.enddate AS endDate, CTE_ProgramYear.durationValue AS durationValue " +
                    "       , Year(CTE_ProgramYear.startdate) AS year " +
                    "       , datename(month, CTE_ProgramYear.startdate) AS month " +
                    "       , month(CTE_ProgramYear.startdate) AS monthnum " +
                    "FROM ProgPerf.ProviderGroupPerformance pg_perf WITH (NOLOCK) " +
                    "INNER JOIN CTE_Accounts " +
                    "       ON pg_perf.providergroupid = CTE_Accounts.groupid " +
                    "             AND pg_perf.STATE = CTE_Accounts.STATE " +
                    "INNER JOIN CTE_ProgramYear " +
                    "       ON pg_perf.programyear = CTE_ProgramYear.programyear " +
                    "             AND pg_perf.durationValue = CTE_ProgramYear.durationValue " +
                    "WHERE  pg_perf.clientname = 'All' " +
                    "             AND pg_perf.servicelevel = 'All' " +
                    "GROUP BY CTE_ProgramYear.startdate " +
                    "       , CTE_ProgramYear.enddate " +
                    "       , CTE_ProgramYear.durationValue " +
                    "       , Year(CTE_ProgramYear.startdate) " +
                    "       , datename(month, CTE_ProgramYear.startdate) " +
                    "       , month(CTE_ProgramYear.startdate) " +
                    "ORDER BY year " +
                    "       , monthnum " +
                    "       , CTE_ProgramYear.startdate ASC; ";

   private static final String LANDING_PAGE_CURRENT_PROGRAM_YEAR = "IF (1=:hasQFORole) " +
            " SELECT value FROM progperf.masterconfiguration where code in ('QFOCurrentProgramYear', 'QFOPreviousProgramYear','QFOPreviousToPreviousProgramYear') ORDER BY value DESC " +
            " Else " +
            " SELECT value FROM progperf.masterconfiguration where code in ('CurrentProgramYear', 'PreviousProgramYear', 'PreviousToPreviousProgramYear') ORDER BY value DESC ";

    @Override
    public Flux<ProviderGroupLobPerformanceDTO> getProviderGroupPerformance(String providerGroupId, String state, String serviceLevel, int programYear) {
        return client.execute(PROVIDER_GROUP_PERFORMANCE)
                .bind(ColumnNames.PROVIDER_GROUP_ID.getColumnName(), providerGroupId)
                .bind(ColumnNames.STATE.getColumnName(), state)
                .bind(ColumnNames.SERVICE_LEVEL.getColumnName(), ALL)
                .bind(ColumnNames.CLIENT_NAME.getColumnName(), ALL)
                .bind(ColumnNames.PROGRAM_YEAR.getColumnName(), programYear)
                .as(ProviderGroupLobPerformanceDTO.class)
                .fetch()
                .all();
    }

    @Override
    public Flux<ProviderGroupLobPerformanceDTO> getProviderGroupPerformanceRules(String providerGroupId, String state, String serviceLevel, int programYear) {
        return client.execute(PROVIDER_GROUP_PERFORMANCE_RULES)
                .bind(ColumnNames.PROVIDER_GROUP_ID.getColumnName(), providerGroupId)
                .bind(ColumnNames.STATE.getColumnName(), state)
                .bind(ColumnNames.SERVICE_LEVEL.getColumnName(), serviceLevel)
                .bind(ColumnNames.PROGRAM_YEAR.getColumnName(), programYear)
                .as(ProviderGroupLobPerformanceDTO.class)
                .fetch()
                .all();
    }

    @Override
    public Mono<AssignedProviderGroupPerformanceDTO> getAssignedProviderGroupsPerformance(String uuid, int programYear, RoleType roleType) {
        String filterQuery = ProgramPerformanceUtil.excludeProvidersByRoles(roleType.getValue());
        return client.execute(String.format(ASSIGNED_PROVIDER_GROUP_PERFORMANCE, filterQuery))
                .bind(ColumnNames.OWNER_UUID.getColumnName(), uuid)
                .bind(ColumnNames.PROGRAM_YEAR.getColumnName(), programYear)
                .bind(ALL, ALL)
                .bind(REJECTS, REJECTS)
                .map((row, rowMetadata) -> AssignedProviderGroupPerformanceDTO
                        .builder()
                        .deployYTDActual(getLongValue(row, ColumnNames.DEPLOY_YTD_ACTUAL.getColumnName()))
                        .returnYETarget(getLongValue(row, ColumnNames.RETURN_YE_TARGET.getColumnName()))
                        .returnYTDActual(getLongValue(row, ColumnNames.RETURN_YTD_ACTUAL.getColumnName()))
                        .returnedNetCNAYTDActual(getLongValue(row, ColumnNames.RETURN_NET_CNA_YTD_ACTUAL.getColumnName()))
                        .returnYTDTarget(getLongValue(row, ColumnNames.RETURN_YTD_TARGET.getColumnName()))
                        .hoursAgo(row.get(ColumnNames.LAST_ACTIVITY_AGO.getColumnName(), Integer.class))
                        .rejects(getLongValue(row, ColumnNames.REJECTS.getColumnName()))
                        .programYear(programYear)
                        .deployYTDTarget(getLongValue(row, ColumnNames.DEPLOY_YTD_TARGET.getColumnName()))
                        .deployYETarget(getLongValue(row, ColumnNames.DEPLOY_YE_TARGET.getColumnName()))
                        .build()
                )
                .one();
    }

    @Override
    public Flux<AssignedProviderGroupOpportunities> getAssignedProviderGroupOpportunities(String uuid, RoleType roleType) {
        String filterQuery = ProgramPerformanceUtil.excludeProvidersByRoles(roleType.getValue());
        return client.execute(String.format(ASSIGNED_PROVIDER_GROUP_OPPORTUNITIES, filterQuery))
                .bind(ColumnNames.UUID.getColumnName(), uuid)
                .as(AssignedProviderGroupOpportunities.class)
                .fetch()
                .all();
    }

    @Override
    public Flux<ProviderGroupPerformanceYTDGraphDTO> getProviderGroupsPerformanceYTDReturns(String uuid, RoleType roleType, int programYear) {
        String filterQuery = ProgramPerformanceUtil.getExcludedProvidersByRolesList(roleType.getValue());
        return client.execute(String.format(PROVIDER_GROUP_PERFORMANCE_YTD_GRAPH, filterQuery))
                .bind(ColumnNames.OWNER_UUID.getColumnName(), uuid)
                .bind(ColumnNames.PROGRAM_YEAR.getColumnName(), programYear)
                .as(ProviderGroupPerformanceYTDGraphDTO.class)
                .fetch()
                .all();
    }

    @Override
    public Flux<ProviderGroupStateDerivedDeployments> getProviderGroupsStateDerivedDeploymentCounts(int programYear, String type, String name, String state, String serviceLevel, int offset, int limit) {
        ProviderGroupPerformanceQueryBuilder.Builder b = getProviderGroupPerformanceQueryBuilder(type, serviceLevel);
        b.asDerivedDeployment();
        return client.execute(b.build())
                .bind(ColumnNames.NAME.getColumnName(), name)
                .bind(ColumnNames.STATE.getColumnName(), state)
                .bind(ColumnNames.PROGRAM_YEAR.getColumnName(), programYear)
                .bind(ColumnNames.OFFSET.getColumnName(), offset)
                .bind(ColumnNames.LIMIT.getColumnName(), limit)
                .as(ProviderGroupStateDerivedDeployments.class)
                .map((row, rowMetadata) -> ProviderGroupStateDerivedDeployments
                        .builder()
                        .name(getStringValue(row, type))
                        .providerGroupId(getStringValue(row, ColumnNames.PROVIDER_GROUP_ID.getColumnName()))
                        .providerGroupName(getStringValue(row, ColumnNames.PROVIDER_GROUP_NAME.getColumnName()))
                        .serviceLevel(getStringValue(row, ColumnNames.SERVICE_LEVEL.getColumnName()))
                        .state(getStringValue(row, ColumnNames.STATE.getColumnName()))
                        .ytdActual(getLongValue(row, ColumnNames.DEPLOY_YTD_ACTUAL.getColumnName()))
                        .currentWeekCounts(getLongValue(row, "CurrentWeekDeploymentsCount"))
                        .previousWeekCounts(getLongValue(row, "PreviousWeekDeploymentsCount"))
                        .nextWeekForecastCounts(getLongValue(row, "NextWeekForcastDeploymentsCount"))
                        .opportunityCounts(getLongValue(row, "DeploymentsOpportunityAssessmentCount"))
                        .programYearGoal(getDoubleValue(row, ColumnNames.DEPLOY_YE_TARGET.getColumnName()))
                        .programYearVariance(getDoubleValue(row, "DeployYETargetVariance"))
                        .ytdGoal(getDoubleValue(row, ColumnNames.DEPLOY_YTD_TARGET.getColumnName()))
                        .ytdVariance(getDoubleValue(row, "DeployYTDTargetVariance"))
                        .build()
                )
                .all();
    }

    @Override
    public Flux<ProviderGroupStateReturnsNetCNA> getProviderGroupsStateReturnsNetCNACounts(int programYear, String type, String name, String state, String serviceLevel, int offset, int limit) {
        ProviderGroupPerformanceQueryBuilder.Builder b = getProviderGroupPerformanceQueryBuilder(type, serviceLevel);
        b.asReturnsNetCNA();
        return client.execute(b.build())
                .bind(ColumnNames.NAME.getColumnName(), name)
                .bind(ColumnNames.STATE.getColumnName(), state)
                .bind(ColumnNames.PROGRAM_YEAR.getColumnName(), programYear)
                .bind(ColumnNames.OFFSET.getColumnName(), offset)
                .bind(ColumnNames.LIMIT.getColumnName(), limit)
                .as(ProviderGroupStateReturnsNetCNA.class)
                .map((row, rowMetadata) -> ProviderGroupStateReturnsNetCNA
                        .builder()
                        .name(getStringValue(row, type))
                        .providerGroupId(getStringValue(row, ColumnNames.PROVIDER_GROUP_ID.getColumnName()))
                        .providerGroupName(getStringValue(row, ColumnNames.PROVIDER_GROUP_NAME.getColumnName()))
                        .serviceLevel(getStringValue(row, ColumnNames.SERVICE_LEVEL.getColumnName()))
                        .state(getStringValue(row, ColumnNames.STATE.getColumnName()))
                        .ytdActual(getLongValue(row, ColumnNames.RETURN_YTD_ACTUAL.getColumnName()))
                        .currentWeekCounts(getLongValue(row, "CurrentWeekReturnsCount"))
                        .previousWeekCounts(getLongValue(row, "PreviousWeekReturnsCount"))
                        .nextWeekForecastCounts(getLongValue(row, "NextWeekForcastReturnsCount"))
                        .opportunityCounts(getLongValue(row, "ReturnsOpportunityAssessmentCount"))
                        .programYearGoal(getDoubleValue(row, ColumnNames.RETURN_YE_TARGET.getColumnName()))
                        .programYearVariance(getDoubleValue(row, "ReturnYETargetVariance"))
                        .ytdGoal(getDoubleValue(row, ColumnNames.RETURN_YTD_TARGET.getColumnName()))
                        .ytdVariance(getDoubleValue(row, "ReturnYTDTargetVariance"))
                        .build()
                )
                .all();
    }
    @Override
    public Flux<String> getCurrentProgramYear(String userRole) {
        return client.execute(LANDING_PAGE_CURRENT_PROGRAM_YEAR)
                .bind("hasQFORole", userRole.trim().isEmpty()? 0: 1)
                .as(String.class)
                .fetch()
                .all();
    }

    String getStringValue(Row row, String columnName) {
        return getValue(row, columnName, String.class);
    }

    private ProviderGroupPerformanceQueryBuilder.Builder getProviderGroupPerformanceQueryBuilder(String type, String serviceLevel) {
        ProviderGroupPerformanceQueryBuilder.Builder b = ProviderGroupPerformanceQueryBuilder.builder();

        switch (type) {
            case DerivedDeploymentReturnNetCNAConstants.TYPE_REGION:
                b.asByRegion();
                break;
            case DerivedDeploymentReturnNetCNAConstants.TYPE_LOB_NAME:
                b.asByLobName();
                break;
            case DerivedDeploymentReturnNetCNAConstants.TYPE_CLIENT_NAME:
                b.asByClientName();
                break;
            default:
                b.asByRegion();
                break;
        }

        switch (serviceLevel) {
            case DerivedDeploymentReturnNetCNAConstants.SERVICE_LEVEL_ALL:
                b.asByAll();
                break;
            case DerivedDeploymentReturnNetCNAConstants.SERVICE_LEVEL_HCA:
                b.asByHSCA();
                break;
            case DerivedDeploymentReturnNetCNAConstants.SERVICE_LEVEL_PSC:
                b.asByPSC();
                break;
            default:
                b.asByRegion();
                break;
        }
        return b;
    }

}
