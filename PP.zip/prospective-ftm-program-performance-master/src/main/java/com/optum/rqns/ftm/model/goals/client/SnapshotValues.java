package com.optum.rqns.ftm.model.goals.client;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@Builder
@AllArgsConstructor
//@JsonInclude(JsonInclude.Include.NON_NULL)
public class SnapshotValues {
    private Double deployValue;
    private Double deployPercentage;
    private Double eligibleMembers;
    private Double returnValue;
    private Double returnPercentage;
    private Double completedValue;
    private Double completedPercentage;
    private Long secondarySubmissionValue;
    private Double secondarySubmissionPercentage;
    private Double riskGapAssessmentPercentage;
    private Double qualityGapAssessmentPercentage;
    private Double riskDocumentVerificationPercentage;
    private Double qualityDocumentVerificationPercentage;
    private Double riskGapClosurePercentage;
    private Double diagnosedVerifiedPercentage;
}