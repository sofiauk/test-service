package com.optum.rqns.ftm.model.qfo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.time.LocalDateTime;

@Data
@Builder
@EqualsAndHashCode
@NoArgsConstructor
@ToString
@AllArgsConstructor
public class StarRating {
    private Integer programYear;
    private String month;
    private Float overallStarRating;
    private Float mapCpiStarRating;
    private LocalDateTime updatedDate;
}
