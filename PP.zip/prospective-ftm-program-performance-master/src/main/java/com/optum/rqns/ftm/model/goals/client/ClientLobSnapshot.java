package com.optum.rqns.ftm.model.goals.client;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"lobId","name","goalStatus","lastUpdated","goalValues"})
public class ClientLobSnapshot {
    @JsonProperty("name")
    private String lobName;
    @JsonProperty("lobId")
    private long lobId;
    private String goalStatus;
    private String lastUpdated;
    @JsonProperty("goalValues")
    private SnapshotValues snapshotValues;
}