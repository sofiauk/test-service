package com.optum.rqns.ftm.dto.fieldleader;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EModalityDTO {

    private EModality national;
    private EModality myTeam;
    private LocalDateTime updatedDate;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class EModality {
        private Integer returnedNetCnaTotal;
        private Integer opaf;
        private Integer optumUpload;
        private Integer ogm;
        private Integer eData;
    }
}
