package com.optum.rqns.ftm.response.commandcenter;

import com.optum.rqns.ftm.dto.commandcenter.ProviderGroupClientMembersCountDto;
import com.optum.rqns.ftm.wrapper.Meta;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.ToString;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Data
@ToString
@AllArgsConstructor
@Builder
public class ProviderGroupClientLobResponse {
    private Meta meta;

    private ProviderGroupClientLobWrapper data;


    public ProviderGroupClientLobResponse() {
        this.meta = new Meta();
        this.data = new ProviderGroupClientLobWrapper(new ArrayList<>(),LocalDateTime.now());
    }
}
