package com.optum.rqns.ftm.dto.fieldleader;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class IOAPerformanceRatesDTO {

    private IOAPerformanceRates nationalIOAPerformanceRates;
    private IOAPerformanceRates myTeamIOAPerformanceRates;

    @Data
    @Builder
    public static class IOAPerformanceRates {
        private Integer derivedDeployedCount;
        private Integer eligibleDeployableMemberCount;
        private Integer rejectsCount;
        private Integer returnNetCNACount;
        private Integer cgapClosedSuspect;
        private Integer cgapTotalSuspect;
    }
}
