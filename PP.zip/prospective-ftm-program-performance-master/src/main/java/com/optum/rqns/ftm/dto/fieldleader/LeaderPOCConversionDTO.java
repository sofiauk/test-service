package com.optum.rqns.ftm.dto.fieldleader;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class LeaderPOCConversionDTO extends LeaderBaseDTO<LeaderPOCConversionDTO> {
    private Double prevMonthConversionRateNew;
    private Double currentMonthConversionRateNew;
    private Double monthOverMonthChangeNew;
    private Double prevMonthConversionRateExisting;
    private Double currentMonthConversionRateExisting;
    private Double monthOverMonthChangeExisting;
}
