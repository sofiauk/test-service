package com.optum.rqns.ftm.repository.fieldleader;

import com.optum.rqns.ftm.dto.fieldleader.AnnualCareVisitsDTO;
import com.optum.rqns.ftm.dto.fieldleader.QualityGapsDTO;
import com.optum.rqns.ftm.dto.fieldleader.RiskQualityGapsSummaryDTO;
import com.optum.rqns.ftm.dto.fieldleader.SuspectConditionsDTO;
import com.optum.rqns.ftm.model.programyearcalendar.CurrentPreviousMonth;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface LeaderOpportunitiesDetailsRepository {
    Flux<QualityGapsDTO> getQualityGaps(String uuid, int programYear, String sortColumn, String sortOrder, int offset, int limit, CurrentPreviousMonth currentPreviousMonth);
    Flux<AnnualCareVisitsDTO> getAnnualCareVisits(String uuid, int programYear, CurrentPreviousMonth currentPreviousMonth);
    Flux<SuspectConditionsDTO> getSuspectConditions(String uuid, int programYear, CurrentPreviousMonth currentPreviousMonth);
    Flux<RiskQualityGapsSummaryDTO> getRiskQualityGapsSummary(String uuid, int programYear, CurrentPreviousMonth currentPreviousMonth);
    Mono<Long> getQualityGapsCount(String uuid, int programYear, CurrentPreviousMonth currentPreviousMonth);
}
