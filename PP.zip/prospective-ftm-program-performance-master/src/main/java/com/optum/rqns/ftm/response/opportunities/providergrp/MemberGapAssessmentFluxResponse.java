package com.optum.rqns.ftm.response.opportunities.providergrp;

import com.optum.rqns.ftm.model.opportunities.providergrp.MemberAssessmentClients;
import com.optum.rqns.ftm.wrapper.Meta;
import lombok.Data;
import org.apache.avro.generic.GenericData;
import reactor.core.publisher.Flux;

import java.util.ArrayList;
import java.util.List;

@Data
public class MemberGapAssessmentFluxResponse{
    private Meta meta;

    private List<Object> data;
    public MemberGapAssessmentFluxResponse(){
        this.meta = new Meta();
        this.data = new ArrayList<>();
    }

}
