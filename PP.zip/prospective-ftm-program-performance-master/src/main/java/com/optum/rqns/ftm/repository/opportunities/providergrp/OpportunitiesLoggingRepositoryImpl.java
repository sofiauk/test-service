package com.optum.rqns.ftm.repository.opportunities.providergrp;

import com.optum.rqns.ftm.model.opportunities.providergrp.OpportunitiesLogging;
import com.optum.rqns.ftm.repository.common.CommonRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.stream.Collectors;


@Slf4j
@Repository
public class OpportunitiesLoggingRepositoryImpl implements OpportunitiesLoggingRepository {

    @Autowired
    private CommonRepository commonRepository;

    private static final String INSERT_OPPORTUNITY_LOGGING = "INSERT INTO ProgPerf.OpportunitesLogging " +
            "(MasterOpportunityType,OpportunityType,OpportunitySubType,ProviderGroupID,ProviderGroupName,Tin,State,MemberID,ChartID,ProgramYear,ExportedBy,ExportedDate,ExportedByEmail,RequestId) " +
            "VALUES ('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', GETUTCDATE(), '%s', '%s')";


    private String getFormattedQueryToInsertIntoOpportunitesLogging(OpportunitiesLogging detail) {
        return String.format (INSERT_OPPORTUNITY_LOGGING,
                detail.getMasterOpportunityType (),
                detail.getOpportunityType (),
                detail.getOpportunitySubType (),
                detail.getProviderGroupID (),
                detail.getProviderGroupName (),
                detail.getTin (),
                detail.getState (),
                detail.getMemberID (),
                detail.getChartID (),
                detail.getProgramYear (),
                detail.getExportedBy (),
                detail.getExportedDate (),
                detail.getExportedByEmail (),
                detail.getRequestId ()
        );
    }

    @Override
    public Mono<Long> batchQueriesExecuteForInsertOpportunitiesLogging(List<OpportunitiesLogging> opportunitiesLoggings) {
        log.info ("Try generate a batch of insert queries, list size {} ",opportunitiesLoggings.size ());
        List<String> updateQueries = opportunitiesLoggings.stream ()
                .map (this::getFormattedQueryToInsertIntoOpportunitesLogging)
                .collect (Collectors.toList ());
        log.info ("Try run a batch of insert queries, batch size {} ",updateQueries.size ());
        return commonRepository.updateBatchQueries (updateQueries);

    }
}
