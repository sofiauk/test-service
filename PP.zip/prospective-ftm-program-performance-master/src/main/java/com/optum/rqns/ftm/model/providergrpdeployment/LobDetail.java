package com.optum.rqns.ftm.model.providergrpdeployment;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class LobDetail {
    private String lob;
    private List<ClientDetail> clients;
}