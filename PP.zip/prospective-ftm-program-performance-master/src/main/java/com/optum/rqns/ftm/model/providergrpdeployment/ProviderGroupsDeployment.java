package com.optum.rqns.ftm.model.providergrpdeployment;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class ProviderGroupsDeployment {
    private String providerGroupID;
    private String state;
    private int programYear;
    private int deploymentsCount;
    private int returnsCount;
    private int returnsNetCnaCount;
}