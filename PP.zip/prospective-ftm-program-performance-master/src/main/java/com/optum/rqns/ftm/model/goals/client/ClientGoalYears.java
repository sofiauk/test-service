package com.optum.rqns.ftm.model.goals.client;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
public class ClientGoalYears {
    private int defaultYear;
    private List<Integer> programYears;
}
