package com.optum.rqns.ftm.model.performance.providergrp.qfo;

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
public class QFOSuspectConditions {
    Long totalPatients;
    Long suspectConditionsTotal;
    Long suspectConditionAssessedTotal;
    Long suspectDiagnosed;
    Long suspectUndiagnosed;
    Long suspectNotAssessed;
    Long mcaipFullyAssessed;
    Long mcaipTotalPatients;
    Long mcaipSuspectMedicalConditions;
    Long conditionAssessedTarget;
    Boolean conditionAssessedMeetsTarget;
    Long conditionAssessedPercentage;
    Long mcaipAssessedPatientsPercentage;
    Long suspectDiagnosedPercentage;
    Long suspectUndiagnosedPercentage;
    Long suspectNotAssessedPercentage;
    LocalDateTime updatedDate;
}
