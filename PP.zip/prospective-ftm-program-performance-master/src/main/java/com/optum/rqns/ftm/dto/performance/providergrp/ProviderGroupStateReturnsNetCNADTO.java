package com.optum.rqns.ftm.dto.performance.providergrp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ProviderGroupStateReturnsNetCNADTO {

    private String name;
    private String state;
    private String providerGroupId;
    private String providerGroupName;
    private String serviceLevel;
    private ReturnsNetCNAWeeksDTO returns;
    private ReturnsNetCNAYearsDTO programYear;
    private ReturnsNetCNAYearsDTO ytd;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ReturnsNetCNAWeeksDTO {
        private Long ytdActual;
        private Long currentWeekCounts;
        private Long previousWeekCounts;
        private Long nextWeekForecastCounts;
        private Long opportunityCounts;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ReturnsNetCNAYearsDTO {
        private Double goal;
        private Double variance;
    }
}
