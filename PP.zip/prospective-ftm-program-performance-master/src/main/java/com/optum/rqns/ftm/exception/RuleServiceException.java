package com.optum.rqns.ftm.exception;


import lombok.Getter;

@Getter
public class RuleServiceException extends RuntimeException {
    private static final long serialVersionUID = 1905122041950251457L;

    private final String errorMessage;
    private final String errorDetails;
    private final String jobName;

    public RuleServiceException(String message, String details, String jobName) {
        super(details);
        this.errorMessage = message;
        this.errorDetails = details;
        this.jobName = jobName;
    }
}
