package com.optum.rqns.ftm.configuration;

import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.avro.models.v1.program.performance.provider.ProgPerfProviderMSSync;
import io.confluent.kafka.serializers.KafkaAvroDeserializer;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.KafkaListenerContainerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.listener.ConcurrentMessageListenerContainer;


@Configuration
@Slf4j
public class GCPKafkaConfiguration extends GCPBaseKafkaConfiguration{

    @Bean
    public KafkaTemplate<String, ProgPerfProviderMSSync> opportunitySummaryKafkaTemplateV1() {
        return new KafkaTemplate<>(gcpProducerFactory("progPerfProviderSync", Constants.OFC));
    }

    @Bean
    public KafkaTemplate<String, JobEvent> jobEventKafkaTemplate() {
        return new KafkaTemplate<>(gcpProducerFactory("jobEvent", Constants.OFC));
    }

    @Bean
    public KafkaListenerContainerFactory<ConcurrentMessageListenerContainer<String, Object>> jobEventKafkaListenerContainerFactory() {

        return gcpCreateContainerFactory( new StringDeserializer(), new KafkaAvroDeserializer(),
                  gcpKafkaProperties.getProperties().get("topics.jobEvent"),
                Constants.CONSUMER_JOBEVENT, Constants.OFC);
    }

}