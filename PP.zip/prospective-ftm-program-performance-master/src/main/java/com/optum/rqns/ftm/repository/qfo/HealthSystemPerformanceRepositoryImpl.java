package com.optum.rqns.ftm.repository.qfo;

import com.optum.rqns.ftm.constants.ProviderGroupConstants;
import com.optum.rqns.ftm.dto.qfo.performance.healthSystem.QFOHealthSystemPerformanceDetailsDTO;
import org.springframework.data.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Repository;

import reactor.core.publisher.Flux;
import com.optum.rqns.ftm.dto.qfo.performance.healthSystem.HealthSystemPerformanceDetailsDTO;

import reactor.core.publisher.Mono;

@Repository
public class HealthSystemPerformanceRepositoryImpl implements HealthSystemPerformanceRepository {

	private static final String FETCH_HEALTHSYSTEM_DETAILS=
			"with template as( " +
			"select  pgp.HealthSystemId as HealthSystemId, " +
			"pgp.HealthSystemName as HealthSystemName, " +
			"pgp.ProgramYear as ProgramYear, " +
			"sum(pgp.TotalPatients) as TotalPatients, " +
			"sum(pgp.McaipTotalPatients) as McaipTotalPatients, " +
			"sum(pgp.MapCpiEligiblePatients) as MapCpiEligiblePatients, " +
			"sum(pgp.MapCpiAnnualCareVisits) as MapCpiAnnualCareVisits, " +
			"sum(pgp.SuspectConditionsTotal) as SuspectConditionsTotal, " +
			"sum(pgp.SuspectConditionsAssessedTotal) as SuspectConditionsAssessedTotal, " +
			"sum(pgp.SuspectConditionsAssessedDiagnosed) as SuspectConditionsAssessedDiagnosed, " +
			"sum(pgp.SuspectConditionsAssessedUndiagnosed) as SuspectConditionsAssessedUndiagnosed, " +
			"sum(pgp.SuspectConditionsNotAssessed) as SuspectConditionsNotAssessed, " +
			"sum(pgp.McaipPatientsFullyAssessed) as McaipPatientsFullyAssessed, " +
			"sum(pgp.McaipSuspectMedicalConditions) as McaipSuspectMedicalConditions, " +
			"pgp.TeamType as TeamType, " +
			"pgp.DurationValue as DurationValue, " +
			"max(pgp.UpdatedDate) as UpdatedDate, " +
			"max(pgp.MapCpiLastUpdated) as MapCpiLastUpdated, " +
			"max(pgp.McaipLastUpdated) as McaipLastUpdated, " +
			"pgp.MapCpiPatientExperience as MapCpiPatientExperience " +
			"FROM ProgPerf.ProviderGroupPerformanceDetails pgp " +
			"where pgp.HealthSystemId = :HEALTHSYSTEMID " +
			"and pgp.ProgramYear =:programYear " +
			"group by " +
			"pgp.ProgramYear, " +
			"pgp.DurationValue, " +
			"pgp.HealthSystemId, " +
			"pgp.TeamType, " +
			"pgp.MapCpiPatientExperience, " +
			"pgp.HealthSystemName) " +
			"select t.*, " +
			"cpyc.StartDate, " +
			"cpyc.[Month], " +
			"pcmc.[MA-PCPi_Star_Rating_Target], " +
			"pcmc.[Overall_Star_Rating_Target], " +
			"pcmc.[Annual_Care_Visits_Target], " +
			"pcmc.[Suspect_Conditions_Target], " +
			"pcmc.[Part_D_Star_Rating_Target], " +
			"pcmc.[Assessed_And_Unable_To_Diagnose_Target], " +
			"srgp.MapcpiRating as MapCpiStarRating, " +
			"srgp.PartDRating as MapCpiPartDStarRating, " +
			"srgp.OverallRating as OverAllStarRating, " +
			"srgp.AcoRating as AcpStarRating " +
			"from template t " +
			"INNER JOIN ProgPerf.StarRatingGlidePath srgp ON " +
			"srgp.ProgramYear = t.ProgramYear " +
			"and srgp.HealthSystemId = t.HealthSystemId " +
			"and srgp.RatingType = 'HEALTHSYSTEM' " +
			"and srgp.DurationValue = t.DurationValue " +
			"right join ProgPerf.CommonProgramYearCalender cpyc on " +
			"cpyc.DurationValue = t.DurationValue " +
			"and cpyc.ProgramYear = t.ProgramYear " +
			"left join ( " +
			"select * " +
			"from ( " +
			"SELECT distinct [Key], " +
			"Value " +
			"from ProgPerf.CategoryMasterConfiguration " +
			"where " +
			"Name in ('QFO_RatingTargets') " +
			"and ProgramYear =:programYear ) as cmc PIVOT ( max(value) FOR [Key] IN (Annual_Care_Visits_Target, \"MA-PCPi_Star_Rating_Target\", Overall_Star_Rating_Target, Part_D_Star_Rating_Target, Suspect_Conditions_Target, Assessed_And_Unable_To_Diagnose_Target) ) AS cc) as pcmc on " +
			"1 = 1 " +
			"where cpyc.DurationType = 'MONTH' " +
			"and cpyc.programyear = :programYear " +
			" ";
			


	public static final String PERFORMANCE_QUERY = "with aggregratePerformance as (  " +
			"select  " +
			" pgp.HealthSystemId as HealthSystemId,  " +
			" pgp.HealthSystemName as HealthSystemName,  " +
			" SUM(pgp.TotalPatients) as TotalPatients,  " +
			" SUM(pgp.MapCpiEligiblePatients) as MapCpiEligiblePatients,  " +
			" pgp.MapCpiPatientExperience as MapCpiPatientExperience,  " +
			" SUM(pgp.McaipTotalPatients) as McaipTotalPatients,  " +
			" SUM(pgp.MapCpiAnnualCareVisits) as MapCpiAnnualCareVisits,  " +
			" SUM(pgp.SuspectConditionsTotal) as SuspectConditionsTotal,  " +
			" SUM(pgp.SuspectConditionsAssessedTotal) as SuspectConditionAssessedTotal,  " +
			" SUM(pgp.SuspectConditionsAssessedDiagnosed) as SuspectDiagnosed,  " +
			" SUM(pgp.SuspectConditionsAssessedUndiagnosed) as SuspectUndiagnosed,  " +
			" SUM(pgp.SuspectConditionsNotAssessed) as SuspectNotAssessed,  " +
			" SUM(pgp.McaipPatientsFullyAssessed) as McaipFullyAssessed,  " +
			" SUM(pgp.McaipSuspectMedicalConditions) as McaipSuspectMedicalConditions,  " +
			" MAX(pgp.UpdatedDate) as UpdatedDate,  " +
			" MAX(pgp.MapCpiLastUpdated) as MapCpiLastUpdated,  " +
			" pgp.DurationValue as DurationValue,  " +
			" MAX(pgp.McaipLastUpdated) as McaipLastUpdated,  " +
			" pgp.TeamType as TeamType,  " +
			" pgp.ProgramYear as ProgramYear  " +
			"from  " +
			" ProgPerf.ProviderGroupPerformanceDetails pgp WITH (NOLOCK)  " +
			"where  " +
			" pgp.HealthSystemId = :healthSystemId  " +
			" and pgp.ProgramYear =:programYear  " +
			" and DurationValue =(  " +
			" select  " +
			"  top 1 DurationValue  " +
			" from  " +
			"  progperf.ProviderGroupPerformanceDetails pgp  " +
			" where  " +
			"  ProgramYear = :programYear  " +
			"  and TeamType = 'QFO'  " +
			" order by  " +
			"  createdDate desc )  " +
			"group by  " +
			" pgp.ProgramYear,  " +
			" pgp.DurationValue,  " +
			" pgp.HealthSystemId,  " +
			" pgp.TeamType,  " +
			" pgp.MapCpiPatientExperience,  " +
			" pgp.HealthSystemName)  " +
			"  " +
			"select  " +
			" apgp.*,  " +
			" srgp.MapcpiRating as MapCpiStarRating,  " +
			" srgp.PartDRating as MapCpiPartDStarRating,  " +
			" srgp.OverallRating as OverAllStarRating,  " +
			" srgp.AcoRating as AcpStarRating  " +
			"from  " +
			" aggregratePerformance apgp  " +
			"INNER JOIN ProgPerf.StarRatingGlidePath srgp ON  " +
			" srgp.ProgramYear = apgp.ProgramYear  " +
			" and srgp.HealthSystemId = apgp.HealthSystemId  " +
			" and srgp.RatingType = 'HEALTHSYSTEM'  " +
			" and srgp.DurationValue = apgp.DurationValue  " ;

	private final DatabaseClient client;

	public HealthSystemPerformanceRepositoryImpl(DatabaseClient client) {
        this.client = client;
    }

    @Override
    public Flux<QFOHealthSystemPerformanceDetailsDTO> getHealthSystemPerformanceDetailsByYear(String healthSystemId, int programYear) {
        return client.execute(FETCH_HEALTHSYSTEM_DETAILS)
                .bind(ProviderGroupConstants.PROGRAM_YEAR,programYear)
                .bind(ProviderGroupConstants.HEALTH_SYSTEM_ID, healthSystemId)
                .as(QFOHealthSystemPerformanceDetailsDTO.class)
                .fetch()
                .all();
    }

	@Override
	public Mono<HealthSystemPerformanceDetailsDTO> getPerformanceDetails(String healthSystemId, int programYear) {
		return client.execute(PERFORMANCE_QUERY).bind("programYear", programYear).bind("healthSystemId", healthSystemId)
				.as(HealthSystemPerformanceDetailsDTO.class).fetch().one();
	}

}
