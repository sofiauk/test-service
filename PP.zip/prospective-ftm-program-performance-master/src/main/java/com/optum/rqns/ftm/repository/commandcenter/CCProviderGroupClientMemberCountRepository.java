package com.optum.rqns.ftm.repository.commandcenter;

import com.optum.rqns.ftm.dto.commandcenter.ProviderGroupClientMemberCount;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;

public interface CCProviderGroupClientMemberCountRepository {
    Flux<ProviderGroupClientMemberCount> getProviderGroupClientLobData(String providerGroupId, String state, String programYear);
    Mono<LocalDateTime> getLastUpdateDateforClientsEligibleMemberCount();
}
