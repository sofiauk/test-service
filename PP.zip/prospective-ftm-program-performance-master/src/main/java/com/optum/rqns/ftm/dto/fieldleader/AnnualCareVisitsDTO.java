package com.optum.rqns.ftm.dto.fieldleader;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class AnnualCareVisitsDTO {
    private String measure;
    private Long totalPrevious;
    private Long openPrevious;
    private Double closureRatePrevious;
    private Long totalCurrent;
    private Long openCurrent;
    private Double closureRateCurrent;
    private Double monthOverMonthChange;
}
