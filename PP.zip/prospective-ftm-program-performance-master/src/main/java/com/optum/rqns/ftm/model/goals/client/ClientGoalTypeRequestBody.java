package com.optum.rqns.ftm.model.goals.client;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Data
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class ClientGoalTypeRequestBody {
    private int programYear;
    private int year;
    private String goalType;
    private String intervalType;
    private String intervalValue;
    private boolean isClientRegion;
}
