package com.optum.rqns.ftm.dto.providergrp.converter;

import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.dto.providergrp.ProviderGroupDetailsDTO;
import com.optum.rqns.ftm.repository.providergrp.ProviderGroupDetailsRepositoryImpl;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;

import java.time.LocalDateTime;


public class ProviderGroupDetailsDTOConverter implements Converter<Row, ProviderGroupDetailsDTO>, DTOWrapperTypeConverter {
    private static final String Y_STR = "Y";

    @Override
    public ProviderGroupDetailsDTO convert(Row rs) {

        return ProviderGroupDetailsDTO.builder()
                .providerGroupId(rs.get(ProviderGroupDetailsRepositoryImpl.ColumnNames.PROVIDER_GROUP_ID.getColumnName(), String.class))
                .providerGroupName(rs.get(ProviderGroupDetailsRepositoryImpl.ColumnNames.PROVIDER_GROUP_NAME.getColumnName(),String.class))
                .taxId(rs.get(ProviderGroupDetailsRepositoryImpl.ColumnNames.TAX_ID.getColumnName(),String.class))
                .state(rs.get(ProviderGroupDetailsRepositoryImpl.ColumnNames.STATE.getColumnName(), String.class))
                .serviceLevel(rs.get(ProviderGroupDetailsRepositoryImpl.ColumnNames.SERVICE_LEVEL.getColumnName(), String.class))
                .isNewForDeployment(hasBooleanValue(rs, ProviderGroupDetailsRepositoryImpl.ColumnNames.IS_NEW_FOR_DEPLOYMENT.getColumnName()))
                .lastActivityDate(rs.get(ProviderGroupDetailsRepositoryImpl.ColumnNames.LAST_ACTIVITY_DATE.getColumnName(), LocalDateTime.class))
                .ownerType(rs.get(ProviderGroupDetailsRepositoryImpl.ColumnNames.OWNER_TYPE.getColumnName(), String.class))
                .ownerName(rs.get(ProviderGroupDetailsRepositoryImpl.ColumnNames.OWNER_NAME.getColumnName(), String.class))
                .engagementOnshoreFlag(getOnshoreFlag(rs))
                .canShowPSCOwner(hasBooleanValue(rs,ProviderGroupDetailsRepositoryImpl.ColumnNames.CAN_SHOW_PSC_OWNER.getColumnName()))
                .build();
    }

    private Boolean getOnshoreFlag(Row rs) {
        String sOnshoreFlag = rs.get(ProviderGroupDetailsRepositoryImpl.ColumnNames.PSC_ENGAGEMENT_ON_SHORE.getColumnName(), String.class);
        return Y_STR.equalsIgnoreCase(sOnshoreFlag);
    }
}