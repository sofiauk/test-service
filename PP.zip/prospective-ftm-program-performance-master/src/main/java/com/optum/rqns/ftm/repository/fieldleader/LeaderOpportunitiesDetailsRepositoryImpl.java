package com.optum.rqns.ftm.repository.fieldleader;

import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.dto.fieldleader.AnnualCareVisitsDTO;
import com.optum.rqns.ftm.dto.fieldleader.QualityGapsDTO;
import com.optum.rqns.ftm.dto.fieldleader.RiskQualityGapsSummaryDTO;
import com.optum.rqns.ftm.dto.fieldleader.SuspectConditionsDTO;
import com.optum.rqns.ftm.model.programyearcalendar.CurrentPreviousMonth;
import io.r2dbc.spi.Row;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.springframework.data.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Repository
public class LeaderOpportunitiesDetailsRepositoryImpl implements LeaderOpportunitiesDetailsRepository, DTOWrapperTypeConverter {

    private final DatabaseClient client;

    private static final String OFFSET = "Offset";
    private static final String LIMIT = "Limit";
    private static final String PROGRAM_YEAR = "ProgramYear";
    private static final String PREVIOUS_MONTH = "PreviousMonth";
    private static final String CURRENT_MONTH = "CurrentMonth";
    private static final String UUID = "UUID";
    private static final String MASTER_OPPORTUNITY_TYPE = "MasterOpportunityType";

    LeaderOpportunitiesDetailsRepositoryImpl(DatabaseClient client) {
        this.client = client;
    }

    @AllArgsConstructor
    @Getter
    public enum MasterOpportunityTypes {
        ANNUAL_CARE_VISITS("Annual Care Visits"),
        QUALTIY_GAPS("Quality Gaps"),
        SUSPECT_CONDITIONS("Suspect Conditions");
        private String masterOpportunityType;
    }

    @AllArgsConstructor
    @Getter
    public enum ColumnNames {
        ANNUAL_CARE_VISITS("AnnualCareVisits"),
        CLOSED_CURRENT("ClosedGapsCur"),
        CLOSED_PREVIOUS("ClosedGapsPrev"),
        CLOSURE_RATE_CURRENT("ClosureRateCur"),
        CLOSURE_RATE_PREVIOUS("ClosureRatePrev"),
        MEASURE("Measure"),
        MOM_CHANGE("MonthOverMonthChange"),
        OPEN_CURRENT("OpenGapsCur"),
        OPEN_PREVIOUS("OpenGapsPrev"),
        OPPORTUNITIES_CURRENT("OpportunitiesCur"),
        OPPORTUNITIES_PREVIOUS("OpportunitiesPrev"),
        QUALTIY_GAPS("QualityGaps"),
        SUSPECT_CONDITIONS("SuspectConditions"),
        TOTAL_CURRENT("TotalCur"),
        TOTAL_PREVIOUS("TotalPrev"),
        UPDATED_DATE("UpdatedDate");
        private String columnName;
    }

    @Override
    public Mono<Long> getQualityGapsCount(String uuid, int programYear, CurrentPreviousMonth currentPreviousMonth) {
        LeaderOpportunitiesDetailsQueryBuilder.Builder builder = LeaderOpportunitiesDetailsQueryBuilder.builder();
        builder
                .asQualityGaps(null,null)
                .asCount();
        return client.execute(builder.build())
                .bind(MASTER_OPPORTUNITY_TYPE,MasterOpportunityTypes.QUALTIY_GAPS.getMasterOpportunityType())
                .bind(PROGRAM_YEAR,programYear)
                .bind(UUID,uuid)
                .bind(CURRENT_MONTH,currentPreviousMonth.getCurrentMonth())
                .bind(PREVIOUS_MONTH,currentPreviousMonth.getPreviousMonth())
                .as(Long.class)
                .fetch()
                .one();
    }

    @Override
    public Flux<QualityGapsDTO> getQualityGaps(String uuid, int programYear, String sortColumn, String sortOrder, int offset, int limit, CurrentPreviousMonth currentPreviousMonth) {
        LeaderOpportunitiesDetailsQueryBuilder.Builder builder = LeaderOpportunitiesDetailsQueryBuilder.builder();
        builder.asQualityGaps(sortColumn,sortOrder);
        return client.execute(builder.build())
                .bind(MASTER_OPPORTUNITY_TYPE,MasterOpportunityTypes.QUALTIY_GAPS.getMasterOpportunityType())
                .bind(PROGRAM_YEAR,programYear)
                .bind(UUID,uuid)
                .bind(CURRENT_MONTH,currentPreviousMonth.getCurrentMonth())
                .bind(PREVIOUS_MONTH,currentPreviousMonth.getPreviousMonth())
                .bind(OFFSET, offset)
                .bind(LIMIT,limit)
                .as(QualityGapsDTO.class)
                .map((row, rowMetadata) ->
                        QualityGapsDTO.builder()
                                .measure(getStringValue(row,ColumnNames.MEASURE.getColumnName()))
                                .totalPrevious(getLongValue(row,ColumnNames.TOTAL_PREVIOUS.getColumnName()))
                                .closedPrevious(getLongValue(row,ColumnNames.CLOSED_PREVIOUS.getColumnName()))
                                .openPrevious(getLongValue(row,ColumnNames.OPEN_PREVIOUS.getColumnName()))
                                .closureRatePrevious(getDoubleValue(row,ColumnNames.CLOSURE_RATE_PREVIOUS.getColumnName()))
                                .totalCurrent(getLongValue(row,ColumnNames.TOTAL_CURRENT.getColumnName()))
                                .closedCurrent(getLongValue(row,ColumnNames.CLOSED_CURRENT.getColumnName()))
                                .openCurrent(getLongValue(row,ColumnNames.OPEN_CURRENT.getColumnName()))
                                .closureRateCurrent(getDoubleValue(row,ColumnNames.CLOSURE_RATE_CURRENT.getColumnName()))
                                .monthOverMonthChange(getDoubleValue(row,ColumnNames.MOM_CHANGE.getColumnName()))
                                .build()
                )
                .all();
    }

    @Override
    public Flux<AnnualCareVisitsDTO> getAnnualCareVisits(String uuid, int programYear, CurrentPreviousMonth currentPreviousMonth) {
        LeaderOpportunitiesDetailsQueryBuilder.Builder builder = LeaderOpportunitiesDetailsQueryBuilder.builder();
        builder.asAnnualCareVisits();
        return client.execute(builder.build())
                .bind(MASTER_OPPORTUNITY_TYPE,MasterOpportunityTypes.ANNUAL_CARE_VISITS.getMasterOpportunityType())
                .bind(PROGRAM_YEAR,programYear)
                .bind(UUID,uuid)
                .bind(CURRENT_MONTH,currentPreviousMonth.getCurrentMonth())
                .bind(PREVIOUS_MONTH,currentPreviousMonth.getPreviousMonth())
                .as(AnnualCareVisitsDTO.class)
                .map((row, rowMetadata) ->
                        AnnualCareVisitsDTO.builder()
                                .measure(getStringValue(row,ColumnNames.MEASURE.getColumnName()))
                                .totalPrevious(getLongValue(row,ColumnNames.TOTAL_PREVIOUS.getColumnName() ))
                                .openPrevious(getLongValue(row,ColumnNames.OPEN_PREVIOUS.getColumnName()))
                                .closureRatePrevious(getDoubleValue(row,ColumnNames.CLOSURE_RATE_PREVIOUS.getColumnName()))
                                .totalCurrent(getLongValue(row,ColumnNames.TOTAL_CURRENT.getColumnName()))
                                .openCurrent(getLongValue(row,ColumnNames.OPEN_CURRENT.getColumnName()))
                                .closureRateCurrent(getDoubleValue(row,ColumnNames.CLOSURE_RATE_CURRENT.getColumnName()))
                                .monthOverMonthChange(getDoubleValue(row,ColumnNames.MOM_CHANGE.getColumnName()))
                                .build()
                )
                .all();
    }

    @Override
    public Flux<SuspectConditionsDTO> getSuspectConditions(String uuid, int programYear, CurrentPreviousMonth currentPreviousMonth) {
        LeaderOpportunitiesDetailsQueryBuilder.Builder builder = LeaderOpportunitiesDetailsQueryBuilder.builder();
        builder.asSuspectConditions();
        return client.execute(builder.build())
                .bind(MASTER_OPPORTUNITY_TYPE,MasterOpportunityTypes.SUSPECT_CONDITIONS.getMasterOpportunityType())
                .bind(PROGRAM_YEAR,programYear)
                .bind(UUID,uuid)
                .bind(CURRENT_MONTH,currentPreviousMonth.getCurrentMonth())
                .bind(PREVIOUS_MONTH,currentPreviousMonth.getPreviousMonth())
                .as(SuspectConditionsDTO.class)
                .map((row, rowMetadata) ->
                        SuspectConditionsDTO.builder()
                                .measure(getStringValue(row,ColumnNames.MEASURE.getColumnName()))
                                .totalPrevious(getLongValue(row,ColumnNames.TOTAL_PREVIOUS.getColumnName() ))
                                .opportunitiesPrevious(getLongValue(row,ColumnNames.OPPORTUNITIES_PREVIOUS.getColumnName()))
                                .closureRatePrevious(getDoubleValue(row,ColumnNames.CLOSURE_RATE_PREVIOUS.getColumnName()))
                                .totalCurrent(getLongValue(row,ColumnNames.TOTAL_CURRENT.getColumnName()))
                                .opportunitiesCurrent(getLongValue(row,ColumnNames.OPPORTUNITIES_CURRENT.getColumnName()))
                                .closureRateCurrent(getDoubleValue(row,ColumnNames.CLOSURE_RATE_CURRENT.getColumnName()))
                                .monthOverMonthChange(getDoubleValue(row,ColumnNames.MOM_CHANGE.getColumnName()))
                                .build()
                )
                .all();
    }

    @Override
    public Flux<RiskQualityGapsSummaryDTO> getRiskQualityGapsSummary(String uuid, int programYear, CurrentPreviousMonth currentPreviousMonth) {
        LeaderOpportunitiesDetailsQueryBuilder.Builder builder = LeaderOpportunitiesDetailsQueryBuilder.builder();
        builder.asSummary();
        return client.execute(builder.build())
                .bind(CURRENT_MONTH,currentPreviousMonth.getCurrentMonth())
                .bind(PROGRAM_YEAR,programYear)
                .bind(UUID,uuid)
                .as(RiskQualityGapsSummaryDTO.class)
                .map((row, rowMetadata) ->
                        RiskQualityGapsSummaryDTO.builder()
                                .qualityGaps(getLongValue(row,ColumnNames.QUALTIY_GAPS.getColumnName()))
                                .annualCareVisits(getLongValue(row,ColumnNames.ANNUAL_CARE_VISITS.getColumnName()))
                                .suspectConditions(getLongValue(row,ColumnNames.SUSPECT_CONDITIONS.getColumnName()))
                                .lastUpdatedDate(getValue(row, ColumnNames.UPDATED_DATE.getColumnName(), java.time.LocalDateTime.class))
                                .build()
                )
                .all();
    }

    private String getStringValue(Row row, String columnName) {
        return getValue(row, columnName, String.class);
    }

}
