package com.optum.rqns.ftm.dto.opportunities.providergrp.converter;

import com.optum.rqns.ftm.constants.ProviderGroupConstants;
import com.optum.rqns.ftm.dto.opportunities.providergrp.MemberAssessmentDTO;
import com.optum.rqns.ftm.model.opportunities.providergrp.ProviderGroupMemberAssessments;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;

import java.time.LocalDateTime;

public class MemberAssessmentsConverter implements Converter<Row, MemberAssessmentDTO> {
    @Override
    public MemberAssessmentDTO convert(Row row) {
        return MemberAssessmentDTO.builder()
                .chartId(row.get(ProviderGroupConstants.CHARTID,String.class))
                .client(row.get(ProviderGroupConstants.CLIENT,String.class))
                .deployDate(row.get(ProviderGroupConstants.DEPLOY_DATE, LocalDateTime.class))
                .memberDob(row.get(ProviderGroupConstants.MEMBER_DOB, LocalDateTime.class))
                .returnDate(row.get(ProviderGroupConstants.RETURN_DATE, LocalDateTime.class))
                .memberName(row.get(ProviderGroupConstants.MEMBER_NAME, String.class))
                .cGapMet(row.get(ProviderGroupConstants.IS_C_GAP_MET, String.class))
                .dvMet(row.get(ProviderGroupConstants.IS_DV_MET, String.class))
                .gaMet(row.get(ProviderGroupConstants.IS_GA_MET, String.class))
                .providerName(row.get(ProviderGroupConstants.PROVIDER_NAME, String.class))
                .opportunityReason(row.get(ProviderGroupConstants.OPPORTUNITY_SUB_TYPE, String.class))
                .memberId(row.get(ProviderGroupConstants.MEMBERID, String.class))
                .secondarySubmission(row.get(ProviderGroupConstants.IS_SECONDARY_SUBMISSION, String.class))
                .programYear(row.get(ProviderGroupConstants.PROGRAM_YEAR, Integer.class))
                .lobName(row.get(ProviderGroupConstants.LOB_NAME, String.class))
                .eligibleProgramType(row.get(ProviderGroupConstants.ELIGIBLE_PROGRAM_TYPE, String.class))
                .cpg(row.get(ProviderGroupConstants.CPG, String.class))
                .build();
    }
}
