package com.optum.rqns.ftm.repository.audithistory;

import com.optum.rqns.ftm.model.audithistory.AuditHistory;
import reactor.core.publisher.Mono;

public interface AuditHistoryRepository {
    Mono<Integer> insertAuditHistory(AuditHistory auditHistory);
}
