package com.optum.rqns.ftm.response.commandcenter;

import com.optum.rqns.ftm.dto.commandcenter.DerivedDeploymentWeeklyDTO;
import com.optum.rqns.ftm.wrapper.Meta;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.ToString;

import java.util.ArrayList;
import java.util.List;

@Data
@ToString
@AllArgsConstructor
@Builder
public class DerivedDeploymentWeeklyResponse {
    private Meta meta;
    private List<DerivedDeploymentWeeklyDTO> data;

    public DerivedDeploymentWeeklyResponse(){
        this.meta = new Meta();
        this.data = new ArrayList<>();
    }
}
