package com.optum.rqns.ftm.repository.rules;

import com.optum.rqns.ftm.constants.RuleConstants;
import com.optum.rqns.ftm.dto.rules.ProviderGroupOpportunitiesDetailsDTO;
import com.optum.rqns.ftm.dto.rules.ProviderGroupOpportunitiesSummaryDTO;
import com.optum.rqns.ftm.dto.rules.ProviderGroupOpportunitiesSummaryDetailDTO;
import com.optum.rqns.ftm.enums.OpportunityType;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.model.rules.DeploymentOpportunityInput;
import com.optum.rqns.ftm.model.rules.FinancialInformationOpportunityInput;
import com.optum.rqns.ftm.model.rules.MemberAssessmentOpportunity;
import com.optum.rqns.ftm.model.rules.OutlierOpportunityInput;
import com.optum.rqns.ftm.model.rules.ProviderGroup;
import com.optum.rqns.ftm.model.rules.ProviderGroupOpportunitiesDetail;
import com.optum.rqns.ftm.model.rules.ProviderGroupOpportunitiesSummary;
import com.optum.rqns.ftm.model.rules.RejectOpportunityInput;
import com.optum.rqns.ftm.model.rules.ReturnOpportunityInput;
import com.optum.rqns.ftm.model.rules.SecondarySubmissionOpportunityInput;
import com.optum.rqns.ftm.repository.common.CommonRepository;
import com.optum.rqns.ftm.service.rules.RuleMapper;
import com.optum.rqns.ftm.util.ProgramPerformanceUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Repository
@Slf4j
public class RuleRepositoryImpl implements RuleRepository {
    @Autowired
    private DatabaseClient opportunityClient;

    @Autowired
    private CommonRepository commonRepository;

    @Autowired
    private RuleMapper ruleMapper;

    public enum ColumnNames {

        ID("ID"), PROVIDERGROUPID("PROVIDERGROUPID"), PROVIDERGROUPNAME("PROVIDERGROUPNAME"), STATE("STATE"),
        SERVICELEVEL("SERVICELEVEL"),
        ISNEW("ISNEW"),PROJECT_YEAR("PROJECT_YEAR"),PROVIDER_STATE("PROVIDER_STATE"),SINGLE_REJECT_REASON("SINGLE_REJECT_REASON"),
        CLIENT("CLIENT"),LOB("LOB"),PROGRAMYEAR("PROGRAMYEAR"),MASTERLEVELOPPORTUNITY("MASTERLEVELOPPORTUNITY"),
        TOTALASSESSMENTSCOUNT("TOTALASSESSMENTSCOUNT"),TOTALGAPSCOUNT("TOTALGAPSCOUNT"),LASTUPDATEDDATE("LASTUPDATEDDATE"),
        TOTALCLIENTSCOUNT("TOTALCLIENTSCOUNT"), CLIENTNAME("CLIENTNAME"),CLIENT_ID("CLIENTID"),LATESTUPDATEDDATE("LATESTUPDATEDDATE"),
        MASTEROPPORTUNITYTYPE("MASTEROPPORTUNITYTYPE"),MASTEROPPORTUNITYTYPEPOSITION("MASTEROPPORTUNITYTYPEPOSITION"),
        OPPORTUNITYTYPE("OPPORTUNITYTYPE"),OPPORTUNITYSUBTYPE("OPPORTUNITYSUBTYPE"),
        OPPORTUNITYTYPEPOSITION("OPPORTUNITYTYPEPOSITION"),OPPORTUNITYTYPESUBPOSITION("OPPORTUNITYTYPESUBPOSITION"),
        DISPLAYTEXT("DISPLAYTEXT"),ASSESSMENTCOUNT("ASSESSMENTCOUNT"),OPPORTUNITYSUBTYPEPOSITION("OPPORTUNITYSUBTYPEPOSITION"),
        DEPLOYMENTCOUNT("DEPLOYMENTCOUNT"),GAPCOUNT("GAPCOUNT"),
        STATUS("STATUS"),JOBNAME("JOBNAME"),CHARTID("CHARTID"),LOBNAME("LOBNAME"),CREATEDBY("CREATEDBY"),CREATEDDATE("CREATEDDATE"),
        LASTRUNDATE("LASTRUNDATE"),MODIFIEDBY("MODIFIEDBY"),MODIFIEDDATE("MODIFIEDDATE"),JOBSTART("JOBSTART"),JOBEND("JOBEND"),
        PROJECT_TYPE("PROJECTTYPE"),EC("EC"),REFRESH_DATE("REFRESHDATE"),PROJECTYEAR("PROJECTYEAR"),
        PROJECT_ID_TYPE("PROJECTIDTYPE"), OVER_ALL_STATUS_NOT_IN("OVERALLSTATUSNOTIN"),ISSECONDARYSUBMISSIONELIGIBLE("ISSECONDARYSUBMISSIONELIGIBLE"),
        GAPTYPE("GAPTYPE"),GAPDESC("GAPDESC"),LASTSUCCESSFULRUNDATE("LASTSUCCESSFULRUNDATE"),OUTLIER_NAME("OUTLIERNAME"),PAYMENTREJECTREASON("PAYMENTREJECTREASON")
        ,ERROR_MESSAGE("ERRORMESSAGE"),ROW_ACTION("ROWACTION"),OPPORTUNITY_ID("OPPORTUNITYID"),PROVIDERGROUP_NAME("ProviderGroupName "),MASTERLEVELOPPORTUNITY_POSITION("MasterLevelOpportunityPosition"),
        OVERALL_STATUS("OVERALL_STATUS"),LOB2("LOB2"),GLOBALMEMBERID("GLOBALMEMBERID"),ISPROVIDERASSOCIATED("ISPROVIDERASSOCIATED"),ISDEPLOYED("ISDEPLOYED"),
        ISSUPPRESSED("ISSUPPRESSED"),PROVIDERSTATE("PROVIDERSTATE"),ELIGIBLEMEMBERSCOUNT("ELIGIBLEMEMBERSCOUNT"),MESSAGE("MESSAGE"),SUMMERY("SUMMERY"),DETAIL("DETAIL"),
        MEMBERASSESSMENTOPPORTUNITY("MEMBERASSESSMENTOPPORTUNITY"),OPPORTUNITYDETAILID("OPPORTUNITYDETAILID");

        private String columnName;
        ColumnNames(String columnName) {
            this.columnName = columnName;
        }

        public String getColumnName() {
            return this.columnName;
        }
    }

    private static final String PROVIDER_GROUPS_BY_LAST_RUN_DATE = "SELECT DISTINCT A.Prov_Group_ID AS ProviderGroupID ," +
            " A.providerstate AS State FROM progperf.MemberAssessment A WITH (NOLOCK)" +
            " WHERE EXISTS" +
            " ( SELECT * FROM ProgPerf.ProviderGroup pg , ProgPerf.Accounts ao" +
            " WHERE pg.ProviderGroupID = A.Prov_Group_ID AND pg.State = A.providerstate AND pg.ProviderGroupID = ao.GroupId" +
            " AND ao.ServiceLevel IN (:SERVICELEVEL) )" +
            "  %s " +
            " AND A.UpdatedDate > :LASTRUNDATE";
    

    private static final String PROVIDER_GROUPS_BY_LAST_RUN_DATE_FOR_FINCANICAL = "SELECT " +
            " DISTINCT pap.ProviderGroupId AS ProviderGroupID," +
            " pap.ProviderState AS State," +
            " 'NA' AS ServiceLevel " +
            " FROM ProgPerf.PafAsfPayment pap WITH (NOLOCK)" +
            " WHERE " +
            "  EXISTS" +
            " ( SELECT * FROM ProgPerf.ProviderGroup pg , ProgPerf.Accounts ao" +
            " WHERE pg.ProviderGroupID = pap.ProviderGroupId" +
            " AND pg.State = pap.ProviderState" +
            " AND pg.ProviderGroupID = ao.GroupId" +
            " AND ao.ServiceLevel IN (:SERVICELEVEL))" +
            " GROUP BY ProviderGroupId , ProviderState";

    private static final String PROVIDER_GROUPS_BY_LAST_RUN_DATE_FOR_DEPLOYMENTS = "SELECT  " +
            "  DISTINCT PAx.ProviderGroupID,  " +
            "  PAx.ProviderState AS State,  " +
            "  'NA' AS ServiceLevel  " +
            "FROM  " +
            "  progperf.PafExMemberAssessment PAx WITH (NOLOCK)  " +
            "WHERE  " +
            "  PAx.ProgramYear = :PROGRAMYEAR  " +
            "  AND PAx.UpdatedDate > :LASTRUNDATE";

    private static final String REJECTS_OPPORTUNITIES_QUERY =
            "  SELECT " +
            "  A.Prov_Group_ID AS PROVIDERGROUPID, " +
            "  A.prov_group_name AS PROVIDERGROUPNAME, " +
            "  A.providerstate AS PROVIDER_STATE, " +
            "  A.engagementchannel AS SERVICELEVEL, " +
            "  A.Project_Year AS PROJECT_YEAR, " +
            "  A.ClientNameOFCStandard AS CLIENT, " +
            "  A.lob2 AS LOB, " +
            "  A.chart_id AS CHARTID, " +
            "  A.singlerejectreason AS SINGLE_REJECT_REASON," +
            "  A.overall_status AS OVERALL_STATUS " +
            "  FROM progperf.MemberAssessment A WITH (NOLOCK) " +
            "  WHERE  " +
            "  EXISTS ( SELECT * FROM ProgPerf.ProviderGroup pg , ProgPerf.Accounts ao  " +
            "           WHERE pg.ProviderGroupID = A.Prov_Group_ID AND pg.State = A.providerstate  " +
            "           AND pg.ProviderGroupID = ao.GroupId AND ao.ServiceLevel IN (:SERVICELEVEL)) " +
            "  AND (datalength(A.singlerejectreason) <> 0)  " +
            "  AND A.deriveddeployed = 1 "+
            "  %s " +
            "  AND A.LOB2 IN (:LOB) "+
            "  AND UPPER(A.RecordChangeType) <> 'DELETED' ";


    private static final String RETURNS_OPPORTUNITIES_QUERY ="SELECT  " +
            "  S.ProviderGroupID,  " +
            "  S.ProviderGroupName,  " +
            "  S.State,  " +
            "  S.ProgramYear,  " +
            "  S.ClientName,  " +
            "  S.LobName,  " +
            "  S.DeployYTDActual,  " +
            "  S.ReturnYTDActual,  " +
            "  S.RetunYTDActualPercentage,  " +
            "  100 AS ReturnYTDTargetPercent  " +
            " FROM  " +
            "  ProgPerf.ProviderGroupPerformance AS T WITH (NOLOCK)  " +
            " INNER JOIN (  " +
            "  SELECT  " +
            "    A.ClientNameOFCStandard AS ClientName , A.prov_group_name AS ProviderGroupName , A.Project_Year AS ProgramYear , A.providerstate AS State , A.Prov_Group_ID AS ProviderGroupID , a.engagementchannel AS ServiceLevel , A.LOB2 AS LobName," +
            "    SUM(CASE WHEN a.project_year = :PROJECTYEAR AND a.deriveddeployed = 1  THEN 1 ELSE 0 END) AS DeployYTDActual , SUM(CASE WHEN a.project_year = :PROJECTYEAR AND a.returned = 1 THEN 1 ELSE 0 END) AS ReturnYTDActual ,  " +
            "    CASE  " +
            "      WHEN (sum(CASE WHEN a.project_year = :PROJECTYEAR AND a.deriveddeployed = 1 THEN 1 ELSE 0 END) = 0) THEN 0  " +
            "      ELSE CAST (ROUND(((CAST (sum(CASE WHEN a.project_year = :PROJECTYEAR AND a.returned = 1 THEN 1 ELSE 0 END) AS float)/ sum(CASE WHEN a.project_year = :PROJECTYEAR AND a.deriveddeployed = 1  THEN 1 ELSE 0 END))* 100), 0) AS int)  " +
            "    END AS RetunYTDActualPercentage  " +
            "  FROM  " +
            "    progperf.MemberAssessment A WITH (NOLOCK)  " +
            "  WHERE  " +
            "    EXISTS (  " +
            "    SELECT  " +
            "      *  " +
            "    FROM  " +
            "      ProgPerf.ProviderGroup pg , ProgPerf.Accounts ao  " +
            "    WHERE  " +
            "      pg.ProviderGroupID = A.Prov_Group_ID  " +
            "      AND pg.State = A.providerstate  " +
            "      AND pg.ProviderGroupID = ao.GroupId  " +
            "      AND ao.ServiceLevel IN (:SERVICELEVEL))   " +
            "    AND A.Project_Year IN (:PROJECTYEAR)  " +
            "    AND A.DerivedDeployed = 1  " +
            "    AND A.LOB2 IN (:LOB)  " +
            "    %s  " +
            "  GROUP BY  " +
            "    A.ClientNameOFCStandard , A.LOB2, A.prov_group_name , A.Project_Year , A.providerstate , A.Prov_Group_ID , A.engagementchannel) AS S ON  " +
            "  S.ProviderGroupID = T.ProviderGroupID  " +
            "  AND S.ProviderGroupName = T.ProviderGroupName  " +
            "  AND S.State = T.State  " +
            "  AND S.ServiceLevel = T.ServiceLevel  " +
            "  AND S.ProgramYear = T.ProgramYear  " +
            "  AND S.ClientName = T.ClientName  " +
            "  AND S.LobName = T.LobName  " +
            "WHERE  " +
            "  T.isCurrentWeekForRules =1  ";

    private static final String RETURNS_OPPORTUNITIES_QUERY_OCT_30_RELEASE =
            " select S.*,100 AS ReturnYTDTargetPercent," +
            " (select ProviderGroupName from ProgPerf.ProviderGroup pg" +
            " where pg.ProviderGroupID = S.ProviderGroupID and pg.State = S.State ) AS ProviderGroupName" +
            " from (SELECT " +
            " A.Prov_Group_ID AS ProviderGroupID ," +
            " A.providerstate AS State ," +
            " A.Project_Year AS ProgramYear ," +
            " A.ClientId AS ClientId ," +
            " A.ClientNameOFCStandard AS ClientName ," +
            " A.LOB2 AS LobName," +
            " SUM(CASE WHEN a.project_year = :PROJECTYEAR AND a.deriveddeployed = 1 THEN 1 ELSE 0 END) AS DeployYTDActual ," +
            " SUM(CASE WHEN a.project_year = :PROJECTYEAR AND a.returned = 1 THEN 1 ELSE 0 END) AS ReturnYTDActual ," +
            " CASE WHEN (sum(CASE WHEN a.project_year = :PROJECTYEAR AND a.deriveddeployed = 1 THEN 1 ELSE 0 END) = 0) THEN 0 ELSE CAST (FLOOR(((CAST (sum(CASE WHEN a.project_year = :PROJECTYEAR AND a.returned = 1 THEN 1 ELSE 0 END) AS float)/ sum(CASE WHEN a.project_year = :PROJECTYEAR AND a.deriveddeployed = 1 THEN 1 ELSE 0 END))* 100)) AS int) END AS RetunYTDActualPercentage" +
            " FROM progperf.MemberAssessment A WITH (NOLOCK)" +
            " WHERE EXISTS ( SELECT * FROM ProgPerf.ProviderGroup pg , ProgPerf.Accounts ao" +
            " WHERE pg.ProviderGroupID = A.Prov_Group_ID AND pg.State = A.providerstate" +
            " AND pg.ProviderGroupID = ao.GroupId AND ao.ServiceLevel IN (:SERVICELEVEL))" +
            " AND A.Project_Year = :PROJECTYEAR" +
            " AND A.DerivedDeployed = 1" +
            " AND A.LOB2 IN (:LOB)" +
            " %s " +
            " AND UPPER(A.RecordChangeType) <> 'DELETED' "+
            " GROUP BY A.Prov_Group_ID , A.providerstate , A.Project_Year ,A.ClientId, A.ClientNameOFCStandard , A.LOB2) AS S";


    private static final String OUTLIER_OPPORTUNITIES_QUERY =
            "  SELECT  " +
            "  A.ProviderGroupID as PROVIDERGROUPID ,  " +
            "  A.ProviderGroupName as PROVIDERGROUPNAME ,  " +
            "  'NA' AS SERVICELEVEL,  " +
            "  A.State as PROVIDER_STATE ,  " +
            "  A.ProgramYear as PROJECT_YEAR,  " +
            "  A.ClientName as CLIENT,  " +
            "  A.LOBName as LOB,  " +
            "  A.ChartID as CHARTID,  " +
            "  A.OpportunitySubType AS OUTLIERNAME,   " +
            "  A.GapType AS GAPTYPE,  " +
            "  A.GapDesc AS GAPDESC  " +
            "  FROM  " +
            "  ProgPerf.MemberAssessmentGap A WITH (NOLOCK) " +
            "  WHERE  " +
            "  A.MasterOpportunityType = :MASTEROPPORTUNITYTYPE  " +
            "  %s " ;

    private static final String SECONDARYSUBMISSION_OPPORTUNITIES_QUERY ="SELECT " +
            " A.Prov_Group_ID as PROVIDERGROUPID ," +
            " A.prov_group_name as PROVIDERGROUPNAME ," +
            " A.providerstate as PROVIDER_STATE ," +
            " A.engagementchannel as SERVICELEVEL," +
            " A.Project_Year as PROJECT_YEAR," +
            " A.ClientNameOFCStandard as CLIENT," +
            " A.lob2 as LOB," +
            " A.chart_id as CHARTID," +
            " A.IsSecondarySubmissionEligible" +
            " FROM ProgPerf.MemberAssessment A WITH (NOLOCK)" +
            " WHERE A.IsSecondarySubmissionEligible = :ISSECONDARYSUBMISSIONELIGIBLE" +
            " AND (A.SecondarySubmissionUpdateFlag = 'Replace'OR A.SecondarySubmissionUpdateFlag = 'Insert')" +
            " AND A.project_year = :PROJECTYEAR" +
            " AND UPPER(A.RecordChangeType) <> 'DELETED' ";

    private static final String FINANCIALINFORMATION_OPPORTUNITIES_QUERY ="SELECT  " +
            "  pap.ProviderGroupId,  " +
            "  pap.ProviderGroupName,  " +
            "  pap.ProviderState AS PROVIDER_STATE,  " +
            "  'NA' AS SERVICELEVEL,  " +
            "  (SELECT CAST (mc.value  AS int) FROM PROGPERF.MasterConfiguration mc WITH (NOLOCK) WHERE mc.code = 'CurrentProgramYear') AS PROJECT_YEAR,  " +
            "  value PAYMENTREJECTREASON  " +
            "FROM  " +
            "  ProgPerf.PafAsfPayment pap WITH (NOLOCK) CROSS APPLY STRING_SPLIT(pap.Flag, ',')  " +
            "WHERE  " +
            "  pap.StatusId = 1  " +
            "  AND EXISTS (  " +
            "  SELECT  " +
            "    *  " +
            "  FROM  " +
            "    ProgPerf.ProviderGroup pg , ProgPerf.Accounts ao  " +
            "  WHERE  " +
            "    pg.ProviderGroupID = pap.ProviderGroupId  " +
            "    AND pg.State = pap.ProviderState  " +
            "    AND pg.ProviderGroupID = ao.GroupId  " +
            "    AND ao.ServiceLevel IN (:SERVICELEVEL))  " +
            "GROUP BY  " +
            "  ProviderGroupId ,  " +
            "  ProviderGroupName ,  " +
            "  ProviderState ,  " +
            "  value";

    private static final String DEPLOYMENTS_OPPORTUNITIES_QUERY =
            "  SELECT " +
            "  PM.*, (SELECT DISTINCT TOP 1 P.ProviderGroupName from ProgPerf.PafExMemberAssessment P where P.ProviderGroupID = PM.ProviderGroupID AND P.ProgramYear = PM.ProgramYear) AS ProviderGroupName,  " +
            " 'NA' AS ServiceLevel ,  " +
            " 'No' As IsDeployed,  " +
            " 'Yes' As IsProviderAssociated  " +
            "  FROM  ( SELECT  " +
            "  PA.ProviderGroupID," +
            "  (CASE WHEN PA.ProviderState IS NULL THEN '' ELSE PA.ProviderState END) ProviderState," +
            "  (CASE WHEN PA.ClientName IS NULL THEN '' ELSE PA.ClientName END) ClientName," +
            "  PA.ClientId AS ClientId," +
            "  PA.LobName, PA.ProgramYear, Count(PA.GlobalMemberId) EligibleMembersCount  " +
            "  FROM ProgPerf.PafExMemberAssessment PA WITH (NOLOCK)  " +
            "  WHERE  " +
            "  PA.IsSuppressed = 'N'  " +
            "  AND PA.IsDeployed = 0  " +
            "  AND (PA.IsProviderAssociated <> 'No' OR PA.IsProviderAssociated IS NULL)  " +
            "  AND PA.RecordStatus <> 'Deleted'  " +
            "  AND PA.ProgramYear = :PROGRAMYEAR  " +
            "  AND LEN(PA.ProviderGroupId) > 0  " +
            "  AND LEN(PA.ProviderState) > 0  " +
            "  AND LEN(PA.LobName) > 0  " +
            "  AND LEN(PA.ClientName) > 0  " +
            "  AND LEN(PA.ClientId) > 0   " +
            "  AND LEN(PA.ProgramYear) > 0   " +
            "  %s  " +
            "  GROUP BY  " +
            "  PA.ProviderGroupID, PA.ProviderState, PA.ClientName,PA.ClientId, PA.LobName, PA.ProgramYear) AS PM ";

    private static final String INSERT_PROVIDERGROUP_OPPORTUNITY_SUMMERY="INSERT INTO ProgPerf.ProviderGroupOpportunitiesSummary (ProviderGroupID,ProviderGroupName,State,ServiceLevel,ProgramYear,MasterLevelOpportunity, " +
            " MasterLevelOpportunityPosition,TotalAssessmentsCount,TotalGapsCount,LastUpdatedDate,TotalClientsCount,CreatedBy,CreatedDate) VALUES ( " +
            " '%s','%s','%s','%s',%d,'%s','%s',%d,%d,GETUTCDATE(),%d,'System',GETUTCDATE())";

    private static final String MOVE_SUMMERY_TO_SUMMERYHISTORY=
            "   INSERT INTO ProgPerf.ProviderGroupOpportunitiesSummaryHistory " +
            "   (OpportunityID,ProviderGroupID, [ProviderGroupName ], State, ServiceLevel, ProgramYear," +
            "   MasterLevelOpportunity, MasterLevelOpportunityPosition, TotalAssessmentsCount," +
            "   TotalGapsCount, TotalClientsCount, LastUpdatedDate,CreatedBy,CreatedDate) " +

            "   SELECT ID,ProviderGroupID, [ProviderGroupName ], State, ServiceLevel, ProgramYear," +
            "   MasterLevelOpportunity, MasterLevelOpportunityPosition, TotalAssessmentsCount," +
            "   TotalGapsCount, TotalClientsCount, LastUpdatedDate,CreatedBy='System',CreatedDate= GETUTCDATE() " +
            "   FROM ProgPerf.ProviderGroupOpportunitiesSummary WITH (NOLOCK) " +
            "   WHERE ProviderGroupID = '%s' AND  " +
            "   State ='%s' AND " +
            "   %s " +
            "   MasterLevelOpportunity ='%s' " +

            "   DELETE FROM ProgPerf.ProviderGroupOpportunitiesSummary " +
            "   WHERE ProviderGroupID = '%s' AND  " +
            "   State ='%s' AND " +
            "   %s " +
            "   MasterLevelOpportunity ='%s'";

    private static final String MOVE_ALL_SUMMERY_TO_SUMMERYHISTORY=
            "   INSERT INTO ProgPerf.ProviderGroupOpportunitiesSummaryHistory " +
            "   (OpportunityID,ProviderGroupID, [ProviderGroupName ], State, ServiceLevel, ProgramYear, MasterLevelOpportunity," +
            "   MasterLevelOpportunityPosition, TotalAssessmentsCount, TotalGapsCount," +
            "   TotalClientsCount, LastUpdatedDate,CreatedBy,CreatedDate) " +

            "   SELECT ID,ProviderGroupID, [ProviderGroupName ], State, ServiceLevel, ProgramYear," +
            "   MasterLevelOpportunity, MasterLevelOpportunityPosition, TotalAssessmentsCount," +
            "   TotalGapsCount, TotalClientsCount, LastUpdatedDate,CreatedBy='System',CreatedDate= GETUTCDATE() " +
            "   FROM ProgPerf.ProviderGroupOpportunitiesSummary WITH (NOLOCK) " +
            "   WHERE "+
            "   %s " +
            "   MasterLevelOpportunity =:MASTERLEVELOPPORTUNITY " +

            "   DELETE FROM ProgPerf.ProviderGroupOpportunitiesSummary " +
            "   WHERE " +
            "   %s " +
            "   MasterLevelOpportunity =:MASTERLEVELOPPORTUNITY";


    private static final String DELETED_OPPORTUNITIES_SUMMARY_RECORDS=
            " select S.*,'Deleted' As RowAction from ProgPerf.ProviderGroupOpportunitiesSummaryHistory S WITH (NOLOCK)" +
            " where MasterLevelOpportunity = :OPPORTUNITYTYPE" +
            " and CreatedDate > ( select JobStart from ProgPerf.JobRunConfiguration where JobName = :JOBNAME)";

    private static final String INSERTED_OPPORTUNITIES_SUMMARY_RECORDS=
            " select S.* ,'Inserted' As RowAction,D.ID as OpportunityDetailID,D.ServiceLevel,D.ClientName,D.ClientId,D.LobName,D.OpportunityType,D.OpportunitySubType,D.OpportunitySubTypePosition,  " +
                    " D.OpportunityTypePosition,D.OpportunitySubTypePosition,CAST(D.LastUpdatedDate AS datetime) As latestUpdatedDate ,D.DisplayText,D.AssessmentCount,D.DeploymentCount,D.GapCount   " +
                    " from ProgPerf.ProviderGroupOpportunitiesSummary S WITH (NOLOCK)   " +
                    " INNER JOIN ProgPerf.ProviderGroupOpportunitiesDetail D  WITH (NOLOCK)   " +
                    " ON S.ProviderGroupID =D.ProviderGroupID    " +
                    " AND S.State =D.State    " +
                    " AND S.ProgramYear =D.ProgramYear    " +
                    " AND S.MasterLevelOpportunity =D.MasterOpportunityType    " +
                    " where S.MasterLevelOpportunity = :OPPORTUNITYTYPE   " +
                    " and S.CreatedDate > ( select JobStart from ProgPerf.JobRunConfiguration where JobName = :JOBNAME) ";

    private static final String MOVE_DETAIL_TO_DETAILHISTORY=
            "   INSERT INTO ProgPerf.ProviderGroupOpportunitiesDetailHistory " +
            "   (OpportunityID,ProviderGroupID, [ProviderGroupName ], State, ServiceLevel, ProgramYear, ClientName," +
            "   MasterOpportunityType, MasterOpportunityTypePosition, OpportunityType, OpportunitySubType, OpportunityTypePosition," +
            "   OpportunitySubTypePosition, DisplayText, AssessmentCount, DeploymentCount, GapCount, LastUpdatedDate,CreatedBy,CreatedDate,ClientId,LobName) " +

            "   SELECT ID,ProviderGroupID, [ProviderGroupName ], State, ServiceLevel, ProgramYear, ClientName," +
            "   MasterOpportunityType, MasterOpportunityTypePosition, OpportunityType, OpportunitySubType, OpportunityTypePosition," +
            "   OpportunitySubTypePosition, DisplayText, AssessmentCount, DeploymentCount, GapCount, LastUpdatedDate,CreatedBy='System',CreatedDate= GETUTCDATE(),ClientId,LobName   " +
            "   FROM ProgPerf.ProviderGroupOpportunitiesDetail  WITH (NOLOCK) " +
            "   WHERE ProviderGroupID = '%s' AND  " +
            "   State ='%s' AND " +
            "   %s " +
            "   MasterOpportunityType ='%s' " +

            "   DELETE FROM ProgPerf.ProviderGroupOpportunitiesDetail " +
            "   WHERE ProviderGroupID = '%s' AND  " +
            "   State ='%s' AND " +
            "   %s " +
            "   MasterOpportunityType ='%s'";

    private static final String MOVE_ALL_DETAIL_TO_DETAILHISTORY=
            "   INSERT INTO ProgPerf.ProviderGroupOpportunitiesDetailHistory " +
            "   (OpportunityID,ProviderGroupID, [ProviderGroupName ], State, ServiceLevel, ProgramYear, ClientName, MasterOpportunityType, " +
            "   MasterOpportunityTypePosition, OpportunityType, OpportunitySubType, OpportunityTypePosition, OpportunitySubTypePosition," +
            "   DisplayText, AssessmentCount, DeploymentCount, GapCount, LastUpdatedDate,CreatedBy,CreatedDate,ClientId,LobName) " +

            "   SELECT ID,ProviderGroupID, [ProviderGroupName ], State, ServiceLevel, ProgramYear, ClientName, MasterOpportunityType," +
            "   MasterOpportunityTypePosition, OpportunityType, OpportunitySubType, OpportunityTypePosition, OpportunitySubTypePosition," +
            "   DisplayText, AssessmentCount, DeploymentCount, GapCount, LastUpdatedDate,CreatedBy='System',CreatedDate= GETUTCDATE(),ClientId,LobName  " +
            "   FROM ProgPerf.ProviderGroupOpportunitiesDetail  WITH (NOLOCK) " +
            "   WHERE   " +
            "   %s " +
            "   MasterOpportunityType =:MASTEROPPORTUNITYTYPE " +

            "   DELETE FROM ProgPerf.ProviderGroupOpportunitiesDetail " +
            "   WHERE   " +
            "   %s " +
            "   MasterOpportunityType =:MASTEROPPORTUNITYTYPE";

    private static final String INSERT_PROVIDERGROUP_OPPORTUNITYDETAIL = "INSERT    " +
            "   INTO    " +
            "   ProgPerf.ProviderGroupOpportunitiesDetail (ProviderGroupID, [ProviderGroupName ], State, ServiceLevel, ProgramYear, ClientName, " +
            " OpportunityType, OpportunitySubType, OpportunityTypePosition, OpportunitySubTypePosition, " +
            " DisplayText, AssessmentCount, DeploymentCount, GapCount, LastUpdatedDate, MasterOpportunityType, MasterOpportunityTypePosition, " +
            " CreatedBy, CreatedDate,ClientId,LobName) " +
            " VALUES('%s', '%s', '%s', '%s', '%s', '%s', " +
            " '%s', '%s', '%s', '%s', " +
            " '%s', %d, %d, %d, GETUTCDATE(), '%s', '%s', " +
            " 'System', GETUTCDATE(), '%s', '%s')";

    private static final String INSERT_MEMBER_ASSESSMENT_OPPORTUNITIES =
            "   INSERT INTO ProgPerf.MemberAssessmentOpportunity " +
                    "   (ProviderGroupID, State, ServiceLevel, ProgramYear, MasterOpportunityType, OpportunityType, OpportunitySubType, ChartID, LOBName, [ClientName ],CreatedBy,CreatedDate) " +
                    "   VALUES('%s', '%s', '%s', %d, '%s', '%s', '%s','%s', '%s', '%s','System',GETUTCDATE());";

    private static final String DELETE_MEMBER_ASSESSMENT_OPPORTUNITIES="DELETE FROM ProgPerf.MemberAssessmentOpportunity   " +
            "  WHERE ProviderGroupID = '%s'  " +
            "  AND State = '%s'  " +
            "  %s  " +
            "  AND MasterOpportunityType = '%s'  ";

    private static final String DELETE_ALL_MEMBER_ASSESSMENT_OPPORTUNITIES="DELETE FROM ProgPerf.MemberAssessmentOpportunity   " +
            "  WHERE   " +
            "   %s " +
            "   MasterOpportunityType = :MASTEROPPORTUNITYTYPE  ";

    private static final String GENERATE_MEMBER_ASSESSMENT_OPPORTUNITIESV2=
            " INSERT INTO ProgPerf.MemberAssessmentOpportunity " +
            " (ProviderGroupID, State, ServiceLevel, ProgramYear," +
            " MasterOpportunityType, OpportunityType, OpportunitySubType," +
            " ChartID, LOBName, [ClientName ],CreatedBy,CreatedDate) " +

            " SELECT A.Prov_Group_ID as ProviderGroupID, A.providerstate as State, 'NA' as ServiceLevel," +
            " A.Project_Year as ProgramYear, " +
            " MasterOpportunityType='%s', OpportunityType='%s', OpportunitySubType='%s', A.chart_id as ChartID, " +
            " A.lob2 as LOBName, A.ClientNameOFCStandard as ClientName,'System' as CreatedBy, GETUTCDATE() as CreatedDate FROM progperf.MemberAssessment A WITH (NOLOCK) " +
            " WHERE A.prov_group_id = '%s'" +
            " AND A.providerstate = '%s'" +
            " AND A.Project_Year =%d  " +
            " AND A.LOB2 ='%s'" +
            " AND A.ClientNameOFCStandard = '%s'" +
            " AND A.DerivedDeployed = 1" +
            " AND A.overall_status = 'Not Received' "+
            " AND EXISTS ( SELECT * FROM ProgPerf.ProviderGroup pg , ProgPerf.Accounts ao" +
            " WHERE pg.ProviderGroupID = A.Prov_Group_ID AND pg.State = A.providerstate" +
            " AND pg.ProviderGroupID = ao.GroupId" +
            " AND ao.ServiceLevel IN (%s))"+
            " AND UPPER(A.RecordChangeType) <> 'DELETED' ";

    private static final String UPDATE_JOBRUNCONFIGURATION_AS_INPUT_STATUS_WITH_JOBEND_DATE ="UPDATE    " +
            "  ProgPerf.JobRunConfiguration    " +
            "SET    " +
            "  Status = :STATUS,    " +
            "  ModifiedBy = :MODIFIEDBY,    " +
            "  ModifiedDate = GETUTCDATE(),    " +
            "  JobEnd = GETUTCDATE(),    " +
            "  ErrorMessage = :ERRORMESSAGE  " +
            "WHERE    " +
            "  JobName = :JOBNAME";
    private static final String UPDATE_JOBRUNCONFIGURATION_AS_SUCCESS_UPDATED_WITH_MESSAGE="UPDATE    " +
            "  ProgPerf.JobRunConfiguration    " +
            "SET    " +
            "  Status = :STATUS,    " +
            "  LastSuccessfulRunDate = GETUTCDATE(),    " +
            "  ModifiedBy = :MODIFIEDBY,    " +
            "  ModifiedDate = GETUTCDATE(),    " +
            "  JobEnd = GETUTCDATE(),    " +
            "  ErrorMessage = :ERRORMESSAGE,  " +
            "  Message = :MESSAGE "+
            "WHERE    " +
            "  JobName = :JOBNAME " + 
            "UPDATE  " +
            "  [ProgPerf].[JobExecutionHistory]  " +
            "SET  " +
            "  [Status] = :STATUS,  " +
            "  [JobEnd] = getUTCDate(),  " +
            "  [Message] = :MESSAGE  " +
            "WHERE  " +
            "  [ID] = (  " +
            "  SELECT  " +
            "    MAX(ID)  " +
            "  FROM  " +
            "    ProgPerf.JobExecutionHistory WITH (NOLOCK)  " +
            "  WHERE  " +
            "    [JobID] = (  " +
            "    SELECT  " +
            "      ID  " +
            "    FROM  " +
            "      ProgPerf.JobRunConfiguration  " +
            "    WHERE  " +
            "      JobName = :JOBNAME))";

    private static final String UPDATE_JOBRUNCONFIGURATION_AS_INPROGRESS="UPDATE  " +
            "  ProgPerf.JobRunConfiguration  " +
            "SET  " +
            "  LastRunDate =GETUTCDATE(),  " +
            "  Status = :STATUS,  " +
            "  ModifiedBy = :MODIFIEDBY,  " +
            "  ModifiedDate = GETUTCDATE(),  " +
            "  JobStart = GETUTCDATE()  " +
            "WHERE  " +
            "  JobName = :JOBNAME";

    private static final String UPDATE_JOB_RUN_CONFIGURATION_AS_FAILED="UPDATE  " +
            "  ProgPerf.JobRunConfiguration  " +
            "SET  " +
            "  LastRunDate =GETUTCDATE(),  " +
            "  Status = :STATUS,  " +
            "  ModifiedBy = :MODIFIEDBY,  " +
            "  ModifiedDate = GETUTCDATE(),  " +
            "  JobEnd = GETUTCDATE(),  " +
            "  ErrorMessage = :ERRORMESSAGE  " +
            " WHERE  " +
            "  JobName = :JOBNAME";

    private static final String SELECT_JOBRUNCONFIGURATION=
            " SELECT Status FROM ProgPerf.JobRunConfiguration J" +
                    " WHERE J.JobName = :JOBNAME ";

    private static final String UPDATEDROWSCOUNT="SELECT  " +
            "  (  " +
            "  SELECT  " +
            "    COUNT(pgos.ID)  " +
            "  FROM  " +
            "    ProgPerf.ProviderGroupOpportunitiesSummary pgos WITH (NOLOCK) " +
            "  WHERE  " +
            "    MASterLevelOpportunity = :OPPORTUNITYTYPE  " +
            "    AND CreatedDate > (  " +
            "    SELECT  " +
            "      JobStart  " +
            "    FROM  " +
            "      ProgPerf.JobRunConfiguration WITH (NOLOCK) " +
            "    WHERE  " +
            "      JobName = :JOBNAME)  " +
            "    AND CreatedDate < (  " +
            "    SELECT  " +
            "      JobEnd  " +
            "    FROM  " +
            "      ProgPerf.JobRunConfiguration WITH (NOLOCK) " +
            "    WHERE  " +
            "      JobName = :JOBNAME)) AS Summery,  " +
            "  (  " +
            "  SELECT  " +
            "    COUNT(pgod.ID)  " +
            "  FROM  " +
            "    ProgPerf.ProviderGroupOpportunitiesDetail pgod WITH (NOLOCK) " +
            "  WHERE  " +
            "    pgod.MASterOpportunityType = :OPPORTUNITYTYPE  " +
            "    AND pgod.CreatedDate > (  " +
            "    SELECT  " +
            "      JobStart  " +
            "    FROM  " +
            "      ProgPerf.JobRunConfiguration WITH (NOLOCK) " +
            "    WHERE  " +
            "      JobName = :JOBNAME)  " +
            "    AND pgod.CreatedDate < (  " +
            "    SELECT  " +
            "      JobEnd  " +
            "    FROM  " +
            "      ProgPerf.JobRunConfiguration WITH (NOLOCK) " +
            "    WHERE  " +
            "      JobName = :JOBNAME)) AS Detail,  " +
            "  (  " +
            "  SELECT  " +
            "    COUNT(mao.ID)  " +
            "  FROM  " +
            "    ProgPerf.MemberASsessmentOpportunity mao WITH (NOLOCK) " +
            "  WHERE  " +
            "    mao.MASterOpportunityType = :OPPORTUNITYTYPE  " +
            "    AND mao.CreatedDate > (  " +
            "    SELECT  " +
            "      JobStart  " +
            "    FROM  " +
            "      ProgPerf.JobRunConfiguration WITH (NOLOCK) " +
            "    WHERE  " +
            "      JobName = :JOBNAME)  " +
            "    AND mao.CreatedDate < (  " +
            "    SELECT  " +
            "      JobEnd  " +
            "    FROM  " +
            "      ProgPerf.JobRunConfiguration WITH (NOLOCK) " +
            "    WHERE  " +
            "      JobName = :JOBNAME)) AS MemberAssessmentOpportunity";

    @Override
    public Flux<ProviderGroup> getProviderGroupsByLastRunDate(Map<String,String> inputMap,OpportunityType opportunityType) {

        if(OpportunityType.REJECTS.getValue().equalsIgnoreCase(opportunityType.getValue()) || OpportunityType.RETURNS.getValue().equalsIgnoreCase(opportunityType.getValue())){

            boolean overlapPeriodActive =inputMap.get(RuleConstants.OVERLAP_ENABLED_FOR_REJECTS)!=null
                    && inputMap.get(RuleConstants.PREVIOUS_PROGRAM_YEAR)!=null
                    && inputMap.get(RuleConstants.OVERLAP_ENABLED_FOR_REJECTS).equalsIgnoreCase(RuleConstants.ACTIVE);

            String programYearCondition ="";

            if(overlapPeriodActive && OpportunityType.REJECTS.getValue().equalsIgnoreCase(opportunityType.getValue()))
            {
                programYearCondition= " AND A.Project_Year IN ( " + inputMap.get(RuleConstants.PROGRAM_YEAR)+ ","+ inputMap.get(RuleConstants.PREVIOUS_PROGRAM_YEAR) + " ) ";

            }else {
                programYearCondition=" AND A.Project_Year = " + inputMap.get(RuleConstants.PROGRAM_YEAR);
            }

            String modifiedProviderGroups=String.format(PROVIDER_GROUPS_BY_LAST_RUN_DATE,programYearCondition);

            return opportunityClient.execute(modifiedProviderGroups)
                    .bind(ColumnNames.LASTRUNDATE.getColumnName(), inputMap.get(opportunityType.getValue()))
                    .bind(ColumnNames.SERVICELEVEL.getColumnName(), Arrays.asList(inputMap.get(RuleConstants.SERVICE_LEVEL).split(",")))
                    .as(ProviderGroup.class)
                    .fetch()
                    .all()
                    .switchIfEmpty(Flux.just(ProviderGroup.builder().build()));  //to continue flow further, returning ProviderGroup with empty.


        }else if(OpportunityType.FINANCIAL_INFORMATION.getValue().equalsIgnoreCase(opportunityType.getValue()) ){

            return opportunityClient.execute(PROVIDER_GROUPS_BY_LAST_RUN_DATE_FOR_FINCANICAL)
                    .bind(ColumnNames.SERVICELEVEL.getColumnName(), Arrays.asList(inputMap.get(RuleConstants.SERVICE_LEVEL).split(",")))
//                    .bind(ColumnNames.LASTRUNDATE.getColumnName(), inputMap.get(opportunityType.getValue()))
                    .as(ProviderGroup.class)
                    .fetch()
                    .all()
                    .switchIfEmpty(Flux.just(ProviderGroup.builder().build()));  //to continue flow further, returning ProviderGroup with empty.
        }else if(OpportunityType.DEPLOYMENTS.getValue().equalsIgnoreCase(opportunityType.getValue()) ){
            return opportunityClient.execute(PROVIDER_GROUPS_BY_LAST_RUN_DATE_FOR_DEPLOYMENTS)
                    .bind(ColumnNames.PROGRAMYEAR.getColumnName(), Integer.parseInt(inputMap.get(RuleConstants.PROGRAM_YEAR)))
                    .bind(ColumnNames.LASTRUNDATE.getColumnName(), String.valueOf(inputMap.get(RuleConstants.DEPLOYMENTS_LAST_RUN_DATE)))
                    .as(ProviderGroup.class)
                    .fetch()
                    .all()
                    .switchIfEmpty(Flux.just(ProviderGroup.builder().build()));  //to continue flow further, returning ProviderGroup with empty.
        }else {
            return Flux.empty();
        }
    }

    @Override
    public Flux<RejectOpportunityInput> getRejectOpportunityInput(Map<String,String> inputMap,boolean isModified) {

        //if Overlap Period is Active for Rejects, Consider CurrentProgramYear and PreviousProgramYear
        String programYears="";
        String executeModifiedGroupsProgramYearCondition="";
        String rejectsOverlapEnabledQuery="";

        boolean overlapPeriodActive =inputMap.get(RuleConstants.OVERLAP_ENABLED_FOR_REJECTS)!=null
                && inputMap.get(RuleConstants.PREVIOUS_PROGRAM_YEAR)!=null
                && inputMap.get(RuleConstants.OVERLAP_ENABLED_FOR_REJECTS).equalsIgnoreCase(RuleConstants.ACTIVE);

        if(overlapPeriodActive)
        {
            programYears= " AND A.Project_Year IN ( " + inputMap.get(RuleConstants.PROGRAM_YEAR)+ ","+ inputMap.get(RuleConstants.PREVIOUS_PROGRAM_YEAR) + " ) ";

        }else {
            programYears=" AND A.Project_Year = " + inputMap.get(RuleConstants.PROGRAM_YEAR);
        }

        if(isModified) {
            if(overlapPeriodActive){
                executeModifiedGroupsProgramYearCondition= " Ax.Project_Year IN ( " + inputMap.get(RuleConstants.PROGRAM_YEAR)+ ","+ inputMap.get(RuleConstants.PREVIOUS_PROGRAM_YEAR) + " ) ";

            }else{
                executeModifiedGroupsProgramYearCondition=" Ax.Project_Year = " + inputMap.get(RuleConstants.PROGRAM_YEAR);
            }

            final String rejectsModifiedOpportunitiesQuery = REJECTS_OPPORTUNITIES_QUERY +
                    " AND A.Prov_Group_ID+A.providerstate in ( SELECT " +
                    " DISTINCT Ax.Prov_Group_ID + Ax.providerstate AS ProviderGroupIDState FROM " +
                    " progperf.MemberAssessment Ax WITH (NOLOCK) " +
                    " WHERE " +
                      executeModifiedGroupsProgramYearCondition +
                    " AND Ax.UpdatedDate > :LASTRUNDATE)";

            rejectsOverlapEnabledQuery=String.format(rejectsModifiedOpportunitiesQuery,programYears);

            return opportunityClient.execute(rejectsOverlapEnabledQuery)
                    .bind(ColumnNames.LOB.getColumnName(), Arrays.asList(inputMap.get(RuleConstants.LOBS).split(",")))
                    .bind(ColumnNames.LASTRUNDATE.getColumnName(), String.valueOf(inputMap.get(RuleConstants.REJECT_LAST_RUN_DATE)))
                    .bind(ColumnNames.SERVICELEVEL.getColumnName(), Arrays.asList(inputMap.get(RuleConstants.SERVICE_LEVEL).split(",")))
                    .as(RejectOpportunityInput.class)
                    .fetch()
                    .all();
        }
        else {
            rejectsOverlapEnabledQuery=String.format(REJECTS_OPPORTUNITIES_QUERY,programYears);

            return opportunityClient.execute(rejectsOverlapEnabledQuery)
                    .bind(ColumnNames.LOB.getColumnName(), Arrays.asList(inputMap.get(RuleConstants.LOBS).split(",")))
                    .bind(ColumnNames.SERVICELEVEL.getColumnName(), Arrays.asList(inputMap.get(RuleConstants.SERVICE_LEVEL).split(",")))
                    .as(RejectOpportunityInput.class)
                    .fetch()
                    .all();
        }
    }


    @Override
    public Flux<ReturnOpportunityInput> getReturnOpportunityInput(Map<String,String> inputMap, boolean isModified) {

        if(isModified) {
            final String returnsOpportunityQuery = String.format(RETURNS_OPPORTUNITIES_QUERY_OCT_30_RELEASE , " AND A.Prov_Group_ID+A.providerstate in ( SELECT " +
                    " DISTINCT Ax.Prov_Group_ID + Ax.providerstate AS ProviderGroupIDState FROM " +
                    " progperf.MemberAssessment Ax WITH (NOLOCK) " +
                    " WHERE " +
                    " Ax.Project_Year = :PROJECTYEAR " +
                    " AND Ax.UpdatedDate > :LASTRUNDATE)");
            return opportunityClient.execute(returnsOpportunityQuery)
                    .bind(ColumnNames.LOB.getColumnName(), Arrays.asList(inputMap.get(RuleConstants.LOBS).split(",")))
                    .bind(ColumnNames.PROJECTYEAR.getColumnName(), Integer.parseInt(inputMap.get(RuleConstants.PROGRAM_YEAR)))
                    .bind(ColumnNames.LASTRUNDATE.getColumnName(), String.valueOf(inputMap.get(RuleConstants.RETURN_LAST_RUN_DATE)))
                    .bind(ColumnNames.SERVICELEVEL.getColumnName(), Arrays.asList(inputMap.get(RuleConstants.SERVICE_LEVEL).split(",")))
                    .as(ReturnOpportunityInput.class)
                    .fetch()
                    .all();
        } else {
            final String returnsOpportunityQuery = String.format(RETURNS_OPPORTUNITIES_QUERY_OCT_30_RELEASE, " ");
            return opportunityClient.execute(returnsOpportunityQuery)
                    .bind(ColumnNames.LOB.getColumnName(), Arrays.asList(inputMap.get(RuleConstants.LOBS).split(",")))
                    .bind(ColumnNames.PROJECTYEAR.getColumnName(), Integer.parseInt(inputMap.get(RuleConstants.PROGRAM_YEAR)))
                    .bind(ColumnNames.SERVICELEVEL.getColumnName(), Arrays.asList(inputMap.get(RuleConstants.SERVICE_LEVEL).split(",")))
                    .as(ReturnOpportunityInput.class)
                    .fetch()
                    .all();
        }

    }

    @Override
    public Flux<OutlierOpportunityInput> getOutlierOpportunityInput(Map<String, String> inputMap) {
        //if OverlapEnabledForOutliers is Active for Outliers, Consider CurrentProgramYear and PreviousProgramYear
        String programYears="";

        boolean overlapPeriodActive =inputMap.get(RuleConstants.OVERLAP_ENABLED_FOR_OUTLIERS)!=null
                && inputMap.get(RuleConstants.PREVIOUS_PROGRAM_YEAR)!=null
                && inputMap.get(RuleConstants.OVERLAP_ENABLED_FOR_OUTLIERS).equalsIgnoreCase(RuleConstants.ACTIVE);

        if(overlapPeriodActive)
        {
            programYears= " AND A.ProgramYear IN ( " + inputMap.get(RuleConstants.PROGRAM_YEAR)+ ","+ inputMap.get(RuleConstants.PREVIOUS_PROGRAM_YEAR) + " ) ";

        }else {
            programYears=" AND A.ProgramYear = " + inputMap.get(RuleConstants.PROGRAM_YEAR);
        }

        String outliersOverlapEnabledQuery=String.format(OUTLIER_OPPORTUNITIES_QUERY,programYears);
        return opportunityClient.execute(outliersOverlapEnabledQuery)
                .bind(ColumnNames.MASTEROPPORTUNITYTYPE.getColumnName(), RuleConstants.OUTLIERS)
                .as(OutlierOpportunityInput.class)
                .fetch()
                .all();
    }

    @Override
    public Flux<SecondarySubmissionOpportunityInput> getSecondarySubmissionOpportunityInput(Map<String, String> inputMap) {
        return opportunityClient.execute(SECONDARYSUBMISSION_OPPORTUNITIES_QUERY)
                .bind(ColumnNames.ISSECONDARYSUBMISSIONELIGIBLE.getColumnName(), RuleConstants.ISSECONDARYSUBMISSIONELIGIBLE)
                .bind(ColumnNames.PROJECTYEAR.getColumnName(), Integer.parseInt(inputMap.get(RuleConstants.PROGRAM_YEAR)))
                .as(SecondarySubmissionOpportunityInput.class)
                .fetch()
                .all();
    }

    @Override
    public Flux<FinancialInformationOpportunityInput> getFinancialInformationOpportunityInput(Map<String, String> inputMap) {
        return opportunityClient.execute(FINANCIALINFORMATION_OPPORTUNITIES_QUERY)
              //  .bind(ColumnNames.LASTRUNDATE.getColumnName(), String.valueOf(inputMap.get(RuleConstants.FINANCIAL_INFORMATION_LAST_RUN_DATE)))
                .bind(ColumnNames.SERVICELEVEL.getColumnName(), Arrays.asList(inputMap.get(RuleConstants.SERVICE_LEVEL).split(",")))
                .as(FinancialInformationOpportunityInput.class)
                .fetch()
                .all();
    }

    @Override
    public Flux<DeploymentOpportunityInput> getDeploymentOpportunityInput(Map<String, String> inputMap, boolean isModified) {
        if(isModified) {
            final String returnsOpportunityQuery = String.format(DEPLOYMENTS_OPPORTUNITIES_QUERY , "    AND PA.ProviderGroupID + PA.ProviderState in (  " +
                    "    SELECT  " +
                    "      DISTINCT PAx.ProviderGroupID + PAx.ProviderState AS ProviderGroupIDState  " +
                    "    FROM  " +
                    "      progperf.PafExMemberAssessment PAx WITH (NOLOCK)  " +
                    "    WHERE  " +
                    "      PAx.ProgramYear = :PROGRAMYEAR  " +
                    "      AND PAx.UpdatedDate > :LASTRUNDATE)");
            return opportunityClient.execute(returnsOpportunityQuery)
                    .bind(ColumnNames.PROGRAMYEAR.getColumnName(), Integer.parseInt(inputMap.get(RuleConstants.PROGRAM_YEAR)))
                    .bind(ColumnNames.LASTRUNDATE.getColumnName(), String.valueOf(inputMap.get(RuleConstants.DEPLOYMENTS_LAST_RUN_DATE)))
                    .as(DeploymentOpportunityInput.class)
                    .fetch()
                    .all();
        } else {
            final String returnsOpportunityQuery = String.format(DEPLOYMENTS_OPPORTUNITIES_QUERY, " ");
            return opportunityClient.execute(returnsOpportunityQuery)
                    .bind(ColumnNames.PROGRAMYEAR.getColumnName(), Integer.parseInt(inputMap.get(RuleConstants.PROGRAM_YEAR)))
                    .as(DeploymentOpportunityInput.class)
                    .fetch()
                    .all();
        }
    }

    @Override
    public Mono<Integer> moveProviderGroupOpportunitySummeryToHistory(String opportunityType,Map<String, String> inputMap) {
        String programYearIn="";
        String formattedQuery="";
        if((OpportunityType.FINANCIAL_INFORMATION.getValue().equalsIgnoreCase(opportunityType)
                && inputMap.get(RuleConstants.PREVIOUS_PROGRAM_YEAR)!=null)
                ||
                (OpportunityType.REJECTS.getValue().equalsIgnoreCase(opportunityType)
                && inputMap.get(RuleConstants.OVERLAP_ENABLED_FOR_REJECTS)!=null
                && inputMap.get(RuleConstants.PREVIOUS_PROGRAM_YEAR)!=null
                && inputMap.get(RuleConstants.OVERLAP_ENABLED_FOR_REJECTS).equalsIgnoreCase(RuleConstants.ACTIVE))
                ||
                (OpportunityType.OUTLERS.getValue().equalsIgnoreCase(opportunityType)
                        && inputMap.get(RuleConstants.OVERLAP_ENABLED_FOR_OUTLIERS)!=null
                        && inputMap.get(RuleConstants.PREVIOUS_PROGRAM_YEAR)!=null
                        && inputMap.get(RuleConstants.OVERLAP_ENABLED_FOR_OUTLIERS).equalsIgnoreCase(RuleConstants.ACTIVE))
                )
        {
            programYearIn= " ProgramYear IN ( " + inputMap.get(RuleConstants.PROGRAM_YEAR)+ ","+ inputMap.get(RuleConstants.PREVIOUS_PROGRAM_YEAR) + " ) AND ";

        }else {
            programYearIn=" ProgramYear = " + inputMap.get(RuleConstants.PROGRAM_YEAR) + " AND ";
        }
        formattedQuery=String.format(MOVE_ALL_SUMMERY_TO_SUMMERYHISTORY,programYearIn,programYearIn);
        return opportunityClient.execute(formattedQuery)
                .bind(ColumnNames.MASTERLEVELOPPORTUNITY.getColumnName(),opportunityType)
                .fetch().rowsUpdated();
    }

    @Override
    public Mono<Integer> moveProviderGroupOpportunityDetailToHistory( String opportunityType,Map<String, String> inputMap) {
        String programYearIn="";
        String formattedQuery="";
        if((OpportunityType.FINANCIAL_INFORMATION.getValue().equalsIgnoreCase(opportunityType)
                && inputMap.get(RuleConstants.PREVIOUS_PROGRAM_YEAR)!=null)
                ||
                (OpportunityType.REJECTS.getValue().equalsIgnoreCase(opportunityType)
                && inputMap.get(RuleConstants.OVERLAP_ENABLED_FOR_REJECTS)!=null
                && inputMap.get(RuleConstants.PREVIOUS_PROGRAM_YEAR)!=null
                && inputMap.get(RuleConstants.OVERLAP_ENABLED_FOR_REJECTS).equalsIgnoreCase(RuleConstants.ACTIVE))
                ||
                (OpportunityType.OUTLERS.getValue().equalsIgnoreCase(opportunityType)
                        && inputMap.get(RuleConstants.OVERLAP_ENABLED_FOR_OUTLIERS)!=null
                        && inputMap.get(RuleConstants.PREVIOUS_PROGRAM_YEAR)!=null
                        && inputMap.get(RuleConstants.OVERLAP_ENABLED_FOR_OUTLIERS).equalsIgnoreCase(RuleConstants.ACTIVE))
                )
        {
            programYearIn=" ProgramYear IN ( " + inputMap.get(RuleConstants.PROGRAM_YEAR)+ ","+ inputMap.get(RuleConstants.PREVIOUS_PROGRAM_YEAR) + " ) AND ";
        }else {
            programYearIn=" ProgramYear = " + inputMap.get(RuleConstants.PROGRAM_YEAR) + " AND ";
        }
        formattedQuery=String.format(MOVE_ALL_DETAIL_TO_DETAILHISTORY,programYearIn,programYearIn);
        return opportunityClient.execute(formattedQuery)
                .bind(ColumnNames.MASTEROPPORTUNITYTYPE.getColumnName(),opportunityType)
                .fetch().rowsUpdated();
    }

//    @Override
//    public Mono<Integer> updateJobRunConfigurationAsInProgress(OpportunityType opportunityType) {
//        return opportunityClient.execute(UPDATE_JOBRUNCONFIGURATION_AS_INPROGRESS)
//                .bind(ColumnNames.STATUS.getColumnName(), Status.IN_PROGRESS.getValue())
//                .bind(ColumnNames.MODIFIEDBY.getColumnName(),RuleConstants.SYSTEM)
//                .bind(ColumnNames.JOBNAME.getColumnName(), ruleMapper.getJobName(opportunityType).getValue())
//                .fetch().rowsUpdated();
//    }

//    @Override
//    public Mono<Integer> updateJobRunConfigurationAsSuccess(OpportunityType opportunityType) {
//        return opportunityClient.execute(UPDATE_JOBRUNCONFIGURATION_AS_INPUT_STATUS_WITH_JOBEND_DATE)
//                .bind(ColumnNames.STATUS.getColumnName(), Status.SUCCESS.getValue())
//                .bind(ColumnNames.MODIFIEDBY.getColumnName(), RuleConstants.SYSTEM)
//                .bind(ColumnNames.JOBNAME.getColumnName(), ruleMapper.getJobName(opportunityType).getValue())
//                .bind(ColumnNames.ERROR_MESSAGE.getColumnName(), StringUtils.EMPTY)
//                .fetch().rowsUpdated();
//    }

//    @Override
//    public Mono<Integer> updateJobRunConfigurationAsInProgressWithJobEndDate(OpportunityType opportunityType) {
//        return opportunityClient.execute(UPDATE_JOBRUNCONFIGURATION_AS_INPUT_STATUS_WITH_JOBEND_DATE)
//                .bind(ColumnNames.STATUS.getColumnName(), Status.IN_PROGRESS.getValue())
//                .bind(ColumnNames.MODIFIEDBY.getColumnName(), RuleConstants.SYSTEM)
//                .bind(ColumnNames.JOBNAME.getColumnName(), ruleMapper.getJobName(opportunityType).getValue())
//                .bind(ColumnNames.ERROR_MESSAGE.getColumnName(), StringUtils.EMPTY)
//                .fetch().rowsUpdated();
//    }

//    @Override
//    public Mono<Integer> updateJobRunConfigurationAsSuccess(OpportunityType opportunityType, String message) {
//        log.debug("Running query : {} with params status : {}, modifiedBy : {},  jobName : {}, errorMessage : {}, message : {}", UPDATE_JOBRUNCONFIGURATION_AS_SUCCESS_UPDATED_WITH_MESSAGE,Status.SUCCESS.getValue(),RuleConstants.SYSTEM, ruleMapper.getJobName(opportunityType).getValue(),StringUtils.EMPTY, message);
//        return opportunityClient.execute(UPDATE_JOBRUNCONFIGURATION_AS_SUCCESS_UPDATED_WITH_MESSAGE)
//                .bind(ColumnNames.STATUS.getColumnName(), Status.SUCCESS.getValue())
//                .bind(ColumnNames.MODIFIEDBY.getColumnName(), RuleConstants.SYSTEM)
//                .bind(ColumnNames.JOBNAME.getColumnName(), ruleMapper.getJobName(opportunityType).getValue())
//                .bind(ColumnNames.ERROR_MESSAGE.getColumnName(), StringUtils.EMPTY)
//                .bind(ColumnNames.MESSAGE.getColumnName(), message)
//                .fetch().rowsUpdated();
//    }
//    @Override
//    public Mono<Integer> updateJobRunConfigurationToFailed(String jobName,String errorMessage) {
//        return opportunityClient.execute(UPDATE_JOB_RUN_CONFIGURATION_AS_FAILED)
//                .bind(ColumnNames.STATUS.getColumnName(),Status.FAILURE.getValue())
//                .bind(ColumnNames.MODIFIEDBY.getColumnName(),RuleConstants.SYSTEM)
//                .bind(ColumnNames.JOBNAME.getColumnName(),jobName)
//                .bind(ColumnNames.ERROR_MESSAGE.getColumnName(),errorMessage)
//                .fetch().rowsUpdated();
//    }

//    @Override
//    public Mono<String> getJobRunConfiguration(String jobName) {
//        return opportunityClient.execute(SELECT_JOBRUNCONFIGURATION)
//                .bind(ColumnNames.JOBNAME.getColumnName(), jobName)
//                .as(String.class)
//                .fetch()
//                .one();
//    }

    @Override
    public Mono<Integer> deleteMemberAssessmentOpportunity( String opportunityType, Map<String, String> inputMap) {
        String programYearIn="";
        String deleteAssessmentQuery="";
        if(OpportunityType.REJECTS.getValue().equalsIgnoreCase(opportunityType)
                        && inputMap.get(RuleConstants.OVERLAP_ENABLED_FOR_REJECTS)!=null
                        && inputMap.get(RuleConstants.PREVIOUS_PROGRAM_YEAR)!=null
                        && inputMap.get(RuleConstants.OVERLAP_ENABLED_FOR_REJECTS).equalsIgnoreCase(RuleConstants.ACTIVE))
        {
            programYearIn=" ProgramYear IN ( " + inputMap.get(RuleConstants.PROGRAM_YEAR)+ ","+ inputMap.get(RuleConstants.PREVIOUS_PROGRAM_YEAR) + " )  AND ";
        }else {
            programYearIn=" ProgramYear = " + inputMap.get(RuleConstants.PROGRAM_YEAR) +" AND ";
        }
        deleteAssessmentQuery=String.format(DELETE_ALL_MEMBER_ASSESSMENT_OPPORTUNITIES,programYearIn);
        return opportunityClient.execute(deleteAssessmentQuery)
                .bind(ColumnNames.MASTEROPPORTUNITYTYPE.getColumnName(),opportunityType)
                .fetch().rowsUpdated();
    }


    @Override
    public  Mono<Long> groupingOfQueriesForDeleteMemberAssessmentOpportunities(List<ProviderGroup> providerGroupList, String opportunityValue,  Map<String, String> inputMap) {
        List<String> updateQueries = providerGroupList.stream()
                .map(providerGroup ->
                     getFormattedQueryToDeleteMemberAssessmentOpportunities(providerGroup,opportunityValue,inputMap)
                )
                .collect(Collectors.toList());
        providerGroupList.clear();
        return commonRepository.updateBatchQueries(updateQueries);
    }

    private String getFormattedQueryToDeleteMemberAssessmentOpportunities(ProviderGroup providerGroup, String opportunityType,  Map<String, String> inputMap) {
        String programYearIn="";
        if(OpportunityType.REJECTS.getValue().equalsIgnoreCase(opportunityType)
                && inputMap.get(RuleConstants.OVERLAP_ENABLED_FOR_REJECTS)!=null
                && inputMap.get(RuleConstants.PREVIOUS_PROGRAM_YEAR)!=null
                && inputMap.get(RuleConstants.OVERLAP_ENABLED_FOR_REJECTS).equalsIgnoreCase(RuleConstants.ACTIVE))
        {
            programYearIn=" AND ProgramYear IN ( " + inputMap.get(RuleConstants.PROGRAM_YEAR)+ ","+ inputMap.get(RuleConstants.PREVIOUS_PROGRAM_YEAR) + " ) ";
        }else {
            programYearIn=" AND ProgramYear = " + inputMap.get(RuleConstants.PROGRAM_YEAR) ;
        }

        return String.format(DELETE_MEMBER_ASSESSMENT_OPPORTUNITIES,
                providerGroup.getProviderGroupID(),
                providerGroup.getState(),
                programYearIn,
                opportunityType);
    }

    @Override
    public Mono<Long> batchQueriesExecuteForInsertMemberAssessmentOpportunities(List<MemberAssessmentOpportunity> memberAssessmentOpportunities) {
        List<String> updateQueries = memberAssessmentOpportunities.stream()
                .map(this::getFormattedQueryToInsertMemberAssessmentOpportunities)
                .collect(Collectors.toList());
        memberAssessmentOpportunities.clear();
        return commonRepository.updateBatchQueries(updateQueries);
    }

    @Override
    public Mono<Long> batchQueriesExecuteForGetMemberAssessmentOpportunities(List<MemberAssessmentOpportunity> memberAssessmentOpportunities,
                                                                                                Map<String, String> processQueryInputMap) {
        List<String> updateQueries = memberAssessmentOpportunities.stream()
                .map(memberAssessmentOpportunity ->
                     getFormattedQueryToSelectMemberAssessmentOpportunities(memberAssessmentOpportunity,processQueryInputMap)
                )
                .collect(Collectors.toList());
        memberAssessmentOpportunities.clear();
        return commonRepository.updateBatchQueries(updateQueries);
    }

    private String getFormattedQueryToSelectMemberAssessmentOpportunities(MemberAssessmentOpportunity memberAssessmentOpportunity,Map<String, String> processQueryInputMap) {
        return String.format(GENERATE_MEMBER_ASSESSMENT_OPPORTUNITIESV2,
                memberAssessmentOpportunity.getMasterOpportunityType(),
                memberAssessmentOpportunity.getOpportunityType(),
                memberAssessmentOpportunity.getOpportunitySubType(),
                memberAssessmentOpportunity.getProviderGroupID(),
                memberAssessmentOpportunity.getState(),
                memberAssessmentOpportunity.getProgramYear(),
                memberAssessmentOpportunity.getLobName(),
                memberAssessmentOpportunity.getClientName(),
                Stream.of(processQueryInputMap.get(RuleConstants.SERVICE_LEVEL).split(",")).collect(Collectors.joining("','", "'", "'"))
                );
    }


    private String getFormattedQueryToInsertMemberAssessmentOpportunities(MemberAssessmentOpportunity memberAssessmentOpportunity) {
        return String.format(INSERT_MEMBER_ASSESSMENT_OPPORTUNITIES,
                memberAssessmentOpportunity.getProviderGroupID(),
                memberAssessmentOpportunity.getState(),
                memberAssessmentOpportunity.getServiceLevel(),
                memberAssessmentOpportunity.getProgramYear(),
                memberAssessmentOpportunity.getMasterOpportunityType(),
                memberAssessmentOpportunity.getOpportunityType(),
                memberAssessmentOpportunity.getOpportunitySubType(),
                memberAssessmentOpportunity.getChartID(),
                memberAssessmentOpportunity.getLobName(),
                memberAssessmentOpportunity.getClientName()
        );
    }

    @Override
    public  Mono<Long> groupingOfQueriesForMoveSummaryToHistory(List<ProviderGroup> providerGroupList, String opportunityValue, Map<String, String> inputMap) {
        List<String> updateQueries = providerGroupList.stream()
                .map(providerGroup ->
                        groupingOfQueriesForMoveSummaryToHistory(providerGroup,opportunityValue,inputMap)
                )
                .collect(Collectors.toList());
        providerGroupList.clear();
        return commonRepository.updateBatchQueries(updateQueries);
    }

    private String groupingOfQueriesForMoveSummaryToHistory(ProviderGroup providerGroup, String opportunityValue, Map<String, String> inputMap) {
        String programYearIn;
        if((OpportunityType.FINANCIAL_INFORMATION.getValue().equalsIgnoreCase(opportunityValue)
                && inputMap.get(RuleConstants.PREVIOUS_PROGRAM_YEAR) != null)
                ||
                (OpportunityType.REJECTS.getValue().equalsIgnoreCase(opportunityValue)
                        && inputMap.get(RuleConstants.OVERLAP_ENABLED_FOR_REJECTS)!=null
                        && inputMap.get(RuleConstants.PREVIOUS_PROGRAM_YEAR)!=null
                        && inputMap.get(RuleConstants.OVERLAP_ENABLED_FOR_REJECTS).equalsIgnoreCase(RuleConstants.ACTIVE))
                ||
                (OpportunityType.OUTLERS.getValue().equalsIgnoreCase(opportunityValue)
                        && inputMap.get(RuleConstants.OVERLAP_ENABLED_FOR_OUTLIERS)!=null
                        && inputMap.get(RuleConstants.PREVIOUS_PROGRAM_YEAR)!=null
                        && inputMap.get(RuleConstants.OVERLAP_ENABLED_FOR_OUTLIERS).equalsIgnoreCase(RuleConstants.ACTIVE))
                )

        {
            programYearIn=" ProgramYear IN ( " + inputMap.get(RuleConstants.PROGRAM_YEAR)+ ","+ inputMap.get(RuleConstants.PREVIOUS_PROGRAM_YEAR) + " ) AND ";
        }else {
            programYearIn=" ProgramYear = " + inputMap.get(RuleConstants.PROGRAM_YEAR) +" AND ";
        }
        return String.format(MOVE_SUMMERY_TO_SUMMERYHISTORY,
                providerGroup.getProviderGroupID(),
                providerGroup.getState(),
                programYearIn,
                opportunityValue,
                providerGroup.getProviderGroupID(),
                providerGroup.getState(),
                programYearIn,
                opportunityValue);
    }



    @Override
    public Mono<Long> batchQueriesExecuteForInsertIntoSummary(List<ProviderGroupOpportunitiesSummary> providerGroupOpportunitiesSummaries) {
        List<String> updateQueries = providerGroupOpportunitiesSummaries.stream()
                .map(this::getFormattedQueryToInsertSummary)
                .collect(Collectors.toList());
        providerGroupOpportunitiesSummaries.clear();
        return commonRepository.updateBatchQueries(updateQueries);
    }

    private String getFormattedQueryToInsertSummary(ProviderGroupOpportunitiesSummary summary) {
        return String.format(INSERT_PROVIDERGROUP_OPPORTUNITY_SUMMERY,
                summary.getProviderGroupID(),
                ProgramPerformanceUtil.getQuotedString(summary.getProviderGroupName()),
                summary.getState(),
                summary.getServiceLevel(),
                summary.getProgramYear(),
                summary.getMasterOpportunityType(),
                summary.getMasterOpportunityTypePosition(),
                summary.getTotalAssessmentsCount(),
                summary.getTotalGapsCount(),
               summary.getTotalClientsCount()
        );
    }


    @Override
    public  Mono<Long> groupingOfQueriesForMoveDetailToHistory(List<ProviderGroup> providerGroupList, String opportunityValue, Map<String, String> inputMap) {
        List<String> updateQueries = providerGroupList.stream()
                .map(providerGroup ->
                        getFormattedQueryToMoveDetailToHistory(providerGroup,opportunityValue,inputMap)
                )
                .collect(Collectors.toList());
        providerGroupList.clear();
        return commonRepository.updateBatchQueries(updateQueries);
    }

    private String getFormattedQueryToMoveDetailToHistory(ProviderGroup providerGroup, String opportunityValue, Map<String, String> inputMap) {
        String programYearIn = "";
        if((OpportunityType.FINANCIAL_INFORMATION.getValue().equalsIgnoreCase(opportunityValue)
                && inputMap.get(RuleConstants.PREVIOUS_PROGRAM_YEAR) != null)
                ||
                (OpportunityType.REJECTS.getValue().equalsIgnoreCase(opportunityValue)
                        && inputMap.get(RuleConstants.OVERLAP_ENABLED_FOR_REJECTS)!=null
                        && inputMap.get(RuleConstants.PREVIOUS_PROGRAM_YEAR)!=null
                        && inputMap.get(RuleConstants.OVERLAP_ENABLED_FOR_REJECTS).equalsIgnoreCase(RuleConstants.ACTIVE))
                ||
                (OpportunityType.OUTLERS.getValue().equalsIgnoreCase(opportunityValue)
                        && inputMap.get(RuleConstants.OVERLAP_ENABLED_FOR_OUTLIERS)!=null
                        && inputMap.get(RuleConstants.PREVIOUS_PROGRAM_YEAR)!=null
                        && inputMap.get(RuleConstants.OVERLAP_ENABLED_FOR_OUTLIERS).equalsIgnoreCase(RuleConstants.ACTIVE))
                )
        {
            programYearIn=" ProgramYear IN ( " + inputMap.get(RuleConstants.PROGRAM_YEAR)+ ","+ inputMap.get(RuleConstants.PREVIOUS_PROGRAM_YEAR) + " ) AND ";

        }else {
            programYearIn=" ProgramYear = " + inputMap.get(RuleConstants.PROGRAM_YEAR) + " AND ";
        }
        return String.format(MOVE_DETAIL_TO_DETAILHISTORY,
                providerGroup.getProviderGroupID(),
                providerGroup.getState(),
                programYearIn,
                opportunityValue,
                providerGroup.getProviderGroupID(),
                providerGroup.getState(),
                programYearIn,
                opportunityValue);
    }

    @Override
    public Mono<Long> batchQueriesExecuteForInsertIntoDetail(List<ProviderGroupOpportunitiesDetail> providerGroupOpportunitiesDetails) {
        List<String> updateQueries = providerGroupOpportunitiesDetails.stream()
                .map(this::getFormattedQueryToInsertIntoDetail)
                .collect(Collectors.toList());
        providerGroupOpportunitiesDetails.clear();
        return commonRepository.updateBatchQueries(updateQueries);
    }

    private String getFormattedQueryToInsertIntoDetail(ProviderGroupOpportunitiesDetail detail) {
        return String.format(INSERT_PROVIDERGROUP_OPPORTUNITYDETAIL,
                detail.getProviderGroupID(),
                ProgramPerformanceUtil.getQuotedString(detail.getProviderGroupName()),
                detail.getState(),
                detail.getServiceLevel(),
                detail.getProgramYear(),
                detail.getClientName(),
                detail.getOpportunityType(),
                detail.getOpportunitySubType(),
                detail.getOpportunityTypePosition(),
                detail.getOpportunitySubTypePosition(),
                detail.getDisplayText(),
                detail.getAssessmentCount(),
                detail.getDeploymentCount(),
                detail.getGapCount(),
                detail.getMasterOpportunityType(),
                detail.getMasterOpportunityTypePosition(),
                detail.getClientId(),
                detail.getLobName()
        );
    }



    @Override
    public Flux<ProviderGroupOpportunitiesSummaryDTO> getDeletedOpportunitiesSummaryList(OpportunityType opportunityType,String jobName) {
        return opportunityClient.execute(DELETED_OPPORTUNITIES_SUMMARY_RECORDS)
                .bind(ColumnNames.OPPORTUNITYTYPE.getColumnName(), opportunityType.getValue())
                .bind(ColumnNames.JOBNAME.getColumnName(), jobName)
                .as(ProviderGroupOpportunitiesSummaryDTO.class)
                .fetch()
                .all();
    }


    @Override
    public Flux<ProviderGroupOpportunitiesSummaryDetailDTO> getInsertedOpportunitiesSummaryList(OpportunityType opportunityType, String jobName) {
        return opportunityClient.execute(INSERTED_OPPORTUNITIES_SUMMARY_RECORDS)
                .bind(ColumnNames.OPPORTUNITYTYPE.getColumnName(), opportunityType.getValue())
                .bind(ColumnNames.JOBNAME.getColumnName(), jobName)
                .as(ProviderGroupOpportunitiesSummaryDetailDTO.class)
                .fetch()
                .all();
    }

    @Override
    public Mono<Map<String,Long>> getUpdatedRowsCount(OpportunityType opportunityType, String jobName) {
        return opportunityClient.execute(UPDATEDROWSCOUNT)
                .bind(ColumnNames.OPPORTUNITYTYPE.getColumnName(), opportunityType.getValue())
                .bind(ColumnNames.JOBNAME.getColumnName(), jobName)
                .map((row, rowMetadata) -> {
                    Map<String,Long> updatedRowsCountMap = new ConcurrentHashMap<>();
                    updatedRowsCountMap.put(RuleConstants.PROVIDERGROUPOPPORTUNITIESSUMMARY,row.get(ColumnNames.SUMMERY.getColumnName(), Long.class));
                    updatedRowsCountMap.put(RuleConstants.PROVIDERGROUPOPPORTUNITIESDETAIL,row.get(ColumnNames.DETAIL.getColumnName(), Long.class));
                    updatedRowsCountMap.put(RuleConstants.MEMBERASSESSMENTOPPORTUNITY,row.get(ColumnNames.MEMBERASSESSMENTOPPORTUNITY.getColumnName(), Long.class));
                    return updatedRowsCountMap;
                })
                .one();
    }
}
