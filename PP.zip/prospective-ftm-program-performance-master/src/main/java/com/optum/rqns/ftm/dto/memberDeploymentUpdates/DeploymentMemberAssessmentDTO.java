package com.optum.rqns.ftm.dto.memberDeploymentUpdates;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.time.LocalDate;
import java.util.Date;

@AllArgsConstructor
@Data
@ToString
@Builder
@NoArgsConstructor
public class DeploymentMemberAssessmentDTO {
    String providerGroupId;
    String providerState;
    String providerId;
    String clientId;
    String lobName;
    int programYear;
    String globalMemberId;
    String isAssociated;
    String isDeployed;
    String validationStatus;
    LocalDate associationValidFrom;
    LocalDate associationValidTo;
}