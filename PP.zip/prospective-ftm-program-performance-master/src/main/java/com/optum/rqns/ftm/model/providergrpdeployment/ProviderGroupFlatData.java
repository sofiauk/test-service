package com.optum.rqns.ftm.model.providergrpdeployment;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class ProviderGroupFlatData {
    private String providerGroupID;
    private String providerGroupName;
    private String state;
    private int programYear;
    private String clientId;
    private String clientName;
    private String lob;
    private String distributionChannel;
    private String retrievalChannel;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime lastReturnDate;
    private int deploymentsCount;
    private int returnsCount;
    private int returnsNetCNACount;

}

