package com.optum.rqns.ftm.controller.qfo;

import com.optum.rqns.ftm.constants.FTMHeaders;
import com.optum.rqns.ftm.customannotation.CustomApiResponse;
import com.optum.rqns.ftm.dto.qfo.StarRatingDTO;
import com.optum.rqns.ftm.dto.qfo.SuspectConditionTotalsDTO;
import com.optum.rqns.ftm.enums.TypeEnum;
import com.optum.rqns.ftm.model.UserInfo;
import com.optum.rqns.ftm.model.qfo.QFOGroupStarRating;
import com.optum.rqns.ftm.model.qfo.QFOPatientsCovered;
import com.optum.rqns.ftm.model.qfo.Rating;
import com.optum.rqns.ftm.response.ListResponse;
import com.optum.rqns.ftm.response.performance.providergrp.qfo.ProviderGroupPerformanceDetailsByYearResponse;
import com.optum.rqns.ftm.response.performance.providergrp.qfo.ProviderGroupPerformanceDetailsResponse;
import com.optum.rqns.ftm.response.qfo.PatientExpResponse;
import com.optum.rqns.ftm.response.qfo.QFOGroupStarRatingResponse;
import com.optum.rqns.ftm.response.qfo.QFOPatientsCoveredResponse;
import com.optum.rqns.ftm.service.qfo.PatientExpScoreService;
import com.optum.rqns.ftm.service.qfo.ProviderGroupPerformanceDetailsService;
import com.optum.rqns.ftm.util.StargateStandardResponseUtilV2;
import com.optum.rqns.ftm.util.UserInfoUtil;
import com.optum.rqns.ftm.wrapper.SingleResponseWrapper;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

@Profile("rqnsFtmApi")
@RestController
@RequestMapping("/v1/qfo/provider-groups")
@Slf4j
@CustomApiResponse
public class ProviderGroupPerformanceDetailsController {

    @Autowired
    StargateStandardResponseUtilV2<Object, Object> stargateStandardResponseUtilV2;

    @Autowired
    ProviderGroupPerformanceDetailsService providerGroupPerformanceDetailsService;

    @Autowired
    PatientExpScoreService patientExpScoreService;

    @GetMapping("{provider-group-id}/qfo-performances")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = ProviderGroupPerformanceDetailsResponse.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<ProviderGroupPerformanceDetailsResponse> getQfoProviderGroupPerformance(
            @PathVariable("provider-group-id") String providerGroupId,
            @RequestParam("program-year") int programYear
    ) {
        log.info("Getting Qfo Provider Group Performance Details for the Given Details: {}, {}", providerGroupId, programYear);

        return stargateStandardResponseUtilV2
                .generateStargateStandardResponse(
                        providerGroupPerformanceDetailsService.getPerformanceDetails(providerGroupId, programYear)
                        , TypeEnum.MONO
                        , new ProviderGroupPerformanceDetailsResponse())
                .cast(ProviderGroupPerformanceDetailsResponse.class);
    }

    @GetMapping("{provider-group-id}/qfo-performances-by-year")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = ProviderGroupPerformanceDetailsResponse.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<ProviderGroupPerformanceDetailsByYearResponse> getProviderGroupPerformanceByYear(
            @PathVariable("provider-group-id") String providerGroupId,
            @RequestParam("program-year") int programYear
    ) {
        log.info("Getting Qfo Provider Group Performance Details for the Given Details: {}, {}", providerGroupId, programYear);

        return stargateStandardResponseUtilV2
                .generateStargateStandardResponse(
                        providerGroupPerformanceDetailsService.getPerformanceDetailsByYear(providerGroupId, programYear)
                        , TypeEnum.FLUX
                        , new ProviderGroupPerformanceDetailsByYearResponse())
                .cast(ProviderGroupPerformanceDetailsByYearResponse.class);
    }

    @GetMapping("{group-id}/qfo-patient-exp-scores")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = PatientExpResponse.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<PatientExpResponse> getPatienceExperienceData(
        @PathVariable("group-id") String groupId,
        @RequestParam("program-year") int programYear,
        @RequestParam("health-org-id-type") String healthOrgIdType
    ){
        log.info("Getting Qfo PatientExperience Score for the Given Group Id: {}, {}", groupId, programYear);
        return stargateStandardResponseUtilV2
                .generateStargateStandardResponse(
                        patientExpScoreService.getPatientExpScoreDetails(groupId,programYear,healthOrgIdType)
                        , TypeEnum.FLUX
                        , new PatientExpResponse())
                .cast(PatientExpResponse.class);
    }

    @GetMapping("overall-rating")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = PatientExpResponse.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<SingleResponseWrapper<Rating>> getOverallRatingsByUUID(
            @RequestHeader(value = FTMHeaders.X_USER_DETAILS) String userDetailsJson,
            @RequestParam("program-year") int programYear) {
        UserInfo userInfo = UserInfoUtil.parseUserInfo(userDetailsJson);
        String uuid = userInfo.getUuid();

        log.info("Getting overall qfo ratings for uuid: {}, programYear: {}", uuid, programYear);
        return patientExpScoreService
                .getOverallRatingByUUID(uuid, programYear)
                .flatMap(t -> Mono.just(new SingleResponseWrapper<>(t)));
    }

    @GetMapping("group-star-ratings/{program-year}/{rating}")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = QFOGroupStarRatingResponse.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<SingleResponseWrapper<QFOGroupStarRating>> getGroupsStarRatingDetails(
            @RequestHeader(value = FTMHeaders.X_USER_DETAILS) String userDetailsJson,
            @PathVariable("program-year") int programYear,
            @PathVariable("rating") int rating) {

        UserInfo userInfo = UserInfoUtil.parseUserInfo(userDetailsJson);
        String uuid = userInfo.getUuid();

        log.info("Getting QFO Group Star Rating details for uuid: {} and program-year: {}", uuid, programYear);
        return providerGroupPerformanceDetailsService
                .getGroupsStarRatingDetails(uuid, programYear, rating)
                .flatMap(t -> Mono.just(new SingleResponseWrapper<>(t)));
    }

    @GetMapping("patients-covered/{program-year}")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = QFOPatientsCoveredResponse.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<SingleResponseWrapper<QFOPatientsCovered>> getPatientsCoveredDetails(
            @RequestHeader(value = FTMHeaders.X_USER_DETAILS) String userDetailsJson,
            @PathVariable("program-year") int programYear) {

        UserInfo userInfo = UserInfoUtil.parseUserInfo(userDetailsJson);
        String uuid = userInfo.getUuid();

        log.info("Getting QFO Patients Covered details for uuid: {} and program-year: {}", uuid, programYear);
        return providerGroupPerformanceDetailsService
                .getPatientsCoveredDetails(uuid, programYear)
                .flatMap(t -> Mono.just(new SingleResponseWrapper<>(t)));
    }

    @GetMapping("suspect-conditions")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = PatientExpResponse.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<ListResponse> getQFOSuspectConditions(
            @RequestHeader(value = FTMHeaders.X_USER_DETAILS) String userDetailsJson,
            @RequestParam("program-year") int programYear) {
        UserInfo userInfo = UserInfoUtil.parseUserInfo(userDetailsJson);
        String uuid = userInfo.getUuid();

        log.info("Getting qfo suspect conditions for uuid: {}, programYear: {}", uuid, programYear);

        return stargateStandardResponseUtilV2
                .generateStargateStandardResponse(
                        providerGroupPerformanceDetailsService.getQFOSuspectConditions(uuid, programYear)
                        , TypeEnum.MONO
                        , new ListResponse())
                .cast(ListResponse.class);
    }

    @GetMapping("star-ratings")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = StarRatingDTO.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<ListResponse<StarRatingDTO>> getStarRatings(
            @RequestHeader(value = FTMHeaders.X_USER_DETAILS) String userDetailsJson,
            @RequestParam("program-year") int programYear) {
        UserInfo userInfo = UserInfoUtil.parseUserInfo(userDetailsJson);
        String uuid = userInfo.getUuid();

        log.info("Getting star ratings for uuid: {}, programYear: {}", uuid, programYear);

        return stargateStandardResponseUtilV2
                .generateStargateStandardResponse(
                        providerGroupPerformanceDetailsService.getStarRatingsByUUID(uuid, programYear)
                        , TypeEnum.FLUX
                        , new ListResponse<StarRatingDTO>())
                .cast(ListResponse.class).map(l -> (ListResponse<StarRatingDTO>) l);
    }

    @GetMapping("suspect-condition-totals")
    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = SuspectConditionTotalsDTO.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    public Mono<ListResponse<SuspectConditionTotalsDTO>> getSuspectConditionTotals(
            @RequestHeader(value = FTMHeaders.X_USER_DETAILS) String userDetailsJson,
            @RequestParam("program-year") int programYear) {
        UserInfo userInfo = UserInfoUtil.parseUserInfo(userDetailsJson);
        String uuid = userInfo.getUuid();

        log.info("Getting suspect condition totals for uuid: {}, programYear: {}", uuid, programYear);

        return stargateStandardResponseUtilV2
                .generateStargateStandardResponse(
                        providerGroupPerformanceDetailsService.getSuspectConditionTotalsByUUID(uuid, programYear)
                        , TypeEnum.FLUX
                        , new ListResponse<>())
                .cast(ListResponse.class).map(l -> (ListResponse<SuspectConditionTotalsDTO>) l);
    }
}
