package com.optum.rqns.ftm.configuration;

import com.optum.rqns.ftm.constants.JobConfigurationConstants;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.avro.models.v1.opportunities.ProviderGroupOpportunitiesSummary;
import com.optum.rqns.ftm.kafka.avro.models.v1.program.performance.provider.ProgPerfProviderMSSync;
import io.confluent.kafka.serializers.AbstractKafkaSchemaSerDeConfig;
import io.confluent.kafka.serializers.KafkaAvroDeserializer;
import io.confluent.kafka.serializers.KafkaAvroDeserializerConfig;
import io.confluent.kafka.serializers.KafkaAvroSerializer;
import io.confluent.kafka.serializers.subject.TopicNameStrategy;
import org.apache.commons.lang3.StringUtils;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.Deserializer;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.apache.logging.log4j.core.util.UuidUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.config.KafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.listener.ConcurrentMessageListenerContainer;

import java.util.HashMap;
import java.util.Map;

import static org.springframework.kafka.listener.ContainerProperties.AckMode.MANUAL;

@Configuration
public class KafkaConfiguration {

    @Autowired
    private KafkaProperties kafkaProperties;

//    @Bean
//    public KafkaTemplate<String, JobEvent> jobEventKafkaTemplate() {
//        return new KafkaTemplate<>(producerFactory());
//    }

    @Bean
    public KafkaTemplate<String, ProviderGroupOpportunitiesSummary> opportunitySummaryKafkaTemplate() {
        return new KafkaTemplate<>(producerFactory());
    }

//    @Bean
//    public KafkaTemplate<String, ProgPerfProviderMSSync> opportunitySummaryKafkaTemplateV1() {
//        return new KafkaTemplate<>(producerFactory());
//    }

    public static final String APPLICATION_PREFIX = "FTM";//OFC
    public static final String APPLICATION_HOST_DATA_CENTER = "ENV_DATACENTRE";
    public static final String APPLICATION_ENVIRONMENT = "ENV_PROFILES_ACTIVE";


    private <K, V> ProducerFactory<K, V> producerFactory() {
        Map<String, Object> producerProps = kafkaProperties.buildProducerProperties();

        producerProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        producerProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, KafkaAvroSerializer.class);
        producerProps.put(ProducerConfig.ACKS_CONFIG, "all");
        producerProps.put(ProducerConfig.RETRIES_CONFIG, Integer.MAX_VALUE);
        producerProps.put(ProducerConfig.DELIVERY_TIMEOUT_MS_CONFIG, Integer.MAX_VALUE);
        producerProps.put(ProducerConfig.LINGER_MS_CONFIG, JobConfigurationConstants.LINGER_MS_CONFIG);
        producerProps.put(ProducerConfig.REQUEST_TIMEOUT_MS_CONFIG,JobConfigurationConstants.REQUEST_TIMEOUT_MS_CONFIG);

        DefaultKafkaProducerFactory<K, V> defaultKafkaProducerFactory = new DefaultKafkaProducerFactory<>(producerProps);

        return defaultKafkaProducerFactory;
    }

//    @Bean
//    public KafkaListenerContainerFactory<ConcurrentMessageListenerContainer<String, Object>> jobEventKafkaListenerContainerFactory() {
//
//        return createContainerFactory(kafkaProperties.getProperties().get("topics.jobEvent"), new StringDeserializer(), new KafkaAvroDeserializer(), false);
//    }

    private <K, V> KafkaListenerContainerFactory<ConcurrentMessageListenerContainer<K, V>> createContainerFactory(String topicName,
                                                                                                                  Deserializer<K> keyDeserializer,
                                                                                                                  Deserializer<V> valueDeserializer,
                                                                                                                  boolean isBatchListener) {
        Map<String, Object> deserializerProps = new HashMap<>();
        deserializerProps.put(AbstractKafkaSchemaSerDeConfig.SCHEMA_REGISTRY_URL_CONFIG, kafkaProperties.getProperties()
                .get(AbstractKafkaSchemaSerDeConfig.SCHEMA_REGISTRY_URL_CONFIG));
        deserializerProps.put(AbstractKafkaSchemaSerDeConfig.VALUE_SUBJECT_NAME_STRATEGY, TopicNameStrategy.class);
        deserializerProps.put(KafkaAvroDeserializerConfig.SPECIFIC_AVRO_READER_CONFIG, Boolean.TRUE);

        keyDeserializer.configure(deserializerProps, true);
        valueDeserializer.configure(deserializerProps, false);

        Map<String, Object> consumerProps = kafkaProperties.buildConsumerProperties();

        consumerProps.put(ConsumerConfig.CLIENT_ID_CONFIG, kafkaProperties.getClientId() + "_" + UuidUtil.getTimeBasedUuid().toString());
        consumerProps.put (ConsumerConfig.GROUP_ID_CONFIG, getConsumerGroupId (topicName));
        consumerProps.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false);
        consumerProps.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "latest");
        consumerProps.put(ConsumerConfig.ALLOW_AUTO_CREATE_TOPICS_CONFIG, false);

        consumerProps.put(ConsumerConfig.MAX_POLL_INTERVAL_MS_CONFIG, Integer.MAX_VALUE);

        consumerProps.put(ConsumerConfig.FETCH_MIN_BYTES_CONFIG, 1_000);
        consumerProps.put(ConsumerConfig.FETCH_MAX_WAIT_MS_CONFIG, 2_000);

        consumerProps.put(ConsumerConfig.HEARTBEAT_INTERVAL_MS_CONFIG, 60_000);
        consumerProps.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, 180_000);
        consumerProps.put(ConsumerConfig.REQUEST_TIMEOUT_MS_CONFIG, 10_000);


        ConsumerFactory consumerFactory = new DefaultKafkaConsumerFactory<>(
                consumerProps,
                keyDeserializer,
                valueDeserializer);

        ConcurrentKafkaListenerContainerFactory<K, V> factory = new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(consumerFactory);
        factory.setBatchListener(isBatchListener);
        factory.setAutoStartup(true);
        factory.getContainerProperties().setAckMode(MANUAL);
        factory.setConcurrency(1);
        factory.getContainerProperties().setSyncCommits(true);
        factory.getContainerProperties().setPollTimeout(5_000L);

        return factory;
    }

    private String getConsumerGroupId(String topicName) {
        String hostedDataCenter = System.getenv (APPLICATION_HOST_DATA_CENTER);
        if (StringUtils.isEmpty (hostedDataCenter))
            hostedDataCenter = "DC_Unknown";
        String applicationEnvironment = System.getenv (APPLICATION_ENVIRONMENT);
        if (StringUtils.isEmpty (applicationEnvironment))
            applicationEnvironment = "ENV_Unknown";
        String consumerGroupId = String.format ("%s_%s_%s_%s", APPLICATION_PREFIX, topicName, applicationEnvironment, hostedDataCenter);

        return consumerGroupId;
    }


}
