package com.optum.rqns.ftm.dto.job_configuration.converter;

import com.optum.rqns.ftm.constants.JobConfigurationConstants;
import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.dto.job_configuration.JobConfigurationDTO;
import com.optum.rqns.ftm.dto.job_configuration.JobExecutionHistoryDTO;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;

import java.time.LocalDateTime;



public class JobConfigurationConverter extends JobConfigurationConverterHelper implements Converter<Row, JobConfigurationDTO>, DTOWrapperTypeConverter {

    @Override
    public JobConfigurationDTO convert(Row row) {
        return JobConfigurationDTO.builder()
                .jobID(row.get(JobConfigurationConstants.JOB_ID,Integer.class))
                .jobName(getJobName(row))
                .jobDescription(row.get(JobConfigurationConstants.JOB_DESCRIPTION,String.class))
                .createdBy(row.get(JobConfigurationConstants.CREATED_BY,String.class))
                .createdDate(row.get(JobConfigurationConstants.CREATED_DATE, LocalDateTime.class))
                .modifiedBy(row.get(JobConfigurationConstants.MODIFIED_BY,String.class))
                .modifiedDate(row.get(JobConfigurationConstants.MODIFIED_DATE,LocalDateTime.class))
                .lastSuccessfulRunDate(row.get(JobConfigurationConstants.LAST_SUCCESSFUL_RUN_DATE,LocalDateTime.class))
                .errorMessage(row.get(JobConfigurationConstants.ERROR_MESSAGE,String.class))
                .messageKey(row.get(JobConfigurationConstants.MESSAGE_KEY,String.class))
                .message(row.get(JobConfigurationConstants.MESSAGE,String.class))
                .jobEvent(row.get(JobConfigurationConstants.JOB_EVENT,String.class))
                .isActive(row.get(JobConfigurationConstants.IS_ACTIVE,Boolean.class))
                .jobExecutionHistory(convertJobExecutionHistory(row))
                .build();
    }

    private JobExecutionHistoryDTO convertJobExecutionHistory(Row row) {
        return JobExecutionHistoryDTO.builder()
                .jobID(row.get(JobConfigurationConstants.JOB_ID,Integer.class))
                .id(row.get(JobConfigurationConstants.ID,Integer.class))
                .status(getStatus(row))
                .jobStart(row.get(JobConfigurationConstants.JOB_START,LocalDateTime.class))
                .jobEnd(row.get(JobConfigurationConstants.JOB_END,LocalDateTime.class))
                .errorMessage(row.get(JobConfigurationConstants.ERROR_MESSAGE,String.class))
                .affectedRows(row.get(JobConfigurationConstants.AFFECTED_ROWS,Integer.class))
                .messageKey(row.get(JobConfigurationConstants.MESSAGE_KEY,String.class))
                .message(row.get(JobConfigurationConstants.MESSAGE,String.class))
                .jobEvent(row.get(JobConfigurationConstants.JOB_EVENT,String.class))
                .build();
    }
}
