package com.optum.rqns.ftm.model.practiceassist.providerdashboard;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ProviderDashboardResponse {
    private int a1CCount;
    private int oMWCount;
    private int annualCareVisitNotCompleteCount;
    private int noCurrFluVaccCount;
    private int newPatient7Count;
    private int newPatient30Count;
    private int newPatient90Count;
    private int highPriorityCount;
    private int absFailDateCount;
    private int rxFillOppurtunityCount;
}
