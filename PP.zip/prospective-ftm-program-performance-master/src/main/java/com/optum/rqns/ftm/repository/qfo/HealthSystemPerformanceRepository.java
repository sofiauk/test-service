package com.optum.rqns.ftm.repository.qfo;

import com.optum.rqns.ftm.dto.qfo.performance.healthSystem.QFOHealthSystemPerformanceDetailsDTO;
import reactor.core.publisher.Flux;

import com.optum.rqns.ftm.dto.qfo.performance.healthSystem.HealthSystemPerformanceDetailsDTO;

import reactor.core.publisher.Mono;

public interface HealthSystemPerformanceRepository {

    Flux<QFOHealthSystemPerformanceDetailsDTO> getHealthSystemPerformanceDetailsByYear(String healthSystemId, int programYear);

	Mono<HealthSystemPerformanceDetailsDTO> getPerformanceDetails(String healthSystemId, int programYear);

}
