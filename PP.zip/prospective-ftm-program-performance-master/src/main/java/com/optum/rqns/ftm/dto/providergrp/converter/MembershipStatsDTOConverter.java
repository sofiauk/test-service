package com.optum.rqns.ftm.dto.providergrp.converter;

import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.dto.providergrp.MembershipStatsIhaIoaDTO;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;

import java.time.LocalDateTime;

public class MembershipStatsDTOConverter implements Converter<Row, MembershipStatsIhaIoaDTO>, DTOWrapperTypeConverter {

    @Override
    public MembershipStatsIhaIoaDTO convert(Row rs) {

        return MembershipStatsIhaIoaDTO.builder ()
                .providerGroupId (rs.get ("ProviderGroupID", String.class))
                .providerState (rs.get ("State", String.class))
                .programYear (rs.get ("ProgramYear", Integer.class))
                .ihaOnlyCount (rs.get ("IHAOnlyCount", Integer.class))
                .ioaOnlyCount (rs.get ("IOAOnlyCount", Integer.class))
                .bothIhaIoaCount (rs.get ("BothIHAIOACount", Integer.class))
                .membershipChangeCount (rs.get ("MemberChangeCount", Integer.class))
                .latestMembershipChangeDate (getValue (rs, "LatestMemberMoveDate", LocalDateTime.class))
                .build ();
    }
}
