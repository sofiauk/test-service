package com.optum.rqns.ftm.repository.memberAssessmentHistory;

import com.optum.rqns.ftm.dto.memberassessment.MemberAssessmentHistory;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;

@Repository
@Slf4j
public class MemberAssessmentHistoryRepositoryImpl implements MemberAssessmentHistoryRepository {

    private final DatabaseClient databaseClient;

    public MemberAssessmentHistoryRepositoryImpl(DatabaseClient databaseClient) {
        this.databaseClient = databaseClient;
    }

    @AllArgsConstructor
    @Getter
    public enum ColumnNames {
        PROVIDER_GROUP_ID("prov_group_id"),
        PROVIDER_STATE("providerstate"),
        OVERALL_STATUS("overall_status"),
        PROJECT_YEAR("project_year");

        private String columnName;
    }

    private static final String MEMBER_ASSESSMENT_HISTORY_QUERY = "SELECT prov_group_id, providerstate, overall_status, project_year from ProgPerf.MemberAssessmentHistory " +
            "WHERE prov_group_id in (%s) " +
            "AND project_year = ((select mc.value from ProgPerf.MasterConfiguration mc WITH (NOLOCK) where mc.code='CurrentProgramYear') - 1)";

    @Override
    public Flux<MemberAssessmentHistory> getMemberAssessmentHistoryDetails(String providerGroupIds) {
        log.debug("Received getMemberAssessmentHistoryDetails request {}", "Received ProviderGroups");
        String query = String.format(MEMBER_ASSESSMENT_HISTORY_QUERY, providerGroupIds);
        return databaseClient.execute(query)
                .as(MemberAssessmentHistory.class)
                .fetch()
                .all();
    }

}
