package com.optum.rqns.ftm.repository.opportunities.providergrp;

import com.optum.rqns.ftm.dto.opportunities.providergrp.MeasuresThresholdConfigurationDTO;
import com.optum.rqns.ftm.dto.opportunities.providergrp.MemberACVDTO;
import com.optum.rqns.ftm.dto.opportunities.providergrp.MemberAssessmentDTO;
import com.optum.rqns.ftm.dto.opportunities.providergrp.MemberQualityGapDTO;
import com.optum.rqns.ftm.dto.opportunities.providergrp.MemberSuspectConditionDTO;
import com.optum.rqns.ftm.dto.opportunities.providergrp.MemberSuspectPatientsDTO;
import com.optum.rqns.ftm.dto.opportunities.providergrp.OpportunitiesDetailsDTO;
import com.optum.rqns.ftm.dto.opportunities.providergrp.OpportunityConfigurationDTO;
import com.optum.rqns.ftm.model.opportunities.providergrp.ClientsFilterDetails;
import com.optum.rqns.ftm.model.opportunities.providergrp.DetailsRequestBody;
import com.optum.rqns.ftm.model.opportunities.providergrp.LobFilterDetails;
import com.optum.rqns.ftm.model.opportunities.providergrp.MemberAssessment;
import com.optum.rqns.ftm.model.opportunities.providergrp.MemberAssessmentClients;
import com.optum.rqns.ftm.model.opportunities.providergrp.MemberAssessmentLobs;
import com.optum.rqns.ftm.model.opportunities.providergrp.MemberAssessmentOpportunitySubTypes;
import com.optum.rqns.ftm.model.opportunities.providergrp.MemberAssessmentProgramYears;
import com.optum.rqns.ftm.model.opportunities.providergrp.OpportunitiesDetails;
import com.optum.rqns.ftm.model.opportunities.providergrp.OpportunitiesSummaryDetails;
import com.optum.rqns.ftm.model.opportunities.providergrp.PAConfigDetails;
import com.optum.rqns.ftm.model.opportunities.providergrp.ProviderGroupMemberGaps;
import com.optum.rqns.ftm.model.opportunities.providergrp.ClientsRequestBody;
import com.optum.rqns.ftm.model.opportunities.providergrp.QFOHealthSystemDetailsRequestBody;
import com.optum.rqns.ftm.model.opportunities.providergrp.QFOHealthSystemOpportunitiesDetails;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Map;
import java.util.Set;

public interface OpportunitiesRepository {


    Flux<MemberAssessmentDTO> getMemberAssessments(MemberAssessment memberAssessment,boolean enablePagination,boolean offshoreRestricted);

    Mono<Long> getMemberAssessmentsCounts(MemberAssessment memberAssessment,boolean offshoreRestricted);

    Flux<ProviderGroupMemberGaps> getMemberGaps(MemberAssessment memberAssessment,boolean enablePagination, boolean offshoreRestricted);

    Mono<Long> getMemberAssessmentsGapCounts(MemberAssessment memberAssessment, boolean offshoreRestricted);

    Flux<OpportunitiesSummaryDetails> getOpportunitiesSummary(String providerGroupId, String state, String serviceLevel, int programYear);

    Flux<OpportunitiesDetailsDTO> getOpportunitiesDetails(String providerGroupId, String state, String serviceLevel, String programYear);

    Flux<MemberAssessmentOpportunitySubTypes> getMemberAssessmentOpportunitySubTypes(String providerGroupId, String state, String type, String serviceLevel,int programYear);

    Flux<MemberAssessmentProgramYears> getMemberAssessmentProgramYears(String providerGroupId, String state, String type, String serviceLevel);

    Flux<MemberAssessmentLobs> getMemberAssessmentLobs(String providerGroupId, String state, String type, String serviceLevel, boolean offshoreRestricted, int programYear);

    Flux<MemberAssessmentClients> getMemberAssessmentClients(String providerGroupId, String state, String type, String serviceLevel, int programYear);

    Flux<String> getMemberGapAssessmentOpportunitySubTypes(String providerGroupId, String state, String type,int programYear);

    Flux<Integer> getMemberGapAssessmentProgramYears(String providerGroupId, String state, String type);

    Flux<String> getMemberGapAssessmentLobs(String providerGroupId, String state, String type, boolean offshoreRestricted, int programYear);

    Flux<String> getMemberGapAssessmentClients(String providerGroupId, String state, String type,int programYear);

    Flux<ProviderGroupMemberGaps> getMemberGapsForExport(MemberAssessment memberAssessment,boolean enablePagination, boolean isOffsetChangeNeeded,boolean offshoreRestricted);

    Flux<OpportunitiesDetails> getRiskQualityOpportunitiesDetails(DetailsRequestBody detailsRequestBody);

    Flux<ClientsFilterDetails> getRiskQualityOpportunitiesClientDetails(ClientsRequestBody clientsRequestBody);

    Flux<LobFilterDetails> getRiskQualityOpportunitiesLobDetails(ClientsRequestBody clientsRequestBody);

    Flux<OpportunityConfigurationDTO> getAllOpportunitiesConfigurationsByMasterOpportunityName(String masterOpportunityName, Integer programYear,String teamType);

    Flux<OpportunityConfigurationDTO> getOpportunitiesConfigurationsByMasterOpportunityNameAndOpportunities(String masterOpportunityName, Set<String> opportunities, Integer programYear,String teamType);

    Flux<MemberQualityGapDTO> getMemberQualityGapDetailsByOpportunity(OpportunityConfigurationDTO opportunityConfigurationDTO, MemberAssessment memberAssessment, String memberIndicatorValues,boolean excludeRecords);

    Mono<String> getMemberIndicator(String name);

    Flux<MeasuresThresholdConfigurationDTO> getStarThreshold(String teamType, int programYear);

    Flux<String> getMinEligibleMembersCount();

    Flux<MemberSuspectConditionDTO> getMemberSuspectConditionDetailsByOpportunity(OpportunityConfigurationDTO opportunityConfigurationDTO, MemberAssessment memberAssessment, Map<String,String> masterConfigValues,boolean excludeRecords);
    Flux<MemberACVDTO> getACVNotCompleted(OpportunityConfigurationDTO opportunityConfigurationDTO, MemberAssessment memberAssessment, String memberIndicatorValues,boolean excludeRecords);
    Flux<MemberSuspectPatientsDTO> getMemberNotFullyAssessedDetails(OpportunityConfigurationDTO opportunityConfigurationDTO, MemberAssessment memberAssessment, Map<String,String> masterConfigValues,boolean excludeRecords);

    Flux<String> getQualityGapOpportunitiesDetailsByCount( MemberAssessment memberAssessment);

    Mono<Map<String, String>> getMasterConfigurationValues();

    Flux<ClientsFilterDetails> getIhaIoaClientList(ClientsRequestBody clientsRequestBody);

    Flux<LobFilterDetails> getIhaIoaLobList(ClientsRequestBody clientsRequestBody);

    Flux<QFOHealthSystemOpportunitiesDetails> getQFOHealthSystemRiskQualityOpportunitiesDetails(QFOHealthSystemDetailsRequestBody qfoHealthSystemDetailsRequestBody);

    Flux<PAConfigDetails> getOFCPAMasterConfigurationValues();

}

