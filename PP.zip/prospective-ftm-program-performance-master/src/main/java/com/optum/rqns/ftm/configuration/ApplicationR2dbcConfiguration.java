package com.optum.rqns.ftm.configuration;


import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import com.optum.rqns.ftm.dto.opportunities.providergrp.converter.QFOHealthSystemOpportunitiesDetailsConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.convert.converter.Converter;
import org.springframework.core.env.Environment;
import org.springframework.data.r2dbc.config.AbstractR2dbcConfiguration;
import org.springframework.data.r2dbc.connectionfactory.R2dbcTransactionManager;
import org.springframework.data.r2dbc.convert.R2dbcCustomConversions;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.transaction.ReactiveTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.optum.rqns.ftm.dto.commandcenter.converter.ProviderGroupClientMemberCountDTOConverter;
import com.optum.rqns.ftm.dto.export.converter.ExportDTOConverter;
import com.optum.rqns.ftm.dto.export.converter.ExportNotificationDTOConverter;
import com.optum.rqns.ftm.dto.export.converter.ExportTransactionConverter;
import com.optum.rqns.ftm.dto.goals.client.converter.ClientGoalsAggregateDTOConverter;
import com.optum.rqns.ftm.dto.goals.client.converter.ClientGoalsLobDTODeployConverter;
import com.optum.rqns.ftm.dto.goals.client.converter.ClientGoalsLobDTOGADVConverter;
import com.optum.rqns.ftm.dto.goals.client.converter.ClientGoalsSnapshotDTOConverter;
import com.optum.rqns.ftm.dto.goals.client.converter.ClientLobRegionGoalConverter;
import com.optum.rqns.ftm.dto.goals.client.converter.LobClientConverter;
import com.optum.rqns.ftm.dto.goals.client.converter.RegionConverter;
import com.optum.rqns.ftm.dto.job_configuration.converter.CategoryUpdateDateConverter;
import com.optum.rqns.ftm.dto.job_configuration.converter.JobConfigurationConverter;
import com.optum.rqns.ftm.dto.job_configuration.converter.PafOverAllStatusDetailDTOConverter;
import com.optum.rqns.ftm.dto.jobalerts.converter.JobAlertConverter;
import com.optum.rqns.ftm.dto.memberDeploymentUpdates.converter.DeploymentMemberAssessmentDTOConverter;
import com.optum.rqns.ftm.dto.memberassessment.converter.MemberAssessmentHistoryDTOConverter;
import com.optum.rqns.ftm.dto.opportunities.providergrp.converter.ClientLobFilterDetailsConverter;
import com.optum.rqns.ftm.dto.opportunities.providergrp.converter.LobFilterDetailsConverter;
import com.optum.rqns.ftm.dto.opportunities.providergrp.converter.MemberACVDTOConverter;
import com.optum.rqns.ftm.dto.opportunities.providergrp.converter.MemberAssessmentClientConverter;
import com.optum.rqns.ftm.dto.opportunities.providergrp.converter.MemberAssessmentLobConverter;
import com.optum.rqns.ftm.dto.opportunities.providergrp.converter.MemberAssessmentOpportunitySubTypeConverter;
import com.optum.rqns.ftm.dto.opportunities.providergrp.converter.MemberAssessmentProgramYearConverter;
import com.optum.rqns.ftm.dto.opportunities.providergrp.converter.MemberAssessmentsConverter;
import com.optum.rqns.ftm.dto.opportunities.providergrp.converter.MemberGapConverter;
import com.optum.rqns.ftm.dto.opportunities.providergrp.converter.MemberQualityGapDTOConverter;
import com.optum.rqns.ftm.dto.opportunities.providergrp.converter.MemberSuspectConditionDTOConverter;
import com.optum.rqns.ftm.dto.opportunities.providergrp.converter.MemberSuspectPatientsDTOConverter;
import com.optum.rqns.ftm.dto.opportunities.providergrp.converter.OpportunitiesDetailsConverter;
import com.optum.rqns.ftm.dto.opportunities.providergrp.converter.OpportunitiesDetailsDTOConverter;
import com.optum.rqns.ftm.dto.opportunities.providergrp.converter.PAConfigDetailsDTOConverter;
import com.optum.rqns.ftm.dto.opportunities.providergrp.converter.OpportunitiesSummaryConverter;
import com.optum.rqns.ftm.dto.opportunities.providergrp.converter.OpportunityConfigurationDTOConverter;
import com.optum.rqns.ftm.dto.opportunities.providergrp.converter.QualityRatingsThresholdDTOConverter;
import com.optum.rqns.ftm.dto.qfo.performance.healthSystem.converter.HealthSystemPerformanceDetailsDTOConverter;
import com.optum.rqns.ftm.dto.performance.providergrp.converter.AssignedProviderGroupOpportunitiesConverter;
import com.optum.rqns.ftm.dto.performance.providergrp.converter.ProviderGroupLobPerformanceDTOConverter;
import com.optum.rqns.ftm.dto.performance.providergrp.converter.ProviderGroupsPerformanceDTOConverter;
import com.optum.rqns.ftm.dto.performance.providergrp.converter.qfo.ProviderGroupPerformanceDetailsDTOConverter;
import com.optum.rqns.ftm.dto.qfo.performance.healthSystem.converter.QFOHealthSystemPerformanceDetailsDTOConverter;
import com.optum.rqns.ftm.dto.performance.providergrp.converter.qfo.QFOSuspectConditionsDTOConverter;
import com.optum.rqns.ftm.dto.performance.providergrp.converter.qfo.QFOProviderGroupPerformanceDetailsDTOConverter;
import com.optum.rqns.ftm.dto.processor.providergrp.converter.ProgramYearCalendarDTOConverter;
import com.optum.rqns.ftm.dto.processor.providergrp.converter.ProviderGroupFlatDataConverter;
import com.optum.rqns.ftm.dto.processor.providergrp.converter.ProviderGroupsDeploymentConverter;
import com.optum.rqns.ftm.dto.providergrp.converter.MembershipStatsDTOConverter;
import com.optum.rqns.ftm.dto.providergrp.converter.ProviderGroupDetailsDTOConverter;
import com.optum.rqns.ftm.dto.qfo.converter.PEQuestionConfigurationDTOConverter;
import com.optum.rqns.ftm.dto.qfo.converter.PatientExpScoreDTOConverter;
import com.optum.rqns.ftm.dto.qfo.converter.RatingDTOConverter;
import com.optum.rqns.ftm.dto.qfo.converter.QFOPatientsCoveredDTOConverter;
import com.optum.rqns.ftm.dto.qfo.converter.QFOGroupStarRatingConverter;
import com.optum.rqns.ftm.dto.rules.DeploymentOpportunityInputConverter;
import com.optum.rqns.ftm.dto.rules.FinancialInformationOpportunityInputConverter;
import com.optum.rqns.ftm.dto.rules.MemberAssessmentOpportunityConverter;
import com.optum.rqns.ftm.dto.rules.OutlierOpportunityInputConverter;
import com.optum.rqns.ftm.dto.rules.ProviderGroupDTOConverter;
import com.optum.rqns.ftm.dto.rules.ProviderGroupOpportunitiesDetailsDTOConverter;
import com.optum.rqns.ftm.dto.rules.ProviderGroupOpportunitiesSummaryDTOConverter;
import com.optum.rqns.ftm.dto.rules.ProviderGroupOpportunitiesSummaryDetailDTOConverter;
import com.optum.rqns.ftm.dto.rules.RejectOpportunityInputConverter;
import com.optum.rqns.ftm.dto.rules.ReturnOpportunityInputConverter;
import com.optum.rqns.ftm.dto.rules.SecondarySubmissionOpportunityInputConverter;
import com.optum.rqns.ftm.exception.APIErrorCode;
import com.optum.rqns.ftm.exception.ProgramPerformanceException;

import io.r2dbc.mssql.MssqlConnectionConfiguration;
import io.r2dbc.mssql.MssqlConnectionFactory;
import io.r2dbc.spi.ConnectionFactory;
import lombok.extern.slf4j.Slf4j;

@Configuration
@EnableTransactionManagement
@Slf4j
public class ApplicationR2dbcConfiguration extends AbstractR2dbcConfiguration {

    private Environment env;

    public ApplicationR2dbcConfiguration(Environment env) {
        this.env = env;
    }

    @Override
    @Bean
    public ConnectionFactory connectionFactory() {
        ConnectionFactory configFactory = null;
        try {
            MssqlConnectionConfiguration configuration = MssqlConnectionConfiguration.builder()
                    .host(env.getProperty("spring.datasource.host"))
                    .username(env.getProperty("spring.datasource.username"))
                    .password(env.getProperty("spring.datasource.password"))
                    .database(env.getProperty("spring.datasource.database"))
                    .connectTimeout(Duration.ofHours(1))
                    .build();
            configFactory = new MssqlConnectionFactory(configuration);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            throw new ProgramPerformanceException(HttpStatus.INTERNAL_SERVER_ERROR, APIErrorCode.DB_CONNECTION_EXCEPTION);
        }
        return configFactory;
    }

    @Bean
    @Override
    public R2dbcCustomConversions r2dbcCustomConversions() {

        List<Converter<?, ?>> dtoConverters = new ArrayList<>();
        dtoConverters.add(new ClientGoalsSnapshotDTOConverter());
        dtoConverters.add(new ClientGoalsLobDTODeployConverter());
        dtoConverters.add(new ClientGoalsLobDTOGADVConverter());
        dtoConverters.add(new LobClientConverter());
        dtoConverters.add(new ClientLobRegionGoalConverter());
        dtoConverters.add(new ClientGoalsAggregateDTOConverter());
        dtoConverters.add(new RegionConverter());
        dtoConverters.add(new ProviderGroupLobPerformanceDTOConverter());
        dtoConverters.add(new MemberAssessmentsConverter());
        dtoConverters.add(new MemberGapConverter());
        dtoConverters.add(new OpportunitiesSummaryConverter());
        dtoConverters.add(new OpportunitiesDetailsDTOConverter());
        dtoConverters.add(new QualityRatingsThresholdDTOConverter());
        dtoConverters.add(new ProviderGroupDTOConverter());
        dtoConverters.add(new ReturnOpportunityInputConverter());
        dtoConverters.add(new RejectOpportunityInputConverter());
        dtoConverters.add(new MemberAssessmentOpportunityConverter());
        dtoConverters.add(new MemberAssessmentOpportunitySubTypeConverter());
        dtoConverters.add(new MemberAssessmentProgramYearConverter());
        dtoConverters.add(new MemberAssessmentLobConverter());
        dtoConverters.add(new MemberAssessmentClientConverter());
        dtoConverters.add(new OutlierOpportunityInputConverter());
        dtoConverters.add(new SecondarySubmissionOpportunityInputConverter());
        dtoConverters.add(new ProviderGroupDetailsDTOConverter());
        dtoConverters.add(new com.optum.rqns.ftm.dto.providergrp.converter.ProviderGroupDTOConverter());
        dtoConverters.add(new FinancialInformationOpportunityInputConverter());
        dtoConverters.add(new MemberAssessmentHistoryDTOConverter());
        dtoConverters.add(new AssignedProviderGroupOpportunitiesConverter());
        dtoConverters.add(new ProviderGroupsPerformanceDTOConverter());
        dtoConverters.add(new ProviderGroupOpportunitiesSummaryDTOConverter());
        dtoConverters.add(new ProviderGroupsDeploymentConverter());
        dtoConverters.add(new DeploymentOpportunityInputConverter());
        dtoConverters.add(new ProgramYearCalendarDTOConverter());
        dtoConverters.add(new MembershipStatsDTOConverter());

        //Exports
        dtoConverters.add(new ExportTransactionConverter());
        dtoConverters.add(new ExportDTOConverter());
        dtoConverters.add(new ExportNotificationDTOConverter());
        dtoConverters.add(new MemberQualityGapDTOConverter());
        dtoConverters.add(new OpportunityConfigurationDTOConverter());
        dtoConverters.add(new MemberSuspectConditionDTOConverter());
        dtoConverters.add(new MemberACVDTOConverter());
        dtoConverters.add(new MemberSuspectPatientsDTOConverter());



        //Added JobAlertDTO converter
        dtoConverters.add(new JobAlertConverter());


        //JobConfiguration
        dtoConverters.add(new JobConfigurationConverter());

        dtoConverters.add(new DeploymentMemberAssessmentDTOConverter());
        dtoConverters.add(new PafOverAllStatusDetailDTOConverter());
        dtoConverters.add(new CategoryUpdateDateConverter());
        dtoConverters.add(new ProviderGroupFlatDataConverter());
        dtoConverters.add(new ProviderGroupClientMemberCountDTOConverter());
        dtoConverters.add(new OpportunitiesDetailsConverter());
        dtoConverters.add(new ClientLobFilterDetailsConverter());
        dtoConverters.add(new LobFilterDetailsConverter());
        dtoConverters.add(new ProviderGroupOpportunitiesDetailsDTOConverter());
        dtoConverters.add(new ProviderGroupOpportunitiesSummaryDetailDTOConverter());

        //QFO
        dtoConverters.add(new ProviderGroupPerformanceDetailsDTOConverter());
        dtoConverters.add(new QFOProviderGroupPerformanceDetailsDTOConverter());
        dtoConverters.add(new PEQuestionConfigurationDTOConverter());
        dtoConverters.add(new PatientExpScoreDTOConverter());
        dtoConverters.add(new RatingDTOConverter());
        dtoConverters.add(new HealthSystemPerformanceDetailsDTOConverter());
        dtoConverters.add(new QFOSuspectConditionsDTOConverter());
        dtoConverters.add(new QFOPatientsCoveredDTOConverter());
        dtoConverters.add(new QFOGroupStarRatingConverter());
        dtoConverters.add(new QFOHealthSystemPerformanceDetailsDTOConverter());
        dtoConverters.add(new QFOHealthSystemOpportunitiesDetailsConverter());
        dtoConverters.add(new PAConfigDetailsDTOConverter());

        return new R2dbcCustomConversions(getStoreConversions(), dtoConverters);
    }

    @Bean
    ReactiveTransactionManager transactionManager(ConnectionFactory connectionFactory) {
        return new R2dbcTransactionManager(connectionFactory);
    }

    @Bean
    public ThreadPoolTaskExecutor taskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(5);
        executor.setMaxPoolSize(100);
        executor.setQueueCapacity(100);
        executor.setThreadNamePrefix("PA-");
        executor.initialize();
        return executor;
    }
}

