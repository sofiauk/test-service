package com.optum.rqns.ftm.response.processor.providergrp;

import com.optum.rqns.ftm.dto.job_configuration.PafOverAllStatusDetailDTO;
import com.optum.rqns.ftm.wrapper.Meta;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.ToString;

import java.util.ArrayList;
import java.util.List;

@Data
@ToString
@AllArgsConstructor
@Builder
public class PafOverAllStatusResponse {
    private Meta meta;

    private List<PafOverAllStatusDetailDTO> data;

    public PafOverAllStatusResponse() {
        this.meta = new Meta();
        this.data = new ArrayList<>();
    }
}
