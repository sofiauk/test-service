package com.optum.rqns.ftm.dto.performance.providergrp.converter.qfo;

import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.dto.performance.providergrp.qfo.ProviderGroupPerformanceDetailsDTO;
import com.optum.rqns.ftm.dto.performance.providergrp.qfo.QFOProviderGroupPerformanceDetailsDTO;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class QFOProviderGroupPerformanceDetailsDTOConverter implements Converter<Row, QFOProviderGroupPerformanceDetailsDTO>, DTOWrapperTypeConverter {
    @Override
    public QFOProviderGroupPerformanceDetailsDTO convert(Row row) {
        return QFOProviderGroupPerformanceDetailsDTO.providerGroupPerformanceDetailsBuilder()
                .mapCpiAnnualCareVisits(getPrimitiveLongValue(row, "MapCpiAnnualCareVisits"))
                .mapCpiEligiblePatients(getPrimitiveLongValue(row, "MapCpiEligiblePatients"))
                .mapCpiStarRating(row.get("MapCpiStarRating", BigDecimal.class))
                .mcaipFullyAssessed(getPrimitiveLongValue(row, "McaipPatientsFullyAssessed"))
                .mcaipSuspectMedicalConditions(getPrimitiveLongValue(row, "McaipSuspectMedicalConditions"))
                .overAllStarRating(row.get("OverAllStarRating", BigDecimal.class))
               // .pCpiPartDRating(row.get("MapCpiPartDStarRating", BigDecimal.class))
                .providerGroupId(row.get("ProviderGroupId", String.class))
                .suspectConditionAssessedTotal(getPrimitiveLongValue(row, "SuspectConditionsAssessedTotal"))
                .suspectConditionsTotal(getPrimitiveLongValue(row, "SuspectConditionsTotal"))
                .suspectDiagnosed(getPrimitiveLongValue(row, "SuspectConditionsAssessedDiagnosed"))
                .suspectNotAssessed(getPrimitiveLongValue(row, "SuspectConditionsNotAssessed"))
                .suspectUndiagnosed(getPrimitiveLongValue(row, "SuspectConditionsAssessedUndiagnosed"))
                .totalPatients(getPrimitiveLongValue(row, "TotalPatients"))
                .mcaipTotalPatients(getPrimitiveLongValue(row, "McaipTotalPatients"))
                .updatedDate(row.get("UpdatedDate", LocalDateTime.class))
                .mcaipLastUpdated(row.get("McaipLastUpdated", LocalDateTime.class))
                .mapCpiLastUpdated(row.get("MapCpiLastUpdated", LocalDateTime.class))
                .month(row.get("Month", String.class))
                .maPCPiStarRatingTarget(convertStringToFloat(row,"MA-PCPi_Star_Rating_Target"))
                .overallStarRatingTarget(convertStringToFloat(row,"Overall_Star_Rating_Target"))
                .annualCareVisitsTarget(convertStringToInt(row,"Annual_Care_Visits_Target"))
                .suspectConditionsTarget(convertStringToInt(row,"Suspect_Conditions_Target"))
                .partDStarRatingTarget(convertStringToInt(row,"Part_D_Star_Rating_Target"))
                .assessedAndUnableToDiagnoseTarget(convertStringToInt(row,"Assessed_And_Unable_To_Diagnose_Target"))
                .mapCpiPartDStarRating(row.get("MapCpiPartDStarRating", BigDecimal.class))
                .startDate(row.get("StartDate", LocalDate.class))
                .build();
    }
}
