package com.optum.rqns.ftm.repository.goals.client;

import com.optum.rqns.ftm.dto.goals.client.ClientGoalsAggregateDTO;
import com.optum.rqns.ftm.dto.goals.client.ClientGoalsSnapshotDTO;
import com.optum.rqns.ftm.dto.goals.client.ClientLobRegionGoalValuesDTO;
import com.optum.rqns.ftm.dto.goals.client.LobDTO;
import com.optum.rqns.ftm.dto.goals.client.LobGoalDTO;
import com.optum.rqns.ftm.dto.goals.client.Region;
import com.optum.rqns.ftm.model.goals.client.ClientGoalTypeRequestBody;
import com.optum.rqns.ftm.model.goals.client.RegionGoalTypeRequestBody;
import com.optum.rqns.ftm.model.goals.client.RegionsRequestBody;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import java.time.LocalDateTime;


public interface ClientGoalsReactiveRepository {
    public Flux<Integer> getClientGoalYears();

    public Flux<ClientGoalsSnapshotDTO> clientLobSnapshotValues(int year);

    public Flux<LobGoalDTO> clientAllRegionGoals(long clientId, long lobId, RegionGoalTypeRequestBody regionGoalTypeRequestBody);

    public Flux<LobGoalDTO> clientRegionGoals(long clientId, long lobId, String regionId, RegionGoalTypeRequestBody regionGoalTypeRequestBody);

    public Flux<LocalDateTime> getWeeksInaYear(Integer year);

    public Flux<LobDTO> getLobForClientId(Integer clientId);

    public Flux<ClientLobRegionGoalValuesDTO> getClientLobGoalValues(int clientId, int lobId, ClientGoalTypeRequestBody clientGoalTypeRequestBody);

    Mono<ClientGoalsAggregateDTO> getClientGoalsAggregate(int year);

    /**
     * @deprecated (when, why, refactoring advice...)
     */
    @Deprecated
    Flux<Region> getRegionsForClientId(Integer clientId, Integer lobId, Integer year);

    Flux<Region> getRegionsForRequestType(Integer clientId, Integer lobId, RegionsRequestBody regionsRequestBody);

}
