package com.optum.rqns.ftm.model.opportunities.providergrp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.Set;


@AllArgsConstructor
@NoArgsConstructor
@Data
@ToString
@Builder
public class ClientsRequestBody {
    private String providerGroupId;
    private String healthSystemId;
    private String providerState;
    private int programYear;
    private Set<String> masterOpportunityTypes;
    private String teamType;
    private boolean ioaIhaSection;
}