package com.optum.rqns.ftm.kafka.consumer.events;

import com.optum.rqns.ftm.enums.JobName;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class RedisConsumerFactory {
    @Autowired(required = false)
    WeeklyJobsConsumer weeklyJobsConsumer;
    @Autowired(required = false)
    LOBTargetValuesAndActualsConsumer lobTargetValuesAndActualsConsumer;
    @Autowired(required = false)
    MemberAssessmentConsumer memberAssessmentConsumer;
    @Autowired(required = false)
    DeploymentRulesConsumer deploymentRulesConsumer;
    @Autowired(required = false)
    DerivedDeploymentCountConsumer derivedDeploymentCountConsumer;
    @Autowired(required = false)
    EligibleMemberCountConsumer eligibleMemberCountConsumer;
    @Autowired(required = false)
    LoadHistoricalActualsConsumer loadHistoricalActualsConsumer;
    @Autowired(required = false)
    OutlierRulesConsumer outlierRulesConsumer;
    @Autowired(required = false)
    PaymentRulesConsumer paymentRulesConsumer;
    @Autowired(required = false)
    RejectRulesConsumer rejectRulesConsumer;

    @Autowired(required = false)
    ReturnRulesConsumer returnRulesConsumer;
    @Autowired(required = false)
    SecondarySubmissionRulesConsumer secondarySubmissionRulesConsumer;



    public RedisMessageHandler getInstance(JobName jobName){
        switch (jobName) {
            case RUN_WEEKLY_JOBS:
                return weeklyJobsConsumer;
            case LOAD_LOB_TARGET_VALUES_AND_ACTUALS:
                return lobTargetValuesAndActualsConsumer;
            case LOAD_MEMBER_ASSESSMENT:
                return memberAssessmentConsumer;
            case RUN_DEPLOYMENT_RULES:
                return deploymentRulesConsumer;
            case RUN_DERIVED_DEPLOYMENTS:
                return derivedDeploymentCountConsumer;
            case RUN_ELIGIBLE_MEMBER_COUNT:
                return eligibleMemberCountConsumer;
            case LOAD_HISTORICAL_LOB_TARGET_VALUES_AND_ACTUALS:
                return loadHistoricalActualsConsumer;
            case RUN_OUTLIER_RULES:
                return outlierRulesConsumer;
            case RUN_PAYMENT_RULES:
                return paymentRulesConsumer;
            case RUN_REJECT_RULES:
                return rejectRulesConsumer;
            case RUN_RETURN_RULES:
                return returnRulesConsumer;
            case RUN_SECONDARY_SUBMISSION_RULES:
                return secondarySubmissionRulesConsumer;
            default:
                return null;
        }

    }
}
