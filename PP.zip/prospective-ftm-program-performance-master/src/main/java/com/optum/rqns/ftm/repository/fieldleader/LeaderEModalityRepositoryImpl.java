package com.optum.rqns.ftm.repository.fieldleader;

import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.dto.fieldleader.LeaderEModalityDTO;
import io.r2dbc.spi.ColumnMetadata;
import io.r2dbc.spi.Row;
import io.r2dbc.spi.RowMetadata;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.springframework.data.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;

import java.util.List;

@Repository
public class LeaderEModalityRepositoryImpl implements LeaderEModalityRepository, DTOWrapperTypeConverter {
    private final DatabaseClient client;

    private static final String REGION = "Region";

    LeaderEModalityRepositoryImpl(DatabaseClient client) {
        this.client = client;
    }

    @AllArgsConstructor
    @Getter
    public enum  ColumnNames {
        PROGRAM_YEAR("ProgramYear"),
        REGION_MARKET("RegionMarket"),
        CURRENT_YEAR_OPAF("CurrentYearOpaf"),
        CURRENT_YEAR_OPTUM_UPLOAD("CurrentYearOptumUpload"),
        CURRENT_YEAR_OGM("CurrentYearOgm"),
        CURRENT_YEAR_EDATA("CurrentYearEData"),
        PREVIOUS_YEAR_OPAF("PreviousYearOpaf"),
        PREVIOUS_YEAR_OPTUM_UPLOAD("PreviousYearOptumUpload"),
        PREVIOUS_YEAR_OGM("PreviousYearOgm"),
        PREVIOUS_YEAR_EDATA("PreviousYearEData"),
        UPDATED_DATE("UpdatedDate"),
        FIRST_NAME("FirstName"),
        LAST_NAME("LastName"),
        UUID("UUID"),
        PARENT_UUID("ParentUUID");
        private String columnName;
    }

    @Override
    public Flux<LeaderEModalityDTO> getLeaderEModality(String uuid, int programYear, List<String> clientName, List<String> lob, List<String> serviceLevel) {
        LeaderEModalityQueryBuilder.Builder b = LeaderEModalityQueryBuilder.builder();
        b.asStandard(clientName, lob, serviceLevel);
        return client.execute(b.build())
                .bind(ColumnNames.PROGRAM_YEAR.getColumnName(), programYear)
                .bind(ColumnNames.UUID.getColumnName(), uuid)
                .as(LeaderEModalityDTO.class)
                .map((row, rowMetadata) -> {
                    LeaderEModalityDTO.LeaderEModalityDTOBuilder leaderBuilder =
                            buildCommonLeaderEModalityValues(row);
                    return leaderBuilder.build();
                })
                .all();
    }

    @Override
    public Flux<LeaderEModalityDTO> getLeaderEModalityByRegion(String uuid, int programYear, List<String> clientName, List<String> lob, List<String> serviceLevel, String region) {
        LeaderEModalityQueryBuilder.Builder b = LeaderEModalityQueryBuilder.builder();
        b.asRegion(clientName, lob, serviceLevel);
        return client.execute(b.build())
                .bind(ColumnNames.PROGRAM_YEAR.getColumnName(), programYear)
                .bind(REGION, region)
                .as(LeaderEModalityDTO.class)
                .map((row, rowMetadata) -> {
                    LeaderEModalityDTO.LeaderEModalityDTOBuilder leaderBuilder =
                            buildCommonLeaderEModalityValues(row);
                    return leaderBuilder.build();
                })
                .all();
    }

    @Override
    public Flux<LeaderEModalityDTO> getLeaderEModalityByTeam(String uuid, int programYear, List<String> clientName, List<String> lob, List<String> serviceLevel) {
        LeaderEModalityQueryBuilder.Builder b = LeaderEModalityQueryBuilder.builder();
        b.asTeam(clientName, lob, serviceLevel);
        return client.execute(b.build())
                .bind(ColumnNames.PROGRAM_YEAR.getColumnName(), programYear)
                .bind(ColumnNames.UUID.getColumnName(), uuid)
                .as(LeaderEModalityDTO.class)
                .map((row, rowMetadata) -> {
                    LeaderEModalityDTO.LeaderEModalityDTOBuilder leaderBuilder =
                            buildCommonLeaderEModalityValues(row);
                    return leaderBuilder
                            .firstName(getStringValue(row,"FirstName"))
                            .lastName(getStringValue(row,"LastName"))
                            .uuid(getStringValue(row,"UUID"))
                            .parentUUID(getStringValue(row,"ParentUUID"))
                            .role(getStringValue(row,"Role"))
                            .build();
                })
                .all();
    }

    private LeaderEModalityDTO.LeaderEModalityDTOBuilder buildCommonLeaderEModalityValues(Row row) {
        return LeaderEModalityDTO.builder()
                .regionMarket(getStringValue(row, ColumnNames.REGION_MARKET.getColumnName()))
                .currentYearOpaf(getDoubleValue(row, ColumnNames.CURRENT_YEAR_OPAF.getColumnName()))
                .currentYearOptumUpload(getDoubleValue(row, ColumnNames.CURRENT_YEAR_OPTUM_UPLOAD.getColumnName()))
                .currentYearOgm(getDoubleValue(row, ColumnNames.CURRENT_YEAR_OGM.getColumnName()))
                .currentYearEData(getDoubleValue(row, ColumnNames.CURRENT_YEAR_EDATA.getColumnName()))
                .previousYearOpaf(getDoubleValue(row, ColumnNames.PREVIOUS_YEAR_OPAF.getColumnName()))
                .previousYearOptumUpload(getDoubleValue(row, ColumnNames.PREVIOUS_YEAR_OPTUM_UPLOAD.getColumnName()))
                .previousYearOgm(getDoubleValue(row, ColumnNames.PREVIOUS_YEAR_OGM.getColumnName()))
                .previousYearEData(getDoubleValue(row, ColumnNames.PREVIOUS_YEAR_EDATA.getColumnName()))
                .lastUpdatedDate(getValue(row, ColumnNames.UPDATED_DATE.getColumnName(), java.time.LocalDateTime.class));
    }

    private String getStringValue(Row row, String columnName) {
        return getValue(row, columnName, String.class);
    }
}
