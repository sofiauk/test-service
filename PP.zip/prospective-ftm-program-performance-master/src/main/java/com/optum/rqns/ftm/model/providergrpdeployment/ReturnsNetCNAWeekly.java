package com.optum.rqns.ftm.model.providergrpdeployment;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ReturnsNetCNAWeekly {
    private Integer programYear;
    private LocalDate durationStartDate;
    private LocalDate durationEndDate;
    private String month;
    private Long currentWeekCounts;
    private Float currentWeekGoals;
    private LocalDateTime lastUpdatedDate;
}
