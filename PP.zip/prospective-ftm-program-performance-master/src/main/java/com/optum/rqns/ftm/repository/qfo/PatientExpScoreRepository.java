package com.optum.rqns.ftm.repository.qfo;

import com.optum.rqns.ftm.dto.qfo.PatientExpScoreDTO;
import com.optum.rqns.ftm.dto.qfo.PEQuestionConfigurationDTO;
import com.optum.rqns.ftm.dto.qfo.RatingDTO;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface PatientExpScoreRepository {
    Flux<PEQuestionConfigurationDTO> getQuestionMapping();
    Mono<PatientExpScoreDTO> getPatientExpScoreDetails(String groupId, int programYear,String healthOrgIdType);
    Mono<RatingDTO> getOverallRatingsByUUID(String uuid, int programYear);
}
