package com.optum.rqns.ftm.repository.fieldleader;

import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.model.fieldleader.LeaderPOCConversion;
import com.optum.rqns.ftm.model.programyearcalendar.CurrentPreviousMonth;
import io.r2dbc.spi.Row;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.springframework.data.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;

import java.util.List;

@Repository
public class LeaderGrowthRatePOCEModalityRepositoryImpl implements LeaderGrowthRatePOCEModalityRepository, DTOWrapperTypeConverter {

    private final DatabaseClient client;

    private static final String PROGRAM_YEAR = "ProgramYear";
    private static final String REGION = "Region";
    private static final String PREVIOUS_MONTH = "PreviousMonth";
    private static final String CURRENT_MONTH = "CurrentMonth";
    private static final String UUID = "UUID";

    LeaderGrowthRatePOCEModalityRepositoryImpl(DatabaseClient client) {
        this.client = client;
    }

    @AllArgsConstructor
    @Getter
    public enum  ColumnNames {
        REGION_MARKET("RegionMarket"),
        PREV_NEW("PrevMonthConversionRateNew"),
        CUR_NEW("CurrentMonthConversionRateNew"),
        MOM_CHANGE_NEW("MonthOverMonthChangeNew"),
        PREV_EXIST("PrevMonthConversionRateExisting"),
        CUR_EXIST("CurrentMonthConversionRateExisting"),
        MOM_CHANGE_EXIST("MonthOverMonthChangeExisting"),
        UPDATED_DATE("UpdatedDate"),
        FIRST_NAME("FirstName"),
        LAST_NAME("LastName"),
        UUID("UUID"),
        PARENT_UUID("ParentUUID"),
        ROLE("Role");
        private String columnName;
    }

    @Override
    public Flux<LeaderPOCConversion> getLeaderPOCConversion(int programYear, CurrentPreviousMonth currentPreviousMonth, String uuid, List<String> appliedFilters) {
        LeaderGrowthRatePOCEModalityQueryBuilder.Builder builder = LeaderGrowthRatePOCEModalityQueryBuilder.builder();
        builder.asLeaderPOCConversion(appliedFilters);
        return client.execute(builder.build())
                .bind(PROGRAM_YEAR,programYear)
                .bind(CURRENT_MONTH,currentPreviousMonth.getCurrentMonth())
                .bind(PREVIOUS_MONTH,currentPreviousMonth.getPreviousMonth())
                .bind(UUID,uuid)
                .as(LeaderPOCConversion.class)
                .map((row, rowMetadata) -> {

                    LeaderPOCConversion.LeaderPOCConversionBuilder leaderBuilder =
                            buildCommonLeaderPOCConversionValues(row);

                    return leaderBuilder.
                            regionMarket(getStringValue(row,ColumnNames.REGION_MARKET.getColumnName()))
                            .build();
                })
                .all();
    }

    @Override
    public Flux<LeaderPOCConversion> getLeaderPOCConversionRegion(String region, int programYear, CurrentPreviousMonth currentPreviousMonth, List<String> appliedFilters) {
        LeaderGrowthRatePOCEModalityQueryBuilder.Builder builder = LeaderGrowthRatePOCEModalityQueryBuilder.builder();
        builder.asLeaderPOCConversionRegion(appliedFilters);
        return client.execute(builder.build())
                .bind(PROGRAM_YEAR,programYear)
                .bind(CURRENT_MONTH,currentPreviousMonth.getCurrentMonth())
                .bind(PREVIOUS_MONTH,currentPreviousMonth.getPreviousMonth())
                .bind(REGION,region)
                .as(LeaderPOCConversion.class)
                .map((row, rowMetadata) -> {

                    LeaderPOCConversion.LeaderPOCConversionBuilder leaderBuilder =
                            buildCommonLeaderPOCConversionValues(row);

                    return leaderBuilder.
                            regionMarket(getStringValue(row,ColumnNames.REGION_MARKET.getColumnName()))
                            .build();
                })
                .all();
    }

    @Override
    public Flux<LeaderPOCConversion> getLeaderPOCConversionMyTeam(int programYear, CurrentPreviousMonth currentPreviousMonth, String uuid, List<String> appliedFilters) {
        LeaderGrowthRatePOCEModalityQueryBuilder.Builder builder = LeaderGrowthRatePOCEModalityQueryBuilder.builder();
        builder.asLeaderPOCConversionTeam(appliedFilters);
        return client.execute(builder.build())
                .bind(PROGRAM_YEAR,programYear)
                .bind(CURRENT_MONTH,currentPreviousMonth.getCurrentMonth())
                .bind(PREVIOUS_MONTH,currentPreviousMonth.getPreviousMonth())
                .bind(UUID,uuid)
                .as(LeaderPOCConversion.class)
                .map((row, rowMetadata) -> {

                    LeaderPOCConversion.LeaderPOCConversionBuilder leaderBuilder =
                            buildCommonLeaderPOCConversionValues(row);

                    return leaderBuilder
                            .firstName(getStringValue(row,ColumnNames.FIRST_NAME.getColumnName()))
                            .lastName(getStringValue(row,ColumnNames.LAST_NAME.getColumnName()))
                            .uuid(getStringValue(row,ColumnNames.UUID.getColumnName()))
                            .parentUUID(getStringValue(row,ColumnNames.PARENT_UUID.getColumnName()))
                            .role(getStringValue(row,ColumnNames.ROLE.getColumnName()))
                            .build();
                })
                .all();
    }

    private LeaderPOCConversion.LeaderPOCConversionBuilder buildCommonLeaderPOCConversionValues(Row row) {
        return LeaderPOCConversion.builder()
                .prevMonthConversionRateNew(getDoubleValue(row,ColumnNames.PREV_NEW.getColumnName()))
                .currentMonthConversionRateNew(getDoubleValue(row,ColumnNames.CUR_NEW.getColumnName()))
                .monthOverMonthChangeNew(getDoubleValue(row,ColumnNames.MOM_CHANGE_NEW.getColumnName()))
                .prevMonthConversionRateExisting(getDoubleValue(row,ColumnNames.PREV_EXIST.getColumnName()))
                .currentMonthConversionRateExisting(getDoubleValue(row,ColumnNames.CUR_EXIST.getColumnName()))
                .monthOverMonthChangeExisting(getDoubleValue(row,ColumnNames.MOM_CHANGE_EXIST.getColumnName()))
                .lastUpdatedDate(getValue(row,ColumnNames.UPDATED_DATE.getColumnName(), java.time.LocalDateTime.class));
    }

    private String getStringValue(Row row, String columnName) {
        return getValue(row, columnName, String.class);
    }

}
