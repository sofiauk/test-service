package com.optum.rqns.ftm.controller;

import com.optum.rqns.ftm.constants.RuleConstants;
import com.optum.rqns.ftm.customannotation.CustomApiResponse;
import com.optum.rqns.ftm.dto.rules.ProviderGroupOpportunitiesSummaryDTO;
import com.optum.rqns.ftm.dto.rules.ProviderGroupOpportunitiesSummaryDetailDTO;
import com.optum.rqns.ftm.enums.ExecutionWeek;
import com.optum.rqns.ftm.enums.GroupsToExecute;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.OpportunityType;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.model.job.JobProcessingResponse;
import com.optum.rqns.ftm.model.rules.OpportunityInput;
import com.optum.rqns.ftm.service.masterconfigservice.MasterConfigService;
import com.optum.rqns.ftm.service.rules.RuleService;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Instant;
import java.util.Map;

@Profile("rqnsFtmApi")
@RestController
@RequestMapping("/v1/rules")
@Slf4j
@CustomApiResponse
public class RulesController {

    public static final String COMPLETE = "Complete";

    @Autowired
    RuleService ruleService;

    @Autowired
    MasterConfigService masterService;

    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = Map.class),
            mediaType = MediaType.APPLICATION_JSON_VALUE))
    @GetMapping("/shoots")
    public Mono<JobProcessingResponse> rulesExecution(@RequestParam(value = "opportunity-type") String opportunityType,
                                                      @RequestParam(value = "mode-of-run") String modeOfRun,
                                                      @RequestParam(value = "cascade-events",defaultValue = "false") boolean cascadeEvents) {
        JobEvent jobEvent = new JobEvent();
        if(opportunityType.equalsIgnoreCase(OpportunityType.REJECTS.getValue())) {
            getJobEvent(jobEvent, JobName.RUN_REJECT_RULES.getValue(), modeOfRun, cascadeEvents);
            return ruleService.processRules(jobEvent);
        }else if(opportunityType.equalsIgnoreCase(OpportunityType.RETURNS.getValue())) {
            getJobEvent(jobEvent, JobName.RUN_RETURN_RULES.getValue(), modeOfRun, cascadeEvents);
            return ruleService.processRules(jobEvent);
        }else if(RuleConstants.SECONDARY_SUBMISSION_NO_SPACE.equalsIgnoreCase(opportunityType)) {
            getJobEvent(jobEvent, JobName.RUN_SECONDARY_SUBMISSION_RULES.getValue(), modeOfRun, cascadeEvents);
            return ruleService.processRules(jobEvent);
        }else if(opportunityType.equalsIgnoreCase(OpportunityType.OUTLERS.getValue())) {
            getJobEvent(jobEvent, JobName.RUN_OUTLIER_RULES.getValue(), modeOfRun, cascadeEvents);
            return ruleService.processRules(jobEvent);
        }else if(RuleConstants.FINANCIAL_INFORMATION_NO_SPACE.equalsIgnoreCase(opportunityType)) {
            getJobEvent(jobEvent, JobName.RUN_PAYMENT_RULES.getValue(), modeOfRun, cascadeEvents);
            return ruleService.processRules(jobEvent);
        }else if(opportunityType.equalsIgnoreCase(OpportunityType.DEPLOYMENTS.getValue())) {
            getJobEvent(jobEvent, JobName.RUN_DEPLOYMENT_RULES.getValue(), modeOfRun, cascadeEvents);
            return ruleService.processRules(jobEvent);
        }else {
            return Mono.empty();
        }
    }

    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = OpportunityInput.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    @GetMapping("/rejects/inputs")
    public Flux<OpportunityInput> getRejectInputData(){
        JobEvent jobEvent = new JobEvent();
        getJobEvent(jobEvent, JobName.RUN_REJECT_RULES.getValue(), GroupsToExecute.ALL.getValue(),false);
        return ruleService.getRejectOpportunityInput(jobEvent);
    }

    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = OpportunityInput.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    @GetMapping("/returns/inputs")
    public Flux<OpportunityInput> getReturnInputData(){
        JobEvent jobEvent = new JobEvent();
        getJobEvent(jobEvent, JobName.RUN_RETURN_RULES.getValue(), GroupsToExecute.ALL.getValue(),false);
        return ruleService.getReturnOpportunityInput(jobEvent);
    }

    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = OpportunityInput.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    @GetMapping("/outliers/inputs")
    public Flux<OpportunityInput> getOutlierOpportunityInput(){
        return ruleService.getOutlierOpportunityInput(new JobEvent());
    }

    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = OpportunityInput.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    @GetMapping("/secondary-submissions/inputs")
    public Flux<OpportunityInput> getSecondarySubmissionOpportunityInput(){
        return ruleService.getSecondarySubmissionOpportunityInput(new JobEvent());
    }

    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = OpportunityInput.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    @GetMapping("/payments/inputs")
    public Flux<OpportunityInput> getFinancialInformationOpportunityInput(){
        JobEvent jobEvent = new JobEvent();
        getJobEvent(jobEvent, JobName.RUN_PAYMENT_RULES.getValue(), GroupsToExecute.ALL.getValue(),false);
        return ruleService.getFinancialInformationOpportunityInput(jobEvent);
    }

    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = OpportunityInput.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    @GetMapping("/deployments/inputs")
    public Flux<OpportunityInput> getDeploymentOpportunityInput(){
        JobEvent jobEvent = new JobEvent();
        getJobEvent(jobEvent, JobName.RUN_DEPLOYMENT_RULES.getValue(), GroupsToExecute.ALL.getValue(),false);
        return ruleService.getDeploymentOpportunityInput(jobEvent);
    }

    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = Map.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    @GetMapping("/inputs")
    public Mono<Map<String,String>> getProcessQueryInputs() {
        return masterService.processQueryInputs();
    }


    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = ProviderGroupOpportunitiesSummaryDTO.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    @GetMapping("/opportunities/inserted-summaries")
    public Flux<ProviderGroupOpportunitiesSummaryDetailDTO> getInsertedOpportunitiesSummaryList(@RequestParam("opportunity-type") String opportunityType){
        log.info("Calling getInsertedOpportunitiesSummaryList for {}",opportunityType);

        OpportunityType opportunity = null;
        if(opportunityType.equalsIgnoreCase(OpportunityType.REJECTS.getValue())) {
            opportunity = OpportunityType.REJECTS;
        }else if(opportunityType.equalsIgnoreCase(OpportunityType.RETURNS.getValue())) {
            opportunity = OpportunityType.RETURNS;
        }else if(opportunityType.equalsIgnoreCase(RuleConstants.SECONDARY_SUBMISSION_NO_SPACE)) {
            opportunity = OpportunityType.SECONDARY_SUBMISSIONS;
        }else if(opportunityType.equalsIgnoreCase(OpportunityType.OUTLERS.getValue())) {
            opportunity = OpportunityType.OUTLERS;
        }else if(opportunityType.equalsIgnoreCase(RuleConstants.FINANCIAL_INFORMATION_NO_SPACE)) {
            opportunity = OpportunityType.FINANCIAL_INFORMATION;
        }else if(opportunityType.equalsIgnoreCase(OpportunityType.DEPLOYMENTS.getValue())) {
            opportunity = OpportunityType.DEPLOYMENTS;
        }
        if(opportunity == null) return Flux.empty();

        return ruleService.getInsertedOpportunitiesSummaryList(opportunity);
    }


    @ApiResponse(responseCode = "200", description = "Success Request",
            content = @Content(schema = @Schema(implementation = ProviderGroupOpportunitiesSummaryDTO.class),
                    mediaType = MediaType.APPLICATION_JSON_VALUE))
    @GetMapping("/opportunities/deleted-summaries")
    public Flux<ProviderGroupOpportunitiesSummaryDTO> getDeletedOpportunitiesSummaryList(@RequestParam("opportunity-type") String opportunityType){
        log.info("Calling getDeletedOpportunitiesSummaryList for {}",opportunityType);
        OpportunityType opportunity = null;
        if(opportunityType.equalsIgnoreCase(OpportunityType.REJECTS.getValue())) {
            opportunity = OpportunityType.REJECTS;
        }else if(opportunityType.equalsIgnoreCase(OpportunityType.RETURNS.getValue())) {
            opportunity = OpportunityType.RETURNS;
        }else if(opportunityType.equalsIgnoreCase(RuleConstants.SECONDARY_SUBMISSION_NO_SPACE)) {
            opportunity = OpportunityType.SECONDARY_SUBMISSIONS;
        }else if(opportunityType.equalsIgnoreCase(OpportunityType.OUTLERS.getValue())) {
            opportunity = OpportunityType.OUTLERS;
        }else if(opportunityType.equalsIgnoreCase(RuleConstants.FINANCIAL_INFORMATION_NO_SPACE)) {
            opportunity = OpportunityType.FINANCIAL_INFORMATION;
        }else if(opportunityType.equalsIgnoreCase(OpportunityType.DEPLOYMENTS.getValue())) {
            opportunity = OpportunityType.DEPLOYMENTS;
        }
        if(opportunity == null) return Flux.empty();

        return ruleService.getDeletedOpportunitiesSummaryList(opportunity);
    }

    private void getJobEvent(JobEvent jobEvent, String jobName, String groupsToExecute, boolean cascadeEvents) {
        jobEvent.setProgramYear(2020);
        jobEvent.setJobName(jobName);
        jobEvent.setGroupsToExecute(groupsToExecute);
        jobEvent.setExecutionWeek(ExecutionWeek.ALL.getValue());
        jobEvent.setTimeStamp(Instant.now());
        jobEvent.setCascadeEvents(cascadeEvents);
        jobEvent.setStatus(COMPLETE);
    }

}

