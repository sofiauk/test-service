package com.optum.rqns.ftm.configuration;


import lombok.extern.slf4j.Slf4j;
import org.reactivestreams.Publisher;
import org.slf4j.MDC;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.http.server.reactive.ServerHttpResponseDecorator;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.ServerWebExchangeDecorator;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;




@Configuration
public class LoggingWebFilter implements WebFilter {
    @Override
    public Mono<Void> filter(ServerWebExchange serverWebExchange, WebFilterChain webFilterChain) {
        final long startMillis = System.currentTimeMillis();
        ServerWebExchange exchangeDecorator = new ServerWebExchangeDecorator(serverWebExchange){
            @Override
            public ServerHttpResponse getResponse() {
                return new ResponseLoggingInterceptor(super.getResponse(), startMillis, serverWebExchange.getRequest());
            }
        };
        return webFilterChain.filter(exchangeDecorator);
    }
}
@Slf4j
class ResponseLoggingInterceptor extends ServerHttpResponseDecorator {
    private long startTime;
    private ServerHttpRequest request;

    public ResponseLoggingInterceptor(ServerHttpResponse delegate, long startTime, ServerHttpRequest request) {
        super(delegate);
        this.startTime = startTime;
        this.request = request;
    }

    @Override
    public Mono<Void> writeWith(Publisher<? extends DataBuffer> body) {
        Flux<DataBuffer> buffer = Flux.from(body);
        return super.writeWith(buffer.doOnNext(dataBuffer -> {
            MDC.put("path", request.getURI().toString());
            if(getStatusCode()!=null)
                MDC.put("statusCode", String.valueOf(getStatusCode().value()));
            MDC.put("responseTime", String.valueOf((System.currentTimeMillis() - startTime)));
            log.info("Success in executing the request");
            MDC.clear();
        }));
    }
}
