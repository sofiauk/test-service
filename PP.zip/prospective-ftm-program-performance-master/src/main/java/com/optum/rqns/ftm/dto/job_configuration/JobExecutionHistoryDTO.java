package com.optum.rqns.ftm.dto.job_configuration;

import com.optum.rqns.ftm.enums.Status;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class JobExecutionHistoryDTO {
    @NotNull
    private Integer id;
    @NotNull
    private Integer jobID;
    private Status status;
    private String errorMessage;
    private Integer affectedRows;
    private LocalDateTime jobStart;
    private LocalDateTime jobEnd;
    private String jobEvent;
    private String message;
    private String messageKey;
}
