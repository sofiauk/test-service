package com.optum.rqns.ftm.repository.rules;

import com.optum.rqns.ftm.dto.rules.ProviderGroupOpportunitiesDetailsDTO;
import com.optum.rqns.ftm.dto.rules.ProviderGroupOpportunitiesSummaryDTO;
import com.optum.rqns.ftm.dto.rules.ProviderGroupOpportunitiesSummaryDetailDTO;
import com.optum.rqns.ftm.enums.OpportunityType;
import com.optum.rqns.ftm.model.rules.DeploymentOpportunityInput;
import com.optum.rqns.ftm.model.rules.FinancialInformationOpportunityInput;
import com.optum.rqns.ftm.model.rules.MemberAssessmentOpportunity;
import com.optum.rqns.ftm.model.rules.OutlierOpportunityInput;
import com.optum.rqns.ftm.model.rules.ProviderGroup;
import com.optum.rqns.ftm.model.rules.ProviderGroupOpportunitiesDetail;
import com.optum.rqns.ftm.model.rules.ProviderGroupOpportunitiesSummary;
import com.optum.rqns.ftm.model.rules.RejectOpportunityInput;
import com.optum.rqns.ftm.model.rules.ReturnOpportunityInput;
import com.optum.rqns.ftm.model.rules.SecondarySubmissionOpportunityInput;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Map;

public interface RuleRepository {

    Flux<ProviderGroup> getProviderGroupsByLastRunDate(Map<String, String> inputMap,OpportunityType opportunityType);

    Flux<ReturnOpportunityInput> getReturnOpportunityInput(Map<String, String> inputMap, boolean isModified);

    Flux<RejectOpportunityInput> getRejectOpportunityInput(Map<String, String> inputMap,boolean isModified);

    Flux<OutlierOpportunityInput> getOutlierOpportunityInput(Map<String, String> inputMap);

    Flux<SecondarySubmissionOpportunityInput> getSecondarySubmissionOpportunityInput(Map<String, String> inputMap);

    Flux<FinancialInformationOpportunityInput> getFinancialInformationOpportunityInput(Map<String, String> inputMap);

    Flux<DeploymentOpportunityInput> getDeploymentOpportunityInput(Map<String, String> inputMap, boolean isModified);

    Mono<Integer> moveProviderGroupOpportunitySummeryToHistory(String opportunityType,Map<String, String> inputMap) ;

    Mono<Integer> moveProviderGroupOpportunityDetailToHistory(String opportunityType,Map<String, String> inputMap);

//    Mono<Integer> updateJobRunConfigurationAsInProgress(OpportunityType opportunityType);
//
//    Mono<Integer> updateJobRunConfigurationAsSuccess(OpportunityType opportunityType);
//
//    Mono<Integer> updateJobRunConfigurationAsSuccess(OpportunityType opportunityType, String message);

    Mono<Integer> deleteMemberAssessmentOpportunity( String opportunityType, Map<String, String> inputMap);

//    Mono<String> getJobRunConfiguration(String jobName);

    Mono<Long> groupingOfQueriesForDeleteMemberAssessmentOpportunities(List<ProviderGroup> providerGroupList, String opportunityValue, Map<String, String> inputMap);

    Mono<Long> batchQueriesExecuteForInsertMemberAssessmentOpportunities(List<MemberAssessmentOpportunity> assessmentOpportunityList);

    Mono<Long> groupingOfQueriesForMoveSummaryToHistory(List<ProviderGroup> providerGroupList, String opportunityValue, Map<String, String> inputMap);

    Mono<Long> batchQueriesExecuteForInsertIntoSummary(List<ProviderGroupOpportunitiesSummary> assessmentOpportunityList);


    Mono<Long> groupingOfQueriesForMoveDetailToHistory(List<ProviderGroup> providerGroupList, String value, Map<String, String> inputMap);

    Mono<Long> batchQueriesExecuteForInsertIntoDetail(List<ProviderGroupOpportunitiesDetail> providerGroupOpportunitiesDetails);

//    Mono<Integer> updateJobRunConfigurationToFailed(String jobName,String errorMessage);

    Mono<Long> batchQueriesExecuteForGetMemberAssessmentOpportunities(List<MemberAssessmentOpportunity> assessmentOpportunityList,
                                                                                  Map<String, String> processQueryInputMap);

    Flux<ProviderGroupOpportunitiesSummaryDTO> getDeletedOpportunitiesSummaryList(OpportunityType opportunityType, String jobName);

    Flux<ProviderGroupOpportunitiesSummaryDetailDTO> getInsertedOpportunitiesSummaryList(OpportunityType opportunityType, String jobName);

    Mono<Map<String,Long>> getUpdatedRowsCount(OpportunityType opportunityType,String jobName);

//    Mono<Integer> updateJobRunConfigurationAsInProgressWithJobEndDate(OpportunityType opportunityType);

}
