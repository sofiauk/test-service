package com.optum.rqns.ftm.dto.opportunities.providergrp.converter;

import com.optum.rqns.ftm.constants.ProviderGroupConstants;
import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.model.opportunities.providergrp.QFOHealthSystemOpportunitiesDetails;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;

import java.time.LocalDateTime;

public class QFOHealthSystemOpportunitiesDetailsConverter implements Converter<Row, QFOHealthSystemOpportunitiesDetails>, DTOWrapperTypeConverter {
    @Override
    public QFOHealthSystemOpportunitiesDetails convert(Row row) {
        return QFOHealthSystemOpportunitiesDetails.builder()
                .masterOpportunityType(row.get(ProviderGroupConstants.MASTER_OPPORTUNITY_TYPE, String.class))
                .masterOpportunityTypePosition(getPrimitiveIntegerValue(row, ProviderGroupConstants.MASTER_OPPORTUNITY_TYPE_POSITION))
                .healthSystemId(row.get(ProviderGroupConstants.HEALTHSYSTEMID, String.class))
                .programYear(getPrimitiveIntegerValue(row, ProviderGroupConstants.PROGRAM_YEAR))
                .assessmentCount(getPrimitiveIntegerValue(row, ProviderGroupConstants.ASSESSMENT_COUNT))
                .deploymentCount(getPrimitiveIntegerValue(row, ProviderGroupConstants.DEPLOYMENT_COUNT))
                .gapCount(getPrimitiveIntegerValue(row, ProviderGroupConstants.GAP_COUNT))
                .opportunityType(row.get(ProviderGroupConstants.OPPORTUNITY_TYPE_COLUMN, String.class))
                .opportunityTypePosition(getPrimitiveIntegerValue(row, ProviderGroupConstants.OPPORTUNITY_TYPE_POSITION))
                .membersToAchieveFiveStarRatings(getPrimitiveIntegerValue(row, ProviderGroupConstants.MEMBERS_TO_ACHIEVE_FIVE_STAR_RATINGS))
                .compliantMembers(getPrimitiveIntegerValue(row, ProviderGroupConstants.COMPLIANT_MEMBERS))
                .updatedDate(row.get(ProviderGroupConstants.UPDATED_DATE, LocalDateTime.class))
                .measureId(row.get(ProviderGroupConstants.MEASURE_ID, String.class))
                .build();
    }
}


