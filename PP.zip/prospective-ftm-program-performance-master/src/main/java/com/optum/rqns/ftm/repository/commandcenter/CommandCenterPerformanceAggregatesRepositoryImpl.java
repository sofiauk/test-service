package com.optum.rqns.ftm.repository.commandcenter;

import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.model.providergrpdeployment.PerformanceAggregate;
import io.r2dbc.spi.Row;
import org.springframework.data.r2dbc.core.DatabaseClient;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;


@Repository
public class CommandCenterPerformanceAggregatesRepositoryImpl implements CommandCenterPerformanceAggregatesRepository, DTOWrapperTypeConverter {

    private final DatabaseClient client;

    CommandCenterPerformanceAggregatesRepositoryImpl(DatabaseClient client) {
        this.client = client;
    }

    public enum ColumnNames {

        PROGRAM_YEAR("ProgramYear");

        private String columnName;

        ColumnNames(String columnName) {
            this.columnName = columnName;
        }

        public String getColumnName() {
            return this.columnName;
        }
    }

    private static final String COMMAND_CENTER_PERFORMANCE_AGGREGATES =
            "SELECT Name, Value FROM ProgPerf.CommandCenterPerformanceAggregates WHERE ProgramYear = :ProgramYear";

    @Override
    public Flux<PerformanceAggregate> getCommandCenterPerformanceAggregates(int programYear) {

        return client.execute(COMMAND_CENTER_PERFORMANCE_AGGREGATES)
                .bind(ColumnNames.PROGRAM_YEAR.getColumnName(), programYear)
                .as(PerformanceAggregate.class)
                .map((row, rowMetadata) -> PerformanceAggregate
                        .builder()
                        .name(getStringValue(row, "Name"))
                        .value(getStringValue(row, "Value"))
                        .build()
                )
                .all();
    }

    String getStringValue(Row row, String columnName) {
        return getValue(row, columnName, String.class);
    }

}
