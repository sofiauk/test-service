package com.optum.rqns.ftm.dto.memberassessment.converter;

import com.optum.rqns.ftm.dto.DTOWrapperTypeConverter;
import com.optum.rqns.ftm.dto.memberassessment.MemberAssessmentHistory;
import com.optum.rqns.ftm.repository.memberAssessmentHistory.MemberAssessmentHistoryRepositoryImpl;
import io.r2dbc.spi.Row;
import org.springframework.core.convert.converter.Converter;

public class MemberAssessmentHistoryDTOConverter implements Converter<Row, MemberAssessmentHistory>, DTOWrapperTypeConverter {

    @Override
    public MemberAssessmentHistory convert(Row rs) {

        return MemberAssessmentHistory.builder()
                .provGroupId(rs.get(MemberAssessmentHistoryRepositoryImpl.ColumnNames.PROVIDER_GROUP_ID.getColumnName(), String.class))
                .providerState(rs.get(MemberAssessmentHistoryRepositoryImpl.ColumnNames.PROVIDER_STATE.getColumnName(), String.class))
                .overallStatus(rs.get(MemberAssessmentHistoryRepositoryImpl.ColumnNames.OVERALL_STATUS.getColumnName(), String.class))
                .projectYear(getPrimitiveIntegerValue(rs, MemberAssessmentHistoryRepositoryImpl.ColumnNames.PROJECT_YEAR.getColumnName()))
                .build();
    }
}