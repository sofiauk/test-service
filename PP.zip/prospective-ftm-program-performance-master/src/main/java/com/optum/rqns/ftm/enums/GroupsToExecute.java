package com.optum.rqns.ftm.enums;

public enum GroupsToExecute {
    ALL("All"),
    MONTHLY("Monthly"),
    MODIFIED("Modified");

    private String value;
    private GroupsToExecute(String value) {
        this.value = value;
    }
    public String getValue(){
        return value;
    }
}
