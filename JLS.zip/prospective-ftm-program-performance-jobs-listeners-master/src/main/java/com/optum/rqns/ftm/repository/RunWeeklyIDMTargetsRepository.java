package com.optum.rqns.ftm.repository;

import java.util.concurrent.Callable;

public interface RunWeeklyIDMTargetsRepository {
    Long getRecordCount(Integer programYear);

    Callable<Integer> mergeData(int batchSize, Integer batchOffset,Integer programYear);
}
