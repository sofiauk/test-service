package com.optum.rqns.ftm.kafka.consumer;

import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.repository.common.CommonRepository;
import com.optum.rqns.ftm.service.landingpage.LeaderPerformanceHistorical;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.context.annotation.Profile;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.annotation.TopicPartition;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

@Profile("rqnsFtmJobs")
@Component
@Slf4j
public class LeaderPerformanceHistoricalConsumer extends JobEventConsumer {
    public LeaderPerformanceHistoricalConsumer(LeaderPerformanceHistorical jobService, CommonRepository commonRepository) {
        super(jobService, commonRepository);
    }

    @KafkaListener(topicPartitions = {@TopicPartition(topic = "${spring.gcpkafka.properties.topics.jobEvent}", partitions = {"10"})},
            containerFactory = "jobEventKafkaListenerContainerFactory", autoStartup = "true")
    public void onMessage(ConsumerRecord<String, JobEvent> record, Acknowledgment acknowledgment) {
        log.info("{} Begin Leader Performance historical : {}", super.generateTransactionId(record), record);
        processMessage(10, record, acknowledgment);
    }
}
