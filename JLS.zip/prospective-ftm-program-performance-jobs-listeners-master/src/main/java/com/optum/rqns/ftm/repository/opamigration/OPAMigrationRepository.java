package com.optum.rqns.ftm.repository.opamigration;

import com.optum.rqns.ftm.model.opamigration.MemberOverallStatus;
import com.optum.rqns.ftm.model.providergroup.ProviderGroup;

import java.util.List;

public interface OPAMigrationRepository {

    List<MemberOverallStatus> getMemberStatusDetails(int batchSize, Integer batchOffset,Integer programYear);

    List<MemberOverallStatus> getMemberStatusDetailsBasedOnLostJobRunDate(int batchSize, Integer batchOffset, Integer programYear);

    Long getRecordCount(Integer programYear);

    Long getRecordCountForLastUpdateJobRunConfiguration(Integer programYear);
}
