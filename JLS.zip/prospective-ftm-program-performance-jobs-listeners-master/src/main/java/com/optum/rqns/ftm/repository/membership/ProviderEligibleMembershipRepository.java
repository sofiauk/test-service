package com.optum.rqns.ftm.repository.membership;

import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.model.membership.ProviderEligibleMembershipFlatData;

import java.util.List;

public interface ProviderEligibleMembershipRepository {


    Long getRecordCount(JobEvent jobEvent);

    List<ProviderEligibleMembershipFlatData> getProviderEligibleMembershipDetails(int batchSize, Integer batchOffset,JobEvent jobEvent);


}
