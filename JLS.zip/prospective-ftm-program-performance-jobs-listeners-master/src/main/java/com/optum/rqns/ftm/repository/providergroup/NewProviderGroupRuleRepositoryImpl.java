package com.optum.rqns.ftm.repository.providergroup;

import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.model.providergroup.MemberAssessmentHistory;
import com.optum.rqns.ftm.model.providergroup.ProviderGroup;
import com.optum.rqns.ftm.util.ProgramPerformanceJobUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
@Slf4j
public class NewProviderGroupRuleRepositoryImpl implements NewProviderGroupRuleRepository {

    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    public NewProviderGroupRuleRepositoryImpl(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
        this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
    }

    private static final String LAST_UPDATE_QUERY = "SELECT CAST(LastSuccessfulRunDate as DATE)   " +
            "              FROM ProgPerf.JobRunConfiguration where JobName = '  " + JobName.RUN_NEW_PROVIDER_GROUP_RULES.getValue() +   "'";

    private static final String MEMBER_ASSESSMENT_QUERY_FILTER = " and m.UpdatedDate >= (" + LAST_UPDATE_QUERY + ")";

    private static final String PROVIDER_GROUP_BASED_ON_GROUPIDS_QUERY = "SELECT PG.ProviderGroupId, PG.State, PG.IsNewForDeployment AS newForDeployment, PG.EligiblePreferredMembers, PG.ProgramYear as programYear, " +
            "PG.IsNewForPOC as newForPOC FROM ProgPerf.ProviderGroupExtended PG WITH (NOLOCK) " +
            "WHERE PG.ProviderGroupId in (%s) " +
            "AND PG.ProgramYear = %s " +
            "%s";

    private static final String PROVIDER_GROUP_QUERY = "SELECT PG.ProviderGroupId, PG.State, PG.IsNewForDeployment AS newForDeployment, PG.EligiblePreferredMembers, PG.ProgramYear as programYear, " +
            "PG.IsNewForPOC as newForPOC FROM ProgPerf.ProviderGroupExtended PG WITH (NOLOCK) " +
            "WHERE PG.ProgramYear = :ProgramYear";

    public static final String UPDATE_PROVIDER_GROUP_ISNEW = "UPDATE ProgPerf.ProviderGroup SET " +
            "IsNewForDeployment = :IsNewForDeployment, " +
            "UpdatedBy = :UpdatedBy, " +
            "UpdatedDate = GETUTCDATE() " +
            "WHERE ProviderGroupId = :ProviderGroupId AND state = :State";

    public static final String UPDATE_PROVIDER_GROUP_EXTENDED_ISNEW = "UPDATE ProgPerf.ProviderGroupExtended SET " +
            "IsNewForDeployment = :IsNewForDeployment, " +
            "IsNewForPOC = :IsNewForPOC, " +
            "UpdatedBy = :UpdatedBy, " +
            "UpdatedDate = GETUTCDATE() " +
            "WHERE ProviderGroupId = :ProviderGroupId AND state = :State AND ProgramYear = :ProgramYear";

    // Based on LastSuccessfulRunDate
    private static final String MEMBER_ASSESSMENT_HISTORY_LAST_RUN_DATE_QUERY = "SELECT prov_group_id, providerstate, overall_status, project_year, deriveddeployed, returned " +
            "FROM ProgPerf.MemberAssessmentHistory WITH (NOLOCK) " +
            "WHERE CAST(UpdatedDate as DATE) >= (select CAST(LastSuccessfulRunDate as DATE) " +
            "FROM ProgPerf.JobRunConfiguration where JobName = '" + JobName.RUN_NEW_PROVIDER_GROUP_RULES.getValue() + "') " +
            "AND project_year = (:ProgramYear - 1)";

    //Based on ProviderGroups
    private static final String MEMBER_ASSESSMENT_HISTORY_QUERY = "SELECT prov_group_id, providerstate, overall_status, project_year, deriveddeployed, returned from ProgPerf.MemberAssessmentHistory WITH (NOLOCK) " +
            "WHERE prov_group_id in (%s) " +
            "AND project_year = (:ProgramYear - 1)";

    // Select count of groups for batching
    private static final String COUNT_ACCT_IS_ELIGIBLE_POC=
                  "   SELECT count(*)  " +
                  "        FROM ProgPerf.Accounts acct  WITH (NOLOCK)  " +
                  "        WHERE acct.ServiceLevel ='HCA'" ;

    //Update the IsGroupEligibleForPOC flag
    private static final String UPDATE_IS_GROUP_ELIGIBLE_POC=
            ";WITH accts as( " +
                    "        SELECT Groupid,state " +
                    "        FROM ProgPerf.Accounts acct WITH (NOLOCK)" +
                    "        WHERE acct.ServiceLevel ='HCA' " +
                    "        ORDER BY acct.AccountId OFFSET :begin ROWS FETCH NEXT :end ROWS ONLY "+
                    "          ) " +
                    "      ,providers as(       " +
                    "        SELECT accts.Groupid " +
                    "           ,accts.State " +
                    "           ,RS.LobName " +
                    "        FROM accts JOIN (  SELECT  " +
                    "                  PGP.ProviderGroupID, " +
                    "                  PGP.State, " +
                    "                  PGP.LobName " +
                    "                FROM " +
                    "                ( " +
                    "                  ( " +
                    "                  SELECT pg_perf.ProviderGroupID " +
                    "                       ,pg_perf.State  " +
                    "                       ,pg_perf.LobName  " +
                    "                  FROM  ProgPerf.ProviderGroupPerformance pg_perf WITH (NOLOCK) " +
                    "                  WHERE pg_perf.ProgramYear =:ProgramYear  " +
                    "                      AND pg_perf.EligiblePreferredMemberCount >25 " +
                    "                      AND pg_perf.DeployYTDActual >=1 " +
                    "                      AND pg_perf.ReturnedNetCnaYtdActual >=1 " +
                    "                      AND pg_perf.isCurrentWeekForPerformance =1 " +
                    "                  GROUP BY pg_perf.ProviderGroupID,pg_perf.State,pg_perf.LobName " +
                    "                  )  AS PGP JOIN " +
                    "                          ( " +
                    "                            SELECT  " +
                    "                               m.prov_group_id as ProviderGroupID " +
                    "                               ,m.providerstate as State " +
                    "                               ,m.lob2 as LobName " +
                    "                             FROM ProgPerf.MemberAssessment m  WITH (NOLOCK)" +
                    "                             WHERE m.chart_dup_id =1 " +
                    "                                   AND m.project_year =:ProgramYear " +
                    "                                   AND m.projectid_type in ('PAF','FLA') " +
                    "                                   %s "+
                    "                              GROUP BY m.prov_group_id ,m.providerstate ,m.lob2 " +
                    "                              ) AS MA " +
                    "                             ON PGP.ProviderGroupID=MA.ProviderGroupID AND PGP.State=MA.State AND PGP.LobName=MA.LobName " +
                    "                   ) " +
                    "                ) AS RS      " +
                    "              ON RS.ProviderGroupID=accts.GroupId AND RS.State=accts.State " +
                    "             ) " +
                    "  UPDATE ProgPerf.ProviderGroupExtended  " +
                    "  SET IsGroupEligibleForPOC =1 , UpdatedDate =GETUTCDATE(), UpdatedBy ='NewProviderGroupRulesJob'   " +
                    "  FROM providers  " +
                    "  JOIN ProgPerf.ProviderGroupExtended PGE WITH (NOLOCK) " +
                    "  ON PGE.ProviderGroupID =providers.GroupId AND PGE.State =providers.State AND PGE.ProgramYear=:ProgramYear;" ;

    //Existing Group Count Without Utilization
   private static final String EXISTING_GROUP_WITHOUT_UTILIZATION_COUNT_QUERY=
                       " ;with count_1 as (  " +
                       "         select count(*) as ExistingGroups, pge.ProgramYear as py  " +
                       "         from ProgPerf.ProviderGroupExtended pge with (nolock)   " +
                       "         WHERE pge.ProgramYear = :ProgramYear" +
                       "                 and  pge.IsNewForPOC =0   " +
                       "                 and pge.IsGroupEligibleForPOC =1  group by pge.ProgramYear         " +
                       "                   )  " +
                       "         update  ProgPerf.CommandCenterPerformanceAggregates   " +
                       "         set Value =count_1.ExistingGroups,  " +
                       "             UpdatedBy ='NewProviderGroupRulesJob',  " +
                       "             UpdatedDate =GETUTCDATE()   " +
                       "         from count_1 where name='POCConversion_ExistingProviderGroupPOCEligibleCount' and ProgramYear=count_1.py;";

    //New Group Without Utilization
    private static final String NEW_GROUP_WITHOUT_UTILZATION_COUNT_QUERY=
                           "  ;with count_2 as (  " +
                           "       select count(*) as NewGroups , pge.ProgramYear as py" +
                           "       from ProgPerf.ProviderGroupExtended pge with (nolock)   " +
                           "        WHERE pge.ProgramYear = :ProgramYear" +
                           "              and  pge.IsNewForPOC =1  " +
                           "              and pge.IsGroupEligibleForPOC =1  group by pge.ProgramYear " +
                           "                    )  " +
                           "        update  ProgPerf.CommandCenterPerformanceAggregates   " +
                           "        set Value =count_2.NewGroups,  " +
                           "            UpdatedBy ='NewProviderGroupRulesJob',  " +
                           "            UpdatedDate =GETUTCDATE()   " +
                           "        from count_2 where name='POCConversion_NewProviderGroupPOCEligibleCount' and ProgramYear=count_2.py; " ;

    //Existing Group With Utilization
    private static final String EXISTING_GROUPS_WITH_UTILIZATION_COUNT_QUERY =
                            "  ;with count_3 as (   " +
                            "     select count(*) as ExistingGroupsWithUsage,pge.ProgramYear as py   " +
                            "     from ProgPerf.ProviderGroupExtended pge    with (nolock)     " +
                            "            join ProgPerf.Accounts a on a.GroupId =pge.ProviderGroupID   " +
                            "             and a.State =pge.State    " +
                            "             and a.UtilizingPOC =1   " +
                            "             and pge.ProgramYear = :ProgramYear " +
                            "             and pge.IsNewForPOC =0   " +
                            "             and pge.IsGroupEligibleForPOC =1  group by pge.ProgramYear  " +
                            "                   )   " +
                            "     update  ProgPerf.CommandCenterPerformanceAggregates   " +
                            "     set Value =count_3.ExistingGroupsWithUsage,   " +
                            "         UpdatedBy ='NewProviderGroupRulesJob',   " +
                            "         UpdatedDate =GETUTCDATE()    " +
                            "     from count_3 where name='POCConversion_ExistingProviderGroupCountUtilizingPOC' and ProgramYear=count_3.py; ";

    //New Group With Utilization
    private static final String NEW_GROUPS_WITH_UTILIZATION_COUNT_QUERY =
                            " ;with count_4 as (   " +
                            "    select count(*) as ExistingGroupsWithUsage,pge.ProgramYear as py   " +
                            "    from ProgPerf.ProviderGroupExtended pge    with (nolock)     " +
                            "            join ProgPerf.Accounts a on a.GroupId =pge.ProviderGroupID   " +
                            "             and a.State =pge.State    " +
                            "             and a.UtilizingPOC =1   " +
                            "             and pge.ProgramYear = :ProgramYear " +
                            "             and pge.IsNewForPOC =1   " +
                            "             and pge.IsGroupEligibleForPOC =1 group by pge.ProgramYear   " +
                            "                   )   " +
                            "     update  ProgPerf.CommandCenterPerformanceAggregates    " +
                            "     set Value =count_4.ExistingGroupsWithUsage,   " +
                            "         UpdatedBy ='NewProviderGroupRulesJob',   " +
                            "         UpdatedDate =GETUTCDATE()    " +
                            "     from count_4 where name='POCConversion_NewProviderGroupCountUtilizingPOC' and ProgramYear=count_4.py; " ;

    //Check for only IsNewForDeployment 1 and IsNewForPOC
    private static final Object NEWGROUPS_MODIFIED_CONDITION = " AND (IsNewForDeployment = 1 OR IsNewForDeployment is null OR IsNewForPOC = 1 OR IsNewForPOC is null)";

    //TO FIX memory issues
    private static final String PROVIDER_GROUPS_COUNT_QUERY = "select count(*) AS totalCount from ProgPerf.ProviderGroupExtended WITH (NOLOCK) " +
            "WHERE ProgramYear = %s %s";

    private static final String PROVIDER_GROUP_OFFSET_QUERY = "SELECT PG.ProviderGroupId, PG.State, PG.IsNewForDeployment As newForDeployment, PG.EligiblePreferredMembers, PG.ProgramYear as programYear, " +
            "PG.IsNewForPOC as newForPOC FROM ProgPerf.ProviderGroupExtended PG WITH (NOLOCK) " +
            "WHERE PG.ProgramYear = %s %s " +
            "ORDER BY [ProviderGroupId] "+
            "OFFSET :OFFSET ROWS FETCH NEXT :BATCHSIZE ROWS ONLY";

    private static final String PROVIDER_GROUP_DETAILS_BASED_ON_IDS_QUERY = "SELECT PG.ProviderGroupId, PG.State, PG.IsNewForDeployment As newForDeployment, PG.EligiblePreferredMembers, PG.ProgramYear as programYear, " +
            "PG.IsNewForPOC as newForPOC FROM ProgPerf.ProviderGroupExtended PG WITH (NOLOCK) " +
            "WHERE PG.ProgramYear = %s %s " +
            "AND PG.ProviderGroupId in (%s)";

    private static final String PROVIDER_GROUP_NEW_GROUPS_QUERY = "SELECT PG.ProviderGroupId FROM ProgPerf.ProviderGroupExtended PG WITH (NOLOCK) " +
            "WHERE PG.ProgramYear = %s %s";

    // Based on LastSuccessfulRunDate
    private static final String MEMBER_ASSESSMENT_HISTORY_LAST_RUN_DATE_COMMON_QUERY = " FROM ProgPerf.MemberAssessmentHistory WITH (NOLOCK) " +
            "WHERE CAST(UpdatedDate as DATE) >= (select CAST(LastSuccessfulRunDate as DATE) " +
            "FROM ProgPerf.JobRunConfiguration where JobName = '" + JobName.RUN_NEW_PROVIDER_GROUP_RULES.getValue() + "') " +
            "AND project_year = (:ProgramYear - 1)";

    private static final String MEMBER_ASSESSMENT_HISTORY_PROVIDER_GROUP_COMMON_QUERY = "SELECT prov_group_id " + MEMBER_ASSESSMENT_HISTORY_LAST_RUN_DATE_COMMON_QUERY + " GROUP BY [prov_group_id]";

    private static final String MEMBER_ASSESSMENT_HISTORY_LAST_RUN_DATE_PROVIDERGROUP_QUERY =  MEMBER_ASSESSMENT_HISTORY_PROVIDER_GROUP_COMMON_QUERY +
            "ORDER BY [prov_group_id] "+
            "OFFSET :OFFSET ROWS FETCH NEXT :BATCHSIZE ROWS ONLY";

    //Count query
    private static final String MEMBER_ASSESSMENT_HISTORY_LAST_RUN_DATE_QUERY_COUNT = "SELECT count(*) AS totalCount FROM ("
            + MEMBER_ASSESSMENT_HISTORY_PROVIDER_GROUP_COMMON_QUERY
            + ") AS LastJobCountNewPGRule";

    //Actual Data Query
    private static final String MEMBER_ASSESSMENT_HISTORY_LAST_RUN_DATE_QUERY_PROVIDERGROUP_QUERY_BATCH =   "SELECT prov_group_id, providerstate, overall_status, project_year, deriveddeployed, returned " +
            MEMBER_ASSESSMENT_HISTORY_LAST_RUN_DATE_COMMON_QUERY +
            " AND prov_group_id in (%s)";

    public List<ProviderGroup> getProviderGroupDetails(Integer programYear){
        SqlParameterSource sqlParameterSource = new MapSqlParameterSource("ProgramYear", programYear);
        return namedParameterJdbcTemplate.query(PROVIDER_GROUP_QUERY,sqlParameterSource,new BeanPropertyRowMapper<>(ProviderGroup.class));
    }

    @Override
    public List<MemberAssessmentHistory> getMemberAssessmentHistoryDetails(String providerGroupIds, Integer programYear) {
        SqlParameterSource sqlParameterSource = new MapSqlParameterSource("ProgramYear", programYear);
        String query = String.format(MEMBER_ASSESSMENT_HISTORY_QUERY, providerGroupIds);
        return namedParameterJdbcTemplate.query(query,sqlParameterSource,new BeanPropertyRowMapper<>(MemberAssessmentHistory.class));
    }

    @Override
    public List<MemberAssessmentHistory> getMemberAssessmentHistoryDetailsBasedOnLastJobRunDate(Integer programYear) {
        SqlParameterSource sqlParameterSource = new MapSqlParameterSource("ProgramYear", programYear);
        String query = String.format(MEMBER_ASSESSMENT_HISTORY_LAST_RUN_DATE_QUERY);
        return namedParameterJdbcTemplate.query(query,sqlParameterSource,new BeanPropertyRowMapper<>(MemberAssessmentHistory.class));
    }

    @Override
    public int[] updateBatchQueries(List<Map<String, Object>> batchValues) {

        int[] providerGroupUpdatedRecords = namedParameterJdbcTemplate.batchUpdate(UPDATE_PROVIDER_GROUP_ISNEW, batchValues.toArray(new Map[batchValues.size()]));
        log.info("{} Updated ProviderGroup records {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier (), providerGroupUpdatedRecords.length);

        return namedParameterJdbcTemplate.batchUpdate(UPDATE_PROVIDER_GROUP_EXTENDED_ISNEW, batchValues.toArray(new Map[batchValues.size()]));

    }

    @Override
    public List<ProviderGroup> getProviderGroupDetailsBasedOnProviderGroups(String providerGroupIds, Integer programYear, boolean executeForNewGroups) {
        String query = "";

        if(executeForNewGroups){
            query = String.format(PROVIDER_GROUP_BASED_ON_GROUPIDS_QUERY, providerGroupIds, programYear, NEWGROUPS_MODIFIED_CONDITION);
        } else {
            query = String.format(PROVIDER_GROUP_BASED_ON_GROUPIDS_QUERY, providerGroupIds, programYear, "");
        }
        return namedParameterJdbcTemplate.query(query , new BeanPropertyRowMapper<>(ProviderGroup.class));

    }

    @Override
    public List<Integer> getRowCountforIsEligiblePOClist(int batchsize) {
        Integer totalRows =   namedParameterJdbcTemplate.queryForObject(COUNT_ACCT_IS_ELIGIBLE_POC, new HashMap<>(), Integer.class);
        List<Integer> batches = new ArrayList<>();
        if (totalRows!=null && totalRows > 0) {
            for (int batchOffset = 0; batchOffset <= totalRows; batchOffset += batchsize) {
                batches.add(batchOffset);
            }
        }
        return batches;
    }

    @Override
    public int updateIsGroupEligiblePOC(boolean isAllProviderGroups,int programYear, int begin, int end) {
        String query=UPDATE_IS_GROUP_ELIGIBLE_POC;
        if(isAllProviderGroups){
            query= String.format(query,"");
        }
        else{
            query=String.format(query,MEMBER_ASSESSMENT_QUERY_FILTER);
        }
        log.info("Executing Update query for IsEligibleForPOC: {},offset {}, end {}",query,begin,end);
        Map<String,Object> paramMap= new HashMap<>();
        paramMap.put("ProgramYear",programYear);
        paramMap.put("begin",begin);
        paramMap.put("end",end);
        return namedParameterJdbcTemplate.update(query, paramMap);
    }

    @Override
    public int updateCommandCenterPerformanceAggregates(Integer programYear){
        SqlParameterSource sqlParameterSource = new MapSqlParameterSource("ProgramYear", programYear);
        return
        namedParameterJdbcTemplate.update(EXISTING_GROUP_WITHOUT_UTILIZATION_COUNT_QUERY,sqlParameterSource)
       + namedParameterJdbcTemplate.update(NEW_GROUP_WITHOUT_UTILZATION_COUNT_QUERY,sqlParameterSource)
       + namedParameterJdbcTemplate.update(EXISTING_GROUPS_WITH_UTILIZATION_COUNT_QUERY,sqlParameterSource)
       + namedParameterJdbcTemplate.update(NEW_GROUPS_WITH_UTILIZATION_COUNT_QUERY, sqlParameterSource) ;

    }

    @Override
    public Long getProviderGroupsRecordCount(boolean executeForNewGroups, Integer programYear) {

        String query = "";
        if(executeForNewGroups){
            query = String.format(PROVIDER_GROUPS_COUNT_QUERY, programYear, NEWGROUPS_MODIFIED_CONDITION);
        } else {
            query = String.format(PROVIDER_GROUPS_COUNT_QUERY, programYear, Constants.EMPTY);
        }
        log.info("Get ProviderGroup Extended Count Query :{}", query);
        return namedParameterJdbcTemplate.queryForObject(query, new HashMap<>(), Long.class);
    }

    @Override
    public List<ProviderGroup> getProviderGroupDetailsByOffset(int batchSize, Integer offset, boolean executeForNewGroups, Integer programYear) {
        SqlParameterSource sqlParameterSource = new MapSqlParameterSource("BATCHSIZE", batchSize)
                .addValue("OFFSET", offset);

        String query = "";
        if(executeForNewGroups){
            query = String.format(PROVIDER_GROUP_OFFSET_QUERY, programYear, NEWGROUPS_MODIFIED_CONDITION);
        } else {
            query = String.format(PROVIDER_GROUP_OFFSET_QUERY, programYear, Constants.EMPTY);
        }
        log.info("Provider Group By groupId batch size {} offset {}", batchSize, offset);
        return namedParameterJdbcTemplate.query(query, sqlParameterSource, new BeanPropertyRowMapper<>(ProviderGroup.class));
    }

    @Override
    public Long getMemberAssessmentHistoryDetailsBasedOnLastJobRunDateRecordCount(Integer programYear) {
        SqlParameterSource sqlParameterSource = new MapSqlParameterSource("ProgramYear", programYear);
        return namedParameterJdbcTemplate.queryForObject(MEMBER_ASSESSMENT_HISTORY_LAST_RUN_DATE_QUERY_COUNT, sqlParameterSource, Long.class);
    }

    @Override
    public List<MemberAssessmentHistory> getMemberAssessmentHistoryProviderGroupsBasedOnLastRunDate(int batchSize, Integer offset, Integer programYear) {
        SqlParameterSource sqlParameterSource = new MapSqlParameterSource("BATCHSIZE", batchSize)
                .addValue("OFFSET", offset)
                .addValue("ProgramYear", programYear);
        log.info("MemberAssessmentHistory Last successful rundate batch size {} offset {}", batchSize, offset);
        return namedParameterJdbcTemplate.query(MEMBER_ASSESSMENT_HISTORY_LAST_RUN_DATE_PROVIDERGROUP_QUERY, sqlParameterSource, new BeanPropertyRowMapper<>(MemberAssessmentHistory.class));
    }

    @Override
    public List<MemberAssessmentHistory> getMemberAssessmentHistoryDetailsBasedOnLastJobRunDateRecordsByOffset(String providerGroupIds, Integer programYear) {
        SqlParameterSource sqlParameterSource = new MapSqlParameterSource("ProgramYear", programYear);
        String query=String.format(MEMBER_ASSESSMENT_HISTORY_LAST_RUN_DATE_QUERY_PROVIDERGROUP_QUERY_BATCH,providerGroupIds);
        return namedParameterJdbcTemplate.query(query, sqlParameterSource, new BeanPropertyRowMapper<>(MemberAssessmentHistory.class));
    }

    @Override
    public List<String> getProviderGroupDetailsForNewGroups(Integer programYear) {
        String query = String.format(PROVIDER_GROUP_NEW_GROUPS_QUERY, programYear, NEWGROUPS_MODIFIED_CONDITION);
        return namedParameterJdbcTemplate.queryForList(query, new HashMap<>(), String.class);
    }

    @Override
    public List<ProviderGroup> getProviderGroupDetailsBasedOnGroupIds(Integer programYear, String providerGroupIds) {
        String query = String.format(PROVIDER_GROUP_DETAILS_BASED_ON_IDS_QUERY, programYear, NEWGROUPS_MODIFIED_CONDITION, providerGroupIds);
        return namedParameterJdbcTemplate.query(query, new HashMap<>(), new BeanPropertyRowMapper<>(ProviderGroup.class));
    }
}
