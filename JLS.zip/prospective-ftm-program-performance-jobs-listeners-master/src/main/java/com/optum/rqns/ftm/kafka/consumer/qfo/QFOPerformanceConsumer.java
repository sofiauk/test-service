package com.optum.rqns.ftm.kafka.consumer.qfo;

import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.consumer.JobEventConsumer;
import com.optum.rqns.ftm.repository.common.CommonRepositoryImpl;
import com.optum.rqns.ftm.service.qfo.QFOPerformanceServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.context.annotation.Profile;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.annotation.TopicPartition;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;


@Profile("qfoPerfJobs")
@Component
@Slf4j
public class QFOPerformanceConsumer extends JobEventConsumer {

    public QFOPerformanceConsumer(final QFOPerformanceServiceImpl qfoPerformanceService, final CommonRepositoryImpl commonRepository) {
        super(qfoPerformanceService,commonRepository);
    }

    @KafkaListener(topicPartitions = {@TopicPartition(topic = "${spring.gcpkafka.properties.topics.jobEvent}", partitions = {"11"})},
            containerFactory = "jobEventKafkaListenerContainerFactory", autoStartup = "true")
    public void onMessage(ConsumerRecord<String, JobEvent> record, Acknowledgment acknowledgment) {
        log.info("{} Begin Consumer QFOPerformanceConsumer: {}", super.generateTransactionId (record), record);
        processMessage(11, record, acknowledgment);
    }
}






