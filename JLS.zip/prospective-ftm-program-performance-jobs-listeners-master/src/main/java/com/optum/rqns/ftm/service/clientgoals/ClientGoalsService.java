package com.optum.rqns.ftm.service.clientgoals;

import com.optum.rqns.ftm.service.IJob;
import org.springframework.stereotype.Service;

@Service
public interface ClientGoalsService extends IJob {
}
