package com.optum.rqns.ftm.model;

import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.Status;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.Setter;

@Builder
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor

public class JobRunConfiguration {
    @NonNull
    private JobName jobName;
    private String jobDescription;
    @NonNull
    Status status;
    String createdBy;
    String modifiedBy;
    String errorMessage;
    boolean updateJobStart;
    boolean updateJobEnd;
    boolean updateLastRun;
    boolean updateLastSuccessfulRun;
    boolean updateAffectedRows;
    @Builder.Default
    boolean updateErrorMessage = true;
    Long affectedRows;
    String messageKey;
    String message;
    String jobEvent;
    boolean updateMessageKey;
    boolean updateMessage;
    boolean updateJobEvent;
    boolean isActive;
}
