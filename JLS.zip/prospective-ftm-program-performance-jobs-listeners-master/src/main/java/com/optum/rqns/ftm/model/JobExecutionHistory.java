package com.optum.rqns.ftm.model;

import com.optum.rqns.ftm.enums.Status;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class JobExecutionHistory {
    @NotNull
    private Integer id;
    @NotNull
    private Integer jobID;
    private Status status;
    private String errorMessage;
    private Integer affectedRows;
    private LocalDateTime jobStart;
    private LocalDateTime jobEnd;
    private String jobEvent;
    private String message;
    private String messageKey;
}
