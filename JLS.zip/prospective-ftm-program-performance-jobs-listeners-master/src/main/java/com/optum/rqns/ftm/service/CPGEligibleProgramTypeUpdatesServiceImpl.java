package com.optum.rqns.ftm.service;

import com.fasterxml.uuid.Generators;
import com.optum.rqns.ftm.constants.CommonConstants;
import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.avro.models.v1.program.performance.provider.AdditionalProviderGroupStats;
import com.optum.rqns.ftm.kafka.avro.models.v1.program.performance.provider.ProgPerfProviderMSSync;
import com.optum.rqns.ftm.kafka.producer.KeyBasedProviderSyncProducer;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.model.providergroup.PAFXMemberData;
import com.optum.rqns.ftm.model.providergroup.ProviderGroup;
import com.optum.rqns.ftm.repository.CPGEligibleProgramTypeUpdatesRepository;
import com.optum.rqns.ftm.repository.common.CommonRepository;
import com.optum.rqns.ftm.util.JobUtilility;
import com.optum.rqns.ftm.util.ProgramPerformanceJobUtil;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.time.StopWatch;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

@Service
@Slf4j
public class CPGEligibleProgramTypeUpdatesServiceImpl implements CPGEligibleProgramTypeUpdatesService {

    private static final String COMMA_SPACE = ", ";
    private CPGEligibleProgramTypeUpdatesRepository cpgEligibleProgramTypeUpdatesRepository;
    private CommonRepository CommonRepository;
    private static final int BATCH_SIZE = 25000;

    @Value("${new_providergroup_rule_producer_thread_pool_size}")
    private int producerThreadPoolSize;

    @Autowired
    private KeyBasedProviderSyncProducer producer;

    public CPGEligibleProgramTypeUpdatesServiceImpl(CPGEligibleProgramTypeUpdatesRepository cpgEligibleProgramTypeUpdatesRepository,CommonRepository commonRepository) {
        this.cpgEligibleProgramTypeUpdatesRepository = cpgEligibleProgramTypeUpdatesRepository;
        this.CommonRepository= commonRepository;
    }

    public JobStatus executeJob(JobEvent jobEvent) {

        MDC.put(Constants.TRACE_ID, Generators.timeBasedGenerator().generate().toString());
        MDC.put(Constants.TRANSACTION_ID, ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
        MDC.put(Constants.MESSAGE_ID, ProgramPerformanceJobUtil.TransactionIdLogger.getMessageIdIdentifier());

        log.info("{} jobEvent.CPGEligibleProgramTypeUpdates() :: {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), jobEvent.getJobName());
        JobStatus jobStatus = new JobStatus();
        String joblastrunsuccessfuldate =  CommonRepository.getJobsLastRunSuccessfulDate(jobEvent.getJobName().toString());
        try {
            log.info("{} Received CPGEligibleProgramTypeUpdates message from topic : {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), jobEvent.getJobName());

            //ProviderGrouPExtended
            Long totalRowsUpdatedProviderGroupExtended = upsertEligibleProgramTypeProviderGroupExtended(jobEvent,joblastrunsuccessfuldate);
            log.info("{} ProviderGroupExtended total updated record count {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), totalRowsUpdatedProviderGroupExtended);

            //Sub Process for MemberAssessment and MemberAssessmentGap
            Long[] totalUpdatedRecords = memberAssessmentAndGapSubProcess(jobEvent,joblastrunsuccessfuldate);
            log.info("{} MemberAssessment total updated record count {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), totalUpdatedRecords[0]);
            log.info("{} MemberAssessmentGap total updated record count {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), totalUpdatedRecords[1]);



            //Generate final message and update in JobRunconfiguration
            String message = "Completed CPGEligibleProgramType job successfully. "
                    + ", MemberAssessment: "+totalUpdatedRecords[0]
                    + ", MemberAssessmentGap: "+totalUpdatedRecords[1]
                    + ", ProviderGroupExtended: "+totalRowsUpdatedProviderGroupExtended;

            jobStatus.setStatus(Status.SUCCESS);
            jobStatus.setMessage(message);
            jobStatus.setUpdatedRows(totalUpdatedRecords[0]+totalUpdatedRecords[1]+totalRowsUpdatedProviderGroupExtended);

        } catch (Exception e) {
            log.error("{} Exception while executing CPGEligibleProgramType job : {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), e);
            jobStatus.setStatus(Status.FAILURE);
            jobStatus.setMessage("CPGEligibleProgramType job execution failed : " + e.getMessage());
            jobStatus.setUpdatedRows(0L);
        } finally{
            MDC.clear();
        }
        return jobStatus;
    }

    /**
     * MemberAssessment and MemberAssessmentGap sub process for current program year
     * @return
     * @param jobEvent
     * @param joblastrunsuccessfuldate
     */
    private Long[] memberAssessmentAndGapSubProcess(JobEvent jobEvent, String joblastrunsuccessfuldate) {
        Long totalRowsUpdatedInMemberAssessment = 0l;
        Long totalRowsUpdatedInMemeberGap = 0l;

        final Long totalRows = cpgEligibleProgramTypeUpdatesRepository.getPafxMembersForCurrentProgramYearRecordCount(jobEvent.getProgramYear(),jobEvent.getGroupsToExecute().toString(),joblastrunsuccessfuldate);
        log.info("{} PAFXMeberAssessment Current Program Year record Count for MemberAssessment and Gap sub process {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), totalRows);

        List<Integer> batches = getBatches(totalRows);
        log.info("{} PAFXMeberAssessment Current Program Year Batches offsets are {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), batches.size());

        for (Integer offset : batches) {

            //Parallel process for MemberAssessment and MemberAssessmentGap
            Integer[] totalUpdatedRecords = executeParallelSubprocess(offset,jobEvent.getProgramYear(),jobEvent.getGroupsToExecute().toString(),joblastrunsuccessfuldate);

            totalRowsUpdatedInMemberAssessment = totalRowsUpdatedInMemberAssessment + totalUpdatedRecords[0];
            totalRowsUpdatedInMemeberGap = totalRowsUpdatedInMemeberGap + totalUpdatedRecords[1];
        }

        Long[] updatedRecordsForSubProcess = new Long[2];
        updatedRecordsForSubProcess[0] = totalRowsUpdatedInMemberAssessment;
        updatedRecordsForSubProcess[1] = totalRowsUpdatedInMemeberGap;

        return updatedRecordsForSubProcess;
    }

    /**
     * Execute Parallel process for MemberAssessment and MemberAssessmentGap
     * @param offset
     * @param programYear
     * @params
     * @param joblastrunsuccessfuldate
     * @return
     */
    private Integer[] executeParallelSubprocess(Integer offset, Integer programYear, String groupstoExecute, String joblastrunsuccessfuldate) {
        //For parallel producing
        ExecutorService executorService = Executors.newFixedThreadPool(2);
        List<Callable<Integer>> taskList = new ArrayList<>();

        //MemberAssessment
        taskList.add(() -> {
            return cpgEligibleProgramTypeUpdatesRepository.mergeMemberAssessmentData(BATCH_SIZE, offset,programYear,groupstoExecute,joblastrunsuccessfuldate);
        });

        //memberGap
        taskList.add(() -> {
            return cpgEligibleProgramTypeUpdatesRepository.mergeMemberGapData(BATCH_SIZE, offset,programYear,groupstoExecute,joblastrunsuccessfuldate);
        });

       return getUpdatedRowsWithParallelProcess(executorService, taskList);
    }

    /**
     * After executng parallel process get the results and update
     * @param executorService
     * @param taskList
     * @return
     */
    @SneakyThrows
    private Integer[] getUpdatedRowsWithParallelProcess(ExecutorService executorService, List<Callable<Integer>> taskList) {
        Integer[] updatedRows = new Integer[2];
        Integer totalrowupdatedInMemberAssessment = 0;
        Integer totalrowupdatedMemeberGap = 0;
        try {
            List<Future<Integer>> results = executorService.invokeAll(taskList);
            int count = 0;
            for (Future<Integer> f : results) {
                if (f != null && f.get() != null) {

                    if(count == 0){
                        totalrowupdatedInMemberAssessment = totalrowupdatedInMemberAssessment + f.get();

                    } else {
                        totalrowupdatedMemeberGap = totalrowupdatedMemeberGap + f.get();

                    }
                    count++;
                }
            }
            updatedRows[0] = totalrowupdatedInMemberAssessment;
            updatedRows[1] = totalrowupdatedMemeberGap;

        } catch (InterruptedException | ExecutionException e) {
            log.error("Error while  merging Idm data to performance table  ", e);
            throw e;
        } finally {
            taskList.clear();
            executorService.shutdown();
        }
        return updatedRows;
    }


    /**
     * UPSERT EligibleProgramType in ProviderGroupExtended based on PAFXMemberAssessment
     */
    private Long upsertEligibleProgramTypeProviderGroupExtended(JobEvent jobEvent, String joblastrunsuccessfuldate) {

        log.info("{} ProviderGroupExtended EligibleProgramType Start time :{}",ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), new Timestamp(System.currentTimeMillis()));

        JobUtilility jobUtilility = new JobUtilility();
        Integer programYear = jobEvent.getProgramYear();
        final Long totalRows = cpgEligibleProgramTypeUpdatesRepository.getPafxGroupsRecordCount(programYear, jobEvent.getGroupsToExecute().toString(), joblastrunsuccessfuldate);
        log.info("{} PAFXMeberAssessment Group By ProviderGroup,State,ProgramYear record Count {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), totalRows);

        List<Integer> batches = jobUtilility.getBatches(totalRows);
        log.info("{} PAFXMeberAssessment Group By ProviderGroup,State,ProgramYear Batches offsets are {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), batches.size());

        Long totalRowsUpdatedProviderGroupExtended = 0l;
        for (Integer offset : batches) {

            //For parallel producing
            ExecutorService executorService = Executors.newFixedThreadPool(producerThreadPoolSize);
            List<Callable<Boolean>> taskList = new ArrayList<>();

            List<PAFXMemberData> providerGroupList = cpgEligibleProgramTypeUpdatesRepository.getPafxProviderGroupIds(Constants.BATCH_SIZE, offset, programYear,jobEvent.getGroupsToExecute().toString(),joblastrunsuccessfuldate);
            String providerGroupIds = getProviderGroupIds(providerGroupList);

            //PAFXMemberAssessment fetch data
            List<PAFXMemberData> pafxMembers = cpgEligibleProgramTypeUpdatesRepository.getPafxMembersProgramTypeBasedOnGroups(providerGroupIds, programYear);

            //GroupBy with GroupId,state,ProgramYear with EligibleProgramType - PAFXMemberAssessment
            Map<String, String> pafxWithProgramTypeMap = pafxMembers.stream().collect(
                    Collectors.groupingBy(p ->(p.getProviderGroupId() + Constants.COMMA + p.getProviderState() + Constants.COMMA + p.getProgramYear()),
                            Collectors.mapping(p -> p.getEligibleProgType(), Collectors.joining(COMMA_SPACE))));
            log.info("PAFXMemberAssessment With EligibleProgramType Map ProviderGroups : {}", pafxWithProgramTypeMap.size());

            //ProviderGroupExtendedFetchData
            List<ProviderGroup> providerGroupsWithEligibleProgramTypes = cpgEligibleProgramTypeUpdatesRepository.getProviderGroupExtendedRecords(providerGroupIds, programYear);

            //GroupBy with GroupId,state,ProgramYear with EligibleProgramType - ProviderGroupExtended
            Map<String, String> providerGroupsWithProgramTypeMap = providerGroupsWithEligibleProgramTypes.stream()
                    .collect(Collectors.groupingBy(p ->(p.getProviderGroupId() + Constants.COMMA + p.getState() + Constants.COMMA + p.getProgramYear()),
                            Collectors.mapping(p -> p.getEligibleProgramType(), Collectors.joining(""))));

            log.info("ProviderGroups With EligibleProgramType Map ProviderGroups : {}", providerGroupsWithProgramTypeMap.size());

            List<Map<String, Object>> batchValues = new ArrayList<>();
            pafxWithProgramTypeMap.forEach(
                    (pafxMemberKey, pafxMemberEligibleProgramType) -> {

                        String pafxMemberEligibleProgramTypeValue = removeDuplicateProgramType(pafxMemberEligibleProgramType); //String.join(",", pafxMemberEligibleProgramType);
                        //Check both groups matches
                        if(providerGroupsWithProgramTypeMap.containsKey(pafxMemberKey)){

                            //Check ProgramType changed in PAFX -- then update else dont update and publish
                            if(!pafxMemberEligibleProgramTypeValue.equalsIgnoreCase(providerGroupsWithProgramTypeMap.get(pafxMemberKey))){
                                generateBatchValues(pafxMemberKey, batchValues, pafxMemberEligibleProgramTypeValue, taskList);
                            }
                        } else {
                            //ProviderGroup not in Extended table then insert
                            generateBatchValues(pafxMemberKey, batchValues, pafxMemberEligibleProgramTypeValue, taskList);
                        }

            });

            //UPSERT DB
            int[] updatedProviderGroupExtendedRecords = cpgEligibleProgramTypeUpdatesRepository.updateBatchQueries(batchValues);
            log.info("{} Updated ProviderGroupExtended records {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), updatedProviderGroupExtendedRecords.length);
            totalRowsUpdatedProviderGroupExtended = totalRowsUpdatedProviderGroupExtended + updatedProviderGroupExtendedRecords.length;

            // Producing Elements to Topic parallelly
            StopWatch stopWatch = StopWatch.createStarted();
            jobUtilility.producingElementsParallellyToTopic(executorService, taskList);
            stopWatch.stop();
            log.info("Time took for producing messages to kafka in ms is ::" + stopWatch.getTime() + " and rule is EligibleProgramType Service Impl::");

        }
        log.info("{} Total ProviderGroups Updated ProviderGroupExtended with Eligible ProgramType records {}",ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), totalRowsUpdatedProviderGroupExtended);
        log.info("{} ProviderGroupExtended EligibleProgramType End time :{}",ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), new Timestamp(System.currentTimeMillis()));

        return totalRowsUpdatedProviderGroupExtended;
    }

    /**
     * Remove duplicate word ex: IOA,CGAP & FLA,IOA final value --> IOA,CGAP,FLA
     * @param pafxMemberEligibleProgramType
     * @return
     */
    private String removeDuplicateProgramType(String pafxMemberEligibleProgramType) {
        //Sort in Ascending Order ex: CGAP, FLA, IOA or CGAP, IOA
        String sortedPafxMemberEligibleProgramType[] = pafxMemberEligibleProgramType.split(COMMA_SPACE);
        Arrays.sort(sortedPafxMemberEligibleProgramType);

        return Arrays.asList(sortedPafxMemberEligibleProgramType)
                .stream()
                .filter(s -> !s.equalsIgnoreCase("null"))
                .distinct()
                .collect(Collectors.joining(COMMA_SPACE));

    }

    /**
     * Generate Update record and publish message
     * @param pafxMemberKey
     * @param batchValues
     * @param pafxMemberEligibleProgramType
     * @param taskList
     */
    private void generateBatchValues(String pafxMemberKey, List<Map<String, Object>> batchValues, String pafxMemberEligibleProgramType, List<Callable<Boolean>> taskList) {

        String[] providerGroupStateProgramYearKey = pafxMemberKey.split(",");
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put("ProviderGroupID", providerGroupStateProgramYearKey[0]);
        paramMap.put("State", providerGroupStateProgramYearKey[1]);
        paramMap.put("ProgramYear", providerGroupStateProgramYearKey[2]);
        paramMap.put("EligibleProgramType",pafxMemberEligibleProgramType);
        paramMap.put("UpdatedBy","PAFDeployUpdate");

        //Publish message to topic
        taskList.add(() -> {
            return producer.postToKafka(buildProviderGroupOpportunitiesSummaryAvroV1(providerGroupStateProgramYearKey[0], providerGroupStateProgramYearKey[1], providerGroupStateProgramYearKey[2], pafxMemberEligibleProgramType),("EigibleProgramType" + "_" + providerGroupStateProgramYearKey[0] + providerGroupStateProgramYearKey[1] + providerGroupStateProgramYearKey[2]));
        });
        batchValues.add(paramMap);
    }

    /**
     * Build Provider MS message
     * @param providerGroupId
     * @param state
     * @param programYear
     * @param providerGroupEligibleProgramType
     * @return
     */
    private ProgPerfProviderMSSync buildProviderGroupOpportunitiesSummaryAvroV1(String providerGroupId, String state, String programYear, String providerGroupEligibleProgramType) {

        AdditionalProviderGroupStats additionalProviderGroupStats = new AdditionalProviderGroupStats();
        additionalProviderGroupStats.setEligibleProgramType(providerGroupEligibleProgramType);

        ProgPerfProviderMSSync summaryAvroMessage = new ProgPerfProviderMSSync();
        summaryAvroMessage.setProviderGroupID(providerGroupId);
        summaryAvroMessage.setProviderGroupName(CommonConstants.DEFAULE_STRING_VALUE);
        summaryAvroMessage.setState(state);
        summaryAvroMessage.setProgramYear(Integer.parseInt(programYear));
        summaryAvroMessage.setAdditionalProviderGroupStats(additionalProviderGroupStats);
        summaryAvroMessage.setMessageType(Constants.ADDITIONAL_PROVIDERGROUP_STATS_MESSAGE_TYPE);

        return summaryAvroMessage;
    }

    /**
     * Get ProviderGroupIds
     * @param pafxMembers
     * @return
     */
    private String getProviderGroupIds(List<PAFXMemberData> pafxMembers) {
        return pafxMembers.stream().map(m -> ("'" + m.getProviderGroupId()) + "'")
                .collect(Collectors.joining(","));
    }

    private List<Integer> getBatches(Long totalRows) {
        List<Integer> batches = new ArrayList<>();
        if (totalRows > 0) {
            for (int batchOffset = 0; batchOffset <= totalRows; batchOffset += BATCH_SIZE) {
                batches.add(batchOffset);
            }
        }
        return batches;
    }

}
