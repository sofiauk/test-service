package com.optum.rqns.ftm.repository.jobalerts;

import com.optum.rqns.ftm.model.JobAlert;

import java.util.List;

public interface MonitoringJobRepository {
    List<JobAlert> getLongRunningJobs();
}
