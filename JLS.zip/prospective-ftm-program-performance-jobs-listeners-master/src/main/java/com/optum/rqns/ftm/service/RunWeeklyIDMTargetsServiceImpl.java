package com.optum.rqns.ftm.service;

import com.fasterxml.uuid.Generators;
import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.producer.JobEventProducer;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.repository.RunWeeklyIDMTargetsRepository;
import com.optum.rqns.ftm.util.ProgramPerformanceJobUtil;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

@Service
@Slf4j
public class RunWeeklyIDMTargetsServiceImpl implements RunWeeklyIDMTargetsService {

    private RunWeeklyIDMTargetsRepository runWeeklyIDMTargetsRepository;

    private static final int BATCH_SIZE = 25000;

    @Autowired
    private JobEventProducer jobEventProducer;

    @Value("${spring.db_connection_thread_pool_size}")
    private int dbConnectionThreadPoolSize;

    public RunWeeklyIDMTargetsServiceImpl(RunWeeklyIDMTargetsRepository runWeeklyIDMTargetsRepository){
     this.runWeeklyIDMTargetsRepository = runWeeklyIDMTargetsRepository;
    }

    @Override
    public JobStatus executeJob(JobEvent jobEvent) {
        MDC.put(Constants.TRACE_ID, Generators.timeBasedGenerator().generate().toString());
        MDC.put(Constants.TRANSACTION_ID, ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
        MDC.put(Constants.MESSAGE_ID, ProgramPerformanceJobUtil.TransactionIdLogger.getMessageIdIdentifier());

        log.info("jobEvent.RunWeeklyIdmTargets() :: {}", jobEvent.getJobName());
        JobStatus jobStatus = new JobStatus();

        try {
            log.info("Received RunWeeklyIdmTargets message from topic : {}", jobEvent.getJobName());

            final Long totalRows = this.runWeeklyIDMTargetsRepository.getRecordCount(jobEvent.getProgramYear());
            log.info("record Count {}", totalRows);

            List<Integer> batches = getBatches(totalRows);
            log.info("total Batches offsets are {}", batches);
            ExecutorService executorService = Executors.newFixedThreadPool(dbConnectionThreadPoolSize);
            List<Callable<Integer>> taskList = new ArrayList<>();

            batches.forEach(batchOffset -> taskList.add(this.runWeeklyIDMTargetsRepository
                    .mergeData(BATCH_SIZE, batchOffset,jobEvent.getProgramYear())));
            final long totalUpdatedRecords = executeQueries(executorService, taskList);
            log.info("total updated record count {}", totalUpdatedRecords);

            jobStatus.setStatus(Status.SUCCESS);
            jobStatus.setMessage("Completed RunWeeklyIdmTargets job successfully");
            jobStatus.setUpdatedRows(totalUpdatedRecords);

        } catch (Exception e) {
            log.error("Exception while executing RunWeeklyIdmTargets job : {}", e);
            jobStatus.setStatus(Status.FAILURE);
            jobStatus.setMessage("RunWeeklyIdmTargets job execution failed : " + e.getMessage());
            jobStatus.setUpdatedRows(0L);
        } finally{

            MDC.clear();
        }
        return jobStatus;
    }

    @SneakyThrows
    private long executeQueries(ExecutorService executorService, List<Callable<Integer>> taskList) {
        long totalCount = 0;
        try {
            List<Future<Integer>> results = executorService.invokeAll(taskList);
            for (Future<Integer> f : results) {
                if (f != null && f.get() != null) {
                    totalCount += f.get();
                }
            }
        } catch (InterruptedException | ExecutionException e) {
            log.error("Error while  merging deploy return target data to performance table weekly  ", e);
            throw e;
        } finally {
            taskList.clear();
            executorService.shutdown();
        }
        return totalCount;
    }

    private List<Integer> getBatches(Long totalRows) {
        List<Integer> batches = new ArrayList<>();
        if (totalRows > 0) {
            for (int batchOffset = 0; batchOffset <= totalRows; batchOffset += BATCH_SIZE) {
                batches.add(batchOffset);
            }
        }
        return batches;
    }


}
