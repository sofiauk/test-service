package com.optum.rqns.ftm.repository;

import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.Map;

@Repository
@Slf4j
public class PAFxMemberAssessmentStagingRepositoryImpl implements PAFxMemberAssessmentStagingRepository {

    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    public PAFxMemberAssessmentStagingRepositoryImpl(NamedParameterJdbcTemplate namedParameterJdbcTemplate){
        this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
    }

    public final String MODIFIED_CONDITION = " AND UpdatedDate >= (select LastSuccessfulRunDate " +
            " from ProgPerf.jobrunconfiguration where jobname = '" + JobName.RUN_PAFX_MEMBER_ASSESSMENT_STAGING.getValue() + "')";

    public final String COUNT_QUERY = "SELECT   " +
            "count(*) as totalCount  " +
            "FROM   " +
            "ProgPerf.Stage_PafExMemberAssessment with (NOLOCK)  where ProgramYear=:ProgramYear  " +
            " :MODIFIED " ;

    public final String MERGE_QUERY = "MERGE INTO ProgPerf.PafExMemberAssessment AS tgt USING (Select  " +
            " HicNumber, ClientId, ClientName, Lob, LobName,ProviderGroupId, ProviderId,ProviderState, " +
            "  ProviderGroupName,GlobalMemberId,ProgramYear,SuppressionReason, IsSuppressed, IsOnShore, " +
            "  FirstName, MiddleName, LastName, Cpg, GroupType, ProviderMemberReimbType, " +
            "  ClientMemberId, ValidationStatus, OptumAssignedGroupId, IsProviderAssociated, AssociationValidFrom, " +
            "  AssociationValidTo, IsDeployed, RecordStatus, SubClientSK, RunId, CreatedBy, UpdatedBy, " +
            "  CreatedDate,UpdatedDate, PafMasterUpdatedDate, ProviderAssociationUpdatedDate, PafxMemberUpdatedDate, " +
            "  HealthPlanName, Phone, Address1, Address2, City, State, Zip, " +
            "  Gender, BirthDate, EnrolEffectDate, EnrolEndDate, MemContractNumber, Pbp, PreferredMbrReimbType, " +
            "  AssignedProvId, AssignedGroupId, AssignedGroupType, AssignedGroupName, AssignedProvState, AssignedMbrReimbType, " +
            "  AssignedProviderName, RenderedProviderName, EligibleProgramType, deployableSource, deployableStatus, " +
            "  RenderedProvId, RenderedGroupId, RenderedGroupType, RenderedGroupName, RenderedProvState, RenderedMbrReimbType, " +
            "  MbrReimbType, MbrPopType, ProductName, ProviderOverride, deployableEligibilityReason,deployed, edataDeployed, " +
            "  AssignedSuppFlag, AssignedSuppReason, RenderedSuppFlag, RenderedSuppReason, deployableTs, deployableWOTollgate, " +
            "  FlaAssignedSuppFlag, FlaAssignedSuppReason, FlaPreferredSuppFlag, FlaPreferredSuppReason, FlaRenderedSuppFlag, FlaRenderedSuppReason, " +
            "  edataFirstDeployedTs, edataLatestDeployedTs, firstChannel, firstDeployableTs, " +
            "  firstDeployedTs, latestChannel, latestDeployedTs, paDeployed, pafgenDeployed, pafgenFirstDeployedTs, pafgenLatestDeployedTs, " +
            "  paFirstDeployedTs, paLatestDeployedTs, paProvisioned, provAssocStatus, provAssocStatusTs, pumaProvisioned, tollgatePauseStatus, " +
            "  tollgatePauseStatusTs, PafxClientName  from ProgPerf.Stage_PafExMemberAssessment pafx  " +
            "  where ProgramYear = :ProgramYear " +
            "  :MODIFIED " +
            "  order by id " +
            "  OFFSET :offset ROWS FETCH NEXT :batchsize ROWS ONLY " +
            ") " +
            "  AS src  " +
            "  ON ( " +
            "   tgt.ProgramYear = src.ProgramYear " +
            "   AND tgt.Lob=src.Lob  " +
            "   AND tgt.ClientId=src.ClientId " +
            "   AND tgt.SubClientSk = src.SubClientSK " +
            "   AND tgt.GlobalMemberId = src.GlobalMemberId ) " +
            "   WHEN MATCHED THEN UPDATE " +
            "   SET tgt.HicNumber=src.HicNumber, tgt.ClientId=src.ClientId, tgt.Lob=src.Lob, tgt.ClientName = src.ClientName, " +
            "       tgt.LobName=src.LobName, tgt.ProviderGroupId=src.ProviderGroupId,tgt.ProviderState = src.ProviderState, tgt.ProviderId=src.ProviderId, " +
            "       tgt.PafxClientName = src.PafxClientName,  " +
            "       tgt.ProviderGroupName=src.ProviderGroupName,  tgt.GlobalMemberId=src.GlobalMemberId,tgt.ProgramYear=src.ProgramYear,tgt.SuppressionReason=src.SuppressionReason, tgt.IsSuppressed=src.IsSuppressed, tgt.IsOnShore=src.IsOnShore, " +
            "       tgt.FirstName=src.FirstName, tgt.MiddleName=src.MiddleName, tgt.LastName=src.LastName, tgt.Cpg=src.Cpg, tgt.GroupType=src.GroupType, tgt.ProviderMemberReimbType=src.ProviderMemberReimbType, " +
            "       tgt.ClientMemberId=src.ClientMemberId, tgt.ValidationStatus=src.ValidationStatus, tgt.OptumAssignedGroupId = src.OptumAssignedGroupId, tgt.IsProviderAssociated=src.IsProviderAssociated, tgt.AssociationValidFrom=src.AssociationValidFrom, " +
            "       tgt.AssociationValidTo=src.AssociationValidTo, tgt.IsDeployed=src.IsDeployed, tgt.RecordStatus=src.RecordStatus, tgt.SubClientSK=src.SubClientSK, tgt.RunId=src.RunId, tgt.CreatedBy=src.CreatedBy, tgt.UpdatedBy= 'PAFXMemberJOB', " +
            "       tgt.UpdatedDate = GETUTCDATE(),tgt.PafxMemberUpdatedDate =  src.PafxMemberUpdatedDate, " +
            "       tgt.PafMasterUpdatedDate = src.PafMasterUpdatedDate, tgt.ProviderAssociationUpdatedDate = src.ProviderAssociationUpdatedDate, " +
            "       tgt.HealthPlanName=src.HealthPlanName, tgt.Phone=src.Phone, tgt.Address1=src.Address1, tgt.Address2=src.Address2, tgt.City=src.City, tgt.State=src.State, tgt.Zip=src.Zip, " +
            "       tgt.Gender=src.Gender, tgt.BirthDate=src.BirthDate, tgt.EnrolEffectDate=src.EnrolEffectDate, tgt.EnrolEndDate=src.EnrolEndDate, tgt.MemContractNumber=src.MemContractNumber, tgt.Pbp=src.Pbp, tgt.PreferredMbrReimbType=src.PreferredMbrReimbType, " +
            "       tgt.AssignedProvId=src.AssignedProvId, tgt.AssignedGroupId=src.AssignedGroupId, tgt.AssignedGroupType=src.AssignedGroupType, tgt.AssignedGroupName=src.AssignedGroupName, tgt.AssignedProvState=src.AssignedProvState, tgt.AssignedMbrReimbType=src.AssignedMbrReimbType, " +
            "       tgt.AssignedProviderName = src.AssignedProviderName, tgt.RenderedProviderName = src.RenderedProviderName, tgt.EligibleProgramType = src.EligibleProgramType, tgt.deployableSource = src.deployableSource, tgt.deployableStatus = src.deployableStatus, " +
            "       tgt.RenderedProvId=src.RenderedProvId, tgt.RenderedGroupId=src.RenderedGroupId, tgt.RenderedGroupType=src.RenderedGroupType, tgt.RenderedGroupName=src.RenderedGroupName, tgt.RenderedProvState=src.RenderedProvState, tgt.RenderedMbrReimbType=src.RenderedMbrReimbType, " +
            "       tgt.MbrReimbType=src.MbrReimbType, tgt.MbrPopType=src.MbrPopType, tgt.ProductName=src.ProductName, tgt.ProviderOverride=src.ProviderOverride, tgt.deployableEligibilityReason = src.deployableEligibilityReason, tgt.deployed = src.deployed, tgt.edataDeployed = src.edataDeployed, " +
            "       tgt.AssignedSuppFlag=src.AssignedSuppFlag, tgt.AssignedSuppReason=src.AssignedSuppReason, tgt.RenderedSuppFlag=src.RenderedSuppFlag, tgt.RenderedSuppReason=src.RenderedSuppReason, tgt.deployableTs = src.deployableTs, tgt.deployableWOTollgate = src.deployableWOTollgate, " +
            "       tgt.FlaAssignedSuppFlag=src.FlaAssignedSuppFlag, tgt.FlaAssignedSuppReason=src.FlaAssignedSuppReason, tgt.FlaPreferredSuppFlag=src.FlaPreferredSuppFlag, tgt.FlaPreferredSuppReason=src.FlaPreferredSuppReason, tgt.FlaRenderedSuppFlag=src.FlaRenderedSuppFlag, tgt.FlaRenderedSuppReason=src.FlaRenderedSuppReason " +
            "        ,  " +
            "        tgt.edataFirstDeployedTs = src.edataFirstDeployedTs, tgt.edataLatestDeployedTs = src.edataLatestDeployedTs,tgt.firstChannel = src.firstChannel, " +
            "        tgt.firstDeployableTs = src.firstDeployableTs, tgt.firstDeployedTs = src.firstDeployedTs, tgt.latestChannel = src.latestChannel, tgt.latestDeployedTs = src.latestDeployedTs, " +
            "        tgt.paDeployed = src.paDeployed, tgt.pafgenDeployed = src.pafgenDeployed, tgt.pafgenFirstDeployedTs = src.pafgenFirstDeployedTs, tgt.pafgenLatestDeployedTs = src.pafgenLatestDeployedTs, " +
            "        tgt.paFirstDeployedTs = src.paFirstDeployedTs, tgt.paLatestDeployedTs = src.paLatestDeployedTs, tgt.paProvisioned  = src.paProvisioned, tgt.provAssocStatus = src.provAssocStatus, " +
            "        tgt.provAssocStatusTs = src.provAssocStatusTs, tgt.pumaProvisioned = src.pumaProvisioned, tgt.tollgatePauseStatus = src.tollgatePauseStatus, " +
            "        tgt.tollgatePauseStatusTs = src.tollgatePauseStatusTs " +
            "        WHEN NOT MATCHED THEN " +
            "       INSERT (HicNumber, ClientId, Lob, LobName, ProviderGroupId, ProviderGroupName,ProviderState, " +
            "        PafxClientName, ClientName, " +
            "        ProviderId,GlobalMemberId,ProgramYear,SuppressionReason, IsSuppressed, IsOnShore, " +
            "        FirstName, MiddleName, LastName, Cpg, GroupType, ProviderMemberReimbType, " +
            "        ClientMemberId, ValidationStatus, IsProviderAssociated, AssociationValidFrom, " +
            "        AssociationValidTo, IsDeployed, RecordStatus, SubClientSK, RunId, CreatedBy, CreatedDate, PafxMemberUpdatedDate, " +
            "        HealthPlanName, Phone, Address1, Address2, City, State, Zip, " +
            "        Gender, BirthDate, EnrolEffectDate, EnrolEndDate, MemContractNumber, Pbp, PreferredMbrReimbType, " +
            "        AssignedProvId, AssignedGroupId, AssignedGroupType, AssignedGroupName, AssignedProvState, AssignedMbrReimbType,  " +
            "        RenderedProvId, RenderedGroupId, RenderedGroupType, RenderedGroupName, RenderedProvState, RenderedMbrReimbType,  " +
            "        MbrReimbType, MbrPopType, ProductName, ProviderOverride, " +
            "        AssignedSuppFlag, AssignedSuppReason, RenderedSuppFlag, RenderedSuppReason, " +
            "        FlaAssignedSuppFlag, FlaAssignedSuppReason, FlaPreferredSuppFlag, FlaPreferredSuppReason, FlaRenderedSuppFlag, FlaRenderedSuppReason " +
//            "       , MemberChangedFromIHA, MemberChangedFromIHADate " +
//            "       , HsClientId, ClientType, PayerId " +
            "      ,OptumAssignedGroupId, UpdatedBy,  UpdatedDate,  PafMasterUpdatedDate, ProviderAssociationUpdatedDate, " +
            "      AssignedProviderName, RenderedProviderName, EligibleProgramType, deployableSource, deployableStatus, " +
            "      deployableEligibilityReason, deployed, edataDeployed , deployableTs, deployableWOTollgate, " +
            "      edataFirstDeployedTs, edataLatestDeployedTs, firstChannel, firstDeployableTs, " +
            "      firstDeployedTs, latestChannel, latestDeployedTs, paDeployed, pafgenDeployed, pafgenFirstDeployedTs, pafgenLatestDeployedTs, " +
            "      paFirstDeployedTs, paLatestDeployedTs, paProvisioned, provAssocStatus, provAssocStatusTs, pumaProvisioned, tollgatePauseStatus, " +
            "      tollgatePauseStatusTs " +
            "        ) " +
            "      VALUES " +
            "        (src.HicNumber, src.ClientId, src.Lob, src.LobName, src.ProviderGroupId, src.ProviderGroupName,src.ProviderState, " +
            "        src.PafxClientName, src.ClientName, " +
            "        src.ProviderId,src.GlobalMemberId, src.ProgramYear,src.SuppressionReason, src.IsSuppressed, src.IsOnShore, " +
            "        src.FirstName, src.MiddleName, src.LastName, src.Cpg, src.GroupType, src.ProviderMemberReimbType,  " +
            "        src.ClientMemberId, src.ValidationStatus, src.IsProviderAssociated, src.AssociationValidFrom, " +
            "        src.AssociationValidTo, src.IsDeployed, src.RecordStatus, src.SubClientSK, src.RunId, 'PAFXMemberJOB', GETUTCDATE(),  GETUTCDATE(), " +
            "        src.HealthPlanName, src.Phone, src.Address1, src.Address2, src.City, src.State, src.Zip, " +
            "        src.Gender, src.BirthDate, src.EnrolEffectDate, src.EnrolEndDate, src.MemContractNumber, src.Pbp, src.PreferredMbrReimbType, " +
            "        src.AssignedProvId, src.AssignedGroupId, src.AssignedGroupType, src.AssignedGroupName, src.AssignedProvState, src.AssignedMbrReimbType,  " +
            "        src.RenderedProvId, src.RenderedGroupId, src.RenderedGroupType, src.RenderedGroupName, src.RenderedProvState, src.RenderedMbrReimbType,  " +
            "        src.MbrReimbType, src.MbrPopType, src.ProductName, src.ProviderOverride, " +
            "        src.AssignedSuppFlag, src.AssignedSuppReason, src.RenderedSuppFlag, src.RenderedSuppReason, " +
            "        src.FlaAssignedSuppFlag, src.FlaAssignedSuppReason, src.FlaPreferredSuppFlag, src.FlaPreferredSuppReason, src.FlaRenderedSuppFlag, src.FlaRenderedSuppReason " +
            "        , src.OptumAssignedGroupId, 'PAFXMemberJOB', GETUTCDATE(), src.PafMasterUpdatedDate, src.ProviderAssociationUpdatedDate," +
            "        src.AssignedProviderName, src.RenderedProviderName, src.EligibleProgramType, src.deployableSource, src.deployableStatus, " +
            "        src.deployableEligibilityReason, src.deployed, src.edataDeployed, src.deployableTs, src.deployableWOTollgate, " +
            "        src.edataFirstDeployedTs, src.edataLatestDeployedTs, src.firstChannel, src.firstDeployableTs, " +
            "        src.firstDeployedTs, src.latestChannel, src.latestDeployedTs, src.paDeployed, src.pafgenDeployed, src.pafgenFirstDeployedTs, src.pafgenLatestDeployedTs, " +
            "        src.paFirstDeployedTs, src.paLatestDeployedTs, src.paProvisioned, src.provAssocStatus, src.provAssocStatusTs, src.pumaProvisioned, src.tollgatePauseStatus, " +
            "        src.tollgatePauseStatusTs " +
            "        );";

    @Override
    public Long getRecordCount(JobEvent jobEvent) {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put( Constants.PROGRAM_YEAR, jobEvent.getProgramYear());
        String query;
        if (Constants.ALL.equalsIgnoreCase(jobEvent.getGroupsToExecute().toString()) ) {
            query = COUNT_QUERY.replace(Constants.LAST_MODIFIED,Constants.EMPTY);
        } else {
            query = COUNT_QUERY.replace(Constants.LAST_MODIFIED,MODIFIED_CONDITION);
        }
        return namedParameterJdbcTemplate.queryForObject(query, paramMap, Long.class);
    }

    @Override
    public Integer mergePAFxMemberAssessmentData(JobEvent jobEvent, Integer offset, int batchSize) {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put( Constants.PROGRAM_YEAR, jobEvent.getProgramYear());
        paramMap.put("batchsize",batchSize);
        paramMap.put("offset",offset);
        String query;
        if (Constants.ALL.equalsIgnoreCase(jobEvent.getGroupsToExecute().toString()) ) {
            query = MERGE_QUERY.replace(Constants.LAST_MODIFIED,Constants.EMPTY);
        } else {
            query = MERGE_QUERY.replace(Constants.LAST_MODIFIED,MODIFIED_CONDITION);
        }
        return namedParameterJdbcTemplate.update(query, paramMap);
    }
}
