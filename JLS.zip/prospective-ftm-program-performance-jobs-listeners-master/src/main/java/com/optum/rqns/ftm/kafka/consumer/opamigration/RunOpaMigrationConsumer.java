package com.optum.rqns.ftm.kafka.consumer.opamigration;

import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.consumer.JobEventConsumer;
import com.optum.rqns.ftm.repository.common.CommonRepository;
import com.optum.rqns.ftm.repository.opamigration.OPAMigrationRepositoryImpl;
import com.optum.rqns.ftm.service.IJob;
import com.optum.rqns.ftm.service.opamigration.OPAMigrationServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.context.annotation.Profile;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.annotation.TopicPartition;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

@Profile("opaMigrationJobs")
@Component
@Slf4j
public class RunOpaMigrationConsumer extends JobEventConsumer {
    public RunOpaMigrationConsumer(final OPAMigrationServiceImpl opaMigrationService, CommonRepository commonRepository) {
        super(opaMigrationService, commonRepository);
    }

    @KafkaListener(topicPartitions = {@TopicPartition(topic = "${spring.gcpkafka.properties.topics.jobEvent}", partitions = {"34"})},
            containerFactory = "jobEventKafkaListenerContainerFactory", autoStartup = "true")
    public void onMessage(ConsumerRecord<String, JobEvent> record, Acknowledgment acknowledgment) {
        log.info("{} Begin Consumer OpaMigrationConsumer: {}", super.generateTransactionId (record), record);
        processMessage(34, record, acknowledgment);
    }
}
