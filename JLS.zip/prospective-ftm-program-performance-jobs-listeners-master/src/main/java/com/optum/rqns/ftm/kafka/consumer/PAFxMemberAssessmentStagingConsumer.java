package com.optum.rqns.ftm.kafka.consumer;

import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.repository.common.CommonRepositoryImpl;
import com.optum.rqns.ftm.service.IJob;
import com.optum.rqns.ftm.service.PAFxMemberAssessmentStagingServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.context.annotation.Profile;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.annotation.TopicPartition;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

@Profile("pafxDeployUpdate")
@Component
@Slf4j
public class PAFxMemberAssessmentStagingConsumer extends  JobEventConsumer {
    public PAFxMemberAssessmentStagingConsumer(PAFxMemberAssessmentStagingServiceImpl paFxMemberAssessmentStagingService, CommonRepositoryImpl commonRepository) {
        super(paFxMemberAssessmentStagingService, commonRepository);
    }

    @KafkaListener(topicPartitions = {@TopicPartition(topic = "${spring.gcpkafka.properties.topics.jobEvent}", partitions = {"55"})},
            containerFactory = "jobEventKafkaListenerContainerFactory", autoStartup = "true")
    public void onMessage(ConsumerRecord<String, JobEvent> record, Acknowledgment acknowledgment) {
        log.info("{} Begin Consumer StagingDataToPafxMemberAssessment : {}", super.generateTransactionId (record), record);
        processMessage(55, record, acknowledgment);
    }
}
