package com.optum.rqns.ftm.model.qfo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.time.LocalDateTime;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class QFOPatientExperienceScore {

    private String providerGroupId;
    private int programYear;
    private Float gncRate;
    private Float cooRate;
    private Float dpcRate;
    private LocalDateTime createdDate;
    private LocalDateTime updatedDate;
}