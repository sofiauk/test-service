package com.optum.rqns.ftm.model.practiceassist;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class PaAggregationData {

	private int programYear;
	private String clientId;
	private int subClientSk;
	private String healthSystemId;
	private String providerGroupId;
	private String providerState;
	private String providerId;
	private boolean isActive;

	private int returnActionNeededCount;
	private int memberOpportunityCount;
	private int a1CCount;
	private int omwCount;
	
	private String updatedBy;
	private String createdBy;
	
	private int newPatient30Count;
	private int NewPatient7Count;
	private int NewPatient90Count;
	private int HighPriorityCount;
	private int noCurrFluVaccCount;

	private String rowAction;
	private LocalDateTime latestUpdatedDate;
	private String teamType;
	private int notAssessedCount;
	
	private int rxFillOppurtunityCount;
	private int absFailDateCount;
	private int annualCareVisitNotCompleteCount;
	
	private int recentDischarge3Count;
	private int recentDischarge7Count;
	private int recentDischarge30Count;

	private String providerGroupName;
	private String preferredProviderState;

}
