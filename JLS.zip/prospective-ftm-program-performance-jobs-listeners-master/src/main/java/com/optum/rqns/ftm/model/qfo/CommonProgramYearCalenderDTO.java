package com.optum.rqns.ftm.model.qfo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import java.time.LocalDate;

@Data
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CommonProgramYearCalenderDTO {
    private Long id;
    private String durationType;
    private String durationValue;
    private LocalDate startDate;
    private LocalDate endDate;
    private int programYear;
    private String currentMonth;
}

