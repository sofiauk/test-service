package com.optum.rqns.ftm.repository.fieldactionrules;

/*
    This package consists of  repository classes  for work queue rules.
 */