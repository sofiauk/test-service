package com.optum.rqns.ftm.service.jobalerts;

import com.optum.rqns.ftm.model.JobAlert;
import io.micrometer.core.instrument.search.MeterNotFoundException;
import org.springframework.stereotype.Service;

@Service
public interface PrometheusJobAlertService {

    /**
     * This service will return the status of FTM Custom Job Alerts whether alerting has been successful or not
     *
     * @return String
     */

    String sendAlerts(JobAlert jobAlert) throws MeterNotFoundException;
}
