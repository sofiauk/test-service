package com.optum.rqns.ftm.repository.qfo;

import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.model.qfo.QFOPatientExperienceScore;
import com.optum.rqns.ftm.util.ProgramPerformanceJobUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;

@Slf4j
@Repository
public class QFOPatientExperienceScoresRepositoryImpl implements QFOPatientExperienceScoresRepository {

    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    public QFOPatientExperienceScoresRepositoryImpl(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
        this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
    }

    private static final String FETCH_TOTAL_PATIENT_EXPERIENCE_SCORE = "SELECT " +
            " HEALTHORGID AS ProviderGroupId, " +
            " PROGRAMYEAR AS ProgramYear, " +
            " GNCRATE AS GncRate, " +
            " COORATE AS CooRate, " +
            " DPCRATE AS DpcRate, " +
            " CreatedDate AS CreatedDate, " +
            " UpdatedDate AS UpdatedDate " +
            "FROM " +
            " ProgPerf.PATIENTEXPERIENCESCORE PES " +
            "WHERE " +
            " HEALTHORGIDTYPE = 'PG' " +
            " AND RPT_MO_KEY =( " +
            " SELECT " +
            "  max(RPT_MO_KEY) " +
            " FROM " +
            "  ProgPerf.PATIENTEXPERIENCESCORE WHERE HEALTHORGIDTYPE = 'PG' )  " +
            " %s ";

    private static final String FETCH_BATCHWISE_PATIENT_EXPERIENCE_SCORE = FETCH_TOTAL_PATIENT_EXPERIENCE_SCORE + " ORDER BY ProgramYear offset :OFFSET rows FETCH next :BatchSize rows only";

    private static final String RECORD_COUNT_QUERY = "SELECT count(*) as recCount FROM (" + FETCH_TOTAL_PATIENT_EXPERIENCE_SCORE + ") AS QFOPatientExperienceScores";

    private static final String MODIFIED_CONDITION = "AND  CAST(UpdatedDate as date) >= (select CAST(LastSuccessfulRunDate as date)" +
            " from ProgPerf.jobrunconfiguration where jobname= '" + JobName.QFO_PATIENT_EXPERIENCE_SCORES.getValue() + "')";



    @Override
    public List<QFOPatientExperienceScore> fetchQFOPatientExperienceScores(int batchSize, Integer batchOffset, JobEvent jobEvent) {
        String fetchPatientExperienceScores=null;
        if(Constants.ALL.equalsIgnoreCase(jobEvent.getGroupsToExecute().toString())) {
            log.info("{} : Fetching fot All scenario for RunQFOPatientExperienceScores Job", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
            fetchPatientExperienceScores = String.format(FETCH_BATCHWISE_PATIENT_EXPERIENCE_SCORE,"");


        } else {
            log.info("{} : Fetching fot Modified scenario for RunQFOPatientExperienceScores Job", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
            fetchPatientExperienceScores = String.format(FETCH_BATCHWISE_PATIENT_EXPERIENCE_SCORE,MODIFIED_CONDITION);

        }

        SqlParameterSource sqlParameterSource = new MapSqlParameterSource("BatchSize", batchSize).addValue("OFFSET", batchOffset);

        log.info("batchsize {} offset {}", batchSize, batchOffset);
        log.info("{} :sql query ", fetchPatientExperienceScores);

        return namedParameterJdbcTemplate.query(fetchPatientExperienceScores, sqlParameterSource, new BeanPropertyRowMapper<>(QFOPatientExperienceScore.class));


    }

    @Override
    public Long getRecordCount(JobEvent jobEvent) {
        String fetchPatientExperienceScores=null;
        if(Constants.ALL.equalsIgnoreCase(jobEvent.getGroupsToExecute().toString())) {
            log.info("{} : Fetching fot All scenario  records count for RunQFOPatientExperienceScoresJob",
                    ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
            fetchPatientExperienceScores = String.format(RECORD_COUNT_QUERY,"");

        } else {
            log.info("{} : Fetching fot Modified scenario  records count RunQFOPatientExperienceScores Job", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
            fetchPatientExperienceScores = String.format(RECORD_COUNT_QUERY,MODIFIED_CONDITION);
        }
        return namedParameterJdbcTemplate.queryForObject(fetchPatientExperienceScores, new HashMap<>(), Long.class);
    }


}






