package com.optum.rqns.ftm.repository.common;

import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.model.JobConfiguration;
import com.optum.rqns.ftm.model.JobConfigurationRequest;
import com.optum.rqns.ftm.model.JobRunConfiguration;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.model.ProgramYearCalendarDTO;
import com.optum.rqns.ftm.model.qfo.CommonProgramYearCalenderDTO;
import com.optum.rqns.ftm.util.ProgramPerformanceJobUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.assertj.core.util.VisibleForTesting;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.ArrayList;

@Repository
@Slf4j
public class CommonRepositoryImpl implements CommonRepository {

    private static final String INSERT_QUERY = "insertQuery";
    private static final String ROWS_UPDATE = "rowsUpdate";
    private static final String JOB_NAME = "JOB_NAME";

    public enum ColumnNames {
        JOB_NAME("JobName"),
        JOB_DESCRIPTION("JobDescription"),
        LAST_RUN_DATE("LastRunDate"),
        STATUS("Status"),
        JOB_START("JobStart"),
        JOB_END("JobEnd"),
        LAST_SUCCESSFUL_RUN_DATE("LastSuccessfulRunDate"),
        AFFECTED_ROWS("AffectedRows"),
        MODIFIED_BY("ModifiedBy"),
        ERROR_MESSAGE("errorMessage"),
        JOB_EVENT("jobEvent"),
        MESSAGE_KEY("messageKey"),
        MESSAGE("message"),
        IS_ACTIVE("isActive"),
        PROGRAM_YEAR("program-year"),
        DURATIONVALUE("DurationValue"),
        CURRENTPROGRAMYEAR("CurrentProgramYear");


        private String columnName;

        ColumnNames(String columnName) {
            this.columnName = columnName;
        }

        public String getColumnName() {
            return this.columnName;
        }
    }

    private static final String LOG_LITERAL_RUNNING_QUERY = "Running query";
    private static final String BIND_PARAM_EXECUTION_STATUS = "EXECUTION_STATUS";

    private static final String COMMA = ",";
    private static final String GET_DATE_STR = "getUTCDate()";
    private static final String EQUAL_STR = "=";

    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    private static final String JOB_RUN_CONFIGURATION_INSERT = "insert into progperf.jobrunconfiguration" +
            " (JobName,JobDescription,LastRunDate,Status,CreatedBy,CreatedDate,ModifiedBy,ModifiedDate,JobStart)" +
            " values('%s',%s,getUTCDate(),'%s','%s',getUTCDate(),'System',getUTCDate(),getUTCDate())";
    private static final String JOB_RUN_CONFIGURATION_UPDATE = "update progperf.jobrunconfiguration set " +
            "ModifiedDate=getUTCDate() " +
            "%s " +
            "where jobName='%s'";

    private static final String GET_JOB_ISACTIVE_BY_NAME = "SELECT isActive FROM [ProgPerf].[JobRunConfiguration] WHERE JobName = :JOB_NAME";

    private static final String GET_JOB_ID_BY_NAME = "SELECT ID FROM [ProgPerf].[JobRunConfiguration] WHERE JobName = :JOB_NAME";

    private static final String INSERT_JOB_HISTORY = "INSERT INTO  [ProgPerf].[JobExecutionHistory] ( [JobID], [Status], [ErrorMessage], [AffectedRows], [JobStart], [JobEvent], [MessageKey])  " +
            "VALUES (:JOB_ID, :EXECUTION_STATUS, :ERROR_MESSAGE, :AFFECTED_ROWS, getUTCDate(), :JOB_EVENT, :MESSAGE_KEY)";

    private static final String GET_LATEST_IDENTITY_FOR_JOB_HISTORY = "SELECT max(ID) FROM ProgPerf.JobExecutionHistory  WHERE [JobID] = :JOB_ID";

    private static final String UPDATE_JOB_HISTORY_COMPLETE_SUCCESS
            = "UPDATE [ProgPerf].[JobExecutionHistory] " +
            "SET  " +
            "[Status] = :EXECUTION_STATUS, " +
            "[JobEnd] = getUTCDate(), " +
            "[Message] =  CONCAT([Message], ' | ', :MESSAGE_TEXT) ," +
            "[AffectedRows] = :AffectedRows," +
            "[ErrorMessage] = :ErrorMessage " +
            "WHERE [ID] = :EXECUTION_HISTORY_ID";

    private static final String UPDATE_JOB_HISTORY_COMPLETE_FAILURE = "UPDATE [ProgPerf].[JobExecutionHistory] " +
            "SET  " +
            "[Status] = :EXECUTION_STATUS, " +
            "[JobEnd] = getUTCDate(), " +
            "[ErrorMessage] =  CONCAT([ErrorMessage], ' | ', :ErrorMessage), " +
            "[Message] =  :MESSAGE_TEXT " +
            "WHERE [ID] = :EXECUTION_HISTORY_ID";

    private static final String GET_COUNT_OF_JOB_HISTORY_BY_MESSAGE_KEY = "SELECT COUNT(ID) FROM [ProgPerf].[JobExecutionHistory] WHERE JobID = %s  AND [messageKey] = '%s'";

    private static final String GET_COUNT_OF_JOB_HISTORY_BY_TIME = "SELECT COUNT(ID) FROM [ProgPerf].[JobExecutionHistory] WHERE JobID = %s  AND [JobStart] > DATEADD(MINUTE, -%s, GETUTCDATE())";

    private static final String UPDATE_AFFECTEDROW_JOB_RUN_CONFIG = "update ProgPerf.JobRunConfiguration set AffectedRows =:AffectedRows " +
            "where JobName =:JobName ";

    private static final String UPDATE_AFFECTEDROW_JOB_EXECUTION_HISTORY ="UPDATE ProgPerf.JobExecutionHistory set AffectedRows =:AffectedRows " +
            " where id = (select  max(id) from ProgPerf.JobExecutionHistory " +
            " where JobID  =(select id from ProgPerf.JobRunConfiguration  where JobName =:JobName)) ";

    private static final String GET_ALL_JOBS_CONFIGURATION =
            "select A.ID as JobID,C.ID,A.JobName, A.JobDescription, A.LastRunDate, A.CreatedBy, " +
                    "A.CreatedDate, A.ModifiedBy, A.ModifiedDate, A.LastSuccessfulRunDate, " +
                    "A.messageKey, A.jobEvent, A.message, A.isActive, " +
                    "C.JobID, C.Status,C.ErrorMessage,C.AffectedRows,C.JobStart,C.JobEnd " +
                    "FROM ProgPerf.JobRunConfiguration as A " +
                    "inner join " +
                    "    ( select ID,JobID,JobStart,JobEnd,ErrorMessage,AffectedRows,Status  " +
                    "    from (select ID,JobID,JobStart,JobEnd,ErrorMessage,AffectedRows,Status, " +
                    "    row_number() over (PARTITION by  JobID ORDER by ID desc) as job_rank  " +
                    "    from ProgPerf.JobExecutionHistory) job_history " +
                    "    WHERE job_rank = 1 ) " +
                    "    as C on A.ID = C.JobID " +
                    "ORDER by C.ID DESC";

    private static final String GET_JOB_CONFIGURATION_BY_NAME =
            "select top 1 A.ID as JobID, A.JobName, A.JobDescription, A.LastRunDate, A.CreatedBy, " +
                    "A.CreatedDate, A.ModifiedBy, A.ModifiedDate, A.LastSuccessfulRunDate, " +
                    "A.messageKey, A.jobEvent, A.message, A.isActive, " +
                    "C.ID, C.Status,C.ErrorMessage,C.AffectedRows,C.JobStart,C.JobEnd " +
                    "FROM ProgPerf.JobRunConfiguration as A with (nolock)" +
                    "inner join " +
                    "    ProgPerf.JobExecutionHistory " +
                    "    as C on A.ID = C.JobID " +
                    "where A.JobName = :JOB_NAME " +
                    "ORDER by C.ID DESC";

    private static final String UPDATE_JOB_RUN_CONFIGURATION_UPDATE = "update progperf.jobrunconfiguration set " +
            "ModifiedDate=getUTCDate() " +
            "%s " +
            "where UPPER(jobName) = UPPER('%s')";

    private static final String GET_JOB_FREQUENCY_CHECK=  "Select jrc.Frequency from ProgPerf.JobRunConfiguration jrc where jrc.JobName=:JOB_NAME";

    private static final String GET_CASCADED_JOBS=  "SELECT convert(varchar(4000), jrc.cascadedEvents) as cascadedEvents from ProgPerf.JobRunConfiguration jrc where jrc.JobName =:JOB_NAME";


    private static final String FETCH_DURATION_WITH_YEAR = "SELECT TOP 1 id,DurationValue,StartDate,EndDate,DurationType,ProgramYear FROM ProgPerf.ProgramYearCalendar  " +
            "WITH (NOLOCK) where  DurationType ='WEEK' and   " +
            "StartDate <= (SELECT CAST( getUTCDate() AS Date )) AND " +
            "EndDate >= (SELECT CAST( getUTCDate() AS Date )) and ProgramYear = :ProgramYear";

    private static final String GET_CURRENT_PROGRAMYEAR = "select mc.value from ProgPerf.MasterConfiguration mc WITH (NOLOCK) where mc.code='CurrentProgramYear'";

    private static final String QUERY_QFO_DURATION_FOR_PROG_YEAR = "SELECT TOP 1 id,DurationValue,StartDate,EndDate,DurationType,ProgramYear, [Month] as CurrentMonth FROM ProgPerf.CommonProgramYearCalender  " +
            "WITH (NOLOCK) where  DurationType ='MONTH' and   " +
            "StartDate <= (SELECT CAST( getUTCDate() AS Date )) AND " +
            "EndDate >= (SELECT CAST( getUTCDate() AS Date )) and ProgramYear = :ProgramYear and TeamType =:TeamType ";

    private static final String LAST_RUN_DATE = "SELECT convert(varchar, JR.LastSuccessfulRunDate, 20) FROM PROGPERF.JobRunConfiguration JR WHERE JR.JobName=:JOBNAME;";


    private static final String FETCH_MONTH_DURATION_WITH_YEAR = "SELECT min(StartDate) as StartDate ,max(EndDate) as EndDate , [Month] , ProgramYear " +
            "from ProgPerf.ProgramYearCalendar where ProgramYear = :ProgramYear  %s " +
            "group by [Month],ProgramYear order by EndDate ";

    private static final String FETCH_MEMBER_OVERALL_STATUS_SYNC_ENABLED_CONFIGURATION = " select  " +
            "   dt.Value" +
            "   from ProgPerf.CategoryMasterConfiguration dt with(nolock) " +
            "   where dt.[Key] =? ";


    public CommonRepositoryImpl(NamedParameterJdbcTemplate namedParameterJdbcTemplate){
        this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
    }

    /**
     *
     * @param jobRunConfiguration
     * @param updateQuerySB
     */
    private void updateStringBuilder(JobRunConfiguration jobRunConfiguration, StringBuilder updateQuerySB) {
        if (jobRunConfiguration.isUpdateJobEnd()) {
            updateQuerySB.append(addConditionWithoutQuote(GET_DATE_STR, ColumnNames.JOB_END));
        } else {
            updateQuerySB.append(addConditionWithoutQuote(null, ColumnNames.JOB_END));
        }
        if (jobRunConfiguration.isUpdateJobStart()) {
            updateQuerySB.append(addConditionWithoutQuote(GET_DATE_STR, ColumnNames.JOB_START));
        }
        if (jobRunConfiguration.isUpdateLastSuccessfulRun()) {
            updateQuerySB.append(addConditionWithoutQuote(String.format ("[%s]", ColumnNames.JOB_START.getColumnName ()), ColumnNames.LAST_SUCCESSFUL_RUN_DATE));
        }
        if (jobRunConfiguration.isUpdateLastRun()) {
            updateQuerySB.append(addConditionWithoutQuote(GET_DATE_STR, ColumnNames.LAST_RUN_DATE));
        }
        if (jobRunConfiguration.isUpdateJobEvent()) {
            // @ gave error No parameters bound for query
            updateQuerySB.append(addCondition(jobRunConfiguration.getJobEvent().replace("@","||"), ColumnNames.JOB_EVENT));
        }
        if (jobRunConfiguration.isUpdateMessageKey()) {
            updateQuerySB.append(addCondition(jobRunConfiguration.getMessageKey(), ColumnNames.MESSAGE_KEY));
        }
        if (jobRunConfiguration.isUpdateMessage()) {
            updateQuerySB.append(addCondition(jobRunConfiguration.getMessage(), ColumnNames.MESSAGE));
        }
    }


    /**
     * Get BatchSize
     * @return
     */
    public int getBatchSize() {
        return Constants.DB_BATCH_SIZE;
    }

    /**
     *
     * @param value
     * @param columnNames
     * @return
     */
    private String addConditionWithoutQuote(Object value, ColumnNames columnNames) {
        return String.format("%s %s %s %s", COMMA, columnNames.getColumnName(), EQUAL_STR, value);
    }

    /**
     *
     * @param value
     * @param columnNames
     * @return
     */
    private String addCondition(String value, ColumnNames columnNames) {
        if (Objects.nonNull(value)) {
            return String.format(", %s = '%s'", columnNames.getColumnName(), value);
        }
        return "";
    }

    /**
     *
     * @param object
     * @return
     */
    private String getStringValue(Object object) {
        return Objects.isNull(object) ? null
                : String.format("'%s'", object);
    }

    /**
     *
     * @param jobRunConfiguration
     * @return
     */
    public Integer upsertJobRunConfiguration(JobRunConfiguration jobRunConfiguration) {

        StringBuilder updateQuerySB = new StringBuilder();
        String modifiedBy = jobRunConfiguration.getModifiedBy();
        if (StringUtils.isEmpty(modifiedBy)) {
            modifiedBy = jobRunConfiguration.getJobName().getValue();
        }

        updateQuerySB.append(addCondition(jobRunConfiguration.getJobDescription(), ColumnNames.JOB_DESCRIPTION));
        updateQuerySB.append(addCondition(jobRunConfiguration.getStatus().getValue(), ColumnNames.STATUS));
        updateQuerySB.append(addCondition(modifiedBy, ColumnNames.MODIFIED_BY));
        if (jobRunConfiguration.isUpdateErrorMessage()) {
            if (Objects.nonNull(jobRunConfiguration.getErrorMessage()) && StringUtils.isNotEmpty(jobRunConfiguration.getErrorMessage())) {
                jobRunConfiguration.setErrorMessage(
                        StringUtils.left(
                                ProgramPerformanceJobUtil.getQuotedString(jobRunConfiguration.getErrorMessage())
                                , 253));
                String errorQuery = "CASE WHEN ErrorMessage IS NULL THEN '%1$s' " +
                        "WHEN ErrorMessage = '' THEN '%1$s' " +
                        "ELSE CONCAT([ErrorMessage], ' | ', '%1$s') END";
                String errorValue = String.format(errorQuery, jobRunConfiguration.getErrorMessage());

                updateQuerySB.append(addConditionWithoutQuote(errorValue, ColumnNames.ERROR_MESSAGE));
            } else {
                updateQuerySB.append(addCondition("", ColumnNames.ERROR_MESSAGE));
            }
        }

        if (jobRunConfiguration.isUpdateAffectedRows()) {
            updateQuerySB.append(addConditionWithoutQuote(jobRunConfiguration.getAffectedRows(), ColumnNames.AFFECTED_ROWS));
        }

        updateStringBuilder(jobRunConfiguration, updateQuerySB);

        String updateQuery = String.format(JOB_RUN_CONFIGURATION_UPDATE
                , updateQuerySB.toString()
                , jobRunConfiguration.getJobName().getValue()
        );
        log.info("Job Run Configuration Update Query is {}", updateQuery);

        int rowsUpdate = this.namedParameterJdbcTemplate.update(updateQuery, new HashMap<>());
        log.info("Updated rows : {}", rowsUpdate);
        if (rowsUpdate == 0) {
            String createdBy = jobRunConfiguration.getCreatedBy();
            if (StringUtils.isEmpty(createdBy)) {
                createdBy = jobRunConfiguration.getJobName().getValue();
            }
            String insertQuery = String.format(JOB_RUN_CONFIGURATION_INSERT
                    , jobRunConfiguration.getJobName().getValue()
                    , getStringValue(jobRunConfiguration.getJobDescription())
                    , jobRunConfiguration.getStatus().getValue()
                    , createdBy
            );
            log.info("Job Run Configuration Insert Query is {}", insertQuery);

            return namedParameterJdbcTemplate.update(insertQuery, new HashMap<>());
        }

        return rowsUpdate;
    }


    /**
     *
     * @param jobName
     * @return
     */
    public Boolean getJobIsActiveByName(String jobName) {
        log.info("{} {} With Params - jobName : {} ",LOG_LITERAL_RUNNING_QUERY, GET_JOB_ISACTIVE_BY_NAME, jobName);

        SqlParameterSource param = new MapSqlParameterSource(JOB_NAME, jobName);

        return namedParameterJdbcTemplate.queryForObject(GET_JOB_ISACTIVE_BY_NAME, param, Boolean.class);

    }

    /**
     *
     * @param jobName
     * @return
     */
    public Integer getJobIdByName(String jobName) {
        log.info("{} {} With Params - jobName : {} ",LOG_LITERAL_RUNNING_QUERY, GET_JOB_ID_BY_NAME, jobName);

        SqlParameterSource param = new MapSqlParameterSource(JOB_NAME, jobName);
        return namedParameterJdbcTemplate.queryForObject(GET_JOB_ID_BY_NAME, param, Integer.class);

    }

    /**
     * Updated Job with INPROGRESS and rowsupdated 0 then get Max ID from table
     * @param jobConfigId
     * @param correlationKey
     * @param jobEvent
     * @param errorMessage
     * @return
     */
    public Integer updateJobExecutionHistoryAsJobStart(Integer jobConfigId, String correlationKey, String jobEvent, String errorMessage) {
        log.info("{} {} With Params - jobID: {}; messageKey: {}; jobEvent: {}; errorMessage: {};",LOG_LITERAL_RUNNING_QUERY, INSERT_JOB_HISTORY, jobConfigId, correlationKey, jobEvent, errorMessage);

        int result = 0;
        Map<String, Object> bindingMap = new HashMap<>();
        bindingMap.put("JOB_ID", jobConfigId);
        bindingMap.put(BIND_PARAM_EXECUTION_STATUS, Status.IN_PROGRESS.getValue());
        bindingMap.put("ERROR_MESSAGE", errorMessage);
        bindingMap.put("AFFECTED_ROWS", 0);
        bindingMap.put("JOB_EVENT", jobEvent);
        bindingMap.put("MESSAGE_KEY", correlationKey);

        int rowsUpdated = namedParameterJdbcTemplate.update(INSERT_JOB_HISTORY,bindingMap);
        log.info("Job Execution History updated record", rowsUpdated);

        log.info("{} {} ", LOG_LITERAL_RUNNING_QUERY, GET_LATEST_IDENTITY_FOR_JOB_HISTORY);

        SqlParameterSource namedParameters = new MapSqlParameterSource("JOB_ID", jobConfigId);

        result = namedParameterJdbcTemplate.queryForObject(GET_LATEST_IDENTITY_FOR_JOB_HISTORY, namedParameters, Integer.class);

        return result;

    }

    /**
     *
     * @param jobExecutionId
     * @param status
     * @param errorMessage
     * @param message
     * @return
     */
    public Integer updateJobExecutionHistoryAsJobEnd(Integer jobExecutionId, Status status, String errorMessage, String message, Long affectedRows) {

        if (status == Status.SUCCESS) {
            return updateJobExecutionHistoryAsJobSuccess(jobExecutionId, message, affectedRows);
        } else {
            return updateJobExecutionHistoryAsJobFailure(jobExecutionId, errorMessage, affectedRows);
        }

    }

    /**
     *
     * @param jobId
     * @param messageKey
     * @return
     */
    public Integer getJobExecutionHistoryByMessageKey(Integer jobId, String messageKey) {

        String getHistoryCountQuery = String.format (GET_COUNT_OF_JOB_HISTORY_BY_MESSAGE_KEY, jobId, messageKey);
        log.info("{} {}  ",LOG_LITERAL_RUNNING_QUERY, getHistoryCountQuery);

        return namedParameterJdbcTemplate.queryForObject(getHistoryCountQuery, new HashMap<>(), Integer.class);

    }

    /**
     *
     * @param jobId
     * @param thresholdInMinutes
     * @return
     */
    public Integer getJobExecutionHistoryByTime (Integer jobId, Integer thresholdInMinutes) {

        String getHistoryCountQuery = String.format (GET_COUNT_OF_JOB_HISTORY_BY_TIME, jobId, thresholdInMinutes);
        log.info("{} {}",LOG_LITERAL_RUNNING_QUERY, getHistoryCountQuery);

        return namedParameterJdbcTemplate.queryForObject(getHistoryCountQuery, new HashMap<>(), Integer.class);

    }

    /**
     *
     * @return
     */
    public JobConfiguration getAllJobConfigurations() {

        log.info("Getting all jobs configurations");
        return namedParameterJdbcTemplate.queryForObject(GET_ALL_JOBS_CONFIGURATION, new HashMap<>(), JobConfiguration.class);

    }

    /**
     *
      * @param jobName
     * @return
     */
    public JobConfiguration getJobConfigurationByName(JobName jobName) {

        log.info("Getting job configurations for :: {} ", jobName);
        log.info("query for getJobConfigurationByName :: {} ", GET_JOB_CONFIGURATION_BY_NAME);

        SqlParameterSource namedParameters = new MapSqlParameterSource(JOB_NAME, jobName.getValue());

        return namedParameterJdbcTemplate.queryForObject(GET_JOB_CONFIGURATION_BY_NAME, namedParameters, JobConfiguration.class);

    }

    /**
     *
     * @param jobExecutionId
     * @param successMessage
     * @param affectedRows
     * @return
     */
    private Integer updateJobExecutionHistoryAsJobSuccess(Integer jobExecutionId, String successMessage, Long affectedRows) {

        String message = successMessage.replace("'", "''");
        log.info("{} {} With Params - executionHistoryId: {}; message: {};",LOG_LITERAL_RUNNING_QUERY, UPDATE_JOB_HISTORY_COMPLETE_SUCCESS, jobExecutionId, successMessage);

        Map<String, Object> bindingMap = new HashMap<>();
        bindingMap.put("EXECUTION_HISTORY_ID", jobExecutionId);
        bindingMap.put(BIND_PARAM_EXECUTION_STATUS, Status.SUCCESS.getValue());
        bindingMap.put("MESSAGE_TEXT", message);
        bindingMap.put(Constants.AFFECTED_ROWS, affectedRows);
        bindingMap.put("ErrorMessage", "");

        return namedParameterJdbcTemplate.update(UPDATE_JOB_HISTORY_COMPLETE_SUCCESS, bindingMap);

    }

    /**
     *
     * @param jobExecutionId
     * @param errorMessage
     * @param affectedRows
     * @return
     */
    private Integer updateJobExecutionHistoryAsJobFailure(Integer jobExecutionId, String errorMessage, Long affectedRows) {

        String message = StringUtils.left(
                        ProgramPerformanceJobUtil.getQuotedString(errorMessage)
                        , 253); // Escaping sql for single quote; otherwise sql query formation may fail.
        log.info("{} {} With Params - executionHistoryId: {} and errorMessage {}",LOG_LITERAL_RUNNING_QUERY, UPDATE_JOB_HISTORY_COMPLETE_FAILURE, jobExecutionId, message);

        Map<String, Object> bindingMap = new HashMap<>();
        bindingMap.put("EXECUTION_HISTORY_ID", jobExecutionId);
        bindingMap.put(BIND_PARAM_EXECUTION_STATUS, Status.FAILURE.getValue());
        bindingMap.put("MESSAGE_TEXT", "");
        bindingMap.put(Constants.AFFECTED_ROWS, affectedRows);
        bindingMap.put("ErrorMessage", errorMessage);

        return namedParameterJdbcTemplate.update(UPDATE_JOB_HISTORY_COMPLETE_FAILURE, bindingMap);

    }

    /**
     *
     * @param jobName
     * @param affectedRowCount
     * @return
     */
    public Integer updateAffectedRowsCountForJob(String jobName, Long affectedRowCount) {
        log.info ("{} {} with params jobname={} and affectedRow={}",LOG_LITERAL_RUNNING_QUERY, UPDATE_AFFECTEDROW_JOB_RUN_CONFIG, jobName, affectedRowCount);

        Map<String, Object> bindingMap = new HashMap<>();
        bindingMap.put(ColumnNames.AFFECTED_ROWS.getColumnName(),affectedRowCount);
        bindingMap.put(ColumnNames.JOB_NAME.getColumnName(), jobName);

        int result = 0;
        int rowsUpdated =  namedParameterJdbcTemplate.update(UPDATE_AFFECTEDROW_JOB_RUN_CONFIG, bindingMap);
        if(rowsUpdated > 0){

            log.info ("{} {} with params jobname={} and affectedRow={}",LOG_LITERAL_RUNNING_QUERY, UPDATE_AFFECTEDROW_JOB_EXECUTION_HISTORY, jobName, affectedRowCount);

            Map<String, Object> updateAffectedRowsBindingMap = new HashMap<>();
            updateAffectedRowsBindingMap.put(ColumnNames.AFFECTED_ROWS.getColumnName(),affectedRowCount);
            updateAffectedRowsBindingMap.put(ColumnNames.JOB_NAME.getColumnName(), jobName);

            result =  namedParameterJdbcTemplate.update(UPDATE_AFFECTEDROW_JOB_EXECUTION_HISTORY, bindingMap);

        }

        return result;
    }

    /**
     *
     * @param jobConfigurationRequest
     * @return
     */
    public Integer jobConfigurationUpdates(JobConfigurationRequest jobConfigurationRequest) {
        StringBuilder updateQuerySB = new StringBuilder();
        if(jobConfigurationRequest.getIsActive() != null && jobConfigurationRequest.getLastSuccessfulRunDate() != null) {
            updateQuerySB.append(String.format(", %s = %s, %s = '%s' ", ColumnNames.IS_ACTIVE.getColumnName(), jobConfigurationRequest.getIsActive()?1:0, ColumnNames.LAST_SUCCESSFUL_RUN_DATE.getColumnName(), jobConfigurationRequest.getLastSuccessfulRunDate()));
        }else if( jobConfigurationRequest.getIsActive() != null){
            updateQuerySB.append(String.format(", %s = %s ", ColumnNames.IS_ACTIVE.getColumnName(), jobConfigurationRequest.getIsActive()?1:0));
        }else if(jobConfigurationRequest.getLastSuccessfulRunDate() != null){
            updateQuerySB.append(String.format(", %s = '%s' ", ColumnNames.LAST_SUCCESSFUL_RUN_DATE.getColumnName(), jobConfigurationRequest.getLastSuccessfulRunDate()));
        }
        String updateQuery = String.format(UPDATE_JOB_RUN_CONFIGURATION_UPDATE
                , updateQuerySB.toString()
                , jobConfigurationRequest.getJobName()
        );
        log.info("Job Run Configuration Update Query is {}", updateQuery);

        return namedParameterJdbcTemplate.update(UPDATE_JOB_RUN_CONFIGURATION_UPDATE, new HashMap<>());

    }

    public String getJobFrequency(String jobName){
        log.info("{} {} With Params - jobName : {} ",LOG_LITERAL_RUNNING_QUERY, GET_JOB_FREQUENCY_CHECK, jobName);
        SqlParameterSource param = new MapSqlParameterSource(JOB_NAME, jobName);
        return namedParameterJdbcTemplate.queryForObject(GET_JOB_FREQUENCY_CHECK, param, String.class);
    }

    public String getCascadedJobs(String jobName){
        log.info("{} {} With Params - jobName : {} ",LOG_LITERAL_RUNNING_QUERY, GET_CASCADED_JOBS, jobName);
        SqlParameterSource param = new MapSqlParameterSource(JOB_NAME, jobName);
        return namedParameterJdbcTemplate.queryForObject(GET_CASCADED_JOBS, param, String.class);
    }

    @Override
    public ProgramYearCalendarDTO getYTDDuration(Integer programYear) {
        log.info("{} With Params - jobName : {} ",FETCH_DURATION_WITH_YEAR, programYear);
        SqlParameterSource param = new MapSqlParameterSource(Constants.PROGRAM_YEAR, programYear);
        return namedParameterJdbcTemplate.queryForObject(FETCH_DURATION_WITH_YEAR, param, new ProgramYearCalendarDTOMapper());
    }

    @Override
    public CommonProgramYearCalenderDTO getDuration(Integer programYear, String teamType) {
        log.info("Query : {} With Params - {} , {} ",QUERY_QFO_DURATION_FOR_PROG_YEAR, programYear, teamType);
        Map<String, Object> param = new HashMap<>();
        param.put(Constants.PROGRAM_YEAR, programYear);
        param.put("TeamType", teamType);
        return namedParameterJdbcTemplate.queryForObject(QUERY_QFO_DURATION_FOR_PROG_YEAR, param, BeanPropertyRowMapper.newInstance(CommonProgramYearCalenderDTO.class));
    }

    @VisibleForTesting
    class ProgramYearCalendarDTOMapper implements RowMapper<ProgramYearCalendarDTO> {

        @Override
        public ProgramYearCalendarDTO mapRow(ResultSet rs, int i) throws SQLException {
            return ProgramYearCalendarDTO.builder()
                    .id(rs.getLong("id"))
                    .endDate(getDate(rs.getString("EndDate")))
                    .startDate(getDate(rs.getString("StartDate")))
                    .durationType(rs.getString("DurationType"))
                    .programYear(rs.getInt(Constants.PROGRAM_YEAR))
                    .durationValue(rs.getString("DurationValue"))
                    .build();
        }

        private LocalDate getDate(String date) {
            return LocalDate.parse(date);
        }
    }

    @VisibleForTesting
    class ProgramYearCalendarDTOListMapper implements RowMapper<List<ProgramYearCalendarDTO>> {
        List<ProgramYearCalendarDTO> monthList = new ArrayList<ProgramYearCalendarDTO>();
        @Override
        public List<ProgramYearCalendarDTO> mapRow(ResultSet rs, int arg1) throws SQLException {
            ProgramYearCalendarDTO dtomonth = new ProgramYearCalendarDTO();
            while (rs.getRow()>0) {
                if (rs.getString("Month") != null)
                    monthList.add(ProgramYearCalendarDTO.builder()
                            .endDate(getDate(rs.getString("EndDate")))
                            .startDate(getDate(rs.getString("StartDate")))
                            .programYear(rs.getInt(Constants.PROGRAM_YEAR))
                            .month(rs.getString("Month"))
                            .build());
                rs.next();

            }
            return monthList;
        }


        private LocalDate getDate(String date) {
            return LocalDate.parse(date);
        }
    }

    public Integer getCurrentProgramYear() {
        log.info("{} {} With getCurrentProgramYear", LOG_LITERAL_RUNNING_QUERY, GET_JOB_ID_BY_NAME);

        SqlParameterSource param = new MapSqlParameterSource();
        return namedParameterJdbcTemplate.queryForObject(GET_CURRENT_PROGRAMYEAR, param, Integer.class);
    }

    public  String getJobsLastRunSuccessfulDate(String  jobName) {
        HashMap<String,Object> params =  new HashMap<>();
        params.put("JOBNAME",jobName);
        return namedParameterJdbcTemplate.queryForObject(LAST_RUN_DATE, params, String.class);
    }
    
    public static final String MASTEROPPORTUNITY = "MASTEROPPORTUNITY";

	private static final String LASTSUCCESSFULRUNDATE_QUERY = "SELECT  " +
			"  TOP 1 CONVERT(varchar,  " +
			"  jeh.JobStart ,  " +
			"  20) AS LastSuccessfulRunDate  " +
			"FROM  " +
			"  ProgPerf.JobExecutionHistory jeh  " +
			"WHERE  " +
			"  jobid = (  " +
			"  SELECT  " +
			"    TOP 1 id  " +
			"  FROM  " +
			"    ProgPerf.JobRunConfiguration jrc  " +
			"  WHERE  " +
			"    JobName = :MASTEROPPORTUNITY )  " +
			"  AND Status = 'Success'  " +
			"ORDER BY  " +
			"  id DESC";

	@Override 
	public String fetchLastSucessfullJobStartRanDate(String masterOpportunityName) {
		log.info("{} : Fetching last job run date from JobRunConfiguration table for Opportunity :{} ",
				ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), masterOpportunityName);
		Map<String, Object> bindingMap = new HashMap<>();
		bindingMap.put(MASTEROPPORTUNITY, masterOpportunityName);

		return namedParameterJdbcTemplate.query(LASTSUCCESSFULRUNDATE_QUERY, bindingMap, rs -> {
			String result = rs.next() ? rs.getString("LastSuccessfulRunDate") : "1900-01-01 00:00:00";
			return result;
		});
	}

    @Override
    public List<ProgramYearCalendarDTO> getYTDDurationMonth(Integer programYear, String month) {
        log.info("{} With Params - programYear : {} ,  month : {} ",FETCH_MONTH_DURATION_WITH_YEAR, programYear,month);
        SqlParameterSource param = new MapSqlParameterSource(Constants.PROGRAM_YEAR, programYear);
        String selectquerymonth="";
        if(month!=null){
            selectquerymonth = String.format(FETCH_MONTH_DURATION_WITH_YEAR, "and [Month] = '"+month +"'");
            return  namedParameterJdbcTemplate.queryForObject(selectquerymonth,param,new ProgramYearCalendarDTOListMapper());
        }else{
            selectquerymonth=String.format(FETCH_MONTH_DURATION_WITH_YEAR, "");
            return namedParameterJdbcTemplate.queryForObject(selectquerymonth,param,new ProgramYearCalendarDTOListMapper());
        }

    }
    
    private static final String GET_PA_CURRENT_PROGRAMYEAR = "select mc.value from ProgPerf.MasterConfiguration mc WITH (NOLOCK) where mc.code='PACurrentProgramYear'";

	@Override
	public Integer getPACurrentProgramYear() {
		log.info("{} {} With getPACurrentProgramYear", LOG_LITERAL_RUNNING_QUERY, GET_JOB_ID_BY_NAME);
		SqlParameterSource param = new MapSqlParameterSource();
		return namedParameterJdbcTemplate.queryForObject(GET_PA_CURRENT_PROGRAMYEAR, param, Integer.class);
	}

    @Override
    public String getKafkaEnabledConf(String key) {
        return namedParameterJdbcTemplate.getJdbcTemplate().queryForObject(FETCH_MEMBER_OVERALL_STATUS_SYNC_ENABLED_CONFIGURATION ,new Object[]{key}, String.class);
    }
	
}
