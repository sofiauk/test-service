package com.optum.rqns.ftm.service;

import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.producer.JobEventProducer;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.repository.IDMGlidePathRepository;
import com.optum.rqns.ftm.util.ProgramPerformanceJobUtil;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import com.fasterxml.uuid.Generators;

@Service
@Slf4j
public class IDMGlidePathServiceImpl implements IDMGlidePathService {

    private IDMGlidePathRepository idmGlidePathRepository;
    private static final int BATCH_SIZE = 25000;

    @Autowired
    private JobEventProducer jobEventProducer;

    @Value("${spring.db_connection_thread_pool_size}")
    private int dbConnectionThreadPoolSize;

    public IDMGlidePathServiceImpl(IDMGlidePathRepository idmGlidePathRepository) {
        this.idmGlidePathRepository = idmGlidePathRepository;
    }

    public JobStatus executeJob(JobEvent jobEvent) {

        MDC.put(Constants.TRACE_ID, Generators.timeBasedGenerator().generate().toString());
        MDC.put(Constants.TRANSACTION_ID, ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
        MDC.put(Constants.MESSAGE_ID, ProgramPerformanceJobUtil.TransactionIdLogger.getMessageIdIdentifier());

        log.info("jobEvent.IDMGlidePath() :: {}", jobEvent.getJobName());
        JobStatus jobStatus = new JobStatus();

        try {
            log.info("Received IDMGlidePath message from topic : {}", jobEvent.getJobName());

            final boolean canExecuteForAllProviderGroups = ProgramPerformanceJobUtil.canExecuteForAllProviderGroups(jobEvent.getGroupsToExecute());
            final Long totalRows = this.idmGlidePathRepository.getRecordCount(canExecuteForAllProviderGroups);
            log.info("record Count {}", totalRows);

            List<Integer> batches = getBatches(totalRows);
            log.info("total Batches offsets are {}", batches);
            ExecutorService executorService = Executors.newFixedThreadPool(dbConnectionThreadPoolSize);
            List<Callable<Integer>> taskList = new ArrayList<>();

            batches.forEach(batchOffset -> taskList.add(this.idmGlidePathRepository
                    .mergeIDMData(BATCH_SIZE, batchOffset, canExecuteForAllProviderGroups)));
            final long totalUpdatedRecords = executeQueries(executorService, taskList);
            log.info("total updated record count {}", totalUpdatedRecords);

            jobStatus.setStatus(Status.SUCCESS);
            jobStatus.setMessage("Completed IDM GlidePath job successfully");
            jobStatus.setUpdatedRows(totalUpdatedRecords);

        } catch (Exception e) {
            log.error("Exception while executing IDMGlidePath job : {}", e);
            jobStatus.setStatus(Status.FAILURE);
            jobStatus.setMessage("IDMGlidePath job execution failed : " + e.getMessage());
            jobStatus.setUpdatedRows(0L);
        } finally{
            triggerRunPAFXMemberDeploymentUpdates(jobEvent);
            MDC.clear();
        }
        return jobStatus;
    }

    /**
     * Trigger RUN_PAFX_MEMBER_DEPLOYMENT_UPDATES
     * @param jobEvent
     */
    private void triggerRunPAFXMemberDeploymentUpdates(JobEvent jobEvent) {
        log.info("Entering into triggerRunPAFXMemberDeploymentUpdates() : {}", jobEvent.getJobName());
        //Weekly Integration After IDM Merge call RUN_PAFX_MEMBER_DEPLOYMENT_UPDATES

        log.info("Send RunPAFxMemberDeploymentUpdates Message : {}", JobName.RUN_PAFX_MEMBER_DEPLOYMENT_UPDATES);
        JobEvent runPafxMemberDeploymentUpdates = JobEvent.newBuilder().setJobName(JobName.RUN_PAFX_MEMBER_DEPLOYMENT_UPDATES.getValue()).setGroupsToExecute(jobEvent.getGroupsToExecute().toString())
                .setExecutionWeek(jobEvent.getExecutionWeek().toString()).setStatus(Status.SUCCESS.getValue()).setProgramYear(jobEvent.getProgramYear())
                .setCascadeEvents(jobEvent.getCascadeEvents()).setTimeStamp(Instant.now()).build();
        jobEventProducer.postToKafka(runPafxMemberDeploymentUpdates);
        log.info("Completed RunPAFxMemberDeploymentUpdates trigger process : {}", jobEvent.getJobName());
    }

    @SneakyThrows
    private long executeQueries(ExecutorService executorService, List<Callable<Integer>> taskList) {
        long totalCount = 0;
        try {
            List<Future<Integer>> results = executorService.invokeAll(taskList);
            for (Future<Integer> f : results) {
                if (f != null && f.get() != null) {
                    totalCount += f.get();
                }
            }
        } catch (InterruptedException | ExecutionException e) {
            log.error("Error while  merging Idm data to performance table  ", e);
            throw e;
        } finally {
            taskList.clear();
            executorService.shutdown();
        }
        return totalCount;
    }

    private List<Integer> getBatches(Long totalRows) {
        List<Integer> batches = new ArrayList<>();
        if (totalRows > 0) {
            for (int batchOffset = 0; batchOffset <= totalRows; batchOffset += BATCH_SIZE) {
                batches.add(batchOffset);
            }
        }
        return batches;
    }
}
