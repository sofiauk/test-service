package com.optum.rqns.ftm.repository.leaderopportunities;

import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;

import java.util.List;

public interface LeaderOpportunitiesCommonRepository {

    int calculateICQualityGapsAndACVOppData(String ic, String serviceLevel, String masterOpportunityType, int programYear,String jobName);

    int calculateLeaderCommonOppData(String leader, List<String> totalReporters, String masterOpportunityType,String jobName);

    List<String> getServiceLevelForUser(String ic);

    Integer flagIsActiveFalseLeaderOpportunities(JobEvent jobEvent,String masterOpportunityType);

    int calculateICSuspectOppData(String ic, String serviceLevel, String masterOpportunityType, int programYear);

    int calculateLeaderSuspectOppData(String leader, List<String> totalReporters, String masterOpportunityType);
}
