package com.optum.rqns.ftm.kafka.producer;

import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.kafka.avro.models.v1.pps.MemberPaymentOverallStatusSync;
import com.optum.rqns.ftm.repository.common.CommonRepository;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.common.KafkaException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaProducerException;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Component;
import org.springframework.util.concurrent.ListenableFuture;

import java.util.Map;

@Component
@Slf4j
public class KeyBasedMemberOverallStatusSyncProducer {

    @Value("${spring.gcpkafka.properties.topics.memberStatusSync}")
    public String gcpTopicName;

    @Value("${spring.kafka.properties.topics.memberStatusSync}")
    public String rqsTopicName;

    @Autowired
    @Qualifier("rqsMemberPaymentOverallStatusSync")
    private KafkaTemplate<String, MemberPaymentOverallStatusSync> KafkaTemplate;

    @Autowired
    @Qualifier("gcpMemberPaymentOverallStatusSync")
    private KafkaTemplate<String, MemberPaymentOverallStatusSync> gcpKafkaTemplate;


    public boolean postToKafka(MemberPaymentOverallStatusSync message, String key, Map<String, String> KafkaEnableProps) {

        try {
            ListenableFuture<SendResult<String, MemberPaymentOverallStatusSync>> result = null;
            if (KafkaEnableProps.get(Constants.MEMBER_STATUS_RQS_ENABLED) != null && KafkaEnableProps.get(Constants.MEMBER_STATUS_RQS_ENABLED).equalsIgnoreCase("true")) {
                result = KafkaTemplate.send(rqsTopicName, key, message);
                KafkaTemplate.flush();
            }

            if (KafkaEnableProps.get(Constants.MEMBER_STATUS_GCP_ENABLED) != null && KafkaEnableProps.get(Constants.MEMBER_STATUS_GCP_ENABLED).equalsIgnoreCase("true")) {
                result = gcpKafkaTemplate.send(gcpTopicName, key, message);
                gcpKafkaTemplate.flush();
            }
            log.info("Key based Message sent successfully for ******* {} ******* [ClientId,GlobalMemberId,Lob,ProgramYear,SentToTopic]  = {},{},{},{}", message.getClientId(), message.getGlobalMemberId(), message.getLob(), message.getProgramYear(), result.isDone());
            return result!=null?result.isDone():false;

        } catch (KafkaProducerException ex) {
            log.info("Error Message Key {}{}", key, message.toString());
            log.error("KafkaProducerException occured while sending message to kafka topic for keyBased {}", ex.getMessage());
        } catch (KafkaException ex) {
            log.info("Error1 Message Key {}{}", key, message.toString());
            log.error("KafkaException occured while sending message to kafka topic for keyBased {}", ex.getMessage());
        } catch (Exception ex) {
            log.info("Error2 Message Key {}{}", key, message.toString());
            log.error("Exception occured while sending message to kafka topic for keyBased {}, provider group id = {}, clientId={}", ex.getMessage(), message.getProviderGroupId(), message.getClientId());
        }

        return false;
    }
}