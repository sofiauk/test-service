package com.optum.rqns.ftm.repository.fieldactionrules;


import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.model.fieldactionrules.ChangeServiceAction;
import com.optum.rqns.ftm.model.fieldactionrules.RuleAction;
import com.optum.rqns.ftm.util.ProgramPerformanceJobUtil;
import lombok.extern.slf4j.Slf4j;
import org.jboss.logging.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
@Slf4j
public class ChangeServiceLevelRuleRepositoryImpl implements ChangeServiceLevelRuleRepository {

    @Autowired
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    public static final String MANAGER_UUID="ManagerUuid";

    private static final String PROVIDER_GROUP_WITH_SERVICE_LEVEL_QUERY =
                            ";with CTE_ProgramYear(CurrentYear) As( " +
                                    "select mc.value as currentYear " +
                                    "from ProgPerf.MasterConfiguration mc WITH (NOLOCK) " +
                                    "where  mc.code = 'CurrentProgramYear' " +
                                    "), " +
                                    "CTE_Accounts(AccountId,GroupId,State) as " +
                                    "( " +
                                    "select a.AccountId ,a.GroupId ,a.State from ProgPerf.Accounts a WITH (NOLOCK) " +
                                    "where a.ServiceLevel in('Decline Participation', 'Out of Scope', 'None', '') " +
                                    "OR (a.ServiceLevel) is NULL " +
                                    "order by a.AccountId OFFSET :begin ROWS FETCH NEXT :end ROWS ONLY " +
                                    ") " +
                                    "select " +
                                    " u.ManagerEmail ,u.ManagerUuid, " +
                                    " pgp.ProviderGroupID, pgp.State ,  " +
                                    " p.ProviderGroupName, " +
                                    " ISNULL(sum(pgp.EligibleDeployableMemberCount),-1) as EligibleDeployableMemberCount ,ISNULL(sum(pgp.DeployYTDActual),-1) as DeployYTDActual " +
                                    "from CTE_Accounts " +
                                    "join ProgPerf.AccountOwner ao  on CTE_Accounts.AccountId=ao.AccountId " +
                                    "join ProgPerf.ProviderGroup p on p.ProviderGroupID =CTE_Accounts.GroupId and p.State =CTE_Accounts.State " +
                                    "join ProgPerf.Users u on u.UUID =ao.OwnerUUID " +
                                    "join ProgPerf.ProviderGroupPerformance  pgp on CTE_Accounts.GroupId =pgp.ProviderGroupID  and CTE_Accounts.State =pgp.State " +
                                    "join CTE_ProgramYear on pgp.ProgramYear =CTE_ProgramYear.currentYear " +
                                    "where pgp.isCurrentWeekForPerformance =1 " +
                                    "and u.ManagerUuid is NOT NULL and u.ManagerUuid <> '' " +
                                    "group by pgp.ProviderGroupID,pgp.State " +
                                    ",p.ProviderGroupName " +
                                    ",u.ManagerEmail ,u.ManagerUuid ;" ;


    @Override
    public List<RuleAction> getProvidersWithChangeServiceLevel(Integer beginIndex, int batchSize) {
        log.info("Inside Repository Method,current beginIndex:{} current bacthsize:{}", beginIndex, batchSize);
        Map<String, Object> bindingMap = new HashMap<>();
        bindingMap.put("begin", beginIndex);
        bindingMap.put("end", batchSize);
        return namedParameterJdbcTemplate.query(PROVIDER_GROUP_WITH_SERVICE_LEVEL_QUERY, bindingMap, new ChangeServiceRuleActionMapper());
    }

    @Override
    public List<Integer> getRowCountforChangeServiceLevel(int batchsize) {
        log.info("Fetching  count of Providers with Service level Combination:{}",ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
        Integer totalRows =   namedParameterJdbcTemplate.queryForObject(GET_COUNT_ACCOUNTS, new HashMap<>(), Integer.class);
        log.info("Fetching  count of Providers with Service level Combination  :{}, totalRows :{} ", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(),totalRows);
        List<Integer> batches = new ArrayList<>();
        if (totalRows!=null && totalRows > 0) {
            for (int batchOffset = 0; batchOffset <= totalRows; batchOffset += batchsize) {
                batches.add(batchOffset);
            }
        }
        return batches;
    }

    public static final String GET_COUNT_ACCOUNTS ="select count(a.AccountId) from " +
            "ProgPerf.Accounts a " +
            "where a.ServiceLevel in('Decline Participation', 'Out of Scope', 'None', '')  " +
            "OR (a.ServiceLevel) is NULL ";

    public static class ChangeServiceRuleActionMapper implements RowMapper<RuleAction> {

        public ChangeServiceAction mapRow(ResultSet rs, int rowNum) throws SQLException {
            List<String> userList=new ArrayList<>();
            ChangeServiceAction providerData = new ChangeServiceAction();
            providerData.setGroupId(rs.getString("ProviderGroupID"));
            providerData.setDerivedDeployed(rs.getInt("DeployYTDActual"));
            providerData.setEligibleDeployableMembers(rs.getInt("EligibleDeployableMemberCount"));
            providerData.setManagerEmail(rs.getString("ManagerEmail"));
            providerData.setManagerUUID(rs.getString(MANAGER_UUID));
            providerData.setState(rs.getString("State"));
            providerData.setGroupName(rs.getString("ProviderGroupName"));
            providerData.setRuleType("ChangeServiceLevelRule");
            if(rs.getString(MANAGER_UUID)!=null)
                userList.add(rs.getString(MANAGER_UUID));
            else
                userList.add("");
            providerData.setUserUuid(userList);
            providerData.setVerifyRuleResult(true);

            return providerData;
            }


    }
}
