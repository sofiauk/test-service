package com.optum.rqns.ftm.repository.opamigration;

import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.model.opamigration.MemberOverallStatus;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;

@Repository
@Slf4j
public class OPAMigrationRepositoryImpl implements OPAMigrationRepository {

    public static final String PROGRAM_YEAR = "PROGRAMYEAR";
    public static final String BATCH_SIZE = "BatchSize";
    public static final String OFFSET = "OFFSET";

    private static final String COUNT_QUERY =  "select count(src.providerGroupId) as datacount from ( " +
            "  select  " +
            "   lob2 as lob, " +
            "   clientid as clientId, " +
            "   prov_group_id as providerGroupId, " +
            "   mbr_glb_id as globalMemberId, " +
            "   project_year as programYear, " +
            "   overall_status as overallStatus, " +
            "   chart_id as messageCorrId, " +
            "   UpdatedDate  as updatedDate, " +
            "   deploydate  as deployDate, " +
            "   distributionchannel  as distributionChannel " +
            "   from " +
            "   ProgPerf.MemberAssessment ma " +
            "   where " +
            "   chart_dup_id = 1 " +
            "   AND projecttype NOT IN ('CAPE','null', '') " +
            "   AND project_year = :PROGRAMYEAR " +
            "   AND RecordChangeType <> 'DELETED' " +
            "   AND overall_status NOT IN ('null', '') " +
            "   AND lob2 NOT IN ('null', '') " +
            "   AND clientid NOT IN ('null', '') " +
            "   AND prov_group_id NOT IN ('null', '') " +
            "   AND mbr_glb_id NOT IN ('null', '') " +
            "   AND chart_id NOT IN ('null', '')" +
            "  ) as src ";
    private static final String LAST_UPDATE_BY_RUN_CONFIGURATION_COUNT_QUERY = "select count(src.providerGroupId) as datacount from ( " +
            "   select " +
            "    lob2 as lob, " +
            "    clientid as clientId, " +
            "    prov_group_id as providerGroupId, " +
            "    mbr_glb_id as globalMemberId, " +
            "    project_year as programYear, " +
            "    overall_status as overallStatus, " +
            "    chart_id as messageCorrId, " +
            "    UpdatedDate  as updatedDate, " +
            "    deploydate  as deployDate, " +
            "    distributionchannel  as distributionChannel " +
            "    from " +
            "    ProgPerf.MemberAssessment ma " +
            "    where " +
            "    chart_dup_id = 1 " +
            "    AND projecttype NOT IN ('CAPE','null', '') " +
            "    AND project_year = :PROGRAMYEAR " +
            "    AND RecordChangeType <> 'DELETED' " +
            "    AND overall_status NOT IN ('null', '') " +
            "    AND lob2 NOT IN ('null', '') " +
            "    AND clientid NOT IN ('null', '') " +
            "    AND prov_group_id NOT IN ('null', '') " +
            "    AND mbr_glb_id NOT IN ('null', '')" +
            "    AND chart_id NOT IN ('null', '') " +
            "    AND CAST(UpdatedDate as DATE) >= (select CAST(LastSuccessfulRunDate as DATE) " +
            "    FROM ProgPerf.JobRunConfiguration where JobName = '" +JobName.RUN_MEMBER_PAYMENT_OVERALL_STATUS_SYNC.getValue() + "')" +
            "   ) as src ";
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    public OPAMigrationRepositoryImpl(NamedParameterJdbcTemplate namedParameterJdbcTemplate){
        this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
    }

     private final String MEMBER_OVERALL_STATUS_QUERY = "select " +
        "   lob2 as lob," +
        "   clientid as clientId, " +
        "   prov_group_id as providerGroupId, " +
        "   mbr_glb_id as globalMemberId, " +
        "   project_year as programYear, " +
        "   overall_status as overallStatus, " +
        "   chart_id as messageCorrId, " +
        "   UpdatedDate  as updatedDate, " +
        "   deploydate  as deployDate, " +
        "   distributionchannel  as distributionChannel " +
        "   from " +
        "   ProgPerf.MemberAssessment ma " +
        "   where " +
        "   chart_dup_id = 1 " +
        "   AND projecttype NOT IN ('CAPE','null', '') " +
        "   AND project_year = :PROGRAMYEAR " +
        "   AND RecordChangeType <> 'DELETED' " +
        "   AND overall_status NOT IN ('null', '') " +
        "   AND lob2 NOT IN ('null', '') " +
        "   AND clientid NOT IN ('null', '') " +
        "   AND prov_group_id NOT IN ('null', '') " +
        "   AND mbr_glb_id NOT IN ('null', '')" +
        "   AND chart_id NOT IN ('null', '') " +
        "   ORDER BY project_year, chart_id offset :OFFSET rows FETCH next :BatchSize rows only";


    private final String MEMBER_OVERALL_STATUS_QUERY_LAST_RUN_DATE_QUERY = "select " +
            "   lob2 as lob," +
            "   clientid as clientId, " +
            "   prov_group_id as providerGroupId, " +
            "   mbr_glb_id as globalMemberId, " +
            "   project_year as programYear, " +
            "   overall_status as overallStatus, " +
            "   chart_id as messageCorrId, " +
            "   UpdatedDate  as updatedDate, " +
            "   deploydate  as deployDate, " +
            "   distributionchannel  as distributionChannel " +
            "   from " +
            "   ProgPerf.MemberAssessment ma " +
            "   where " +
            "   chart_dup_id = 1 " +
            "   AND projecttype NOT IN ('CAPE','null', '')  " +
            "   AND project_year = :PROGRAMYEAR " +
            "   AND RecordChangeType <> 'DELETED' " +
            "   AND overall_status NOT IN ('null', '') " +
            "   AND lob2 NOT IN ('null', '') " +
            "   AND clientid NOT IN ('null', '') " +
            "   AND prov_group_id NOT IN ('null', '') " +
            "   AND mbr_glb_id NOT IN ('null', '')" +
            "   AND chart_id NOT IN ('null', '') " +
            "   AND CAST(UpdatedDate as DATE) >= (select CAST(LastSuccessfulRunDate as DATE) " +
            "   FROM ProgPerf.JobRunConfiguration where JobName = '" +JobName.RUN_MEMBER_PAYMENT_OVERALL_STATUS_SYNC.getValue() + "')" +
            "   ORDER BY project_year, chart_id offset :OFFSET rows FETCH next :BatchSize rows only " ;


    @Override
    public List<MemberOverallStatus> getMemberStatusDetails(int batchSize, Integer batchOffset,Integer programYear) {
        SqlParameterSource sqlParameterSource = new MapSqlParameterSource(BATCH_SIZE, batchSize)
                .addValue(OFFSET, batchOffset)
                .addValue(PROGRAM_YEAR,programYear);
        log.info("batchsize {} offset {}", batchSize, batchOffset);
        return namedParameterJdbcTemplate.query(MEMBER_OVERALL_STATUS_QUERY, sqlParameterSource, new BeanPropertyRowMapper<>(MemberOverallStatus.class));
    }

    @Override
    public List<MemberOverallStatus> getMemberStatusDetailsBasedOnLostJobRunDate(int batchSize, Integer batchOffset, Integer programYear) {
        SqlParameterSource sqlParameterSource = new MapSqlParameterSource(BATCH_SIZE, batchSize)
                .addValue(OFFSET, batchOffset)
                .addValue(PROGRAM_YEAR,programYear);
        log.info("batchsize {} offset {}", batchSize, batchOffset);
        return namedParameterJdbcTemplate.query(MEMBER_OVERALL_STATUS_QUERY_LAST_RUN_DATE_QUERY,sqlParameterSource, new BeanPropertyRowMapper<>(MemberOverallStatus.class));
    }

    @Override
    public Long getRecordCount(Integer programYear) {
        HashMap<String,Object> params =  new HashMap<>();
        params.put(PROGRAM_YEAR,programYear);
        return namedParameterJdbcTemplate.queryForObject(COUNT_QUERY, params, Long.class);
    }

    @Override
    public Long getRecordCountForLastUpdateJobRunConfiguration(Integer programYear) {
        HashMap<String,Object> params =  new HashMap<>();
        params.put(PROGRAM_YEAR,programYear);
        return namedParameterJdbcTemplate.queryForObject(LAST_UPDATE_BY_RUN_CONFIGURATION_COUNT_QUERY, params, Long.class);
    }
}