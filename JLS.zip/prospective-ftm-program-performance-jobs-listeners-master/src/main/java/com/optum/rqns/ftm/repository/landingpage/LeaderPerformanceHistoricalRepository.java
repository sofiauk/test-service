package com.optum.rqns.ftm.repository.landingpage;

import com.optum.rqns.ftm.model.ProgramYearCalendarDTO;
import java.util.List;

public interface LeaderPerformanceHistoricalRepository {

    long loadLeaderPerformanceNationalLevelAll(ProgramYearCalendarDTO programYearCalendarDTO, int isCurrentWeek,boolean isAllProviderGroups);

    List<ProgramYearCalendarDTO> getAllProgramYearsDurations(int programYear);

    ProgramYearCalendarDTO getPrevoiusYearLastWeekDuration(int programYear);

    ProgramYearCalendarDTO getCurrentWeekDurationForProgramyear(int programYear);

    int loadLeadersHistoricalLeaderPerformanceData(String userId, List<String> totalReporters, ProgramYearCalendarDTO programYearCalendarDTO, int isCurretnWeek , boolean isAllProviderGroups) ;

    int loadHistoricalICPerformanceData(String userId, String serviceLevel, ProgramYearCalendarDTO programYearCalendarDTO, int isCurrentWeek, boolean isAllProviderGroups);

    long loadHistoricalLeaderPerformance(ProgramYearCalendarDTO programYearCalendarDTO, int isCurrentWeek, boolean isAllProviderGroups);

    int updateICGoalLeaderPerformance(String userId, String serviceLevel, ProgramYearCalendarDTO programYearCalendarDTO, boolean isAllProviderGroups);
}

