package com.optum.rqns.ftm.configuration;

import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.kafka.avro.models.v1.fieldactionrule.FieldActionRuleMetadata;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.avro.models.v1.pps.MemberPaymentOverallStatusSync;
import com.optum.rqns.ftm.kafka.avro.models.v1.program.performance.provider.ProgPerfProviderMSSync;
import com.optum.rqns.ftm.kafka.avro.models.v1.program.performance.provider.membership.ProviderEligibleMembership;
import com.optum.rqns.ftm.kafka.avro.models.v1.program.performance.provider.qfo.QFOPatientExperience;
import io.confluent.kafka.serializers.KafkaAvroDeserializer;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.KafkaListenerContainerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.listener.ConcurrentMessageListenerContainer;

@Configuration
@Slf4j
public class GCPKafkaConfiguration extends GCPBaseKafkaConfiguration {

    @Bean
    public KafkaTemplate<String, FieldActionRuleMetadata> fieldActionRuleKafkaTemplate() {
        return new KafkaTemplate<>(gcpProducerFactory("fieldActionRule",Constants.OFC));
    }

    @Bean("newProviderGroupRuleTemplate")
    public KafkaTemplate<String, ProgPerfProviderMSSync> newProviderGroupRuleTemplate() {
        return new KafkaTemplate<>(gcpProducerFactory("progPerfProviderSync", Constants.OFC));
    }

    @Bean("providerEligibleMembershipKafkaTemplate")
    public KafkaTemplate<String, ProviderEligibleMembership> providerEligibleMembershipKafkaTemplate() {
        return new KafkaTemplate<>(gcpProducerFactory("providerEligibleMembershipSync", Constants.OFC));
    }

    @Bean
    public KafkaTemplate<String, JobEvent> jobEventKafkaTemplate() {
        return new KafkaTemplate<>(gcpProducerFactory("jobEvent", Constants.OFC));
    }

    @Bean
    public KafkaListenerContainerFactory<ConcurrentMessageListenerContainer<String, Object>> jobEventKafkaListenerContainerFactory() {

        return gcpCreateContainerFactory( new StringDeserializer(), new KafkaAvroDeserializer(),
                  gcpKafkaProperties.getProperties().get("topics.jobEvent"), Constants.CONSUMER_JOBEVENT, Constants.OFC);
    }

//    @Bean
//    public KafkaListenerContainerFactory<ConcurrentMessageListenerContainer<String, Object>> jobEventKafkaListenerContainerFactory() {
//
//        return createContainerFactory(kafkaProperties.getProperties().get("topics.jobEvent"), new StringDeserializer(), new KafkaAvroDeserializer(), false);
//    }


    @Bean
    @Qualifier("gcpMemberPaymentOverallStatusSync")
    public KafkaTemplate<String, MemberPaymentOverallStatusSync> memberPaymentOverallStatusSyncGcpKafkaTemplate() {
        return new KafkaTemplate<>(gcpProducerFactory("opaMigration", Constants.OFC));
    }


    @Bean("memberGapsNewProviderGroupRuleTemplate")
    public KafkaTemplate<String, ProgPerfProviderMSSync> memberGapsNewProviderGroupRuleTemplate() {
        return new KafkaTemplate<>(gcpProducerFactory("progPerfProviderSync", Constants.OFC));
    }
    @Bean
    public KafkaTemplate<String, QFOPatientExperience> qfoPatientExperienceScoreSyncKafkaTemplate() {
        return new KafkaTemplate<>(gcpProducerFactory("qfoPatientExperienceScoreSync", Constants.OFC));
    }

}
