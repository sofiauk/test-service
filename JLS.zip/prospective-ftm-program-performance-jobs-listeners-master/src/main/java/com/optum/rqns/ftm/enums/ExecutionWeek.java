package com.optum.rqns.ftm.enums;

public enum ExecutionWeek {
    ALL("All"),
    CURRENT("Current");

    private String value;
    private ExecutionWeek(String value) {
        this.value = value;
    }
    public String getValue(){
        return value;
    }
}
