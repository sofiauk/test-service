package com.optum.rqns.ftm.repository;


import java.util.concurrent.Callable;

public interface IDMGlidePathRepository {
    Long getRecordCount(boolean canExecuteForAllProviderGroups);

    Callable<Integer> mergeIDMData(int batchSize, Integer batchOffset, boolean canExecuteForAllProviderGroups);
}
