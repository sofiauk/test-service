package com.optum.rqns.ftm.util;
/*
This class consists of Util functions of a work queue rules.
 */

import com.google.gson.Gson;
import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.enums.RuleEnum;
import com.optum.rqns.ftm.exception.FieldActionRulesException;
import com.optum.rqns.ftm.kafka.avro.models.v1.fieldactionrule.Action;
import com.optum.rqns.ftm.kafka.avro.models.v1.fieldactionrule.FieldActionRuleMetadata;
import com.optum.rqns.ftm.kafka.producer.KeyBasedFieldActionRuleProducer;
import com.optum.rqns.ftm.model.fieldactionrules.ReturnTargetTrackingAction;
import com.optum.rqns.ftm.model.fieldactionrules.RuleAction;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

@Slf4j
@Component
public class FieldActionRulesUtil {

    /*
       To produce the messages parallelly to kafka ,this method is written
    */
    @SneakyThrows
    public static long executeKafkaPushing(ExecutorService executorService, List<Callable<Boolean>> taskList) {
        long totalCount = 0;
        try {
            List<Future<Boolean>> results = executorService.invokeAll(taskList);
            for (Future<Boolean> f : results) {
                if (f != null && f.get() != null) {
                    totalCount = totalCount+1;
                }
            }
        } catch (InterruptedException | ExecutionException e) {
            log.error("Error pushing data to fieldActionTopic  ", e);
            throw e;
        } finally {
            taskList.clear();
            executorService.shutdown();
        }
        return totalCount;
    }
}
