package com.optum.rqns.ftm.controller;

import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.customannotation.CustomApiResponse;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.exception.ProgramPerformanceJobListenerException;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.model.ProgramYearCalendarDTO;
import com.optum.rqns.ftm.repository.common.CommonRepository;
import com.optum.rqns.ftm.repository.landingpage.LeaderPerformanceRepository;
import com.optum.rqns.ftm.repository.users.UsersRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.ws.rs.GET;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/v1")
@Slf4j
@CustomApiResponse
@Profile({"rqnsFtmJobs"})
public class LeaderHistoricalController {

    @Autowired
    private UsersRepository usersRepository;

    @Autowired
    private LeaderPerformanceRepository leaderPerformanceRepository;

    @Autowired
    private CommonRepository commonRepository;

    static final List<String> LEADER_ROLES = Arrays.asList("RVP", "Director", "Manager");
    static final List<String> IC_ROLES = Arrays.asList("PSC", "HCA");

    @GetMapping("/runHistoricalLeaderPerformance")
    public String runLeadersHistorical( @RequestParam(value = "programYear", required = true) int programYear,@RequestParam(value = "month", required = false) String month){
        JobStatus jobStatus = new JobStatus();
        jobStatus.setStatus(Status.SUCCESS);
        jobStatus.setUpdatedRows(0l);
        jobStatus.setMessage("Successfully completed LeaderLandingPage job");
        calculateForAllUsers(jobStatus,programYear,month);

        return null;
    }

    private void calculateForAllUsers(JobStatus jobStatus, int programYear,String inputmonth ) {

        try {
            //1. get RVPs,Directors,Managers
            List<String> leaders = usersRepository.getUsersByRole(LEADER_ROLES);
            log.info("leaders size {}", leaders.size());

            //2. get ICs
            List<String> ics = leaderPerformanceRepository.getUsersByRole(IC_ROLES);
            log.info("ics size {}", ics.size());

            List<ProgramYearCalendarDTO> monthDuartions = commonRepository.getYTDDurationMonth(programYear,inputmonth);
            log.info("monthDuartions size {}", monthDuartions.size());

            //3. Calculate For ics

            monthDuartions.stream().forEach( programYearCalendarDTO -> {
            ics.parallelStream()
                    .forEach(ic -> {
                        int updatedCount = 0;
                        // 1. Calculate Service Levels for this IC
                        List<String> serviceLevels = leaderPerformanceRepository.getServiceLevelForUser(ic);

                        List<String> serviceLevelsForPOC = serviceLevels.parallelStream().filter(sl-> sl.equalsIgnoreCase("HCA")).collect(Collectors.toList());
                    /*    // 2. Calculate Performance data
                        updatedCount = serviceLevels.parallelStream()
                                .map(sl -> leaderPerformanceRepository.calculateICPerformanceData(ic, sl, programYearCalendarDTO))
                                .reduce(Integer::sum)
                                .orElse(0);

                        log.info("IC {} Performance Data updated count {}", ic, updatedCount);

                        //Update the IC Actual Goal calculation
                        int goalCount = serviceLevels.parallelStream().map(sl->leaderPerformanceRepository.updateICGoalLeaderPerformance(ic,sl,programYearCalendarDTO))
                                .reduce(Integer::sum)
                                .orElse(0);
                        log.info("IC {} Performance Data updated with Actual goal data {}", ic, goalCount);*/
                        // 3. Calculate Growth Rate & POC

                        int growthRateUpdatedCount = serviceLevelsForPOC.parallelStream()
                                .map(sl -> leaderPerformanceRepository.calculateICGrowthRatePOCData(ic,sl, programYearCalendarDTO))
                                .reduce(Integer::sum)
                                .orElseGet(() -> 0);

                        log.info("IC {} GrowthRate & POC updated count {}", ic, growthRateUpdatedCount);

                        updatedCount +=growthRateUpdatedCount;

                        // 4. Calculate EModality
//                        int emodalityClientAndLObUpdatedCount = serviceLevels.parallelStream()
//                                .reduce(Integer::sum)
//                                .orElseGet(() -> 0);


                            int emodalityUpdatedCount = serviceLevels.parallelStream()
                                    .map(sl -> {
                                        int  count = leaderPerformanceRepository.calculateEModalityPOCDataHistorical(ic, sl, programYearCalendarDTO);
                                        count +=leaderPerformanceRepository.calculateEModalityPOCDataForClientAndLobHistorical(ic,sl, programYearCalendarDTO);
                                        count =leaderPerformanceRepository.calculateReturenNetCnaForALLHistorical(ic,sl, programYearCalendarDTO);
                                        count +=leaderPerformanceRepository.calculateReturenNetCnaForClientAndLobHistorical(ic,sl, programYearCalendarDTO);
                                        count +=leaderPerformanceRepository.calculateLeaderGrowthRatePOCDataForAllRegionAndStateHistorical(ic,List.of(ic),programYearCalendarDTO);
                                        return count;
                                    })
                                    .reduce(Integer::sum)
                                    .orElseGet(() -> 0);

                            log.info("IC {} Calculate EModality & POC updated count {}", ic, emodalityUpdatedCount);
                            updatedCount +=emodalityUpdatedCount;
//                        updatedCount +=emodalityClientAndLObUpdatedCount;



                     /*   //5. CGap Calculation

                        int cGapUpdatedCount = serviceLevels.parallelStream()
                                .map(sl -> leaderPerformanceRepository.calculateCGapData(ic,sl, programYearCalendarDTO))
                                .reduce(Integer::sum)
                                .orElseGet(() -> 0);

                        log.info("IC {} CGAP Closure updated count {}", ic, cGapUpdatedCount);

                        updatedCount +=cGapUpdatedCount;


                        jobStatus.setUpdatedRows(jobStatus.getUpdatedRows() + updatedCount);*/


                    });
            } );
            //4. get All IC under that Leaders and sum from LeaderPerformance table.
            monthDuartions.stream().forEach( programYearCalendarDTO -> {
                        leaders.parallelStream()
                                .forEach(leader -> {
                                    final List<String> totalReporters = usersRepository.getIcReporters(leader);

                                    int updatedCount = 0;
                                    if (Objects.nonNull(totalReporters) && !totalReporters.isEmpty()) {
                                        log.info("leader {} reporters {}", leader, totalReporters);

                                        // 2. Calculate Growth Rate & POC
                                        updatedCount += leaderPerformanceRepository.calculateLeaderGrowthRatePOCDataHistorical(leader, totalReporters,programYearCalendarDTO );

                                        updatedCount += leaderPerformanceRepository.calculateLeaderGrowthRatePOCDataForAllRegionAndStateHistorical(leader, List.of(leader), programYearCalendarDTO);

                                        log.info("Leader {} GrowthRate & POC updated count {}", leader, updatedCount);

                                        // 4. Calculate EModality
                                    }

                                    jobStatus.setUpdatedRows(jobStatus.getUpdatedRows() + updatedCount);

                                });
                    });

            // 5. Calculate National level calculateICGrowthRatePOCData
            monthDuartions.stream().forEach( programYearCalendarDTO -> {
                int updatedCount = 0;
                updatedCount +=leaderPerformanceRepository.calculateNationalGrowthRatePOCDataHistorical(Constants.NATIONAL, programYearCalendarDTO);
                updatedCount += leaderPerformanceRepository.calculateReturnNetCnaForNationalHistorical(Constants.NATIONAL, programYearCalendarDTO);
                updatedCount += leaderPerformanceRepository.calculateReturnNetCnaForAllNationalHistorical(Constants.NATIONAL, programYearCalendarDTO);
                updatedCount += leaderPerformanceRepository.calculateEModalityPOCDataForNationalHistorical(Constants.NATIONAL, programYearCalendarDTO);
                updatedCount += leaderPerformanceRepository.calculateEModalityPOCDataForNationalClientLobHistorical(Constants.NATIONAL, programYearCalendarDTO);
                updatedCount += leaderPerformanceRepository.calculateLeaderGrowthRatePOCDataForAllRegionAndStateHistorical(Constants.NATIONAL, List.of(Constants.NATIONAL), programYearCalendarDTO);

                // 6. Update Regions
//                        updatedCount += leaderPerformanceRepository.updateRegions(programYearCalendarDTO);
                leaderPerformanceRepository.updateRegionsForHistory(programYearCalendarDTO);
                log.info("Calculate ReturnNetCna updated count {}", updatedCount);
                jobStatus.setUpdatedRows(jobStatus.getUpdatedRows() + updatedCount);

            });


            log.info("*************** API Completed ***************");
        } catch (Exception e) {
            log.error("exception occurred in calculating leader level performance", e);
            throw new ProgramPerformanceJobListenerException("exception occurred in calculating leader performance");
        }
    }
}
