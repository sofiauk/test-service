package com.optum.rqns.ftm.service;

import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.model.JobStatus;

public interface IJob {

    JobStatus executeJob(JobEvent jobEvent);
}
