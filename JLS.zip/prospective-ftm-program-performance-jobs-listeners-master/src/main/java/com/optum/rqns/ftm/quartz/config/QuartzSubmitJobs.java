package com.optum.rqns.ftm.quartz.config;

import com.optum.rqns.ftm.quartz.jobs.QfoPatientExperienceScoresJob;
import com.optum.rqns.ftm.quartz.jobs.QfoPerformanceJob;
import com.optum.rqns.ftm.quartz.jobs.RunMemberPaymentOverallStatusSyncJobs;
import org.quartz.JobDetail;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.scheduling.quartz.CronTriggerFactoryBean;
import org.springframework.scheduling.quartz.JobDetailFactoryBean;

import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.quartz.jobs.MemberQualityGapsJob;
import com.optum.rqns.ftm.quartz.jobs.MonitoringJob;

import lombok.extern.slf4j.Slf4j;

@Profile("rqnsFtmJobs")
@Configuration
@Slf4j
public class QuartzSubmitJobs {

    @Value("${rqns.ftm.schedulerCron.monitoringJob}")
    private String monitoringJobCronExpression;
    @Value("${rqns.ftm.schedulerCron.memberQualityGaps}")
    private String memberQualityGapsJobCronExpression;
//    @Value("${rqns.ftm.schedulerCron.memberSuspectGaps}")
//    private String memberSuspectGapsJobCronExpression;
    @Value("${rqns.ftm.schedulerCron.runMemberOverallStatusSyncJob}")
    private String runMemberOverallStatusSyncJob;
    @Value("${rqns.ftm.schedulerCron.qfoPatientExperienceScoreJob}")
    private String qfoPatientExperienceScoreJobCronExpression;


    /**
     * This method is use to configure JobDetails for specific Job
     * @return
     */
    @Bean(name = "MonitoringJob")
    public JobDetailFactoryBean MonitoringJob() {
        return QuartzConfig
                .createJobDetail(MonitoringJob.class, JobName.MONITORING_JOB.getValue());
    }

    /**
     * This method will start Cron Job based on configuration and triggerd with JobDetails
     * @param jobDetail
     * @return
     */
    @Bean(name = "MonitoringJobTrigger")
    public CronTriggerFactoryBean triggerJobMonitoringJob(@Qualifier("MonitoringJob") JobDetail jobDetail) {
        return QuartzConfig
                .createCronTrigger(jobDetail, monitoringJobCronExpression, "triggerMonitoringJob");
    }
    
    /**
     * This method is use to configure JobDetails for specific Job
     * @return
     */
    @Bean(name = "MemberQualityGapsJob")
    public JobDetailFactoryBean memberQualityGapsJob() {
        return QuartzConfig
                .createJobDetail(MemberQualityGapsJob.class, JobName.QFOPERFORMANCE.getValue());
    }

    /**
     * This method will start Cron Job based on configuration and triggerd with JobDetails
     * @param jobDetail
     * @return
     */
    @Bean(name = "MemberQualityGapsJobTrigger")
    public CronTriggerFactoryBean triggerMemberQualityGapsJob(@Qualifier("MemberQualityGapsJob") JobDetail jobDetail) {
        return QuartzConfig
                .createCronTrigger(jobDetail, memberQualityGapsJobCronExpression, "triggerMemberQualityGapsJob");
    }
    /**
     * This method is use to configure JobDetails for specific Job
     * @return
     */
//    @Bean(name = "MemberSuspectGapsJob")
//    public JobDetailFactoryBean memberSuspectGapsJob() {
//        return QuartzConfig
//                .createJobDetail(MemberSuspectGapsJob.class, JobName.SUSPECT_CONDITIONS_OPPORTUNITIES.getValue());
//    }
//
//    /**
//     * This method will start Cron Job based on configuration and triggerd with JobDetails
//     * @param jobDetail
//     * @return
//     */
//    @Bean(name = "MemberSuspectGapsJobTrigger")
//    public CronTriggerFactoryBean triggerMemberSuspectGapsJob(@Qualifier("MemberSuspectGapsJob") JobDetail jobDetail) {
//        return QuartzConfig
//                .createCronTrigger(jobDetail, memberSuspectGapsJobCronExpression, "triggerMemberSuspectGapsJob");
//    }

    /**
     * This method is use to configure JobDetails for specific Job
     * @return
     */
    @Bean(name = "QfoPerformanceJob")
    public JobDetailFactoryBean qfoPerformanceJob() {
        return QuartzConfig
                .createJobDetail(QfoPerformanceJob.class, JobName.QFOPERFORMANCE.getValue());
    }

    /**
     * This method will start Cron Job based on configuration and triggerd with JobDetails
     * @param jobDetail
     * @return
     */

    @Bean(name = "RunMemberPaymentOverallStatusSyncJobs")
    public JobDetailFactoryBean runMemberPaymentOverallStatusSyncJobs() {
        return QuartzConfig
                .createJobDetail(RunMemberPaymentOverallStatusSyncJobs.class, "RunMemberPaymentOverallStatusSyncJobs");
    }

    @Bean(name = "RunMemberPaymentOverallStatusSyncJobsTrigger")
    public CronTriggerFactoryBean triggerRunMemberPaymentOverallStatusSyncJobs(@Qualifier("RunMemberPaymentOverallStatusSyncJobs") JobDetail jobDetail) {
        return QuartzConfig
                .createCronTrigger(jobDetail, runMemberOverallStatusSyncJob, "RunMemberPaymentOverallStatusSyncJobsTrigger");
    }
    /**
     * This method is use to configure JobDetails for specific Job
     *
     * @return
     */
    @Bean(name = "QfoPatientExperienceScoreJob")
    public JobDetailFactoryBean qfoPatientExperienceScoreJob() {
        return QuartzConfig
                .createJobDetail(QfoPatientExperienceScoresJob.class, JobName.QFO_PATIENT_EXPERIENCE_SCORES.getValue());
    }

    /**
     * This method will start Cron Job based on configuration and triggerd with JobDetails
     *
     * @param jobDetail
     * @return
     */
    @Bean(name = "QfoPatientExperienceScoreJobTrigger")
    public CronTriggerFactoryBean triggerQfoPatientExperienceScoreJob(@Qualifier("QfoPatientExperienceScoreJob") JobDetail jobDetail) {
        return QuartzConfig
                .createCronTrigger(jobDetail, qfoPatientExperienceScoreJobCronExpression, "triggerQfoPatientExperienceScoreJob");
    }


}
