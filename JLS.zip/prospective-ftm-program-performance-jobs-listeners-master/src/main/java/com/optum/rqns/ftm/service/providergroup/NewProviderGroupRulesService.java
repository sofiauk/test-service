package com.optum.rqns.ftm.service.providergroup;

import com.optum.rqns.ftm.service.IJob;
import org.springframework.stereotype.Service;

@Service
public interface NewProviderGroupRulesService extends IJob {
}
