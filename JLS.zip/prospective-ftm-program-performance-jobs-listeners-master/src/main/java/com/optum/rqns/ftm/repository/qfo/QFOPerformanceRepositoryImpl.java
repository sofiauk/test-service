package com.optum.rqns.ftm.repository.qfo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.optum.rqns.ftm.model.qfo.QfoPerformanceData;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.model.qfo.CommonProgramYearCalenderDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;
import com.optum.rqns.ftm.model.qfo.QFOMemberSuspect;
import com.optum.rqns.ftm.util.ProgramPerformanceJobUtil;



@Repository
@Slf4j
public class QFOPerformanceRepositoryImpl implements QFOPerformanceRepository {

	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	private static final String TOTAL_SUSPECT_CONDITIONS = "SELECT COUNT(*) AS SuspectConditionsTotal, ASSOC_PROV_GRP_ID, GAP_YR, ASSOC_HLTH_SYS_ID, LINE_OF_BUSINESS  FROM "
			+ "PROGPERF.MEMBERSUSPECT WITH (NOLOCK) "
			+ "WHERE PCOR_MBR_FLAG = 'Y' AND  MBR_INCNT_PGM_IND LIKE '%MCAIP%' AND MBR_INCNT_PGM_IND IS NOT NULL AND MBR_INCNT_PGM_IND != ''"
			+ "AND IS_ACTIVE = 'Y' AND GAP_YR = :PROGRAMYEAR and LINE_OF_BUSINESS IN (select * from STRING_SPLIT((select value from ProgPerf.CategoryMasterConfiguration mc where Name='QfoLineOfBusiness'),',')) "
			+ " %s GROUP BY ASSOC_PROV_GRP_ID, GAP_YR, ASSOC_HLTH_SYS_ID, LINE_OF_BUSINESS";

	private static final String TOTAL_MODIFIED_SUSPECT_CONDITIONS = "SELECT COUNT(*) AS SuspectConditionsTotal FROM "
			+ "PROGPERF.MEMBERSUSPECT WITH (NOLOCK) "
			+ "WHERE  GAP_YR = :PROGRAMYEAR and LINE_OF_BUSINESS IN (select * from STRING_SPLIT((select value from ProgPerf.CategoryMasterConfiguration mc where Name='QfoLineOfBusiness'),',')) "
			+ " %s ";

	private static final String SUSPECT_CONDITIONS_ASSESSMENTS_COMMON_QUERY = "SELECT COUNT(*) AS COLUMN_NAME,ASSOC_PROV_GRP_ID, "
			+ "GAP_YR, ASSOC_HLTH_SYS_ID, LINE_OF_BUSINESS  "
			+ "FROM PROGPERF.MEMBERSUSPECT WITH (NOLOCK) WHERE PCOR_MBR_FLAG = 'Y' AND  (MBR_INCNT_PGM_IND LIKE '%MCAIP%') AND MBR_INCNT_PGM_IND IS NOT NULL "
			+ "AND MBR_INCNT_PGM_IND != '' " + "AND IS_ACTIVE = 'Y' "
			+ " and LINE_OF_BUSINESS IN (select * from STRING_SPLIT((select value from ProgPerf.CategoryMasterConfiguration mc where Name='QfoLineOfBusiness'),',')) "
			+ "%s "
			+ "AND ( %assessmentStatus ) AND GAP_YR = :PROGRAMYEAR GROUP BY ASSOC_PROV_GRP_ID, GAP_YR, ASSOC_HLTH_SYS_ID, LINE_OF_BUSINESS";

	private static final String TOTAL_ASSESSED_SUSPECT_CONDITIONS = "SELECT COUNT(ASSESSMENT_STATUS) AS SuspectConditionsAssessedTotal,ASSOC_PROV_GRP_ID, "
			+ "GAP_YR, ASSOC_HLTH_SYS_ID, LINE_OF_BUSINESS  "
			+ "FROM PROGPERF.MEMBERSUSPECT WITH (NOLOCK) WHERE PCOR_MBR_FLAG = 'Y' AND  (MBR_INCNT_PGM_IND LIKE '%MCAIP%') AND MBR_INCNT_PGM_IND IS NOT NULL "
			+ "AND MBR_INCNT_PGM_IND != '' " + "AND IS_ACTIVE = 'Y' "
			+ " and LINE_OF_BUSINESS IN (select * from STRING_SPLIT((select value from ProgPerf.CategoryMasterConfiguration mc where Name='QfoLineOfBusiness'),',')) "
			+ " %s"
			+ "AND ( ASSESSMENT_STATUS = 'ASSESSED AND DIAGNOSED' OR ASSESSMENT_STATUS = 'ASSESSED AND UNABLE TO DIAGNOSE AT THIS TIME') AND GAP_YR = :PROGRAMYEAR GROUP BY ASSOC_PROV_GRP_ID, GAP_YR, ASSOC_HLTH_SYS_ID, LINE_OF_BUSINESS";

	private static final String ASSESSED_AND_DIAGNOSED_SUSPECT_CONDITIONS = "ASSESSMENT_STATUS = 'ASSESSED AND DIAGNOSED'";

	private static final String ASSESSED_AND_UNDIAGNOSED_SUSPECT_CONDITIONS = "ASSESSMENT_STATUS = 'ASSESSED AND UNABLE TO DIAGNOSE AT THIS TIME'";

	private static final String NOT_ASSESSED_SUSPECT_CONDITIONS = "ASSESSMENT_STATUS = 'NOT ASSESSED'";

	private static final String TOTAL_FULLY_ASSESSED_SUSPECT_CONDITIONS = "ASSESSMENT_STATUS = 'ASSESSED AND DIAGNOSED' OR ASSESSMENT_STATUS = 'ASSESSED AND UNABLE TO DIAGNOSE AT THIS TIME'";

	private static final String TOTAL_FULLY_ASSESSED_SUSPECT_CONDITIONS_QUERY = "SELECT  " +
			" COUNT_COLUMN AS COLUMN_NAME,  " +
			" ASSOC_PROV_GRP_ID,  " +
			" GAP_YR,  " +
			" ASSOC_HLTH_SYS_ID,  " +
			" LINE_OF_BUSINESS  " +
			"FROM  " +
			" ProgPerf.MemberSuspect mes WITH (nolock)  " +
			"WHERE  " +
			" NOT EXISTS (  " +
			" SELECT  " +
			"  NULL  " +
			" FROM  " +
			"  ProgPerf.MemberSuspect ms WITH (nolock)  " +
			" WHERE  " +
			"  ms.ASSESSMENT_STATUS IN ('Not Assessed')  " +
			"   AND ms.PCOR_MBR_FLAG = mes.PCOR_MBR_FLAG  " +
			"   AND ms.GAP_YR = mes.GAP_YR  " +
			"   AND ms.MBR_INCNT_PGM_IND = mes.MBR_INCNT_PGM_IND  " +
			"   AND ms.IS_ACTIVE = mes.IS_ACTIVE  " +
			"   AND  " +
			"     ms.GLB_MBR_ID = mes.GLB_MBR_ID  " +
			"   AND ms.LINE_OF_BUSINESS = mes.LINE_OF_BUSINESS)  " +
			"   %s " +
			" AND mes.PCOR_MBR_FLAG = 'Y'  " +
			" AND (mes.MBR_INCNT_PGM_IND LIKE '%MCAIP%')  " +
			" AND mes.MBR_INCNT_PGM_IND IS NOT NULL  " +
			" AND mes.GAP_YR =:PROGRAMYEAR " +
			" AND (%assessmentStatus)  " +
			" AND mes.MBR_INCNT_PGM_IND != ''  " +
			" AND mes.IS_ACTIVE = 'Y'  " +
			" AND mes.LINE_OF_BUSINESS IN (  " +
			" SELECT  " +
			"  *  " +
			" FROM  " +
			"  STRING_SPLIT((  " +
			"  SELECT  " +
			"   value  " +
			"  FROM  " +
			"   ProgPerf.CategoryMasterConfiguration mc  " +
			"  WHERE  " +
			"   Name = 'QfoLineOfBusiness'),  " +
			"  ','))  " +
			"GROUP BY  " +
			" ASSOC_PROV_GRP_ID,  " +
			" GAP_YR,  " +
			" ASSOC_HLTH_SYS_ID,  " +
			" LINE_OF_BUSINESS ";

	private static final String MERGE_SUSPECT_CONDITIONS = "MERGE PROGPERF.PROVIDERGROUPPERFORMANCEDETAILS AS TGT   "
			+ " USING (:SUB_QUERY) AS SRC   " + " ON ( SRC.ASSOC_PROV_GRP_ID = TGT.PROVIDERGROUPID AND   "
			+ " SRC.GAP_YR  = TGT.PROGRAMYEAR AND "
			+ "TGT.DURATIONVALUE =:DURATIONVALUE AND "
			+ " TGT.TEAMTYPE = 'QFO' AND "
			+ " TGT.PCORFLAG = 1"
			+ " AND SRC.ASSOC_HLTH_SYS_ID = TGT.HealthSystemId "
			+ " AND SRC.LINE_OF_BUSINESS = TGT.LOB) WHEN MATCHED THEN "
			+ "UPDATE SET TGT.COLUMN_NAME=SRC.COLUMN_NAME, TGT.UPDATEDDATE = GETUTCDATE() "
			+ " WHEN NOT MATCHED THEN   "
			+ " INSERT ( PROVIDERGROUPID, PROGRAMYEAR, DURATIONVALUE,HealthSystemId,HealthSystemName, PCORFLAG, TEAMTYPE, COLUMN_NAME, CREATEDDATE, CREATEDBY, UPDATEDDATE, UPDATEDBY, LOB)  "
			+ " VALUES ( SRC.ASSOC_PROV_GRP_ID, SRC.GAP_YR , :DURATIONVALUE,src.ASSOC_HLTH_SYS_ID,(SELECT " +
			"TOP 1 HealthSysName " +
			"from " +
			"ProgPerf.UHCProviderGroup " +
			"where " +
			"HealthSysID = src.ASSOC_HLTH_SYS_ID " +
			"and ProgramYear =SRC.GAP_YR " +
			"and HealthSysID <> '' " +
			"and IsDeleted = 0 " +
			"order by " +
			"UpdatedDate desc ) , 1, 'QFO', SRC.COLUMN_NAME, GETUTCDATE(),'RunQFOPerformance',GETUTCDATE() ,"
			+ "'RunQFOPerformance', SRC.LINE_OF_BUSINESS);  " + "  ";


	private static final String SUSPECT_CONDITIONS_COMMON_ORDERBY_QUERY = " ORDER BY ASSOC_PROV_GRP_ID, GAP_YR  ";

	private static final String SUSPECT_CONDITIONS_COMMON_OFFSET_QUERY = " OFFSET :OFFSET ROWS FETCH NEXT :BATCHSIZE ROWS ONLY ";

	private static final String SUSPECT_CONDITIONS_ALL_RECORDS_COUNT = "SELECT COUNT (*) AS TOTAL_COUNT FROM ( "
			+ TOTAL_SUSPECT_CONDITIONS + ") AS ALL_SUSPECT_CONDITIONS_QFO_RECORDS";

	private static final String FETCH_LAST_JOB_RUN_DATE = "SELECT TOP 1 "
			+ "  CONVERT(VARCHAR, JRC.LASTSUCCESSFULRUNDATE, 20) AS LASTSUCCESSFULRUNDATE  " + "FROM  "
			+ "  PROGPERF.JOBRUNCONFIGURATION JRC WITH (NOLOCK)  " + "WHERE  " + " JRC.JOBNAME = 'RunQFOPerformance'";

	private static final String MODIFIED_SUSPECT_CONDITIONS = "SELECT ASSOC_PROV_GRP_ID as providerGroupId, GAP_YR as programYear FROM PROGPERF.MEMBERSUSPECT WITH (NOLOCK) WHERE " +
			" UPDATEDDATE >= ':updatedDate' AND GAP_YR = :PROGRAMYEAR  GROUP BY ASSOC_PROV_GRP_ID, GAP_YR ";

	private static final String[] SUSPECT_CONDITIONS_PERFORMANCE_COLUMN_NAMES = { "SuspectConditionsTotal",
			"SuspectConditionsAssessedTotal", "SuspectConditionsAssessedDiagnosed",
			"SuspectConditionsAssessedUndiagnosed", "SuspectConditionsNotAssessed", "McaipPatientsFullyAssessed",
			"McaipSuspectMedicalConditions" };

	private static final String COLUMN_NAME = "COLUMN_NAME";
	private static final String QFO_PERF_JOB = "RunQFOPerformance";

	private static final String MERGE_PROVIDER_GROUP_PERFORMANCE_DETIALS ="with annualCareVists as (" +
			" select" +
			" ms.ASSOC_PROV_GRP_ID," +
			" LINE_OF_BUSINESS," +
			" ms.assoc_Hlth_sys_Id, "+
			" count(*) MapCpiAnnualCareVisits" +
			" FROM" +
			" ProgPerf.MemberSummary ms with (nolock)" +
			" Where" +
			" ms.MBR_PGM_YEAR =:ProgramYear" +
			" AND ms.MBR_ANNL_CARE_VST_DT <> ''" +
			" AND year(ms.MBR_ANNL_CARE_VST_DT)=:ProgramYear" +
			" and ms.MBR_INCNT_PGM_IND like '%MAPCPI%'" +
			" and ms.IS_ACTIVE = 'Y' and ms.PCOR_MBR_FLAG = 'Y'" +
			" GROUP by" +
			" ASSOC_PROV_GRP_ID," +
			" LINE_OF_BUSINESS," +
			" assoc_Hlth_sys_Id)"+
			" MERGE ProgPerf.ProviderGroupPerformanceDetails as tgt " +
			" using ( " +
			"select   " +
			" Distinct mq.ASSOC_PROV_GRP_ID ProviderGroupId, " +
			"  mq.ASSOC_HLTH_SYS_ID HealthSystemID, " +
			"  mq.LINE_OF_BUSINESS LOB, " +
			" count( CASE WHEN  mq.IS_ACTIVE = 'Y'  then mq.ID END ) as TotalPatients, " +
			" count( CASE WHEN (mq.MBR_INCNT_PGM_IND like '%MAPCPI%'   and mq.IS_ACTIVE = 'Y' )then ID END) as MapCpiEligiblePatients, " +
			" count( CASE WHEN (mq.MBR_INCNT_PGM_IND like '%MCAIP%' and mq.IS_ACTIVE = 'Y' )  then ID END) as McaipTotalPatients, " +
			" avg(ac.MapCpiAnnualCareVisits) as MapCpiAnnualCareVisits " +
			"from " +
			" ProgPerf.MemberQuality mq with (nolock) " +
			" full outer join " +
			" annualCareVists ac with (nolock) on " +
			" mq.ASSOC_PROV_GRP_ID = ac.ASSOC_PROV_GRP_ID " +
			"  and mq.LINE_OF_BUSINESS = ac.LINE_OF_BUSINESS"+
			" and mq.ASSOC_HLTH_SYS_ID = ac.assoc_Hlth_sys_Id "+
			" where " +
			" mq.PCOR_MBR_FLAG = 'Y' " +
			" and mq.GAP_YR =:ProgramYear " +
			" and mq.IS_ACTIVE = 'Y' " +
			" and mq.LINE_OF_BUSINESS IN (select * from STRING_SPLIT((select value from ProgPerf.CategoryMasterConfiguration mc where Name='QfoLineOfBusiness'),',')) " +
			"  :MODIFIED " +
			" GROUP by " +
			" mq.ASSOC_PROV_GRP_ID, mq.LINE_OF_BUSINESS, mq.ASSOC_HLTH_SYS_ID " +
			"  ORDER BY mq.[ASSOC_PROV_GRP_ID] OFFSET :OFFSET ROWS FETCH NEXT :BATCHSIZE ROWS ONLY ) as src on " +
			"src.ProviderGroupId = tgt.ProviderGroupId " +
			"and tgt.DurationValue =:DurationValue " +
			"and tgt.ProgramYear = :ProgramYear " +
			"and tgt.TeamType = 'QFO' " +
			"and src.HealthSystemID  = tgt.HealthSystemId " +
			"and src.LOB = tgt.LOB " +
			"when MATCHED THEN " +
			"update " +
			"set " +
			" tgt.TotalPatients = src.TotalPatients, " +
			" tgt.MapCpiAnnualCareVisits = src.MapCpiAnnualCareVisits, " +
			" tgt.MapCpiEligiblePatients = src.MapCpiEligiblePatients, " +
			" tgt.McaipTotalPatients = src.McaipTotalPatients, " +
			" tgt.UpdatedDate = GETUTCDATE(), "+
			" tgt.MapCpiLastUpdated = GETUTCDATE(), "+
			" tgt.McaipLastUpdated = GETUTCDATE(), "+
			" tgt.LOB  = src.Lob, " +
			" tgt.HealthSystemName = (SELECT " +
			"    TOP 1 HealthSysName    " +
			"   from    " +
			"    ProgPerf.UHCProviderGroup    " +
			"   where    " +
			"    HealthSysID = src.HealthSystemID    " +
			"    and ProgramYear =:ProgramYear    " +
			"    and HealthSysID <> ''    " +
			"    and IsDeleted = 0    " +
			"   order by    " +
			"    UpdatedDate desc )    "+
			" when not MATCHED THEN " +
			"INSERT " +
			" (ProviderGroupId, " +
			" HealthSystemId, " +
			" HealthSystemName, "+
			" ProgramYear, " +
			" DurationValue, " +
			" TotalPatients, " +
			" MapCpiEligiblePatients, " +
			" MapCpiAnnualCareVisits, " +
			" McaipTotalPatients, " +
			" MapCpiLastUpdated, "+
			" McaipLastUpdated, "+
			" PcorFlag, " +
			" TeamType, " +
			" CreatedDate, " +
			" CreatedBy, " +
			" UpdatedDate, " +
			" UpdatedBy, " +
			" LOB) " +
			"VALUES(src.ProviderGroupId, " +
			"src.HealthSystemID, " +
			"(SELECT TOP  1  HealthSysName from ProgPerf.UHCProviderGroup where HealthSysID = src.HealthSystemID and ProgramYear =:ProgramYear and HealthSysID <> '' and IsDeleted =0 order by UpdatedDate desc ), " +
			":ProgramYear, " +
			":DurationValue, " +
			"src.TotalPatients, " +
			"src.MapCpiEligiblePatients, " +
			"src.MapCpiAnnualCareVisits, " +
			"src.McaipTotalPatients, " +
			"GETUTCDATE(), " +
			"GETUTCDATE(), " +
			"1, " +
			"'QFO', " +
			"GETUTCDATE(), " +
			":UpdatedBy , " +
			"GETUTCDATE(), " +
			":UpdatedBy," +
			"src.LOB); " ;


	private static final String QUERY_PROVIDER_GROUPS_MEMBER_QUALITY_COUNT = "select " +
			" Count(*) MemberQualityCount " +
			"from " +
			" ( " +
			" select " +
			"   DISTINCT ASSOC_PROV_GRP_ID , ASSOC_HLTH_SYS_ID , LINE_OF_BUSINESS " +
			" from " +
			"  ProgPerf.MemberQuality mq  with (nolock) " +
			" where " +
			"   mq.GAP_YR =:ProgramYear " +
			"  and LINE_OF_BUSINESS IN (select * from STRING_SPLIT((select value from ProgPerf.CategoryMasterConfiguration mc where Name='QfoLineOfBusiness'),',')) " +
			" :MODIFIED " +
			" group by " +
			"   ASSOC_PROV_GRP_ID , ASSOC_HLTH_SYS_ID , LINE_OF_BUSINESS ) MemberQualityPGTable ; ";

	private static final String STAR_RATING_INJESTION_GROUPS_COMMON_COUNT_QUERY = "SELECT GroupId from ProgPerf.StarRatingIngestion WITH (NOLOCK) " +
			"WHERE ProgramYear =  %s " +
			"%s " +
			"GROUP BY GroupId ";

	private static final String STAR_RATING_INJESTION_COUNT_QUERY = "select count(*) AS totalCount from " +
			"(" + STAR_RATING_INJESTION_GROUPS_COMMON_COUNT_QUERY + ") AS ASRRatingCount";

	private static final String MODIFIED_CONDITION = " AND CAST(UpdatedDate as date) >= (select CAST(LastSuccessfulRunDate as date)" +
			" from ProgPerf.jobrunconfiguration where jobname = '" + JobName.QFOPERFORMANCE.getValue() + "')";

	private static final String PROVIDER_GROUP_PERFORMANCE_ASR_MERGE_QUERY = " with t as( " +
			"SELECT " +
			" GroupId , " +
			" HealthSystemId , " +
			" HealthSystemName , " +
			" ProgramYear , " +
			" MapcpiRating , " +
			" OverallRating , " +
			" AcoRating , " +
			" PartDRating , " +
			" RatingType, " +
			" UpdatedDate , " +
			" ROW_NUMBER() over (partition by GroupId " +
			"order by " +
			" UpdatedDate desc) as rnk " +
			"FROM " +
			" ProgPerf.[StarRatingIngestion] WITH (NOLOCK) " +
			"WHERE " +
			" ProgramYear = :ProgramYear " +
			" AND IsActive = '1' " +
			"ORDER BY " +
			" [GroupId] OFFSET :OFFSET ROWS FETCH NEXT :BATCHSIZE ROWS ONLY) " +
			"MERGE ProgPerf.[ProviderGroupPerformanceDetails] AS tgt" +
			"       USING (SELECT " +
			" * " +
			"from " +
			" t " +
			"where " +
			" rnk = 1  ) AS src" +
			"             ON (" +
			"                           tgt.ProviderGroupId = src.GroupId" +
			"                           AND tgt.ProgramYear = src.ProgramYear" +
			"                           AND tgt.DurationValue = :DurationValue" +
			"                           AND tgt.TeamType = :TeamType" +
			"                           )" +
			"       WHEN MATCHED" +
			"             THEN" +
			"                    UPDATE" +
			"                    SET tgt.ProviderGroupId = src.GroupId" +
			"                           , tgt.ProgramYear = src.ProgramYear" +
			"                           , tgt.HealthSystemId = src.HealthSystemId" +
			"                           , tgt.HealthSystemName = (SELECT DISTINCT  HealthSysName from ProgPerf.UHCProviderGroup where HealthSysID=src.HealthSystemId AND ProgramYear =:ProgramYear and IsDeleted=0 ) " +
			"                           , tgt.HealthSystemOverallStarRating = (CASE WHEN src.RatingType <> 'GROUP' THEN src.OverallRating else null END)" +
			"                           , tgt.HealthSystemMAPCPIStarRating = (CASE WHEN src.RatingType <> 'GROUP' THEN src.MapcpiRating else null END)" +
			"                           , tgt.HealthSystemPartDRating = (CASE WHEN src.RatingType <> 'GROUP' THEN src.PartDRating else null END)" +
			"                           , tgt.HealthSystemACOStarRating = (CASE WHEN src.RatingType <> 'GROUP' THEN src.AcoRating else null END)" +
			"                           , tgt.OverallStarRating = src.OverallRating" +
			"                           , tgt.MapCpiStarRating = src.MapcpiRating" +
			"                           , tgt.MapCpiPartDStarRating = src.PartDRating" +
			"                           , tgt.AcoStarRating = src.AcoRating" +
			"                           , tgt.TeamType = :TeamType" +
			"                           , tgt.UpdatedDate = GETUTCDATE()" +
			"                           , tgt.UpdatedBy = :UpdatedBy" +
			"       WHEN NOT MATCHED" +
			"             THEN" +
			"                    INSERT (" +
			"                           ProviderGroupId" +
			"                           , ProgramYear" +
			"                           , HealthSystemId" +
			"                           , HealthSystemName" +
			"                           , HealthSystemOverallStarRating" +
			"                           , HealthSystemMAPCPIStarRating" +
			"                           , HealthSystemPartDRating" +
			"                           , HealthSystemACOStarRating" +
			"                           , OverallStarRating" +
			"                           , MapCpiStarRating" +
			"                           , MapCpiPartDStarRating" +
			"                           , AcoStarRating" +
			"                           , DurationValue" +
			"                           , TeamType" +
			"                           , CreatedDate" +
			"                           , UpdatedDate" +
			"                           , CreatedBy" +
			"                           , UpdatedBy" +
			"                           )" +
			"                    VALUES (" +
			"                           src.GroupId" +
			"                           , src.ProgramYear" +
			"                           , src.HealthSystemId" +
			"                           , (SELECT DISTINCT  HealthSysName from ProgPerf.UHCProviderGroup where HealthSysID =src.HealthSystemId AND ProgramYear =src.ProgramYear and IsDeleted =0 ) " +
			"                           , (CASE WHEN src.RatingType <> 'GROUP' THEN src.OverallRating else null END)" +
			"                           , (CASE WHEN src.RatingType <> 'GROUP' THEN src.MapcpiRating else null END)" +
			"                           , (CASE WHEN src.RatingType <> 'GROUP' THEN src.PartDRating else null END)" +
			"                           , (CASE WHEN src.RatingType <> 'GROUP' THEN src.AcoRating else null END)" +
			"                           , src.OverallRating" +
			"                           , src.MapcpiRating" +
			"                           , src.PartDRating" +
			"                           , src.AcoRating" +
			"                           , :DurationValue" +
			"                           , :TeamType" +
			"                           , GETUTCDATE()" +
			"                           , GETUTCDATE()" +
			"                           , :UpdatedBy" +
			"                           , :UpdatedBy" +
			"                           );";

	private static String HEALTH_SYSTEM_UPDATE_COUNT_QUERY=" select " +
			" count(pg.HealthSystemId) AS totalCount " +
			"from " +
			" ( " +
			" select " +
			"  HealthSystemId , " +
			"  HealthSystemName, " +
			"  HealthSystemACOStarRating , " +
			"  HealthSystemMAPCPIStarRating , " +
			"  HealthSystemOverallStarRating , " +
			"  HealthSystemPartDRating, " +
			"  McaipLastUpdated, " +
			"  MapCpiLastUpdated, " +
			"  PcorFlag, " +
			"  IncentiveProgram, " +
			"  MapCpiPatientExperience " +
			" from " +
			"  ProgPerf.ProviderGroupPerformanceDetails pgpd " +
			" WHERE " +
			"  pgpd.PcorFlag = 1 " +
			"  and pgpd.TeamType =:TeamType " +
			"  and pgpd.ProgramYear =:ProgramYear " +
			"  and pgpd.DurationValue =:DurationValue " +
			"  %s " +
			"  group by pgpd.HealthSystemId, " +
			"  HealthSystemName, " +
			"  HealthSystemACOStarRating , " +
			"  HealthSystemMAPCPIStarRating , " +
			"  HealthSystemOverallStarRating , " +
			"  HealthSystemPartDRating, " +
			"  McaipLastUpdated, " +
			"  MapCpiLastUpdated, " +
			"  PcorFlag, " +
			"  IncentiveProgram, " +
			"  MapCpiPatientExperience ) PG ";

	private static String HEALTH_SYSTEM_DATA_LOD_QUERY="MERGE ProgPerf.HealthSystemPerformanceDetails as tgt " +
			" using ( " +
			"select " +
			" HealthSystemId , " +
			" HealthSystemName, " +
			" HealthSystemACOStarRating , " +
			" HealthSystemMAPCPIStarRating , " +
			" HealthSystemOverallStarRating , " +
			" HealthSystemPartDRating, " +
			" McaipLastUpdated, " +
			" MapCpiLastUpdated, " +
			" PcorFlag, " +
			" IncentiveProgram, " +
			" MapCpiPatientExperience, " +
			" sum(TotalPatients) TotalPatients , " +
			" sum(MapCpiEligiblePatients) MapCpiEligiblePatients, " +
			" sum(MapCpiAnnualCareVisits) MapCpiAnnualCareVisits, " +
			" sum(McaipSuspectMedicalConditions) McaipSuspectMedicalConditions, " +
			" sum(McaipPatientsFullyAssessed) McaipPatientsFullyAssessed, " +
			" sum(McaipTotalPatients) McaipTotalPatients, " +
			" sum(SuspectConditionsTotal) SuspectConditionalTotal, " +
			" sum(SuspectConditionsAssessedTotal) SuspectConditionsAssessedTotal, " +
			" sum(SuspectConditionsAssessedDiagnosed) SuspectConditionsAssessedDiagnosed, " +
			" sum(SuspectConditionsAssessedUndiagnosed) SuspectConditionsAssessedUndiagnosed, " +
			" sum(SuspectConditionsNotAssessed) SuspectConditionsNotAssessed " +
			"from " +
			" ProgPerf.ProviderGroupPerformanceDetails pgpd " +
			"WHERE " +
			" pgpd.PcorFlag = 1 " +
			" and pgpd.TeamType =:TeamType " +
			" and pgpd.ProgramYear =:ProgramYear " +
			" and pgpd.DurationValue =:DurationValue " +
			" and pgpd.HealthSystemId <> '' "+
			" %s " +
			"group by " +
			" pgpd.HealthSystemId, " +
			" HealthSystemName, " +
			" HealthSystemACOStarRating , " +
			" HealthSystemMAPCPIStarRating , " +
			" HealthSystemOverallStarRating , " +
			" HealthSystemPartDRating, " +
			" McaipLastUpdated, " +
			" MapCpiLastUpdated, " +
			" PcorFlag, " +
			" IncentiveProgram, " +
			" MapCpiPatientExperience " +
			"order by " +
			" HealthSystemId OFFSET :OFFSET ROWS FETCH NEXT :BATCHSIZE ROWS ONLY) src on " +
			"src.HealthSystemId = tgt.HealthSystemId " +
			"and tgt.DurationValue =:DurationValue " +
			"and tgt.ProgramYear = :ProgramYear " +
			"and tgt.TeamType =:TeamType " +
			"when matched then " +
			"update " +
			"set " +
			" tgt.AcpStarRating = src.HealthSystemACOStarRating , " +
			" tgt.MapCpiStarRating = src.HealthSystemMAPCPIStarRating , " +
			" tgt.OverallStarRating = src.HealthSystemOverallStarRating , " +
			" tgt.MapCpiPartDStarRating = src.HealthSystemPartDRating, " +
			" tgt.McaipLastUpdated = src.McaipLastUpdated, " +
			" tgt.MapCpiLastUpdated = src.MapCpiLastUpdated, " +
			" tgt.PcorFlag = src.PcorFlag, " +
			" tgt.IncentiveProgram = src.IncentiveProgram, " +
			" tgt.MapCpiPatientExperience = src.MapCpiPatientExperience, " +
			" tgt.TotalPatients = src.TotalPatients , " +
			" tgt.MapCpiEligiblePatients = src.MapCpiEligiblePatients, " +
			" tgt.MapCpiAnnualCareVisits = src.MapCpiAnnualCareVisits, " +
			" tgt.McaipSuspectMedicalConditions = src.McaipSuspectMedicalConditions, " +
			" tgt.McaipTotalPatients = src.McaipTotalPatients, "+
			" tgt.McaipPatientsFullyAssessed = src.McaipPatientsFullyAssessed, " +
			" tgt.SuspectConditionalTotal = src.SuspectConditionalTotal, " +
			" tgt.SuspectConditionsAssessedTotal = src.SuspectConditionsAssessedTotal, " +
			" tgt.SuspectConditionsAssessedDiagnosed = src.SuspectConditionsAssessedDiagnosed, " +
			" tgt.SuspectConditionsAssessedUndiagnosed = src.SuspectConditionsAssessedUndiagnosed, " +
			" tgt.SuspectConditionsNotAssessed = src.SuspectConditionsNotAssessed, " +
			" tgt.UpdatedDate = GETUTCDATE() , " +
			" tgt.UpdatedBy = :UpdatedBy " +
			" when not matched then " +
			"INSERT " +
			" (HealthSystemId, " +
			" HealthSystemName, " +
			" ProgramYear, " +
			" DurationValue, " +
			" TotalPatients, " +
			" OverallStarRating, " +
			" MapCpiEligiblePatients, " +
			" MapCpiStarRating, " +
			" MapCpiPatientExperience, " +
			" MapCpiPartDStarRating, " +
			" AcpStarRating, " +
			" MapCpiAnnualCareVisits, " +
			" MapCpiLastUpdated, " +
			" SuspectConditionalTotal, " +
			" SuspectConditionsAssessedTotal, " +
			" SuspectConditionsAssessedDiagnosed, " +
			" SuspectConditionsAssessedUndiagnosed, " +
			" SuspectConditionsNotAssessed, " +
			" McaipPatientsFullyAssessed, " +
			" McaipSuspectMedicalConditions, " +
			" McaipLastUpdated, " +
			" McaipTotalPatients, "+
			" PcorFlag, " +
			" IncentiveProgram, " +
			" TeamType, " +
			" CreatedDate, " +
			" CreatedBy, " +
			" UpdatedDate, " +
			" UpdatedBy) " +
			"VALUES(src.HealthSystemId, " +
			"src.HealthSystemName, " +
			":ProgramYear, " +
			":DurationValue , " +
			"src.TotalPatients, " +
			"src.HealthSystemOverallStarRating , " +
			"src.MapCpiEligiblePatients , " +
			"src.HealthSystemMAPCPIStarRating , " +
			"src.MapCpiPatientExperience, " +
			"src.HealthSystemPartDRating, " +
			"src.HealthSystemACOStarRating , " +
			"src.MapCpiAnnualCareVisits, " +
			"src.MapCpiLastUpdated, " +
			"src.SuspectConditionalTotal , " +
			"src.SuspectConditionsAssessedTotal , " +
			"src.SuspectConditionsAssessedDiagnosed, " +
			"src.SuspectConditionsAssessedUndiagnosed, " +
			"src.SuspectConditionsNotAssessed, " +
			"src.McaipPatientsFullyAssessed, " +
			"src.McaipSuspectMedicalConditions , " +
			"src.McaipLastUpdated, " +
			"src.McaipTotalPatients, "+
			"src.PcorFlag, " +
			"src.IncentiveProgram, " +
			":TeamType, " +
			"getUtcDate(), " +
			":UpdatedBy, " +
			"getUtcDate(), " +
			":UpdatedBy);";

	private static final String STAR_RATING_GLIDE_PATH_COUNT_QUERY = "with t as( " +
			" SELECT " +
			" GroupId , " +
			" HealthSystemId , " +
			" HealthSystemName , " +
			" ProgramYear , " +
			" MapcpiRating , " +
			" OverallRating , " +
			" AcoRating , " +
			" PartDRating , " +
			" RatingType, " +
			" UpdatedDate , " +
			" ReportingYearMonth, " +
			" ROW_NUMBER() over (partition by %s " +
			" order by " +
			" UpdatedDate desc) as rnk " +
			" FROM " +
			" ProgPerf.[StarRatingIngestion] WITH (NOLOCK) " +
			" WHERE " +
			" ProgramYear = :ProgramYear " +
			" AND IsActive = '1' " +
			" AND RatingType = :RatingType " +
			" %s " +
			" ) " +
			" select count(*) from t where rnk = 1 " ;

	private static final String MERGE_STAR_RATING_GLIDE_PATH_WITH_RATING_INGESTION = "with t as(  " +
			" SELECT " +
			" GroupId , " +
			" HealthSystemId , " +
			" HealthSystemName , " +
			" ProgramYear , " +
			" MapcpiRating , " +
			" OverallRating , " +
			" AcoRating , " +
			" PartDRating , " +
			" RatingType, " +
			" UpdatedDate , " +
			" ReportingYearMonth, " +
			" ROW_NUMBER() over (partition by %s " +
			" order by  " +
			" UpdatedDate desc) as rnk " +
			" FROM " +
			" ProgPerf.[StarRatingIngestion] WITH (NOLOCK) " +
			" WHERE " +
			" ProgramYear = :ProgramYear " +
			" AND IsActive = '1' " +
			" AND RatingType= :RatingType " +
			" %s " +
			" ) " +
			" MERGE ProgPerf.[StarRatingGlidePath] AS tgt " +
			"    USING ( " +
			"    select * from t " +
			"    where " +
			"    rnk = 1 " +
			"    ORDER BY " +
			"    %s asc OFFSET :OFFSET ROWS FETCH NEXT :BATCHSIZE ROWS ONLY " +
			"    ) AS src  " +
			"    ON ( " +
			"    %s " +
			"    AND tgt.ProgramYear = src.ProgramYear " +
			"        AND tgt.DurationValue = :DurationValue " +
			"    ) " +
			"    WHEN MATCHED " +
			"             THEN " +
			"                    UPDATE " +
			"                    SET  tgt.RatingType  = src.RatingType " +
			"                    , tgt.AcoRating  = src.AcoRating " +
			"                    , tgt.OverallRating  = src.OverallRating " +
			"                    , tgt.MapcpiRating  = src.MapcpiRating " +
			"                    , tgt.PartDRating  = src.PartDRating " +
			"                    , tgt.UpdatedDate  = GETUTCDATE() " +
			"                    , tgt.UpdatedBy  = :UpdatedBy  " +
			"    WHEN NOT MATCHED " +
			"             THEN " +
			"             	INSERT( " +
			"             	GroupId, " +
			"             	HealthSystemId, " +
			"             	RatingType, " +
			"             	MapcpiRating, " +
			"             	OverallRating, " +
			"               AcoRating, " +
			"               PartDRating, " +
			"               DurationValue, " +
			"               ProgramYear, " +
			"               CreatedBy, " +
			"               CreatedDate, " +
			"               UpdatedBy, " +
			"               UpdatedDate " +
			"               ) " +
			"               VALUES( " +
			"               src.GroupId, " +
			"               src.HealthSystemId, " +
			"               src.RatingType, " +
			"               src.MapcpiRating, " +
			"               src.OverallRating, " +
			"               src.AcoRating, " +
			"               src.PartDRating, " +
			"               :DurationValue, " +
			"               src.ProgramYear, " +
			"               :UpdatedBy, " +
			"               GETUTCDATE(), " +
			"               :UpdatedBy, " +
			"               GETUTCDATE() " +
			"             	);";
	private static final String STAR_RATING_GLIDE_PATH_RECORDS_COUNT = " select count(*) from ProgPerf.StarRatingGlidePath where ProgramYear = :ProgramYear and DurationValue = :DurationValue ";

	private static final String PERFORMANCE_DETAILS_BOB_SYNC_COUNT_QUERY = "with aggregratePerformance as (  " +
			"select " +
			" pgp.ProviderGroupId as ProviderGroupId,  " +
			" SUM(pgp.TotalPatients) as TotalPatients, " +
			" sum(pgp.MapCpiEligiblePatients) as MapCpiEligiblePatients,  " +
			" SUM(pgp.SuspectConditionsTotal) as totalSuspectConditions, " +
			" pgp.ProgramYear as ProgramYear, " +
			" pgp.DurationValue as DurationValue, " +
			" ( CAST(SUM(MapCpiAnnualCareVisits) AS FLOAT)  / NULLIF(SUM(MapCpiEligiblePatients), 0) )* 100 as acvCompleted, " +
			" ( CAST( (sum(SuspectConditionsAssessedDiagnosed) + sum(SuspectConditionsAssessedUndiagnosed) ) as FLOAT ) / NULLIF(sum(SuspectConditionsTotal), 0) * 100 ) as McaipTotalAssessed, " +
			" ( sum(SuspectConditionsAssessedDiagnosed)+sum(SuspectConditionsAssessedUndiagnosed) ) as conditionsAssessed " +
			" from " +
			" ProgPerf.ProviderGroupPerformanceDetails pgp with (nolock) " +
			" where  " +
			" pgp.ProgramYear = :ProgramYear  " +
			" AND pgp.DurationValue = ( " +
			" select " +
			" TOP 1 DurationValue " +
			" from " +
			" ProgPerf.CommonProgramYearCalender WITH (NOLOCK) " +
			" where " +
			" DurationType = 'MONTH'  " +
			" AND StartDate <= ( " +
			" select " +
			" CAST( getUTCDate() AS Date )) " +
			" AND EndDate >= ( " +
			" select " +
			" CAST( getUTCDate() AS Date )) " +
			" and ProgramYear = :ProgramYear " +
			" and TeamType = 'QFO' )  " +
			" %s " +
			" group by  " +
			" pgp.ProviderGroupId, " +
			" pgp.ProgramYear , " +
			" pgp.DurationValue  " +
			" )  " +
			" select " +
			" count(*) " +
			" from  " +
			" aggregratePerformance apgp  " +
			" left join ProgPerf.StarRatingGlidePath srgp with (nolock) " +
			" on " +
			" srgp.ProgramYear = apgp.ProgramYear " +
			" and srgp.GroupId = apgp.ProviderGroupId  " +
			" and srgp.RatingType = 'GROUP'  " +
			" and srgp.DurationValue =  apgp.DurationValue;";

	private static final String PERFORMANCE_DETAILS_BOB_SYNC_DETAILS_QUERY = "with aggregratePerformance as (  " +
			"select " +
			" pgp.ProviderGroupId as ProviderGroupId,  " +
			" SUM(pgp.TotalPatients) as TotalPatients, " +
			" sum(pgp.MapCpiEligiblePatients) as MapCpiEligiblePatients,  " +
			" SUM(pgp.SuspectConditionsTotal) as totalSuspectConditions, " +
			" pgp.ProgramYear as ProgramYear, " +
			" pgp.DurationValue as DurationValue, " +
			" ( CAST(SUM(MapCpiAnnualCareVisits) AS FLOAT)  / NULLIF(SUM(MapCpiEligiblePatients), 0) )* 100 as acvCompleted, " +
			" ( CAST( (sum(ISNULL(SuspectConditionsAssessedDiagnosed,0)) + sum(ISNULL(SuspectConditionsAssessedUndiagnosed,0)) ) as FLOAT ) / NULLIF(sum(SuspectConditionsTotal), 0) * 100 ) as McaipTotalAssessed, " +
			" ( sum(ISNULL(SuspectConditionsAssessedDiagnosed,0))+sum(ISNULL(SuspectConditionsAssessedUndiagnosed,0)) ) as conditionsAssessed " +
			" from " +
			" ProgPerf.ProviderGroupPerformanceDetails pgp with (nolock)  " +
			" where  " +
			" pgp.ProgramYear = :ProgramYear  " +
			" AND pgp.DurationValue = ( " +
			" select " +
			" TOP 1 DurationValue " +
			" from " +
			" ProgPerf.CommonProgramYearCalender WITH (NOLOCK) " +
			" where " +
			" DurationType = 'MONTH'  " +
			" AND StartDate <= ( " +
			" select " +
			" CAST( getUTCDate() AS Date )) " +
			" AND EndDate >= ( " +
			" select " +
			" CAST( getUTCDate() AS Date )) " +
			" and ProgramYear = :ProgramYear " +
			" and TeamType = 'QFO' )  " +
			" %s " +
			" group by  " +
			" pgp.ProviderGroupId, " +
			" pgp.ProgramYear , " +
			" pgp.DurationValue  " +
			" )  " +
			" select " +
			" apgp.*,  " +
			" srgp.OverallRating as overallStarRating, " +
			" srgp.MapcpiRating as mapCpiStarRating, " +
			" srgp.PartDRating as mapCpiPartDStarRating " +
			" from  " +
			" aggregratePerformance apgp  " +
			" left join ProgPerf.StarRatingGlidePath srgp with (nolock) " +
			" on " +
			" srgp.ProgramYear = apgp.ProgramYear " +
			" and srgp.GroupId = apgp.ProviderGroupId  " +
			" and srgp.RatingType = 'GROUP'  " +
			" and srgp.DurationValue =  apgp.DurationValue " +
			" ORDER BY " +
			" srgp.GroupId asc OFFSET :OFFSET ROWS FETCH NEXT :BatchSize ROWS ONLY";

	private static String MODIFIED_QUALITY_PROV_GRPS_FILTER  = " and ProviderGroupId in (select DISTINCT ASSOC_PROV_GRP_ID from ProgPerf.MemberQuality WHERE GAP_YR =:ProgramYear  "+MODIFIED_CONDITION +" )";

	private static String MODIFIED_SUSPECT_PROV_GRPS_FILTER  = " and ProviderGroupId in (select DISTINCT ASSOC_PROV_GRP_ID from ProgPerf.MemberSuspect WHERE GAP_YR =:ProgramYear  "+MODIFIED_CONDITION +" )";

	private static String RESET_QUALITY_COUNTS= "UPDATE " +
			" ProgPerf.ProviderGroupPerformanceDetails " +
			"set " +
			" TotalPatients = 0, " +
			" MapCpiAnnualCareVisits = 0, " +
			" MapCpiEligiblePatients = 0, " +
			" McaipTotalPatients = 0, " +
			" UpdatedDate = GETUTCDATE(), " +
			" UpdatedBy =:UpdatedBy " +
			"where " +
			" ProgramYear =:ProgramYear and DurationValue =:DurationValue  %s";

	private static String RESET_SUSPECT_COUNTS= "UPDATE " +
			" ProgPerf.ProviderGroupPerformanceDetails " +
			"set " +
			" TotalPatients = 0, " +
			" SuspectConditionsTotal = 0, " +
			" SuspectConditionsAssessedTotal = 0, " +
			" SuspectConditionsAssessedDiagnosed = 0, " +
			" SuspectConditionsAssessedUndiagnosed = 0, " +
			" SuspectConditionsNotAssessed = 0, " +
			" McaipPatientsFullyAssessed = 0, " +
			" McaipSuspectMedicalConditions = 0, " +
			" UpdatedDate = GETUTCDATE(), " +
			" UpdatedBy =:UpdatedBy " +
			"where " +
			" ProgramYear =:ProgramYear and DurationValue =:DurationValue  %s ";

	private static final String MODIFIED_PUBLISHED_QUERY = "; " +
			" WITH ModifiedGroups AS ( " +
			" SELECT " +
			" DISTINCT ProviderGroupId " +
			" FROM " +
			" ( " +
			" SELECT " +
			" DISTINCT ProviderGroupId AS ProviderGroupId " +
			" FROM " +
			" ProgPerf.ProviderGroupPerformanceDetails " +
			" WHERE " +
			" %s " +
			" UNION ALL " +
			" SELECT " +
			" DISTINCT GroupId AS ProviderGroupId " +
			" FROM " +
			" ProgPerf.StarRatingGlidePath " +
			" WHERE " +
			" %s ) AS modified ) , " +
			" aggregratePerformance AS ( " +
			" SELECT " +
			" pgp.ProviderGroupId AS ProviderGroupId , SUM(pgp.TotalPatients) AS TotalPatients , sum(pgp.MapCpiEligiblePatients) AS MapCpiEligiblePatients , SUM(pgp.SuspectConditionsTotal) AS totalSuspectConditions , pgp.ProgramYear AS ProgramYear , pgp.DurationValue AS DurationValue , (CAST(SUM(MapCpiAnnualCareVisits) AS FLOAT) / NULLIF(SUM(MapCpiEligiblePatients), 0)) * 100 AS ACVCompleted , (CAST((sum(ISNULL(SuspectConditionsAssessedDiagnosed,0)) + sum(ISNULL(SuspectConditionsAssessedUndiagnosed,0))) AS FLOAT) / NULLIF(sum(SuspectConditionsTotal), 0) )* 100 AS McaipTotalAssessed , (sum(ISNULL(SuspectConditionsAssessedDiagnosed,0)) + sum(ISNULL(SuspectConditionsAssessedUndiagnosed,0))) AS conditionsAssessed " +
			" FROM " +
			" ProgPerf.ProviderGroupPerformanceDetails pgp WITH (NOLOCK) " +
			" INNER JOIN ModifiedGroups ON " +
			" pgp.ProviderGroupId = ModifiedGroups.ProviderGroupId " +
			" WHERE " +
			" pgp.ProgramYear = :ProgramYear " +
			" AND pgp.DurationValue = ( " +
			" SELECT " +
			" TOP 1 DurationValue " +
			" FROM " +
			" ProgPerf.CommonProgramYearCalender WITH (NOLOCK) " +
			" WHERE " +
			" DurationType = 'MONTH' " +
			" AND StartDate <= ( " +
			" SELECT " +
			" CAST(getUTCDate() AS DATE) ) " +
			" AND EndDate >= ( " +
			" SELECT " +
			" CAST(getUTCDate() AS DATE) ) " +
			" AND ProgramYear = :ProgramYear " +
			" AND TeamType = 'QFO' ) " +
			" GROUP BY " +
			" pgp.ProviderGroupId , pgp.ProgramYear , pgp.DurationValue ) " +
			" SELECT " +
			" apgp.* , " +
			" srgp.OverallRating AS overallStarRating , " +
			" srgp.MapcpiRating AS mapCpiStarRating , " +
			" srgp.PartDRating AS mapCpiPartDStarRating " +
			" FROM " +
			" ProgPerf.StarRatingGlidePath srgp WITH (NOLOCK) " +
			" RIGHT JOIN ModifiedGroups ON " +
			" srgp.GroupId = ModifiedGroups.ProviderGroupId " +
			" RIGHT JOIN aggregratePerformance apgp ON " +
			" srgp.ProgramYear = apgp.ProgramYear " +
			" AND srgp.GroupId = apgp.ProviderGroupId " +
			" AND srgp.RatingType = 'GROUP' " +
			" AND srgp.DurationValue = apgp.DurationValue " +
			" ORDER BY " +
			" srgp.GroupId ASC OFFSET :OFFSET ROWS FETCH NEXT :BatchSize ROWS ONLY ";

	private static final String MODIFIED_PUBLISHED_COUNT_QUERY = "; " +
			" WITH ModifiedGroups AS ( " +
			" SELECT " +
			" DISTINCT ProviderGroupId " +
			" FROM " +
			" ( " +
			" SELECT " +
			" DISTINCT ProviderGroupId AS ProviderGroupId " +
			" FROM " +
			" ProgPerf.ProviderGroupPerformanceDetails " +
			" WHERE " +
			" %s " +
			" UNION ALL " +
			" SELECT " +
			" DISTINCT GroupId AS ProviderGroupId " +
			" FROM " +
			" ProgPerf.StarRatingGlidePath " +
			" WHERE " +
			" %s ) AS modified ) , " +
			" aggregratePerformance AS ( " +
			" SELECT " +
			" pgp.ProviderGroupId AS ProviderGroupId , SUM(pgp.TotalPatients) AS TotalPatients , sum(pgp.MapCpiEligiblePatients) AS MapCpiEligiblePatients , SUM(pgp.SuspectConditionsTotal) AS SuspectConditionsTotal , pgp.ProgramYear AS ProgramYear , pgp.DurationValue AS DurationValue , (CAST(SUM(MapCpiAnnualCareVisits) AS FLOAT) / NULLIF(SUM(MapCpiEligiblePatients), 0)) * 100 AS ACVCompleted , (sum(SuspectConditionsAssessedDiagnosed) + sum(SuspectConditionsAssessedUndiagnosed) / NULLIF(sum(SuspectConditionsTotal), 0) * 100) AS McaipTotalAssessed , (sum(SuspectConditionsAssessedDiagnosed) + sum(SuspectConditionsAssessedUndiagnosed)) AS conditionsAssessed " +
			" FROM " +
			" ProgPerf.ProviderGroupPerformanceDetails pgp WITH (NOLOCK) " +
			" INNER JOIN ModifiedGroups ON " +
			" pgp.ProviderGroupId = ModifiedGroups.ProviderGroupId " +
			" WHERE " +
			" pgp.ProgramYear = :ProgramYear " +
			" AND pgp.DurationValue = ( " +
			" SELECT " +
			" TOP 1 DurationValue " +
			" FROM " +
			" ProgPerf.CommonProgramYearCalender WITH (NOLOCK) " +
			" WHERE " +
			" DurationType = 'MONTH' " +
			" AND StartDate <= ( " +
			" SELECT " +
			" CAST(getUTCDate() AS DATE) ) " +
			" AND EndDate >= ( " +
			" SELECT " +
			" CAST(getUTCDate() AS DATE) ) " +
			" AND ProgramYear = :ProgramYear " +
			" AND TeamType = 'QFO' ) " +
			" GROUP BY " +
			" pgp.ProviderGroupId , pgp.ProgramYear , pgp.DurationValue ) " +
			" SELECT " +
			" count(*)  " +
			" FROM " +
			" ProgPerf.StarRatingGlidePath srgp WITH (NOLOCK) " +
			" RIGHT JOIN ModifiedGroups ON " +
			" srgp.GroupId = ModifiedGroups.ProviderGroupId " +
			" RIGHT JOIN aggregratePerformance apgp ON " +
			" srgp.ProgramYear = apgp.ProgramYear " +
			" AND srgp.GroupId = apgp.ProviderGroupId " +
			" AND srgp.RatingType = 'GROUP' " +
			" AND srgp.DurationValue = apgp.DurationValue  ";

	private static final String DISABLED_PREVIOUS_MONTHS_RECORDS = "WITH DISABLE_PROVIDER_GROUPS_CTE as ( " +
			" select ProviderGroupId from  " +
			" ProgPerf.ProviderGroupPerformanceDetails WITH (NOLOCK)  " +
			" where ProgramYear = :ProgramYear " +
			" AND DurationValue = ( " +
			" SELECT " +
			" FORMAT(dateadd(month, -1, getdate()), 'yyyy_MMM')) " +
			" GROUP BY ProviderGroupId  " +
			" EXCEPT   " +
			" select ProviderGroupId from  " +
			" ProgPerf.ProviderGroupPerformanceDetails WITH (NOLOCK) " +
			" where ProgramYear = :ProgramYear " +
			" AND DurationValue = ( " +
			" SELECT " +
			" CONCAT(FORMAT(GETDATE(), 'yyyy'), '_', FORMAT(GETDATE(), 'MMM'))) " +
			" GROUP BY ProviderGroupId ) " +
			" select  " +
			" pgpd.ProviderGroupId as ProviderGroupId, " +
			" 0 as TotalPatients, " +
			" 0 as MapCpiEligiblePatients,  " +
			" 0 as SuspectConditionsTotal, " +
			" pgpd.ProgramYear as ProgramYear , " +
			" 0  as ACVCompleted, " +
			" 0 as McaipTotalAssessed, " +
			" 0 as conditionsAssessed " +
			" from ProgPerf.ProviderGroupPerformanceDetails pgpd  " +
			" where " +
			" DurationValue = ( " +
			" SELECT " +
			" FORMAT(dateadd(month, -1, getdate()), 'yyyy_MMM')) " +
			" AND EXISTS ( " +
			" SELECT " +
			" ProviderGroupID " +
			" FROM " +
			" DISABLE_PROVIDER_GROUPS_CTE m WITH (NOLOCK) " +
			" WHERE " +
			" m.ProviderGroupID = pgpd.ProviderGroupID ) " +
			" Group BY " +
			" pgpd.ProviderGroupID, pgpd.ProgramYear;";

	public QFOPerformanceRepositoryImpl(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
	}

	@Override
	public Integer calculateAllSuspectConditions(int offset, int batchSize, Integer programYear, CommonProgramYearCalenderDTO commonProgramYearCalenderDTO) {
		Integer totalRowsAffected = 0;
		for (String performance_column_name : SUSPECT_CONDITIONS_PERFORMANCE_COLUMN_NAMES) {
			totalRowsAffected += calculateSuspectConditions(offset, batchSize, performance_column_name, programYear, commonProgramYearCalenderDTO);
		}
		return totalRowsAffected;

	}

	private int calculateSuspectConditions(int offset, int batchSize, String columnNameToUpdate, Integer programYear, CommonProgramYearCalenderDTO commonProgramYearCalenderDTO) {
		log.info("Calculating QFO performance for Suspect Conditions Opportunity : {}", columnNameToUpdate);
		String query = MERGE_SUSPECT_CONDITIONS;
		String subQuery = getMergeSuspectConditionsSubQuery(columnNameToUpdate);
		subQuery = subQuery.replace("%s", Constants.EMPTY);
		subQuery = subQuery.replace(":PROGRAMYEAR", programYear.toString());
		subQuery = subQuery + SUSPECT_CONDITIONS_COMMON_ORDERBY_QUERY + " " + SUSPECT_CONDITIONS_COMMON_OFFSET_QUERY;
		query = query.replace(":SUB_QUERY", subQuery);
		query = query.replace(COLUMN_NAME, columnNameToUpdate);
		query = query.replace(":DURATIONVALUE", "'"+commonProgramYearCalenderDTO.getDurationValue()+"'");
		log.info("Executing suspect conditions performance query: {}", query);
		return mergeSuspectConditions(query, offset, batchSize);
	}

	private String getMergeSuspectConditionsSubQuery(String columnNameToUpdate) {
		String subQuery = SUSPECT_CONDITIONS_ASSESSMENTS_COMMON_QUERY;
		String assessmentStatus = "";
		if (columnNameToUpdate.equals("SuspectConditionsTotal")) {
			subQuery = TOTAL_SUSPECT_CONDITIONS;
		}
		if (columnNameToUpdate.equals("SuspectConditionsAssessedTotal")) {
			subQuery = TOTAL_ASSESSED_SUSPECT_CONDITIONS;
		}
		if (columnNameToUpdate.equals("SuspectConditionsAssessedDiagnosed")) {
			assessmentStatus = ASSESSED_AND_DIAGNOSED_SUSPECT_CONDITIONS;
		}
		if (columnNameToUpdate.equals("SuspectConditionsAssessedUndiagnosed")) {
			assessmentStatus = ASSESSED_AND_UNDIAGNOSED_SUSPECT_CONDITIONS;
		}
		if (columnNameToUpdate.equals("SuspectConditionsNotAssessed")) {
			assessmentStatus = NOT_ASSESSED_SUSPECT_CONDITIONS;
		}
		if (columnNameToUpdate.equals("McaipPatientsFullyAssessed")) {
			assessmentStatus = TOTAL_FULLY_ASSESSED_SUSPECT_CONDITIONS;
			subQuery = TOTAL_FULLY_ASSESSED_SUSPECT_CONDITIONS_QUERY;
			subQuery= subQuery.replace("COUNT_COLUMN","COUNT(DISTINCT GLB_MBR_ID)");
		}
		if (columnNameToUpdate.equals("McaipSuspectMedicalConditions")) {
			assessmentStatus = TOTAL_FULLY_ASSESSED_SUSPECT_CONDITIONS;
			subQuery = TOTAL_FULLY_ASSESSED_SUSPECT_CONDITIONS_QUERY;
			subQuery= subQuery.replace("COUNT_COLUMN","COUNT(*)");
		}
		subQuery = subQuery.replace(COLUMN_NAME, columnNameToUpdate);

		subQuery = subQuery.replace("%assessmentStatus", assessmentStatus);
		return subQuery;
	}

	@Override
	public Long getTotalSuspectConditionsCount(Integer programYear) {
		String query = SUSPECT_CONDITIONS_ALL_RECORDS_COUNT;
		query = query.replace("%s", "");
		query = query.replace(":PROGRAMYEAR", programYear.toString());
		return namedParameterJdbcTemplate.queryForObject(query, new HashMap<>(), Long.class);
	}

	@Override
	public Long getModifiedSuspectConditionsCount(Integer programYear) {
		String query = TOTAL_MODIFIED_SUSPECT_CONDITIONS;
		String lastRunDate = fetchLastRunDate();
		log.info("RunQFOPerformance job last successfully ran on {}", lastRunDate);
		query = query.replace("%s", " AND updatedDate >= '" + lastRunDate + "' ");
		query = query.replace(":PROGRAMYEAR", programYear.toString());
		//query = "SELECT COUNT(*) FROM ( " + query + " ) as MODIFIED_SUSPECT_CONDITIONS_QFO_RECORDS ";
		return namedParameterJdbcTemplate.queryForObject(query, new HashMap<>(), Long.class);
	}

	private Integer mergeSuspectConditions(String query, Integer offset, Integer batchSize) {
		MapSqlParameterSource sqlParameterSource = new MapSqlParameterSource(Constants.BATCHSIZE, batchSize).addValue(Constants.OFFSET,
				offset);
		log.info("Merge suspect conditions data batch size {} offset {}", batchSize, offset);
		return this.namedParameterJdbcTemplate.update(query, sqlParameterSource);
	}

	@Override
	public String fetchLastRunDate() {
		log.info("{} : Fetching last job run date from JobRunConfiguration table for RunQFOPerformance Job",
				ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
		Map<String, Object> bindingMap = new HashMap<>();
		return namedParameterJdbcTemplate.query(FETCH_LAST_JOB_RUN_DATE, bindingMap, rs -> {
			return rs.next() ? rs.getString("LASTSUCCESSFULRUNDATE") : "1900-01-01 00:00:00";

		});
	}

	@Override
	public Integer calculateModifiedSuspectConditions(Integer offset, int batchSize, Integer programYear, CommonProgramYearCalenderDTO commonProgramYearCalenderDTO) {
		List<QFOMemberSuspect> modifiedSuspects = getModifiedMemberSuspects(offset, batchSize, programYear);
		for (String performanceColumnName : SUSPECT_CONDITIONS_PERFORMANCE_COLUMN_NAMES) {
			log.info("Calculating QFO performance for Suspect Conditions Opportunity : {}", performanceColumnName);
			ArrayList<String> sqlBatch = new ArrayList<>();
			for (QFOMemberSuspect modifiedSuspect : modifiedSuspects) {
				String modifiedQueryCondition = " AND ASSOC_PROV_GRP_ID = '" + modifiedSuspect.getProviderGroupId()
						+ "' AND GAP_YR = "
						+ modifiedSuspect.getProgramYear() + "";
				String subQuery = getMergeSuspectConditionsSubQuery(performanceColumnName);
				subQuery = subQuery.replace("%s", modifiedQueryCondition);
				subQuery = subQuery.replace(":PROGRAMYEAR", programYear.toString());
				sqlBatch.add(updateModifiedSuspectConditionsQuery(subQuery, performanceColumnName,commonProgramYearCalenderDTO));

			}
			String[] sqls = new String[sqlBatch.size()];
			sqlBatch.toArray(sqls);
			if(sqls.length>0){
				batchUpdate(sqls);
				sqlBatch.clear();
			}
			sqls = null;
		}
		return modifiedSuspects!=null?modifiedSuspects.size():0;

	}

	private List<QFOMemberSuspect> getModifiedMemberSuspects(Integer offset, int batchSize, Integer programYear) {
		String lastRunDate = fetchLastRunDate();
		String query = MODIFIED_SUSPECT_CONDITIONS;
		query = query.replace(":updatedDate", lastRunDate);
		query = query.replace(":PROGRAMYEAR", programYear.toString());
		query = query + SUSPECT_CONDITIONS_COMMON_ORDERBY_QUERY + " " + SUSPECT_CONDITIONS_COMMON_OFFSET_QUERY;
		SqlParameterSource sqlParameterSource = new MapSqlParameterSource(Constants.BATCHSIZE, batchSize).addValue(Constants.OFFSET,
				offset);
		return namedParameterJdbcTemplate.query(query, sqlParameterSource,
				new BeanPropertyRowMapper<>(QFOMemberSuspect.class));
	}

	public String updateModifiedSuspectConditionsQuery(String subQuery, String columnNameToUpdate, CommonProgramYearCalenderDTO commonProgramYearCalenderDTO) {
		String query = MERGE_SUSPECT_CONDITIONS;
		query = query.replace(":SUB_QUERY", subQuery);
		query = query.replace(COLUMN_NAME, columnNameToUpdate);
		query = query.replace(":DURATIONVALUE", "'"+commonProgramYearCalenderDTO.getDurationValue()+"'");
		return query;

	}

	public int[] batchUpdate(String[] sqlBatch) {
		return namedParameterJdbcTemplate.getJdbcTemplate().batchUpdate(sqlBatch);
	}

	@Override
	public Integer loadProviderGroupPerformanceQualityDetails(int batchSize, Integer batchOffset, String executeForAllProviderGroups,CommonProgramYearCalenderDTO commonProgramYearCalenderDTO) {
		Map<String, Object> paramMap = new HashMap<>();
		String query;
		if (Constants.ALL.equalsIgnoreCase(executeForAllProviderGroups) || Constants.MONTHLY.equalsIgnoreCase(executeForAllProviderGroups)) {
			query=MERGE_PROVIDER_GROUP_PERFORMANCE_DETIALS.replace(Constants.LAST_MODIFIED,Constants.EMPTY);

		} else {
			query=MERGE_PROVIDER_GROUP_PERFORMANCE_DETIALS.replace(Constants.LAST_MODIFIED,MODIFIED_CONDITION);
		}
		paramMap.put("UpdatedBy", QFO_PERF_JOB);
		paramMap.put(Constants.BATCHSIZE,batchSize);
		paramMap.put(Constants.OFFSET,batchOffset);
		paramMap.put( Constants.PROGRAM_YEAR, commonProgramYearCalenderDTO.getProgramYear());
		paramMap.put("DurationValue", commonProgramYearCalenderDTO.getDurationValue());
		log.info("loadMemberQualityProviderGroupPerformanceQualityDetails : query {} batchOffset {}",query, batchOffset);
		return namedParameterJdbcTemplate.update(query, paramMap);
	}

	@Override
	public Long getProviderGroupMemberQualityRecordCount(String executeForAllProviderGroups, Integer programYear) {
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put( Constants.PROGRAM_YEAR, programYear);
		String query;
		if (Constants.ALL.equalsIgnoreCase(executeForAllProviderGroups) || Constants.MONTHLY.equalsIgnoreCase(executeForAllProviderGroups)) {
			query = QUERY_PROVIDER_GROUPS_MEMBER_QUALITY_COUNT.replace(Constants.LAST_MODIFIED,Constants.EMPTY);
		} else {
			query = QUERY_PROVIDER_GROUPS_MEMBER_QUALITY_COUNT.replace(Constants.LAST_MODIFIED,MODIFIED_CONDITION);
		}
		log.info("LoadProviderGroupPerformanceQualityDetails count query :{} ", query);
		return namedParameterJdbcTemplate.queryForObject(query, paramMap, Long.class);
	}

	@Override
	public Long getStarRatingIngestionGroupsRecordCount(String canExecuteForAllProviderGroups, Integer programYear) {
		String query;
		if (Constants.ALL.equalsIgnoreCase(canExecuteForAllProviderGroups)) {
			query = String.format(STAR_RATING_INJESTION_COUNT_QUERY, programYear, Constants.EMPTY);
		} else {
			query = String.format(STAR_RATING_INJESTION_COUNT_QUERY, programYear, MODIFIED_CONDITION);
		}
		log.info("MergeProviderGroupPerformanceDetailsWithASR count query :{} ", query);
		return namedParameterJdbcTemplate.queryForObject(query, new HashMap<>(), Long.class);
	}

	@Override
	public Integer mergeProviderGroupPerformanceDetailsWithASR(int batchSize, Integer batchOffset,
															   String canExecuteForAllProviderGroups, Integer programYear,
															   CommonProgramYearCalenderDTO commonProgramYearCalenderDTO) {
		String query;
		if (Constants.ALL.equalsIgnoreCase(canExecuteForAllProviderGroups)) {
			query = String.format(PROVIDER_GROUP_PERFORMANCE_ASR_MERGE_QUERY, Constants.EMPTY);
		} else {
			query = String.format(PROVIDER_GROUP_PERFORMANCE_ASR_MERGE_QUERY, MODIFIED_CONDITION);
		}
		SqlParameterSource sqlParameterSource = new MapSqlParameterSource(Constants.BATCHSIZE, batchSize)
				.addValue(Constants.OFFSET, batchOffset)
				.addValue("UpdatedBy", QFO_PERF_JOB)
				.addValue( Constants.PROGRAM_YEAR,programYear)
				.addValue(Constants.TEAM_TYPE, Constants.QFO)
				.addValue("DurationValue", commonProgramYearCalenderDTO.getDurationValue());;

		log.info("MergeProviderGroupPerformanceDetailsWithASR batchsize {} offset {}", batchSize, batchOffset);

		return this.namedParameterJdbcTemplate.update(query, sqlParameterSource);
	}

	@Override
	public Long getHealthSystemRecordCount(String executeForAllProviderGroups, CommonProgramYearCalenderDTO commonProgramYearCalenderDTO) {
		Map<String, Object> paramMap = new HashMap<>();
		String query;
		if (Constants.ALL.equalsIgnoreCase(executeForAllProviderGroups)) {
			query = String.format(HEALTH_SYSTEM_UPDATE_COUNT_QUERY, Constants.EMPTY);
		} else {
			query = String.format(HEALTH_SYSTEM_UPDATE_COUNT_QUERY, MODIFIED_CONDITION);
		}
		paramMap.put(Constants.TEAM_TYPE,Constants.QFO);
		paramMap.put( Constants.PROGRAM_YEAR, commonProgramYearCalenderDTO.getProgramYear());
		paramMap.put("DurationValue", commonProgramYearCalenderDTO.getDurationValue());
		log.info("GetHealthSystemCount : query {} ",query);
		return namedParameterJdbcTemplate.queryForObject(query, paramMap, Long.class);
	}

	@Override
	public Integer mergeHealthSystemPerfDetails(int batchSize, Integer batchOffset, String executeForAllProviderGroups, CommonProgramYearCalenderDTO commonProgramYearCalenderDTO) {
		Map<String, Object> paramMap = new HashMap<>();
		String query;
		if (Constants.ALL.equalsIgnoreCase(executeForAllProviderGroups)) {
			query = String.format(HEALTH_SYSTEM_DATA_LOD_QUERY, Constants.EMPTY);
		} else {
			query = String.format(HEALTH_SYSTEM_DATA_LOD_QUERY, MODIFIED_CONDITION);
		}
		paramMap.put("UpdatedBy", QFO_PERF_JOB);
		paramMap.put(Constants.BATCHSIZE,batchSize);
		paramMap.put(Constants.OFFSET,batchOffset);
		paramMap.put(Constants.TEAM_TYPE,Constants.QFO);
		paramMap.put(Constants.PROGRAM_YEAR, commonProgramYearCalenderDTO.getProgramYear());
		paramMap.put("DurationValue", commonProgramYearCalenderDTO.getDurationValue());
		log.info("MergeHealthSystemDetails : query {} batchOffset {}",query, batchOffset);
		return namedParameterJdbcTemplate.update(query, paramMap);
	}

	@Override
	public Long getStarRatingGlidePathGroupsRecordCount(String groupsToExecute, Integer programYear, boolean isModified, String ratingType) {
		String modifiedQuery = null;
		String query;
		String columnType;
		Map<String, Object> paramMap = new HashMap<>();
		if(isModified){
			modifiedQuery =  MODIFIED_CONDITION;
		} else {
			modifiedQuery =  "";
		}
		if(ratingType.equalsIgnoreCase("GROUP")){
			columnType = "GroupId";
		}else{
			columnType = "HealthSystemId";
		}
		query = String.format(STAR_RATING_GLIDE_PATH_COUNT_QUERY, columnType, modifiedQuery);
		paramMap.put(Constants.PROGRAM_YEAR, programYear);
		paramMap.put("RatingType", ratingType);
		paramMap.put("ColumnType", columnType);
		return namedParameterJdbcTemplate.queryForObject(query, paramMap, Long.class);
	}

	@Override
	public Integer mergeStarRatingGlidePathWithRatingIngestion(int batchSize, Integer offset, String groupsToExecute, Integer programYear, CommonProgramYearCalenderDTO commonProgramYearCalenderDTO, boolean isModified, String ratingType) {
		Map<String, Object> paramMap = new HashMap<>();
		String columnType;
		String modifiedQuery;
		String whereClauseCondition;
		String orderByCol;
		String query ;
		if (isModified) {
			modifiedQuery = MODIFIED_CONDITION;
		} else {
			modifiedQuery = Constants.EMPTY;
		}
		if(ratingType.equalsIgnoreCase("GROUP")){
			columnType = "GroupId";
			whereClauseCondition = " tgt.GroupId = src.GroupId " ;
			orderByCol = "t.GroupId";
		}else{
			columnType = "HealthSystemId";
			whereClauseCondition = " tgt.HealthSystemId = src.HealthSystemId " ;
			orderByCol = "t.HealthSystemId";
		}
		query = String.format(MERGE_STAR_RATING_GLIDE_PATH_WITH_RATING_INGESTION, columnType, modifiedQuery, orderByCol, whereClauseCondition);
		paramMap.put("UpdatedBy", QFO_PERF_JOB);
		paramMap.put(Constants.BATCHSIZE,batchSize);
		paramMap.put(Constants.OFFSET,offset);
		paramMap.put(Constants.PROGRAM_YEAR, commonProgramYearCalenderDTO.getProgramYear());
		paramMap.put(Constants.DURATION_VALUE, commonProgramYearCalenderDTO.getDurationValue());
		paramMap.put("RatingType", ratingType);
		log.info("MergeStarRatingGlidePath : query {} batchOffset {} {} {} {}",query, offset, batchSize, commonProgramYearCalenderDTO.getProgramYear(), commonProgramYearCalenderDTO.getDurationValue());
		return namedParameterJdbcTemplate.update(query, paramMap);
	}

	@Override
	public Long getStarRatingGlidePathCount(Integer programYear, String durationValue) {
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put(Constants.DURATION_VALUE, durationValue);
		paramMap.put(Constants.PROGRAM_YEAR, programYear);
		return namedParameterJdbcTemplate.queryForObject(STAR_RATING_GLIDE_PATH_RECORDS_COUNT, paramMap, Long.class);
	}

	@Override
	public Long getQfoPerformanceDataBobSyncCount(Integer programYear, CommonProgramYearCalenderDTO commonProgramYearCalenderDTO, String groupsToExecute) {
		String query;
		Map<String, Object> paramMap = new HashMap<>();
		String modifiedQuery;
		if(groupsToExecute.equalsIgnoreCase("Modified")){
			modifiedQuery = " UpdatedDate >= (select LastSuccessfulRunDate  " +
					" from ProgPerf.jobrunconfiguration where jobname = 'RunQFOPerformance')";
			query = String.format(MODIFIED_PUBLISHED_COUNT_QUERY, modifiedQuery, modifiedQuery);
		}else {
			modifiedQuery = " ";
			query = String.format(PERFORMANCE_DETAILS_BOB_SYNC_COUNT_QUERY, modifiedQuery);
		}
		paramMap.put(Constants.PROGRAM_YEAR, programYear);
		return namedParameterJdbcTemplate.queryForObject(query, paramMap, Long.class);
	}

	@Override
	public List<QfoPerformanceData> getQfoPerformanceDataBobSyncDetails (int batchSize, Integer batchOffset, Integer programYear, String durationValue, String groupExecute){
		String query;
		String modifiedQuery;
		if(groupExecute.equalsIgnoreCase("Modified")){
			modifiedQuery = " UpdatedDate >= (select LastSuccessfulRunDate " +
					" from ProgPerf.jobrunconfiguration where jobname = 'RunQFOPerformance') ";
			query = String.format(MODIFIED_PUBLISHED_QUERY, modifiedQuery, modifiedQuery);
		}else {
			modifiedQuery = " ";
			query = String.format(PERFORMANCE_DETAILS_BOB_SYNC_DETAILS_QUERY, modifiedQuery);
		}
		SqlParameterSource sqlParameterSource = new MapSqlParameterSource(Constants.PROGRAM_YEAR,programYear)
				.addValue("BatchSize", batchSize)
				.addValue("OFFSET", batchOffset);
		return namedParameterJdbcTemplate.query(query, sqlParameterSource, new BeanPropertyRowMapper<>(QfoPerformanceData.class));
	}

	@Override
	public void resetQualityCountsForProviderGroups( Integer programYear , String durationValue)
	{
		String query  = String.format(RESET_QUALITY_COUNTS, MODIFIED_QUALITY_PROV_GRPS_FILTER);
		SqlParameterSource sqlParameterSource = new MapSqlParameterSource(Constants.PROGRAM_YEAR,programYear)
				.addValue(Constants.DURATION_VALUE, durationValue)
				.addValue(Constants.UPDATED_BY,QFO_PERF_JOB);
		namedParameterJdbcTemplate.update(query, sqlParameterSource);
	}

	@Override
	public void resetSuspectCountsForProviderGroups( Integer programYear , String durationValue)
	{
		String query  = String.format(RESET_SUSPECT_COUNTS, MODIFIED_SUSPECT_PROV_GRPS_FILTER);
		SqlParameterSource sqlParameterSource = new MapSqlParameterSource(Constants.PROGRAM_YEAR,programYear)
				.addValue(Constants.DURATION_VALUE, durationValue)
				.addValue(Constants.UPDATED_BY,QFO_PERF_JOB);
		namedParameterJdbcTemplate.update(query, sqlParameterSource);
	}


	@Override
	public List<QfoPerformanceData> getPreviousMonthDisabledProvidersData(Integer programYear) {
		SqlParameterSource sqlParameterSource = new MapSqlParameterSource(Constants.PROGRAM_YEAR,programYear);
		return namedParameterJdbcTemplate.query(DISABLED_PREVIOUS_MONTHS_RECORDS, sqlParameterSource, new BeanPropertyRowMapper<>(QfoPerformanceData.class));
	}

}