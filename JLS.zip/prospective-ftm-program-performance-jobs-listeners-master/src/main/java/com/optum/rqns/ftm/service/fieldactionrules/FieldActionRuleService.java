package com.optum.rqns.ftm.service.fieldactionrules;

import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.exception.FieldActionRulesException;
import com.optum.rqns.ftm.kafka.avro.models.v1.fieldactionrule.Action;
import com.optum.rqns.ftm.kafka.avro.models.v1.fieldactionrule.FieldActionRuleMetadata;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.producer.JobEventProducer;
import com.optum.rqns.ftm.kafka.producer.KeyBasedFieldActionRuleProducer;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.model.fieldactionrules.RuleAction;
import com.optum.rqns.ftm.repository.fieldactionrules.ReturnTargetTrackingRepoImpl;
import com.optum.rqns.ftm.service.IJob;
import com.optum.rqns.ftm.util.FieldActionRulesUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/*
    Common abstract class for work action rules producer
 */

@Slf4j
public abstract class FieldActionRuleService implements IJob {

    @Autowired
    private ReturnTargetTrackingRepoImpl returnTargetTrackingRepoImpl;

    @Autowired
    private JobEventProducer jobEventProducer;

    @Autowired
    private KeyBasedFieldActionRuleProducer keyBasedFieldActionRuleProducer;

    @Autowired
    private KIERuleOrchestrator kieRuleOrchestrator;

    @Autowired
    private FieldActionRulesUtil fieldActionRulesUtil;

    @Value("${producer_thread_pool_size}")
    private int producerThreadPoolSize;

    @Value("${jobs.workqueueRuleAction.batchSize}")
    public int batchSize;

    private boolean isBatchingRequired=true;

    public void setBatchingRequired(boolean isBatchingRequired) {
        this.isBatchingRequired = isBatchingRequired;
    }

    public void setBatchSize(int batchSize){
        this.batchSize=batchSize;
    }

    public JobStatus executeJob(JobEvent jobEvent) {
        log.info("Received FieldActionRuleService.executeJob :: {}", jobEvent.getJobName());
        JobStatus jobStatus = new JobStatus();
        List<RuleAction> totalRuleActionList=new ArrayList<>();
        List<Integer> batchOffSetList=new ArrayList<>();
        List<RuleAction> masterRuleActionList=new ArrayList<>();

        try{
            if(isBatchingRequired){
                batchOffSetList=fetchRuleBatchingOffsetList(batchSize);
                for(Integer batchOffSet : batchOffSetList){
                    totalRuleActionList=fetchRuleData(batchOffSet,batchSize,isBatchingRequired);
                    if(!totalRuleActionList.isEmpty()){
                        totalRuleActionList=kieRuleOrchestrator.getRulesExecutedData(totalRuleActionList, jobEvent.getJobName().toString());
                        masterRuleActionList.addAll(totalRuleActionList);
                    }
                }
                if(!masterRuleActionList.isEmpty()){
                    pushMessagesToTopic(masterRuleActionList,jobEvent.getJobName().toString());
                    postProcessing(masterRuleActionList);
                }
            }else{
                totalRuleActionList=fetchRuleData(0,0,isBatchingRequired);
                masterRuleActionList=kieRuleOrchestrator.getRulesExecutedData(totalRuleActionList, jobEvent.getJobName().toString());
                pushMessagesToTopic(masterRuleActionList,jobEvent.getJobName().toString());
            }
            jobStatus.setStatus(Status.SUCCESS);
            jobStatus.setMessage("Completed Job successfully Job Name is {}"+jobEvent.getJobName().toString());
            jobStatus.setUpdatedRows(Long.valueOf(masterRuleActionList.size()));
            log.info("Completed Job successfully Job Name is and :: Kafka Produced MasterRuleAction Total Count (Result from Drools Engine) is  {} {}", (jobEvent.getJobName().toString()),masterRuleActionList.size());
        }catch (Exception e){
            log.error("Exception while executing job : {}{}", (jobEvent.getJobName().toString()),e);
            jobStatus.setStatus(Status.FAILURE);
            jobStatus.setMessage("Return Target Tracking at Book of Business level execution failed : " + e.getMessage());
            jobStatus.setUpdatedRows(0L);
        }finally {
            totalRuleActionList.clear();
            batchOffSetList.clear();
            masterRuleActionList.clear();
        }
        return  jobStatus;
    }

    public Long pushMessagesToTopic(List<RuleAction> returnTargetTrackingActionsList, String ruleType){

        ExecutorService executorService = Executors.newFixedThreadPool(producerThreadPoolSize);
        List<Callable<Boolean>> taskList = new ArrayList<>();
        long totalElements=0;

        try{

            returnTargetTrackingActionsList.stream().forEach(returnTargetTrackingAction -> {
                taskList.add(()->{
                    return keyBasedFieldActionRuleProducer.postToKafka((buildFieldActionRuleMetadata
                            (returnTargetTrackingAction)),returnTargetTrackingAction.getRuleType());
                });
            });

            totalElements=FieldActionRulesUtil.executeKafkaPushing(executorService,taskList);
        }catch (Exception e){
            log.error("Exception while puhing message to kafka for FieldActionRule{}{}",ruleType,e);
            throw new FieldActionRulesException(Constants.PUBLISHING_DATA_EXCEPTION, e.getMessage(),ruleType);
        }
        return totalElements;
    }


    public FieldActionRuleMetadata buildFieldActionRuleMetadata(RuleAction ruleAction) {

        FieldActionRuleMetadata fieldActionRuleMetadata=new FieldActionRuleMetadata();
        Action action=new Action();
        List<CharSequence> userList=new ArrayList<>();
        try{

            fieldActionRuleMetadata.setRuleResult(getRuleResult(ruleAction));
            fieldActionRuleMetadata.setRuleContext(getRuleContext(ruleAction));
            ruleAction.getUserUuid().forEach(s -> {
                userList.add(s);
            });
            fieldActionRuleMetadata.setUsers(userList);
            fieldActionRuleMetadata.setRuleType(ruleAction.getRuleType());
            action.setMethod(ruleAction.getActionMethod());
            action.setType(ruleAction.getActionType());
            action.setIsShared(ruleAction.getIsShared());
            action.setTitle(ruleAction.getActionTitle());
            action.setDescription(ruleAction.getActionDescription());
            action.setDurationStats(ruleAction.getDurationStats());
            action.setVerifyRuleResult(ruleAction.getVerifyRuleResult());
            action.setPriority(ruleAction.getPriority());
            fieldActionRuleMetadata.setAction(action);

        }catch (Exception e){
            log.error("Exception while puhing message to kafka for FieldActionRule{}{}",ruleAction.getRuleType(),e.getMessage());
            throw new FieldActionRulesException(Constants.PUBLISHING_DATA_EXCEPTION, e.getMessage(),ruleAction.getRuleType());
        }
         return fieldActionRuleMetadata;
    }

    public abstract List<RuleAction> fetchRuleData(Integer beginIndex,int batchSize,boolean isBatchingRequired );

    public abstract  String getRuleResult(RuleAction ruleAction);

    public  List<RuleAction> filterRuleActions(List<RuleAction> ruleActions){
        return ruleActions;
    }

    public List<Integer> fetchRuleBatchingOffsetList(int batchsize){
        return new ArrayList<Integer>(){{
            add(0);
        }};
    }
    public  int postProcessing(List<RuleAction> masterRuleActionList){
        return 0;
    }

    public String getRuleContext(RuleAction ruleAction){
        return "";
    }

}
