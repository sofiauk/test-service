package com.optum.rqns.ftm.service.landingpage;

import com.optum.rqns.ftm.service.IJob;

public interface LeaderPerformanceHistorical extends IJob {
}
