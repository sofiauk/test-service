package com.optum.rqns.ftm.service.practiceassist;

import lombok.SneakyThrows;
import org.springframework.stereotype.Service;

import com.optum.rqns.ftm.service.IJob;

import lombok.extern.slf4j.Slf4j;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Slf4j
@Service
public abstract class PaLandingPageService implements IJob {

    public static String getUTCDateTime(final LocalDateTime time) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        final ZonedDateTime zonedtime = time.atZone(ZoneId.systemDefault());
        final ZonedDateTime converted = zonedtime.withZoneSameInstant(ZoneOffset.UTC);
        
        return converted.toLocalDateTime().format(formatter);
    }

    @SneakyThrows
    public  long invokeAll(ExecutorService executorService, List<Callable<Long>> taskList) {
        long count = 0;
        try {
            List<Future<Long>> results = executorService.invokeAll(taskList);
             for (Future<Long> future : results) {
                if (future != null && future.get() != null) {
                    count += future.get();
                }
            }
          
        } catch (InterruptedException | ExecutionException e) {
            log.error("Error while  processing aggregation task  ", e);
            throw e;
        } finally {
            taskList.clear();
            executorService.shutdown();
            awaitTerminationAfterShutdown(executorService);
            
        }
        return count;
    }

    public void awaitTerminationAfterShutdown(ExecutorService threadPool) {
        threadPool.shutdown();
        try {
            if (!threadPool.awaitTermination(90, TimeUnit.MINUTES)) {
                threadPool.shutdownNow();
            }
        } catch (InterruptedException ex) {
            threadPool.shutdownNow();
            Thread.currentThread().interrupt();
        }
    }
    

	 public static <T> List<List<T>> partition(List<T> collection, int partitionSize)
	    {
	        return IntStream.rangeClosed(0, (collection.size() - 1) / partitionSize)
	                .mapToObj(i -> collection.subList(i * partitionSize,
	                    Math.min((i + 1) * partitionSize, collection.size())))
	                .collect(Collectors.toList());
	    }
	 
	 
	public static String convertUTCToCST(String utcdatetime) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		try {

			Instant instant = Instant.parse((utcdatetime.trim().replace(" ", "T") + "Z"));

			ZoneId z = ZoneId.of("America/Chicago");
			ZonedDateTime zdt = instant.atZone(z);
			return (zdt.toLocalDateTime().format(formatter));
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}

	}

}
