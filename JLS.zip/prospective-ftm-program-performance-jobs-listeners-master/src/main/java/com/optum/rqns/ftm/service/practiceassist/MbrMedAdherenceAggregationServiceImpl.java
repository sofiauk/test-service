package com.optum.rqns.ftm.service.practiceassist;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.IntStream;

import org.apache.commons.lang3.time.StopWatch;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.uuid.Generators;
import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.mutable.MutableLong;
import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.enums.GroupsToExecute;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.model.practiceassist.PaAggregationData;
import com.optum.rqns.ftm.repository.common.CommonRepository;
import com.optum.rqns.ftm.repository.practiceassist.PaLandingPageRepository;
import com.optum.rqns.ftm.util.ProgramPerformanceJobUtil;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MbrMedAdherenceAggregationServiceImpl extends PaLandingPageService {

	private PaLandingPageRepository paLandingPageRepository;
	private CommonRepository commonRepository;

	@Value("${medadherence_fetch_batchsize:1800}")
	private  int FETCH_BATCH_SIZE;

	@Value("${medadherence_upsert_batchsize:5000}")
	private int UPSERT_BATCH_SIZE;

	@Value("${new_providergroup_rule_producer_thread_pool_size}")
	private int producerThreadPoolSize;

	@Value("${medadherence_thread_pool_size:20}")
	private int threadPoolSize;

	public MbrMedAdherenceAggregationServiceImpl(@Qualifier("PaLandingPageRepositoryMysql") PaLandingPageRepository paLandingPageRepository,
												 CommonRepository commonRepository) {
		this.paLandingPageRepository = paLandingPageRepository;
		this.commonRepository = commonRepository;
	}

	public JobStatus executeJob(JobEvent jobEvent) {
		StopWatch stopWatch = StopWatch.createStarted();
		MDC.put(Constants.TRACE_ID, Generators.timeBasedGenerator().generate().toString());
		MDC.put(Constants.TRANSACTION_ID, ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
		MDC.put(Constants.MESSAGE_ID, ProgramPerformanceJobUtil.TransactionIdLogger.getMessageIdIdentifier());

		log.info("{} jobEvent.MbrMedAdherenceAggregation() :: {}",
				ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), jobEvent.getJobName());
		JobStatus jobStatus = new JobStatus();



		try {

			
			MutableLong totalRowsUpdated = new MutableLong();
		
			if (jobEvent.getGroupsToExecute().toString().equalsIgnoreCase(GroupsToExecute.ALL.getValue())) {
			
						
				/*Long totalRows = this.paLandingPageRepository.getRecordCountModifiedByPrvGrps(
						jobEvent.getJobName().toString(), GroupsToExecute.ALL.getValue(),jobEvent.getProgramYear(), null,null);*/
				
				List<String> affectedPrvGrpList= this.paLandingPageRepository.getAffectedProvGrpList(jobEvent.getProgramYear(),
						null,null,jobEvent.getJobName().toString());

			       long totalProGrpCount= affectedPrvGrpList!=null?affectedPrvGrpList.size():0;
			       
			       log.info("{} Full Refresh MbrMedAdherenceAggregation total provider groups  Count {}",
							ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), totalProGrpCount);
					
					List<List<String>> partitions = partition(affectedPrvGrpList, FETCH_BATCH_SIZE);
					log.info("{} Full Refresh MbrMedAdherenceAggregation total provider groups  batches are {}",
							ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), partitions.size());
					
								
					markedRecordsAsDirty(JobName.RUN_MED_ADHERENCE_AGGREGATION.getValue(),
							GroupsToExecute.ALL.getValue(), jobEvent.getProgramYear(),  null,null,partitions);
			
			
				ExecutorService executorService = Executors.newFixedThreadPool(threadPoolSize);
				List<Callable<Long>> taskList = new ArrayList<>();
				AtomicInteger batch= new AtomicInteger();
				
				for (List<String> subList : partitions) {
					if (null != subList && !subList.isEmpty()) {

						taskList.add(new Callable<Long>() {
							int currentBatch = batch.addAndGet(1);

							@Override
							public Long call() throws Exception {

								StopWatch stopWatch2 = StopWatch.createStarted();

								log.info("Thread:{} , Fetching data for provider groups batch:{}  with batch size {}",
										Thread.currentThread().getName(), currentBatch, subList.size());
								List<PaAggregationData> paMedAdherenceAggregationList = fetchAggregationData(jobEvent, null,
										null, subList);

								log.info(
										"Thread:{} , Fetching data for provider groups batch:{} is completed, fetched {} records  in {} seconds",
										Thread.currentThread().getName(), currentBatch,paMedAdherenceAggregationList.size(),
										stopWatch2.getTime(TimeUnit.SECONDS));
								return batchUpdate(paMedAdherenceAggregationList);

							}

						});

					}
				}
				totalRowsUpdated.add(invokeAll(executorService, taskList));

			/*this.paLandingPageRepository.inActivateDirtyRecords(JobName.RUN_MED_ADHERENCE_AGGREGATION.getValue(),
						GroupsToExecute.ALL.getValue(), jobEvent.getProgramYear(), null,null);*/
				
				inActivateDirtyRecords(JobName.RUN_MED_ADHERENCE_AGGREGATION.getValue(), GroupsToExecute.ALL.getValue(),
						jobEvent.getProgramYear(), null, null, partitions);

			} else {


				 String joblastrunsuccessfuldate=convertUTCToCST(commonRepository.fetchLastSucessfullJobStartRanDate(JobName.RUN_MED_ADHERENCE_AGGREGATION.getValue()));
					
				 
					log.info("{} last sucessfull run datetime:{} ",JobName.RUN_MED_ADHERENCE_AGGREGATION.name(), joblastrunsuccessfuldate);
					
					 String jobStartime = convertUTCToCST(getUTCDateTime(LocalDateTime.now()));
					
						/*totalRowsToBeUpdated = this.paLandingPageRepository.getRecordCountModifiedByPrvGrps(jobEvent.getJobName().toString(), GroupsToExecute.MODIFIED.getValue(),
						jobEvent.getProgramYear(),joblastrunsuccessfuldate,jobStartime);*/
					
					List<String> affectedPrvGrpList= this.paLandingPageRepository.getAffectedProvGrpList(jobEvent.getProgramYear(),
								joblastrunsuccessfuldate,jobStartime,jobEvent.getJobName().toString());
					
					long totalProGrpCount= affectedPrvGrpList!=null?affectedPrvGrpList.size():0;
					
					log.info("{}  MbrMedAdherenceAggregation total provider groups  Count {}",
							ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), totalProGrpCount);

					List<List<String>> partitions = partition(affectedPrvGrpList, FETCH_BATCH_SIZE);
						log.info("{} Modified  MbrMedAdherenceAggregation total provider groups batches  are {}",
								ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), partitions.size());
						
									
						markedRecordsAsDirty(JobName.RUN_MED_ADHERENCE_AGGREGATION.getValue(),
								GroupsToExecute.MODIFIED.getValue(), jobEvent.getProgramYear(),  joblastrunsuccessfuldate,jobStartime,partitions);

				/*this.paLandingPageRepository.markedRecordsAsDirty(JobName.RUN_MED_ADHERENCE_AGGREGATION.getValue(),
						GroupsToExecute.MODIFIED.getValue(), jobEvent.getProgramYear(),  joblastrunsuccessfuldate,jobStartime);*/
				ExecutorService executorService = Executors.newFixedThreadPool(threadPoolSize);
				List<Callable<Long>> taskList = new ArrayList<>();
				 AtomicInteger batch= new AtomicInteger();
				 for (List<String> subList : partitions) {
						if (null != subList && !subList.isEmpty()) {

							taskList.add(new Callable<Long>() {
								int currentBatch = batch.addAndGet(1);

								@Override
								public Long call() throws Exception {

									StopWatch stopWatch2 = StopWatch.createStarted();

									log.info("Thread:{} , Fetching data for provider groups batch:{}  with batch size {}",
											Thread.currentThread().getName(), currentBatch, subList.size());
									List<PaAggregationData> paMedAdherenceAggregationList = fetchAggregationData(jobEvent, joblastrunsuccessfuldate, jobStartime
											, subList);

									log.info(
											"Thread:{} , Fetching data for provider groups batch:{} is completed, fetched {} records  in {} seconds",
											Thread.currentThread().getName(), currentBatch,paMedAdherenceAggregationList.size(),
											stopWatch2.getTime(TimeUnit.SECONDS));
									return batchUpdate(paMedAdherenceAggregationList);

								}

							});

						}
					}
				
				totalRowsUpdated.add(invokeAll(executorService, taskList));
						
				/*this.paLandingPageRepository.inActivateDirtyRecords(JobName.RUN_MED_ADHERENCE_AGGREGATION.getValue(),
						GroupsToExecute.MODIFIED.getValue(), jobEvent.getProgramYear(), joblastrunsuccessfuldate,jobStartime);*/
				
				inActivateDirtyRecords(JobName.RUN_MED_ADHERENCE_AGGREGATION.getValue(), GroupsToExecute.MODIFIED.getValue(),
						jobEvent.getProgramYear(), joblastrunsuccessfuldate, jobStartime, partitions);
			}


			// Generate final message and update in JobRunconfiguration
			String message = "Completed MbrMedAdherenceAggregation job successfully. "
					+ "Updated records in MbrMedAdherenceAggregation: " + totalRowsUpdated;

			jobStatus.setStatus(Status.SUCCESS);
			jobStatus.setMessage(message);
			jobStatus.setUpdatedRows(totalRowsUpdated.toLong());
			log.info("MbrMedAdherenceAggregation execution completed for {}  records in {}seconds", totalRowsUpdated,
					stopWatch.getTime(TimeUnit.SECONDS));

		} catch (Exception e) {

			log.error("{} Exception while executing MbrMedAdherenceAggregation job : {}",
					ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), e);
			jobStatus.setStatus(Status.FAILURE);
			jobStatus.setMessage("MbrMedAdherenceAggregation job execution failed : " + e.getMessage());
			jobStatus.setUpdatedRows(0L);
		} finally {
			MDC.clear();
		}
		return jobStatus;
	}

	public Long batchUpdate(List<PaAggregationData> paMedAdherenceAggregationList) {

		MutableLong updateCount= new MutableLong();

		if (null != paMedAdherenceAggregationList) {

			IntStream.range(0, (paMedAdherenceAggregationList.size() + UPSERT_BATCH_SIZE - 1) / UPSERT_BATCH_SIZE)
					.mapToObj(i -> paMedAdherenceAggregationList.subList(i * UPSERT_BATCH_SIZE,
							Math.min(paMedAdherenceAggregationList.size(), (i + 1) * UPSERT_BATCH_SIZE)))
					.forEach(batch -> {
						Integer count = this.paLandingPageRepository.upserMedAdherenceAggregation(batch);
						updateCount.add(count);


					});
		}

		return updateCount.longValue();
	}

	private List<PaAggregationData> fetchAggregationData(JobEvent jobEvent, String joblastrunsuccessfuldate,
			String jobStartTime, List<String> affectedPrvGrpList) {
		List<PaAggregationData> paMedAdherenceAggregationList = this.paLandingPageRepository.getPaMedAdherenceAggregateDataByBatch(
				jobEvent.getProgramYear(), joblastrunsuccessfuldate, jobStartTime, affectedPrvGrpList);

		return paMedAdherenceAggregationList;
	}

	public Integer markedRecordsAsDirty(String jobName, String groupToExecute, Integer programYear,
			String joblastrunsuccessfuldate, String jobStartTime, List<List<String>> partitions) {
		StopWatch stopWatch = StopWatch.createStarted();
		log.info("executing markedRecordsAsDirty::");
		Integer count = 0;
		if (GroupsToExecute.MODIFIED.getValue().equals(groupToExecute)) {
			for (List<String> subList : partitions) {
				count += paLandingPageRepository.markedRecordsAsDirty(jobName, groupToExecute, programYear,
						joblastrunsuccessfuldate, jobStartTime, subList);

			}
		} else {
			count = paLandingPageRepository.markedRecordsAsDirty(jobName, groupToExecute, programYear, null, null,
					null);
		}

		log.info("markedRecordsAsDirty execution completed for {} records in {} seconds", count,
				stopWatch.getTime(TimeUnit.SECONDS));

		return count;
	}
	
	public Integer inActivateDirtyRecords(String jobName, String groupToExecute, Integer programYear,
			String joblastrunsuccessfuldate, String jobStartTime, List<List<String>> partitions) {
		StopWatch stopWatch = StopWatch.createStarted();
		log.info("executing inActivateDirtyRecords::");
		Integer count = 0;
		if (GroupsToExecute.MODIFIED.getValue().equals(groupToExecute)) {
			for (List<String> subList : partitions) {

				count += paLandingPageRepository.inActivateDirtyRecords(jobName, groupToExecute, programYear,
						joblastrunsuccessfuldate, jobStartTime, subList);

			}
		} else {
			count = paLandingPageRepository.inActivateDirtyRecords(jobName, groupToExecute, programYear, null, null,
					null);
		}
		
		log.info("inActivateDirtyRecords execution completed for {} records in {}seconds", count,
				stopWatch.getTime(TimeUnit.SECONDS));
		return count;
	}

}
