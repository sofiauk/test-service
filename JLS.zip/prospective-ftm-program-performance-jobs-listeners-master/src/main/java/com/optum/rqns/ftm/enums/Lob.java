package com.optum.rqns.ftm.enums;

public enum Lob {

    MEDICARE("MA"),
    MEDICAID("MD"),
    COMMERCIAL("AC");

    private String value;

    Lob(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

}
