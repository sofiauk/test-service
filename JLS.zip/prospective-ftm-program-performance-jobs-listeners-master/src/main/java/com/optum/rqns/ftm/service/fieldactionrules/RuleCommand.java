package com.optum.rqns.ftm.service.fieldactionrules;

import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.RuleEnum;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.model.fieldactionrules.RuleAction;

import java.util.List;

/**
 * Command object
 */
public interface RuleCommand {

    List<RuleAction> get(List<RuleAction> inputData, String jobName);

}
