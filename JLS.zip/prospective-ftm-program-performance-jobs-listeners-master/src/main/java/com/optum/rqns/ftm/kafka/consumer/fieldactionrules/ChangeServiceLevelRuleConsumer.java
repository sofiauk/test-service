package com.optum.rqns.ftm.kafka.consumer.fieldactionrules;

import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.consumer.JobEventConsumer;
import com.optum.rqns.ftm.repository.common.CommonRepositoryImpl;
import com.optum.rqns.ftm.service.fieldactionrules.ChangeServiceLevelRuleServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.context.annotation.Profile;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.annotation.TopicPartition;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

@Profile("fieldActionRules")
@Component
@Slf4j
public class ChangeServiceLevelRuleConsumer extends JobEventConsumer {

    public ChangeServiceLevelRuleConsumer(final ChangeServiceLevelRuleServiceImpl changeServiceLevelRuleService, final CommonRepositoryImpl commonRepository) {
        super(changeServiceLevelRuleService, commonRepository);
    }

    @KafkaListener(topicPartitions = {@TopicPartition(topic = "${spring.gcpkafka.properties.topics.jobEvent}", partitions = {"28"})},
            containerFactory = "jobEventKafkaListenerContainerFactory", autoStartup = "true")
    public void onMessage(ConsumerRecord<String, JobEvent> record, Acknowledgment acknowledgment) {
        log.info("{} Begin Consumer Change Service Level Rule : {}", super.generateTransactionId(record), record);
        processMessage(28, record, acknowledgment);
    }
}
