package com.optum.rqns.ftm.service.fieldactionrules;

import com.optum.rqns.ftm.model.fieldactionrules.RuleAction;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
public class KIERuleOrchestrator {

    @Autowired
    RuleCommandImpl ruleCommand;

    public List<RuleAction> getRulesExecutedData(List<RuleAction> inputData, String jobName) {
        return ruleCommand.executeRuleInWorkbench(inputData, jobName);
    }
}
