package com.optum.rqns.ftm.repository;

import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.enums.JobName;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.concurrent.Callable;

@Repository
@Slf4j
public class IDMGlidePathRepositoryImpl implements IDMGlidePathRepository {

    private static final String MODIFIED_CONDITION = "where CAST(UpdatedDate as date) >= (select CAST(LastSuccessfulRunDate as date)" +
            " from ProgPerf.jobrunconfiguration where jobname= '" + JobName.IDM_GLIDEPATH.getValue() + "')";

    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;


    public IDMGlidePathRepositoryImpl(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
        this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
    }

    private static final String RECORD_COUNT_QUERY = "SELECT COUNT(*) as recCount FROM ProgPerf.ProviderGroupPerformanceIDMGlidePath %s";
    private static final String IDM_DATA_MERGE_QUERY = "MERGE ProgPerf.[ProviderGroupPerformance] AS tgt" +
            "       USING (" +
            "            SELECT ProviderGroupID" +
            "                    , [STATE]" +
            "                    , ServiceLevel" +
            "                    , ClientName" +
            "                    , LobName" +
            "                    , ProgramYear" +
            "                    , DurationValue" +
            "                    , DurationStartDate" +
            "                    , DurationEndDate" +
            "                    , ProviderGroupName" +
            "                    , DeployYETargetPercent" +
            "                    , DeployYTDTargetPercent" +
            "                    , ReturnYETargetPercent" +
            "                    , ReturnYTDTargetPercent" +
            "                    , BatchId" +
            "                    , IDMSyncDate" +
            "                    , CreatedDate" +
            "                    , UpdatedDate" +
            "                    , CreatedBy" +
            "                    , UpdatedBy" +
            "             FROM ProgPerf.[ProviderGroupPerformanceIDMGlidePath]" +
            " %s " +
            "             ORDER BY [ID] OFFSET :OFFSET ROWS FETCH NEXT :BatchSize ROWS ONLY" +
            "             ) AS src" +
            "             ON (" +
            "                           tgt.ProviderGroupID = src.ProviderGroupID" +
            "                           AND tgt.[STATE] = src.[STATE]" +
            "                           AND tgt.ClientName = src.ClientName" +
            "                           AND tgt.LobName = src.LobName" +
            "                           AND tgt.ProgramYear = src.ProgramYear" +
            "                           AND tgt.ServiceLevel = src.ServiceLevel" +
            "                           AND tgt.DurationValue = src.DurationValue" +
            "                           )" +
            "       WHEN MATCHED" +
            "             THEN" +
            "                    UPDATE" +
            "                    SET tgt.ProviderGroupID = src.ProviderGroupID" +
            "                           , tgt.[STATE] = src.[STATE]" +
            "                           , tgt.ServiceLevel = src.ServiceLevel" +
            "                           , tgt.ClientName = src.ClientName" +
            "                           , tgt.LobName = src.LobName" +
            "                           , tgt.ProgramYear = src.ProgramYear" +
            "                           , tgt.DurationValue = src.DurationValue" +
            "                           , tgt.DurationStartDate = src.DurationStartDate" +
            "                           , tgt.DurationEndDate = src.DurationEndDate" +
            "                           , tgt.ProviderGroupName = src.ProviderGroupName" +
            "                           , tgt.DeployYETargetPercent = src.DeployYETargetPercent" +
            "                           , tgt.DeployYTDTargetPercent = src.DeployYTDTargetPercent" +
            "                           , tgt.ReturnYETargetPercent = src.ReturnYETargetPercent" +
            "                           , tgt.ReturnYTDTargetPercent = src.ReturnYTDTargetPercent" +
            "                           , tgt.BatchId = src.BatchId" +
            "                           , tgt.IDMSyncDate = src.IDMSyncDate" +
            "                           , tgt.UpdatedDate = src.UpdatedDate" +
            "                           , tgt.UpdatedBy = src.UpdatedBy" +
            "       WHEN NOT MATCHED" +
            "             THEN" +
            "                    INSERT (" +
            "                           ProviderGroupID" +
            "                           , [STATE]" +
            "                           , ServiceLevel" +
            "                           , ClientName" +
            "                           , LobName" +
            "                           , ProgramYear" +
            "                           , DurationValue" +
            "                           , DurationStartDate" +
            "                           , DurationEndDate" +
            "                           , ProviderGroupName" +
            "                           , DeployYETargetPercent" +
            "                           , DeployYTDTargetPercent" +
            "                           , ReturnYETargetPercent" +
            "                           , ReturnYTDTargetPercent" +
            "                           , BatchId" +
            "                           , IDMSyncDate" +
            "                           , CreatedDate" +
            "                           , UpdatedDate" +
            "                           , CreatedBy" +
            "                           , UpdatedBy" +
            "                           )" +
            "                    VALUES (" +
            "                           src.ProviderGroupID" +
            "                           , src.[STATE]" +
            "                           , src.ServiceLevel" +
            "                           , src.ClientName" +
            "                           , src.LobName" +
            "                           , src.ProgramYear" +
            "                           , src.DurationValue" +
            "                           , src.DurationStartDate" +
            "                           , src.DurationEndDate" +
            "                           , src.ProviderGroupName" +
            "                           , src.DeployYETargetPercent" +
            "                           , src.DeployYTDTargetPercent" +
            "                           , src.ReturnYETargetPercent" +
            "                           , src.ReturnYTDTargetPercent" +
            "                           , src.BatchId" +
            "                           , src.IDMSyncDate" +
            "                           , src.CreatedDate" +
            "                           , src.UpdatedDate" +
            "                           , src.CreatedBy" +
            "                           , src.UpdatedBy" +
            "                           );";

    @Override
    public Long getRecordCount(boolean canExecuteForAllProviderGroups) {
        String query;
        if (canExecuteForAllProviderGroups) {
            query = String.format(RECORD_COUNT_QUERY, Constants.EMPTY);
        } else {
            query = String.format(RECORD_COUNT_QUERY, MODIFIED_CONDITION);
        }
        log.info(query);
        return namedParameterJdbcTemplate.queryForObject(query, new HashMap<>(), Long.class);
    }

    @Override
    public Callable<Integer> mergeIDMData(int batchSize, Integer batchOffset, boolean canExecuteForAllProviderGroups) {
        SqlParameterSource sqlParameterSource = new MapSqlParameterSource("BatchSize", batchSize)
                .addValue("OFFSET", batchOffset);
        log.info("batchsize {} offset {}", batchSize, batchOffset);
        String query;
        if (canExecuteForAllProviderGroups) {
            query = String.format(IDM_DATA_MERGE_QUERY, Constants.EMPTY);
        } else {
            query = String.format(IDM_DATA_MERGE_QUERY, MODIFIED_CONDITION);
        }
        return () -> this.namedParameterJdbcTemplate
                .update(query, sqlParameterSource);
    }
}
