package com.optum.rqns.ftm.kafka.consumer.practiceassist;

import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.consumer.JobEventConsumer;
import com.optum.rqns.ftm.repository.common.CommonRepositoryImpl;
import com.optum.rqns.ftm.service.practiceassist.MbrMedAdherenceAggregationServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.annotation.TopicPartition;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

@Profile("paLandingPageJobs")
@Component
@Slf4j
public class MbrMedAdherenceAggregationConsumer extends JobEventConsumer {

	@Autowired
	private AggregationJobCounter aggregationJobCounter;

	public MbrMedAdherenceAggregationConsumer(final MbrMedAdherenceAggregationServiceImpl mbrMedAdherenceAggregationService,
                                              final CommonRepositoryImpl commonRepository) {
		super(mbrMedAdherenceAggregationService, commonRepository);
	}

	@KafkaListener(topicPartitions = {
			@TopicPartition(topic = "${spring.gcpkafka.properties.topics.jobEvent}", partitions = {"51" }) },
			containerFactory = "jobEventKafkaListenerContainerFactory", autoStartup = "true")
	public void onMessage(ConsumerRecord<String, JobEvent> record, Acknowledgment acknowledgment) {
		log.info("{} MbrMedAdherenceAggregation Consumer : {}", super.generateTransactionId(record), record);
		processMessage(51, record, acknowledgment);
		aggregationJobCounter.aggrJobStatusIs("MbrMedAdherenceJob");
	}

}