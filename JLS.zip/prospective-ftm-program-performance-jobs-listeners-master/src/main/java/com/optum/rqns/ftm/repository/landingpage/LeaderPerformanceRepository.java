package com.optum.rqns.ftm.repository.landingpage;

import com.optum.rqns.ftm.model.ProgramYearCalendarDTO;
import java.util.List;

public interface LeaderPerformanceRepository {

    long loadLeaderPerformanceNationalLevelAll(ProgramYearCalendarDTO programYearCalendarDTO);

    int calculateICPerformanceData(String ic, String serviceLevel, ProgramYearCalendarDTO programYearCalendarDTO);

    List<String> getServiceLevelForUser(String ic);

    long loadDataToEModalityFromMemberAssessments(int programYear);

    int calculateLeaderPerformanceData(String leader, List<String> totalReporters,String durationValue);

    long loadLeaderPerformanceWeekly(ProgramYearCalendarDTO programYearCalendarDTO);

    Integer flagIsCurrentWeekFalse(int programYear, ProgramYearCalendarDTO programYearCalendarDTO);

    Integer flagIsActiveFalse(int programYear, ProgramYearCalendarDTO programYearCalendarDTO);

    Integer calculateICGrowthRatePOCData(String ic, String sl, ProgramYearCalendarDTO programYearCalendarDTO);

    int calculateLeaderGrowthRatePOCData(String leader, List<String> totalReporters,int programyear);

    int updateICGoalLeaderPerformance(String userId, String serviceLevel, ProgramYearCalendarDTO programYearCalendarDTO);

    int updateRegions(ProgramYearCalendarDTO programYearCalendarDTO);

    int calculateCGapData(String ic, String sl, ProgramYearCalendarDTO programYearCalendarDTO);

    Integer calculateEModalityPOCData(String userId, String serviceLevel, ProgramYearCalendarDTO programYearCalendarDTO);

    Integer calculateEModalityPOCDataForClientAndLob(String userId, String serviceLevel, ProgramYearCalendarDTO programYearCalendarDTO);

    List<String> getUsersByRole(List<String> roleNames);

    int updateIsActiveFlagToFalse(String programYear);

    int calculateLeaderGrowthRatePOCDataForAllRegionAndState(String leader, List<String> totalReporters,int programyear);

    Integer calculateReturenNetCnaForALL(String userId, String serviceLevel, ProgramYearCalendarDTO programYearCalendarDTO);

    Integer calculateReturenNetCnaForClientAndLob(String userId, String serviceLevel, ProgramYearCalendarDTO programYearCalendarDTO);

    Integer calculateNationalGrowthRatePOCData(String uuid, ProgramYearCalendarDTO programYearCalendarDTO);

    Integer calculateReturnNetCnaForNational(String userId, ProgramYearCalendarDTO programYearCalendarDTO);

    Integer calculateEModalityPOCDataForNational(String userId, ProgramYearCalendarDTO programYearCalendarDTO);
    
    Integer calculateEModalityPOCDataForNationalClientLob(String userId, ProgramYearCalendarDTO programYearCalendarDTO);

    Integer calculateReturnNetCnaForAllNational(String userId, ProgramYearCalendarDTO programYearCalendarDTO);

    long loadLeaderPerformanceWeeklyCGAPClosureStateRegion(ProgramYearCalendarDTO programYearCalendarDTO);

    long loadLeaderPerformanceWeeklyCGAPClosureNational(ProgramYearCalendarDTO programYearCalendarDTO);

    int updateAllNationalGoalsLeaderPerformance( ProgramYearCalendarDTO programYearCalendarDTO);

    int updateNationalGoalsLeaderPerformance(  ProgramYearCalendarDTO programYearCalendarDTO);

    Integer calculateReturenNetCnaForALLHistorical(String ic, String sl,  ProgramYearCalendarDTO programYearCalendarDTO);

    Integer calculateReturenNetCnaForClientAndLobHistorical(String ic, String sl, ProgramYearCalendarDTO programYearCalendarDTO);

    int calculateReturnNetCnaForAllNationalHistorical(String national, ProgramYearCalendarDTO programYearCalendarDTO);



    int calculateLeaderGrowthRatePOCDataHistorical(String leader, List<String> totalReporters, ProgramYearCalendarDTO programYearCalendarDTO);

    int calculateLeaderGrowthRatePOCDataForAllRegionAndStateHistorical(String leader, List<String> leader1, ProgramYearCalendarDTO programYearCalendarDTO);

    int calculateEModalityPOCDataHistorical(String userId, String serviceLevel, ProgramYearCalendarDTO programYearCalendarDTO);
    int calculateEModalityPOCDataForClientAndLobHistorical(String userId, String serviceLevel, ProgramYearCalendarDTO programYearCalendarDTO);
    int calculateReturnNetCnaForNationalHistorical(String national, ProgramYearCalendarDTO programYearCalendarDTO);

//    int calculateLeaderGrowthRatePOCDataForAllRegionAndStateHistorical(String userId, String serviceLevel, ProgramYearCalendarDTO programYearCalendarDTO);

    Integer calculateICGrowthRatePOCDataHistorical(String userId, String serviceLevel, ProgramYearCalendarDTO programYearCalendarDTO);
    int updateRegionsForHistory(ProgramYearCalendarDTO programYearCalendarDTO);
    Integer calculateNationalGrowthRatePOCDataHistorical(String userId,  ProgramYearCalendarDTO programYearCalendarDTO);
    Integer calculateEModalityPOCDataForNationalHistorical(String userId, ProgramYearCalendarDTO programYearCalendarDTO);
    Integer calculateEModalityPOCDataForNationalClientLobHistorical(String userId, ProgramYearCalendarDTO programYearCalendarDTO);
}
