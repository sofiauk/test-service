package com.optum.rqns.ftm.service.fieldactionrules;

import com.google.gson.Gson;
import com.optum.rqns.ftm.model.fieldactionrules.NewMemberShipAction;
import com.optum.rqns.ftm.model.fieldactionrules.RuleAction;
import com.optum.rqns.ftm.repository.fieldactionrules.NewProviderGroupMembershipRepo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@Slf4j
public class NewProviderGroupMembershipServiceImpl extends FieldActionRuleService {

    private NewProviderGroupMembershipRepo newProviderGroupMembershipRepo;

    @Value("${jobs.workqueueRuleAction.newProviderGroupMembership.batchSize}")
    public int batchSize;

    public NewProviderGroupMembershipServiceImpl(NewProviderGroupMembershipRepo newProviderGroupMembershipRepo) {
        this.newProviderGroupMembershipRepo = newProviderGroupMembershipRepo;
        setBatchingRequired(true);
        setBatchSize(batchSize);
    }


    @Override
    public List<Integer> fetchRuleBatchingOffsetList(int batchsize) {
        return newProviderGroupMembershipRepo.getRowCountforNewProviderMembership(batchsize);
    }

    @Override
    public List<RuleAction> fetchRuleData(Integer beginIndex,int batchSize, boolean batchingrequired) {
        return newProviderGroupMembershipRepo.processtoSendActionForNewProviderMembership(beginIndex,batchSize);
    }


    @Override
    public String getRuleResult(RuleAction ruleAction) {
        Map<String,Object> resultMap=new HashMap<>();
        Gson gson=new Gson();
        if(NewMemberShipAction.class.isInstance(ruleAction)){
            NewMemberShipAction newMemberShipAction=(NewMemberShipAction) ruleAction;
            resultMap.put("currentWeekMemberShipCount",newMemberShipAction.getCurrentWeekMemberShipCount());
            resultMap.put("previousWeekMemberShipCount",newMemberShipAction.getPreviousWeekMemberShipCount());
            resultMap.put("providerGroupId",newMemberShipAction.getProviderGroupId());
            resultMap.put("providerGroupName",newMemberShipAction.getProviderGroupName());
            resultMap.put("state",newMemberShipAction.getState());
            return gson.toJson(resultMap);
        }else{
            return null;
        }

    }

    @Override
    public int postProcessing(List<RuleAction> actions){
        final int[] ints = newProviderGroupMembershipRepo
                .updateBaseLine(actions);
        return Arrays.stream(ints)
                .reduce(Integer::sum)
                .getAsInt();

    }

}
