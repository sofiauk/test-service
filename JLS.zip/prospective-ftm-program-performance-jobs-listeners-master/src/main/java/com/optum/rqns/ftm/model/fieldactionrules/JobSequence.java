package com.optum.rqns.ftm.model.fieldactionrules;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;


@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class JobSequence {

    private List<JobDetails> cascadedJobs;

}
