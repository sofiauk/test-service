package com.optum.rqns.ftm;

import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.optum.rqns.ftm")
@EnableEncryptableProperties
@Slf4j
public class Application {

    public static void main(String[] args) {

        SpringApplication.run(Application.class, args);

        log.info("\n\n----------------------------------------------------------\n\t"
                + "FTM Program Performance Jobs Listener Service Started Successfully"
                + "\n----------------------------------------------------------\n");
    }

}
