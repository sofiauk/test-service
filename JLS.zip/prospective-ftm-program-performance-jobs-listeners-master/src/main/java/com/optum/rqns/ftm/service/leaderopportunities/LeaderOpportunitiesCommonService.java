package com.optum.rqns.ftm.service.leaderopportunities;

import com.fasterxml.uuid.Generators;
import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.enums.GroupsToExecute;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.exception.ProgramPerformanceJobListenerException;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.repository.common.CommonRepository;
import com.optum.rqns.ftm.repository.leaderopportunities.LeaderOpportunitiesCommonRepositoryImpl;
import com.optum.rqns.ftm.repository.users.UsersRepository;
import com.optum.rqns.ftm.service.IJob;
import com.optum.rqns.ftm.util.ProgramPerformanceJobUtil;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;


@Slf4j
@Service
public abstract class LeaderOpportunitiesCommonService implements IJob {

    @Autowired
    private LeaderOpportunitiesCommonRepositoryImpl leaderCommonOpportunitiesRepository;

    @Autowired
    private UsersRepository usersRepository;

    @Autowired
    private CommonRepository commonRepository;

    static final List<String> LEADER_ROLES = Arrays.asList("RVP", "Director", "Manager");
    static final List<String> IC_ROLES = Arrays.asList("PSC", "HCA");

    @Override
    public JobStatus executeJob(JobEvent mainJobEvent) {

        MDC.put(Constants.TRACE_ID, Generators.timeBasedGenerator().generate().toString());
        MDC.put(Constants.TRANSACTION_ID, ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
        MDC.put(Constants.MESSAGE_ID, ProgramPerformanceJobUtil.TransactionIdLogger.getMessageIdIdentifier());


        JobStatus jobStatus = new JobStatus();
        JobEvent jobEvent;

        //Whenever Monthly scenario comes we will run ALL Scenario for Leaders
        if(GroupsToExecute.MONTHLY.getValue().equalsIgnoreCase(mainJobEvent.getGroupsToExecute().toString())){
            jobEvent = getJobEvent(mainJobEvent, GroupsToExecute.ALL.getValue());
        }else{
            jobEvent = getJobEvent(mainJobEvent, mainJobEvent.getGroupsToExecute().toString());
        }

        try {
            log.info("{} job started ", jobEvent.getJobName());
            long totalUpdatedRecords = 0;

            if (jobEvent.getProgramYear() == null) {
                jobEvent.setProgramYear(commonRepository.getCurrentProgramYear());
            }

            dataCleanUp(jobEvent, jobStatus);
            totalUpdatedRecords = calculateLeaderOpportunitiesForAllUsers(jobStatus, jobEvent);
            log.info("total updated record count for leaders in {} job is {}",jobEvent.getJobName(), totalUpdatedRecords);

            jobStatus.setUpdatedRows(totalUpdatedRecords);

            jobStatus.setStatus(Status.SUCCESS);
            jobStatus.setMessage("Completed Job successfully Job Name is {}" + jobEvent.getJobName().toString());

            log.info("Completed the Job Successfully:{}", jobEvent.getJobName());

        } catch (Exception e) {
            log.error("Exception while executing job : {}{}", (jobEvent.getJobName().toString()), e);
            jobStatus.setStatus(Status.FAILURE);
            jobStatus.setMessage("Execution is failed for job::" + jobEvent.getJobName().toString());
            jobStatus.setUpdatedRows(0L);
        } finally {
            MDC.clear();
        }
        return jobStatus;
    }

    private JobEvent getJobEvent(JobEvent mainJobEvent, String groupsToExecute) {
        JobEvent jobEvent=new JobEvent();
        jobEvent.setProgramYear(mainJobEvent.getProgramYear());
        jobEvent.setJobName(mainJobEvent.getJobName());
        jobEvent.setGroupsToExecute(groupsToExecute);
        jobEvent.setExecutionWeek(mainJobEvent.getExecutionWeek());
        jobEvent.setCascadeEvents(mainJobEvent.getCascadeEvents());
        jobEvent.setStatus(mainJobEvent.getStatus());
        return jobEvent;
    }


    private Long calculateLeaderOpportunitiesForAllUsers(JobStatus jobStatus, JobEvent jobEvent){
        log.info("{} job Started ", jobEvent.getJobName());
        try {
            //1. get RVPs,Directors,Managers
            List<String> leaders = usersRepository.getUsersByRole(LEADER_ROLES);
            log.info("{} leaders size {}", jobEvent.getJobName(), leaders.size());

            //2. get ICs
            List<String> ics = usersRepository.getUsersByRole(IC_ROLES);
            log.info("{} ic size {}", jobEvent.getJobName(), ics.size());

            ics.parallelStream()
                    .forEach(ic -> {
                        int updatedCount = 0;
                        List<String> serviceLevels = leaderCommonOpportunitiesRepository.getServiceLevelForUser(ic);


                        updatedCount = serviceLevels.parallelStream()
                                .map(sl -> calculateICOppData(ic, sl, jobEvent.getProgramYear()))
                                .reduce(Integer::sum)
                                .orElse(0);

                        log.info("IC of {} Data updated count {}", ic, updatedCount);
                        jobStatus.setUpdatedRows(Long.valueOf(updatedCount));


                    });

            leaders.parallelStream()
                    .forEach(leader -> {
                        final List<String> totalReporters = usersRepository.getIcReporters(leader);

                        int updatedCount = 0;
                        if (Objects.nonNull(totalReporters) && !totalReporters.isEmpty()) {
                            log.info("leader of {} reporters {}", leader, totalReporters);

                            updatedCount = calculateLeaderOppData(leader, totalReporters);


                        } else {
                            log.warn(" leader of {}  has no reporters {}", leader, totalReporters);
                        }

                        jobStatus.setUpdatedRows(jobStatus.getUpdatedRows() + updatedCount);

                    });

            return jobStatus.getUpdatedRows();

        } catch (Exception e) {
            log.error("exception occurred in calculating leader quality gaps opportunities", e);
            throw new ProgramPerformanceJobListenerException("exception occurred in calculating leader quality gaps opportunities");
        }
    };

    public abstract  int calculateICOppData(String ic,String sl,int programYear);

    public abstract  int calculateLeaderOppData(String leader,List<String> totalReporters);

    public abstract void dataCleanUp(JobEvent jobEvent, JobStatus jobStatus) ;


    }