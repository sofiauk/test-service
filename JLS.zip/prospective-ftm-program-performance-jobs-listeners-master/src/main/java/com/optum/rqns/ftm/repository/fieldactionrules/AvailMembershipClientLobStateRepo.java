package com.optum.rqns.ftm.repository.fieldactionrules;

import com.optum.rqns.ftm.model.fieldactionrules.RuleAction;

import java.util.List;

public interface AvailMembershipClientLobStateRepo {
    public List<RuleAction> fetchAvailMembershipClientLobStateInfo(Integer beginIndex, int batchSize);

    public List<Integer> getRowCountAndBatchesForAvailMembershipClientLobState(int batchSize);
}
