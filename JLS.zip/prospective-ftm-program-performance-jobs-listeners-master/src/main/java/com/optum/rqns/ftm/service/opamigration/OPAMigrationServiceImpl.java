package com.optum.rqns.ftm.service.opamigration;

import com.fasterxml.uuid.Generators;
import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.exception.JobErrorCode;
import com.optum.rqns.ftm.exception.ProgramPerformanceJobListenerException;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.avro.models.v1.pps.MemberPaymentOverallStatusSync;
import com.optum.rqns.ftm.kafka.producer.JobEventProducer;
import com.optum.rqns.ftm.kafka.producer.KeyBasedMemberOverallStatusSyncProducer;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.model.opamigration.MemberOverallStatus;
import com.optum.rqns.ftm.repository.common.CommonRepository;
import com.optum.rqns.ftm.repository.opamigration.OPAMigrationRepository;
import com.optum.rqns.ftm.util.ProgramPerformanceJobUtil;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.StopWatch;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicInteger;

@Service
@Slf4j
public class OPAMigrationServiceImpl implements OPAMigrationService {

    @Autowired
    private JobEventProducer jobEventProducer;

    private OPAMigrationRepository opaMigrationRepository;

    @Autowired
    private KeyBasedMemberOverallStatusSyncProducer producer;

    @Autowired
    private CommonRepository commonRepository;

    private static final int BATCH_SIZE = 10000;

    private static final String BATCH_NAME = "MVR";

    @Value("${opa_migration_producer_thread_pool_size}")
    private int producerThreadPoolSize;

    private DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public OPAMigrationServiceImpl(OPAMigrationRepository opaMigrationRepository){
        this.opaMigrationRepository = opaMigrationRepository;
    }

    Map<String,String> kafkaEnableMap= new HashMap<>();

    @Override
    public JobStatus executeJob(JobEvent jobEvent) {
        log.info("job start {}",LocalDateTime.now());
        MDC.put(Constants.TRACE_ID, Generators.timeBasedGenerator().generate().toString());
        MDC.put(Constants.TRANSACTION_ID, ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
        MDC.put(Constants.MESSAGE_ID, ProgramPerformanceJobUtil.TransactionIdLogger.getMessageIdIdentifier());
        log.info("{} jobEvent.RunMemberPaymentOverallStatusSync() :: {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), jobEvent.getJobName());
        String batchId = BATCH_NAME + "-" + dateFormat.format(LocalDateTime.now());
        log.info("{} started jobEvent.RunMemberPaymentOverallStatusSync() executing with batch id",batchId);
        JobStatus jobStatus = new JobStatus();
        Map<String, String> KafkaEnableProps = fetchKafkaEnableDisableProperties();
        final CustomJobInput customJobInput = new CustomJobInput(false);
        if (StringUtils.isNoneEmpty(jobEvent.getJobInput())) {
            try {
                CustomJobInput lActualJobInput = (CustomJobInput) ProgramPerformanceJobUtil.jsonToPojo(jobEvent.getJobInput().toString(), CustomJobInput.class);
                customJobInput.setExecuteAll(lActualJobInput.isExecuteAll());
                log.info(" jobInputClass get value is {}", customJobInput.isExecuteAll());
            } catch (Exception e) {
                log.error("Invalid Job Input Provided");
                throw new ProgramPerformanceJobListenerException(HttpStatus.NOT_ACCEPTABLE, JobErrorCode.INVALID_JOB_EVENT_DETAILS);
            }
        }
        try {
            if(customJobInput.isExecuteAll()) {

                long currentProgramYearCount = executeRuleWithAll(jobEvent, jobEvent.getProgramYear(), batchId);
                log.info("{} Completed RunMemberPaymentOverallStatusSync Job processing", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
                log.info("{} Completed jobEvent.RunMemberPaymentOverallStatusSync() with batch id",batchId);
                jobStatus.setStatus(Status.SUCCESS);
                jobStatus.setMessage("Completed RunMemberPaymentOverallStatusSync job successfully "+batchId);
                jobStatus.setUpdatedRows(currentProgramYearCount);
                log.info("job end {}",LocalDateTime.now());
                return jobStatus;
            } else {
                long currentProgramYearCount = executeWithRuleWithModify(jobEvent, jobEvent.getProgramYear(), batchId);
                long totalCount = currentProgramYearCount;
                log.info("{} Completed RunMemberPaymentOverallStatusSync Job processing", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
                if(totalCount > 0) {
                    log.info("{} Member Overall Status available in MemberAssessment with JobLastSuccessfulRunDate", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
                    log.info("{} Completed jobEvent.RunMemberPaymentOverallStatusSync() with batch id",batchId);
                    jobStatus.setStatus(Status.SUCCESS);
                    jobStatus.setMessage("Completed RunMemberPaymentOverallStatusSync job successfully"+batchId);
                }else{
                    log.info("{} No Member Overall Status available in MemberAssessment with JobLastSuccessfulRunDate ", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
                    log.info("{} Completed jobEvent.RunMemberPaymentOverallStatusSync() with batch id",batchId);
                    jobStatus.setStatus(Status.SUCCESS);
                    jobStatus.setMessage("Completed RunMemberPaymentOverallStatusSync Modify job successfully and No Member Overall Status available");
                }
                jobStatus.setUpdatedRows(totalCount);
                return jobStatus;
            }

        }catch (Exception e){
            log.error("Exception while executing with RunMemberPaymentOverallStatusSync job : {}", e);

            jobStatus.setStatus(Status.FAILURE);
            jobStatus.setMessage("RunMemberPaymentOverallStatusSync job execution failed : " + e.getMessage());
            jobStatus.setUpdatedRows(0L);
            return jobStatus;
        }
        finally {
            MDC.clear();
        }

    }

    @Data
    @AllArgsConstructor
    private static class CustomJobInput {
        private boolean executeAll;
    }

    private long executeWithRuleWithModify(JobEvent jobEvent, Integer programYear, String batchId) {
        log.info("{} Inside Run Job with Modify", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
        AtomicInteger updatedRecords = new AtomicInteger();
        final Long totalRows = opaMigrationRepository.getRecordCountForLastUpdateJobRunConfiguration(programYear);
        log.info("record Count {}, programYear = {}", totalRows, programYear);
        List<Integer> batches = getBatches(totalRows);
        batches.stream().forEach(batchOffset -> {
            List<MemberOverallStatus> memberOverallStatuses = opaMigrationRepository.getMemberStatusDetailsBasedOnLostJobRunDate(BATCH_SIZE, batchOffset, programYear);
            sendMemberOverallStatus(memberOverallStatuses, jobEvent, batchId);
            updatedRecords.addAndGet(memberOverallStatuses.size());
        });
        return updatedRecords.longValue();
    }

    private long executeRuleWithAll(JobEvent jobEvent, Integer programYear, String batchId) {

        log.info("{} Inside Run Job with All", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
        AtomicInteger updatedRecords = new AtomicInteger();
        /**
         * 1. Get MemberAssessments from DB
         * 2. Get MemberAssessments from List
         * 3. Get MemberAssessmentsCount from DB
         */
        final Long totalRows = opaMigrationRepository.getRecordCount(programYear);
        log.info("record Count {}, {}", totalRows, programYear);
        List<Integer> batches = getBatches(totalRows);
        batches.stream().forEach(batchOffset -> {
            List<MemberOverallStatus> MemberOverallStatusDetails = opaMigrationRepository.getMemberStatusDetails(BATCH_SIZE, batchOffset, programYear);
            updatedRecords.addAndGet(MemberOverallStatusDetails.size());
            sendMemberOverallStatus(MemberOverallStatusDetails, jobEvent, batchId);
        });
        return updatedRecords.longValue();
    }

    private void sendMemberOverallStatus(List<MemberOverallStatus> memberStatuses, JobEvent jobEvent, String batchId) {
        log.info("{} Executing RunMemberPaymentOverallStatusSync Job {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), memberStatuses.size());
        //For parallel producing
        ExecutorService executorService = Executors.newFixedThreadPool(producerThreadPoolSize);
        List<Callable<Boolean>> taskList = new ArrayList<>();
        memberStatuses.stream().forEach(memberStatus ->{
            taskList.add(()->{
                return producer.postToKafka(buildMemberOverallStatusAvarov1(memberStatus, jobEvent, batchId), (JobName.RUN_MEMBER_PAYMENT_OVERALL_STATUS_SYNC.getValue() + "_" + memberStatus.getClientId()  +  memberStatus.getGlobalMemberId() + memberStatus.getLob() + memberStatus.getProgramYear()), kafkaEnableMap);
            });
        });
        // Producing Elements to Topic parallelly
        StopWatch stopWatch = StopWatch.createStarted();
        log.info("started publishing data into kafka {}", LocalDateTime.now());
        producingElementsParallellyToTopic(executorService, taskList);
        log.info("ended publishing data into kafka {}", LocalDateTime.now());
        stopWatch.stop();
        log.info("Time took for producing messages to kafka in ms is ::" + stopWatch.getTime() + " and rule is Member Overall Status Service Impl::");

    }

    private MemberPaymentOverallStatusSync buildMemberOverallStatusAvarov1(MemberOverallStatus memberStatus, JobEvent jobEvent, String batchId) {
        MemberPaymentOverallStatusSync memberAvaroMessage = new MemberPaymentOverallStatusSync();
        memberAvaroMessage.setGlobalMemberId(memberStatus.getGlobalMemberId());
        memberAvaroMessage.setClientId(memberStatus.getClientId());
        memberAvaroMessage.setLob(memberStatus.getLob());
        memberAvaroMessage.setOverallStatus(memberStatus.getOverallStatus());
        memberAvaroMessage.setProgramYear(memberStatus.getProgramYear());
        memberAvaroMessage.setProviderGroupId(memberStatus.getProviderGroupId());
        memberAvaroMessage.setMessageCorrelationId(memberStatus.getMessageCorrId());
        memberAvaroMessage.setDeploymentDate(dateFormat.format(memberStatus.getDeployDate()));
        memberAvaroMessage.setDeploymentChannel(memberStatus.getDistributionChannel());
        memberAvaroMessage.setSource("PPS");
        memberAvaroMessage.setMessageBatchId(batchId);
        memberAvaroMessage.setAssessmentDttm(dateFormat.format(memberStatus.getUpdatedDate()));
        return memberAvaroMessage;
    }


    /*
     *  To produce the messages parallelly to kafka ,this method is written
     * @param executorService,taskList
     * @return boolean
     */
    public Boolean producingElementsParallellyToTopic(ExecutorService executorService, List<Callable<Boolean>> taskList) {
        boolean iselementsProc = true;
        try {
            List<Future<Boolean>> results = executorService.invokeAll(taskList);
            for(Future<Boolean> f : results) {
                if(f != null && f.get()) {

                } else {
                    log.warn(" Future object not able to fetch::");
                }
            }

        } catch(Exception e) {
            iselementsProc = false;
            log.error("Error while  producing the elements Parallelly " + e);
        } finally {
            taskList.clear();
            executorService.shutdown();
        }
        return iselementsProc;
    }

    private List<Integer> getBatches(Long totalRows) {
        List<Integer> batches = new ArrayList<>();
        if (totalRows > 0) {
            for (int batchOffset = 0; batchOffset <= totalRows; batchOffset += BATCH_SIZE) {
                batches.add(batchOffset);
            }
        }
        return batches;
    }

    private Map<String, String> fetchKafkaEnableDisableProperties() {
        try {
                String rqsKafkaEnabled = commonRepository.getKafkaEnabledConf(Constants.MEMBER_STATUS_RQS_ENABLED);
                kafkaEnableMap.put(Constants.MEMBER_STATUS_RQS_ENABLED, rqsKafkaEnabled);

                String gcpKafkaEnabled = commonRepository.getKafkaEnabledConf(Constants.MEMBER_STATUS_GCP_ENABLED);
                kafkaEnableMap.put(Constants.MEMBER_STATUS_GCP_ENABLED, gcpKafkaEnabled);
        }
        catch (Exception ex) {
            log.error("Error While fetching the KafkaEnable Properties {}",ex.getMessage());
        }
        return kafkaEnableMap;
    }
}
