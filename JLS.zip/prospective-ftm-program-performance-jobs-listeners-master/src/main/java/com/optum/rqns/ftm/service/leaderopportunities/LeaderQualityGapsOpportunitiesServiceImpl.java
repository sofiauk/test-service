package com.optum.rqns.ftm.service.leaderopportunities;

import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.repository.leaderopportunities.LeaderOpportunitiesCommonRepositoryImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
public class LeaderQualityGapsOpportunitiesServiceImpl extends LeaderOpportunitiesCommonService {

    @Autowired
    private LeaderOpportunitiesCommonRepositoryImpl leaderCommonOpportunitiesRepository;


    @Override
    public int calculateICOppData(String ic, String sl, int programYear) {
        return leaderCommonOpportunitiesRepository.calculateICQualityGapsAndACVOppData(ic, sl, Constants.QUALITY_GAPS, programYear, JobName.LEADER_QUALITY_GAPS_OPPORTUNITIES.getValue());

    }

    @Override
    public int calculateLeaderOppData(String leader, List<String> totalReporters) {
        return leaderCommonOpportunitiesRepository.calculateLeaderCommonOppData(leader, totalReporters, Constants.QUALITY_GAPS, JobName.LEADER_QUALITY_GAPS_OPPORTUNITIES.getValue());
    }

    @Override
    public void dataCleanUp(JobEvent jobEvent, JobStatus jobStatus) {
        final Integer rows = leaderCommonOpportunitiesRepository.flagIsActiveFalseLeaderOpportunities(jobEvent, Constants.QUALITY_GAPS);
        jobStatus.setUpdatedRows(Long.valueOf(rows));

        log.info("Leader Oppportunities for {} flag false count:{}", jobEvent.getJobName(),rows);
        jobStatus.setMessage("Leader Oppportunities flag false count:" + rows);
    }

}
