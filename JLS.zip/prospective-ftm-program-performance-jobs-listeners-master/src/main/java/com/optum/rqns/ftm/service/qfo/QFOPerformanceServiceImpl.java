package com.optum.rqns.ftm.service.qfo;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.kafka.avro.models.v1.program.performance.provider.ProgPerfProviderMSSync;
import com.optum.rqns.ftm.kafka.avro.models.v1.program.performance.provider.QfoPerformance;
import com.optum.rqns.ftm.kafka.producer.KeyBasedProviderSyncProducer;
import com.optum.rqns.ftm.model.qfo.QfoPerformanceData;
import org.apache.commons.lang3.time.StopWatch;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.uuid.Generators;
import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.model.qfo.CommonProgramYearCalenderDTO;
import com.optum.rqns.ftm.repository.common.CommonRepository;
import com.optum.rqns.ftm.repository.qfo.QFOPerformanceRepository;
import com.optum.rqns.ftm.util.JobUtilility;
import com.optum.rqns.ftm.util.ProgramPerformanceJobUtil;

import lombok.extern.slf4j.Slf4j;


@Service
@Slf4j
public class QFOPerformanceServiceImpl implements QFOPerformanceService {

    private QFOPerformanceRepository qfoPerformanceRepository;

    private CommonRepository commonRepository;

    private JobUtilility jobUtilility =new JobUtilility();

    private  CommonProgramYearCalenderDTO commonProgramYearCalenderDTO;

    public static final int BATCH_SIZE = 10000;

    @Value("${new_providergroup_rule_producer_thread_pool_size}")
    private int producerThreadPoolSize;

    @Autowired
    private KeyBasedProviderSyncProducer producer;

    public QFOPerformanceServiceImpl(QFOPerformanceRepository qfoPerformanceRepository, CommonRepository commonRepository) {
        this.qfoPerformanceRepository = qfoPerformanceRepository;
        this.commonRepository = commonRepository;
    }

    public JobStatus executeJob(JobEvent jobEvent) {
        jobEvent.setProgramYear(LocalDate.now().getYear());
         commonProgramYearCalenderDTO=commonRepository.getDuration(jobEvent.getProgramYear(),"QFO");
        MDC.put(Constants.TRACE_ID, Generators.timeBasedGenerator().generate().toString());
        MDC.put(Constants.TRANSACTION_ID, ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
        MDC.put(Constants.MESSAGE_ID, ProgramPerformanceJobUtil.TransactionIdLogger.getMessageIdIdentifier());

        log.info("{} jobEvent.QFOPerformance() :: {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), jobEvent.getJobName());
        try {
          return executePerformanceJob(jobEvent);
        }
        finally {
            MDC.clear();
        }
    }


    /**
     * Execute Performance Job
     * @param jobEvent
     * @return
     */
    private JobStatus executePerformanceJob(JobEvent jobEvent) {
        log.info("{} Inside Run Job with Modify", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());

        JobStatus jobStatus = new JobStatus();

        try{
            //Sub Process -1 US846509 PG Performance Details Quality Job 1 --- Patient Counts (Total Patients, MAPCPi Eligible Patients, MCAPI Total MCAIP Patients- from Member quality
           Long updatedMemberQualityRecords=  executeMemberQualityPerformanceDetails(jobEvent);

            //Sub Process -2 US896739: Start Rating GlidePath Quality Job 2  Star Ratings from StarRatingIngestion Table
            Long updatedStarRatingGlidePath = executeStarRatingGlidePath(jobEvent);

            //Sub process -3 US846527: PG Performance Details Suspect Job  Suspect conditions, assessed counts, Patient counts - From Suspect table
            Long updatedSuspectConditionsRecords;
            if(Constants.ALL.equalsIgnoreCase(jobEvent.getGroupsToExecute().toString()) || Constants.MONTHLY.equalsIgnoreCase(jobEvent.getGroupsToExecute().toString())) {
                 updatedSuspectConditionsRecords = executeAllSuspectsPerformanceDetails(jobEvent);
            } else {
                 updatedSuspectConditionsRecords = executeModifiedSuspectsPerformanceDetails(jobEvent);
            }

            // Sub Process - 4 [US896741] Publishing ProviderGroupPerformanceDetails Data into BoB Sync
            Long publishBoBSyncData = publishQfoPerformanceDataToBob(jobEvent);

            //Generate final message and update in JobRunconfiguration
            String message = "Completed QFOPerformance job successfully. "
                    + ", MemberSuspects: "+updatedSuspectConditionsRecords
                    + ", MemberQuality: "+updatedMemberQualityRecords
                    + ", Star Rating Glide Path: "+updatedStarRatingGlidePath
                    + ", Qfo Performance BOB Sync Data: "+ publishBoBSyncData;
            jobStatus.setStatus(Status.SUCCESS);
            jobStatus.setMessage(message);
            jobStatus.setUpdatedRows(updatedMemberQualityRecords+updatedStarRatingGlidePath+ updatedSuspectConditionsRecords + publishBoBSyncData);
        } catch(Exception e){
            log.error("Exception while executing with Modify QFOPerformance job : {}", e);

            jobStatus.setStatus(Status.FAILURE);
            jobStatus.setMessage("QFOPerformance job execution failed : " + e.getMessage());
            jobStatus.setUpdatedRows(0L);
        }
        return jobStatus;
    }

    private long executeModifiedSuspectsPerformanceDetails(JobEvent jobEvent) {
        log.info("{} QFO Performance - modified suspectConditions sub process started",ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
        Integer programYear = jobEvent.getProgramYear();
        Long modifiedRows = qfoPerformanceRepository.getModifiedSuspectConditionsCount(programYear);
        log.info("{} QFO all suspectConditions group By providerGroupId,programYear record Count {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), modifiedRows);
        List<Integer> batches = jobUtilility.getBatches(modifiedRows);
        log.info("{} QFO modified suspectConditions group By providerGroup,programYear batches offsets are {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), batches.size());
        qfoPerformanceRepository.resetSuspectCountsForProviderGroups(programYear, commonProgramYearCalenderDTO.getDurationValue());
        for (Integer offset: batches) {
            qfoPerformanceRepository.calculateModifiedSuspectConditions(offset, Constants.BATCH_SIZE, programYear, commonProgramYearCalenderDTO);
        }
        log.info("{} QFO Performance - modified suspectConditions sub process completed successfully",ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
        return modifiedRows;
    }

    private long executeAllSuspectsPerformanceDetails(JobEvent jobEvent) {

        log.info("{} QFO Performance - all suspectConditions sub process started",ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
        Integer programYear = jobEvent.getProgramYear();
        Long totalRows = qfoPerformanceRepository.getTotalSuspectConditionsCount(programYear);
        log.info("{} QFO all suspectConditions group By providerGroupId,programYear record Count {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), totalRows);
        List<Integer> batches = jobUtilility.getBatches(totalRows);
        log.info("{} QFO SuspectConditions group By providerGroup,programYear batches offsets are {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), batches.size());
            for (Integer offset: batches) {
            qfoPerformanceRepository.calculateAllSuspectConditions(offset, Constants.BATCH_SIZE, programYear, commonProgramYearCalenderDTO);
        }
        log.info("{} QFO Performance - all suspectConditions sub process completed successfully",ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
        return totalRows;


    }


    private Long executeASRRatings(JobEvent jobEvent) {
        String groupsToExecute = jobEvent.getGroupsToExecute().toString();
        Integer programYear = jobEvent.getProgramYear();

        final Long totalRows = qfoPerformanceRepository.getStarRatingIngestionGroupsRecordCount(groupsToExecute, programYear);
        log.info("{} PAFXMeberAssessment Group By ProviderGroup,State,ProgramYear record Count {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), totalRows);

        List<Integer> batches = jobUtilility.getBatches(totalRows);
        log.info("{} PAFXMeberAssessment Group By ProviderGroup,State,ProgramYear Batches offsets are {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), batches.size());

        Long totalRowsUpdated = 0L;
        for (Integer offset : batches) {

            totalRowsUpdated=totalRowsUpdated+ this.qfoPerformanceRepository
                    .mergeProviderGroupPerformanceDetailsWithASR( Constants.BATCH_SIZE, offset, groupsToExecute, programYear, commonProgramYearCalenderDTO);
        }

        return totalRowsUpdated;
    }

    private Long executeMemberQualityPerformanceDetails(JobEvent jobEvent) {

        String groupsToExecute = jobEvent.getGroupsToExecute().toString();
        Integer programYear = jobEvent.getProgramYear();

        Long totalRows = qfoPerformanceRepository.getProviderGroupMemberQualityRecordCount(groupsToExecute, programYear);
        log.info("QFO Provider Group Member Quality total rows eligible for upsert are {} ", totalRows);

        List<Integer> batches = jobUtilility.getBatches(totalRows);
        log.info("QFO Provider Group Member Quality Batches offsets are {}", batches.size());
        if(!groupsToExecute.equalsIgnoreCase("All") || !groupsToExecute.equalsIgnoreCase(Constants.MONTHLY))
        {
            qfoPerformanceRepository.resetQualityCountsForProviderGroups(programYear, commonProgramYearCalenderDTO.getDurationValue());
        }
        Long rowsUpdated = 0L;
        for (Integer offset : batches) {

            rowsUpdated=rowsUpdated+ this.qfoPerformanceRepository
                    .loadProviderGroupPerformanceQualityDetails( Constants.BATCH_SIZE, offset, groupsToExecute, commonProgramYearCalenderDTO);
        }
        return rowsUpdated;
    }

    private Long loadHealthSystemPerfromanceDetails(JobEvent jobEvent)
    {
        String groupsToExecute = jobEvent.getGroupsToExecute().toString();
        Long totalRows = qfoPerformanceRepository.getHealthSystemRecordCount(groupsToExecute, commonProgramYearCalenderDTO);
        log.info("QFO Provider Group Performance Details total rows eligible for upsert are {} ", totalRows);
        List<Integer> batches = jobUtilility.getBatches(totalRows);
        log.info("QFO Provider Group Performance Details Batches offsets are {}", batches.size());
        Long rowsUpdated = 0L;
        for (Integer offset : batches) {

            rowsUpdated=rowsUpdated+ this.qfoPerformanceRepository
                    .mergeHealthSystemPerfDetails( Constants.BATCH_SIZE, offset, groupsToExecute, commonProgramYearCalenderDTO);
        }
        return rowsUpdated;
    }

    /**
     * This sub process is to update Overall Star Rating,MA-PCPi Star Rating,Part D Star Rating, AcoRating
     * @param jobEvent
     */
    private Long executeStarRatingGlidePath(JobEvent jobEvent) {
        log.info("Started StarRating GlidePath sub process");
        Long firstTimeIngestionCount = qfoPerformanceRepository.getStarRatingGlidePathCount(jobEvent.getProgramYear(), commonProgramYearCalenderDTO.getDurationValue());
        log.info("initial count for Star rating glide path {}",firstTimeIngestionCount);
        Long groupsCount = executeGlidePathSubProcess(jobEvent,"GROUP", firstTimeIngestionCount);
        Long healthSystemCount = executeGlidePathSubProcess(jobEvent,"HEALTHSYSTEM", firstTimeIngestionCount);

        return groupsCount+healthSystemCount;
    }

    private Long executeGlidePathSubProcess(JobEvent jobEvent, String ratingType, Long firstTimeIngestionCount) {
        String groupsToExecute = jobEvent.getGroupsToExecute().toString();
        Integer programYear = jobEvent.getProgramYear();

        boolean isFirstOfMonth = isFirstDayOfMonth();
        Long totalRows = 0l;
        if(isFirstOfMonth || firstTimeIngestionCount == 0){
            totalRows =  qfoPerformanceRepository.getStarRatingGlidePathGroupsRecordCount(groupsToExecute, programYear, false, ratingType);
        }else{
            totalRows =  qfoPerformanceRepository.getStarRatingGlidePathGroupsRecordCount(groupsToExecute, programYear, true, ratingType);
        }
        log.info("{} Qfo Performance Group By ProviderGroup,State,ProgramYear record Count {} RatingType:{}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), totalRows, ratingType);

        List<Integer> batches = jobUtilility.getBatches(totalRows);
        log.info("{} Qfo Performance Group By ProviderGroup,State,ProgramYear Batches offsets are {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), batches.size());
        Long totalRowsUpdated = 0L;
        if(isFirstOfMonth || firstTimeIngestionCount == 0) {
            for (Integer offset : batches) {
                totalRowsUpdated = totalRowsUpdated + this.qfoPerformanceRepository
                        .mergeStarRatingGlidePathWithRatingIngestion(Constants.BATCH_SIZE, offset, groupsToExecute, programYear, commonProgramYearCalenderDTO, false, ratingType);
            }
        }else {
            for (Integer offset : batches) {
                totalRowsUpdated = totalRowsUpdated + this.qfoPerformanceRepository
                        .mergeStarRatingGlidePathWithRatingIngestion(Constants.BATCH_SIZE, offset, groupsToExecute, programYear, commonProgramYearCalenderDTO, true, ratingType);
            }
        }
        log.info("totalRows {}",totalRows);
        return totalRows;
    }

    private boolean isFirstDayOfMonth() {
        Calendar calendar = new GregorianCalendar();
        calendar.setTime(new Date());
        if(calendar.get(Calendar.DAY_OF_MONTH) == 1){
            return true;
        }
        return false;
    }

    private Long publishQfoPerformanceDataToBob(JobEvent jobEvent) {
        Long disabledPreviousMonthRecords = 0l;
        if(jobEvent.getGroupsToExecute().toString().equalsIgnoreCase("Monthly")){
            log.info(" started publishing disabled provider groups into provider sync");
            List<QfoPerformanceData> disabledPreviousMonthList = qfoPerformanceRepository.getPreviousMonthDisabledProvidersData(jobEvent.getProgramYear());
            disabledPreviousMonthRecords = publishDisabledProviderGroups(disabledPreviousMonthList);
            log.info(" Published disabled provider groups into provider sync monthly wise {}", disabledPreviousMonthRecords);

        }

        log.info(" sub process started for publishing the data to bob");
        AtomicInteger updatedRecords = new AtomicInteger();
        final Long totalRows = qfoPerformanceRepository.getQfoPerformanceDataBobSyncCount(jobEvent.getProgramYear(), commonProgramYearCalenderDTO, jobEvent.getGroupsToExecute().toString());
        log.info("QfoPerformance publish record Count {}", totalRows);

        List<Integer> batches = jobUtilility.getBatches(totalRows);
        log.info("QfoPerformance total Batches offsets are {}", batches.size());

        batches.stream().forEach(batchOffset -> {
            int publishPerformanceDetails = sendPublishQfoPerformanceData(Constants.BATCH_SIZE, batchOffset, jobEvent.getProgramYear(),commonProgramYearCalenderDTO.getDurationValue(), jobEvent.getGroupsToExecute().toString());
            updatedRecords.addAndGet(publishPerformanceDetails);
        });
        log.info(" end of qfo publishing sub process");
        return disabledPreviousMonthRecords + totalRows;

    }

    private int sendPublishQfoPerformanceData(int batchSize, Integer batchOffset, Integer programYear, String durationValue, String groupExecute) {

        List<QfoPerformanceData> qfoPerformanceData = qfoPerformanceRepository.getQfoPerformanceDataBobSyncDetails(batchSize, batchOffset,programYear,durationValue, groupExecute);

        ExecutorService executorService = Executors.newFixedThreadPool(producerThreadPoolSize);
        List<Callable<Boolean>> taskList = new ArrayList<>();

        qfoPerformanceData.stream().forEach(qfoPerformanceData1 -> {

            //Publish message to topic
            taskList.add(() -> {
                return producer.postToKafka(buildProviderGroupPerformanceAvroV1(qfoPerformanceData1),(JobName.QFOPERFORMANCE.getValue() + "_" +
                        qfoPerformanceData1.getProviderGroupId() + qfoPerformanceData1.getProgramYear() ));
            });
        });

        log.info("{} Publishing Qfo Performance data to Provider MS  {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), "******* Started ****************");

        // Producing Elements to Topic parallelly
        StopWatch stopWatch = StopWatch.createStarted();
        jobUtilility.producingElementsParallellyToTopic(executorService, taskList);
        stopWatch.stop();
        log.info("Time took for producing messages to kafka in ms is ::" + stopWatch.getTime() + " and  Qfo Performance data Provider MS Service Impl::");

        log.info("{} Published Qfo Performance data to Provider MS records {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), qfoPerformanceData.size());

        return qfoPerformanceData.size();
    }

    private ProgPerfProviderMSSync buildProviderGroupPerformanceAvroV1(QfoPerformanceData qfoPerformance) {
        QfoPerformance qfoPerformance1 = new QfoPerformance();
        qfoPerformance1.setOverallStarRating(qfoPerformance.getOverallStarRating() != null ? qfoPerformance.getOverallStarRating().doubleValue() : null);
        qfoPerformance1.setAcvCompleted(qfoPerformance.getAcvCompleted());
        qfoPerformance1.setConditionsAssessed(qfoPerformance.getConditionsAssessed());
        qfoPerformance1.setMapCpiPartDStarRating(qfoPerformance.getMapCpiPartDStarRating() != null ? qfoPerformance.getMapCpiPartDStarRating().doubleValue() : null);
        qfoPerformance1.setMapCpiStarRating(qfoPerformance.getMapCpiStarRating() != null ? qfoPerformance.getMapCpiStarRating().doubleValue() : null);
        qfoPerformance1.setMapCpiEligiblePatients(qfoPerformance.getMapCpiEligiblePatients());
        qfoPerformance1.setTotalPatients(qfoPerformance.getTotalPatients());
        qfoPerformance1.setMcaipTotalAssessed(qfoPerformance.getMcaipTotalAssessed());
        qfoPerformance1.setTotalSuspectConditions(qfoPerformance.getTotalSuspectConditions());

        ProgPerfProviderMSSync progPerfProviderMSSync = new ProgPerfProviderMSSync();
        progPerfProviderMSSync.setProviderGroupID(qfoPerformance.getProviderGroupId());
        progPerfProviderMSSync.setProgramYear(Integer.parseInt(qfoPerformance.getProgramYear()));
        progPerfProviderMSSync.setProviderGroupName("");
        progPerfProviderMSSync.setState("");
        progPerfProviderMSSync.setQfoPerformance(qfoPerformance1);
        progPerfProviderMSSync.setMessageType(Constants.QFO_PERFORMANCE_MESSAGE_TYPE);

        return progPerfProviderMSSync;
    }

    private long publishDisabledProviderGroups(List<QfoPerformanceData> qfoPerformanceData) {

        ExecutorService executorService = Executors.newFixedThreadPool(producerThreadPoolSize);
        List<Callable<Boolean>> taskList = new ArrayList<>();

        qfoPerformanceData.stream().forEach(qfoPerformanceData1 -> {

            //Publish message to topic
            taskList.add(() -> {
                return producer.postToKafka(buildProviderGroupPerformanceAvroV1(qfoPerformanceData1),(JobName.QFOPERFORMANCE.getValue() + "_" +
                        qfoPerformanceData1.getProviderGroupId() + qfoPerformanceData1.getProgramYear() ));
            });
        });

        log.info("{} Publishing Disabled Provider groups Performance data to Provider MS  {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), "******* Started ****************");

        // Producing Elements to Topic parallelly
        StopWatch stopWatch = StopWatch.createStarted();
        jobUtilility.producingElementsParallellyToTopic(executorService, taskList);
        stopWatch.stop();
        log.info("Time took for producing messages to kafka in ms is ::" + stopWatch.getTime() + " and  Qfo Performance data Provider MS Service Impl::");

        log.info("{} Published  Disabled Provider groups Qfo Performance data to Provider MS records {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), qfoPerformanceData.size());
        return qfoPerformanceData.size();
    }


}