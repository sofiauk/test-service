package com.optum.rqns.ftm.repository.commandcenter;

import java.util.concurrent.Callable;

public interface CommandCenterRepository {
    Long mergeDataFromProgPerfWeeklyToCommandCenter(Integer programYear);
    Long calculateCCPerformance(Integer programYear);
}
