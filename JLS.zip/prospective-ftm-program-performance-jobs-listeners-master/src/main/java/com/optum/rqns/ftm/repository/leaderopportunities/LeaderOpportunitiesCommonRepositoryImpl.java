package com.optum.rqns.ftm.repository.leaderopportunities;

import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Slf4j
@Repository
public class LeaderOpportunitiesCommonRepositoryImpl implements LeaderOpportunitiesCommonRepository {


    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    public LeaderOpportunitiesCommonRepositoryImpl(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
        this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
    }

    private static final String SERVICE_LEVELS_FOR_USER = "SELECT DISTINCT a.ServiceLevel " +
            "from ProgPerf.AccountOwner ao " +
            "join ProgPerf.Accounts a on a.AccountId = ao.AccountId " +
            "where ao.OwnerUUID in( :userId)";


    public static final String LEADER_OPPORTUNITIES_IC_PERFORMANCE_QUERY = "with rs as (SELECT DISTINCT a.GroupId,a.State ,a.ServiceLevel   " +
            " from ProgPerf.AccountOwner ao  with (nolock)  " +
            " join ProgPerf.Accounts a on a.AccountId = ao.AccountId   " +
            " where ao.OwnerUUID in( :OwnerUUID)  " +
            " and a.ServiceLevel = :ServiceLevel" +
            " )  " +
            " Merge ProgPerf.LeaderOpportunitiesDetails as tgt  " +
            " using (  " +
            " SELECT pgod.State, pgod.ClientId , pgod.LobName as lob,   " +
            " pgod.MasterOpportunityType,pgod.OpportunityType,   " +
            "rs.servicelevel,  " +
            " pgod.ProgramYear,  " +
            " sum(pgod.EligibleMemberCount) as TotalPatients,  " +
            " sum(pgod.AssessmentCount) as OpenGaps,  " +
            " ( sum(pgod.EligibleMemberCount)- sum(pgod.AssessmentCount)) as ClosedGaps  " +
            " from ProgPerf.ProvGroupRiskQualityOppDetailsMonthly pgod with (nolock)  " +
            " join rs on  pgod.ProviderGroupID = rs.GroupId and pgod.State = rs.state and pgod.ProgramYear = :ProgramYear  " +
            " WHERE LEN(pgod.State) > 0 and LEN(pgod.LobName)> 0 and LEN(pgod.ClientId)> 0  AND LEN(pgod.ProviderGroupID) > 0 AND pgod.MasterOpportunityType = :MasterOpportunityType   " +
            " AND  pgod.TeamType= :TeamType " +
            " AND pgod.IsCurrentMonth = 1 "+
            " GROUP by pgod.State, pgod.ClientId ,pgod.LobName,rs.servicelevel,pgod.ProgramYear,pgod.MasterOpportunityType,pgod.OpportunityType  " +
            " ) as src  " +
            " on (  " +
            " src.State = tgt.State and  " +
            " src.ClientId = tgt.ClientId and  " +
            " src.Lob = tgt.Lob and  " +
            " src.ServiceLevel = tgt.ServiceLevel and" +
            " src.ProgramYear = tgt.ProgramYear and  " +
            "src.MasterOpportunityType=tgt.MasterOpportunityType AND   " +
            "src.OpportunityType=tgt.OpportunityType AND  " +
            " tgt.UUID = :OwnerUUID AND   " +
            " tgt.Month = (SELECT FORMAT(GETDATE(),'MMM'))"+
            " )   " +
            " when MATCHED THEN   " +
            " update set   " +
            "  tgt.TotalPatients = src.TotalPatients,  " +
            "  tgt.OpenGaps=src.OpenGaps,  " +
            "  tgt.ClosedGaps=src.ClosedGaps,  " +
            "  tgt.UpdatedBy = :UpdatedBy,   " +
            "  tgt.isActive = 1," +
            "  tgt.UpdatedDate = GETUTCDATE()    " +
            "WHEN NOT MATCHED  " +
            "THEN INSERT ( UUID, Region, State, ClientID, ClientName, LOB, ServiceLevel, ProgramYear, [Month], DurationValue, MasterOpportunityType, OpportunityType, MeasureID, TotalPatients, ClosedGaps, OpenGaps, TotalSuspectConditions, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy,IsActive)  " +
            "VALUES (:OwnerUUID, (select  " +
            "   TOP 1 ht.location  " +
            "from  " +
            "   ProgPerf.GeographicalHierarchy gh  " +
            "inner join ProgPerf.GeographicalHierarchy ht on  " +
            "   ht.[Level] = gh.Level.GetAncestor(2)  " +
            "   and gh.LocationType = 'State'  " +
            "   and gh.Location = src.State " +
            " and ht.LocationType ='Region' " +
            " and ht.DeletedDate  is null" +
            " and gh.DeletedDate  is null "+"), src.State, src.ClientID,  (SELECT  TOP 1 ClientName from ProgPerf.ClientConfiguration cc where ClientId = src.ClientID) , src.LOB, src.ServiceLevel, src.ProgramYear, (SELECT FORMAT(GETDATE(),'MMM') AS [Month]), (SELECT CONCAT(FORMAT(GETDATE(),'yyyy'),'_', FORMAT(GETDATE(),'MMM')) AS DurationValue), src.MasterOpportunityType, src.OpportunityType, (  " +
            "Select  " +
            "   measureId  " +
            "from  " +
            "   ProgPerf.OpportunitiesConfigurations oc  " +
            "where  " +
            "   oc.IsActive = 1  and oc.ProgramYear = :ProgramYear " +
            "   and oc.TeamType= :TeamType " +
            "   and oc.OpportunityName = src.OpportunityType), src.TotalPatients, src.ClosedGaps, src.OpenGaps, 0, GETUTCDATE(),:UpdatedBy,GETUTCDATE() ,:UpdatedBy,1);  ";


    public static final String LEADER_OPPORTUNITIES_QUERY = "Merge ProgPerf.LeaderOpportunitiesDetails as tgt   " +
            " using (   " +
            " SELECT lpd.State, lpd.Region, lpd.ClientID , lpd.lob,   " +
            " lpd.servicelevel, lpd.ProgramYear, lpd.DurationValue,   " +
            "lpd .OpportunityType,lpd .MasterOpportunityType ,  " +
            " sum(lpd.TotalPatients) as TotalPatients,   " +
            " sum(lpd.ClosedGaps) as ClosedGaps,   " +
            " sum(lpd.OpenGaps) as OpenGaps    " +
            " from ProgPerf.LeaderOpportunitiesDetails lpd with (nolock)   " +
            " WHERE LEN(lpd.State) > 0 and LEN(lpd.Lob)> 0 and LEN(lpd.DurationValue)> 0  AND LEN(lpd.UUID) > 0 AND len(lpd.region) > 0  AND lpd.MasterOpportunityType =:MasterOpportunityType  " +
            " and lpd.UUID in (:Reporters)   " +
            " and lpd.DurationValue= (SELECT CONCAT(FORMAT(GETDATE(),'yyyy'),'_', FORMAT(GETDATE(),'MMM'))) "+
            " and lpd.ProgramYear=(select mc.value from ProgPerf.MasterConfiguration mc WITH (NOLOCK) where mc.code='CurrentProgramYear') " +
            " GROUP by lpd.State, lpd.Region,lpd.ClientID,lpd.Lob,lpd.servicelevel,lpd.DurationValue, lpd.ProgramYear ,lpd .OpportunityType,lpd .MasterOpportunityType   " +
            " ) as src   " +
            " on (   " +
            " src.Region = tgt.Region and   " +
            " src.State = tgt.State and   " +
            " src.ClientID = tgt.ClientID and   " +
            " src.Lob = tgt.Lob and   " +
            " src.ServiceLevel = tgt.ServiceLevel and" +
            " src.ProgramYear = tgt.ProgramYear and   " +
            " src.DurationValue = tgt.DurationValue and    " +
            " src.MasterOpportunityType=tgt.MasterOpportunityType and  " +
            " src.OpportunityType=tgt.OpportunityType and   " +
            "   " +
            " tgt.UUID = :OwnerUUID  AND " +
            " tgt.Month = (SELECT FORMAT(GETDATE(),'MMM'))"+
            " )    " +
            " when MATCHED THEN    " +
            " update set    " +
            "  tgt.TotalPatients=src.TotalPatients,  " +
            "  tgt.ClosedGaps=src.ClosedGaps,  " +
            "  tgt.OpenGaps=src.OpenGaps,  " +
            "  tgt.UpdatedBy = :UpdatedBy,    " +
            "  tgt.isActive = 1," +
            "  tgt.UpdatedDate = GETUTCDATE()    " +
            " WHEN Not MATCHED THEN   " +
            " INSERT ( UUID, Region, State, ClientID, ClientName, LOB, ServiceLevel, ProgramYear, [Month], DurationValue,  MasterOpportunityType, OpportunityType, MeasureID, TotalPatients, ClosedGaps, OpenGaps, TotalSuspectConditions, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy,IsActive)  " +
            "VALUES (:OwnerUUID, (select  " +
            "   TOP 1 ht.location  " +
            "from  " +
            "   ProgPerf.GeographicalHierarchy gh  " +
            "inner join ProgPerf.GeographicalHierarchy ht on  " +
            "   ht.[Level] = gh.Level.GetAncestor(2)  " +
            "   and gh.LocationType = 'State'  " +
            "   and gh.Location = src.State " +
            " and ht.LocationType ='Region' " +
            " and ht.DeletedDate  is null" +
            " and gh.DeletedDate  is null " +" ), src.State, src.ClientID,  (SELECT  TOP 1 ClientName from ProgPerf.ClientConfiguration cc where ClientId = src.ClientID) , src.LOB, src.ServiceLevel, src.ProgramYear, (SELECT FORMAT(GETDATE(),'MMM') AS [Month]), (SELECT CONCAT(FORMAT(GETDATE(),'yyyy'),'_', FORMAT(GETDATE(),'MMM')) AS DurationValue), src.MasterOpportunityType, src.OpportunityType, NULL, src.TotalPatients, src.ClosedGaps, src.OpenGaps, 0, GETUTCDATE(),:UpdatedBy,GETUTCDATE() ,:UpdatedBy,1);  " +
            "  ";

    private static final String FLAG_IS_ACTIVE_FALSE = "update ProgPerf.LeaderOpportunitiesDetails " +
            " set IsActive = 0,UpdatedBy =:UpdatedBy,UpdatedDate = GETUTCDATE() " +
            " WHERE ProgramYear = :ProgramYear " +
            " and IsActive = 1 " +
            " and MONTH = (SELECT FORMAT(GETDATE(),'MMM') AS [Month]) "+
            " and MasterOpportunityType = :MasterOpportunityType";


    private static final String LEADER_OPPORTUNITIES_IC_SUSPECT_PERFORMANCE_QUERY = " with rs as (SELECT DISTINCT a.GroupId,a.State ,a.ServiceLevel " +
            " from ProgPerf.AccountOwner ao with (nolock) " +
            " join ProgPerf.Accounts a on a.AccountId = ao.AccountId " +
            " where ao.OwnerUUID in( :OwnerUUID) " +
            " and a.ServiceLevel = :ServiceLevel" +
            " )" +
            " Merge ProgPerf.LeaderOpportunitiesDetails as tgt " +
            " using ( " +
            " SELECT pgrqod.State, pgrqod.ClientId , pgrqod.LobName as lob, " +
            " pgrqod.MasterOpportunityType,pgrqod.OpportunityType, " +
            " rs.servicelevel, " +
            " pgrqod.ProgramYear, " +
            " TotalPatients=sum(case when pgrqod.OpportunityType='Suspect Conditions Not Assessed' then 0" +
            " when pgrqod.OpportunityType='Patients Not Fully Assessed' then pgrqod.EligibleMemberCount" +
            " end)," +
            " Opengaps=sum(case when pgrqod.OpportunityType='Suspect Conditions Not Assessed' then pgrqod.GapCount" +
            " when pgrqod.OpportunityType='Patients Not Fully Assessed' then pgrqod.AssessmentCount" +
            " end), " +
            " Closedgaps=sum(case when pgrqod.OpportunityType='Patients Not Fully Assessed' then pgrqod.EligibleMemberCount-pgrqod.AssessmentCount" +
            " when pgrqod.OpportunityType='Suspect Conditions Not Assessed' then pgrqod.TotalGapsCount-pgrqod.GapCount" +
            " end)," +
            " TotalSuspectConditions=sum(case when pgrqod.OpportunityType='Patients Not Fully Assessed' then 0" +
            " when pgrqod.OpportunityType='Suspect Conditions Not Assessed' then pgrqod.TotalGapsCount" +
            " end)" +
            " from ProgPerf.ProvGroupRiskQualityOppDetailsMonthly pgrqod with (nolock) " +
            " join rs on pgrqod.ProviderGroupID = rs.GroupId and pgrqod.State = rs.state and pgrqod.ProgramYear = :ProgramYear " +
            " WHERE LEN(pgrqod.State) > 0 and LEN(pgrqod.LobName)> 0 and LEN(pgrqod.ClientId)> 0 AND LEN(pgrqod.ProviderGroupID) > 0 AND pgrqod.MasterOpportunityType = :MasterOpportunityType " +
            " AND  pgrqod.TeamType= :TeamType " +
            " AND pgrqod.IsCurrentMonth = 1"+
            " GROUP by pgrqod.State, pgrqod.ClientId ,pgrqod.LobName,rs.servicelevel,pgrqod.ProgramYear,pgrqod.MasterOpportunityType,pgrqod.OpportunityType " +
            " ) as src " +
            " on ( " +
            " src.State = tgt.State and " +
            " src.ClientId = tgt.ClientId and " +
            " src.Lob = tgt.Lob and " +
            " src.ServiceLevel = tgt.ServiceLevel and" +
            " src.ProgramYear = tgt.ProgramYear and " +
            " src.MasterOpportunityType=tgt.MasterOpportunityType AND " +
            " src.OpportunityType=tgt.OpportunityType AND " +
            " tgt.UUID = :OwnerUUID AND" +
            " tgt.Month = (SELECT FORMAT(GETDATE(),'MMM'))"+
            " )" +
            " when MATCHED THEN " +
            " update set " +
            " tgt.TotalPatients = src.TotalPatients, " +
            " tgt.OpenGaps=src.OpenGaps, " +
            " tgt.ClosedGaps=src.ClosedGaps," +
            " tgt.TotalSuspectConditions=src.TotalSuspectConditions, " +
            " tgt.UpdatedBy = :UpdatedBy, " +
            " tgt.isActive = 1," +
            " tgt.UpdatedDate = GETUTCDATE()" +
            " WHEN NOT MATCHED " +
            " THEN INSERT ( UUID, Region, State, ClientID, ClientName, LOB, ServiceLevel, ProgramYear, [Month], DurationValue, MasterOpportunityType, OpportunityType, MeasureID, TotalPatients, ClosedGaps, OpenGaps, TotalSuspectConditions, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy,IsActive) " +
            " VALUES (:OwnerUUID, (select " +
            " TOP 1 ht.location " +
            " from " +
            " ProgPerf.GeographicalHierarchy gh " +
            " inner join ProgPerf.GeographicalHierarchy ht on " +
            " ht.[Level] = gh.Level.GetAncestor(2) " +
            " and gh.LocationType = 'State' " +
            " and gh.Location = src.State "+
            " and ht.LocationType ='Region' " +
            " and ht.DeletedDate  is null" +
            " and gh.DeletedDate  is null "+
            "), src.State, src.ClientID, (SELECT TOP 1 ClientName from ProgPerf.ClientConfiguration cc where ClientId = src.ClientID) , src.LOB, src.ServiceLevel, src.ProgramYear, (SELECT FORMAT(GETDATE(),'MMM') AS [Month]), (SELECT CONCAT(FORMAT(GETDATE(),'yyyy'),'_', FORMAT(GETDATE(),'MMM')) AS DurationValue), src.MasterOpportunityType, src.OpportunityType, " +
            " NULL, " +
            " src.TotalPatients, src.ClosedGaps, src.OpenGaps, src.TotalSuspectConditions," +
            " GETUTCDATE(),:UpdatedBy,GETUTCDATE() ,:UpdatedBy,1);";

    public static final String LEADER_SUSPECT_OPPORTUNITIES_QUERY = " Merge ProgPerf.LeaderOpportunitiesDetails as tgt " +
            " using ( " +
            " SELECT lpd.State, lpd.Region, lpd.ClientID , lpd.lob, " +
            " lpd.servicelevel, lpd.ProgramYear, lpd.DurationValue, " +
            " lpd .OpportunityType,lpd .MasterOpportunityType , " +
            " sum(lpd.TotalPatients) as TotalPatients, " +
            " sum(lpd.ClosedGaps) as ClosedGaps, " +
            " sum(lpd.OpenGaps) as OpenGaps," +
            " sum(lpd.TotalSuspectConditions) as TotalSuspectConditions " +
            " from ProgPerf.LeaderOpportunitiesDetails lpd with (nolock) " +
            " WHERE LEN(lpd.State) > 0 and LEN(lpd.Lob)> 0 and LEN(lpd.DurationValue)> 0 AND LEN(lpd.UUID) > 0 AND len(lpd.region) > 0 AND lpd.MasterOpportunityType =:MasterOpportunityType " +
            " and lpd.UUID in (:Reporters) " +
            " and lpd.DurationValue= (SELECT CONCAT(FORMAT(GETDATE(),'yyyy'),'_', FORMAT(GETDATE(),'MMM'))) "+
            " and lpd.ProgramYear=(select mc.value from ProgPerf.MasterConfiguration mc WITH (NOLOCK) where mc.code='CurrentProgramYear') " +
            " GROUP by lpd.State, lpd.Region,lpd.ClientID,lpd.Lob,lpd.servicelevel,lpd.DurationValue, lpd.ProgramYear ,lpd .OpportunityType,lpd .MasterOpportunityType " +
            " ) as src " +
            " on ( " +
            " src.Region = tgt.Region and " +
            " src.State = tgt.State and " +
            " src.ClientID = tgt.ClientID and " +
            " src.Lob = tgt.Lob and " +
            " src.ServiceLevel = tgt.ServiceLevel and" +
            " src.ProgramYear = tgt.ProgramYear and " +
            " src.DurationValue = tgt.DurationValue and " +
            " src.MasterOpportunityType=tgt.MasterOpportunityType and " +
            " src.OpportunityType=tgt.OpportunityType and " +
            " tgt.UUID = :OwnerUUID  AND " +
            " tgt.Month = (SELECT FORMAT(GETDATE(),'MMM'))"+
            " ) " +
            " when MATCHED THEN " +
            " update set " +
            " tgt.TotalPatients=src.TotalPatients, " +
            " tgt.ClosedGaps=src.ClosedGaps, " +
            " tgt.OpenGaps=src.OpenGaps," +
            " tgt.TotalSuspectConditions=src.TotalSuspectConditions," +
            " tgt.UpdatedBy = :UpdatedBy, " +
            " tgt.isActive = 1," +
            " tgt.UpdatedDate = GETUTCDATE() " +
            " WHEN Not MATCHED THEN " +
            " INSERT ( UUID, Region, State, ClientID, ClientName, LOB, ServiceLevel, ProgramYear, [Month], DurationValue, MasterOpportunityType, OpportunityType, MeasureID, TotalPatients, ClosedGaps, OpenGaps, TotalSuspectConditions, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy,IsActive) " +
            " VALUES (:OwnerUUID, (select " +
            " TOP 1 ht.location " +
            " from " +
            " ProgPerf.GeographicalHierarchy gh " +
            " inner join ProgPerf.GeographicalHierarchy ht on " +
            " ht.[Level] = gh.Level.GetAncestor(2) " +
            " and gh.LocationType = 'State' " +
            " and gh.Location = src.State "+ " and ht.LocationType ='Region' " +
            " and ht.DeletedDate  is null" +
            " and gh.DeletedDate  is null "+
            " ), src.State, src.ClientID," +
            " (SELECT TOP 1 ClientName from ProgPerf.ClientConfiguration cc where ClientId = src.ClientID) ," +
            " src.LOB, src.ServiceLevel, src.ProgramYear, (SELECT FORMAT(GETDATE(),'MMM') AS [Month]), " +
            " (SELECT CONCAT(FORMAT(GETDATE(),'yyyy'),'_', FORMAT(GETDATE(),'MMM')) AS DurationValue), " +
            " src.MasterOpportunityType, src.OpportunityType, NULL, src.TotalPatients, src.ClosedGaps, src.OpenGaps, src.TotalSuspectConditions, GETUTCDATE(),:UpdatedBy,GETUTCDATE() ,:UpdatedBy,1); " +
            " ";


    @Override
    public List<String> getServiceLevelForUser(String userID) {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put(Constants.USER_ID, userID);
        return namedParameterJdbcTemplate.queryForList(SERVICE_LEVELS_FOR_USER, paramMap, String.class);
    }

    @Override
    public int calculateICQualityGapsAndACVOppData(String ic, String serviceLevel, String masterOpportunityType, int programYear,String jobName) {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put(Constants.OWNER_UUID, ic);
        paramMap.put(Constants.SERVICE_LEVEL, serviceLevel);
        paramMap.put(Constants.MASTER_OPPORTUNITY_TYPE, masterOpportunityType);
        paramMap.put(Constants.PROGRAM_YEAR, programYear);
        paramMap.put(Constants.UPDATED_BY, jobName);
        paramMap.put(Constants.TEAM_TYPE,Constants.PPT);
        return namedParameterJdbcTemplate.update(LEADER_OPPORTUNITIES_IC_PERFORMANCE_QUERY, paramMap);
    }

    @Override
    public int calculateLeaderCommonOppData(String leader, List<String> totalReporters, String masterOpportunityType,String jobName) {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put(Constants.OWNER_UUID, leader);
        paramMap.put(Constants.MASTER_OPPORTUNITY_TYPE, masterOpportunityType);
        paramMap.put(Constants.REPORTERS, Objects.isNull(totalReporters) ? "" : totalReporters);
        paramMap.put(Constants.UPDATED_BY,jobName);
        return namedParameterJdbcTemplate.update(LEADER_OPPORTUNITIES_QUERY, paramMap);
    }

    @Override
    public int calculateICSuspectOppData(String ic, String serviceLevel, String MasterOpportunityType, int programYear) {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put(Constants.OWNER_UUID, ic);
        paramMap.put(Constants.SERVICE_LEVEL, serviceLevel);
        paramMap.put(Constants.MASTER_OPPORTUNITY_TYPE, MasterOpportunityType);
        paramMap.put(Constants.PROGRAM_YEAR, programYear);
        paramMap.put(Constants.UPDATED_BY, JobName.LEADER_SUSPECT_OPPORTUNITIES.getValue());
        paramMap.put(Constants.TEAM_TYPE,Constants.PPT);
        return namedParameterJdbcTemplate.update(LEADER_OPPORTUNITIES_IC_SUSPECT_PERFORMANCE_QUERY, paramMap);
    }

    @Override
    public int calculateLeaderSuspectOppData(String leader, List<String> totalReporters, String masterOpportunityType) {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put(Constants.OWNER_UUID, leader);
        paramMap.put(Constants.MASTER_OPPORTUNITY_TYPE, masterOpportunityType);
        paramMap.put(Constants.REPORTERS, Objects.isNull(totalReporters) ? "" : totalReporters);
        paramMap.put(Constants.UPDATED_BY, JobName.LEADER_SUSPECT_OPPORTUNITIES.getValue());
        return namedParameterJdbcTemplate.update(LEADER_SUSPECT_OPPORTUNITIES_QUERY, paramMap);
    }

    @Override
    public Integer flagIsActiveFalseLeaderOpportunities(JobEvent jobEvent,String masterOpportunityType) {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put(Constants.PROGRAM_YEAR, jobEvent.getProgramYear());
        paramMap.put(Constants.UPDATED_BY, jobEvent.getJobName());
        paramMap.put(Constants.MASTER_OPPORTUNITY_TYPE, masterOpportunityType);
        return namedParameterJdbcTemplate.update(FLAG_IS_ACTIVE_FALSE, paramMap);
    }
}

