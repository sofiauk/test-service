package com.optum.rqns.ftm.service.fieldactionrules;

import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.model.fieldactionrules.RuleAction;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.List;
import java.util.Map;

/**
 * Command pattern implementation class
 */
@Slf4j
@Service
public class RuleCommandImpl {

    public static final String INVALID_RULE_TYPE = "Invalid rule type: ";
    private  final Map<String, RuleCommand> rules;

    @Autowired
    ThresholdServiceImpl thresholdService;

    RuleCommandImpl() {
        rules = Map.ofEntries(
                Map.entry(JobName.THRESHOLD_RULE.getValue(), (inputData, jobName) -> thresholdService.execute(inputData)),
                Map.entry(JobName.REJECT_AGING_JOB.getValue(), (inputData, jobName) -> thresholdService.invokeDMRuleRestAPIList(inputData,jobName)),
                Map.entry(JobName.NEW_PROVIDER_MANUAL_ASSOCIATION_JOB.getValue(), (inputData, jobName) -> thresholdService.invokeDMRuleRestAPIList(inputData,jobName)),
                Map.entry(JobName.RUN_CHANGE_SERVICE_LEVEL_RULE.getValue(), (inputData, jobName) -> thresholdService.invokeDMRuleRestAPIList(inputData,jobName)),
                Map.entry(JobName.AVAIL_MEMBERSHIP_CLIENT_LOB_STATE_RULE.getValue(), (inputData, jobName) -> thresholdService.invokeDMRuleRestAPIList(inputData,jobName)),
                Map.entry(JobName.RUN_NEW_PROVIDER_GROUP_MEMBERSHIP.getValue(), (inputData, jobName) -> thresholdService.invokeDMRuleRestAPIList(inputData,jobName)),
                Map.entry(JobName.RETURN_METRIC_JOB.getValue(), (inputData, jobName) -> thresholdService.invokeDMRuleRestAPIList(inputData,jobName)));
    }

    protected List<RuleAction> executeRuleInWorkbench(List<RuleAction> inputData, String jobName) {
        RuleCommand command = rules.get(jobName);

        if (command == null) {
            throw new IllegalArgumentException(INVALID_RULE_TYPE + jobName);
        }

        return command.get(inputData,jobName);
    }
}
