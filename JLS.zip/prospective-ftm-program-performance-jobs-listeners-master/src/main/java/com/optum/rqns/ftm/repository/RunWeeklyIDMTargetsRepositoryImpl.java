package com.optum.rqns.ftm.repository;

import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.concurrent.Callable;

@Repository
@Slf4j
public class RunWeeklyIDMTargetsRepositoryImpl implements RunWeeklyIDMTargetsRepository {
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    private final String DATA_MERGE_QUERY = "MERGE  progperf.[ProviderGroupPerformanceWeekly] AS tgt             " +
            "            using        (  " +
            "    SELECT " +
            " cgp.groupid providergroupid, " +
            " cc.ClientName clientname, " +
            " cgp.state state, " +
            " (case when cgp.lobdesc = 'MEDICARE' then 'Medicare' when cgp.lobdesc = 'MEDICAID' then 'Medicaid' when  cgp.lobdesc = 'COMMERCIAL' then 'Commercial' else '' end ) lobname, " +
            " ( " +
            " CASE " +
            "  WHEN ( cgp.groupid IS NULL) " +
            "  OR ( cgp.client IS NULL) " +
            "  OR ( cgp.state IS NULL) " +
            "  OR ( cgp.lobdesc IS NULL) THEN 0 " +
            "  ELSE 1 " +
            " END ) isidmtarget, " +
            " cast(Sum(cgp.projecteddeployments) as decimal(23, 3)) deployyetarget , " +
            " cast(Sum(cgp.projectedreturns) as decimal(23, 3)) returnyetarget, " +
            " cast(Sum(cgp.projecteddeployments * gpd.weeklydeploymentpercent) as decimal(23, 3)) deployytdtarget , " +
            " cast(Sum(cgp.projectedreturns * gpd.weeklyreturnpercent) as decimal(23, 3)) returnytdtarget , " +
            " pyc.durationvalue durationvalue, " +
            " pyc.programyear programyear, " +
            " pyc.startdate durationstartdate, " +
            " pyc.enddate durationenddate, " +
            " cast(gpd.weeklydeploymentpercent as decimal(23, 3)) DeployYTDTargetPercent, " +
            " cast(gpd.weeklyreturnpercent as decimal(23, 3)) ReturnYTDTargetPercent FROM " +
            " progperf.clientgoalspublished cgp with (nolock) " +
            "inner join progperf.ClientConfiguration cc with (nolock) on " +
            " cgp.Client = cc.ClientId " +
            "FULL JOIN progperf.glidepathpercentageidm gpd with (nolock) ON " +
            " 1 = 1 " +
            "INNER JOIN progperf.programyearcalendar pyc with (nolock) ON " +
            " gpd.durationvalue = pyc.durationvalue " +
            " and gpd.programyear = pyc.programyear " +
            " WHERE  ( ( pyc.startdate <= cast(Getutcdate() as date) AND pyc.enddate >= cast(Getutcdate() as date))    " +
            " OR  pyc.startdate >= cast(Getutcdate() as date))    " +
            " AND pyc.durationtype = 'week'   " +
            " AND pyc.programYear = :PROGRAMYEAR   " +
            " And cgp.programYear = pyc.programYear  " +
            " And  cgp.groupid != 'All'   " +
            " And  cgp.state != 'All'   " +
            " And  cgp.regionname != 'All'   " +
            " And  cgp.groupname != 'All' " +
            "GROUP BY " +
            " cgp.groupid, " +
            " cgp.client, " +
            " cc.ClientName , " +
            " cgp.state, " +
            " cgp.lobdesc, " +
            " pyc.durationvalue, " +
            " gpd.weeklydeploymentpercent, " +
            " gpd.weeklyreturnpercent, " +
            " pyc.programyear, " +
            " pyc.startdate , " +
            " pyc.enddate" +
            "     ORDER BY   cgp.groupid offset :OFFSET rows FETCH next :BatchSize rows only ) AS src  " +
            "            ON (  " +
            "       tgt.providergroupid = src.providergroupid  " +
            "      AND          tgt.[STATE] = src.[STATE]  " +
            "      AND          tgt.clientname = src.clientname  " +
            "      AND          tgt.lobname = src.lobname  " +
            "      AND          tgt.programyear = src.programyear  " +
            "      AND          tgt.durationvalue = src.durationvalue )  " +
            "            WHEN matched THEN UPDATE  " +
            "            set    " +
            "          tgt.durationstartdate = src.durationstartdate ,  " +
            "          tgt.durationenddate = src.durationenddate ,  " +
            "          tgt.deployyetarget = src.deployyetarget ,  " +
            "          tgt.returnyetarget = src.returnyetarget ,  " +
            "          tgt.deployytdtarget = src.deployytdtarget ,  " +
            "          tgt.returnytdtarget = src.returnytdtarget ,     " +
            "          tgt.DeployYTDTargetPercent = src.DeployYTDTargetPercent ,     " +
            "          tgt.ReturnYTDTargetPercent = src.ReturnYTDTargetPercent,      " +
            "          tgt.isidmtarget = src.isidmtarget ,  " +
            "          tgt.updateddate = getutcdate() ,  " +
            "          tgt.updatedby = 'RunWeeklyIdmTargets',  " +
            "          tgt.ServiceLevel = 'All' " +
            "            WHEN NOT matched THEN INSERT  " +
            "       (  " +
            "       providergroupid ,  " +
            "       [STATE] ,  " +
            "       clientname ,  " +
            "       lobname ,  " +
            "       programyear ,  " +
            "       durationvalue ,  " +
            "       durationstartdate ,  " +
            "       durationenddate ,  " +
            "       isidmtarget ,  " +
            "       deployyetarget ,  " +
            "       returnyetarget ,  " +
            "       deployytdtarget ,  " +
            "       returnytdtarget ,  " +
            "       DeployYTDTargetPercent ,    " +
            "       ReturnYTDTargetPercent ,          " +
            "       createddate ,  " +
            "       updateddate ,  " +
            "       createdby ,  " +
            "       updatedby, ServiceLevel  " +
            "       )  " +
            "       VALUES  " +
            "       (  " +
            "       src.providergroupid ,  " +
            "       src.[STATE] ,  " +
            "       src.clientname ,  " +
            "       src.lobname ,  " +
            "       src.programyear ,  " +
            "       src.durationvalue ,  " +
            "       src.durationstartdate ,  " +
            "       src.durationenddate ,  " +
            "       src.isidmtarget ,  " +
            "       src.deployyetarget ,  " +
            "       src.returnyetarget ,  " +
            "       src.deployytdtarget ,  " +
            "       src.returnytdtarget ,  " +
            "       src.DeployYTDTargetPercent ,    " +
            "       src.ReturnYTDTargetPercent , " +
            "       getutcdate() ,  " +
            "       getutcdate() ,  " +
            "       'RunWeeklyIdmTargets' ,  " +
            "       'RunWeeklyIdmTargets', 'All'  " +
            "       );";


    private final String COUNT_QUERY = "select count(src.providergroupid) as datacount from ( SELECT     cgp.groupid providergroupid, " +
            "    cgp.client  clientname, " +
            "    cgp.state   state, " +
            "    cgp.lobdesc lobname, " +
            "    pyc.durationvalue   durationvalue, " +
            "    pyc.programyear     programyear, " +
            "    pyc.startdate       durationstartdate, " +
            "    pyc.enddate         durationenddate, " +
            "    gpd.weeklydeploymentpercent  DeployYTDTargetPercent, " +
            "    gpd.weeklyreturnpercent      ReturnYTDTargetPercent  " +
            "     " +
            "     FROM       progperf.clientgoalspublished cgp " +
            "     FULL JOIN  progperf.glidepathpercentageidm gpd " +
            "     ON         1=1 " +
            "     INNER JOIN progperf.programyearcalendar pyc " +
            "     ON         gpd.durationvalue = pyc.durationvalue and gpd.programyear = pyc.programyear " +
            "     WHERE  ( ( pyc.startdate <= cast(Getutcdate() as date) AND pyc.enddate >= cast(Getutcdate() as date))    " +
            " OR  pyc.startdate >= cast(Getutcdate() as date))    " +
            " AND pyc.durationtype = 'week'   " +
            " AND pyc.programYear = :PROGRAMYEAR   " +
            " And  cgp.groupid != 'All'   " +
            " And  cgp.state != 'All'   " +
            " And  cgp.regionname != 'All'   " +
            " And  cgp.groupname != 'All'   " +
            "     GROUP BY   cgp.groupid, " +
            "    cgp.client, " +
            "    cgp.state, " +
            "    gpd.weeklydeploymentpercent,  " +
            "    gpd.weeklyreturnpercent,  " +
            "    cgp.lobdesc, " +
            "    pyc.durationvalue, " +
            "    pyc.programyear, " +
            "    pyc.startdate , " +
            "    pyc.enddate) as src";

    public RunWeeklyIDMTargetsRepositoryImpl(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
        this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
    }


    @Override
    public Long getRecordCount(Integer programYear) {
        HashMap<String,Object> params =  new HashMap<>();
        params.put("PROGRAMYEAR",programYear);
        return namedParameterJdbcTemplate.queryForObject(COUNT_QUERY, params, Long.class);
    }

    @Override
    public Callable<Integer> mergeData(int batchSize, Integer batchOffset, Integer programYear) {
        SqlParameterSource sqlParameterSource = new MapSqlParameterSource("BatchSize", batchSize)
                .addValue("OFFSET", batchOffset)
                .addValue("PROGRAMYEAR",programYear);
        log.info("batchsize {} offset {}", batchSize, batchOffset);

        return () -> this.namedParameterJdbcTemplate
                .update(DATA_MERGE_QUERY, sqlParameterSource);
    }
}
