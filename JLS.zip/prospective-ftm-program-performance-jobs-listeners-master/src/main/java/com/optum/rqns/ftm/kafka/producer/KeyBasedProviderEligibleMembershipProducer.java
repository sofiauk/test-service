package com.optum.rqns.ftm.kafka.producer;

import com.optum.rqns.ftm.kafka.avro.models.v1.program.performance.provider.ProgPerfProviderMSSync;
import com.optum.rqns.ftm.kafka.avro.models.v1.program.performance.provider.membership.ProviderEligibleMembership;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.common.KafkaException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaProducerException;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Component;
import org.springframework.util.concurrent.ListenableFuture;


@Component
@Slf4j
public class KeyBasedProviderEligibleMembershipProducer {

    // bean name was added to differentiate the bean from membergaps opportunities common library
    @Autowired
    @Qualifier("providerEligibleMembershipKafkaTemplate")
    private KafkaTemplate<String, ProviderEligibleMembership> kafkaTemplate;

    @Value("${spring.gcpkafka.properties.topics.providerEligibleMembershipSync}")
    public String topicName;


    public boolean postToKafka(ProviderEligibleMembership message, String key) {

        try {
            ListenableFuture<SendResult<String, ProviderEligibleMembership>> result = kafkaTemplate.send(topicName, key, message);
            kafkaTemplate.flush();
            log.info("Key based Message sent successfully for ************** [ProviderGroupID,State,ProgramYear]  = {},{},{},{}", message.getProviderGroupId(), message.getProviderState(),
                    message.getProgramYear(), result.isDone());
            return result.isDone();
        } catch (KafkaProducerException ex) {
            log.error("KafkaProducerException occured while sending message to kafka topic for keyBased {}", ex.getMessage());
        } catch (KafkaException ex) {
            log.error("KafkaException occured while sending message to kafka topic for keyBased {}", ex.getMessage());
        } catch (Exception ex) {
            log.error("Exception occured while sending message to kafka topic for keyBased {}", ex.getMessage());
        }

        return false;
    }


}
