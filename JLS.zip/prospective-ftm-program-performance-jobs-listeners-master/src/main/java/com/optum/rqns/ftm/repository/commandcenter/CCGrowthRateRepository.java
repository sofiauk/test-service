package com.optum.rqns.ftm.repository.commandcenter;

public interface CCGrowthRateRepository {
    int updateAgreedStatusByIPEFlag(Integer programYear);

    int updateAgreedStatusByDeployActual(Integer programYear);

    int updateEngagedStatusByDeployActual(Integer programYear);

    int flagAgreedAndEngagedTo0(Integer programYear);

    int updateMOMGrowthRateTable(Integer programYear);
}
