package com.optum.rqns.ftm.service.providergroup;

import com.fasterxml.uuid.Generators;
import com.google.common.collect.Lists;
import com.optum.rqns.ftm.constants.CommonConstants;
import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.avro.models.v1.program.performance.provider.NewProviderGroup;
import com.optum.rqns.ftm.kafka.avro.models.v1.program.performance.provider.ProgPerfProviderMSSync;
import com.optum.rqns.ftm.kafka.producer.JobEventProducer;
import com.optum.rqns.ftm.kafka.producer.KeyBasedProviderSyncProducer;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.model.providergroup.MemberAssessmentHistory;
import com.optum.rqns.ftm.model.providergroup.ProviderGroup;
import com.optum.rqns.ftm.repository.providergroup.NewProviderGroupRuleRepository;
import com.optum.rqns.ftm.util.ProgramPerformanceJobUtil;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.StopWatch;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@Slf4j
public class NewProviderGroupRulesServiceImpl implements NewProviderGroupRulesService {

    private NewProviderGroupRuleRepository newProviderGroupRuleRepository;

    @Autowired
    private KeyBasedProviderSyncProducer producer;

    @Autowired
    private JobEventProducer jobEventProducer;

    @Value("${new_providergroup_rule_producer_thread_pool_size}")
    private int producerThreadPoolSize;

    public NewProviderGroupRulesServiceImpl(NewProviderGroupRuleRepository newProviderGroupRuleRepository) {
        this.newProviderGroupRuleRepository = newProviderGroupRuleRepository;
    }

    public JobStatus executeJob(JobEvent jobEvent) {

        MDC.put(Constants.TRACE_ID, Generators.timeBasedGenerator().generate().toString());
        MDC.put(Constants.TRANSACTION_ID, ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
        MDC.put(Constants.MESSAGE_ID, ProgramPerformanceJobUtil.TransactionIdLogger.getMessageIdIdentifier());

        log.info("{} jobEvent.NewProviderGroupRule() :: {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), jobEvent.getJobName());
        try {
            if(Constants.ALL.equalsIgnoreCase(jobEvent.getGroupsToExecute().toString())) {
                return executeRuleWithAll(jobEvent);
            } else {
                return executeWithRuleWithModify(jobEvent);
            }
        }
        finally {
            //TODO -- Commented ClientGoals from here and added in DB repository -- Once everything works we can remove
            //Weekly process add HsClientGoals After New ProviderGroup rule
            /*if(Constants.ALL.equalsIgnoreCase(jobEvent.getGroupsToExecute().toString())) {
                triggerHasClientGoalsProducerProviderMS(jobEvent);
            }*/
            MDC.clear();
        }
    }

    /**
     * Trigger HasClientGoals Producer in Weekly After New ProviderGroup Rule - both jobs runs in same profile one after other
     * @param jobEvent
     */
    /*private void triggerHasClientGoalsProducerProviderMS(JobEvent jobEvent) {
        log.info("Entering into triggerHasClientGoalsProducerProviderMS() : {}", jobEvent.getJobName());
        //Weekly Integration After IDM Merge call RUN_PAFX_MEMBER_DEPLOYMENT_UPDATES

        log.info("Send triggerHasClientGoalsProducerProviderMS Message : {}", JobName.RUN_CLIENT_GOALS);
        JobEvent runClientGoalsProducer = JobEvent.newBuilder()
                .setJobName(JobName.RUN_CLIENT_GOALS.getValue())
                .setGroupsToExecute(jobEvent.getGroupsToExecute().toString())
                .setExecutionWeek(jobEvent.getExecutionWeek().toString())
                .setStatus(Status.SUCCESS.getValue())
                .setProgramYear(jobEvent.getProgramYear())
                .setCascadeEvents(jobEvent.getCascadeEvents())
                .setTimeStamp(Instant.now()).build();
        jobEventProducer.postToKafka(runClientGoalsProducer);

        log.info("Completed triggerHasClientGoalsProducerProviderMS trigger process : {}", jobEvent.getJobName());
    }*/

    /**
     * Execute Rule with Modify
     * @param jobEvent
     * @return
     */
    private JobStatus executeWithRuleWithModify(JobEvent jobEvent) {
        log.info("{} Inside Run Job with Modify", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());

        JobStatus jobStatus = new JobStatus();

        /**Update the IsEligibleGroupForPOC Flag for modified providerGroups in MemberAssessment Table
         1. Get the batches based on no.of records
         2. Update the flag batchwise */
        int updatedRecordsForIsEligiblePOC=0;
        for(Integer batchOffSet : fetchBatches(1000)){
            updatedRecordsForIsEligiblePOC+=newProviderGroupRuleRepository.updateIsGroupEligiblePOC(false,jobEvent.getProgramYear(),batchOffSet,1000);
        }
        log.info(" Completed the EligibleGroupForPOC Flag, Total Updated Groups Count{}",updatedRecordsForIsEligiblePOC);


        /**
         * 1. Read data from MemberAssessmentHistory LastSuccessfulRunDate to current
         * 2. Get ProviderGroups based on MemberAssessmentHistory
         * 3. Execute the Rule
         * 4. Publish message to Provider MS
         * 5. Update in DB
         * 6. Add job chaining
         */
        try{
            AtomicInteger updatedRecords = new AtomicInteger();

            final CustomJobInput customJobInput = getCustomJobInput(jobEvent);
            Integer programYear = jobEvent.getProgramYear();

            final Long totalRows = newProviderGroupRuleRepository.getMemberAssessmentHistoryDetailsBasedOnLastJobRunDateRecordCount(programYear);
            log.info("{} MemberAssessmentHistory Last Successful Job record Count {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), totalRows);

            if(totalRows == 0){
                log.info("{} No New Provider Groups available in MemberAssessmentHistory with JobLastSuccessfulRunDate ", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
                jobStatus.setStatus(Status.SUCCESS);
                jobStatus.setMessage("Completed RunNewProviderGroupRule Modify job successfully and No new ProviderGroups available");
                jobStatus.setUpdatedRows(updatedRecords.longValue());
            } else {

                log.info("{} New Provider Groups available in MemberAssessmentHistory with JobLastSuccessfulRunDate ", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());

                List<Integer> batches = getBatches(totalRows);
                log.info("{} ProviderGroupExtended Batches offsets are {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), batches.size());

                for (Integer offset : batches) {

                    List<MemberAssessmentHistory> memberAssessmentProviderGroups = newProviderGroupRuleRepository.getMemberAssessmentHistoryProviderGroupsBasedOnLastRunDate(Constants.NEW_PROVIDER_GROUP_RULE_BATCH_SIZE, offset, programYear);
                    String providerGroupIds = memberAssessmentProviderGroups.stream().map(m -> ("'" + m.getProvGroupId()) + "'").collect(Collectors.joining(","));

                    List<ProviderGroup> providerGroups = newProviderGroupRuleRepository.getProviderGroupDetailsBasedOnProviderGroups(providerGroupIds, programYear, customJobInput.isExecuteForNewGroups());
                    int updatedProviderGroupExtendedRecords = updateIsNewProviderGroup(providerGroups, providerGroupIds, jobEvent.getGroupsToExecute().toString(), programYear, customJobInput.isExecuteForNewGroups());
                    updatedRecords.addAndGet(updatedProviderGroupExtendedRecords);

                    memberAssessmentProviderGroups.clear();
                    providerGroups.clear();
                }

                log.info("{} Completed New Provider Group Rules for Modify processing Updated Rows {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), updatedRecords.longValue());
                jobStatus.setStatus(Status.SUCCESS);
                jobStatus.setMessage("Completed RunNewProviderGroupRule Modify job successfully");
                jobStatus.setUpdatedRows(updatedRecords.longValue());
            }

            //Run Command Center Aggregate POC Conversion Update Queries
            int ccpUpdateCount=newProviderGroupRuleRepository.updateCommandCenterPerformanceAggregates(programYear);
            log.info(" Updated Counts in Command Center Performance Aggregates  Table {}",ccpUpdateCount);

        } catch(Exception e){
            log.error("Exception while executing with Modify NewProviderGroupRule job : {}", e);

            jobStatus.setStatus(Status.FAILURE);
            jobStatus.setMessage("RunNewProviderGroupRule job execution failed : " + e.getMessage());
            jobStatus.setUpdatedRows(0L);
        }
        return jobStatus;
    }

    /**
     * Execute Rule With All
     * @param jobEvent
     * @return
     */
    private JobStatus executeRuleWithAll(JobEvent jobEvent) {
        log.info("{} Inside Run Job with All", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());

        JobStatus jobStatus = new JobStatus();
        try{

            /**Update the IsEligibleGroupForPOC Flag for modified providerGroups in MemberAssessment Table
             1. Get the batches based on no.of records
             2. Update the flag batchwise
             3. Get the counts for new and existing groups for POC conversion and update in the Command Center Performance aggregates table*/
            int updatedRecordsForIsEligiblePOC=0;
            for(Integer batchOffSet : fetchBatches(1000)){
                updatedRecordsForIsEligiblePOC+=newProviderGroupRuleRepository.updateIsGroupEligiblePOC(true,jobEvent.getProgramYear(),batchOffSet,1000);
            }
            log.info(" Completed the EligibleGroupForPOC Flag, Total Updated Groups Count {}",updatedRecordsForIsEligiblePOC);

            /**
             * 1. Get ProviderGroups from DB
             * 2. Get ProviderGroupIds from List
             * 3. Get MemberAssessmentHistory data from DB
             * 4. Apply
             * 5. If the Provider Group/State combination has not returned at least one assessment  with a PAFMASTER OVERALL_STATUS = [Complete} the previous program year
             * 6. AND
             * 7. Provider Group/State Combination has at least one program eligible member for the current program year
             * 8. Then Update
             */

            final CustomJobInput customJobInput = getCustomJobInput(jobEvent);
            Integer programYear = jobEvent.getProgramYear();
            AtomicInteger updatedRecords = new AtomicInteger();

            //If isExecuteForNewGroups - true then executes for IsNewForPOC =1 OR IsNewForDeployment=1
            if(customJobInput.isExecuteForNewGroups()){

                List<String> isNewProviderGroups = newProviderGroupRuleRepository.getProviderGroupDetailsForNewGroups(programYear);
                log.info(" IsExecuteForNewGroups - true, Total Groups Count {}",isNewProviderGroups.size());
                List<List<String>> batches = Lists.partition(isNewProviderGroups, Constants.NEW_PROVIDER_GROUP_RULE_BATCH_SIZE);
                batches.stream().forEach(providerGroups -> {

                    String providerGroupIds = providerGroups.stream().map(m -> ("'" + m) + "'").collect(Collectors.joining(","));

                    List<ProviderGroup> providerGroupDetails = newProviderGroupRuleRepository.getProviderGroupDetailsBasedOnGroupIds(programYear, providerGroupIds);

                    updatedRecords.addAndGet(providerGroupDetails.size());

                    updateIsNewProviderGroup(providerGroupDetails, providerGroupDetails.stream().map(m ->("'" + m.getProviderGroupId()) + "'").collect(Collectors.joining(",")), jobEvent.getGroupsToExecute().toString(), programYear, customJobInput.isExecuteForNewGroups());

                });

                //clearObjects
                if(batches != null) {
                    log.info(" {} total  batch size {} ", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), batches.size());
                    for(int counter = 0; counter < batches.size(); counter++) {
                        if(batches.get(counter) != null) {
                            batches.get(counter).clear();
                        }
                    }
                }
                isNewProviderGroups.clear();

            } else {
                runJobForAllGroups(customJobInput, programYear, updatedRecords, jobEvent);
            }

            log.info("{} Completed New Provider Group Rules for All processing Updated Rows {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), updatedRecords.longValue());

            //Run Command Center Aggregate POC Conversion Update Queries
            int ccpUpdateCount=newProviderGroupRuleRepository.updateCommandCenterPerformanceAggregates(programYear);
            log.info(" Updated Counts in Command Center Performance Aggregates  Table {}",ccpUpdateCount);

            jobStatus.setStatus(Status.SUCCESS);
            jobStatus.setMessage("Completed RunNewProviderGroupRule job successfully");
            jobStatus.setUpdatedRows(updatedRecords.longValue());
        } catch(Exception e){
            log.error("Exception while executing with All NewProviderGroupRule job : {}", e);

            jobStatus.setStatus(Status.FAILURE);
            jobStatus.setMessage("RunNewProviderGroupRule job execution failed : " + e.getMessage());
            jobStatus.setUpdatedRows(0L);
        }

        return jobStatus;
    }

    /**
     * isExecuteForNewGroups -- false then execute for all groups
     * @param customJobInput
     * @param programYear
     * @param updatedRecords
     * @param jobEvent
     */
    private void runJobForAllGroups(CustomJobInput customJobInput, Integer programYear, AtomicInteger updatedRecords, JobEvent jobEvent) {

        final Long totalRows = newProviderGroupRuleRepository.getProviderGroupsRecordCount(customJobInput.isExecuteForNewGroups(), programYear);
        log.info("{} Execute Job for All Groups - isExecuteForNewGroups - false - ProviderGroupExtended record Count {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), totalRows);

        List<Integer> batches = getBatches(totalRows);
        log.info("{} ProviderGroupExtended Batches offsets are {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), batches.size());

        for (Integer offset : batches) {

            List<ProviderGroup> providerGroupDetails = newProviderGroupRuleRepository.getProviderGroupDetailsByOffset(Constants.NEW_PROVIDER_GROUP_RULE_BATCH_SIZE, offset, customJobInput.isExecuteForNewGroups(), programYear);

            updatedRecords.addAndGet(providerGroupDetails.size());

            updateIsNewProviderGroup(providerGroupDetails, providerGroupDetails.stream().map(m ->("'" + m.getProviderGroupId()) + "'").collect(Collectors.joining(",")), jobEvent.getGroupsToExecute().toString(), programYear, customJobInput.isExecuteForNewGroups());
        }
    }

    @Data
    @AllArgsConstructor
    private static class CustomJobInput {
        private boolean executeForNewGroups;
    }

    /**
     * Get Custom JobInput
     * @param jobEvent
     * @return
     */
    private CustomJobInput getCustomJobInput(JobEvent jobEvent) {

        final CustomJobInput customJobInput = new CustomJobInput(false);
        if (StringUtils.isNoneEmpty(jobEvent.getJobInput())) {

            CustomJobInput customJobInputActual = (CustomJobInput) ProgramPerformanceJobUtil.jsonToPojo(getJobInput(jobEvent), CustomJobInput.class);
            customJobInput.setExecuteForNewGroups(customJobInputActual.isExecuteForNewGroups());
            log.info(" ExecuteForNewGroups -- New ProviderGroup Rule -- jobInputClass get value is {}", customJobInput.isExecuteForNewGroups());
        }

        return customJobInput;
    }

    /**
     * Get JobInput from JobEvent
     * @param jobEvent
     * @return
     */
    private String getJobInput(JobEvent jobEvent) {

        return jobEvent.getJobInput() == null ? "{\"executeForNewGroups\": true}"  : jobEvent.getJobInput().toString();
    }

    private List<Integer> getBatches(Long totalRows) {
        List<Integer> batches = new ArrayList<>();
        if (totalRows > 0) {
            for (int batchOffset = 0; batchOffset < totalRows; batchOffset += Constants.NEW_PROVIDER_GROUP_RULE_BATCH_SIZE) {
                batches.add(batchOffset);
            }
        }
        return batches;
    }


    /**
     * Update isNewForDeployment and Publish to Provider MS
     * @param providerGroups
     * @param providerGroupIds
     * @param groupsToExecute
     * @param programYear
     * @param executeForNewGroups
     * @return
     */
    private int updateIsNewProviderGroup(List<ProviderGroup> providerGroups, String providerGroupIds, String groupsToExecute, Integer programYear, boolean executeForNewGroups) {

        log.info("{} Executing NewProviderGroupRules Job {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), providerGroups.size());

        List<MemberAssessmentHistory> memberAssessmentHistoryList = new ArrayList<>();
        if(Constants.ALL.equalsIgnoreCase(groupsToExecute)) {
            memberAssessmentHistoryList = newProviderGroupRuleRepository.getMemberAssessmentHistoryDetails(providerGroupIds, programYear);
        } else {
            memberAssessmentHistoryList = newProviderGroupRuleRepository.getMemberAssessmentHistoryDetailsBasedOnLastJobRunDateRecordsByOffset(providerGroupIds, programYear);
        }
        log.info("{} Received member assessment history with providergroupIds {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), memberAssessmentHistoryList.size());

        List<Map<String, Object>> batchValues = new ArrayList<>();

        //Get ProviderGroupId + State based map - No record in MemberAssementHistory for GroupId + State the isNew true
        //Get ProviderGroupId + State based map with overall_status is 'complete', deriveddeployed=1 and returned=1 --> IsNewForDeployment
        Map<String, List<MemberAssessmentHistory>> memberAssessmentHistoryMap = memberAssessmentHistoryList.stream()
                .filter(x ->((Constants.COMPLETE.equalsIgnoreCase(x.getOverallStatus())
                        &&(Constants.ONE.equalsIgnoreCase(x.getDerivedDeployed()))
                        &&(Constants.ONE.equalsIgnoreCase(x.getReturned())))))
                .collect(Collectors.groupingBy(p ->(p.getProvGroupId() + p.getProviderState()),
                        Collectors.mapping(Function.identity(), Collectors.toList())));

        log.info("{} IsNewForDeployment DerivedDeployed=1, Returned=1 And  OverallStatus is Complete records {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), memberAssessmentHistoryMap.size());


        //Get ProviderGroupId + State based map with deriveddeployed=1  for isNewForDeploymentPOC
        Map<String, List<MemberAssessmentHistory>> memberAssessmentHistoryMapForIsNewForPOC = memberAssessmentHistoryList.stream()
                .filter(x ->(Constants.ONE.equalsIgnoreCase(x.getDerivedDeployed())))
                .collect(Collectors.groupingBy(p ->(p.getProvGroupId() + p.getProviderState()),
                        Collectors.mapping(Function.identity(), Collectors.toList())));
        log.info("{} IsNewForPOC DerivedDeployed=1 records {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), memberAssessmentHistoryMap.size());

        //For parallel producing
        ExecutorService executorService = Executors.newFixedThreadPool(producerThreadPoolSize);
        List<Callable<Boolean>> taskList = new ArrayList<>();

        providerGroups.stream().forEach(providerGroup -> {

            executeIsNewForDeployment(providerGroup, memberAssessmentHistoryMap, executeForNewGroups);
            executeIsNewForDeploymentPOC(providerGroup, memberAssessmentHistoryMapForIsNewForPOC, executeForNewGroups);

            //Publish message to topic
            taskList.add(() -> {
                return producer.postToKafka(buildProviderGroupOpportunitiesSummaryAvroV1(providerGroup, providerGroup.getNewForDeployment()),(JobName.RUN_NEW_PROVIDER_GROUP_RULES.getValue() + "_" + providerGroup.getProviderGroupId() + providerGroup.getState()));
            });

            Map<String, Object> paramMap = new HashMap<>();
            paramMap.put("ProgramYear",providerGroup.getProgramYear());
            paramMap.put("ProviderGroupId",providerGroup.getProviderGroupId());
            paramMap.put("State",providerGroup.getState());
            paramMap.put("IsNewForDeployment",providerGroup.getNewForDeployment());
            paramMap.put("IsNewForPOC",providerGroup.getNewForPOC());
            paramMap.put("UpdatedBy","NewProviderGroupRulesJob");
            batchValues.add(paramMap);

        });

        log.info("{} Publishing messages to Provider MS  {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), "******* Started ****************");
        // Producing Elements to Topic parallelly
        StopWatch stopWatch = StopWatch.createStarted();
        producingElementsParallellyToTopic(executorService, taskList);
        stopWatch.stop();
        log.info("Time took for producing messages to kafka in ms is ::" + stopWatch.getTime() + " and rule is New Provider GroupRules Service Impl::");
        log.info("{} Publishing messages to Provider MS  {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), "******* Completed ****************");

        log.info("{} Updating ProviderGroup & ProviderGroupExtended records {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), batchValues.size());

        int[] updatedProviderGroupExtendedRecords = newProviderGroupRuleRepository.updateBatchQueries(batchValues);
        log.info("{} Updated ProviderGroupExtended records {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), updatedProviderGroupExtendedRecords.length);

        memberAssessmentHistoryMap.clear();
        memberAssessmentHistoryMapForIsNewForPOC.clear();
        memberAssessmentHistoryList.clear();
        batchValues.clear();
        return updatedProviderGroupExtendedRecords.length;
    }

    /**
     * Execute IsNewForDeploymentPOC rule
     * @param providerGroup
     * @param memberAssessmentHistoryMapForIsNewForPOC
     * @param executeForNewGroups
     */
    private void executeIsNewForDeploymentPOC(ProviderGroup providerGroup, Map<String, List<MemberAssessmentHistory>> memberAssessmentHistoryMapForIsNewForPOC, boolean executeForNewGroups) {

        //If executeForNewGroups - true and isNewForPOC - then dont calculate logic
        if(executeForNewGroups && (providerGroup.getNewForPOC() != null && !providerGroup.getNewForPOC())){
            providerGroup.setNewForPOC(false);
        } else {
            /**
             * If the Provider Group/State combination has at least 1 member in PAFmaster with [derived deployed] = 1  ( in the previous program year)
             * THEN Label Provider Group/State combination as "Existing Group", else label Provider Group/State combination as "New Group"
             */

            if (memberAssessmentHistoryMapForIsNewForPOC.containsKey(providerGroup.getProviderGroupId() + providerGroup.getState())) {
                providerGroup.setNewForPOC(false);
            } else {
                providerGroup.setNewForPOC(true);
            }
        }
    }

    /**
     * Execute IsNewForDeployment rule
     * @param providerGroup
     * @param memberAssessmentHistoryMap
     * @param executeForNewGroups
     */
    private void executeIsNewForDeployment(ProviderGroup providerGroup, Map<String, List<MemberAssessmentHistory>> memberAssessmentHistoryMap, boolean executeForNewGroups) {

        //If executeForNewGroups - true and isNewForDeployment - then dont calculate logic
        if(executeForNewGroups && (providerGroup.getNewForDeployment() != null && !providerGroup.getNewForDeployment())){
            providerGroup.setNewForDeployment(false);
        } else {
            /**
             * If record Not exists with ProviderGroupId and State then isNew True
             * If the Provider Group/State combination has at least 1 member in PAFmaster with [derived deployed] = 1 and [returned] = 1 and [overall_status] = complete(in the previous program year)
             * THEN
             * Label Provider Group/State combination as "Existing Group", else label Provider Group/State combination as "New Group"
             */
            if (memberAssessmentHistoryMap.containsKey(providerGroup.getProviderGroupId() + providerGroup.getState())) {
                providerGroup.setNewForDeployment(false);
            } else {
                providerGroup.setNewForDeployment(true);
            }
        }
    }

    /*
     *  To produce the messages parallelly to kafka ,this method is written
     * @param executorService,taskList
     * @return boolean
     */
    private Boolean producingElementsParallellyToTopic(ExecutorService executorService, List<Callable<Boolean>> taskList) {
        boolean iselementsProc = true;
        try {
            List<Future<Boolean>> results = executorService.invokeAll(taskList);
            for(Future<Boolean> f : results) {
                if(f != null && f.get()) {

                } else {
                    log.warn(" Future object not able to fetch::");
                }
            }

        } catch(Exception e) {
            iselementsProc = false;
            log.error("Error while  producing the elements Parallelly " + e);
        } finally {
            taskList.clear();
            executorService.shutdown();
        }
        return iselementsProc;
    }


    private ProgPerfProviderMSSync buildProviderGroupOpportunitiesSummaryAvroV1(ProviderGroup providerGroup, boolean isNewForDeployment) {
        NewProviderGroup newProviderGroup = new NewProviderGroup();
        newProviderGroup.setIsNewForDeployment(isNewForDeployment);

        ProgPerfProviderMSSync summaryAvroMessage = new ProgPerfProviderMSSync();
        summaryAvroMessage.setProviderGroupID(providerGroup.getProviderGroupId());
        summaryAvroMessage.setProviderGroupName(CommonConstants.DEFAULE_STRING_VALUE);
        summaryAvroMessage.setState(providerGroup.getState());
        summaryAvroMessage.setProgramYear(providerGroup.getProgramYear());
        summaryAvroMessage.setNewProviderGroup(newProviderGroup);
        summaryAvroMessage.setMessageType(CommonConstants.NEW_PROVIDER_GROUP_RULE);

        return summaryAvroMessage;
    }

    private List<Integer> fetchBatches(int batchsize) {
        log.info("Inside Fetch  Batching offset: transactionID :{},batchsize:{}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(),batchsize);
        return newProviderGroupRuleRepository.getRowCountforIsEligiblePOClist(batchsize);
    }
}