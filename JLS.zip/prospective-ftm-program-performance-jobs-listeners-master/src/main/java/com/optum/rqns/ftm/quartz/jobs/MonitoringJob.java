package com.optum.rqns.ftm.quartz.jobs;

import com.optum.rqns.ftm.service.jobalerts.MonitoringJobService;
import lombok.extern.slf4j.Slf4j;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Profile("rqnsFtmJobs")
@Slf4j
@Component
@DisallowConcurrentExecution
public class MonitoringJob implements Job {

    @Autowired
    private MonitoringJobService monitoringJobService;

    /**
     * Execute method will invoke with Cron Job
     */
    @Override
    public void execute(JobExecutionContext context) {
        log.info("Job {}  starting @ {}", context.getJobDetail().getKey().getName(), context.getFireTime());

        try {
            monitoringJobService.monitorJobs();
            log.info("Successfully monitored the jobs");
        } catch (Exception e) {
            log.error("Job Monitoring is Failed  Job ** {} ** starting @ {}  with Exception ## {} ",
                    context.getJobDetail().getKey().getName(), context.getFireTime(), e);

        }
    }

}
