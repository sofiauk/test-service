package com.optum.rqns.ftm.model.providergroup;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PAFXMemberData {
    private String providerGroupId;
    private String providerState;
    private int programYear;
    private String eligibleProgType;/*
    private String clientId;
    private String lobName;
    private String globalMemberId;*/
}