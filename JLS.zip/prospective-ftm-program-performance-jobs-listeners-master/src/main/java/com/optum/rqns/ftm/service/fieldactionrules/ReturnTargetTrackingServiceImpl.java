package com.optum.rqns.ftm.service.fieldactionrules;

import com.google.gson.Gson;
import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.RuleEnum;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.exception.FieldActionRulesException;
import com.optum.rqns.ftm.kafka.avro.models.v1.fieldactionrule.Action;
import com.optum.rqns.ftm.kafka.avro.models.v1.fieldactionrule.FieldActionRuleMetadata;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.producer.JobEventProducer;
import com.optum.rqns.ftm.kafka.producer.KeyBasedFieldActionRuleProducer;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.model.fieldactionrules.ReturnTargetTrackingAction;
import com.optum.rqns.ftm.model.fieldactionrules.RuleAction;
import com.optum.rqns.ftm.repository.fieldactionrules.ReturnTargetTrackingRepoImpl;
import com.optum.rqns.ftm.util.FieldActionRulesUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Service
@Slf4j
public class ReturnTargetTrackingServiceImpl extends FieldActionRuleService {


    @Autowired
    private ReturnTargetTrackingRepoImpl returnTargetTrackingRepoImpl;

    public ReturnTargetTrackingServiceImpl() {

        setBatchingRequired(false);
    }

    @Override
    public List<RuleAction> fetchRuleData(Integer beginIndex, int batchSize,boolean isbatchingrequireed) {
        return returnTargetTrackingRepoImpl.fetchReturnTargetInfo();
    }


    @Override
    public String getRuleResult(RuleAction ruleAction) {

        Map<String,Object> resultMap=new HashMap<>();
        Gson gson=new Gson();
        if(ruleAction instanceof ReturnTargetTrackingAction){
            ReturnTargetTrackingAction returnTargetTrackingRuleAction=(ReturnTargetTrackingAction) ruleAction;
            resultMap.put(Constants.RETURN_TARGET,returnTargetTrackingRuleAction.getReturnTarget());
            resultMap.put(Constants.RETURN_CNA,returnTargetTrackingRuleAction.getReturnCNA());
        }

        return gson.toJson(resultMap);
    }

    @Override
    public List<RuleAction> filterRuleActions(List<RuleAction> ruleActions) {
        return ruleActions;
    }

}
