package com.optum.rqns.ftm.service;

import com.fasterxml.uuid.Generators;
import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.enums.GroupsToExecute;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.producer.KeyBasedProviderSyncProducer;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.repository.PAFxMemberDeploymentUpdatesRepository;
import com.optum.rqns.ftm.repository.common.CommonRepository;
import com.optum.rqns.ftm.util.ProgramPerformanceJobUtil;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;
import java.util.stream.Collectors;

@Service
@Slf4j
public class PAFxMemberDeploymentUpdatesServiceImpl implements PAFxMemberDeploymentUpdatesService {

    private static final String COMMA_SPACE = ", ";
    private PAFxMemberDeploymentUpdatesRepository pafxMemberDeploymentUpdatesRepository;
    private CommonRepository commonRepository;
    private static final int BATCH_SIZE = 25000;

    @Value("${new_providergroup_rule_producer_thread_pool_size}")
    private int producerThreadPoolSize;

    @Autowired
    private KeyBasedProviderSyncProducer producer;

    public PAFxMemberDeploymentUpdatesServiceImpl(PAFxMemberDeploymentUpdatesRepository pafxMemberDeploymentUpdatesRepository,CommonRepository commonRepository) {
        this.pafxMemberDeploymentUpdatesRepository = pafxMemberDeploymentUpdatesRepository;
        this.commonRepository= commonRepository;
    }
    private final int thresholdcountforfullrun= 500000;
    public JobStatus executeJob(JobEvent jobEvent) {

        MDC.put(Constants.TRACE_ID, Generators.timeBasedGenerator().generate().toString());
        MDC.put(Constants.TRANSACTION_ID, ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
        MDC.put(Constants.MESSAGE_ID, ProgramPerformanceJobUtil.TransactionIdLogger.getMessageIdIdentifier());


        log.info("{} jobEvent.PAFxMemberDeploymentUpdate() :: {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), jobEvent.getJobName());
        JobStatus jobStatus = new JobStatus();

        String joblastrunsuccessfuldate =  commonRepository.getJobsLastRunSuccessfulDate(jobEvent.getJobName().toString());

        try {
            log.info("{} Received PAFxMemberDeploymentUpdate message from topic : {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), jobEvent.getJobName());

            final Long totalRows = this.pafxMemberDeploymentUpdatesRepository.getRecordCount(jobEvent.getProgramYear());
            log.info("{} PAFXMemberAssessment record Count {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), totalRows);

            Long totalRowsUpdated = 0l;

            if(jobEvent.getGroupsToExecute().toString().equalsIgnoreCase(GroupsToExecute.MODIFIED.getValue())){
                totalRowsUpdated = this.pafxMemberDeploymentUpdatesRepository.getRecordCountModified(jobEvent.getProgramYear(),joblastrunsuccessfuldate);
                log.info("{} PAFXMemberAssessment totalRowsUpdated record Count {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), totalRowsUpdated);
            }

            boolean isfulldatarun = totalRowsUpdated>thresholdcountforfullrun?true:false;

            if(jobEvent.getGroupsToExecute().toString().equalsIgnoreCase(GroupsToExecute.ALL.getValue()) || isfulldatarun) {
                List<Integer> batches = getBatches(totalRows);
                log.info("{} ALL PAFXMemberAssessment total Batches offsets are {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), batches.size());
                for (Integer offset : batches) {
                    totalRowsUpdated=totalRowsUpdated+ this.pafxMemberDeploymentUpdatesRepository
                            .mergePAFXMemberData(BATCH_SIZE,offset,jobEvent);
                }

            }else{
                List<Integer> batches = getBatches(totalRowsUpdated);
                log.info("{} Modifed PAFXMemberAssessment total Batches offsets are {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), batches.size());
                for (Integer offset : batches) {
                    log.info("mergePAFXMemberData  Modified batchsize {} offset {}", BATCH_SIZE, offset);
                    List<Integer> ids = pafxMemberDeploymentUpdatesRepository.getListOfModifiedIdFromPafx(BATCH_SIZE, offset,jobEvent.getProgramYear(),joblastrunsuccessfuldate);
                    String idsList = ids.stream().map(m -> ("'" + m) + "'").collect(Collectors.joining(","));
                     pafxMemberDeploymentUpdatesRepository.mergeModifiedData(idsList);
                }
            }

            log.info("{} PAFXMember Deployment Updates completed and total updated record count {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), totalRowsUpdated);


            //Generate final message and update in JobRunconfiguration
            String message = "Completed PAFxMemberDeploymentUpdates job successfully. "
                    + "Updated records in PAFXMemberAssessment: "+totalRowsUpdated;

            jobStatus.setStatus(Status.SUCCESS);
            jobStatus.setMessage(message);
            jobStatus.setUpdatedRows(totalRowsUpdated);

        } catch (Exception e) {
            log.error("{} Exception while executing PAFxMemberDeploymentUpdate job : {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), e);
            jobStatus.setStatus(Status.FAILURE);
            jobStatus.setMessage("PAFxMemberDeploymentUpdate job execution failed : " + e.getMessage());
            jobStatus.setUpdatedRows(0L);
        } finally{
            MDC.clear();
        }
        return jobStatus;
    }



    private List<Integer> getBatches(Long totalRows) {
        List<Integer> batches = new ArrayList<>();
        if (totalRows > 0) {
            for (int batchOffset = 0; batchOffset <= totalRows; batchOffset += BATCH_SIZE) {
                batches.add(batchOffset);
            }
        }
        return batches;
    }


}
