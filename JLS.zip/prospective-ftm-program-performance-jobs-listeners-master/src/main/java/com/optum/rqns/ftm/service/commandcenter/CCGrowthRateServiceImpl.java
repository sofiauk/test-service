package com.optum.rqns.ftm.service.commandcenter;

import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.repository.commandcenter.CCGrowthRateRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class CCGrowthRateServiceImpl implements CCGrowthRateService {

    private static final String NEW_LINE = "\n";


    @Autowired
    private CCGrowthRateRepository ccGrowthRateRepository;

    @Override
    public JobStatus executeJob(JobEvent jobEvent) {
        JobStatus jobStatus = new JobStatus();

        //1. Update GrowthRateStatusFlag
        updateGrowthRateStatusFlag(jobEvent, jobStatus);

        //2. calculate MOMData
        calculateMOMData(jobEvent, jobStatus);

        jobStatus.setStatus(Status.SUCCESS);
        return jobStatus;
    }

    private void updateGrowthRateStatusFlag(JobEvent jobEvent, JobStatus jobStatus) {

        StringBuilder stringBuilder = new StringBuilder();

        //0. To reset all flags
        final int flagResetCount = ccGrowthRateRepository.flagAgreedAndEngagedTo0(jobEvent.getProgramYear());
        stringBuilder
                .append("Flag Reset Count :")
                .append(flagResetCount)
                .append(NEW_LINE);


        //1. Update GrowthRateStatus as Agreed by IPE Flag
        int updateAgreedRowCountFromIPEFlag = ccGrowthRateRepository.updateAgreedStatusByIPEFlag(jobEvent.getProgramYear());

        //2. Update GrowthRateStatus as Agreed by DeployYtdActual
        int updateAgreedRowCountFromActual = ccGrowthRateRepository.updateAgreedStatusByDeployActual(jobEvent.getProgramYear());

        //3. Update GrowthRateStatus as Engaged by DeployYtdActual and returnRate
        int updateEngagedRowCount = ccGrowthRateRepository.updateEngagedStatusByDeployActual(jobEvent.getProgramYear());


        stringBuilder
                .append("Agreed GrowthRateStatus record updated count by IPE Flag :")
                .append(updateAgreedRowCountFromIPEFlag)
                .append(NEW_LINE)
                .append("Agreed GrowthRateStatus record updated count by DeployYtdActual :")
                .append(updateAgreedRowCountFromActual)
                .append(NEW_LINE)
                .append("Engaged GrowthRateStatus record updated count byDeployYtdActual :")
                .append(updateEngagedRowCount)
                .append(NEW_LINE)
        ;

        jobStatus.setMessage(stringBuilder.toString());
        jobStatus.setUpdatedRows((long) flagResetCount + updateAgreedRowCountFromIPEFlag + updateAgreedRowCountFromActual + updateEngagedRowCount);
    }


    private void calculateMOMData(JobEvent jobEvent, JobStatus jobStatus) {
        StringBuilder stringBuilder = new StringBuilder();

        int momDataUpdatedCount = ccGrowthRateRepository.updateMOMGrowthRateTable(jobEvent.getProgramYear());

        stringBuilder
                .append(jobStatus.getMessage())
                .append("Calculated AgreedYTD, EngageDYTD, TotalProviderGroups, AgreedYTD%, EngagedYTD %, Updated Count:")
                .append(momDataUpdatedCount)
        ;

        jobStatus.setMessage(stringBuilder.toString());
        jobStatus.setUpdatedRows(jobStatus.getUpdatedRows() + momDataUpdatedCount);
    }

}
