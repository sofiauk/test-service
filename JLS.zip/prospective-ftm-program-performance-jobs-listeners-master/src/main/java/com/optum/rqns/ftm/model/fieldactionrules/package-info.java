package com.optum.rqns.ftm.model.fieldactionrules;

/*
    This package consists of data model objects for work queue rules

 */