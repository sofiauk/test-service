package com.optum.rqns.ftm.kafka.consumer.redis;

import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.kafka.consumer.*;
import com.optum.rqns.ftm.kafka.consumer.commandcenter.CCGrowthRateConsumer;
import com.optum.rqns.ftm.kafka.consumer.commandcenter.CommandCenterConsumer;
import com.optum.rqns.ftm.kafka.consumer.fieldactionrules.*;
import com.optum.rqns.ftm.kafka.consumer.landingpage.EModalityConsumer;
import com.optum.rqns.ftm.kafka.consumer.leaderOpportunities.LeaderACVOppurtunitiesConsumer;
import com.optum.rqns.ftm.kafka.consumer.leaderOpportunities.LeaderQualityGapsOpportunitiesConsumer;
import com.optum.rqns.ftm.kafka.consumer.leaderOpportunities.LeaderSuspectConditionsOppurtunitiesConsumer;
import com.optum.rqns.ftm.kafka.consumer.opamigration.RunOpaMigrationConsumer;
import com.optum.rqns.ftm.kafka.consumer.opportunities.AnnualCareOpportunitiesConsumer;
import com.optum.rqns.ftm.kafka.consumer.opportunities.QualityGapsOpportunitiesConsumer;
import com.optum.rqns.ftm.kafka.consumer.opportunities.SuspectConditionsOpportunitiesConsumer;
import com.optum.rqns.ftm.kafka.consumer.opportunities.qfo.QFOAnnualCareOpportunitiesConsumer;
import com.optum.rqns.ftm.kafka.consumer.opportunities.qfo.QFOQualityGapsOpportunitiesConsumer;
import com.optum.rqns.ftm.kafka.consumer.opportunities.qfo.QFOSuspectConditionsOpportunitiesConsumer;
import com.optum.rqns.ftm.kafka.consumer.practiceassist.*;
import com.optum.rqns.ftm.kafka.consumer.qfo.QFOPatientExperienceScoreConsumer;
import com.optum.rqns.ftm.kafka.consumer.qfo.QFOPerformanceConsumer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class RedisConsumerFactory  {
    @Autowired(required = false)
    CommandCenterConsumer commandCenterConsumer;
    @Autowired(required = false)
    CCGrowthRateConsumer ccGrowthRateConsumer;
    @Autowired(required = false)
    EModalityConsumer eModalityConsumer;
    @Autowired(required = false)
    IDMGlidePathConsumer idmGlidePathConsumer;
    @Autowired(required = false)
    LeaderPerformanceConsumer leaderPerformanceConsumer;
    @Autowired(required = false)
    LeaderPerformanceHistoricalConsumer leaderPerformanceHistoricalConsumer;
    @Autowired(required = false)
    RunWeeklyIDMTargets runWeeklyIDMTargets;

    //fieldActionRules
    @Autowired(required = false)
    AvailMemberShipClientLobStateConsumer availMemberShipClientLobStateConsumer;
    @Autowired(required = false)
    ChangeServiceLevelRuleConsumer changeServiceLevelRuleConsumer;
    @Autowired(required = false)
    NewProviderGroupMembershipConsumer newProviderGroupMembershipConsumer;
    @Autowired(required = false)
    NewProviderManualAssociationConsumer newProviderManualAssociationConsumer;
    @Autowired(required = false)
    RejectAgingConsumer rejectAgingConsumer;
    @Autowired(required = false)
    ReturnTargetTrackingConsumer returnTargetTrackingConsumer;

    //memberGapJobs
    @Autowired(required = false)
    LeaderACVOppurtunitiesConsumer leaderACVOppurtunitiesConsumer;
    @Autowired(required = false)
    LeaderQualityGapsOpportunitiesConsumer leaderQualityGapsOpportunitiesConsumer;
    @Autowired(required = false)
    LeaderSuspectConditionsOppurtunitiesConsumer leaderSuspectConditionsOppurtunitiesConsumer;

    //opaMigrationJobs
    @Autowired(required = false)
    RunOpaMigrationConsumer runOpaMigrationConsumer;

    //memberGapJobs
    @Autowired(required = false)
    QFOAnnualCareOpportunitiesConsumer qfoAnnualCareOpportunitiesConsumer;
    @Autowired(required = false)
    QFOQualityGapsOpportunitiesConsumer qfoQualityGapsOpportunitiesConsumer;
    @Autowired(required = false)
    QFOSuspectConditionsOpportunitiesConsumer qfoSuspectConditionsOpportunitiesConsumer;
    @Autowired(required = false)
    AnnualCareOpportunitiesConsumer annualCareOpportunitiesConsumer;
    @Autowired(required = false)
    QualityGapsOpportunitiesConsumer qualityGapsOpportunitiesConsumer;
    @Autowired(required = false)
    SuspectConditionsOpportunitiesConsumer suspectConditionsOpportunitiesConsumer;

    //paLandingPageJobs
    @Autowired(required = false)
    HospitalEventsAggregationConsumer hospitalEventsAggregationConsumer;
    @Autowired(required = false)
    MbrMedAdherenceAggregationConsumer mbrMedAdherenceAggregationConsumer;
    @Autowired(required = false)
    MemberSummaryAggregationConsumer memberSummaryAggregationConsumer;
    @Autowired(required = false)
    QualityAggregationConsumer qualityAggregationConsumer;
    @Autowired(required = false)
    SuspectAggregationConsumer suspectAggregationConsumer;

    //memberGapJobs
    @Autowired(required = false)
    QFOPatientExperienceScoreConsumer qfoPatientExperienceScoreConsumer;
    @Autowired(required = false)
    QFOPerformanceConsumer qfoPerformanceConsumer;
    //newProviderGroupRule
    @Autowired(required = false)
    ClientGoalsConsumer clientGoalsConsumer;
    //pafxDeployUpdate
    @Autowired(required = false)
    CPGEligibleProgramTypeUpdatesConsumer cpgEligibleProgramTypeUpdatesConsumer;
    //newProviderGroupRule
    @Autowired(required = false)
    NewProviderGroupRulesConsumer newProviderGroupRulesConsumer;
    @Autowired(required = false)
    PAFxMemberDeploymentUpdatesConsumer paFxMemberDeploymentUpdatesConsumer;
    @Autowired(required = false)
    ProviderEligibleMembershipConsumer providerEligibleMembershipConsumer;

    public RedisMessageHandler getInstance(JobName jobName){
        switch (jobName) {
            case RUN_COMMAND_CENTER:
                return commandCenterConsumer;
            case RUN_CC_GROWTH_RATE:
                return ccGrowthRateConsumer;
            case RUN_WEEKLY_EMODALITY_LOAD:
                return eModalityConsumer;
            case IDM_GLIDEPATH:
                return idmGlidePathConsumer;
            case LEADER_PERFORMANCE:
                return leaderPerformanceConsumer;
            case MONITORING_JOB:
                return leaderPerformanceHistoricalConsumer;
            case RUN_WEEKLY_IDM_TARGETS:
                return runWeeklyIDMTargets;
            case RUN_PROVIDER_ELIGIBLE_MEMBERSHIP:
                return providerEligibleMembershipConsumer;
            case RUN_NEW_PROVIDER_GROUP_RULES:
                return newProviderGroupRulesConsumer;
            case RUN_CPG_ELIGIBLEPROGRAMTYPE_UPDATES:
                return cpgEligibleProgramTypeUpdatesConsumer;
            case RUN_CLIENT_GOALS:
                return clientGoalsConsumer;
            case RUN_PAFX_MEMBER_DEPLOYMENT_UPDATES:
                return paFxMemberDeploymentUpdatesConsumer;
            case QFOPERFORMANCE:
                return qfoPerformanceConsumer;
            case QFO_PATIENT_EXPERIENCE_SCORES:
                return qfoPatientExperienceScoreConsumer;
            case RUN_SUSPECT_AGGREGATION:
                return suspectAggregationConsumer;
            case RUN_QUALITY_AGGREGATION:
                return qualityAggregationConsumer;

            case RUN_MEMBER_SUMMARY_AGGREGATION:
                return memberSummaryAggregationConsumer;

            case RUN_MED_ADHERENCE_AGGREGATION:
                return mbrMedAdherenceAggregationConsumer;
            case RUN_MEMBER_HOSPITAL_EVENTS_AGGREGATION:
                return hospitalEventsAggregationConsumer;
            case SUSPECT_CONDITIONS_OPPORTUNITIES:
                return suspectConditionsOpportunitiesConsumer;
            case QUALITYGAPS_OPPORTUNITIES:
                return qualityGapsOpportunitiesConsumer;
            case ANNUAL_CARE_OPPORTUNITIES:
                return annualCareOpportunitiesConsumer;
            case RUN_QFO_SUSPECT_CONDITIONS_OPPORTUNITIES:
                return qfoSuspectConditionsOpportunitiesConsumer;
            case RUN_QFO_QUALITY_GAPS_OPPORTUNITIES:
                return qfoQualityGapsOpportunitiesConsumer;
            case RUN_QFO_ANNUAL_CARE_OPPORTUNITIES:
                return qfoAnnualCareOpportunitiesConsumer;
            case RUN_MEMBER_PAYMENT_OVERALL_STATUS_SYNC:
                return runOpaMigrationConsumer;
            case LEADER_SUSPECT_OPPORTUNITIES:
                return leaderSuspectConditionsOppurtunitiesConsumer;
            case LEADER_QUALITY_GAPS_OPPORTUNITIES:
                return leaderQualityGapsOpportunitiesConsumer;
            case LEADER_ANNUAL_CARE_VISITS_OPPORTUNITIES:
                return leaderACVOppurtunitiesConsumer;
            case RETURN_METRIC_JOB:
                return returnTargetTrackingConsumer;
            case REJECT_AGING_JOB:
                return rejectAgingConsumer;
            case RUN_CHANGE_SERVICE_LEVEL_RULE:
                return changeServiceLevelRuleConsumer;
            case AVAIL_MEMBERSHIP_CLIENT_LOB_STATE_RULE:
                return availMemberShipClientLobStateConsumer;
            case RUN_NEW_PROVIDER_GROUP_MEMBERSHIP:
                return newProviderGroupMembershipConsumer;
            case NEW_PROVIDER_MANUAL_ASSOCIATION_JOB:
                return newProviderManualAssociationConsumer;
            default:
                return null;
        }

    }
}
