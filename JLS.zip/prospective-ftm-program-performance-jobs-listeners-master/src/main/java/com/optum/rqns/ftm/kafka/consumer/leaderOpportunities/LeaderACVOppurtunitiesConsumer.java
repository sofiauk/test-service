package com.optum.rqns.ftm.kafka.consumer.leaderOpportunities;

import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.consumer.JobEventConsumer;
import com.optum.rqns.ftm.repository.common.CommonRepository;
import com.optum.rqns.ftm.service.leaderopportunities.LeaderACVOppurtunitiesServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.context.annotation.Profile;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.annotation.TopicPartition;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

@Profile("memberGapJobs")
@Component
@Slf4j
public class LeaderACVOppurtunitiesConsumer extends JobEventConsumer {
    public LeaderACVOppurtunitiesConsumer(final LeaderACVOppurtunitiesServiceImpl leaderACVOppurtunitiesService, final CommonRepository commonRepository) {
        super(leaderACVOppurtunitiesService, commonRepository);
    }

    @KafkaListener(topicPartitions = {@TopicPartition(topic = "${spring.gcpkafka.properties.topics.jobEvent}", partitions = {"42"})},
            containerFactory = "jobEventKafkaListenerContainerFactory", autoStartup = "true")
    public void onMessage(ConsumerRecord<String, JobEvent> record, Acknowledgment acknowledgment) {
        log.info("{} Begin QualityGaps Leader Opportunities Consumer : {}", super.generateTransactionId(record), record);
        processMessage(42, record, acknowledgment);
    }
}
