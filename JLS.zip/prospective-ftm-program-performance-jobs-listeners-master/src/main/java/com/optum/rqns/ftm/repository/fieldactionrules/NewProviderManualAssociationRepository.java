package com.optum.rqns.ftm.repository.fieldactionrules;

import com.optum.rqns.ftm.model.fieldactionrules.RuleAction;
import java.util.List;

public interface NewProviderManualAssociationRepository {

    List<Integer> getNewProviderManualAssociationRuleCount(int batchsize);
    List<RuleAction> getNewProviderManualAssociationRuleData(Integer beginIndex, int batchSize);
}
