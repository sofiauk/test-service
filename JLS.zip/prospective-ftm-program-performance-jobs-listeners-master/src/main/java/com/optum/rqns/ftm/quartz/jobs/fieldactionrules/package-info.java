package com.optum.rqns.ftm.quartz.jobs.fieldactionrules;

/*
    This package consists of scheduled jobs for work queue rules.
 */