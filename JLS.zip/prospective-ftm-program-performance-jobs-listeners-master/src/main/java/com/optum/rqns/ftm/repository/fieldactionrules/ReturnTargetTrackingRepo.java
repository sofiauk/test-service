package com.optum.rqns.ftm.repository.fieldactionrules;

import com.optum.rqns.ftm.model.fieldactionrules.RuleAction;

import java.util.List;

public interface ReturnTargetTrackingRepo {

    public List<RuleAction> fetchReturnTargetInfo();

   // public Long fetchRecordCount();


}
