package com.optum.rqns.ftm.repository.jobalerts;

import com.optum.rqns.ftm.model.JobAlert;
import org.springframework.stereotype.Repository;

@Repository
public interface PrometheusJobAlertRepository {

   JobAlert getJobAlertByName(String jobName);
}
