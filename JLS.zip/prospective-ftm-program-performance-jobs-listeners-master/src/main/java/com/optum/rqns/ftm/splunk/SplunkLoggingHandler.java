package com.optum.rqns.ftm.splunk;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.optum.rqns.ftm.util.ProgramPerformanceJobUtil;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;

@Aspect
@Component
public class SplunkLoggingHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(SplunkLoggingHandler.class);
    private static final String URI_PATH = "uri_path";

    @Pointcut("within(@org.springframework.web.bind.annotation.RestController *)")
    public void controller() {
        // Dummy method.
    }

    @Pointcut("within(@org.springframework.web.bind.annotation.ControllerAdvice *)")
    public void exceptionHandler() {
        // Dummy method.
    }

    //After -> All method within resource annotated with @Controller annotation
    // and return a  value
    @AfterReturning(pointcut = "exceptionHandler()", returning = "result")
    public void logAfter(JoinPoint joinPoint, Object result) throws Throwable {
        String status = result.toString().substring(1, 4);
        int statusCode = Integer.parseInt(status);
        Map<String, Object> event = new HashMap<>();
        event.put("status", statusCode);
        event.put("timestamp", LocalDateTime.now().format(DateTimeFormatter.ISO_DATE_TIME));
        LOGGER.info(ProgramPerformanceJobUtil.sanitizeLogMessage(new ObjectMapper().writeValueAsString(event)));
    }

    //After -> Any method within resource annotated with @Controller annotation
    // throws an exception ...Log it
    @AfterThrowing(pointcut = "controller()", throwing = "exception")
    public void logAfterThrowing(JoinPoint joinPoint, Throwable exception) {
        LOGGER.error(joinPoint.getSignature().getName(), "An exception has been thrown in {}", 1);
        LOGGER.error(exception.getCause().getMessage(), "Cause : {}", 1);
    }

    //Around -> Any method within resource annotated with @Controller annotation
    @Around("controller() && args(..,req)")
    public Object logAround(ProceedingJoinPoint joinPoint, HttpServletRequest req)
            throws Throwable
    {
        long startTime = System.nanoTime();
        try {
            if (null != req) {
                Enumeration<String> headerNames = req.getHeaderNames();
                while (headerNames.hasMoreElements()) {
                    String headerName = headerNames.nextElement();
                    String headerValue = req.getHeader(headerName);
                    LOGGER.debug("Header Name: {} Header Value : {}", headerName, headerValue);
                }
            }
            ResponseEntity<?> result = (ResponseEntity<?>) joinPoint.proceed();
            long elapsedTime = (System.nanoTime() - startTime) / 1000000;
            Map<String, Object> event = new HashMap<>();
            try {
                if (req != null) {
                    event.put(URI_PATH, req.getServletPath());
                } else {
                    event.put(URI_PATH, "");
                }
            } catch (Exception e1) {
                event.put(URI_PATH, "");
            }
            event.put("response_time", elapsedTime);
            event.put("status", result.getStatusCodeValue());
            if (req != null) {
                event.put("request_method", req.getMethod());
                event.put("http_referer", "Not Present");
            }
            event.put("timestamp", LocalDateTime.now().format(DateTimeFormatter.ISO_DATE_TIME));

            LOGGER.info(ProgramPerformanceJobUtil.sanitizeLogMessage(new ObjectMapper().writeValueAsString(event)));
            return result;
        } catch (IllegalArgumentException e) {
            LOGGER.error("Illegal argument {} in {}()", Arrays.toString(joinPoint.getArgs()), joinPoint.getSignature().getName());
            throw e;
        }
    }
}