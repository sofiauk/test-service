package com.optum.rqns.ftm.kafka.consumer.qfo;

import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.consumer.JobEventConsumer;
import com.optum.rqns.ftm.repository.common.CommonRepositoryImpl;
import com.optum.rqns.ftm.service.qfo.QFOPatientExperienceScoresServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.context.annotation.Profile;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.annotation.TopicPartition;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

@Profile("memberGapJobs")
@Component
@Slf4j
public class QFOPatientExperienceScoreConsumer extends JobEventConsumer {

    public QFOPatientExperienceScoreConsumer(final QFOPatientExperienceScoresServiceImpl qfoPatientExperienceScoresService, final CommonRepositoryImpl commonRepository) {
        super(qfoPatientExperienceScoresService, commonRepository);
    }

    @KafkaListener(topicPartitions = {@TopicPartition(topic = "${spring.gcpkafka.properties.topics.jobEvent}", partitions = {"49"})},
            containerFactory = "jobEventKafkaListenerContainerFactory", autoStartup = "true")
    public void onMessage(ConsumerRecord<String, JobEvent> record, Acknowledgment acknowledgment) {
        log.info("{} Begin QFO Patient Experience Score Consumer : {}", super.generateTransactionId(record), record);
        processMessage(49, record, acknowledgment);
    }

}