package com.optum.rqns.ftm.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum RuleEnum {
    THRESHOLD_RULE("Threshold Rule"),
    REJECT_AGING_RULE("REJECT_AGING_FIELD_ACTION_RULE"),
    NEW_MEMBERSHIP_AVAILABLE("NEW_MEMBERSHIP_AVAILABLE"),
    AVAIL_MEMBERSHIP_CLIENT_LOB_STATE("AVAIL_MEMBERSHIP_CLIENT_LOB_STATE_RULE"),
    RETURN_TARGET_TRACKING_RULE("RETURN_TARGET_TRACKING_FIELD_ACTION_RULE");



    String value;
    public static RuleEnum parseValue(String value){
        switch (value.trim().toUpperCase()){
            case "THRESHOLD_RULE": return THRESHOLD_RULE;
            default:throw new IllegalArgumentException("Unexpected value:"+value+" Expected values are: " +
                    "THRESHOLD_RULE");
        }
    }

}
