package com.optum.rqns.ftm.repository.landingpage;

import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.model.ProgramYearCalendarDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;
import java.util.Objects;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Repository
@Slf4j
public class LeaderPerformanceRepositoryImpl implements LeaderPerformanceRepository {

    private static final String UPDATED_BY = "UpdatedBy";
    private static final String PROGRAM_YEAR = "ProgramYear";
    private static final String ELSE_CONDITION = " else NULL ";
    private static final String OWNER_UUID = "OwnerUUID";
    private static final String SERVICE_LEVEL = "ServiceLevel";
    private static final String REPORTERS = "Reporters";
    private static final String DURATION_VALUE = "DurationValue";
    private static final String DURATION_START_DATE = "DurationStartDate";
    private static final String DURATION_END_DATE = "DurationEndDate";
    private static final String MONTH = "Month";
    static final List<String> LEADER_ROLES = Arrays.asList("RVP", "Director", "Manager");

    private static final String USERS_BY_ROLES_QUERY = "SELECT " +
            " DISTINCT u.UUID " +
            "from " +
            " Auth.UserGroups ug " +
            "join Auth.UserUserGroup uug on " +
            " ug.GroupName in (:ICRoleNames) " +
            " and uug.UserGroupId = ug.UserGroupid " +
            "JOIN Auth.Users u on " +
            " u.UserId = uug.UserId " +
            " and u.UserId not in ( " +
            " SELECT " +
            "  DISTINCT u.UserId " +
            " from " +
            "  Auth.UserGroups ug " +
            " join Auth.UserUserGroup uug on " +
            "  ug.GroupName in (:LeaderRoleNames) " +
            "   and uug.UserGroupId = ug.UserGroupid " +
            "  JOIN Auth.Users u on " +
            "   u.UserId = uug.UserId);";

    private static final String OWNER_SERVICE_LEVEL_GROUP_IDS_QUERY = "with rs as (SELECT DISTINCT a.GroupId,a.State ,a.ServiceLevel " +
            " from ProgPerf.AccountOwner ao  with (nolock)" +
            " join ProgPerf.Accounts a on a.AccountId = ao.AccountId " +
            " where ao.OwnerUUID in( :OwnerUUID)" +
            " and a.ServiceLevel = :ServiceLevel" +
            " )";

    private static final String SERVICE_LEVELS_FOR_USER = "SELECT DISTINCT a.ServiceLevel " +
            "from ProgPerf.AccountOwner ao " +
            "join ProgPerf.Accounts a on a.AccountId = ao.AccountId " +
            "where ao.OwnerUUID in( :userId)";

    private static final String FLAG_IS_CURRENT_WEEK_FALSE = "update ProgPerf.LeaderPerformance set IsCurrentWeek = 0  " +
            ",UpdatedBy =:UpdatedBy,UpdatedDate =getUtcDate() "+
            "WHERE IsCurrentWeek = 1 and DurationValue not in ( :DurationValue )" ;

    private static final String FLAG_IS_ACTIVE_FALSE = "update ProgPerf.LeaderPerformance set IsActive = 0  " +
            ",UpdatedBy =:UpdatedBy,UpdatedDate =getUtcDate() "+
            " WHERE ProgramYear = :ProgramYear and IsActive = 1 and DurationValue in ( :DurationValue )" ;


    private static final String LOAD_DATA_TO_EMODALITY_QUERY = "MERGE  progperf.[Emodality] AS tgt   using    (   " +
            "  SELECT region,prov_group_id providergroupid,  " +
            " client clientname,providerstate STATE,lob2 lobname,project_year programyear,durationvalue durationvalue, StartDate durationstartdate,  EndDate durationenddate,  " +
            " OPAF, OptumUpload, OGM, Edata  FROM  (  " +
            " Select ht.location as region, ma.prov_group_id ,ma.project_year ,ma.providerstate,      " +
            " ma.client,ma.lob2, ma.retrievedby ,  ma.returnednetcna  returnednetcna , pyc.StartDate,pyc.EndDate,pyc.DurationValue   " +
            " from ProgPerf.MemberAssessment ma WITH (NOLOCK) join ProgPerf.ProgramYearCalendar pyc WITH (NOLOCK) on ma.project_year = pyc.ProgramYear" +
            "  inner join  ProgPerf.GeographicalHierarchy gh on gh.Location = ma.providerstate and  gh.LocationType ='State' " +
            " join ProgPerf.GeographicalHierarchy ht on ht.[Level] = gh.Level.GetAncestor(2)  " + " and ht.LocationType ='Region' " +
            " and ht.DeletedDate  is null" +
            " and gh.DeletedDate  is null " +
            " where   " +
            " ma.deriveddeployed = 1 and ma.returnednetcna =1 and ma.RecordChangeType != 'deleted'  " +
            " and ma.retrievedby in('OPAF','OptumUpload','OGM','Edata')  " +
            " and ma.project_year = :ProgramYear   " +
            " and pyc.DurationType ='WEEK' and     " +
            " pyc.StartDate <= CAST( getUTCDate() AS Date ) AND   " +
            " pyc.EndDate >=  CAST( getUTCDate() AS Date ) and ProgramYear = :ProgramYear   " +
            " ) AS SourceTable PIVOT(count([returnednetcna]) FOR [retrievedby] IN(OPAF,OptumUpload,OGM,Edata)) AS PivotTable " +
            " ) AS src    " +
            "             ON (    " +
            "        tgt.providergroupid = src.providergroupid    " +
            "       AND          tgt.[STATE] = src.[STATE]    " +
            "       AND          tgt.clientname = src.clientname    " +
            "       AND          tgt.lob = src.lobname    " +
            "       AND          tgt.programyear = src.programyear    " +
            "       AND          tgt.durationvalue = src.durationvalue )    " +
            "             WHEN matched THEN UPDATE    " +
            "             set  tgt.providergroupid = src.providergroupid ,    " +
            "           tgt.[STATE] = src.[STATE] ,    " +
            "           tgt.clientname = src.clientname ,    " +
            "           tgt.lob = src.lobname ,    " +
            "           tgt.programyear = src.programyear ,    " +
            "           tgt.durationvalue = src.durationvalue ,    " +
            "           tgt.durationstartdate = src.durationstartdate ,    " +
            "           tgt.durationenddate = src.durationenddate ,    " +
            "        tgt.RetrievedByOPAF = src.OPAF, " +
            "         tgt.RetrievedByOptumUpload = src.OptumUpload, " +
            "         tgt.RetrievedByOGM = src.OGM, " +
            "           tgt.RetrievedByEdata = src.Edata, " +
            "            " +
            "           tgt.updateddate = getutcdate() ,    " +
            "           tgt.updatedby = 'RunWeeklyEModalityLoad',    " +
            "           tgt.ServiceLevel = 'All'   " +
            "             WHEN NOT matched THEN INSERT      (  region,   " +
            "        providergroupid ,    " +
            "        [STATE] ,    " +
            "        clientname ,    " +
            "        lob ,    " +
            "        programyear ,    " +
            "        durationvalue ,    " +
            "        durationstartdate ,    " +
            "        durationenddate ,    " +
            "               RetrievedByOPAF, " +
            " RetrievedByOptumUpload, " +
            " RetrievedByOgm, " +
            " RetrievedByEdata, " +
            "        createddate ,    " +
            "        updateddate ,    " +
            "        createdby ,    " +
            "        updatedby, ServiceLevel            )    " +
            "        VALUES         (  src.region,  " +
            "        src.providergroupid ,    " +
            "        src.[STATE] ,    " +
            "        src.clientname ,    " +
            "        src.lobname ,    " +
            "        src.programyear ,    " +
            "        src.durationvalue ,    " +
            "        src.durationstartdate ,    " +
            "        src.durationenddate ,    " +
            "        src.OPAF, " +
            "        src.OptumUpload, " +
            "        src.OGM, " +
            "        src.Edata, " +
            "        getutcdate() ,    " +
            "        getutcdate() ,    " +
            "        'RunWeeklyEModalityLoad' ,    " +
            "        'RunWeeklyEModalityLoad', 'All'    " +
            "        );";

    private static final String LEADER_PERFORMANCE_QUERY = "Merge ProgPerf.LeaderPerformance as tgt " +
            " using ( " +
            " SELECT count(*) as recCount, pgpw.State, pgpw.Region, pgpw.ClientName, pgpw.lob, " +
            " pgpw.servicelevel, pgpw.ProgramYear, pgpw.DurationValue, " +
            " min(pgpw.DurationStartDate) as DurationStartDate, " +
            " max(pgpw.DurationEndDate) as DurationEndDate, " +
            " sum(pgpw.DeployActualPerf) as DeployActualPerf, " +
            " sum(pgpw.DeployGoalYTD) as DeployGoalYTD, " +
            " sum(pgpw.DeployGoalYE) as DeployGoalYE, " +
            " sum(pgpw.DeployActualGoal) as DeployActualGoal, " +
            " sum(pgpw.ReturnNetCnaActualPerf) as ReturnNetCnaActualPerf, " +
            " sum(pgpw.ReturnGoalYTD) as ReturnGoalYTD, " +
            " sum(pgpw.ReturnGoalYE) as ReturnGoalYE, " +
            " sum(pgpw.ReturnNetCnaActualGoal) as ReturnNetCnaActualGoal, " +
            " sum(pgpw.CompletedAssessmentActualPerf) as CompletedAssessmentActualPerf, " +
            " sum(pgpw.CompletedAssessmentActualGoal) as CompletedAssessmentActualGoal, " +
            " sum(pgpw.Rejects) as Rejects, " +
            " sum(pgpw.EligibleDeployableMembers) as EligibleDeployableMembers, " +
            " sum(pgpw.CGAPClosedSuspect) as CGAPClosedSuspect, " +
            " sum(pgpw.CGAPTotalSuspect) as CGAPTotalSuspect  " +
            " from ProgPerf.LeaderPerformance pgpw with (nolock) " +
            " WHERE LEN(pgpw.State) > 0 and LEN(pgpw.Lob)> 0 and LEN(pgpw.DurationValue)> 0 and LEN(pgpw.ClientName)> 0  AND LEN(pgpw.UUID) > 0 AND len(pgpw.region) > 0 " +
            " and pgpw.UUID in (:Reporters) and pgpw.DurationValue =:DurationValue and pgpw.IsActive =1 " +
            " GROUP by pgpw.State, pgpw.Region,pgpw.ClientName,pgpw.Lob,pgpw.servicelevel,pgpw.DurationValue, pgpw.ProgramYear " +
            " ) as src " +
            " on ( " +
            " src.Region = tgt.Region and " +
            " src.State = tgt.State and " +
            " src.ClientName = tgt.ClientName and " +
            " src.Lob = tgt.Lob and " +
            " src.ServiceLevel = tgt.ServiceLevel and " +
            " src.ProgramYear = tgt.ProgramYear and " +
            " src.DurationValue = tgt.DurationValue and  " +
            " tgt.UUID =  :OwnerUUID " +
            " )  " +
            " when MATCHED THEN  " +
            " update set  " +
            "  tgt.DurationStartDate = src.DurationStartDate, " +
            "  tgt.DurationEndDate = src.DurationEndDate, " +
            "  tgt.isCurrentWeek = 1, " +
            "  tgt.IsActive = 1," +
            "  tgt.DeployActualPerf = src.DeployActualPerf, " +
            "  tgt.DeployGoalYTD = src.DeployGoalYTD, " +
            "  tgt.DeployGoalYE = src.DeployGoalYE, " +
            "  tgt.DeployActualGoal = src.DeployActualGoal, " +
            "  tgt.ReturnNetCnaActualPerf = src.ReturnNetCnaActualPerf, " +
            "  tgt.ReturnGoalYTD = src.ReturnGoalYTD, " +
            "  tgt.ReturnGoalYE = src.ReturnGoalYE, " +
            "  tgt.ReturnNetCnaActualGoal = src.ReturnNetCnaActualGoal, " +
            "  tgt.CompletedAssessmentActualPerf = src.CompletedAssessmentActualPerf, " +
            "  tgt.CompletedAssessmentActualGoal = src.CompletedAssessmentActualGoal, " +
            "  tgt.EligibleDeployableMembers = src.EligibleDeployableMembers, " +
            "  tgt.CGAPClosedSuspect = src.CGAPClosedSuspect, " +
            "  tgt.CGAPTotalSuspect = src.CGAPTotalSuspect, " +
            "  tgt.Rejects = src.Rejects, " +
            "  tgt.UpdatedBy = :UpdatedBy,  " +
            "  tgt.UpdatedDate = GETUTCDATE()  " +
            " WHEN Not MATCHED THEN " +
            " INSERT(UUID,Region,State,ClientId,ClientName,LOB,ServiceLevel,ProgramYear,DurationValue,DurationStartDate,DurationEndDate,IsCurrentWeek, " +
            "  DeployActualPerf,DeployActualGoal,DeployGoalYTD,DeployGoalYE,ReturnNetCnaActualPerf,ReturnNetCnaActualGoal,ReturnGoalYTD,ReturnGoalYE, " +
            "  CompletedAssessmentActualPerf,CompletedAssessmentActualGoal,EligibleDeployableMembers,Rejects,CGAPClosedSuspect,CGAPTotalSuspect " +
            "  ,updatedBy,updatedDate,createdDate,createdBy,IsActive) " +
            " VALUES (:OwnerUUID ,src.region,src.State,NULL,src.ClientName,src.Lob,src.ServiceLevel,src.ProgramYear ,src.DurationValue,src.DurationStartDate,src.DurationEndDate,1, " +
            "        src.DeployActualPerf,src.DeployActualGoal, src.DeployGoalYTD,src.DeployGoalYE,src.ReturnNetCnaActualPerf,src.ReturnNetCnaActualGoal,src.ReturnGoalYTD,src.ReturnGoalYE, " +
            "       src.CompletedAssessmentActualPerf,src.CompletedAssessmentActualGoal,src.EligibleDeployableMembers,src.Rejects,src.CGAPClosedSuspect,src.CGAPTotalSuspect, " +
            "       :UpdatedBy,GETUTCDATE() ,GETUTCDATE() ,:UpdatedBy, 1);";

    private static final String IC_PERFORMANCE_QUERY = OWNER_SERVICE_LEVEL_GROUP_IDS_QUERY +
            " Merge ProgPerf.LeaderPerformance as tgt" +
            " using ( SELECT pgpw.State, pgpw.Region, pgpw.ClientName, pgpw.LobName as lob, " +
            " count(*) as recCount,rs.servicelevel," +
            " pgpw.ProgramYear, pgpw.DurationValue," +
            " sum(pgpw.DeployYTDActual) as DeployActualPerf," +
            " sum(pgpw.DeployYTDTarget) as DeployGoalYTD," +
            " sum(pgpw.DeployYETarget) as DeployGoalYE," +
            " sum(pgpw.ReturnedNetCnaYtdActual) as ReturnNetCnaActualPerf," +
            " sum(pgpw.ReturnYTDTarget) as ReturnGoalYTD," +
            " sum(pgpw.ReturnYETarget) as ReturnGoalYE," +
            " sum(pgpw.Completed) as CompletedAssessmentActualPerf," +
            " sum(pgpw.Rejects) as Rejects," +
            " sum(pgpw.EligibleDeployableMemberCount) as EligibleDeployableMembers" +
            " from ProgPerf.ProviderGroupPerformanceWeekly pgpw with (nolock)" +
            " join rs on  pgpw.ProviderGroupID = rs.GroupId and pgpw.State = rs.state and pgpw.DurationValue = :DurationValue and pgpw.ProgramYear = :ProgramYear" +
            " WHERE LEN(pgpw.State) > 0 and LEN(pgpw.LobName)> 0 and LEN(pgpw.DurationValue)> 0 and LEN(pgpw.ClientName)> 0  AND LEN(pgpw.ProviderGroupID) > 0 AND len(pgpw.region) > 0" +
            " GROUP by pgpw.State, pgpw.Region,pgpw.ClientName,pgpw.LobName,rs.servicelevel,pgpw.DurationValue, pgpw.ProgramYear" +
            " ) as src on (" +
            " src.Region  = tgt.Region and" +
            " src.State   = tgt.State and" +
            " src.ClientName  = tgt.ClientName and" +
            " src.Lob   = tgt.Lob and" +
            " src.ServiceLevel  = tgt.ServiceLevel and" +
            " src.ProgramYear   = tgt.ProgramYear and" +
            " src.DurationValue = tgt.DurationValue and " +
            " tgt.UUID = :OwnerUUID " +
            " ) " +
            " when MATCHED THEN " +
            " update set  " +
            "  tgt.DeployActualPerf = src.DeployActualPerf," +
            "     tgt.DeployGoalYTD = src.DeployGoalYTD," +
            "  tgt.DeployGoalYE = src.DeployGoalYE," +
            "  tgt.ReturnNetCnaActualPerf = src.ReturnNetCnaActualPerf," +
            "  tgt.ReturnGoalYTD = src.ReturnGoalYTD," +
            "  tgt.ReturnGoalYE = src.ReturnGoalYE," +
            "  tgt.CompletedAssessmentActualPerf = src.CompletedAssessmentActualPerf," +
            "  tgt.EligibleDeployableMembers = src.EligibleDeployableMembers," +
            "  tgt.Rejects = src.Rejects," +
            "  tgt.DurationStartDate = :DurationStartDate," +
            "  tgt.DurationEndDate = :DurationEndDate," +
            "  tgt.isCurrentWeek = 1," +
            "  tgt.isActive = 1," +
            "  tgt.UpdatedBy = :UpdatedBy , " +
            "  tgt.UpdatedDate = GETUTCDATE() " +
            " WHEN Not MATCHED " +
            " THEN" +
            " INSERT(UUID,Region,State,ClientId,ClientName,LOB,ServiceLevel,ProgramYear,DurationValue,DurationStartDate,DurationEndDate,IsCurrentWeek," +
            "  DeployActualPerf,DeployActualGoal,DeployGoalYTD,DeployGoalYE,ReturnNetCnaActualPerf,ReturnNetCnaActualGoal,ReturnGoalYTD,ReturnGoalYE," +
            "  CompletedAssessmentActualPerf,CompletedAssessmentActualGoal,EligibleDeployableMembers,Rejects,CGAPClosedSuspect,CGAPTotalSuspect" +
            "   ,updatedBy,updatedDate,createdDate,createdBy, IsActive)" +
            " VALUES (:OwnerUUID ,src.region,src.State,NULL,src.ClientName,src.Lob,src.ServiceLevel,src.ProgramYear ,src.DurationValue,:DurationStartDate,:DurationEndDate,1," +
            "        src.DeployActualPerf,NULL, src.DeployGoalYTD,src.DeployGoalYE,src.ReturnNetCnaActualPerf,NULL,src.ReturnGoalYTD,src.ReturnGoalYE," +
            "       src.CompletedAssessmentActualPerf,NULL,src.EligibleDeployableMembers,src.Rejects,NULL,NULL," +
            "  :UpdatedBy,GETUTCDATE() ,GETUTCDATE() ,:UpdatedBy,1);";


    private static final String IC_CGAP_QUERY = OWNER_SERVICE_LEVEL_GROUP_IDS_QUERY +
            " Merge ProgPerf.LeaderPerformance as tgt" +
            " using (   " +
            " SELECT cc.ProviderState as state,cc.ClientName, cc.Lob, " +
            " count(*) as recCount,rs.servicelevel," +
            " cc.ProgramYear, :DurationValue as DurationValue," +
            " sum(cc.RiskDXVerified + cc.RiskNoDXAttestation + cc.RiskReferred) as CGAPClosedSuspect," +
            " sum(cc.TotalSuspects) as CGAPTotalSuspect, ht.Location " +
            " from ProgPerf.CGapClosure cc with (nolock) " +
            " join rs on  cc.ProviderGroupID = rs.GroupId and cc.ProviderState = rs.state and cc.ProgramYear = :ProgramYear" +
            " join ProgPerf.GeographicalHierarchy gh on " +
            " gh.Location = rs.state " +
            "join ProgPerf.GeographicalHierarchy ht on " +
            " ht.[Level] = gh.Level.GetAncestor(2) and gh.LocationType = 'State' " +
            " and ht.LocationType ='Region' " +
            " and ht.DeletedDate  is null" +
            " and gh.DeletedDate  is null " +
            "WHERE " +
            " LEN(cc.ProviderState) > 0 and LEN(cc.Lob)> 0 and LEN(cc.ClientName)> 0  AND LEN(cc.ProviderGroupID) > 0 " +
            " GROUP by cc.ProviderState, cc.ClientName,cc.Lob,rs.servicelevel,cc.ProgramYear, ht.Location " +
            " ) as src on (" +
            " src.State = tgt.State and" +
            " src.ClientName = tgt.ClientName and" +
            " src.Lob = tgt.Lob and" +
            " src.ServiceLevel = tgt.ServiceLevel and" +
            " src.ProgramYear = tgt.ProgramYear and" +
            " src.DurationValue = tgt.DurationValue and " +
            " tgt.UUID = :OwnerUUID " +
            " ) " +
            " when MATCHED THEN update set " +
            "  tgt.CGAPClosedSuspect = src.CGAPClosedSuspect," +
            "     tgt.CGAPTotalSuspect = src.CGAPTotalSuspect," +
            "  tgt.isCurrentWeek = 1," +
            "  tgt.isActive = 1," +
            "  tgt.UpdatedBy = :UpdatedBy , " +
            "  tgt.UpdatedDate = GETUTCDATE() " +
            " WHEN  Not MATCHED  THEN" +
            " INSERT(UUID,Region,State,ClientId,ClientName,LOB,ServiceLevel,ProgramYear,DurationValue,DurationStartDate,DurationEndDate,IsCurrentWeek," +
            "  CGAPClosedSuspect,CGAPTotalSuspect" +
            "   ,updatedBy,updatedDate,createdDate,createdBy, IsActive)" +
            " VALUES (:OwnerUUID ,src.Location, src.State,NULL,src.ClientName,src.Lob,src.ServiceLevel,src.ProgramYear ,src.DurationValue,:DurationStartDate,:DurationEndDate,1," +
            "         src.CGAPClosedSuspect,src.CGAPTotalSuspect," +
            "  :UpdatedBy,GETUTCDATE() ,GETUTCDATE() ,:UpdatedBy,1);";

    private static final String IC_GROWTH_RATE_POC_QUERY = "with rs as (SELECT DISTINCT a.GroupId,a.State ,a.ServiceLevel , a.UtilizingPOC " +
            " from ProgPerf.AccountOwner ao  with (nolock)" +
            " join ProgPerf.Accounts a on a.AccountId = ao.AccountId " +
            " where ao.OwnerUUID in( :OwnerUUID)" +
            " and a.ServiceLevel = :ServiceLevel" +
            " )" +
            " Merge ProgPerf.LeaderGrowthRatePOCEModality as tgt" +
            " using (" +
            "  SELECT pge.State, 'All' as ClientName, 'All' as lob, " +
            " rs.servicelevel, FORMAT(GETUTCDATE() , 'MMM', 'en-US') as CurrentMonth," +
            " pge.ProgramYear,count(*) as GrowthRateTotalGroups," +
            " sum(case when pge.IsAgreed = 1 then 1 else 0 end ) as AgreedParticipate," +
            " sum(case when pge.IsEngaged = 1 then 1 else 0 end ) as EngagedParticipate," +
            " sum(case when pge.IsGroupEligibleForPOC = 1 and pge.IsNewForPOC = 0 then 1 else 0 end) as POCExistingTotalGroups," +
            " sum(case when rs.UtilizingPOC = 1 and pge.IsGroupEligibleForPOC = 1 and pge.IsNewForPOC = 0 then 1 else 0 end) as POCExistingGroups," +
            " sum(case when rs.UtilizingPOC = 1 and pge.IsGroupEligibleForPOC = 1 and pge.IsNewForPOC = 1 then 1 else 0 end) as POCNewGroups," +
            " sum(case when pge.IsGroupEligibleForPOC = 1 and pge.IsNewForPOC = 1 then 1 else 0 end) as POCNewTotalGroups" +
            " from ProgPerf.ProviderGroupExtended pge with (nolock)" +
            " join rs on  pge.ProviderGroupID = rs.GroupId and pge.State = rs.state and pge.ProgramYear = :ProgramYear" +
            " WHERE LEN(pge.State) > 0  AND LEN(pge.ProviderGroupID) > 0 " +
            " GROUP by pge.State,rs.servicelevel, pge.ProgramYear" +
            " ) as src" +
            " on (" +
            " src.State = tgt.State and" +
            " src.ClientName = tgt.ClientName and" +
            " src.Lob = tgt.Lob and" +
            " src.ServiceLevel = tgt.ServiceLevel and" +
            " src.ProgramYear = tgt.ProgramYear and" +
            " src.CurrentMonth = tgt.[Month] and" +
            " tgt.UUID = :OwnerUUID" +
            " ) " +
            " when MATCHED THEN " +
            " update set " +
            "  tgt.GrowthRateTotalGroups = src.GrowthRateTotalGroups," +
            "  tgt.AgreedParticipate = src.AgreedParticipate," +
            "  tgt.EngagedParticipate = src.EngagedParticipate," +
            "  tgt.POCExistingTotalGroups = src.POCExistingTotalGroups," +
            "  tgt.POCExistingGroups = src.POCExistingGroups," +
            "  tgt.POCNewTotalGroups = src.POCNewTotalGroups," +
            "  tgt.POCNewGroups = src.POCNewGroups," +
            "  tgt.UpdatedBy = :UpdatedBy, " +
            "  tgt.UpdatedDate = GETUTCDATE()," +
            "  tgt.IsActive = 1" +
            " WHEN Not MATCHED THEN" +
            " INSERT(UUID,State,ClientId,ClientName,LOB,ServiceLevel,ProgramYear,[Month]," +
            " GrowthRateTotalGroups,AgreedParticipate,EngagedParticipate" +
            " ,POCExistingTotalGroups,POCExistingGroups,POCNewTotalGroups,POCNewGroups" +
            "  ,updatedBy,updatedDate,createdDate,createdBy, IsActive)" +
            " VALUES (:OwnerUUID ,src.State,NULL,src.ClientName,src.Lob,src.ServiceLevel,src.ProgramYear,src.CurrentMonth," +
            "        src.GrowthRateTotalGroups,src.AgreedParticipate,src.EngagedParticipate," +
            "        src.POCExistingTotalGroups,src.POCExistingGroups,src.POCNewTotalGroups,src.POCNewGroups," +
            "       :UpdatedBy,GETUTCDATE() ,GETUTCDATE() ,:UpdatedBy,1);";

    private static final String LEADER_GROWTH_RATE_POC_QUERY = "Merge ProgPerf.LeaderGrowthRatePOCEModality as tgt" +
            " using (" +
            "  SELECT State,  ClientName, lob, servicelevel, [Month] as CurrentMonth, ProgramYear" +
            "  ,sum(GrowthRateTotalGroups) as GrowthRateTotalGroups," +
            " sum(AgreedParticipate) as AgreedParticipate," +
            " sum(EngagedParticipate) as EngagedParticipate," +
            " sum(POCExistingTotalGroups) as POCExistingTotalGroups," +
            " sum(POCExistingGroups) as POCExistingGroups," +
            " sum(POCNewTotalGroups) as POCNewTotalGroups," +
            " sum(POCNewGroups) as POCNewGroups, " +
            " sum(RetrievedByOPAF) as RetrievedByOPAF, " +
            " sum(RetrievedByOptumUpload) as RetrievedByOptumUpload, " +
            " sum(RetrievedByOgm) as RetrievedByOgm, " +
            " sum(RetrievedByEdata) as RetrievedByEdata, sum(ReturnNetCnaActualPer) as ReturnNetCnaActualPer "+
            " from ProgPerf.LeaderGrowthRatePOCEModality pge with (nolock)" +
            " WHERE LEN(pge.State) > 0  and LEN(pge.ClientName)>0 and LEN(pge.LOB) >0 and LEN(pge.ServiceLevel)> 0" +
            " and pge.UUID in (:Reporters) and pge.ProgramYear = :ProgramYear and pge.isActive=1 and pge.[Month] = FORMAT(GETUTCDATE() , 'MMM', 'en-US') " +
            " GROUP by pge.State,pge.ClientName,pge.servicelevel,pge.LOB,pge.[Month] , pge.ProgramYear" +
            " ) as src" +
            " on (" +
            " tgt.State = src.State and" +
            " tgt.ClientName = src.ClientName and" +
            " tgt.Lob = src.Lob and" +
            " tgt.ServiceLevel = src.ServiceLevel and" +
            " tgt.ProgramYear = src.ProgramYear and" +
            " tgt.[Month] = src.CurrentMonth and" +
            " tgt.UUID = :OwnerUUID" +
            " ) " +
            " when MATCHED  THEN " +
            " update set " +
            "  tgt.GrowthRateTotalGroups = src.GrowthRateTotalGroups," +
            "  tgt.AgreedParticipate = src.AgreedParticipate," +
            "  tgt.EngagedParticipate = src.EngagedParticipate," +
            "  tgt.POCExistingTotalGroups = src.POCExistingTotalGroups," +
            "  tgt.POCExistingGroups = src.POCExistingGroups," +
            "  tgt.POCNewTotalGroups = src.POCNewTotalGroups," +
            "  tgt.POCNewGroups = src.POCNewGroups," +
            "  tgt.RetrievedByOPAF = src.RetrievedByOPAF, " +
            "  tgt.RetrievedByOptumUpload = src.RetrievedByOptumUpload, " +
            "  tgt.RetrievedByOgm = src.RetrievedByOgm, " +
            "  tgt.RetrievedByEdata = src.RetrievedByEdata, " +
            "  tgt.UpdatedBy = :UpdatedBy, " +
            "  tgt.UpdatedDate = GETUTCDATE(), tgt.ReturnNetCnaActualPer=src.ReturnNetCnaActualPer," +
            "  tgt.IsActive = 1" +
            " WHEN Not MATCHED THEN" +
            " INSERT(UUID,State,ClientId,ClientName,LOB,ServiceLevel,ProgramYear,[Month]," +
            " GrowthRateTotalGroups,AgreedParticipate,EngagedParticipate" +
            " ,POCExistingTotalGroups,POCExistingGroups,POCNewTotalGroups,POCNewGroups" +
            " ,RetrievedByOPAF,RetrievedByOptumUpload,RetrievedByOgm,RetrievedByEdata" +
            "  ,updatedBy,updatedDate,createdDate,createdBy, IsActive,ReturnNetCnaActualPer)" +
            " VALUES (:OwnerUUID ,src.State,NULL,src.ClientName,src.Lob,src.ServiceLevel,src.ProgramYear,src.CurrentMonth," +
            "        src.GrowthRateTotalGroups,src.AgreedParticipate,src.EngagedParticipate," +
            "        src.POCExistingTotalGroups,src.POCExistingGroups,src.POCNewTotalGroups,src.POCNewGroups," +
            " src.RetrievedByOPAF,src.RetrievedByOptumUpload,src.RetrievedByOgm,src.RetrievedByEdata," +
            "       :UpdatedBy,GETUTCDATE() ,GETUTCDATE() ,:UpdatedBy,1,src.ReturnNetCnaActualPer);";

    String LEADER_GROWTH_RATE_POC_FOR_ALL_QUERY = "Merge ProgPerf.LeaderGrowthRatePOCEModality as tgt  " +
            " using (  " +
            "  SELECT 'All' as state, 'All' as Region, ClientName, lob, servicelevel, [Month] as CurrentMonth, ProgramYear  " +
            "  ,sum(GrowthRateTotalGroups) as GrowthRateTotalGroups,  " +
            " sum(AgreedParticipate) as AgreedParticipate,  " +
            " sum(EngagedParticipate) as EngagedParticipate,  " +
            " sum(POCExistingTotalGroups) as POCExistingTotalGroups,  " +
            " sum(POCExistingGroups) as POCExistingGroups,  " +
            " sum(POCNewTotalGroups) as POCNewTotalGroups,  " +
            " sum(POCNewGroups) as POCNewGroups,   " +
            " sum(RetrievedByOPAF) as RetrievedByOPAF,   " +
            " sum(RetrievedByOptumUpload) as RetrievedByOptumUpload,   " +
            " sum(RetrievedByOgm) as RetrievedByOgm,   " +
            " sum(RetrievedByEdata) as RetrievedByEdata ,sum(ReturnNetCnaActualPer) as ReturnNetCnaActualPer  " +
            " from ProgPerf.LeaderGrowthRatePOCEModality pge with (nolock)  " +
            " WHERE LEN(pge.State) > 0  and LEN(pge.ClientName)>0 and LEN(pge.LOB) >0 and LEN(pge.ServiceLevel)> 0  " +
            " and pge.UUID in (:Reporters) and pge.ProgramYear = :ProgramYear  and pge.ClientName  = 'All' and pge.lob = 'All' and pge.state != 'All' and  (pge.Region !='All' or pge.Region is Null) and pge.isActive=1 and pge.[Month] = FORMAT(GETUTCDATE() , 'MMM', 'en-US') " +
            " GROUP by pge.ClientName,pge.servicelevel,pge.LOB,pge.[Month] , pge.ProgramYear  " +
            " ) as src  " +
            " on (  " +
            " tgt.State = src.State and  " +
            " tgt.ClientName = src.ClientName and  " +
            " tgt.Lob = src.Lob and  " +
            " tgt.ServiceLevel = src.ServiceLevel and  " +
            " tgt.ProgramYear = src.ProgramYear and  " +
            " tgt.[Month] = src.CurrentMonth and  " +
            " tgt.UUID = :OwnerUUID  " +
            " )   " +
            " when MATCHED  THEN   " +
            " update set   " +
            "  tgt.GrowthRateTotalGroups = src.GrowthRateTotalGroups,  " +
            "  tgt.AgreedParticipate = src.AgreedParticipate,  " +
            "  tgt.EngagedParticipate = src.EngagedParticipate,  " +
            "  tgt.POCExistingTotalGroups = src.POCExistingTotalGroups,  " +
            "  tgt.POCExistingGroups = src.POCExistingGroups,  " +
            "  tgt.POCNewTotalGroups = src.POCNewTotalGroups,  " +
            "  tgt.POCNewGroups = src.POCNewGroups,  " +
            "  tgt.RetrievedByOPAF = src.RetrievedByOPAF,   " +
            "  tgt.RetrievedByOptumUpload = src.RetrievedByOptumUpload,   " +
            "  tgt.RetrievedByOgm = src.RetrievedByOgm,   " +
            "  tgt.RetrievedByEdata = src.RetrievedByEdata,   " +
            "  tgt.UpdatedBy = :UpdatedBy,   " +
            "  tgt.UpdatedDate = GETUTCDATE(),  tgt.Region =src.Region, " +
            "  tgt.IsActive = 1 ,tgt.ReturnNetCnaActualPer = src.ReturnNetCnaActualPer " +
            " WHEN Not MATCHED THEN  " +
            " INSERT(UUID,Region,State,ClientId,ClientName,LOB,ServiceLevel,ProgramYear,[Month],  " +
            " GrowthRateTotalGroups,AgreedParticipate,EngagedParticipate  " +
            " ,POCExistingTotalGroups,POCExistingGroups,POCNewTotalGroups,POCNewGroups  " +
            " ,RetrievedByOPAF,RetrievedByOptumUpload,RetrievedByOgm,RetrievedByEdata  " +
            "  ,updatedBy,updatedDate,createdDate,createdBy, IsActive,ReturnNetCnaActualPer)  " +
            " VALUES (:OwnerUUID,src.Region ,src.State,NULL,src.ClientName,src.Lob,src.ServiceLevel,src.ProgramYear,src.CurrentMonth,  " +
            "        src.GrowthRateTotalGroups,src.AgreedParticipate,src.EngagedParticipate,  " +
            "        src.POCExistingTotalGroups,src.POCExistingGroups,src.POCNewTotalGroups,src.POCNewGroups,  " +
            " src.RetrievedByOPAF,src.RetrievedByOptumUpload,src.RetrievedByOgm,src.RetrievedByEdata,  " +
            "       :UpdatedBy,GETUTCDATE() ,GETUTCDATE() ,:UpdatedBy,1,src.ReturnNetCnaActualPer);";

    String QUERY_DATA_LOAD_LEADER_PERF_NATIONAL="Merge ProgPerf.LeaderPerformance as target " +
            " using ( " +
            "SELECT " +
            " pgpw.Region, " +
            " pgpw.State, " +
            " pgpw.ClientName, " +
            " pgpw.LobName, " +
            " a.servicelevel, " +
            " pgpw.ProgramYear, " +
            " pgpw.DurationValue, " +
            " sum(ReturnedNetCnaYtdActual) ReturnNetCnaActualPerf, " +
        /*    " case " +
            "  when SUM(DeployYETarget) > 0 then sum(ReturnedNetCnaYtdActual) " +
            " end ReturnNetCnaActualGoal, " +
            " case " +
            "  when SUM(DeployYETarget) > 0 then sum(Completed) " +
            " end CompletedAssessmentActualGoal, " +
            " case " +
            "  when SUM(DeployYETarget) > 0 then sum(DeployYTDActual) " +
            " end DeployActualGoal, " +*/
            " sum(EligibleDeployableMemberCount) EligibleDeployableMembers, " +
            " sum(ReturnYTDTarget) ReturnGoalYTD, " +
            " sum(ReturnYETarget) ReturnGoalYE, " +
            " sum(DeployYETarget) DeployGoalYE , " +
            " sum(DeployYTDTarget) DeployGoalYTD, " +
            " sum(Rejects) Rejects, " +
            " sum(DeployYTDActual) DeployActualPerf, " +
            " sum(Completed) CompletedAssessmentActualPerf " +
            "from " +
            " ProgPerf.ProviderGroupPerformanceWeekly pgpw with (nolock) , " +
            " ProgPerf.Accounts a " +
            "where " +
            " pgpw.ProviderGroupID = a.groupId " +
            " and pgpw.State = a.State " +
            " and pgpw.DurationValue = :durationValue " +
            " and pgpw.ProgramYear = :programYear " +
            " and LEN(pgpw.State) > 0 " +
            " and LEN(pgpw.LobName)> 0 " +
            " and LEN(pgpw.DurationValue)> 0 " +
            " and LEN(pgpw.ClientName)> 0 " +
            " and LEN(pgpw.ProviderGroupID) > 0 " +
            " and len(pgpw.region) > 0 " +
            " and a .ServiceLevel in ( " +
            " select " +
            "  distinct ServiceLevel " +
            " from " +
            "  ProgPerf.Accounts a " +
            " where " +
            "  ServiceLevel <> '' " +
            "  AND ServiceLevel is not NULL) " +
            "GROUP by " +
            " pgpw.State, " +
            " pgpw.Region, " +
            " pgpw.ClientName, " +
            " pgpw.LobName, " +
            " a.servicelevel, " +
            " pgpw.ProgramYear, " +
            " pgpw.DurationValue) src on " +
            "( ISNULL(src.Region, " +
            "'') = ISNULL( target.Region, " +
            "'') " +
            " and src.State = target.State " +
            " and src.ClientName = target.ClientName " +
            " and src.LobName = target.Lob " +
            " and src.ServiceLevel = target.ServiceLevel " +
            " and src.ProgramYear = target.ProgramYear " +
            " and src.DurationValue = target.DurationValue " +
            " and target.UUID = :uuid ) " +
            "when MATCHED THEN " +
            "update " +
            "set " +
            " target.DeployActualPerf = src.DeployActualPerf, " +
            " target.DeployGoalYTD = src.DeployGoalYTD, " +
            " target.DeployGoalYE = src.DeployGoalYE, " +
            " target.ReturnNetCnaActualPerf = src.ReturnNetCnaActualPerf, " +
            " target.ReturnGoalYTD = src.ReturnGoalYTD, " +
            " target.ReturnGoalYE = src.ReturnGoalYE, " +
            " target.CompletedAssessmentActualPerf = src.CompletedAssessmentActualPerf, " +
            " target.EligibleDeployableMembers = src.EligibleDeployableMembers, " +
            " target.Rejects = src.Rejects, " +
            " target.DurationStartDate = :durationStartDate, " +
            " target.DurationEndDate = :durationEndDate, " +
            " target.UpdatedBy = :updatedBy, " +
            " target.IsActive = 1, " +
            " target.UpdatedDate = GETUTCDATE() " +
            " WHEN Not MATCHED THEN " +
            "INSERT " +
            " (UUID, " +
            " Region, " +
            " State, " +
            " ClientId, " +
            " ClientName, " +
            " LOB, " +
            " ServiceLevel, " +
            " ProgramYear, " +
            " DurationValue, " +
            " DurationStartDate, " +
            " DurationEndDate, " +
            " IsCurrentWeek, " +
            " IsActive, " +
            " DeployActualPerf, " +
            " DeployActualGoal, " +
            " DeployGoalYTD, " +
            " DeployGoalYE, " +
            " ReturnNetCnaActualPerf, " +
            " ReturnNetCnaActualGoal, " +
            " ReturnGoalYTD, " +
            " ReturnGoalYE, " +
            " CompletedAssessmentActualPerf, " +
            " CompletedAssessmentActualGoal, " +
            " EligibleDeployableMembers, " +
            " Rejects, " +
            " CGAPClosedSuspect, " +
            " CGAPTotalSuspect , " +
            " updatedBy, " +
            " updatedDate, " +
            " createdDate, " +
            " createdBy) " +
            "VALUES (:uuid , " +
            "src.region, " +
            "src.State, " +
            "NULL , " +
            "src.ClientName, " +
            "src.LobName, " +
            "src.ServiceLevel, " +
            "src.ProgramYear , " +
            ":durationValue, " +
            ":durationStartDate, " +
            ":durationEndDate, " +
            "'1', " +
            "1, " +
            "src.DeployActualPerf, " +
            "NULL, " +
            "src.DeployGoalYTD, " +
            "src.DeployGoalYE, " +
            "src.ReturnNetCnaActualPerf, " +
            "NULL, " +
            "src.ReturnGoalYTD, " +
            "src.ReturnGoalYE, " +
            "src.CompletedAssessmentActualPerf, " +
            "NULL, " +
            "src.EligibleDeployableMembers, " +
            "src.Rejects, " +
            "0, " +
            "0, " +
            ":updatedBy, " +
            "GETUTCDATE() , " +
            "GETUTCDATE() , " +
            ":updatedBy);";

    String IC_GOAL_UPDATE_LEADER_PERFORMANCE="with rs as ( " +
            "SELECT " +
            " DISTINCT a.GroupId, " +
            " a.State , " +
            " a.ServiceLevel " +
            "from " +
            " ProgPerf.AccountOwner ao with (nolock) " +
            "join ProgPerf.Accounts a on " +
            " a.AccountId = ao.AccountId " +
            "where " +
            " ao.OwnerUUID in( :OwnerUUID) " +
            " and a.ServiceLevel = :ServiceLevel ) " +
            " Merge ProgPerf.LeaderPerformance as tgt   " +
            " using (   " +
            "SELECT " +
            " pgpw.State, " +
            " pgpw.Region, " +
            " pgpw.ClientName, " +
            " pgpw.LobName as lob, " +
            " count(*) as recCount, " +
            " rs.servicelevel, " +
            " pgpw.ProgramYear, " +
            " pgpw.DurationValue, " +
            " sum(ReturnedNetCnaYtdActual) ReturnNetCnaActualGoal, " +
            " sum(Completed) CompletedAssessmentActualGoal, " +
            " sum(DeployYTDActual) DeployActualGoal " +
            "from " +
            " ProgPerf.ProviderGroupPerformanceWeekly pgpw with (nolock) " +
            "join rs on " +
            " pgpw.ProviderGroupID = rs.GroupId " +
            " and pgpw.State = rs.state " +
            " and pgpw.DurationValue = :DurationValue " +
            " and pgpw.ProgramYear = :ProgramYear " +
            "WHERE " +
            " LEN(pgpw.State) > 0 " +
            " and LEN(pgpw.LobName)> 0 " +
            " and LEN(pgpw.DurationValue)> 0 " +
            " and LEN(pgpw.ClientName)> 0 " +
            " AND LEN(pgpw.ProviderGroupID) > 0 " +
            " AND len(pgpw.region) > 0 " +
            " and pgpw.IsIDMTarget = 1 " +
            "GROUP by " +
            " pgpw.State, " +
            " pgpw.Region, " +
            " pgpw.ClientName, " +
            " pgpw.LobName, " +
            " rs.servicelevel, " +
            " pgpw.DurationValue, " +
            " pgpw.ProgramYear) as src on " +
            " ( src.Region = tgt.Region " +
            "  and src.State = tgt.State " +
            "  and src.ClientName = tgt.ClientName " +
            "  and src.Lob = tgt.Lob " +
            "  and src.ServiceLevel = tgt.ServiceLevel " +
            "  and src.ProgramYear = tgt.ProgramYear " +
            "  and src.DurationValue = tgt.DurationValue " +
            "  and tgt.UUID = :OwnerUUID ) " +
            " when MATCHED THEN " +
            "update " +
            "set " +
            " tgt.DeployActualGoal = src.DeployActualGoal, " +
            " tgt.ReturnNetCnaActualGoal = src.ReturnNetCnaActualGoal, " +
            " tgt.CompletedAssessmentActualGoal = src.CompletedAssessmentActualGoal, " +
            " tgt.UpdatedBy = :UpdatedBy, " +
            " tgt.UpdatedDate = GETUTCDATE();";

    private static final String UPDATE_REGION_QUERY = "update  ProgPerf.LeaderGrowthRatePOCEModality  " +
            "set Region  = ht.location " +
            "FROM ProgPerf.LeaderGrowthRatePOCEModality PGP  " +
            "join ProgPerf.GeographicalHierarchy gh on gh.Location = PGP.State and  gh.LocationType ='State' " +
            "join ProgPerf.GeographicalHierarchy ht on ht.[Level] = gh.Level.GetAncestor(2) " +
            "WHERE PGP.[Month] = FORMAT(GETUTCDATE() , 'MMM', 'en-US') " +
            "and gh.Location = PGP.State " +
            "AND PGP.ProgramYear =:ProgramYear "+
            " and ht.LocationType ='Region' " +
            " and ht.DeletedDate  is null" +
            " and gh.DeletedDate  is null ";
    private static final String IC_EMODALITY_POC_QUERY =
            "  with rs as (SELECT DISTINCT ao.OwnerUUID,a.GroupId,a.State ,a.ServiceLevel , a.UtilizingPOC from ProgPerf.AccountOwner ao  with (nolock) join ProgPerf.Accounts a on a.AccountId = ao.AccountId  where ao.OwnerUUID in( :OwnerUUID) and a.ServiceLevel = :ServiceLevel )  " +
            "  Merge ProgPerf.LeaderGrowthRatePOCEModality as tgt using (  " +
            "  SELECT OwnerUUID uuid, FORMAT(GETUTCDATE() , 'MMM', 'en-US') as CurrentMonth,  " +
            " 'All' clientname,providerstate STATE,'All' lob,project_year programyear,servicelevel servicelevel,  " +
            " OPAF, OptumUpload, OGM, Edata  FROM  (    " +
            " Select  ma.project_year ,ma.providerstate, rs.servicelevel, rs.OwnerUUID,     " +
            "  ma.retrievedby ,  ma.returnednetcna  returnednetcna    " +
            " from ProgPerf.MemberAssessment ma join rs on  ma.prov_group_id= rs.GroupId and ma.providerstate = rs.State   where     " +
            " ma.deriveddeployed = 1 and ma.returnednetcna =1 and ma.RecordChangeType != 'deleted'    " +
            " and ma.retrievedby in('OPAF','OptumUpload','OGM','Edata')    " +
            " and ma.project_year = :ProgramYear    " +
            " ) AS SourceTable PIVOT(count([returnednetcna]) FOR [retrievedby] IN(OPAF,OptumUpload,OGM,Edata)) AS PivotTable) as src   on (  " +
            " src.State = tgt.State and src.ClientName = tgt.ClientName and src.Lob = tgt.Lob and src.ServiceLevel = tgt.ServiceLevel and  " +
            " src.ProgramYear = tgt.ProgramYear and src.CurrentMonth = tgt.[Month] and tgt.UUID = :OwnerUUID  " +
            " ) when MATCHED THEN update set   " +
            "  tgt.RetrievedByOPAF = src.OPAF,  " +
            "  tgt.RetrievedByOptumUpload = src.OptumUpload,  " +
            "  tgt.RetrievedByOgm = src.OGM,  " +
            "  tgt.RetrievedByEdata = src.Edata,   " +
            "  tgt.UpdatedBy = :UpdatedBy,  tgt.UpdatedDate = GETUTCDATE(), tgt.IsActive=1 " +
            " WHEN Not MATCHED THEN   INSERT(UUID,State,ClientId,ClientName,LOB,ServiceLevel,ProgramYear,[Month], RetrievedByOPAF,  " +
            " RetrievedByOptumUpload,RetrievedByOgm,RetrievedByEdata,updatedBy,updatedDate,createdDate,createdBy,IsActive)  " +
            " VALUES (:OwnerUUID ,src.State,NULL,src.ClientName,src.Lob,src.ServiceLevel,src.ProgramYear,src.CurrentMonth,  " +
            "        src.OPAF,src.OptumUpload, src.OGM,src.Edata, :UpdatedBy,GETUTCDATE() ,GETUTCDATE() ,:UpdatedBy,1);  " ;

    private static  String IC_EMODALITY_POC_CLIENT_LOB_LEVEL = "  with rs as (SELECT DISTINCT ao.OwnerUUID,a.GroupId,a.State ,a.ServiceLevel , a.UtilizingPOC from ProgPerf.AccountOwner ao  with (nolock) join ProgPerf.Accounts a on a.AccountId = ao.AccountId  where ao.OwnerUUID in( :OwnerUUID) and a.ServiceLevel = :ServiceLevel )   " +
            " Merge ProgPerf.LeaderGrowthRatePOCEModality as tgt using (   " +
            "  SELECT OwnerUUID uuid, FORMAT(GETUTCDATE() , 'MMM', 'en-US') as CurrentMonth,   " +
            " client clientname,providerstate STATE,lob lob,project_year programyear,servicelevel servicelevel,   " +
            " OPAF, OptumUpload, OGM, Edata  FROM  (     " +
            " Select  ma.project_year ,ma.providerstate, rs.servicelevel, rs.OwnerUUID,      " +
            "  ma.retrievedby ,  ma.returnednetcna  returnednetcna   ,ma.ClientNameOFCStandard client,ma.lob2 lob   " +
            " from ProgPerf.MemberAssessment ma with (nolock) join rs on  ma.prov_group_id= rs.GroupId and ma.providerstate = rs.State  where     ma.deriveddeployed = 1 and ma.returnednetcna =1 and ma.RecordChangeType != 'deleted'     " +
            " and ma.retrievedby in('OPAF','OptumUpload','OGM','Edata')     and ma.project_year = :ProgramYear  ) AS SourceTable PIVOT(count([returnednetcna]) FOR [retrievedby] IN(OPAF,OptumUpload,OGM,Edata)) AS PivotTable) as src   on (   " +
            " src.State = tgt.State and src.ClientName = tgt.ClientName and src.Lob = tgt.Lob and src.ServiceLevel = tgt.ServiceLevel and   " +
            " src.ProgramYear = tgt.ProgramYear and src.CurrentMonth = tgt.[Month] and tgt.UUID = :OwnerUUID   " +
            " ) when MATCHED THEN update set  tgt.RetrievedByOPAF = src.OPAF,  tgt.RetrievedByOptumUpload = src.OptumUpload,  tgt.RetrievedByOgm = src.OGM,   tgt.RetrievedByEdata = src.Edata,    " +
            "  tgt.UpdatedBy = :UpdatedBy,  tgt.UpdatedDate = GETUTCDATE() , tgt.IsActive=1 WHEN Not MATCHED THEN   INSERT(UUID,State,ClientId,ClientName,LOB,ServiceLevel,ProgramYear,[Month], RetrievedByOPAF,   " +
            " RetrievedByOptumUpload,RetrievedByOgm,RetrievedByEdata,updatedBy,updatedDate,createdDate,createdBy,IsActive)   " +
            " VALUES (:OwnerUUID ,src.State,NULL,src.ClientName,src.Lob,src.ServiceLevel,src.ProgramYear,src.CurrentMonth, src.OPAF,src.OptumUpload, src.OGM,src.Edata, :UpdatedBy,GETUTCDATE() ,GETUTCDATE() ,:UpdatedBy,1);   ";

    String NATIONAL_LEVEL_FOR_ALL_CLIENTS_LOB_REGION_STATE_SERVICE_LEVELS ="Merge ProgPerf.LeaderPerformance as target " +
            " using ( " +
            "SELECT " +
            " 'ALL' as Region, " +
            " 'ALL' as State, " +
            " 'ALL' as ClientName, " +
            " 'ALL' as LobName, " +
            " 'PSC-B,PSC-P,HCA' as servicelevel, " +
            " pgpw.ProgramYear, " +
            " pgpw.DurationValue, " +
            " sum(ReturnedNetCnaYtdActual) ReturnNetCnaActualPerf, " +
           /* " case " +
            "  when sum(DeployYETarget) > 0 then sum(ReturnedNetCnaYtdActual) " +
            "  else NULL " +
            " end ReturnNetCnaActualGoal, " +
            " case " +
            "  when sum(DeployYETarget) > 0 then sum(Completed) " +
            "  else NULL " +
            " end CompletedAssessmentActualGoal, " +
            " case " +
            "  when sum(DeployYETarget) > 0 then sum(DeployYTDActual) " +
            "  else NULL " +
            " end DeployActualGoal, " +*/
            " sum(EligibleDeployableMemberCount) EligibleDeployableMembers, " +
            " sum(ReturnYTDTarget) ReturnGoalYTD, " +
            " sum(ReturnYETarget) ReturnGoalYE, " +
            " sum(DeployYETarget) DeployGoalYE , " +
            " sum(DeployYTDTarget) DeployGoalYTD, " +
            " sum(Rejects) Rejects, " +
            " sum(DeployYTDActual) DeployActualPerf, " +
            " sum(Completed) CompletedAssessmentActualPerf " +
            "from " +
            " ProgPerf.ProviderGroupPerformanceWeekly pgpw with (nolock) , " +
            " ProgPerf.Accounts a " +
            "where " +
            " pgpw.ProviderGroupID = a.groupId " +
            " and pgpw.State = a.State " +
            " and pgpw.DurationValue = :durationValue " +
            " and pgpw.ProgramYear = :programYear " +
            " and LEN(pgpw.State) > 0 " +
            " and LEN(pgpw.LobName)> 0 " +
            " and LEN(pgpw.DurationValue)> 0 " +
            " and LEN(pgpw.ClientName)> 0 " +
            " and LEN(pgpw.ProviderGroupID) > 0 " +
            " and len(pgpw.region) > 0 " +
            " and a .ServiceLevel in ('HCA', 'PSC-P', 'PSC-B') " +
            "GROUP by " +
            " pgpw.ProgramYear, " +
            " pgpw.DurationValue ) src on " +
            "( ISNULL(src.Region, " +
            "'') = ISNULL( target.Region, " +
            "'') " +
            " and src.State = target.State " +
            " and src.ClientName = target.ClientName " +
            " and src.LobName = target.Lob " +
            " and src.ServiceLevel = target.ServiceLevel " +
            " and src.ProgramYear = target.ProgramYear " +
            " and src.DurationValue = target.DurationValue " +
            " and target.UUID = :uuid ) " +
            "when MATCHED THEN " +
            "update " +
            "set " +
            " target.DeployActualPerf = src.DeployActualPerf, " +
            " target.DeployGoalYTD = src.DeployGoalYTD, " +
            " target.DeployGoalYE = src.DeployGoalYE, " +
            " target.ReturnNetCnaActualPerf = src.ReturnNetCnaActualPerf, " +
            " target.ReturnGoalYTD = src.ReturnGoalYTD, " +
            " target.ReturnGoalYE = src.ReturnGoalYE, " +
            " target.CompletedAssessmentActualPerf = src.CompletedAssessmentActualPerf, " +
            " target.EligibleDeployableMembers = src.EligibleDeployableMembers, " +
            " target.Rejects = src.Rejects, " +
            " target.DurationStartDate = :durationStartDate, " +
            " target.DurationEndDate = :durationEndDate, " +
            " target.UpdatedBy = :updatedBy, " +
            " target.IsActive = 1, " +
            " target.UpdatedDate = GETUTCDATE() " +
            " WHEN Not MATCHED THEN " +
            "INSERT " +
            " (UUID, " +
            " Region, " +
            " State, " +
            " ClientId, " +
            " ClientName, " +
            " LOB, " +
            " ServiceLevel, " +
            " ProgramYear, " +
            " DurationValue, " +
            " DurationStartDate, " +
            " DurationEndDate, " +
            " IsCurrentWeek, " +
            " IsActive, " +
            " DeployActualPerf, " +
            " DeployActualGoal, " +
            " DeployGoalYTD, " +
            " DeployGoalYE, " +
            " ReturnNetCnaActualPerf, " +
            " ReturnNetCnaActualGoal, " +
            " ReturnGoalYTD, " +
            " ReturnGoalYE, " +
            " CompletedAssessmentActualPerf, " +
            " CompletedAssessmentActualGoal, " +
            " EligibleDeployableMembers, " +
            " Rejects, " +
            " CGAPClosedSuspect, " +
            " CGAPTotalSuspect , " +
            " updatedBy, " +
            " updatedDate, " +
            " createdDate, " +
            " createdBy) " +
            "VALUES (:uuid , " +
            "src.region, " +
            "src.State, " +
            "NULL , " +
            "src.ClientName, " +
            "src.LobName, " +
            "src.ServiceLevel, " +
            "src.ProgramYear , " +
            ":durationValue, " +
            ":durationStartDate, " +
            ":durationEndDate, " +
            "'1', " +
            "1, " +
            "src.DeployActualPerf, " +
            "NULL, " +
            "src.DeployGoalYTD, " +
            "src.DeployGoalYE, " +
            "src.ReturnNetCnaActualPerf, " +
            "NULL, " +
            "src.ReturnGoalYTD, " +
            "src.ReturnGoalYE, " +
            "src.CompletedAssessmentActualPerf, " +
            "NULL, " +
            "src.EligibleDeployableMembers, " +
            "src.Rejects, " +
            "0, " +
            "0, " +
            ":updatedBy, " +
            "GETUTCDATE() , " +
            "GETUTCDATE() , " +
            ":updatedBy);";

    private static final String IS_ACTIVE_FLAG_FALSE_POC = "update ProgPerf.LeaderGrowthRatePOCEModality set IsActive = 0  " +
            ",UpdatedBy =:UpdatedBy,UpdatedDate =getUtcDate() "+
            " WHERE programyear=:programYear  and [Month] = FORMAT(GETUTCDATE() , 'MMM', 'en-US')" ;
    private static final String IC_RETURNNETCNA_ALL = "   with rs as (SELECT DISTINCT ao.OwnerUUID,a.GroupId,a.State ,a.ServiceLevel , a.UtilizingPOC from ProgPerf.AccountOwner ao  with (nolock) join ProgPerf.Accounts a on a.AccountId = ao.AccountId  where ao.OwnerUUID in( :OwnerUUID) and a.ServiceLevel = :ServiceLevel )  " +
            "  Merge ProgPerf.LeaderGrowthRatePOCEModality as tgt using (     " +
            "    Select rs.OwnerUUID uuid,    " +
            "    FORMAT(GETUTCDATE() ,    " +
            "    'MMM',    " +
            "    'en-US') as CurrentMonth,    " +
            "    'All' clientname,    " +
            "    ma.providerstate STATE,    " +
            "    'All' lob,    " +
            "    ma.project_year programyear,    " +
            "    rs.servicelevel servicelevel,    " +
            "    sum(ma.returnednetcna) returnednetcna    " +
            "    from    " +
            "        ProgPerf.MemberAssessment ma    " +
            "    join rs on    " +
            "        ma.prov_group_id = rs.GroupId and ma.providerstate = rs.State   " +
            "    where    " +
            "        ma.deriveddeployed = 1    " +
            "        and ma.returnednetcna = 1    " +
            "        and ma.RecordChangeType != 'deleted'    " +
            "        and ma.project_year = :ProgramYear        " +
            " group by rs.OwnerUUID,ma.project_year,ma.providerstate,rs.servicelevel,ma.project_year) as src   on (      " +
            " src.State = tgt.State and src.ClientName = tgt.ClientName and src.Lob = tgt.Lob and src.ServiceLevel = tgt.ServiceLevel and      " +
            " src.ProgramYear = tgt.ProgramYear and src.CurrentMonth = tgt.[Month] and tgt.UUID = :OwnerUUID  and tgt.IsActive = 1    " +
            " ) when MATCHED THEN update set       " +
            "  tgt.ReturnNetCnaActualPer = src.returnednetcna,      " +
            "  tgt.UpdatedBy = :UpdatedBy,  tgt.UpdatedDate = GETUTCDATE()  WHEN Not MATCHED THEN  INSERT(UUID,State,ClientId,ClientName,LOB,ServiceLevel,ProgramYear,[Month], ReturnNetCnaActualPer,updatedBy,updatedDate,createdDate,createdBy, IsActive)  " +
            " VALUES (:OwnerUUID ,src.State,NULL,src.ClientName,src.Lob,src.ServiceLevel,src.ProgramYear,src.CurrentMonth,  src.returnednetcna,:UpdatedBy,GETUTCDATE() ,GETUTCDATE() ,:UpdatedBy,1);  ";
    private static final String IC_RETURNNETCNA_FOR_CLIENT_LOB_LEVEL = "   with rs as (SELECT DISTINCT ao.OwnerUUID,a.GroupId,a.State ,a.ServiceLevel , a.UtilizingPOC from ProgPerf.AccountOwner ao  with (nolock) join ProgPerf.Accounts a on a.AccountId = ao.AccountId  where ao.OwnerUUID in( :OwnerUUID) and a.ServiceLevel = :ServiceLevel )  " +
            "  Merge ProgPerf.LeaderGrowthRatePOCEModality as tgt using (     " +
            "    Select rs.OwnerUUID uuid,    " +
            "    FORMAT(GETUTCDATE() ,    " +
            "    'MMM',    " +
            "    'en-US') as CurrentMonth,    " +
            "    ma.ClientNameOFCStandard clientname,    " +
            "    ma.providerstate STATE,    " +
            "    ma.lob2 lob,    " +
            "    ma.project_year programyear,    " +
            "    rs.servicelevel servicelevel,    " +
            "    sum(ma.returnednetcna) returnednetcna    " +
            "    from    " +
            "        ProgPerf.MemberAssessment ma    " +
            "    join rs on    " +
            "        ma.prov_group_id = rs.GroupId and ma.providerstate = rs.State    " +
            "    where    " +
            "        ma.deriveddeployed = 1    " +
            "        and ma.returnednetcna = 1    " +
            "        and ma.RecordChangeType != 'deleted'    " +
            "        and ma.project_year = :ProgramYear        " +
            " group by ma.lob2,ma.ClientNameOFCStandard,rs.OwnerUUID,ma.project_year,ma.providerstate,rs.servicelevel,ma.project_year) as src   on (      " +
            " src.State = tgt.State and src.ClientName = tgt.ClientName and src.Lob = tgt.Lob and src.ServiceLevel = tgt.ServiceLevel and      " +
            " src.ProgramYear = tgt.ProgramYear and src.CurrentMonth = tgt.[Month] and tgt.UUID = :OwnerUUID  and tgt.IsActive = 1    " +
            " ) when MATCHED THEN update set       " +
            "  tgt.ReturnNetCnaActualPer = src.returnednetcna,      " +
            "  tgt.UpdatedBy = :UpdatedBy,  tgt.UpdatedDate = GETUTCDATE()  WHEN Not MATCHED THEN  INSERT(UUID,State,ClientId,ClientName,LOB,ServiceLevel,ProgramYear,[Month], ReturnNetCnaActualPer,updatedBy,updatedDate,createdDate,createdBy, IsActive)  " +
            " VALUES (:OwnerUUID ,src.State,NULL,src.ClientName,src.Lob,src.ServiceLevel,src.ProgramYear,src.CurrentMonth,  src.returnednetcna,:UpdatedBy,GETUTCDATE() ,GETUTCDATE() ,:UpdatedBy,1); ";

    private static final String NATIONAL_GROWTH_RATE_POC_QUERY =
            "Merge ProgPerf.LeaderGrowthRatePOCEModality as tgt using (  " +
            "  SELECT  pge.State, 'All' as ClientName, 'All' as lob,   " +
            " ac.ServiceLevel , FORMAT(GETUTCDATE() , 'MMM', 'en-US') as CurrentMonth,  " +
            " pge.ProgramYear,  " +
            " count(*) as GrowthRateTotalGroups  " +
            " ,sum(case when pge.IsAgreed = 1 then 1 else 0 end ) as AgreedParticipate,  " +
            " sum(case when pge.IsEngaged = 1 then 1 else 0 end ) as EngagedParticipate,  " +
            " sum(case when pge.IsGroupEligibleForPOC = 1 and pge.IsNewForPOC = 0 then 1 else 0 end) as POCExistingTotalGroups,  " +
            " sum(case when ac.UtilizingPOC = 1 and pge.IsGroupEligibleForPOC = 1 and pge.IsNewForPOC = 0 then 1 else 0 end) as POCExistingGroups,  " +
            " sum(case when ac.UtilizingPOC = 1 and pge.IsGroupEligibleForPOC = 1 and pge.IsNewForPOC = 1 then 1 else 0 end) as POCNewGroups,  " +
            " sum(case when pge.IsGroupEligibleForPOC = 1 and pge.IsNewForPOC = 1 then 1 else 0 end) as POCNewTotalGroups  " +
            " from ProgPerf.ProviderGroupExtended pge with (nolock)  " +
            " join ProgPerf.Accounts ac on pge.State= ac.state and pge.ProviderGroupID  = ac.GroupID WHERE LEN(pge.State) > 0  AND LEN(pge.ProviderGroupID) > 0   " +
            " and pge.ProgramYear = :ProgramYear    " +
            " GROUP by pge.State,ac.servicelevel, pge.ProgramYear ) as src  " +
            " on (  " +
            " src.State = tgt.State and  " +
            " src.ClientName = tgt.ClientName and  " +
            " src.Lob = tgt.Lob and  " +
            " src.ServiceLevel = tgt.ServiceLevel and  " +
            " src.ProgramYear = tgt.ProgramYear and  " +
            " src.CurrentMonth = tgt.[Month] and  " +
            " tgt.UUID = :OwnerUUID  " +
            " )   " +
            " when MATCHED THEN   " +
            " update set   " +
            "  tgt.GrowthRateTotalGroups = src.GrowthRateTotalGroups,  " +
            "  tgt.AgreedParticipate = src.AgreedParticipate,  " +
            "  tgt.EngagedParticipate = src.EngagedParticipate,  " +
            "  tgt.POCExistingTotalGroups = src.POCExistingTotalGroups,  " +
            "  tgt.POCExistingGroups = src.POCExistingGroups,  " +
            "  tgt.POCNewTotalGroups = src.POCNewTotalGroups,  " +
            "  tgt.POCNewGroups = src.POCNewGroups,  " +
            "  tgt.UpdatedBy = :UpdatedBy,   " +
            "  tgt.UpdatedDate = GETUTCDATE(),  " +
            "  tgt.IsActive = 1  " +
            " WHEN Not MATCHED THEN  " +
            " INSERT(UUID,State,ClientId,ClientName,LOB,ServiceLevel,ProgramYear,[Month],  " +
            " GrowthRateTotalGroups,AgreedParticipate,EngagedParticipate  " +
            " ,POCExistingTotalGroups,POCExistingGroups,POCNewTotalGroups,POCNewGroups  " +
            "  ,updatedBy,updatedDate,createdDate,createdBy, IsActive)  " +
            " VALUES (:OwnerUUID ,src.State,NULL,src.ClientName,src.Lob,src.ServiceLevel,src.ProgramYear,src.CurrentMonth,  " +
            "        src.GrowthRateTotalGroups,src.AgreedParticipate,src.EngagedParticipate,  " +
            "        src.POCExistingTotalGroups,src.POCExistingGroups,src.POCNewTotalGroups,src.POCNewGroups,  " +
            "       :UpdatedBy,GETUTCDATE() ,GETUTCDATE() ,:UpdatedBy,1);  " ;
    private static final String NATIONAL_RETURN_NET_CNA_QUERY ="Merge ProgPerf.LeaderGrowthRatePOCEModality as tgt    " +
            "    using (    " +
            "Select    " +
            "    FORMAT(GETUTCDATE() ,    " +
            "    'MMM',    " +
            "    'en-US') as CurrentMonth,    " +
            "    ma.ClientNameOFCStandard clientname,    " +
            "    ma.providerstate STATE,    " +
            "    ma.lob2 lob,    " +
            "    ma.project_year programyear,    " +
            "    a.servicelevel servicelevel,    " +
            "    sum(ma.returnednetcna) returnednetcna    " +
            "from    " +
            "    ProgPerf.MemberAssessment ma with (nolock)    " +
            "join ProgPerf.Accounts a with (nolock) on    " +
            "    ma.prov_group_id = a.GroupId    " +
            "    and ma.providerstate = a.State    " +
            "where    " +
            "    ma.deriveddeployed = 1    " +
            "    and ma.returnednetcna = 1    " +
            "    and ma.RecordChangeType <> 'deleted'    " +
            "    and ma.project_year = :ProgramYear    " +
            "group by    " +
            "    ma.project_year,    " +
            "    ma.ClientNameOFCStandard,    " +
            "    ma.lob2,    " +
            "    ma.providerstate,    " +
            "    a.servicelevel,    " +
            "    ma.project_year) as src on    " +
            "( src.State = tgt.State    " +
            "    and tgt.ClientName = src.ClientName    " +
            "    and tgt.Lob = src.Lob    " +
            "    and tgt.ServiceLevel = src.ServiceLevel    " +
            "    and tgt.ProgramYear = src.ProgramYear    " +
            "    and tgt.[Month] = src.CurrentMonth    " +
            "    and tgt.UUID = :OwnerUUID    " +
            "    and tgt.IsActive = 1 )    " +
            "when MATCHED THEN    " +
            "update    " +
            "set    " +
            "    tgt.ReturnNetCnaActualPer = src.returnednetcna,    " +
            "    tgt.UpdatedBy = :UpdatedBy,    " +
            "    tgt.UpdatedDate = GETUTCDATE() " +
            " WHEN Not MATCHED THEN  INSERT(UUID,State,ClientId,ClientName,LOB,ServiceLevel,ProgramYear,[Month], ReturnNetCnaActualPer,updatedBy,updatedDate,createdDate,createdBy, IsActive)  " +
            " VALUES (:OwnerUUID ,src.State,NULL,src.ClientName,src.Lob,src.ServiceLevel,src.ProgramYear,src.CurrentMonth,  src.returnednetcna,:UpdatedBy,GETUTCDATE() ,GETUTCDATE() ,:UpdatedBy,1);  " ;
    private static final String NATIONAL_EMODALITY_FOR_ALL_LEVEL = "    Merge ProgPerf.LeaderGrowthRatePOCEModality as tgt using (      " +
            "  SELECT OwnerUUID uuid, FORMAT(GETUTCDATE() , 'MMM', 'en-US') as CurrentMonth,      " +
            " 'All' clientname,providerstate STATE,'All' lob,project_year programyear,servicelevel servicelevel,      " +
            " OPAF, OptumUpload, OGM, Edata  FROM  (        " +
            " Select  ma.project_year ,ma.providerstate, ac.servicelevel, :OwnerUUID as OwnerUUID,         " +
            "  ma.retrievedby ,  ma.returnednetcna  returnednetcna        " +
            " from ProgPerf.MemberAssessment ma     " +
            " join ProgPerf.Accounts ac on ma.prov_group_id = ac.GroupID and  ma.providerstate = ac.State  " +
            "   where         " +
            " ma.deriveddeployed = 1 and ma.returnednetcna =1 and ma.RecordChangeType != 'deleted'        " +
            " and ma.retrievedby in('OPAF','OptumUpload','OGM','Edata')        " +
            " and ma.project_year = :ProgramYear        " +
            " ) AS SourceTable PIVOT(count([returnednetcna]) FOR [retrievedby] IN(OPAF,OptumUpload,OGM,Edata)) AS PivotTable) as src   on (      " +
            " src.State = tgt.State and src.ClientName = tgt.ClientName and src.Lob = tgt.Lob and src.ServiceLevel = tgt.ServiceLevel and      " +
            " src.ProgramYear = tgt.ProgramYear and src.CurrentMonth = tgt.[Month] and tgt.UUID = :OwnerUUID      " +
            " ) when MATCHED THEN update set       " +
            "  tgt.RetrievedByOPAF = src.OPAF,      " +
            "  tgt.RetrievedByOptumUpload = src.OptumUpload,      " +
            "  tgt.RetrievedByOgm = src.OGM,      " +
            "  tgt.RetrievedByEdata = src.Edata,       " +
            "  tgt.UpdatedBy = :UpdatedBy,  tgt.UpdatedDate = GETUTCDATE(), tgt.IsActive=1     " +
            " WHEN Not MATCHED THEN   INSERT(UUID,State,ClientId,ClientName,LOB,ServiceLevel,ProgramYear,[Month], RetrievedByOPAF,      " +
            " RetrievedByOptumUpload,RetrievedByOgm,RetrievedByEdata,updatedBy,updatedDate,createdDate,createdBy,IsActive)      " +
            " VALUES (:OwnerUUID ,src.State,NULL,src.ClientName,src.Lob,src.ServiceLevel,src.ProgramYear,src.CurrentMonth,      " +
            "        src.OPAF,src.OptumUpload, src.OGM,src.Edata, :UpdatedBy,GETUTCDATE() ,GETUTCDATE() ,:UpdatedBy,1);  ";
    private static final String NATIONAL_EMODALITY_FOR_CLIENT_LOB_LEVEL = "Merge ProgPerf.LeaderGrowthRatePOCEModality as tgt  " +
            "    using (  " +
            "SELECT  " +
            "    OwnerUUID uuid,  " +
            "    FORMAT(GETUTCDATE() ,  " +
            "    'MMM',  " +
            "    'en-US') as CurrentMonth,  " +
            "    client clientname,  " +
            "    providerstate STATE,  " +
            "    lob lob,  " +
            "    project_year programyear,  " +
            "    servicelevel servicelevel,  " +
            "    OPAF,  " +
            "    OptumUpload,  " +
            "    OGM,  " +
            "    Edata  " +
            "FROM  " +
            "    (  " +
            "    Select  " +
            "        ma.project_year ,  " +
            "        ma.providerstate,  " +
            "        ac.servicelevel,  " +
            "        :OwnerUUID as OwnerUUID,  " +
            "        ma.retrievedby ,  " +
            "        ma.returnednetcna returnednetcna ,  " +
            "        ma.ClientNameOFCStandard client,  " +
            "        ma.lob2 lob  " +
            "    from  " +
            "        ProgPerf.MemberAssessment ma with (nolock)  " +
            "    join ProgPerf.Accounts ac on  " +
            "        ma.prov_group_id = ac.GroupID  and  ma.providerstate = ac.State    " +
            "    where  " +
            "        ma.deriveddeployed = 1  " +
            "        and ma.returnednetcna = 1  " +
            "        and ma.RecordChangeType != 'deleted'  " +
            "        and ma.retrievedby in('OPAF', 'OptumUpload', 'OGM', 'Edata')  " +
            "            and ma.project_year = :ProgramYear ) AS SourceTable PIVOT(count([returnednetcna]) FOR [retrievedby] IN(OPAF, OptumUpload, OGM, Edata)) AS PivotTable) as src on  " +
            "(     " +
            " src.State = tgt.State  " +
            "    and src.ClientName = tgt.ClientName  " +
            "    and src.Lob = tgt.Lob  " +
            "    and src.ServiceLevel = tgt.ServiceLevel  " +
            "    and     " +
            " src.ProgramYear = tgt.ProgramYear  " +
            "    and src.CurrentMonth = tgt.[Month]  " +
            "    and tgt.UUID = :OwnerUUID     " +
            " )  " +
            "when MATCHED THEN  " +
            "update  " +
            "set  " +
            "    tgt.RetrievedByOPAF = src.OPAF,  " +
            "    tgt.RetrievedByOptumUpload = src.OptumUpload,  " +
            "    tgt.RetrievedByOgm = src.OGM,  " +
            "    tgt.RetrievedByEdata = src.Edata,  " +
            "    tgt.UpdatedBy = :UpdatedBy,  " +
            "    tgt.UpdatedDate = GETUTCDATE() ,  " +
            "    tgt.IsActive = 1  " +
            "    WHEN Not MATCHED THEN  " +
            "INSERT  " +
            "    (UUID,  " +
            "    State,  " +
            "    ClientId,  " +
            "    ClientName,  " +
            "    LOB,  " +
            "    ServiceLevel,  " +
            "    ProgramYear,  " +
            "    [Month],  " +
            "    RetrievedByOPAF,  " +
            "    RetrievedByOptumUpload,  " +
            "    RetrievedByOgm,  " +
            "    RetrievedByEdata,  " +
            "    updatedBy,  " +
            "    updatedDate,  " +
            "    createdDate,  " +
            "    createdBy,  " +
            "    IsActive)  " +
            "VALUES (:OwnerUUID ,  " +
            "src.State,  " +
            "NULL,  " +
            "src.ClientName,  " +
            "src.Lob,  " +
            "src.ServiceLevel,  " +
            "src.ProgramYear,  " +
            "src.CurrentMonth,  " +
            "src.OPAF,  " +
            "src.OptumUpload,  " +
            "src.OGM,  " +
            "src.Edata,  " +
            ":UpdatedBy,  " +
            "GETUTCDATE() ,  " +
            "GETUTCDATE() ,  " +
            ":UpdatedBy,  " +
            "1);     ";

    private static final String RETURNED_NET_CNA_FOR_ALL_QUERY = "  Merge ProgPerf.LeaderGrowthRatePOCEModality as tgt using (        " +
            "Select   FORMAT(GETUTCDATE() , 'MMM', 'en-US') as CurrentMonth,   'All' clientname,  ma.providerstate STATE,  'All' lob, ma.project_year programyear, a.servicelevel servicelevel,   sum(ma.returnednetcna) returnednetcna        " +
            "from   ProgPerf.MemberAssessment ma with (nolock) join ProgPerf.Accounts a with (nolock) on     ma.prov_group_id = a.GroupId  and ma.providerstate = a.State        " +
            "where  ma.deriveddeployed = 1  and ma.returnednetcna = 1   and ma.RecordChangeType <> 'deleted'     and ma.project_year = :ProgramYear        " +
            "group by     ma.project_year,  ma.providerstate,      a.servicelevel,    ma.project_year) as src on        " +
            "( tgt.State = src.State   and tgt.ClientName = src.ClientName   and tgt.Lob = src.Lob     and tgt.ServiceLevel = src.ServiceLevel        " +
            "    and tgt.ProgramYear = src.ProgramYear  and tgt.[Month] = src.CurrentMonth        " +
            "    and tgt.UUID = :OwnerUUID  and tgt.IsActive = 1 )        " +
            "when MATCHED THEN  update  set   tgt.ReturnNetCnaActualPer = src.returnednetcna, tgt.UpdatedBy = :UpdatedBy, tgt.UpdatedDate = GETUTCDATE()  WHEN Not MATCHED THEN  INSERT(UUID,State,ClientId,ClientName,LOB,ServiceLevel,ProgramYear,[Month], ReturnNetCnaActualPer,updatedBy,updatedDate,createdDate,createdBy, IsActive)  " +
            " VALUES (:OwnerUUID ,src.State,NULL,src.ClientName,src.Lob,src.ServiceLevel,src.ProgramYear,src.CurrentMonth,  src.returnednetcna,:UpdatedBy,GETUTCDATE() ,GETUTCDATE() ,:UpdatedBy,1); " ;

    private static final String REGION_STATE_CGAP_SUSPECT_COUNT = "Merge ProgPerf.LeaderPerformance as target " +
            "using ( " +
            "SELECT " +
            "pgp1.State, " +
            "pgp1.Region, " +
            "pgp1.ClientName, " +
            "pgp1.LobName, " +
            "a1.servicelevel, " +
            "pgp1.ProgramYear, " +
            "pgp1.DurationValue, " +
            "sum(cc.RiskDXVerified + cc.RiskNoDXAttestation + cc.RiskReferred) as CGAPClosedSuspect , " +
            "sum(cc.TotalSuspects) as CGAPTotalSuspect " +
            "FROM " +
            "ProgPerf.ProviderGroupPerformanceWeekly pgp1, " +
            "ProgPerf.CGapClosure cc , " +
            "ProgPerf.Accounts a1 " +
            "where " +
            "pgp1.DurationValue = :durationValue " +
            "and pgp1.ProgramYear = :programYear " +
            "and pgp1 .ProviderGroupID =cc.ProviderGroupId " +
            "and pgp1.State =cc.ProviderState " +
            "and pgp1.Clientname =cc.Clientname " +
            "and pgp1.LobName =cc.LOB " +
            "and pgp1.ProgramYear=cc.ProgramYear " +
            "and pgp1.ProviderGroupID = a1.groupId " +
            "and pgp1.State = a1.State " +
            "and a1 .ServiceLevel in ( " +
            "select " +
            "distinct ServiceLevel " +
            "from " +
            "ProgPerf.Accounts a " +
            "where " +
            "ServiceLevel <> '' " +
            "AND ServiceLevel is not NULL) " +
            "GROUP by " +
            "pgp1.State, " +
            "pgp1.Region, " +
            "pgp1.ClientName, " +
            "pgp1.LobName, " +
            "a1.servicelevel, " +
            "pgp1.ProgramYear, " +
            "pgp1.DurationValue) src on " +
            "( ISNULL(src.Region, " +
            "'') = ISNULL( target.Region, " +
            "'') " +
            "and src.State = target.State " +
            "and src.ClientName = target.ClientName " +
            "and src.LobName = target.Lob " +
            "and src.ServiceLevel = target.ServiceLevel " +
            "and src.ProgramYear = target.ProgramYear " +
            "and src.DurationValue = target.DurationValue " +
            "and target.UUID = :uuid ) " +
            "when MATCHED THEN " +
            "update " +
            "set " +
            "target.CGAPClosedSuspect = src.CGAPClosedSuspect, " +
            "target.CGAPTotalSuspect = src.CGAPTotalSuspect, " +
            "target.UpdatedBy = :updatedBy, " +
            "target.IsActive =1, " +
            "target.UpdatedDate = GETUTCDATE(); ";
    private static final String NATIONAL_CGAP_SUSPECT_COUNT = "Merge ProgPerf.LeaderPerformance as target  " +
            "using (  " +
            "SELECT  " +
            "'ALL' as Region,  " +
            "'ALL' as State,  " +
            "'ALL' as ClientName,  " +
            "'ALL' as LobName,  " +
            "'PSC-B,PSC-P,HCA' as servicelevel,  " +
            "pgpw.ProgramYear,  " +
            "pgpw.DurationValue,  " +
            "sum(cc.RiskDXVerified + cc.RiskNoDXAttestation + cc.RiskReferred) as CGAPClosedSuspect ,  " +
            "sum(cc.TotalSuspects) as CGAPTotalSuspect  " +
            "from  " +
            "ProgPerf.ProviderGroupPerformanceWeekly pgpw with (nolock) ,  " +
            "ProgPerf.Accounts a ,  " +
            "ProgPerf.CGapClosure cc  " +
            "where  " +
            "pgpw.ProviderGroupID = a.groupId  " +
            "and pgpw.State = a.State  " +
            "and pgpw.DurationValue = :durationValue  " +
            "and pgpw.ProgramYear = :programYear  " +
            "and LEN(pgpw.State) > 0  " +
            "and LEN(pgpw.LobName)> 0  " +
            "and LEN(pgpw.DurationValue)> 0  " +
            "and LEN(pgpw.ClientName)> 0  " +
            "and LEN(pgpw.ProviderGroupID) > 0  " +
            "and len(pgpw.region) > 0  " +
            "and a .ServiceLevel in ('HCA', 'PSC-P', 'PSC-B')  " +
            "and pgpw.ProviderGroupID = cc.ProviderGroupId  " +
            "and pgpw.State = cc.ProviderState  " +
            "and pgpw.ProgramYear = cc.ProgramYear  " +
            "and pgpw.ClientName =cc.clientname  " +
            "and pgpw .LobName = cc.lob  " +
            "GROUP by  " +
            "pgpw.ProgramYear,  " +
            "pgpw.DurationValue  ) src on  " +
            "( ISNULL(src.Region,  " +
            "'') = ISNULL( target.Region,  " +
            "'')  " +
            "and src.State = target.State  " +
            "and src.ClientName = target.ClientName  " +
            "and src.LobName = target.Lob  " +
            "and src.ServiceLevel = target.ServiceLevel  " +
            "and src.ProgramYear = target.ProgramYear  " +
            "and src.DurationValue = target.DurationValue  " +
            "and target.UUID = :uuid )  " +
            "when MATCHED THEN  " +
            "update  " +
            "set  " +
            "target.CGAPClosedSuspect = src.CGAPClosedSuspect,  " +
            "target.CGAPTotalSuspect = src.CGAPTotalSuspect,  " +
            "target.UpdatedBy = :updatedBy,  " +
            "target.IsActive = 1,  " +
            "target.UpdatedDate = GETUTCDATE() ;  ";

    private static final String NATIONAL_ALL_LEVEL_GOAL_CALC_QUERY ="Merge ProgPerf.LeaderPerformance as target " +
            " using ( " +
            "SELECT " +
            " 'ALL' as Region, " +
            " 'ALL' as State, " +
            " 'ALL' as ClientName, " +
            " 'ALL' as LobName, " +
            " 'PSC-B,PSC-P,HCA' as servicelevel, " +
            " sum(DeployYTDActual) DeployActualGoal, " +
            " sum(Completed) CompletedAssessmentActualGoal, " +
            " sum(ReturnedNetCnaYtdActual) ReturnNetCnaActualGoal " +
            "from " +
            " ProgPerf.ProviderGroupPerformanceWeekly pgpw with (nolock) , " +
            " ProgPerf.Accounts a " +
            "where " +
            " pgpw.ProviderGroupID = a.groupId " +
            " and pgpw.State = a.State " +
            " and pgpw.DurationValue = :DurationValue " +
            " and pgpw.ProgramYear = :ProgramYear " +
            " and LEN(pgpw.State) > 0 " +
            " and LEN(pgpw.LobName)> 0 " +
            " and LEN(pgpw.DurationValue)> 0 " +
            " and LEN(pgpw.ClientName)> 0 " +
            " and LEN(pgpw.ProviderGroupID) > 0 " +
            " and len(pgpw.region) > 0 " +
            " and pgpw.IsIDMTarget = 1 " +
            " and a.ServiceLevel in ('HCA', 'PSC-P', 'PSC-B')) src on " +
            "( ISNULL(src.Region, " +
            "'') = ISNULL( target.Region, " +
            "'') " +
            " and src.State = target.State " +
            " and src.ClientName = target.ClientName " +
            " and src.LobName = target.Lob " +
            " and src.ServiceLevel = target.ServiceLevel " +
            " and target.ProgramYear =:ProgramYear " +
            " and  target.DurationValue =:DurationValue " +
            " and target.UUID = :OwnerUUID ) " +
            "when MATCHED THEN " +
            "update " +
            "set " +
            " target.ReturnNetCnaActualGoal = src.ReturnNetCnaActualGoal, " +
            " target.DeployActualGoal = src.DeployActualGoal , " +
            " target.CompletedAssessmentActualGoal = src.CompletedAssessmentActualGoal ; ";
    
    private String NATIONAL_LEVEL_GOAL_UPDATE ="Merge ProgPerf.LeaderPerformance as target  " +
            " using (  " +
            "SELECT  " +
            " pgpw.Region,  " +
            " pgpw.State,  " +
            " pgpw.ClientName,  " +
            " pgpw.LobName,  " +
            " a.servicelevel,  " +
            " pgpw.ProgramYear,  " +
            " pgpw.DurationValue, " +
            " sum(DeployYTDActual) DeployActualGoal, " +
            " sum(ReturnedNetCnaYtdActual) ReturnNetCnaActualGoal, " +
            " sum(Completed) CompletedAssessmentActualGoal " +
            "from  " +
            " ProgPerf.ProviderGroupPerformanceWeekly pgpw with (nolock) ,  " +
            " ProgPerf.Accounts a  " +
            "where  " +
            " pgpw.ProviderGroupID = a.groupId  " +
            " and pgpw.State = a.State  " +
            " and pgpw.DurationValue = :DurationValue  " +
            " and pgpw.ProgramYear = :ProgramYear  " +
            " and LEN(pgpw.State) > 0  " +
            " and LEN(pgpw.LobName)> 0  " +
            " and LEN(pgpw.DurationValue)> 0  " +
            " and LEN(pgpw.ClientName)> 0  " +
            " and LEN(pgpw.ProviderGroupID) > 0  " +
            " and len(pgpw.region) > 0  " +
            " and pgpw.IsIDMTarget =1 "+
            " and a .ServiceLevel in (  " +
            " select  " +
            "  distinct ServiceLevel  " +
            " from  " +
            "  ProgPerf.Accounts a  " +
            " where  " +
            "  ServiceLevel <> ''  " +
            "  AND ServiceLevel is not NULL)  " +
            "GROUP by  " +
            " pgpw.State,  " +
            " pgpw.Region,  " +
            " pgpw.ClientName,  " +
            " pgpw.LobName,  " +
            " a.servicelevel,  " +
            " pgpw.ProgramYear,  " +
            " pgpw.DurationValue) src on  " +
            "( ISNULL(src.Region,  " +
            "'') = ISNULL( target.Region,  " +
            "'')  " +
            " and src.State = target.State  " +
            " and src.ClientName = target.ClientName  " +
            " and src.LobName = target.Lob  " +
            " and src.ServiceLevel = target.ServiceLevel  " +
            " and src.ProgramYear = target.ProgramYear  " +
            " and src.DurationValue = target.DurationValue  " +
            " and target.UUID = :OwnerUUID )  " +
            "when MATCHED THEN  " +
            "update  " +
            "set  " +
            " target.ReturnNetCnaActualGoal = src.ReturnNetCnaActualGoal,  " +
            " target.DeployActualGoal = src.DeployActualGoal ,  " +
            " target.CompletedAssessmentActualGoal = src.CompletedAssessmentActualGoal ,  " +
            " target.UpdatedBy = :UpdatedBy,  " +
            " target.UpdatedDate = GETUTCDATE(); ";

    private static final String IC_RETURNNETCNA_ALL_HISTORICAL = "   with rs as (SELECT DISTINCT ao.OwnerUUID,a.GroupId,a.State ,a.ServiceLevel , a.UtilizingPOC from ProgPerf.AccountOwner ao  with (nolock) join ProgPerf.Accounts a on a.AccountId = ao.AccountId  where ao.OwnerUUID in( :OwnerUUID) and a.ServiceLevel = :ServiceLevel )  " +
            "  Merge ProgPerf.LeaderGrowthRatePOCEModality as tgt using (     " +
            "    Select rs.OwnerUUID uuid,    " +
            "     :Month as CurrentMonth,    " +
            "    'All' clientname,    " +
            "    ma.providerstate STATE,    " +
            "    'All' lob,    " +
            "    ma.project_year programyear,    " +
            "    rs.servicelevel servicelevel,    " +
            "    sum(ma.returnednetcna) returnednetcna    " +
            "    from    " +
            "        ProgPerf.MemberAssessment ma    " +
            "    join rs on    " +
            "        ma.prov_group_id = rs.GroupId and ma.providerstate = rs.State   " +
            "    where    " +
            "        ma.deriveddeployed = 1    " +
            "        and ma.returnednetcna = 1    " +
            "        and ma.RecordChangeType != 'deleted'    " +
            "        and ma.project_year = :ProgramYear        " +
            "  and ma.retrieval_date <=:DurationEndDate " +
            " group by rs.OwnerUUID,ma.project_year,ma.providerstate,rs.servicelevel,ma.project_year) as src   on (      " +
            " src.State = tgt.State and src.ClientName = tgt.ClientName and src.Lob = tgt.Lob and src.ServiceLevel = tgt.ServiceLevel and      " +
            " src.ProgramYear = tgt.ProgramYear and src.CurrentMonth = tgt.[Month] and tgt.UUID = :OwnerUUID  and tgt.IsActive = 1    " +
            " ) when MATCHED THEN update set       " +
            "  tgt.ReturnNetCnaActualPer = src.returnednetcna,      " +
            "  tgt.UpdatedBy = :UpdatedBy,  tgt.UpdatedDate = GETUTCDATE()  WHEN Not MATCHED THEN  INSERT(UUID,State,ClientId,ClientName,LOB,ServiceLevel,ProgramYear,[Month], ReturnNetCnaActualPer,updatedBy,updatedDate,createdDate,createdBy, IsActive)  " +
            " VALUES (:OwnerUUID ,src.State,NULL,src.ClientName,src.Lob,src.ServiceLevel,src.ProgramYear,src.CurrentMonth,  src.returnednetcna,:UpdatedBy,GETUTCDATE() ,GETUTCDATE() ,:UpdatedBy,1);  ";
    private static final String RETURNED_NET_CNA_FOR_ALL_QUERY_HISTORICAL = "  Merge ProgPerf.LeaderGrowthRatePOCEModality as tgt using (        " +
            "Select   :Month as CurrentMonth,   'All' clientname,  ma.providerstate STATE,  'All' lob, ma.project_year programyear, a.servicelevel servicelevel,   sum(ma.returnednetcna) returnednetcna        " +
            "from   ProgPerf.MemberAssessment ma with (nolock) join ProgPerf.Accounts a with (nolock) on     ma.prov_group_id = a.GroupId  and ma.providerstate = a.State        " +
            "where  ma.deriveddeployed = 1  and ma.returnednetcna = 1   and ma.RecordChangeType <> 'deleted'     and ma.project_year = :ProgramYear        " +
            " and ma.retrieval_date <=:DurationEndDate " +
            "group by   ma.project_year,  ma.providerstate,      a.servicelevel,    ma.project_year) as src on        " +
            "( tgt.State = src.State   and tgt.ClientName = src.ClientName   and tgt.Lob = src.Lob     and tgt.ServiceLevel = src.ServiceLevel        " +
            "    and tgt.ProgramYear = src.ProgramYear  and tgt.[Month] = src.CurrentMonth        " +
            "    and tgt.UUID = :OwnerUUID  and tgt.IsActive = 1 )        " +
            "when MATCHED THEN  update  set   tgt.ReturnNetCnaActualPer = src.returnednetcna, tgt.UpdatedBy = :UpdatedBy, tgt.UpdatedDate = GETUTCDATE()  WHEN Not MATCHED THEN  INSERT(UUID,State,ClientId,ClientName,LOB,ServiceLevel,ProgramYear,[Month], ReturnNetCnaActualPer,updatedBy,updatedDate,createdDate,createdBy, IsActive)  " +
            " VALUES (:OwnerUUID ,src.State,NULL,src.ClientName,src.Lob,src.ServiceLevel,src.ProgramYear,src.CurrentMonth,  src.returnednetcna,:UpdatedBy,GETUTCDATE() ,GETUTCDATE() ,:UpdatedBy,1); " ;
    private static final String IC_RETURNNETCNA_FOR_CLIENT_LOB_LEVEL_HISTORICAL = "   with rs as (SELECT DISTINCT ao.OwnerUUID,a.GroupId,a.State ,a.ServiceLevel , a.UtilizingPOC from ProgPerf.AccountOwner ao  with (nolock) join ProgPerf.Accounts a on a.AccountId = ao.AccountId  where ao.OwnerUUID in( :OwnerUUID) and a.ServiceLevel = :ServiceLevel )  " +
            "  Merge ProgPerf.LeaderGrowthRatePOCEModality as tgt using (     " +
            "    Select rs.OwnerUUID uuid,    " +
            "    :Month as CurrentMonth, " +
            "    ma.ClientNameOFCStandard clientname,    " +
            "    ma.providerstate STATE,    " +
            "    ma.lob2 lob,    " +
            "    ma.project_year programyear,    " +
            "    rs.servicelevel servicelevel,    " +
            "    sum(ma.returnednetcna) returnednetcna    " +
            "    from    " +
            "        ProgPerf.MemberAssessment ma    " +
            "    join rs on    " +
            "        ma.prov_group_id = rs.GroupId and ma.providerstate = rs.State    " +
            "    where    " +
            "        ma.deriveddeployed = 1    " +
            "        and ma.returnednetcna = 1    " +
            "        and ma.RecordChangeType != 'deleted'    " +
            "        and ma.project_year = :ProgramYear        " +
            " and ma.retrieval_date <=:DurationEndDate "+
            " group by ma.lob2,ma.ClientNameOFCStandard,rs.OwnerUUID,ma.project_year,ma.providerstate,rs.servicelevel,ma.project_year) as src   on (      " +
            " src.State = tgt.State and src.ClientName = tgt.ClientName and src.Lob = tgt.Lob and src.ServiceLevel = tgt.ServiceLevel and      " +
            " src.ProgramYear = tgt.ProgramYear and src.CurrentMonth = tgt.[Month] and tgt.UUID = :OwnerUUID  and tgt.IsActive = 1    " +
            " ) when MATCHED THEN update set       " +
            "  tgt.ReturnNetCnaActualPer = src.returnednetcna,      " +
            "  tgt.UpdatedBy = :UpdatedBy,  tgt.UpdatedDate = GETUTCDATE()  WHEN Not MATCHED THEN  INSERT(UUID,State,ClientId,ClientName,LOB,ServiceLevel,ProgramYear,[Month], ReturnNetCnaActualPer,updatedBy,updatedDate,createdDate,createdBy, IsActive)  " +
            " VALUES (:OwnerUUID ,src.State,NULL,src.ClientName,src.Lob,src.ServiceLevel,src.ProgramYear,src.CurrentMonth,  src.returnednetcna,:UpdatedBy,GETUTCDATE() ,GETUTCDATE() ,:UpdatedBy,1); ";


    private static final String LEADER_GROWTH_RATE_POC_QUERY_HISTORICAL = "Merge ProgPerf.LeaderGrowthRatePOCEModality as tgt" +
            " using (" +
            "  SELECT State,  ClientName, lob, servicelevel, [Month] as CurrentMonth, ProgramYear" +
            "  ,sum(GrowthRateTotalGroups) as GrowthRateTotalGroups," +
            " sum(AgreedParticipate) as AgreedParticipate," +
            " sum(EngagedParticipate) as EngagedParticipate," +
            " sum(POCExistingTotalGroups) as POCExistingTotalGroups," +
            " sum(POCExistingGroups) as POCExistingGroups," +
            " sum(POCNewTotalGroups) as POCNewTotalGroups," +
            " sum(POCNewGroups) as POCNewGroups, " +
            " sum(RetrievedByOPAF) as RetrievedByOPAF, " +
            " sum(RetrievedByOptumUpload) as RetrievedByOptumUpload, " +
            " sum(RetrievedByOgm) as RetrievedByOgm, " +
            " sum(RetrievedByEdata) as RetrievedByEdata, sum(ReturnNetCnaActualPer) as ReturnNetCnaActualPer "+
            " from ProgPerf.LeaderGrowthRatePOCEModality pge with (nolock)" +
            " WHERE LEN(pge.State) > 0  and LEN(pge.ClientName)>0 and LEN(pge.LOB) >0 and LEN(pge.ServiceLevel)> 0" +
            " and pge.UUID in (:Reporters) and pge.ProgramYear = :ProgramYear and pge.isActive=1 and pge.[Month] =:Month " +
            " GROUP by pge.State,pge.ClientName,pge.servicelevel,pge.LOB,pge.[Month] , pge.ProgramYear" +
            " ) as src" +
            " on (" +
            " tgt.State = src.State and" +
            " tgt.ClientName = src.ClientName and" +
            " tgt.Lob = src.Lob and" +
            " tgt.ServiceLevel = src.ServiceLevel and" +
            " tgt.ProgramYear = src.ProgramYear and" +
            " tgt.[Month] = src.CurrentMonth and" +
            " tgt.UUID = :OwnerUUID" +
            " ) " +
            " when MATCHED  THEN " +
            " update set " +
            "  tgt.GrowthRateTotalGroups = src.GrowthRateTotalGroups," +
            "  tgt.AgreedParticipate = src.AgreedParticipate," +
            "  tgt.EngagedParticipate = src.EngagedParticipate," +
            "  tgt.POCExistingTotalGroups = src.POCExistingTotalGroups," +
            "  tgt.POCExistingGroups = src.POCExistingGroups," +
            "  tgt.POCNewTotalGroups = src.POCNewTotalGroups," +
            "  tgt.POCNewGroups = src.POCNewGroups," +
            "  tgt.RetrievedByOPAF = src.RetrievedByOPAF, " +
            "  tgt.RetrievedByOptumUpload = src.RetrievedByOptumUpload, " +
            "  tgt.RetrievedByOgm = src.RetrievedByOgm, " +
            "  tgt.RetrievedByEdata = src.RetrievedByEdata, " +
            "  tgt.UpdatedBy = :UpdatedBy, " +
            "  tgt.UpdatedDate = GETUTCDATE(), tgt.ReturnNetCnaActualPer=src.ReturnNetCnaActualPer," +
            "  tgt.IsActive = 1" +
            " WHEN Not MATCHED THEN" +
            " INSERT(UUID,State,ClientId,ClientName,LOB,ServiceLevel,ProgramYear,[Month]," +
            " GrowthRateTotalGroups,AgreedParticipate,EngagedParticipate" +
            " ,POCExistingTotalGroups,POCExistingGroups,POCNewTotalGroups,POCNewGroups" +
            " ,RetrievedByOPAF,RetrievedByOptumUpload,RetrievedByOgm,RetrievedByEdata" +
            "  ,updatedBy,updatedDate,createdDate,createdBy, IsActive,ReturnNetCnaActualPer)" +
            " VALUES (:OwnerUUID ,src.State,NULL,src.ClientName,src.Lob,src.ServiceLevel,src.ProgramYear,src.CurrentMonth," +
            "        src.GrowthRateTotalGroups,src.AgreedParticipate,src.EngagedParticipate," +
            "        src.POCExistingTotalGroups,src.POCExistingGroups,src.POCNewTotalGroups,src.POCNewGroups," +
            " src.RetrievedByOPAF,src.RetrievedByOptumUpload,src.RetrievedByOgm,src.RetrievedByEdata," +
            "       :UpdatedBy,GETUTCDATE() ,GETUTCDATE() ,:UpdatedBy,1,src.ReturnNetCnaActualPer);";



    String LEADER_GROWTH_RATE_POC_FOR_ALL_QUERY_HISTORICAL = "Merge ProgPerf.LeaderGrowthRatePOCEModality as tgt  " +
            " using (  " +
            "  SELECT 'All' as state, 'All' as Region, ClientName, lob, servicelevel, [Month] as CurrentMonth, ProgramYear  " +
            "  ,sum(GrowthRateTotalGroups) as GrowthRateTotalGroups,  " +
            " sum(AgreedParticipate) as AgreedParticipate,  " +
            " sum(EngagedParticipate) as EngagedParticipate,  " +
            " sum(POCExistingTotalGroups) as POCExistingTotalGroups,  " +
            " sum(POCExistingGroups) as POCExistingGroups,  " +
            " sum(POCNewTotalGroups) as POCNewTotalGroups,  " +
            " sum(POCNewGroups) as POCNewGroups,   " +
            " sum(RetrievedByOPAF) as RetrievedByOPAF,   " +
            " sum(RetrievedByOptumUpload) as RetrievedByOptumUpload,   " +
            " sum(RetrievedByOgm) as RetrievedByOgm,   " +
            " sum(RetrievedByEdata) as RetrievedByEdata ,sum(ReturnNetCnaActualPer) as ReturnNetCnaActualPer  " +
            " from ProgPerf.LeaderGrowthRatePOCEModality pge with (nolock)  " +
            " WHERE LEN(pge.State) > 0  and LEN(pge.ClientName)>0 and LEN(pge.LOB) >0 and LEN(pge.ServiceLevel)> 0  " +
            " and pge.UUID in (:Reporters) and pge.ProgramYear = :ProgramYear  and pge.ClientName  = 'All' and pge.lob = 'All' and pge.state != 'All' and  (pge.Region !='All' or pge.Region is Null) and pge.isActive=1 and pge.[Month] =:Month  " +
            " GROUP by pge.ClientName,pge.servicelevel,pge.LOB,pge.[Month] , pge.ProgramYear  " +
            " ) as src  " +
            " on (  " +
            " tgt.State = src.State and  " +
            " tgt.ClientName = src.ClientName and  " +
            " tgt.Lob = src.Lob and  " +
            " tgt.ServiceLevel = src.ServiceLevel and  " +
            " tgt.ProgramYear = src.ProgramYear and  " +
            " tgt.[Month] = src.CurrentMonth and  " +
            " tgt.UUID = :OwnerUUID  " +
            " )   " +
            " when MATCHED  THEN   " +
            " update set   " +
            "  tgt.GrowthRateTotalGroups = src.GrowthRateTotalGroups,  " +
            "  tgt.AgreedParticipate = src.AgreedParticipate,  " +
            "  tgt.EngagedParticipate = src.EngagedParticipate,  " +
            "  tgt.POCExistingTotalGroups = src.POCExistingTotalGroups,  " +
            "  tgt.POCExistingGroups = src.POCExistingGroups,  " +
            "  tgt.POCNewTotalGroups = src.POCNewTotalGroups,  " +
            "  tgt.POCNewGroups = src.POCNewGroups,  " +
            "  tgt.RetrievedByOPAF = src.RetrievedByOPAF,   " +
            "  tgt.RetrievedByOptumUpload = src.RetrievedByOptumUpload,   " +
            "  tgt.RetrievedByOgm = src.RetrievedByOgm,   " +
            "  tgt.RetrievedByEdata = src.RetrievedByEdata,   " +
            "  tgt.UpdatedBy = :UpdatedBy,   " +
            "  tgt.UpdatedDate = GETUTCDATE(),  tgt.Region =src.Region, " +
            "  tgt.IsActive = 1 ,tgt.ReturnNetCnaActualPer = src.ReturnNetCnaActualPer " +
            " WHEN Not MATCHED THEN  " +
            " INSERT(UUID,Region,State,ClientId,ClientName,LOB,ServiceLevel,ProgramYear,[Month],  " +
            " GrowthRateTotalGroups,AgreedParticipate,EngagedParticipate  " +
            " ,POCExistingTotalGroups,POCExistingGroups,POCNewTotalGroups,POCNewGroups  " +
            " ,RetrievedByOPAF,RetrievedByOptumUpload,RetrievedByOgm,RetrievedByEdata  " +
            "  ,updatedBy,updatedDate,createdDate,createdBy, IsActive,ReturnNetCnaActualPer)  " +
            " VALUES (:OwnerUUID,src.Region ,src.State,NULL,src.ClientName,src.Lob,src.ServiceLevel,src.ProgramYear,src.CurrentMonth,  " +
            "        src.GrowthRateTotalGroups,src.AgreedParticipate,src.EngagedParticipate,  " +
            "        src.POCExistingTotalGroups,src.POCExistingGroups,src.POCNewTotalGroups,src.POCNewGroups,  " +
            " src.RetrievedByOPAF,src.RetrievedByOptumUpload,src.RetrievedByOgm,src.RetrievedByEdata,  " +
            "       :UpdatedBy,GETUTCDATE() ,GETUTCDATE() ,:UpdatedBy,1,src.ReturnNetCnaActualPer);";


    private static final String IC_EMODALITY_POC_QUERY_HISTORICAL =
            "  with rs as (SELECT DISTINCT ao.OwnerUUID,a.GroupId,a.State ,a.ServiceLevel , a.UtilizingPOC from ProgPerf.AccountOwner ao  with (nolock) join ProgPerf.Accounts a on a.AccountId = ao.AccountId  where ao.OwnerUUID in( :OwnerUUID) and a.ServiceLevel = :ServiceLevel )  " +
                    "  Merge ProgPerf.LeaderGrowthRatePOCEModality as tgt using (  " +
                    "  SELECT OwnerUUID uuid, :Month as CurrentMonth,  " +
                    " 'All' clientname,providerstate STATE,'All' lob,project_year programyear,servicelevel servicelevel,  " +
                    " OPAF, OptumUpload, OGM, Edata  FROM  (    " +
                    " Select  ma.project_year ,ma.providerstate, rs.servicelevel, rs.OwnerUUID,     " +
                    "  ma.retrievedby ,  ma.returnednetcna  returnednetcna    " +
                    " from ProgPerf.MemberAssessment ma join rs on  ma.prov_group_id= rs.GroupId and ma.providerstate = rs.State   where     " +
                    " ma.deriveddeployed = 1 and ma.returnednetcna =1 and ma.RecordChangeType != 'deleted'    " +
                    " and ma.retrievedby in('OPAF','OptumUpload','OGM','Edata')    " +
                    " and ma.project_year = :ProgramYear  and ma.retrieval_date <=:DurationEndDate     " +
                    " ) AS SourceTable PIVOT(count([returnednetcna]) FOR [retrievedby] IN(OPAF,OptumUpload,OGM,Edata)) AS PivotTable) as src   on (  " +
                    " src.State = tgt.State and src.ClientName = tgt.ClientName and src.Lob = tgt.Lob and src.ServiceLevel = tgt.ServiceLevel and  " +
                    " src.ProgramYear = tgt.ProgramYear and src.CurrentMonth = tgt.[Month] and tgt.UUID = :OwnerUUID and tgt.IsActive = 1  " +
                    " ) when MATCHED THEN update set   " +
                    "  tgt.RetrievedByOPAF = src.OPAF,  " +
                    "  tgt.RetrievedByOptumUpload = src.OptumUpload,  " +
                    "  tgt.RetrievedByOgm = src.OGM,  " +
                    "  tgt.RetrievedByEdata = src.Edata,   " +
                    "  tgt.UpdatedBy = :UpdatedBy,  tgt.UpdatedDate = GETUTCDATE(), tgt.IsActive=1 " +
                    " WHEN Not MATCHED THEN   INSERT(UUID,State,ClientId,ClientName,LOB,ServiceLevel,ProgramYear,[Month], RetrievedByOPAF,  " +
                    " RetrievedByOptumUpload,RetrievedByOgm,RetrievedByEdata,updatedBy,updatedDate,createdDate,createdBy,IsActive)  " +
                    " VALUES (:OwnerUUID ,src.State,NULL,src.ClientName,src.Lob,src.ServiceLevel,src.ProgramYear,src.CurrentMonth,  " +
                    "        src.OPAF,src.OptumUpload, src.OGM,src.Edata, :UpdatedBy,GETUTCDATE() ,GETUTCDATE() ,:UpdatedBy,1);  " ;


    private static  String IC_EMODALITY_POC_CLIENT_LOB_LEVEL_HISTORICAL = "  with rs as (SELECT DISTINCT ao.OwnerUUID,a.GroupId,a.State ,a.ServiceLevel , a.UtilizingPOC from ProgPerf.AccountOwner ao  with (nolock) join ProgPerf.Accounts a on a.AccountId = ao.AccountId  where ao.OwnerUUID in( :OwnerUUID) and a.ServiceLevel = :ServiceLevel )   " +
            " Merge ProgPerf.LeaderGrowthRatePOCEModality as tgt using (   " +
            "  SELECT OwnerUUID uuid, :Month as CurrentMonth,   " +
            " client clientname,providerstate STATE,lob lob,project_year programyear,servicelevel servicelevel,   " +
            " OPAF, OptumUpload, OGM, Edata  FROM  (     " +
            " Select  ma.project_year ,ma.providerstate, rs.servicelevel, rs.OwnerUUID,      " +
            "  ma.retrievedby ,  ma.returnednetcna  returnednetcna   ,ma.ClientNameOFCStandard client,ma.lob2 lob   " +
            " from ProgPerf.MemberAssessment ma with (nolock) join rs on  ma.prov_group_id= rs.GroupId and ma.providerstate = rs.State  where     ma.deriveddeployed = 1 and ma.returnednetcna =1 and ma.RecordChangeType != 'deleted'     " +
            " and ma.retrievedby in('OPAF','OptumUpload','OGM','Edata')     and ma.project_year = :ProgramYear and ma.retrieval_date <=:DurationEndDate  ) AS SourceTable PIVOT(count([returnednetcna]) FOR [retrievedby] IN(OPAF,OptumUpload,OGM,Edata)) AS PivotTable) as src   on (   " +
            " src.State = tgt.State and src.ClientName = tgt.ClientName and src.Lob = tgt.Lob and src.ServiceLevel = tgt.ServiceLevel and   " +
            " src.ProgramYear = tgt.ProgramYear and src.CurrentMonth = tgt.[Month] and tgt.UUID = :OwnerUUID and tgt.IsActive = 1   " +
            " ) when MATCHED THEN update set  tgt.RetrievedByOPAF = src.OPAF,  tgt.RetrievedByOptumUpload = src.OptumUpload,  tgt.RetrievedByOgm = src.OGM,   tgt.RetrievedByEdata = src.Edata,    " +
            "  tgt.UpdatedBy = :UpdatedBy,  tgt.UpdatedDate = GETUTCDATE() , tgt.IsActive=1 WHEN Not MATCHED THEN   INSERT(UUID,State,ClientId,ClientName,LOB,ServiceLevel,ProgramYear,[Month], RetrievedByOPAF,   " +
            " RetrievedByOptumUpload,RetrievedByOgm,RetrievedByEdata,updatedBy,updatedDate,createdDate,createdBy,IsActive)   " +
            " VALUES (:OwnerUUID ,src.State,NULL,src.ClientName,src.Lob,src.ServiceLevel,src.ProgramYear,src.CurrentMonth, src.OPAF,src.OptumUpload, src.OGM,src.Edata, :UpdatedBy,GETUTCDATE() ,GETUTCDATE() ,:UpdatedBy,1);   ";

    private static String LEADER_GROWTH_RATE_POC_FOR_ALL_QUERY_HISTORY = "Merge ProgPerf.LeaderGrowthRatePOCEModality as tgt   " +
            " using (   " +
            "  SELECT 'All' as state, 'All' as Region, ClientName, lob, servicelevel, [Month] as CurrentMonth, ProgramYear   " +
            "  ,sum(GrowthRateTotalGroups) as GrowthRateTotalGroups,   " +
            " sum(AgreedParticipate) as AgreedParticipate,   " +
            " sum(EngagedParticipate) as EngagedParticipate,   " +
            " sum(POCExistingTotalGroups) as POCExistingTotalGroups,   " +
            " sum(POCExistingGroups) as POCExistingGroups,   " +
            " sum(POCNewTotalGroups) as POCNewTotalGroups,   " +
            " sum(POCNewGroups) as POCNewGroups,    " +
            " sum(RetrievedByOPAF) as RetrievedByOPAF,    " +
            " sum(RetrievedByOptumUpload) as RetrievedByOptumUpload,    " +
            " sum(RetrievedByOgm) as RetrievedByOgm,    " +
            " sum(RetrievedByEdata) as RetrievedByEdata ,sum(ReturnNetCnaActualPer) as ReturnNetCnaActualPer   " +
            " from ProgPerf.LeaderGrowthRatePOCEModality pge with (nolock)   " +
            " WHERE LEN(pge.State) > 0  and LEN(pge.ClientName)>0 and LEN(pge.LOB) >0 and LEN(pge.ServiceLevel)> 0   " +
            " and pge.UUID in (:Reporters) and pge.ProgramYear = :ProgramYear  and pge.ClientName  = 'All' and pge.lob = 'All' and pge.state != 'All' and  (pge.Region !='All' or pge.Region is Null) and pge.isActive=1 and pge.[Month] = :Month  " +
            " GROUP by pge.ClientName,pge.servicelevel,pge.LOB,pge.[Month] , pge.ProgramYear   " +
            " ) as src   " +
            " on (   " +
            " tgt.State = src.State and   " +
            " tgt.ClientName = src.ClientName and   " +
            " tgt.Lob = src.Lob and   " +
            " tgt.ServiceLevel = src.ServiceLevel and   " +
            " tgt.ProgramYear = src.ProgramYear and   " +
            " tgt.[Month] = src.CurrentMonth and   " +
            " tgt.UUID = :OwnerUUID   " +
            " )    " +
            " when MATCHED  THEN    " +
            " update set    " +
            "  tgt.GrowthRateTotalGroups = src.GrowthRateTotalGroups,   " +
            "  tgt.AgreedParticipate = src.AgreedParticipate,   " +
            "  tgt.EngagedParticipate = src.EngagedParticipate,   " +
            "  tgt.POCExistingTotalGroups = src.POCExistingTotalGroups,   " +
            "  tgt.POCExistingGroups = src.POCExistingGroups,   " +
            "  tgt.POCNewTotalGroups = src.POCNewTotalGroups,   " +
            "  tgt.POCNewGroups = src.POCNewGroups,   " +
            "  tgt.RetrievedByOPAF = src.RetrievedByOPAF,    " +
            "  tgt.RetrievedByOptumUpload = src.RetrievedByOptumUpload,    " +
            "  tgt.RetrievedByOgm = src.RetrievedByOgm,    " +
            "  tgt.RetrievedByEdata = src.RetrievedByEdata,    " +
            "  tgt.UpdatedBy = :UpdatedBy,    " +
            "  tgt.UpdatedDate = GETUTCDATE(),  tgt.Region =src.Region,  " +
            "  tgt.IsActive = 1 ,tgt.ReturnNetCnaActualPer = src.ReturnNetCnaActualPer  " +
            " WHEN Not MATCHED THEN   " +
            " INSERT(UUID,Region,State,ClientId,ClientName,LOB,ServiceLevel,ProgramYear,[Month],   " +
            " GrowthRateTotalGroups,AgreedParticipate,EngagedParticipate   " +
            " ,POCExistingTotalGroups,POCExistingGroups,POCNewTotalGroups,POCNewGroups   " +
            " ,RetrievedByOPAF,RetrievedByOptumUpload,RetrievedByOgm,RetrievedByEdata   " +
            "  ,updatedBy,updatedDate,createdDate,createdBy, IsActive,ReturnNetCnaActualPer)   " +
            " VALUES (:OwnerUUID,src.Region ,src.State,NULL,src.ClientName,src.Lob,src.ServiceLevel,src.ProgramYear,src.CurrentMonth,   " +
            "        src.GrowthRateTotalGroups,src.AgreedParticipate,src.EngagedParticipate,   " +
            "        src.POCExistingTotalGroups,src.POCExistingGroups,src.POCNewTotalGroups,src.POCNewGroups,   " +
            " src.RetrievedByOPAF,src.RetrievedByOptumUpload,src.RetrievedByOgm,src.RetrievedByEdata,   " +
            "       :UpdatedBy,GETUTCDATE() ,GETUTCDATE() ,:UpdatedBy,1,src.ReturnNetCnaActualPer);";
    private static final String NATIONAL_RETURN_NET_CNA_QUERY_HISTORICAL ="Merge ProgPerf.LeaderGrowthRatePOCEModality as tgt " +
            " using ( " +
            "Select " +
            " :Month as CurrentMonth, " +
            " ma.ClientNameOFCStandard clientname, " +
            " ma.providerstate STATE, " +
            " ma.lob2 lob, " +
            " ma.project_year programyear, " +
            " a.servicelevel servicelevel, " +
            " sum(ma.returnednetcna) returnednetcna " +
            "from " +
            " ProgPerf.MemberAssessment ma with (nolock) " +
            "join ProgPerf.Accounts a with (nolock) on " +
            " ma.prov_group_id = a.GroupId " +
            " and ma.providerstate = a.State " +
            "where " +
            " ma.deriveddeployed = 1 " +
            " and ma.returnednetcna = 1 " +
            " and ma.RecordChangeType <> 'deleted' " +
            " and ma.project_year = :ProgramYear " +
            " and ma.retrieval_date <=:DurationEndDate " +
            "group by " +
            " ma.project_year, " +
            " ma.ClientNameOFCStandard, " +
            " ma.lob2, " +
            " ma.providerstate, " +
            " a.servicelevel, " +
            " ma.project_year) as src on " +
            "( src.State = tgt.State " +
            " and tgt.ClientName = src.ClientName " +
            " and tgt.Lob = src.Lob " +
            " and tgt.ServiceLevel = src.ServiceLevel " +
            " and tgt.ProgramYear = src.ProgramYear " +
            " and tgt.[Month] = src.CurrentMonth " +
            " and tgt.UUID = :OwnerUUID " +
            " and tgt.IsActive = 1 ) " +
            "when MATCHED THEN " +
            "update " +
            "set " +
            " tgt.ReturnNetCnaActualPer = src.returnednetcna, " +
            " tgt.UpdatedBy = :UpdatedBy, " +
            " tgt.UpdatedDate = GETUTCDATE() " +
            " WHEN Not MATCHED THEN INSERT(UUID,State,ClientId,ClientName,LOB,ServiceLevel,ProgramYear,[Month], ReturnNetCnaActualPer,updatedBy,updatedDate,createdDate,createdBy, IsActive) " +
            " VALUES (:OwnerUUID ,src.State,NULL,src.ClientName,src.Lob,src.ServiceLevel,src.ProgramYear,src.CurrentMonth, src.returnednetcna,:UpdatedBy,GETUTCDATE() ,GETUTCDATE() ,:UpdatedBy,1); ";

    private static final String IC_GROWTH_RATE_POC_QUERY_HISTORY = "with rs as (SELECT DISTINCT a.GroupId,a.State ,a.ServiceLevel , a.UtilizingPOC " +
            " from ProgPerf.AccountOwner ao  with (nolock)" +
            " join ProgPerf.Accounts a on a.AccountId = ao.AccountId " +
            " where ao.OwnerUUID in( :OwnerUUID)" +
            " and a.ServiceLevel = :ServiceLevel" +
            " )" +
            " Merge ProgPerf.LeaderGrowthRatePOCEModality as tgt" +
            " using (" +
            "  SELECT pge.State, 'All' as ClientName, 'All' as lob, " +
            " rs.servicelevel, :Month as CurrentMonth," +
            " pge.ProgramYear,count(*) as GrowthRateTotalGroups," +
            " sum(case when pge.IsAgreed = 1 then 1 else 0 end ) as AgreedParticipate," +
            " sum(case when pge.IsEngaged = 1 then 1 else 0 end ) as EngagedParticipate," +
            " sum(case when pge.IsGroupEligibleForPOC = 1 and pge.IsNewForPOC = 0 then 1 else 0 end) as POCExistingTotalGroups," +
            " sum(case when rs.UtilizingPOC = 1 and pge.IsGroupEligibleForPOC = 1 and pge.IsNewForPOC = 0 then 1 else 0 end) as POCExistingGroups," +
            " sum(case when rs.UtilizingPOC = 1 and pge.IsGroupEligibleForPOC = 1 and pge.IsNewForPOC = 1 then 1 else 0 end) as POCNewGroups," +
            " sum(case when pge.IsGroupEligibleForPOC = 1 and pge.IsNewForPOC = 1 then 1 else 0 end) as POCNewTotalGroups" +
            " from ProgPerf.ProviderGroupExtended pge with (nolock)" +
            " join rs on  pge.ProviderGroupID = rs.GroupId and pge.State = rs.state and pge.ProgramYear = :ProgramYear" +
            " WHERE LEN(pge.State) > 0  AND LEN(pge.ProviderGroupID) > 0 " +
            " GROUP by pge.State,rs.servicelevel, pge.ProgramYear" +
            " ) as src" +
            " on (" +
            " src.State = tgt.State and" +
            " src.ClientName = tgt.ClientName and" +
            " src.Lob = tgt.Lob and" +
            " src.ServiceLevel = tgt.ServiceLevel and" +
            " src.ProgramYear = tgt.ProgramYear and" +
            " src.CurrentMonth = tgt.[Month] and" +
            " tgt.UUID = :OwnerUUID" +
            " ) " +
            " when MATCHED THEN " +
            " update set " +
            "  tgt.GrowthRateTotalGroups = src.GrowthRateTotalGroups," +
            "  tgt.AgreedParticipate = src.AgreedParticipate," +
            "  tgt.EngagedParticipate = src.EngagedParticipate," +
            "  tgt.POCExistingTotalGroups = src.POCExistingTotalGroups," +
            "  tgt.POCExistingGroups = src.POCExistingGroups," +
            "  tgt.POCNewTotalGroups = src.POCNewTotalGroups," +
            "  tgt.POCNewGroups = src.POCNewGroups," +
            "  tgt.UpdatedBy = :UpdatedBy, " +
            "  tgt.UpdatedDate = GETUTCDATE()," +
            "  tgt.IsActive = 1" +
            " WHEN Not MATCHED THEN" +
            " INSERT(UUID,State,ClientId,ClientName,LOB,ServiceLevel,ProgramYear,[Month]," +
            " GrowthRateTotalGroups,AgreedParticipate,EngagedParticipate" +
            " ,POCExistingTotalGroups,POCExistingGroups,POCNewTotalGroups,POCNewGroups" +
            "  ,updatedBy,updatedDate,createdDate,createdBy, IsActive)" +
            " VALUES (:OwnerUUID ,src.State,NULL,src.ClientName,src.Lob,src.ServiceLevel,src.ProgramYear,src.CurrentMonth," +
            "        src.GrowthRateTotalGroups,src.AgreedParticipate,src.EngagedParticipate," +
            "        src.POCExistingTotalGroups,src.POCExistingGroups,src.POCNewTotalGroups,src.POCNewGroups," +
            "       :UpdatedBy,GETUTCDATE() ,GETUTCDATE() ,:UpdatedBy,1);";

    private static final String UPDATE_REGION_QUERY_HISTORICAL = "update  ProgPerf.LeaderGrowthRatePOCEModality  " +
            "set Region  = ht.location " +
            "FROM ProgPerf.LeaderGrowthRatePOCEModality PGP  " +
            "join ProgPerf.GeographicalHierarchy gh on gh.Location = PGP.State and  gh.LocationType ='State' " +
            "join ProgPerf.GeographicalHierarchy ht on ht.[Level] = gh.Level.GetAncestor(2) " +
            "WHERE PGP.[Month] = :Month " +
            "and gh.Location = PGP.State " +
            "AND PGP.ProgramYear =:ProgramYear " +
            " and ht.LocationType ='Region'" +
            "and ht.DeletedDate  is null" +
            "and gh.DeletedDate  is null ";

    private static final String NATIONAL_GROWTH_RATE_POC_QUERY_HISTORY =
            "Merge ProgPerf.LeaderGrowthRatePOCEModality as tgt using (  " +
                    "  SELECT  pge.State, 'All' as ClientName, 'All' as lob,   " +
                    " ac.ServiceLevel , :Month as CurrentMonth,  " +
                    " pge.ProgramYear,  " +
                    " count(*) as GrowthRateTotalGroups  " +
                    " ,sum(case when pge.IsAgreed = 1 then 1 else 0 end ) as AgreedParticipate,  " +
                    " sum(case when pge.IsEngaged = 1 then 1 else 0 end ) as EngagedParticipate,  " +
                    " sum(case when pge.IsGroupEligibleForPOC = 1 and pge.IsNewForPOC = 0 then 1 else 0 end) as POCExistingTotalGroups,  " +
                    " sum(case when ac.UtilizingPOC = 1 and pge.IsGroupEligibleForPOC = 1 and pge.IsNewForPOC = 0 then 1 else 0 end) as POCExistingGroups,  " +
                    " sum(case when ac.UtilizingPOC = 1 and pge.IsGroupEligibleForPOC = 1 and pge.IsNewForPOC = 1 then 1 else 0 end) as POCNewGroups,  " +
                    " sum(case when pge.IsGroupEligibleForPOC = 1 and pge.IsNewForPOC = 1 then 1 else 0 end) as POCNewTotalGroups  " +
                    " from ProgPerf.ProviderGroupExtended pge with (nolock)  " +
                    " join ProgPerf.Accounts ac on pge.State= ac.state and pge.ProviderGroupID  = ac.GroupID WHERE LEN(pge.State) > 0  AND LEN(pge.ProviderGroupID) > 0   " +
                    " and pge.ProgramYear = :ProgramYear    " +
                    " GROUP by pge.State,ac.servicelevel, pge.ProgramYear ) as src  " +
                    " on (  " +
                    " src.State = tgt.State and  " +
                    " src.ClientName = tgt.ClientName and  " +
                    " src.Lob = tgt.Lob and  " +
                    " src.ServiceLevel = tgt.ServiceLevel and  " +
                    " src.ProgramYear = tgt.ProgramYear and  " +
                    " src.CurrentMonth = tgt.[Month] and  " +
                    " tgt.UUID = :OwnerUUID  " +
                    " )   " +
                    " when MATCHED THEN   " +
                    " update set   " +
                    "  tgt.GrowthRateTotalGroups = src.GrowthRateTotalGroups,  " +
                    "  tgt.AgreedParticipate = src.AgreedParticipate,  " +
                    "  tgt.EngagedParticipate = src.EngagedParticipate,  " +
                    "  tgt.POCExistingTotalGroups = src.POCExistingTotalGroups,  " +
                    "  tgt.POCExistingGroups = src.POCExistingGroups,  " +
                    "  tgt.POCNewTotalGroups = src.POCNewTotalGroups,  " +
                    "  tgt.POCNewGroups = src.POCNewGroups,  " +
                    "  tgt.UpdatedBy = :UpdatedBy,   " +
                    "  tgt.UpdatedDate = GETUTCDATE(),  " +
                    "  tgt.IsActive = 1  " +
                    " WHEN Not MATCHED THEN  " +
                    " INSERT(UUID,State,ClientId,ClientName,LOB,ServiceLevel,ProgramYear,[Month],  " +
                    " GrowthRateTotalGroups,AgreedParticipate,EngagedParticipate  " +
                    " ,POCExistingTotalGroups,POCExistingGroups,POCNewTotalGroups,POCNewGroups  " +
                    "  ,updatedBy,updatedDate,createdDate,createdBy, IsActive)  " +
                    " VALUES (:OwnerUUID ,src.State,NULL,src.ClientName,src.Lob,src.ServiceLevel,src.ProgramYear,src.CurrentMonth,  " +
                    "        src.GrowthRateTotalGroups,src.AgreedParticipate,src.EngagedParticipate,  " +
                    "        src.POCExistingTotalGroups,src.POCExistingGroups,src.POCNewTotalGroups,src.POCNewGroups,  " +
                    "       :UpdatedBy,GETUTCDATE() ,GETUTCDATE() ,:UpdatedBy,1);  " ;

    private static final String NATIONAL_EMODALITY_FOR_ALL_LEVEL_HISTORICAL = "    Merge ProgPerf.LeaderGrowthRatePOCEModality as tgt using (      " +
            "  SELECT OwnerUUID uuid,  :Month as CurrentMonth,      " +
            " 'All' clientname,providerstate STATE,'All' lob,project_year programyear,servicelevel servicelevel,      " +
            " OPAF, OptumUpload, OGM, Edata  FROM  (        " +
            " Select  ma.project_year ,ma.providerstate, ac.servicelevel, :OwnerUUID as OwnerUUID,         " +
            "  ma.retrievedby ,  ma.returnednetcna  returnednetcna        " +
            " from ProgPerf.MemberAssessment ma     " +
            " join ProgPerf.Accounts ac on ma.prov_group_id = ac.GroupID and  ma.providerstate = ac.State  " +
            "   where         " +
            " ma.deriveddeployed = 1 and ma.returnednetcna =1 and ma.RecordChangeType != 'deleted'        " +
            " and ma.retrievedby in('OPAF','OptumUpload','OGM','Edata')        " +
            " and ma.project_year = :ProgramYear  and ma.retrieval_date <=:DurationEndDate      " +
            " ) AS SourceTable PIVOT(count([returnednetcna]) FOR [retrievedby] IN(OPAF,OptumUpload,OGM,Edata)) AS PivotTable) as src   on (      " +
            " src.State = tgt.State and src.ClientName = tgt.ClientName and src.Lob = tgt.Lob and src.ServiceLevel = tgt.ServiceLevel and      " +
            " src.ProgramYear = tgt.ProgramYear and src.CurrentMonth = tgt.[Month] and tgt.UUID = :OwnerUUID      " +
            " ) when MATCHED THEN update set       " +
            "  tgt.RetrievedByOPAF = src.OPAF,      " +
            "  tgt.RetrievedByOptumUpload = src.OptumUpload,      " +
            "  tgt.RetrievedByOgm = src.OGM,      " +
            "  tgt.RetrievedByEdata = src.Edata,       " +
            "  tgt.UpdatedBy = :UpdatedBy,  tgt.UpdatedDate = GETUTCDATE(), tgt.IsActive=1     " +
            " WHEN Not MATCHED THEN   INSERT(UUID,State,ClientId,ClientName,LOB,ServiceLevel,ProgramYear,[Month], RetrievedByOPAF,      " +
            " RetrievedByOptumUpload,RetrievedByOgm,RetrievedByEdata,updatedBy,updatedDate,createdDate,createdBy,IsActive)      " +
            " VALUES (:OwnerUUID ,src.State,NULL,src.ClientName,src.Lob,src.ServiceLevel,src.ProgramYear,src.CurrentMonth,      " +
            "        src.OPAF,src.OptumUpload, src.OGM,src.Edata, :UpdatedBy,GETUTCDATE() ,GETUTCDATE() ,:UpdatedBy,1);  ";

    private static final String NATIONAL_EMODALITY_FOR_CLIENT_LOB_LEVEL_HISTORICAL = "Merge ProgPerf.LeaderGrowthRatePOCEModality as tgt  " +
            "    using (  " +
            "SELECT  " +
            "    OwnerUUID uuid,  " +
            "    :Month as CurrentMonth,  " +
            "    client clientname,  " +
            "    providerstate STATE,  " +
            "    lob lob,  " +
            "    project_year programyear,  " +
            "    servicelevel servicelevel,  " +
            "    OPAF,  " +
            "    OptumUpload,  " +
            "    OGM,  " +
            "    Edata  " +
            "FROM  " +
            "    (  " +
            "    Select  " +
            "        ma.project_year ,  " +
            "        ma.providerstate,  " +
            "        ac.servicelevel,  " +
            "        :OwnerUUID as OwnerUUID,  " +
            "        ma.retrievedby ,  " +
            "        ma.returnednetcna returnednetcna ,  " +
            "        ma.ClientNameOFCStandard client,  " +
            "        ma.lob2 lob  " +
            "    from  " +
            "        ProgPerf.MemberAssessment ma with (nolock)  " +
            "    join ProgPerf.Accounts ac on  " +
            "        ma.prov_group_id = ac.GroupID  and  ma.providerstate = ac.State    " +
            "    where  " +
            "        ma.deriveddeployed = 1  " +
            "        and ma.returnednetcna = 1  " +
            "        and ma.RecordChangeType != 'deleted'  " +
            "        and ma.retrievedby in('OPAF', 'OptumUpload', 'OGM', 'Edata')  " +
            "            and ma.project_year = :ProgramYear and ma.retrieval_date <=:DurationEndDate ) AS SourceTable PIVOT(count([returnednetcna]) FOR [retrievedby] IN(OPAF, OptumUpload, OGM, Edata)) AS PivotTable) as src on  " +
            "(     " +
            " src.State = tgt.State  " +
            "    and src.ClientName = tgt.ClientName  " +
            "    and src.Lob = tgt.Lob  " +
            "    and src.ServiceLevel = tgt.ServiceLevel  " +
            "    and     " +
            " src.ProgramYear = tgt.ProgramYear  " +
            "    and src.CurrentMonth = tgt.[Month]  " +
            "    and tgt.UUID = :OwnerUUID     " +
            " )  " +
            "when MATCHED THEN  " +
            "update  " +
            "set  " +
            "    tgt.RetrievedByOPAF = src.OPAF,  " +
            "    tgt.RetrievedByOptumUpload = src.OptumUpload,  " +
            "    tgt.RetrievedByOgm = src.OGM,  " +
            "    tgt.RetrievedByEdata = src.Edata,  " +
            "    tgt.UpdatedBy = :UpdatedBy,  " +
            "    tgt.UpdatedDate = GETUTCDATE() ,  " +
            "    tgt.IsActive = 1  " +
            "    WHEN Not MATCHED THEN  " +
            "INSERT  " +
            "    (UUID,  " +
            "    State,  " +
            "    ClientId,  " +
            "    ClientName,  " +
            "    LOB,  " +
            "    ServiceLevel,  " +
            "    ProgramYear,  " +
            "    [Month],  " +
            "    RetrievedByOPAF,  " +
            "    RetrievedByOptumUpload,  " +
            "    RetrievedByOgm,  " +
            "    RetrievedByEdata,  " +
            "    updatedBy,  " +
            "    updatedDate,  " +
            "    createdDate,  " +
            "    createdBy,  " +
            "    IsActive)  " +
            "VALUES (:OwnerUUID ,  " +
            "src.State,  " +
            "NULL,  " +
            "src.ClientName,  " +
            "src.Lob,  " +
            "src.ServiceLevel,  " +
            "src.ProgramYear,  " +
            "src.CurrentMonth,  " +
            "src.OPAF,  " +
            "src.OptumUpload,  " +
            "src.OGM,  " +
            "src.Edata,  " +
            ":UpdatedBy,  " +
            "GETUTCDATE() ,  " +
            "GETUTCDATE() ,  " +
            ":UpdatedBy,  " +
            "1);     ";

    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    public LeaderPerformanceRepositoryImpl(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
        this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
    }

    @Override
    public long loadLeaderPerformanceNationalLevelAll(ProgramYearCalendarDTO programYearCalendarDTO)
    {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put("programYear", programYearCalendarDTO.getProgramYear());
        paramMap.put("durationValue", programYearCalendarDTO.getDurationValue());
        paramMap.put("durationStartDate", programYearCalendarDTO.getStartDate().toString());
        paramMap.put("durationEndDate", programYearCalendarDTO.getEndDate().toString());
        paramMap.put("updatedBy", "RunLeaderPerfWeekly");
        paramMap.put("uuid",  "National");
        return namedParameterJdbcTemplate.update(NATIONAL_LEVEL_FOR_ALL_CLIENTS_LOB_REGION_STATE_SERVICE_LEVELS, paramMap);
    }

    @Override
    public int calculateICPerformanceData(String userId, String serviceLevel, ProgramYearCalendarDTO programYearCalendarDTO) {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put(OWNER_UUID, userId);
        paramMap.put(SERVICE_LEVEL, serviceLevel);
        paramMap.put(DURATION_VALUE, programYearCalendarDTO.getDurationValue());
        paramMap.put(PROGRAM_YEAR, programYearCalendarDTO.getProgramYear());
        paramMap.put(DURATION_START_DATE, programYearCalendarDTO.getStartDate().toString());
        paramMap.put(DURATION_END_DATE, programYearCalendarDTO.getEndDate().toString());
        paramMap.put(UPDATED_BY, JobName.LEADER_PERFORMANCE.getValue());
        return namedParameterJdbcTemplate.update(IC_PERFORMANCE_QUERY, paramMap);
    }

    @Override
    public List<String> getServiceLevelForUser(String userID) {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put("userId", userID);
        return namedParameterJdbcTemplate.queryForList(SERVICE_LEVELS_FOR_USER, paramMap, String.class);
    }

    @Override
    public long loadDataToEModalityFromMemberAssessments(int programYear) {

        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put(PROGRAM_YEAR, programYear);
        return namedParameterJdbcTemplate.update(LOAD_DATA_TO_EMODALITY_QUERY, paramMap);
    }

    @Override
    public int calculateLeaderPerformanceData(String userId, List<String> totalReporters, String durationValue) {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put(OWNER_UUID, userId);
        paramMap.put(REPORTERS, Objects.isNull(totalReporters)?"" : totalReporters);
        paramMap.put(DURATION_VALUE, durationValue);
        paramMap.put(UPDATED_BY, JobName.LEADER_PERFORMANCE.getValue());
        return namedParameterJdbcTemplate.update(LEADER_PERFORMANCE_QUERY, paramMap);
    }

    @Override
    public long loadLeaderPerformanceWeekly(ProgramYearCalendarDTO programYearCalendarDTO)
    {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put("programYear", programYearCalendarDTO.getProgramYear());
        paramMap.put("durationValue", programYearCalendarDTO.getDurationValue());
        paramMap.put("durationStartDate", programYearCalendarDTO.getStartDate().toString());
        paramMap.put("durationEndDate", programYearCalendarDTO.getEndDate().toString());
        paramMap.put("updatedBy", "RunLeaderPerfWeekly");
        paramMap.put("uuid",  "National");
        return namedParameterJdbcTemplate.update(QUERY_DATA_LOAD_LEADER_PERF_NATIONAL, paramMap);
    }

    @Override
    public Integer flagIsCurrentWeekFalse(int programYear, ProgramYearCalendarDTO programYearCalendarDTO) {

        log.info("{} Flag 0 Query With Params - jobName : {} {} ",FLAG_IS_CURRENT_WEEK_FALSE, programYear,programYearCalendarDTO);
        SqlParameterSource param = new MapSqlParameterSource(UPDATED_BY, JobName.LEADER_PERFORMANCE.getValue())
                .addValue(DURATION_VALUE,programYearCalendarDTO.getDurationValue());

        return namedParameterJdbcTemplate.update(FLAG_IS_CURRENT_WEEK_FALSE, param);

    }

    @Override
    public Integer flagIsActiveFalse(int programYear, ProgramYearCalendarDTO programYearCalendarDTO) {

        log.info("{} IsActive Query With Params - jobName : {} {} ",FLAG_IS_ACTIVE_FALSE, programYear,programYearCalendarDTO);
        SqlParameterSource param = new MapSqlParameterSource(PROGRAM_YEAR, programYear)
                .addValue(UPDATED_BY, JobName.LEADER_PERFORMANCE.getValue())
                .addValue(DURATION_VALUE,programYearCalendarDTO.getDurationValue());

        return namedParameterJdbcTemplate.update(FLAG_IS_ACTIVE_FALSE, param);

    }

    @Override
    public Integer calculateICGrowthRatePOCData(String userId, String serviceLevel, ProgramYearCalendarDTO programYearCalendarDTO) {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put(OWNER_UUID, userId);
        paramMap.put(SERVICE_LEVEL, serviceLevel);
        paramMap.put(PROGRAM_YEAR, programYearCalendarDTO.getProgramYear());
        paramMap.put(UPDATED_BY, JobName.LEADER_PERFORMANCE.getValue());
        return namedParameterJdbcTemplate.update(IC_GROWTH_RATE_POC_QUERY, paramMap);
    }

    @Override
    public Integer calculateNationalGrowthRatePOCData(String userId,  ProgramYearCalendarDTO programYearCalendarDTO) {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put(OWNER_UUID, userId);
        paramMap.put(PROGRAM_YEAR, programYearCalendarDTO.getProgramYear());
        paramMap.put(UPDATED_BY, JobName.LEADER_PERFORMANCE.getValue());
        return namedParameterJdbcTemplate.update(NATIONAL_GROWTH_RATE_POC_QUERY, paramMap);
    }

    @Override
    public Integer calculateReturnNetCnaForNational(String userId, ProgramYearCalendarDTO programYearCalendarDTO) {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put(OWNER_UUID, userId);
        paramMap.put(PROGRAM_YEAR, programYearCalendarDTO.getProgramYear());
        paramMap.put(UPDATED_BY, JobName.LEADER_PERFORMANCE.getValue());
        return namedParameterJdbcTemplate.update(NATIONAL_RETURN_NET_CNA_QUERY, paramMap);
    }

    @Override
    public Integer calculateReturnNetCnaForAllNational(String userId, ProgramYearCalendarDTO programYearCalendarDTO) {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put(OWNER_UUID, userId);
        paramMap.put(PROGRAM_YEAR, programYearCalendarDTO.getProgramYear());
        paramMap.put(UPDATED_BY, JobName.LEADER_PERFORMANCE.getValue());
        return namedParameterJdbcTemplate.update(RETURNED_NET_CNA_FOR_ALL_QUERY, paramMap);
    }

    @Override
    public Integer calculateEModalityPOCDataForNational(String userId, ProgramYearCalendarDTO programYearCalendarDTO) {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put(OWNER_UUID, userId);
        paramMap.put(PROGRAM_YEAR, programYearCalendarDTO.getProgramYear());
        paramMap.put(UPDATED_BY, JobName.LEADER_PERFORMANCE.getValue());
        return namedParameterJdbcTemplate.update(NATIONAL_EMODALITY_FOR_ALL_LEVEL, paramMap);
    }

    @Override
    public Integer calculateEModalityPOCDataForNationalClientLob(String userId, ProgramYearCalendarDTO programYearCalendarDTO) {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put(OWNER_UUID, userId);
        paramMap.put(PROGRAM_YEAR, programYearCalendarDTO.getProgramYear());
        paramMap.put(UPDATED_BY, JobName.LEADER_PERFORMANCE.getValue());
        return namedParameterJdbcTemplate.update(NATIONAL_EMODALITY_FOR_CLIENT_LOB_LEVEL, paramMap);
    }

    @Override
    public Integer calculateEModalityPOCData(String userId, String serviceLevel, ProgramYearCalendarDTO programYearCalendarDTO) {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put(OWNER_UUID, userId);
        paramMap.put(SERVICE_LEVEL, serviceLevel);
        paramMap.put(PROGRAM_YEAR, programYearCalendarDTO.getProgramYear());
        paramMap.put(UPDATED_BY, JobName.LEADER_PERFORMANCE.getValue());
        return namedParameterJdbcTemplate.update(IC_EMODALITY_POC_QUERY, paramMap);
    }

    @Override
    public Integer calculateEModalityPOCDataForClientAndLob(String userId, String serviceLevel, ProgramYearCalendarDTO programYearCalendarDTO) {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put(OWNER_UUID, userId);
        paramMap.put(SERVICE_LEVEL, serviceLevel);
        paramMap.put(PROGRAM_YEAR, programYearCalendarDTO.getProgramYear());
        paramMap.put(UPDATED_BY, JobName.LEADER_PERFORMANCE.getValue());
        return namedParameterJdbcTemplate.update(IC_EMODALITY_POC_CLIENT_LOB_LEVEL, paramMap);
    }
    @Override
    public Integer calculateReturenNetCnaForALL(String userId, String serviceLevel, ProgramYearCalendarDTO programYearCalendarDTO) {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put(OWNER_UUID, userId);
        paramMap.put(SERVICE_LEVEL, serviceLevel);
        paramMap.put(PROGRAM_YEAR, programYearCalendarDTO.getProgramYear());
        paramMap.put(UPDATED_BY, JobName.LEADER_PERFORMANCE.getValue());
        return namedParameterJdbcTemplate.update(IC_RETURNNETCNA_ALL, paramMap);
    }

    @Override
    public Integer calculateReturenNetCnaForClientAndLob(String userId, String serviceLevel, ProgramYearCalendarDTO programYearCalendarDTO) {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put(OWNER_UUID, userId);
        paramMap.put(SERVICE_LEVEL, serviceLevel);
        paramMap.put(PROGRAM_YEAR, programYearCalendarDTO.getProgramYear());
        paramMap.put(UPDATED_BY, JobName.LEADER_PERFORMANCE.getValue());
        return namedParameterJdbcTemplate.update(IC_RETURNNETCNA_FOR_CLIENT_LOB_LEVEL, paramMap);
    }

    @Override
    public List<String> getUsersByRole(List<String> icRoleList) {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put("ICRoleNames", icRoleList);
        paramMap.put("LeaderRoleNames", LEADER_ROLES);
        return namedParameterJdbcTemplate.queryForList(USERS_BY_ROLES_QUERY, paramMap, String.class);
    }

    @Override
    public int updateIsActiveFlagToFalse(String programyear) {
        log.info("{} IsActive Query With Params - jobName : {} {} ",IS_ACTIVE_FLAG_FALSE_POC, programyear);
        SqlParameterSource param = new MapSqlParameterSource("programYear", programyear)
                .addValue(UPDATED_BY, JobName.LEADER_PERFORMANCE.getValue());
        return namedParameterJdbcTemplate.update(IS_ACTIVE_FLAG_FALSE_POC, param);
    }


    @Override
    public int calculateLeaderGrowthRatePOCData(String userId, List<String> totalReporters, int programYear) {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put(OWNER_UUID, userId);
        paramMap.put(PROGRAM_YEAR, programYear);
        paramMap.put(REPORTERS, Objects.isNull(totalReporters)?"" : totalReporters);
        paramMap.put(UPDATED_BY, JobName.LEADER_PERFORMANCE.getValue());
        return namedParameterJdbcTemplate.update(LEADER_GROWTH_RATE_POC_QUERY, paramMap);
    }

    @Override
    public int calculateLeaderGrowthRatePOCDataForAllRegionAndState(String userId, List<String> totalReporters, int programYear) {
        log.info("{} calculateLeaderGrowthRatePOCDataForAllRegionAndState Query With Params -  : {} ",LEADER_GROWTH_RATE_POC_FOR_ALL_QUERY,totalReporters);
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put(OWNER_UUID, userId);
        paramMap.put(PROGRAM_YEAR, programYear);
        paramMap.put(REPORTERS, Objects.isNull(totalReporters)?"" : totalReporters);
        paramMap.put(UPDATED_BY, JobName.LEADER_PERFORMANCE.getValue());
        return namedParameterJdbcTemplate.update(LEADER_GROWTH_RATE_POC_FOR_ALL_QUERY, paramMap);
    }


    @Override
    public int updateICGoalLeaderPerformance(String userId, String serviceLevel, ProgramYearCalendarDTO programYearCalendarDTO) {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put(OWNER_UUID, userId);
        paramMap.put(SERVICE_LEVEL, serviceLevel);
        paramMap.put(DURATION_VALUE, programYearCalendarDTO.getDurationValue());
        paramMap.put(PROGRAM_YEAR, programYearCalendarDTO.getProgramYear());
        paramMap.put(UPDATED_BY, JobName.LEADER_PERFORMANCE.getValue());
        return namedParameterJdbcTemplate.update(IC_GOAL_UPDATE_LEADER_PERFORMANCE, paramMap);
    }

    @Override
    public int updateRegions(ProgramYearCalendarDTO programYearCalendarDTO) {
        log.info("{} Regions Query With Params - jobName : {} ",UPDATE_REGION_QUERY,programYearCalendarDTO);
        SqlParameterSource param = new MapSqlParameterSource(PROGRAM_YEAR, programYearCalendarDTO.getProgramYear());

        return namedParameterJdbcTemplate.update(UPDATE_REGION_QUERY, param);
    }

    @Override
    public int calculateCGapData(String userId, String serviceLevel, ProgramYearCalendarDTO programYearCalendarDTO) {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put(OWNER_UUID, userId);
        paramMap.put(SERVICE_LEVEL, serviceLevel);
        paramMap.put(DURATION_VALUE, programYearCalendarDTO.getDurationValue());
        paramMap.put(DURATION_START_DATE, programYearCalendarDTO.getStartDate().toString());
        paramMap.put(DURATION_END_DATE, programYearCalendarDTO.getEndDate().toString());
        paramMap.put(PROGRAM_YEAR, programYearCalendarDTO.getProgramYear());
        paramMap.put(UPDATED_BY, JobName.LEADER_PERFORMANCE.getValue());
        return namedParameterJdbcTemplate.update(IC_CGAP_QUERY, paramMap);
    }

    @Override
    public long loadLeaderPerformanceWeeklyCGAPClosureStateRegion(ProgramYearCalendarDTO programYearCalendarDTO)
    {
        log.info("{} loadLeaderPerformanceWeeklyCGAPClosureStateRegion With Params - jobName : {} ",REGION_STATE_CGAP_SUSPECT_COUNT,programYearCalendarDTO);
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put("programYear", programYearCalendarDTO.getProgramYear());
        paramMap.put("durationValue", programYearCalendarDTO.getDurationValue());
        paramMap.put("updatedBy", "RunLeaderPerfWeekly");
        paramMap.put("uuid",  "National");
        return namedParameterJdbcTemplate.update(REGION_STATE_CGAP_SUSPECT_COUNT, paramMap);
    }

    @Override
    public long  loadLeaderPerformanceWeeklyCGAPClosureNational  (ProgramYearCalendarDTO programYearCalendarDTO)
    {
        log.info("{} loadLeaderPerformanceWeeklyCGAPClosureNation With Params - jobName : {} ",NATIONAL_CGAP_SUSPECT_COUNT,programYearCalendarDTO);
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put("programYear", programYearCalendarDTO.getProgramYear());
        paramMap.put("durationValue", programYearCalendarDTO.getDurationValue());
        paramMap.put("updatedBy", "RunLeaderPerfWeekly");
        paramMap.put("uuid",  "National");
        return namedParameterJdbcTemplate.update(NATIONAL_CGAP_SUSPECT_COUNT, paramMap);
    }

    @Override
    public int updateAllNationalGoalsLeaderPerformance( ProgramYearCalendarDTO programYearCalendarDTO)
    {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put(OWNER_UUID, "National");
        paramMap.put(DURATION_VALUE, programYearCalendarDTO.getDurationValue());
        paramMap.put(PROGRAM_YEAR, programYearCalendarDTO.getProgramYear());
        return namedParameterJdbcTemplate.update(NATIONAL_ALL_LEVEL_GOAL_CALC_QUERY, paramMap);
    }

    @Override
    public int updateNationalGoalsLeaderPerformance( ProgramYearCalendarDTO programYearCalendarDTO)
    {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put(OWNER_UUID, "National");
        paramMap.put(DURATION_VALUE, programYearCalendarDTO.getDurationValue());
        paramMap.put(PROGRAM_YEAR, programYearCalendarDTO.getProgramYear());
        paramMap.put(UPDATED_BY, JobName.LEADER_PERFORMANCE.getValue());
        return namedParameterJdbcTemplate.update(NATIONAL_LEVEL_GOAL_UPDATE, paramMap);
    }

    @Override
    public Integer calculateReturenNetCnaForALLHistorical(String userId, String serviceLevel, ProgramYearCalendarDTO programYearCalendarDTO) {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put(OWNER_UUID, userId);
        paramMap.put(SERVICE_LEVEL, serviceLevel);
        paramMap.put(MONTH, programYearCalendarDTO.getMonth());
        paramMap.put(DURATION_END_DATE, String.valueOf(programYearCalendarDTO.getEndDate()));
        paramMap.put(PROGRAM_YEAR, programYearCalendarDTO.getProgramYear());
        paramMap.put(UPDATED_BY, JobName.LEADER_PERFORMANCE.getValue()+"_HistoricalAPI");
        return namedParameterJdbcTemplate.update(IC_RETURNNETCNA_ALL_HISTORICAL, paramMap);

    }

    @Override
    public Integer calculateReturenNetCnaForClientAndLobHistorical(String userId, String serviceLevel,  ProgramYearCalendarDTO programYearCalendarDTO) {
        Map<String, Object> paramMap = new HashMap<>();
            paramMap.put(OWNER_UUID, userId);
            paramMap.put(SERVICE_LEVEL, serviceLevel);
            paramMap.put(MONTH, programYearCalendarDTO.getMonth());
            paramMap.put(DURATION_END_DATE, String.valueOf(programYearCalendarDTO.getEndDate()));
            paramMap.put(PROGRAM_YEAR,programYearCalendarDTO.getProgramYear());
            paramMap.put(UPDATED_BY, JobName.LEADER_PERFORMANCE.getValue()+"_HistoricalAPI");
            return namedParameterJdbcTemplate.update(IC_RETURNNETCNA_FOR_CLIENT_LOB_LEVEL_HISTORICAL, paramMap);

    }

    @Override
    public int calculateReturnNetCnaForAllNationalHistorical(String national, ProgramYearCalendarDTO programYearCalendarDTO) {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put(OWNER_UUID, national);
        paramMap.put(PROGRAM_YEAR, programYearCalendarDTO.getProgramYear());
        paramMap.put(MONTH, programYearCalendarDTO.getMonth());
        paramMap.put(DURATION_END_DATE, String.valueOf(programYearCalendarDTO.getEndDate()));
        paramMap.put(UPDATED_BY, JobName.LEADER_PERFORMANCE.getValue()+"_HistoricalAPI");
        return namedParameterJdbcTemplate.update(RETURNED_NET_CNA_FOR_ALL_QUERY_HISTORICAL, paramMap);
    }

    @Override
    public int calculateEModalityPOCDataHistorical(String userId, String serviceLevel, ProgramYearCalendarDTO programYearCalendarDTO) {
        Map<String, Object> paramMap = new HashMap<>();
        try{
            paramMap.put(OWNER_UUID, userId);
            paramMap.put(SERVICE_LEVEL, serviceLevel);
            paramMap.put(MONTH, programYearCalendarDTO.getMonth());
            paramMap.put(DURATION_END_DATE, String.valueOf(programYearCalendarDTO.getEndDate()));
            paramMap.put(PROGRAM_YEAR, programYearCalendarDTO.getProgramYear());
            paramMap.put(UPDATED_BY, JobName.LEADER_PERFORMANCE.getValue()+"_HistoricalAPI");
            return namedParameterJdbcTemplate.update(IC_EMODALITY_POC_QUERY_HISTORICAL, paramMap);
        }catch (Exception ex ){
            log.error(" exception :: {}   {} loadLeaderPerformanceWeeklyCGAPClosureNation With Params - {} ",ex.getMessage(),IC_EMODALITY_POC_QUERY_HISTORICAL,paramMap);
        }
        return 0;
    }
    @Override
    public int calculateEModalityPOCDataForClientAndLobHistorical(String userId, String serviceLevel, ProgramYearCalendarDTO programYearCalendarDTO) {
        Map<String, Object> paramMap = new HashMap<>();
        try{
            paramMap.put(OWNER_UUID, userId);
            paramMap.put(SERVICE_LEVEL, serviceLevel);
            paramMap.put(MONTH, programYearCalendarDTO.getMonth());
            paramMap.put(DURATION_END_DATE, String.valueOf(programYearCalendarDTO.getEndDate()));
            paramMap.put(PROGRAM_YEAR, programYearCalendarDTO.getProgramYear());
            paramMap.put(UPDATED_BY, JobName.LEADER_PERFORMANCE.getValue()+"_HistoricalAPI");
            return namedParameterJdbcTemplate.update(IC_EMODALITY_POC_CLIENT_LOB_LEVEL_HISTORICAL, paramMap);
        }catch (Exception ex ){
            log.error(" exception :: {}   {} loadLeaderPerformanceWeeklyCGAPClosureNation With Params - {} ",ex.getMessage(),IC_EMODALITY_POC_CLIENT_LOB_LEVEL_HISTORICAL,paramMap);
        }
        return 0;
    }

//    @Override
//    public int calculateLeaderGrowthRatePOCDataForAllRegionAndStateHistorical(String userId, String serviceLevel, ProgramYearCalendarDTO programYearCalendarDTO) {
//        Map<String, Object> paramMap = new HashMap<>();
//        try{
//            paramMap.put(OWNER_UUID, userId);
//            paramMap.put(SERVICE_LEVEL, serviceLevel);
//            paramMap.put(MONTH, programYearCalendarDTO.getMonth());
//            paramMap.put(DURATION_END_DATE, String.valueOf(programYearCalendarDTO.getEndDate()));
//            paramMap.put(PROGRAM_YEAR, programYearCalendarDTO.getProgramYear());
//            paramMap.put(UPDATED_BY, JobName.LEADER_PERFORMANCE.getValue()+"_HistoricalAPI");
//            return namedParameterJdbcTemplate.update(LEADER_GROWTH_RATE_POC_FOR_ALL_QUERY_HISTORY, paramMap);
//        }catch (Exception ex ){
//            log.error(" exception :: {}   {} loadLeaderPerformanceWeeklyCGAPClosureNation With Params - {} ",ex.getMessage(),LEADER_GROWTH_RATE_POC_FOR_ALL_QUERY_HISTORY,paramMap);
//        }
//        return 0;
//    }
    @Override
    public int calculateReturnNetCnaForNationalHistorical(String national, ProgramYearCalendarDTO programYearCalendarDTO) {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put(OWNER_UUID, national);
        paramMap.put(PROGRAM_YEAR, programYearCalendarDTO.getProgramYear());
        paramMap.put(MONTH, programYearCalendarDTO.getMonth());
        paramMap.put(DURATION_END_DATE, String.valueOf(programYearCalendarDTO.getEndDate()));
        paramMap.put(UPDATED_BY, JobName.LEADER_PERFORMANCE.getValue()+"_HistoricalAPI");
        return namedParameterJdbcTemplate.update(NATIONAL_RETURN_NET_CNA_QUERY_HISTORICAL, paramMap);
    }

    @Override
    public int calculateLeaderGrowthRatePOCDataHistorical(String userId, List<String> totalReporters,  ProgramYearCalendarDTO programYearCalendarDTO) {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put(OWNER_UUID, userId);
        paramMap.put(PROGRAM_YEAR, programYearCalendarDTO.getProgramYear());
        paramMap.put(REPORTERS, Objects.isNull(totalReporters)?"" : totalReporters);
        paramMap.put(MONTH, programYearCalendarDTO.getMonth());
        paramMap.put(UPDATED_BY, JobName.LEADER_PERFORMANCE.getValue());
        return namedParameterJdbcTemplate.update(LEADER_GROWTH_RATE_POC_QUERY_HISTORICAL, paramMap);
    }

    @Override
    public int calculateLeaderGrowthRatePOCDataForAllRegionAndStateHistorical(String userId, List<String> totalReporters, ProgramYearCalendarDTO programYearCalendarDTO) {
        log.info("{} calculateLeaderGrowthRatePOCDataForAllRegionAndStateHistorical  Query With Params -  : {} ",LEADER_GROWTH_RATE_POC_FOR_ALL_QUERY_HISTORICAL,totalReporters);
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put(OWNER_UUID, userId);
        paramMap.put(PROGRAM_YEAR, programYearCalendarDTO.getProgramYear());
        paramMap.put(REPORTERS, Objects.isNull(totalReporters)?"" : totalReporters);
        paramMap.put(MONTH, programYearCalendarDTO.getMonth());
        paramMap.put(UPDATED_BY, JobName.LEADER_PERFORMANCE.getValue());
        return namedParameterJdbcTemplate.update(LEADER_GROWTH_RATE_POC_FOR_ALL_QUERY_HISTORICAL, paramMap);
    }

    @Override
    public Integer calculateICGrowthRatePOCDataHistorical(String userId, String serviceLevel, ProgramYearCalendarDTO programYearCalendarDTO) {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put(OWNER_UUID, userId);
        paramMap.put(SERVICE_LEVEL, serviceLevel);
        paramMap.put(PROGRAM_YEAR, programYearCalendarDTO.getProgramYear());
        paramMap.put(MONTH, programYearCalendarDTO.getMonth());
        paramMap.put(DURATION_END_DATE, String.valueOf(programYearCalendarDTO.getEndDate()));
        paramMap.put(UPDATED_BY, JobName.LEADER_PERFORMANCE.getValue()+"_HistoricalAPI");
        return namedParameterJdbcTemplate.update(IC_GROWTH_RATE_POC_QUERY_HISTORY, paramMap);
    }

    @Override
    public int updateRegionsForHistory(ProgramYearCalendarDTO programYearCalendarDTO) {
        log.info("{} Regions Query With Params - jobName : {} ",UPDATE_REGION_QUERY_HISTORICAL,programYearCalendarDTO);
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put(PROGRAM_YEAR, programYearCalendarDTO.getProgramYear());
        paramMap.put(MONTH, programYearCalendarDTO.getMonth());
        paramMap.put(UPDATED_BY, JobName.LEADER_PERFORMANCE.getValue()+"_HistoricalAPI");

        return namedParameterJdbcTemplate.update(UPDATE_REGION_QUERY_HISTORICAL, paramMap);
    }

    @Override
    public Integer calculateNationalGrowthRatePOCDataHistorical(String userId, ProgramYearCalendarDTO programYearCalendarDTO) {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put(OWNER_UUID, userId);
        paramMap.put(PROGRAM_YEAR, programYearCalendarDTO.getProgramYear());
        paramMap.put(MONTH, programYearCalendarDTO.getMonth());
        paramMap.put(DURATION_END_DATE, String.valueOf(programYearCalendarDTO.getEndDate()));
        paramMap.put(UPDATED_BY, JobName.LEADER_PERFORMANCE.getValue()+"_HistoricalAPI");
        return namedParameterJdbcTemplate.update(NATIONAL_GROWTH_RATE_POC_QUERY_HISTORY, paramMap);
    }

    @Override
    public Integer calculateEModalityPOCDataForNationalHistorical(String userId, ProgramYearCalendarDTO programYearCalendarDTO) {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put(OWNER_UUID, userId);
        paramMap.put(PROGRAM_YEAR, programYearCalendarDTO.getProgramYear());
        paramMap.put(MONTH, programYearCalendarDTO.getMonth());
        paramMap.put(DURATION_END_DATE, String.valueOf(programYearCalendarDTO.getEndDate()));
        paramMap.put(UPDATED_BY, JobName.LEADER_PERFORMANCE.getValue()+"_HistoricalAPI");
        return namedParameterJdbcTemplate.update(NATIONAL_EMODALITY_FOR_ALL_LEVEL_HISTORICAL, paramMap);
    }

    @Override
    public Integer calculateEModalityPOCDataForNationalClientLobHistorical(String userId, ProgramYearCalendarDTO programYearCalendarDTO) {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put(OWNER_UUID, userId);
        paramMap.put(PROGRAM_YEAR, programYearCalendarDTO.getProgramYear());
        paramMap.put(MONTH, programYearCalendarDTO.getMonth());
        paramMap.put(DURATION_END_DATE, String.valueOf(programYearCalendarDTO.getEndDate()));
        paramMap.put(UPDATED_BY, JobName.LEADER_PERFORMANCE.getValue()+"_HistoricalAPI");
        return namedParameterJdbcTemplate.update(NATIONAL_EMODALITY_FOR_CLIENT_LOB_LEVEL_HISTORICAL, paramMap);
    }
}

