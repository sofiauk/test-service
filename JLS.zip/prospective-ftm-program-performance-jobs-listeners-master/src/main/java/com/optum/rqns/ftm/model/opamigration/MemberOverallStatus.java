package com.optum.rqns.ftm.model.opamigration;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.time.LocalDateTime;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MemberOverallStatus {

    private String globalMemberId;
    private String lob;
    private String clientId;
    private int programYear;
    private String overallStatus;
    private String messageCorrId;
    private String providerGroupId;
    private LocalDateTime updatedDate;
    private String distributionChannel;
    private LocalDateTime deployDate;

}
