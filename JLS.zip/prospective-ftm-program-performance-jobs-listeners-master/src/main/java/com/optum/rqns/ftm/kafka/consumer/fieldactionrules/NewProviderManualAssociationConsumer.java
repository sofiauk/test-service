package com.optum.rqns.ftm.kafka.consumer.fieldactionrules;

import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.consumer.JobEventConsumer;
import com.optum.rqns.ftm.repository.common.CommonRepositoryImpl;
import com.optum.rqns.ftm.service.fieldactionrules.NewProviderManualAssociationServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.context.annotation.Profile;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.annotation.TopicPartition;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

@Profile("fieldActionRules")
@Component
@Slf4j
public class NewProviderManualAssociationConsumer extends JobEventConsumer {

    public NewProviderManualAssociationConsumer(final NewProviderManualAssociationServiceImpl providerManualAssociationService, final CommonRepositoryImpl commonRepository) {
        super(providerManualAssociationService, commonRepository);
    }

    @KafkaListener(topicPartitions = {@TopicPartition(topic = "${spring.gcpkafka.properties.topics.jobEvent}", partitions = {"27"})},
            containerFactory = "jobEventKafkaListenerContainerFactory", autoStartup = "true")
    public void onMessage(ConsumerRecord<String, JobEvent> record, Acknowledgment acknowledgment) {
        log.info("{} Begin Consumer NewProviderManualAssociation  : {}", super.generateTransactionId(record), record);
        processMessage(27, record, acknowledgment);
    }

}