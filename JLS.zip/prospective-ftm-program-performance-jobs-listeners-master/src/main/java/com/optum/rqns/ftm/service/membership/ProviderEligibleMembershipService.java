package com.optum.rqns.ftm.service.membership;

import com.optum.rqns.ftm.service.IJob;
import org.springframework.stereotype.Service;

@Service
public interface ProviderEligibleMembershipService extends IJob {
}
