package com.optum.rqns.ftm.kafka.consumer.redis;

import org.springframework.data.redis.connection.MessageListener;

public interface RedisMessageHandler extends MessageListener {

}
