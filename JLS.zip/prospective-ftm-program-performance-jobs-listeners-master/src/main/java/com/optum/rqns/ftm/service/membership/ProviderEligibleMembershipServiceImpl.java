package com.optum.rqns.ftm.service.membership;

import com.fasterxml.uuid.Generators;
import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.avro.models.v1.program.performance.provider.membership.ClientStats;
import com.optum.rqns.ftm.kafka.avro.models.v1.program.performance.provider.membership.PerformanceStats;
import com.optum.rqns.ftm.kafka.avro.models.v1.program.performance.provider.membership.ProviderEligibleMembership;
import com.optum.rqns.ftm.kafka.avro.models.v1.program.performance.provider.membership.ProviderPerformance;
import com.optum.rqns.ftm.kafka.producer.KeyBasedProviderEligibleMembershipProducer;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.model.membership.ProviderEligibleMembershipFlatData;
import com.optum.rqns.ftm.opportunities.common.util.MemberGapsKafkaUtil;
import com.optum.rqns.ftm.repository.membership.ProviderEligibleMembershipRepository;
import com.optum.rqns.ftm.util.JobUtilility;
import com.optum.rqns.ftm.util.ProgramPerformanceJobUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.time.StopWatch;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Function;
import java.util.stream.Collectors;


@Service
@Slf4j
public class ProviderEligibleMembershipServiceImpl implements ProviderEligibleMembershipService {

    private ProviderEligibleMembershipRepository providerEligibleMembershipRepository;

    @Autowired
    private KeyBasedProviderEligibleMembershipProducer producer;

    JobUtilility jobUtilility;

    @Value("${new_providergroup_rule_producer_thread_pool_size}")
    private int producerThreadPoolSize;

    public ProviderEligibleMembershipServiceImpl(ProviderEligibleMembershipRepository providerEligibleMembershipRepository) {
        this.providerEligibleMembershipRepository = providerEligibleMembershipRepository;
    }

    public JobStatus executeJob(JobEvent jobEvent) {

        MDC.put(Constants.TRACE_ID, Generators.timeBasedGenerator().generate().toString());
        MDC.put(Constants.TRANSACTION_ID, ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
        MDC.put(Constants.MESSAGE_ID, ProgramPerformanceJobUtil.TransactionIdLogger.getMessageIdIdentifier());

        JobStatus jobStatus = new JobStatus();
        jobUtilility = new JobUtilility();
        log.info("{} jobEvent.Provider Eligible Membership() :: {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), jobEvent.getJobName());
        try {
            log.info("{} Inside Run Job ", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());

            AtomicInteger updatedRecords = new AtomicInteger();

            final Long totalRows = this.providerEligibleMembershipRepository.getRecordCount(jobEvent);
            log.info("Provider Eligible Membership record Count {}", totalRows);

            List<Integer> batches = jobUtilility.getBatches(totalRows);
            log.info("Provider Eligible Membership total Batches offsets are {}", batches.size());

            batches.stream().forEach(batchOffset -> {

                int publishedProviderEligibleMembershipCount = sendProviderEligibleMembershipToProviderMS(Constants.BATCH_SIZE, batchOffset,jobEvent);
                updatedRecords.addAndGet(publishedProviderEligibleMembershipCount);

            });

            jobStatus.setStatus(Status.SUCCESS);
            jobStatus.setMessage("Completed Provider Eligible Membership Provider MS Producer job successfully");
            jobStatus.setUpdatedRows(updatedRecords.longValue());

        } catch (Exception e) {
            log.error("Exception while executing with All Provider Eligible Membership Provider MS Producer job : {}", e);

            jobStatus.setStatus(Status.FAILURE);
            jobStatus.setMessage("ProviderEligibleMembership Provider MS Producer job execution failed : " + e.getMessage());
            jobStatus.setUpdatedRows(0L);
        } finally {
            MDC.clear();
        }

        return jobStatus;
    }


    private int sendProviderEligibleMembershipToProviderMS(int batchSize,int offset,JobEvent jobEvent) {

        List<ProviderEligibleMembershipFlatData> providerEligibleMembershipFlatDataList = providerEligibleMembershipRepository.getProviderEligibleMembershipDetails(batchSize,offset,jobEvent);
        log.info("records count {}",providerEligibleMembershipFlatDataList.size());
        List<ProviderEligibleMembership> providerEligibleMembershipList = convertToJSON(providerEligibleMembershipFlatDataList);
        log.info("Messages Count :: {}", providerEligibleMembershipList.size());
        log.info("Started publishing to kafka");
        long totalElements = 0;

        //For parallel producing
        ExecutorService executorService = Executors.newFixedThreadPool(producerThreadPoolSize);
        List<Callable<Boolean>> taskList = new ArrayList<>();

        try {
            for (ProviderEligibleMembership providerEligibleMembershipDetails : providerEligibleMembershipList) {
                taskList.add(() -> producer.postToKafka(providerEligibleMembershipDetails, (JobName.RUN_PROVIDER_ELIGIBLE_MEMBERSHIP.getValue() + "_" +
                        providerEligibleMembershipDetails.getProviderGroupId() + providerEligibleMembershipDetails.getProviderState() + providerEligibleMembershipDetails.getProgramYear())));
            }
            totalElements = MemberGapsKafkaUtil.executeKafkaPushing(executorService, taskList);
            log.info("{} Publishing Provider Eligible Membership to Provider MS  {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), "******* Started ****************");

            // Producing Elements to Topic parallelly
            StopWatch stopWatch = StopWatch.createStarted();
            jobUtilility.producingElementsParallellyToTopic(executorService, taskList);
            stopWatch.stop();
            log.info(" Provider Eligible Membership Producer - Time took for producing messages to kafka in ms is ::" + stopWatch.getTime() + " for " + totalElements + "  messages ");
        } catch (Exception e) {
            log.error("Exception while puhing message to kafka for {}", e);
            throw new RuntimeException(e.getMessage());
        }
        return providerEligibleMembershipFlatDataList.size();
    }

    private List<ProviderEligibleMembership> convertToJSON(List<ProviderEligibleMembershipFlatData> providerEligibleMembershipDetailsList) {

        Map<String, List<ProviderEligibleMembershipFlatData>> groupByPriceMap = providerEligibleMembershipDetailsList.stream().collect(Collectors.groupingBy(p -> (p.getProviderGroupId() + p.getProviderState() + p.getProviderId() + p.getProviderName()),
                Collectors.mapping(Function.identity(), Collectors.toList())));

        List<ProviderEligibleMembership> providerEligibleMembershipDetailList = new ArrayList<>();
        for (Map.Entry<String, List<ProviderEligibleMembershipFlatData>> entry : groupByPriceMap.entrySet()) {

            ProviderEligibleMembership providerEligibleMembershipDetail = new ProviderEligibleMembership();


            providerEligibleMembershipDetail.setProviderGroupId(entry.getValue().get(0).getProviderGroupId());
            providerEligibleMembershipDetail.setProviderState(entry.getValue().get(0).getProviderState());
            providerEligibleMembershipDetail.setProviderId(entry.getValue().get(0).getProviderId());
            providerEligibleMembershipDetail.setProgramYear(entry.getValue().get(0).getProgramYear());
            providerEligibleMembershipDetail.setProviderName(entry.getValue().get(0).getProviderName());

            Map<String, List<ProviderEligibleMembershipFlatData>> clientsMap = entry.getValue().stream().collect(Collectors.groupingBy(p -> (p.getLobName()),
                    Collectors.mapping(Function.identity(), Collectors.toList())));


            List<ProviderPerformance> performaceDetailsList = new ArrayList<>();

            for (Map.Entry<String, List<ProviderEligibleMembershipFlatData>> entry2 : clientsMap.entrySet()) {
                ProviderPerformance performanceDetail = new ProviderPerformance();
                performanceDetail.setLob(entry2.getKey());
                List<ClientStats> clientDetailsList = new ArrayList<>();

                for (ProviderEligibleMembershipFlatData details : entry2.getValue()) {
                    ClientStats clientDetails = new ClientStats();
                    clientDetails.setClientId(details.getClientId());
                    clientDetails.setClientName(details.getClientName());
                    PerformanceStats performanceStatsDetails = new PerformanceStats();
                    performanceStatsDetails.setEligibleMembershipCount(details.getEligibleMemberCount());
                    clientDetails.setPerformanceStats(performanceStatsDetails);
                    clientDetailsList.add(clientDetails);
                    performanceDetail.setClientStats(clientDetailsList);

                }
                performaceDetailsList.add(performanceDetail);
            }
            providerEligibleMembershipDetail.setProviderPerformance(performaceDetailsList);
            providerEligibleMembershipDetailList.add(providerEligibleMembershipDetail);

        }

        return providerEligibleMembershipDetailList;

    }

}