package com.optum.rqns.ftm.repository.commandcenter;

import com.optum.rqns.ftm.enums.JobName;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.HashMap;

@Repository
@Slf4j
@RequiredArgsConstructor
public class CCGrowthRateRepositoryImpl implements CCGrowthRateRepository {

    @Autowired
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
    private final HashMap<String, Object> paramMap = new HashMap<>();


    @Override
    public int updateAgreedStatusByIPEFlag(Integer programYear) {
        paramMap.put(PROGRAM_YEAR, programYear);
        paramMap.put(UPDATED_BY, JobName.RUN_CC_GROWTH_RATE.getValue());
        return namedParameterJdbcTemplate.update(UPDATE_AGREED_GROWTH_RATE_STATUS_BY_IPE_FLAG, paramMap);
    }

    @Override
    public int updateAgreedStatusByDeployActual(Integer programYear) {
        paramMap.put(PROGRAM_YEAR, programYear);
        paramMap.put(UPDATED_BY, JobName.RUN_CC_GROWTH_RATE.getValue());
        return namedParameterJdbcTemplate.update(UPDATE_AGREED_GROWTH_RATE_STATUS_BY_YTD_ACTUAL, paramMap);
    }

    @Override
    public int updateEngagedStatusByDeployActual(Integer programYear) {
        paramMap.put(PROGRAM_YEAR, programYear);
        paramMap.put(UPDATED_BY,  JobName.RUN_CC_GROWTH_RATE.getValue());
        return namedParameterJdbcTemplate.update(UPDATE_ENGAGED_GROWTH_RATE_STATUS_BY_YTD_ACTUAL, paramMap);
    }

    @Override
    public int flagAgreedAndEngagedTo0(Integer programYear) {
        paramMap.put(PROGRAM_YEAR, programYear);
        paramMap.put(UPDATED_BY,  JobName.RUN_CC_GROWTH_RATE.getValue());
        return namedParameterJdbcTemplate.update(FLAG_AGREED_AND_ENGAGED_TO_0, paramMap);
    }

    @Override
    public int updateMOMGrowthRateTable(Integer programYear) {
        paramMap.put(PROGRAM_YEAR, programYear);
        paramMap.put(UPDATED_BY,  JobName.RUN_CC_GROWTH_RATE.getValue());
        return namedParameterJdbcTemplate.update(UPDATE_MOM_GROWTHRATE, paramMap);
    }

    private static final String UPDATE_AGREED_GROWTH_RATE_STATUS_BY_IPE_FLAG = "update ProgPerf.ProviderGroupExtended " +
            "set IsAgreed = 1, UpdatedBy=:UpdatedBy, UpdatedDate=GetUtcDate() " +
            "where IPEFlag = 'Y' " +
            "and ProgramYear = :ProgramYear";

    private static final String UPDATE_AGREED_GROWTH_RATE_STATUS_BY_YTD_ACTUAL = "MERGE ProgPerf.ProviderGroupExtended as tgt " +
            "Using ( " +
            " Select distinct pgp.ProviderGroupID ,pgp.State ,pgp.ProgramYear  " +
            " from ProgPerf.ProviderGroupPerformance pgp with (nolock) " +
            " where pgp.ProgramYear = :ProgramYear " +
            " and pgp.DeployYTDActual >=1 " +
            " and pgp.DurationValue = (select DurationValue from ProgPerf.ProgramYearCalendar pyc where StartDate <= (SELECT CAST( getUTCDate() AS Date )) AND  " +
            "  EndDate >= (SELECT CAST( getUTCDate() AS Date )) and DurationType = 'Week' )  " +
            ") as src  " +
            "on ( " +
            " src.ProviderGroupID = tgt.ProviderGroupID  " +
            " and src.State = tgt.State  " +
            " and src.ProgramYear = tgt.ProgramYear  " +
            ") " +
            "when MATCHED THEN  " +
            " Update set tgt.IsAgreed = 1, tgt.UpdatedBy = :UpdatedBy, tgt.UpdatedDate = GetUTCDate() " +
            "when not matched THEN  " +
            " insert(ProviderGroupId,state,ProgramYear,IsAgreed,IsEngaged, CreatedBy, CreatedDate, UpdatedBy, UpdatedDate) " +
            " values(src.ProviderGroupId,src.state,src.ProgramYear,1,0,:UpdatedBy,GetUTCDate(),:UpdatedBy,GetUTCDate() );";

    public static final String UPDATE_ENGAGED_GROWTH_RATE_STATUS_BY_YTD_ACTUAL = "MERGE ProgPerf.ProviderGroupExtended as tgt " +
            "Using ( " +
            " Select pgp.ProviderGroupID ,pgp.State ,pgp.ProgramYear,  " +
            "    sum(pgp.DeployYTDActual) as deployTotal, sum(pgp.ReturnedNetCnaYtdActual) as returnToal " +
            " from ProgPerf.ProviderGroupPerformance pgp with (nolock) " +
            " where pgp.ProgramYear = :ProgramYear " +
            "  and pgp.DurationValue = (select DurationValue from ProgPerf.ProgramYearCalendar pyc where  StartDate <= (SELECT CAST( getUTCDate() AS Date )) AND  " +
            "    EndDate >= (SELECT CAST( getUTCDate() AS Date )) and DurationType = 'Week') " +
            "  and pgp.ServiceLevel = 'All' and pgp.ClientName = 'All' " +
            " Group By pgp.ProviderGroupID ,pgp.State ,pgp.ProgramYear " +
            " HAVING  " +
            " sum(pgp.DeployYTDActual) >= (select TRY_CONVERT(int,value) as value from ProgPerf.MasterConfiguration mc where mc.code = 'CCGrowthRateDeployActualThreshold') " +
            " and sum(pgp.ReturnedNetCnaYtdActual) >= (select TRY_CONVERT(float,value) as value from ProgPerf.MasterConfiguration mc where mc.code = 'CCGrowthRateReturnActualPercentageThreshold') /100 * sum(pgp.DeployYTDActual)  " +
            ") as src  " +
            "on ( " +
            " src.ProviderGroupID = tgt.ProviderGroupID  " +
            " and src.State = tgt.State  " +
            " and src.ProgramYear = tgt.ProgramYear  " +
            ") " +
            "when MATCHED THEN  " +
            " Update set tgt.IsEngaged = 1, tgt.UpdatedBy = :UpdatedBy, tgt.UpdatedDate = GetUTCDate() " +
            "when not matched THEN  " +
            " insert(ProviderGroupId,state,ProgramYear,IsAgreed,IsEngaged, CreatedBy, CreatedDate, UpdatedBy, UpdatedDate)  " +
            " values(src.ProviderGroupId,src.state,src.ProgramYear,0,1,:UpdatedBy,GetUTCDate(),:UpdatedBy,GetUTCDate() );";

    public static final String FLAG_AGREED_AND_ENGAGED_TO_0 = "update ProgPerf.ProviderGroupExtended " +
            "set IsAgreed = 0, IsEngaged = 0 " +
            "where  ProgramYear = :ProgramYear";

    public static final String UPDATE_MOM_GROWTHRATE = "MERGE ProgPerf.CommandCenterGrowthRate as tgt  " +
            "using( " +
            " select  :ProgramYear as ProgramYear,  " +
            " LEFT(DATENAME(m,getutcdate()),3) as Month,rs.*, " +
            " round(cast(rs.AgreedYTD as float)/rs.TotalProviderGroups * 100 ,2) as AgreedYTDPercent, " +
            " round(cast(rs.EngagedYTD as float)/rs.TotalProviderGroups * 100 ,2) EngagedYTDPercent " +
            " from ( " +
            "  SELECT count(ProviderGroupId) as TotalProviderGroups , " +
            "  sum(case when IsAgreed  =1 then 1 end) as AgreedYTD, " +
            "  sum(case when IsEngaged =1 then 1 end) as EngagedYTD " +
            "  from ProgPerf.ProviderGroupExtended pge  " +
            "  where pge.ProgramYear=:ProgramYear " +
            " ) as rs " +
            ") as src " +
            "ON  " +
            "(src.ProgramYear = tgt.ProgramYear " +
            "and src.Month = tgt.Month) " +
            "when MATCHED THEN  " +
            " update set tgt.AgreedYTD = src.AgreedYTD, tgt.EngagedYTD=src.EngagedYTD, " +
            " tgt.AgreedYTDPercent=src.AgreedYTDPercent,tgt.EngagedYTDPercent= src.EngagedYTDPercent, " +
            " tgt.TotalProviderGroups = src.TotalProviderGroups, tgt.UpdatedBy = :UpdatedBy, tgt.UpdatedDate = GetUTCDate() " +
            "when not MATCHED THEN  " +
            " insert(ProgramYear,[Month],AgreedYTD,EngagedYTD,AgreedYTDPercent,EngagedYTDPercent,TotalProviderGroups, CreatedBy, CreatedDate, UpdatedBy, UpdatedDate) " +
            " VALUES (src.ProgramYear,src.[Month],src.AgreedYTD,src.EngagedYTD,src.AgreedYTDPercent,src.EngagedYTDPercent,src.TotalProviderGroups , :UpdatedBy,GetUTCDate(),:UpdatedBy,GetUTCDate() ); " +
            " ";

    private static final String PROGRAM_YEAR = "ProgramYear";
    private static final String UPDATED_BY = "UpdatedBy";

}
