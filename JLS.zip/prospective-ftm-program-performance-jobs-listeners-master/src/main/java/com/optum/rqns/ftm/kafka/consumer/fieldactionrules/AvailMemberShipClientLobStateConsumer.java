package com.optum.rqns.ftm.kafka.consumer.fieldactionrules;

import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.consumer.JobEventConsumer;
import com.optum.rqns.ftm.repository.common.CommonRepositoryImpl;
import com.optum.rqns.ftm.service.fieldactionrules.AvailMemberShipClientLobStateServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.context.annotation.Profile;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.annotation.TopicPartition;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

@Profile("fieldActionRules")
@Component
@Slf4j
public class AvailMemberShipClientLobStateConsumer extends JobEventConsumer {

    public AvailMemberShipClientLobStateConsumer(final AvailMemberShipClientLobStateServiceImpl availMemberShipClientLobStateService, final CommonRepositoryImpl commonRepository) {
        super(availMemberShipClientLobStateService, commonRepository);
    }

    @KafkaListener(topicPartitions = {@TopicPartition(topic = "${spring.gcpkafka.properties.topics.jobEvent}", partitions = {"30"})},
            containerFactory = "jobEventKafkaListenerContainerFactory", autoStartup = "true")
    public void onMessage(ConsumerRecord<String, JobEvent> record, Acknowledgment acknowledgment) {
        log.info("{} Begin Consumer Available MemberShip ClientLobState Rule : {}", super.generateTransactionId(record), record);
        processMessage(30, record, acknowledgment);
    }
}
