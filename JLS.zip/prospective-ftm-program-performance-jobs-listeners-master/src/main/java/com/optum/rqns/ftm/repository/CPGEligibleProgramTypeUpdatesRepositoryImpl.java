package com.optum.rqns.ftm.repository;

import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.enums.GroupsToExecute;
import com.optum.rqns.ftm.model.providergroup.PAFXMemberData;
import com.optum.rqns.ftm.model.providergroup.ProviderGroup;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
@Slf4j
public class CPGEligibleProgramTypeUpdatesRepositoryImpl implements CPGEligibleProgramTypeUpdatesRepository {
    public static final String BATCHSIZE = "BATCHSIZE";
    public static final String OFFSET = "OFFSET";
    public static final String PROGRAM_YEAR = "ProgramYear";
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;


    private static final String MEMBER_ASSESSMENT_COUNT_QUERY = "SELECT   " +
            "count(*) as totalCount  " +
            "FROM   " +
            "ProgPerf.MemberAssessment with (NOLOCK)";

    private static final String MEMBER_ASSESSMENT_MERGE_QUERY = "MERGE ProgPerf.[MemberAssessment] AS tgt " +
            "USING ( " +
            "(select DISTINCT  * from " +
            "(SELECT   EligibleProgramType, CPG, ClientId, LobName, ProviderGroupId, [ProviderState], ProgramYear, GlobalMemberId " +
            "FROM ProgPerf.[PafExMemberAssessment] WITH (NOLOCK) " +
            "WHERE ProgramYear = :ProgramYear and IsSuppressed ='N' %s " +
            "and RecordStatus <> 'Deleted'  " +
            "ORDER BY [id] OFFSET :OFFSET ROWS FETCH NEXT :BATCHSIZE ROWS ONLY) as batch) " +
            ") AS src " +
            "ON ( " +
            "tgt.clientid = src.ClientId " +
            "AND tgt.lob2 = src.LobName " +
            "AND tgt.prov_group_id = src.ProviderGroupId " +
            "AND tgt.[providerstate] = src.[ProviderState] " +
            "AND tgt.project_year = src.ProgramYear " +
            "AND tgt.mbr_glb_id = src.GlobalMemberId " +
            "AND (ISNULL(tgt.EligibleProgramType,'') != ISNULL(src.EligibleProgramType,'') OR ISNULL(tgt.CPG,'') != ISNULL(src.CPG,'')) " +
            ") " +
            "WHEN MATCHED " +
            "THEN " +
            "UPDATE " +
            "SET tgt.EligibleProgramType = src.EligibleProgramType " +
            ", tgt.CPG = src.CPG " +
            ", tgt.UpdatedDate = getUtcDate() ; ";

    private static final String MEMBER_GAP_MERGE_QUERY ="MERGE ProgPerf.[MemberAssessmentGap] AS tgt  " +
            "USING (  " +
            "(select DISTINCT * from  " +
            "(SELECT EligibleProgramType, CPG, ClientId, LobName, ProviderGroupId, [ProviderState], ProgramYear, GlobalMemberId  " +
            "FROM ProgPerf.[PafExMemberAssessment]  WITH (NOLOCK) " +
            "WHERE ProgramYear = :ProgramYear  and IsSuppressed ='N' %s " +
            "and RecordStatus <> 'Deleted'  " +
            "ORDER BY [ID] OFFSET :OFFSET ROWS FETCH NEXT :BATCHSIZE ROWS ONLY ) as batchgap)  " +
            ") AS src  " +
            "ON (  " +
            "tgt.ClientId =  src.ClientId  " +
            "AND tgt.LOBName = src.LobName  " +
            "AND tgt.ProviderGroupID = src.ProviderGroupId  " +
            "AND tgt.[State] = src.[ProviderState]  " +
            "AND tgt.ProgramYear = src.ProgramYear  " +
            "AND tgt.MemberGlobalID = src.GlobalMemberId  " +
            "AND (ISNULL(tgt.EligibleProgramType,'') != ISNULL(src.EligibleProgramType,'') OR ISNULL(tgt.CPG,'') != ISNULL(src.CPG,''))  " +
            ")  " +
            "WHEN MATCHED  " +
            "THEN  " +
            "UPDATE  " +
            "SET tgt.EligibleProgramType = src.EligibleProgramType  " +
            ", tgt.CPG = src.CPG  " +
            ",tgt.Modifiedby=:updatedBy  " +
            ", tgt.ModifiedDate = getUtcDate();  ";

    private static final String UPSERT_PROVIDER_GROUP_EXTENDED_ELIGIBLE_PROGRAMTYPE = "MERGE INTO ProgPerf.ProviderGroupExtended AS tgt USING (VALUES " +
            "        (:ProviderGroupID, :State, :ProgramYear, :EligibleProgramType, :UpdatedBy))" +
            "        AS src " +
            "       (ProviderGroupID,State,ProgramYear,EligibleProgramType,UpdatedBy)" +
            "       ON ( tgt.ProviderGroupID = src.ProviderGroupID AND tgt.State = src.State AND tgt.ProgramYear = src.ProgramYear)" +
            "       WHEN MATCHED THEN UPDATE SET" +
            "       tgt.EligibleProgramType=src.EligibleProgramType, tgt.UpdatedBy=src.UpdatedBy, tgt.UpdatedDate=getUtcDate() " +
            "       WHEN NOT MATCHED THEN" +
            "       INSERT (ProviderGroupID,State,ProgramYear,EligibleProgramType,CreatedBy,CreatedDate,UpdatedBy,UpdatedDate)" +
            "       VALUES (src.ProviderGroupID,src.State,src.ProgramYear,src.EligibleProgramType," +
            "       'PAFDeployUpdate',GETUTCDATE(),src.UpdatedBy,getUtcDate());";

    private static final String PAFX_GROUPS_COMMON_COUNT_QUERY = "SELECT ProviderGroupId from ProgPerf.PafExMemberAssessment WITH (NOLOCK)" +
            "        WHERE ProgramYear = :ProgramYear and IsSuppressed ='N' %s " +
            "        GROUP BY ProviderGroupId ";

    private static final String PAFX_GROUPS_COUNT_QUERY = "select count(*) AS totalCount from (" + PAFX_GROUPS_COMMON_COUNT_QUERY + ") AS PAFXMemberCount";

    public static final String PAFX_MEMBERS_CURRENT_PROGRAM_YEAR_COUNT_QUERY = "select count(*) AS totalCount from ProgPerf.PafExMemberAssessment WITH (NOLOCK) " +
            " WHERE ProgramYear = %s and IsSuppressed ='N' %s ";

    private static final String PAFX_MEMBER_PROVIDERGROUP_QUERY =  PAFX_GROUPS_COMMON_COUNT_QUERY +
            "       ORDER BY [ProviderGroupId] "+
            "       OFFSET :OFFSET ROWS FETCH NEXT :BATCHSIZE ROWS ONLY";

    private static final String PAFX_MEMBER_GROUPBY_QUERY = "SELECT DISTINCT pafx.ProviderGroupId, pafx.ProviderState, pafx.ProgramYear, pafx.EligibleProgramType AS EligibleProgType " +
            "       FROM ProgPerf.PafExMemberAssessment pafx WITH (NOLOCK)" +
            "       WHERE ProviderGroupId IN (%s)  AND ProgramYear = %s and IsSuppressed ='N'  ";

    private static final String PROVIDERGROUP_EXTENDED_QUERY = "SELECT ProviderGroupID, State, ProgramYear, EligibleProgramType from ProgPerf.ProviderGroupExtended WITH (NOLOCK) " +
            "       WHERE ProviderGroupId IN (%s) " +
            "       AND ProgramYear = %s";

    public CPGEligibleProgramTypeUpdatesRepositoryImpl(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
        this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
    }



    @Override
    public Long getRecordMemberAssessmentCount() {
        return namedParameterJdbcTemplate.queryForObject(MEMBER_ASSESSMENT_COUNT_QUERY, new HashMap<>(), Long.class);
    }


    @Override
    public Integer mergeMemberAssessmentData(int batchSize, Integer batchOffset, Integer programYear, String groupsToExecute, String joblastrunsuccessfuldate) {
        SqlParameterSource sqlParameterSource = new MapSqlParameterSource(BATCHSIZE, batchSize)
                .addValue(OFFSET, batchOffset)
                .addValue(PROGRAM_YEAR,programYear);

        log.info("MergeMemberAssessmentData batch size {} offset {}", batchSize, batchOffset);
        String query= "";
        if(groupsToExecute.equalsIgnoreCase(GroupsToExecute.ALL.getValue())){
            query=String.format(MEMBER_ASSESSMENT_MERGE_QUERY,"");
        }else{
            query=String.format(MEMBER_ASSESSMENT_MERGE_QUERY," and UpdatedDate >'"+joblastrunsuccessfuldate+"' ");
        }

        return this.namedParameterJdbcTemplate.update(query, sqlParameterSource);
    }

    @Override
    public Integer mergeMemberGapData(int batchSize, Integer offset, Integer programYear, String groupsToExecute, String joblastrunsuccessfuldate) {
        SqlParameterSource sqlParameterSource = new MapSqlParameterSource(BATCHSIZE, batchSize)
                .addValue(OFFSET, offset)
                .addValue("updatedBy","PAFDeployUpdate")
                .addValue(PROGRAM_YEAR,programYear);

        log.info("mergeMemberGapData batch size {} offset {}", batchSize, offset);
        String query= "";
        if(groupsToExecute.equalsIgnoreCase(GroupsToExecute.ALL.getValue())){
            query=String.format(MEMBER_GAP_MERGE_QUERY,"");
        }else{
            query=String.format(MEMBER_GAP_MERGE_QUERY," and UpdatedDate >'"+joblastrunsuccessfuldate+"' ");
        }
        return this.namedParameterJdbcTemplate.update(query, sqlParameterSource);
    }

    @Override
    public int[] updateBatchQueries(List<Map<String, Object>> batchValues) {

        return namedParameterJdbcTemplate.batchUpdate(UPSERT_PROVIDER_GROUP_EXTENDED_ELIGIBLE_PROGRAMTYPE, batchValues.toArray(new Map[batchValues.size()]));

    }

    @Override
    public Long getPafxGroupsRecordCount(Integer programYear, String grousptoExecute, String joblastrunsuccessfuldate) {
        SqlParameterSource sqlParameterSource = new MapSqlParameterSource(PROGRAM_YEAR,programYear);
        String query="";
        if(grousptoExecute.equalsIgnoreCase(GroupsToExecute.ALL.getValue())){
             query=String.format(PAFX_GROUPS_COUNT_QUERY,"");
        }else{
             query=String.format(PAFX_GROUPS_COUNT_QUERY," and UpdatedDate >'"+joblastrunsuccessfuldate+"' ");
        }

        return namedParameterJdbcTemplate.queryForObject(query, sqlParameterSource, Long.class);
    }

    @Override
    public List<PAFXMemberData> getPafxMembersProgramTypeBasedOnGroups(String providerGroupIds, Integer programYear) {
        String query=String.format(PAFX_MEMBER_GROUPBY_QUERY,providerGroupIds, programYear);
        return namedParameterJdbcTemplate.query(query, new BeanPropertyRowMapper<>(PAFXMemberData.class));
    }

    @Override
    public List<ProviderGroup> getProviderGroupExtendedRecords(String providerGroupIds, Integer programYear) {
        String query=String.format(PROVIDERGROUP_EXTENDED_QUERY,providerGroupIds, programYear);
        return this.namedParameterJdbcTemplate.query(query, new BeanPropertyRowMapper<>(ProviderGroup.class));
    }

    @Override
    public List<PAFXMemberData> getPafxProviderGroupIds(int batchSize, Integer offset, Integer programYear, String groupstoexecute, String joblastrunsuccessfuldate) {
        SqlParameterSource sqlParameterSource = new MapSqlParameterSource(BATCHSIZE, batchSize)
                .addValue(OFFSET, offset)
                .addValue(PROGRAM_YEAR,programYear);
        String query="";
        if(groupstoexecute.equalsIgnoreCase(GroupsToExecute.ALL.getValue())){
             query=String.format(PAFX_MEMBER_PROVIDERGROUP_QUERY,"");
        }else{
             query=String.format(PAFX_MEMBER_PROVIDERGROUP_QUERY," and UpdatedDate >'"+joblastrunsuccessfuldate+"' ");
        }
        log.info("PAFXMember Group By groupId batch size {} offset {}", batchSize, offset);
        return namedParameterJdbcTemplate.query(query, sqlParameterSource, new BeanPropertyRowMapper<>(PAFXMemberData.class));
    }

    @Override
    public Long getPafxMembersForCurrentProgramYearRecordCount(Integer programYear, String groupsToExecute, String joblastrunsuccessfuldate) {

        String query="";
        if(groupsToExecute.equalsIgnoreCase(GroupsToExecute.ALL.getValue())){
            query=String.format(PAFX_MEMBERS_CURRENT_PROGRAM_YEAR_COUNT_QUERY,programYear, "");
        }else{
            query=String.format(PAFX_MEMBERS_CURRENT_PROGRAM_YEAR_COUNT_QUERY,programYear, " and UpdatedDate >'"+joblastrunsuccessfuldate+"' ");
        }

        return namedParameterJdbcTemplate.queryForObject(query, new HashMap<>(), Long.class);
    }


}
