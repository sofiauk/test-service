package com.optum.rqns.ftm.kafka.consumer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.kafka.consumer.redis.RedisMessageHandler;
import com.optum.rqns.ftm.kafka.producer.JobEventProducer;
import com.optum.rqns.ftm.model.JobAlert;
import com.optum.rqns.ftm.model.JobRunConfiguration;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.exception.ProgramPerformanceJobListenerException;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.model.fieldactionrules.JobDetails;
import com.optum.rqns.ftm.model.fieldactionrules.JobSequence;
import com.optum.rqns.ftm.repository.common.CommonRepository;
import com.optum.rqns.ftm.repository.jobalerts.PrometheusJobAlertRepositoryImpl;
import com.optum.rqns.ftm.service.IJob;
import com.optum.rqns.ftm.service.jobalerts.PrometheusJobAlertServiceImpl;
import com.optum.rqns.ftm.util.ProgramPerformanceJobUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.data.redis.connection.Message;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.lang.Nullable;

import java.lang.management.ManagementFactory;
import java.lang.management.RuntimeMXBean;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.UUID;
import java.util.stream.Stream;

@Profile({"rqnsFtmJobs","fieldActionRules","newProviderGroupRule","memberGapJobs","qfoPerfJobs","pafxDeployUpdate"})
@Slf4j
public abstract class JobEventConsumer implements RedisMessageHandler {

    private IJob jobService;
    private CommonRepository commonRepository;

    @Value("${jobs.concurrencyThresholdTime}")
    public int jobConcurrencyThresholdTime; //int minutes

    private final String consumerUUID = UUID.randomUUID().toString();

    protected Boolean updateJobConfigurationOnSuccess = true;
    protected Boolean checkForDuplicateJobExecutionBasedOnThresholdTime = true;

    @Value("${ftm-job-alert-enabled}")
    private boolean isJobAlertEnabled; // Prometheus Custom Job Alerts

    @Value("${ftm-job-alert-exclusions}")
    private String jobAlertExclusionList; //Alerts excluded for these jobs

    @Autowired
    private PrometheusJobAlertRepositoryImpl jobAlertRepository;

    @Autowired
    private PrometheusJobAlertServiceImpl prometheusJobAlertService;

    @Autowired
    private JobEventProducer jobEventProducer;

    @Autowired
    private ObjectMapper mapper;
    public JobEventConsumer(IJob jobService, CommonRepository commonRepository) {
        this.jobService = jobService;
        this.commonRepository = commonRepository;
    }

    protected String generateTransactionId(ConsumerRecord<String, JobEvent> record) {
        String messageKey = record.key();
        String jobName = record.value().getJobName().toString();
        return generateTransactionId(jobName,messageKey);
    }

    protected String generateTransactionId(String jobName,String messageKey) {

        StringBuilder transactionIdBuilder = new StringBuilder();
        transactionIdBuilder.append(String.format("Job Name: %s | ", jobName));
        transactionIdBuilder.append(String.format("Message Key: %s | ", messageKey));
        transactionIdBuilder.append(String.format("Processor ID: %s | ", consumerUUID));
        String transactionId = transactionIdBuilder.toString();
        ProgramPerformanceJobUtil.TransactionIdLogger.setTransactionIdentifier(transactionId);
        ProgramPerformanceJobUtil.TransactionIdLogger.setMessageIdIdentifier(messageKey);

        return transactionId;
    }


    public void processMessage(int partitionId, ConsumerRecord<String, JobEvent> record, Acknowledgment acknowledgment) {
        MDC.put("messageId", record.key());
        if (record == null) {
            acknowledgment.acknowledge();
            return;
        }

        JobEvent jobEvent = record.value();

        JobName jobName = Stream.of(JobName.values())
                .filter(v -> v.getValue().equals(jobEvent.getJobName().toString()))
                .findFirst()
                .orElse(null);

        if (jobName == null) {
            acknowledgment.acknowledge();
            return;
        }

        acknowledgment.acknowledge();
        StringBuilder msgBuilder = new StringBuilder();
        msgBuilder.append(String.format("JobEvent record received from DataSync.Program.Performance.JobEvent topic and partition %d | ", partitionId));
        msgBuilder.append(String.format("with offset %s | ", record.offset()));
        this.processJobEvent(jobEvent,record.key(),msgBuilder);
    }
    public void processMessage(String event){
        JobEvent jobEvent = this.convertStringToJobEvent(event);
        if(jobEvent == null){
            return;
        }
        //TODO: add time stamp to uuid
        UUID uuid = UUID.randomUUID();
        String messageKey = uuid.toString();
        MDC.put("Redis channel", jobEvent.getJobName().toString());
        MDC.put("Generated Message Key",messageKey);
        JobName jobName = Stream.of(JobName.values())
                .filter(v -> v.getValue().equals(jobEvent.getJobName().toString()))
                .findFirst()
                .orElse(null);

        if (jobName == null) {
            return;
        }
        log.info("{} Begin Consumer Run Weekly Jobs : {}", generateTransactionId (jobEvent.getJobName().toString(),messageKey), jobEvent);

        StringBuilder msgBuilder = new StringBuilder();
        msgBuilder.append(String.format("JobEvent record received from DataSync.Program.Performance.JobEvent Redis Channel %s | ", jobEvent.getJobName().toString()));
        //msgBuilder.append(String.format("with offset %s | ", record.offset()));
        this.processJobEvent(jobEvent,messageKey,msgBuilder);
    }

    private void processJobEvent(JobEvent jobEvent,String messageKey ,StringBuilder msgBuilder){


        JobName jobName = Stream.of(JobName.values())
                .filter(v -> v.getValue().equals(jobEvent.getJobName().toString()))
                .findFirst()
                .orElse(null);

        msgBuilder.append(String.format("Job event Detail %s.", jobEvent.toString()));

        /**
         * 1. Check Job isActive
         * 2. If active start the process
         * 3. Check JobExecutionHistory Job instance is running, if Yes leave the process else continue the process
         * 4. Update record in JobExecutionHistory with IN_PROGRESS
         * 5. If record inserted then get JobId
         * 6. Update JobExecutionHistory Success job completed
         * 7. Based on Job status update the JobConfiguration
         *
         */
        Boolean isActive = checkIsActive(jobName.getValue());
        log.info("{} JobName : {} - isActive : {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), jobEvent.getJobName(), isActive);

        if (isActive) {
            Integer historyCount = checkIfJobExecutionAlreadyRegistered(jobName.getValue(), messageKey, jobConcurrencyThresholdTime);
            if (historyCount > 0) {
                log.warn("{} Another instance of this job is already running. Aborting current process.", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
            } else {
                log.info("{} Update job configuration table as Job Started.", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());

                try {
                    Integer rowsUpdated = commonRepository.upsertJobRunConfiguration(JobRunConfiguration.builder()
                            .jobName(jobName)
                            .updateJobEvent(true)
                            .updateMessageKey(true)
                            .updateMessage(true)
                            .updateJobStart(true)
                            .updateAffectedRows(true)
                            .jobEvent(jobEvent.toString())
                            .messageKey(messageKey)
                            .message("")
                            .createdBy(Constants.SYSTEM)
                            .modifiedBy(Constants.SYSTEM)
                            .status(Status.IN_PROGRESS)
                            .errorMessage("")
                            .affectedRows(0L)
                            .build());

                    if (rowsUpdated > 0) {
                        try {
                            int jobId = commonRepository.getJobIdByName(jobName.getValue());
                            log.info("{} JobId, Adding new record into jobExecutionHistory table.", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), jobId);

                            try {
                                int execId = commonRepository.updateJobExecutionHistoryAsJobStart(jobId, messageKey, jobEvent.toString(), "");
                                JobStatus jobStatus = null;
                                try {
                                    jobStatus = jobService.executeJob(jobEvent);

                                    if (updateJobConfigurationOnSuccess) {

                                        //If Success Then update message else error message
                                        if (Status.SUCCESS.equals(jobStatus.getStatus())) {

                                            //JobExecutionHistory
                                            commonRepository.updateJobExecutionHistoryAsJobEnd(execId, Status.SUCCESS, "", jobStatus.getMessage(), jobStatus.getUpdatedRows());

                                            if(jobEvent.getCascadeEvents()) {
                                                processCascadedJobs(jobEvent,false);
                                                log.info("{} processed cascaded Jobs sucessfully", jobEvent);
                                            }

                                            //Update Success message
                                            commonRepository.upsertJobRunConfiguration(
                                                    JobRunConfiguration
                                                            .builder()
                                                            .jobName(jobName)
                                                            .status(jobStatus.getStatus())
                                                            .updateJobEnd(true)
                                                            .updateLastSuccessfulRun(true)
                                                            .updateLastRun(true)
                                                            .updateMessage(true)
                                                            .message(jobStatus.getMessage())
                                                            .updateAffectedRows(true)
                                                            .affectedRows(jobStatus.getUpdatedRows())
                                                            .updateErrorMessage(true)
                                                            .errorMessage("")
                                                            .createdBy(Constants.SYSTEM)
                                                            .modifiedBy(Constants.SYSTEM)
                                                            .build()
                                            );
                                        } else {
                                            //JobExecutionHistory
                                            commonRepository.updateJobExecutionHistoryAsJobEnd(execId, Status.FAILURE, jobStatus.getMessage(), "", jobStatus.getUpdatedRows());
                                            if(jobEvent.getCascadeEvents()) {
                                                processCascadedJobs(jobEvent,true);
                                                log.info("{} processed cascaded Jobs sucessfully", jobEvent);
                                            }
                                            //Update ErrorMessage
                                            commonRepository.upsertJobRunConfiguration(
                                                    JobRunConfiguration
                                                            .builder()
                                                            .jobName(jobName)
                                                            .status(jobStatus.getStatus())
                                                            .updateJobEnd(true)
                                                            .updateLastSuccessfulRun(false)
                                                            .updateLastRun(true)
                                                            .updateErrorMessage(true)
                                                            .errorMessage(jobStatus.getMessage())
                                                            .updateAffectedRows(true)
                                                            .affectedRows(jobStatus.getUpdatedRows())
                                                            .updateMessage(true)
                                                            .message("")
                                                            .createdBy(Constants.SYSTEM)
                                                            .modifiedBy(Constants.SYSTEM)
                                                            .build()
                                            );
                                        }

                                    }

                                } catch (Exception e) {
                                    //ProgramPerformanceException gives null when we do err.getMessage();
                                    //hence trying to retrieve core exception that was thrown
                                    Throwable coreError = getCoreError(e);
                                    String errorMessage = coreError.getMessage();
                                    log.error("{} Exception occurred while executing JobEvent. Error: {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), coreError);
                                    commonRepository.updateJobExecutionHistoryAsJobEnd(execId, Status.FAILURE, errorMessage, "", 0L);
                                    commonRepository.upsertJobRunConfiguration(
                                            JobRunConfiguration
                                                    .builder()
                                                    .jobName(jobName)
                                                    .status(jobStatus.getStatus())
                                                    .updateErrorMessage(true)
                                                    .updateLastRun(true)
                                                    .errorMessage(jobStatus.getMessage())
                                                    .updateJobEnd(true)
                                                    .createdBy(Constants.SYSTEM)
                                                    .modifiedBy(Constants.SYSTEM)
                                                    .build());

                                }
                            } catch (Exception e) {
                                String errorMessage = e.getMessage();
                                log.error("{} Failed to add new record in job execution history. Error message: {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), errorMessage);
                                commonRepository.upsertJobRunConfiguration(
                                        JobRunConfiguration.builder()
                                                .jobName(jobName)
                                                .updateJobEnd(true)
                                                .updateJobStart(false)
                                                .updateLastSuccessfulRun(false)
                                                .updateLastRun(true)
                                                .updateAffectedRows(false)
                                                .updateErrorMessage(true)
                                                .errorMessage(jobName.getValue().concat(" has erred out " + errorMessage))
                                                .modifiedBy(Constants.SYSTEM)
                                                .status(Status.FAILURE)
                                                .build());

                            }
                        } catch (Exception e) {
                            String errorMessage = e.getMessage();
                            log.error("{} Failed to fetch job id. Error Details: {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), errorMessage);
                            commonRepository.upsertJobRunConfiguration(
                                    JobRunConfiguration.builder()
                                            .jobName(jobName)
                                            .updateJobEnd(true)
                                            .updateJobStart(false)
                                            .updateLastSuccessfulRun(false)
                                            .updateLastRun(true)
                                            .updateAffectedRows(false)
                                            .errorMessage(jobName.getValue().concat(" has erred out with " + errorMessage))
                                            .modifiedBy(Constants.SYSTEM)
                                            .status(Status.FAILURE)
                                            .build());
                        }
                    }

                    if (isJobAlertEnabled) {
                        boolean isJobInExlcusionList = false;
                        if (!jobAlertExclusionList.isEmpty() && jobAlertExclusionList != null) {
                            String[] jobList = jobAlertExclusionList.split(",");
                            isJobInExlcusionList = isJobinList(jobEvent.getJobName().toString(), jobList);
                        }
                        if (!isJobInExlcusionList) {
                            String result = sendPrometheusAlerts(jobEvent.getJobName().toString());
                            if (result.equals("SUCCESS")) {
                                log.info("Job Alerts sent to Prometheus Successfully", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), result);
                            } else {
                                log.warn("Sending alerts to Prometheus failed", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), result);
                            }
                        } else {
                            log.info("{} Job is mentioned in exclusion list.Prometheus alerts are not sent", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
                        }

                    } else {
                        log.info("{} Prometheus Job Alert Service is disabled", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
                    }

                } catch (Exception e) {
                    log.error("{} Failed to update job configuration table. Error message: {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), e.getMessage());
                }
            }
        } else {
            log.info("Job {} is not active", jobName.getValue());
        }


    }

    private Throwable getCoreError(Throwable error) {
        //ProgramPerformanceException gives null when we do error.getMessage();
        //hence trying to retrieve core exception that was thrown
        if (!(error instanceof ProgramPerformanceJobListenerException)) {
            return error;
        } else {
            return getCoreError(((ProgramPerformanceJobListenerException) error).getCustomException());
        }
    }

    /**
     * Check Job isActive status
     *
     * @param jobName
     * @return
     */
    private Boolean checkIsActive(String jobName) {

        try {
            return commonRepository.getJobIsActiveByName(jobName);
        } catch (Exception e) {
            log.error("{} Failed to fetch isActive: {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), e.getMessage());
        }
        return false;
    }

    /**
     * Check JobExecutionHistory with Threshold
     *
     * @param jobName
     * @param messageKey
     * @param thresholdTime
     * @return
     */
    private Integer checkIfJobExecutionAlreadyRegistered(String jobName, String messageKey, Integer thresholdTime) {

        LoggingForConsumerIdentity();//This is temporary logging step for debugging stage issue - multiple instance of jobs running simultaneously.

        int jobId = getJobId(jobName, thresholdTime);
        if (jobId > 0) {
            try {
                int historyCount = checkByLastRunTime(jobId, thresholdTime);
                log.info("{} History count to Evaluating history count by time threshold.", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), historyCount);

                if (historyCount == 0) {
                    checkByMessageKey(messageKey, jobId);
                }
                return historyCount;
            } catch (Exception e) {
                log.error("{} Error while trying to retrieve history count by time threshold. Error details: ", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), e.getMessage());
                throw new ProgramPerformanceJobListenerException(e.getMessage());
            }

        }
        return 0;
    }

    private int getJobId(String jobName, Integer thresholdTime) {

        try {
            return commonRepository.getJobIdByName(jobName);

        } catch (Exception e) {
            log.error("{} Failed to fetch job id. {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), e.getMessage());
        }
        return 0;
    }

    /**
     * Check JobExecutionHistory with MessageKey
     *
     * @param messageKey
     * @param jobId
     * @return
     */
    private Integer checkByMessageKey(String messageKey, Integer jobId) {
        MDC.put(Constants.MESSAGE_ID, messageKey);
        log.info("{} Check for job id {} by message key {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), jobId, messageKey);

        try {
            int historyCount = commonRepository.getJobExecutionHistoryByMessageKey(jobId, messageKey);
            log.info("{} History count By message key is {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), historyCount);
            if (historyCount > 0) {
                log.info("{} Job execution history already registered by another instance/thread.", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
            }
            return historyCount;

        } catch (Exception e) {
            String errorMessage = e.getMessage();
            log.error("{} Failed to get job execution history by message key. Error details: {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), errorMessage);
            throw new ProgramPerformanceJobListenerException(errorMessage);
        }

    }

    /**
     * Check Job last run time
     *
     * @param jobId
     * @param thresholdInMinutes
     * @return
     */
    private Integer checkByLastRunTime(Integer jobId, Integer thresholdInMinutes) {
        MDC.put(Constants.MESSAGE_ID, ProgramPerformanceJobUtil.TransactionIdLogger.getMessageIdIdentifier());
        if (!this.checkForDuplicateJobExecutionBasedOnThresholdTime) {
            log.info("{} Check job execution history by time for this job is: {}, hence skipping.", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), this.checkForDuplicateJobExecutionBasedOnThresholdTime);
            return 0;
        }
        log.info("{} Check for job id {} by time {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), jobId, thresholdInMinutes);

        int historyCount = 0;
        try {
            historyCount = commonRepository.getJobExecutionHistoryByTime(jobId, thresholdInMinutes);
            log.info("{} History count By time threshold is {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), historyCount);
            if (historyCount > 0) {
                log.info("{} Job execution history already registered by another instance/thread within past {} minutes", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), thresholdInMinutes);
            }
        } catch (Exception e) {
            String errorMessage = e.getMessage();
            log.error("{} Failed to get job execution history by time. Error details: {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), errorMessage);
            throw new ProgramPerformanceJobListenerException(errorMessage);
        }
        return historyCount;

    }

    private void LoggingForConsumerIdentity() {
        MDC.put(Constants.MESSAGE_ID, ProgramPerformanceJobUtil.TransactionIdLogger.getMessageIdIdentifier());
        StringBuilder logMessage = new StringBuilder();
        long threadID = Thread.currentThread().getId();
        logMessage.append(String.format("Thread Name: %s | ", Thread.currentThread().getName()));
        logMessage.append(String.format("Thread ID: %s | ", threadID));
        long pid = getProcessID();
        logMessage.append(String.format("Process ID: %s.", pid));

        log.info("Process tracker: {} {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), logMessage.toString());
    }

    private long getProcessID() {
        RuntimeMXBean bean = ManagementFactory.getRuntimeMXBean();
        // Get name representing the running Java virtual machine.
        // It returns something like 35892@LHTU05CG834148Q. Where the value
        // before the @ symbol is the PID.
        String jvmName = bean.getName();
        log.info("{} process running with BeanName: {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), jvmName);
        // Extract the PID by splitting the string returned by the
        // bean.getName() method.
        long pid = Long.valueOf(jvmName.split("@")[0]);
        return pid;
    }

    //Sending the jobAlert details to alert manager through prometheus
    private String sendPrometheusAlerts(String jobName) {
        log.info("Sending JobAlert data to alert manager service");
        String status = null;
        try {
            JobAlert jobAlert = jobAlertRepository.getJobAlertByName(jobName);
            log.info("{} JobAlert details fetched {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
            status = prometheusJobAlertService.sendAlerts(jobAlert);
            log.info("{} Prometheus Alerts Status {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), status);

        } catch (Exception e) {
            log.error("{} Failed to get job alert  details by jobName . Error details: {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), e.getMessage());
        }
        return status;
    }

    // Method to check if the JOb is in the exclusion list for sending alerts
    private boolean isJobinList(String jobName, String[] jobList) {
        boolean isJobInList = false;
        for (String job : jobList) {
            if (jobName.equals(job)) isJobInList = true;

        }
        return isJobInList;
    }


    private JobEvent getJobEventForCascadedJobs(JobEvent jobEvent, String jobName, String jobInput) {

        return JobEvent.newBuilder()
                .setJobName(jobName)
                .setGroupsToExecute(jobEvent.getGroupsToExecute().toString())
                .setExecutionWeek(jobEvent.getExecutionWeek().toString())
                .setStatus(Status.SUCCESS.getValue())
                .setProgramYear(jobEvent.getProgramYear())
                .setTimeStamp(Instant.now())
                .setCascadeEvents(jobEvent.getCascadeEvents())
                .setJobInput(jobInput)
                .setFrequency(null)
                .build();

    }

    private void processCascadedJobs(JobEvent jobEvent, boolean onError) {
        log.info("{} started processing the cascaded Jobs", jobEvent.getJobName());
        JobSequence jobSequence = getChildJobs(jobEvent);
        if (jobSequence != null) {
            log.info("{} child JobSequence ",jobSequence.toString());
            jobSequence.getCascadedJobs().forEach(jobDetails -> {
                log.info("{} child job started", jobDetails.getJobName());
                if (checkFrequencyMatchAndOnErrorTrigger(jobDetails,onError)) {
                    JobEvent childJobEvent = getJobEventForCascadedJobs(jobEvent, jobDetails.getJobName(), jobDetails.getJobInput());
                    if("REDIS".equalsIgnoreCase(jobEvent.getEventType().toString()))
                    {
                        childJobEvent.setEventType("REDIS");
                    }
                    jobEventProducer.postToMsgQue(childJobEvent);
                }else{
                    log.info("{} child job frequency doesn't match ",jobDetails.getJobName());
                }

            });
        }
    }

    public JobSequence getChildJobs(JobEvent jobEvent) {
        String childJobs = commonRepository.getCascadedJobs(jobEvent.getJobName().toString());
        JobSequence jobSequence = null;
        if (childJobs != null) {
            ObjectMapper objectMapper = new ObjectMapper();
            try {
                jobSequence = objectMapper.readValue(childJobs, JobSequence.class);
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
        }
        return jobSequence;

    }

    public boolean checkFrequencyMatchAndOnErrorTrigger(JobDetails jobDetails, boolean onError) {
        LocalDateTime dateTime = LocalDateTime.ofInstant(Instant.now(), ZoneOffset.UTC);
        String frequency = commonRepository.getJobFrequency(jobDetails.getJobName());
        if (frequency == null || frequency.equalsIgnoreCase(dateTime.getDayOfWeek().toString())) {
            if( (onError && jobDetails.isTriggerOnError() )  || !onError)
                return true;
            else
                return false;
        }
        return false;
    }
    private JobEvent convertStringToJobEvent(String event)  {
        try {
            return mapper.readValue(event, JobEvent.class);
        }catch(Exception e){
            log.error(" Failed to convert the Job Event {}",e);
        }
        return null;
    }

    @Override
    public void onMessage(Message message, @Nullable byte[] var2){
        this.processMessage(new String(message.getBody()));
    }

}

