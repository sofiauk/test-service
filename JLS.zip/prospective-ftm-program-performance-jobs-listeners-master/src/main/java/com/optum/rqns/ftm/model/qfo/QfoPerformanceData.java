package com.optum.rqns.ftm.model.qfo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.math.BigDecimal;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class QfoPerformanceData {

    private String providerGroupId;
    private String programYear;
    private BigDecimal overallStarRating;
    private BigDecimal mapCpiStarRating;
    private BigDecimal mapCpiPartDStarRating;
    private Integer mapCpiEligiblePatients;
    private Integer mcaipTotalAssessed;
    private Integer acvCompleted;
    private Integer conditionsAssessed;
    private Integer totalPatients;
    private Integer totalSuspectConditions;

}
