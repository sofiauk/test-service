package com.optum.rqns.ftm.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum DMNRuleDefinitionDetails {

    REJECCT_AGING_DMN_RULE(JobName.REJECT_AGING_JOB,"RejectAgingGroupLevelAction","RejectAgingGroupLevelRule", "RejectAgingGroupLevelNamespace"),
    NEW_PROVIDER_MANUAL_ASSOCIATION_JOB(JobName.NEW_PROVIDER_MANUAL_ASSOCIATION_JOB,"NewProviderManualAssociationAction","NewProviderManualAssociationRule", "NewProviderManualAssociationNamespace"),
    RUN_CHANGE_SERVICE_LEVEL_RULE(JobName.RUN_CHANGE_SERVICE_LEVEL_RULE,"ChangeServiceAction","ChangeServiceRule", "ChangeServiceNamespace"),
    AVAIL_MEMBERSHIP_CLIENT_LOB_STATE_RULE(JobName.AVAIL_MEMBERSHIP_CLIENT_LOB_STATE_RULE,"AvailMembershipClientLobStateAction","AvailMembershipClientLobStateRule", "AvailMembershipClientLobStateNamespace"),
    RUN_NEW_PROVIDER_GROUP_MEMBERSHIP(JobName.RUN_NEW_PROVIDER_GROUP_MEMBERSHIP,"NewMemberShipAction","NewMemberShipRule", "NewMemberShipNamespace"),
    RETURN_METRIC_JOB(JobName.RETURN_METRIC_JOB,"ReturnTargetTrackingAction","ReturnTargetTrackingRule", "ReturnTargetTrackingNamespace");

    private JobName jobName;
    private String inputDataActionName;
    private String modelName;
    private String modelNamespace;

    public static DMNRuleDefinitionDetails getDMNRuleDefinitionDetails(String jobName) {
        if(DMNRuleDefinitionDetails.REJECCT_AGING_DMN_RULE.getJobName().getValue().equalsIgnoreCase(jobName)){
            return DMNRuleDefinitionDetails.REJECCT_AGING_DMN_RULE;
        }else if(DMNRuleDefinitionDetails.NEW_PROVIDER_MANUAL_ASSOCIATION_JOB.getJobName().getValue().equalsIgnoreCase(jobName)){
            return DMNRuleDefinitionDetails.NEW_PROVIDER_MANUAL_ASSOCIATION_JOB;
        }else if(DMNRuleDefinitionDetails.RUN_CHANGE_SERVICE_LEVEL_RULE.getJobName().getValue().equalsIgnoreCase(jobName)){
            return DMNRuleDefinitionDetails.RUN_CHANGE_SERVICE_LEVEL_RULE;
        }else if(DMNRuleDefinitionDetails.AVAIL_MEMBERSHIP_CLIENT_LOB_STATE_RULE.getJobName().getValue().equalsIgnoreCase(jobName)){
            return DMNRuleDefinitionDetails.AVAIL_MEMBERSHIP_CLIENT_LOB_STATE_RULE;
        }else if(DMNRuleDefinitionDetails.RUN_NEW_PROVIDER_GROUP_MEMBERSHIP.getJobName().getValue().equalsIgnoreCase(jobName)){
            return DMNRuleDefinitionDetails.RUN_NEW_PROVIDER_GROUP_MEMBERSHIP;
        }else if(DMNRuleDefinitionDetails.RETURN_METRIC_JOB.getJobName().getValue().equalsIgnoreCase(jobName)){
            return DMNRuleDefinitionDetails.RETURN_METRIC_JOB;
        }
        return null;
    }

}
