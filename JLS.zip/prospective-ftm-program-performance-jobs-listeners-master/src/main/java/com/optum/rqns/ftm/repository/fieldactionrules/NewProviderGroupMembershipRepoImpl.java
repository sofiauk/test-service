package com.optum.rqns.ftm.repository.fieldactionrules;

import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.RuleEnum;
import com.optum.rqns.ftm.model.fieldactionrules.NewMemberShipAction;
import com.optum.rqns.ftm.model.fieldactionrules.RuleAction;
import com.optum.rqns.ftm.util.ProgramPerformanceJobUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
@Slf4j
public class NewProviderGroupMembershipRepoImpl implements NewProviderGroupMembershipRepo {

    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
    private JdbcTemplate jdbcTemplate;

    public NewProviderGroupMembershipRepoImpl(NamedParameterJdbcTemplate namedParameterJdbcTemplate,JdbcTemplate jdbcTemplate) {
        this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
        this.jdbcTemplate = jdbcTemplate;
    }

    private static final String UPDATE_BASE_LINE = "update ProgPerf.ProviderGroupExtended set Baseline = ?, " +
            " UpdatedDate=getUtcDate(), UpdatedBy='RunNewProviderGroupMembershipFieldActionRule', IsActionSent = 1" +
            " where ProviderGroupId = ? and State = ? and ProgramYear = ?";

    public static final String GET_ELIGLIBLE_PROVIDER_STATE_TO_SEND_ACTION ="select   " +
            "pgp.ProviderGroupID ,   " +
            "pgp.State,   " +
            "pgp.ProgramYear,   " +
            "SUM(pgp.EligibleDeployableMemberCount) as eligibleMembercount,   " +
            "pge.baseline,   " +
            "ao.owneruuid,   " +
            "(SELECT TOP 1 pg.ProviderGroupName FROM ProgPerf.ProviderGroup pg WITH (NOLOCK) WHERE pg.ProviderGroupID =pgp. ProviderGroupId and pg.State = pgp.State ) as ProviderGroupName   " +
            "from   " +
            "ProgPerf.ProviderGroupPerformance pgp WITH (NOLOCK),   " +
            "ProgPerf.Accounts a WITH (NOLOCK),   " +
            "ProgPerf.AccountOwner ao WITH (NOLOCK),   " +
            "ProgPerf.ProviderGroupExtended pge WITH (NOLOCK)   " +
            "where   " +
            "pgp.isCurrentWeekForPerformance = 1   " +
            "and pgp.ClientName = 'ALL'   " +
            "and pgp.ServiceLevel = 'ALL'   " +
            "and pgp.EligibleDeployableMemberCount is not null   " +
            "and pgp.ProgramYear =(   " +
            "select   " +
            "mc.value   " +
            "from   " +
            "ProgPerf.MasterConfiguration mc WITH (NOLOCK)   " +
            "where   " +
            "mc.code = 'CurrentProgramYear' )   " +
            "and a.GroupId = pgp.ProviderGroupID   " +
            "and a.State = pgp.State   " +
            "and a.AccountId = ao.AccountId   " +
            "and ( (a.ServiceLevel = 'HCA'   " +
            "and ao.ownertype = 'HCA' )   " +
            "or (a.ServiceLevel = 'PSC-P'   " +
            "and ao.ownertype = 'PSC'))   " +
            "and ao.owneruuid  is not null  " +
            "and ao.owneruuid  <> ''  " +
            "and pgp.ProviderGroupID = pge.providergroupid   " +
            "and pgp.State = pge.state   " +
            "and pgp.ProgramYear = pge.ProgramYear   " +
            "and pge.IsActionSent = 0   " +
            "and exists (   " +
            "select   " +
            "*   " +
            "from   " +
            "ProgPerf.MemberAssessment ma WITH (NOLOCK)   " +
            "where   " +
            "ma.deriveddeployed = 1   " +
            "and ma.RecordChangeType <> 'Deleted'   " +
            "and ma.distributionchannel = 'PAFGEN'   " +
            "and ma.project_year = pgp.ProgramYear   " +
            "and ma.prov_group_id = pgp.ProviderGroupID   " +
            "and ma.providerstate = pgp.State )   " +
            "group by   " +
            "pgp.ProviderGroupID ,   " +
            "pgp.State,   " +
            "pgp.ProgramYear,owneruuid,baseline   " +
            "order by pgp.ProviderGroupID ,pgp.State OFFSET :begin ROWS FETCH NEXT :end ROWS ONLY   ";


    public static final String GET_COUNT_ELIGLIBLE_PROVIDER_STATE_TO_SEND_ACTION ="SELECT    " +
            "COUNT(*) AS totalrowcount    " +
            "FROM    " +
            "(    " +
            "select    " +
            "pge.ID ,    " +
            "pge.ProviderGroupID ,    " +
            "pge.State    " +
            "from    " +
            "ProgPerf.ProviderGroupExtended pge with (nolock)    " +
            "join (    " +
            "select    " +
            "pgp.ProviderGroupID ,    " +
            "pgp.State,    " +
            "pgp.ProgramYear    " +
            "from    " +
            "ProgPerf.ProviderGroupPerformance pgp with (nolock)    " +
            "where    " +
            "pgp.isCurrentWeekForPerformance = 1    " +
            "and pgp.ClientName = 'ALL'    " +
            "and pgp.ServiceLevel = 'ALL'    " +
            "and pgp.EligibleDeployableMemberCount is not null    " +
            "and pgp.ProgramYear =(    " +
            "select    " +
            "mc.value    " +
            "from    " +
            "ProgPerf.MasterConfiguration mc with (nolock)    " +
            "where    " +
            "mc.code = 'CurrentProgramYear' )    " +
            "and exists (    " +
            "SELECT    " +
            "a.GroupId ,    " +
            "a.State ,    " +
            "a.ServiceLevel ,    " +
            "ao.ownertype    " +
            "from    " +
            "ProgPerf.Accounts a with (nolock),    " +
            "ProgPerf.AccountOwner ao with (nolock)    " +
            "where    " +
            "a.GroupId = pgp.ProviderGroupID    " +
            "and a.State = pgp.State    " +
            "and a.AccountId = ao.AccountId    " +
            "and ( (a.ServiceLevel = 'HCA'    " +
            "and ao.ownertype = 'HCA' )    " +
            "or (a.ServiceLevel = 'PSC-P'    " +
            "and ao.ownertype = 'PSC'))    " +
            "and ao.owneruuid  is not null  " +
            "and ao.owneruuid  <> '' ) " +
            "and EXISTS (    " +
            "select    " +
            "1    " +
            "from    " +
            "(    " +
            "SELECT    " +
            "ma.prov_group_id ,    " +
            "ma.providerstate    " +
            "from    " +
            "ProgPerf.MemberAssessment ma with (nolock)    " +
            "where    " +
            "ma.deriveddeployed = 1    " +
            "and ma.RecordChangeType <> 'Deleted'    " +
            "and ma.distributionchannel = 'PAFGEN'    " +
            "and ma.project_year = pgp.ProgramYear    " +
            "and exists (    " +
            "select    " +
            "1    " +
            "from    " +
            "ProgPerf.ProviderGroupExtended pge with (nolock)    " +
            "where    " +
            "pge.ProviderGroupID = ma.prov_group_id    " +
            "and pge.State = ma.providerstate    " +
            "and pge.ProgramYear = ma.project_year    " +
            "and pge.IsActionSent = 0 )    " +
            "group by    " +
            "ma.prov_group_id ,    " +
            "ma.providerstate    " +
            "having    " +
            "count(*)>0) as rs    " +
            "where    " +
            "rs.prov_group_id = pgp.ProviderGroupID    " +
            "and rs.providerstate = pgp.State    " +
            "and pgp.ClientName = 'ALL'    " +
            "and pgp.ServiceLevel = 'ALL'    " +
            "and pgp.ProgramYear =(    " +
            "select    " +
            "mc.value    " +
            "from    " +
            "ProgPerf.MasterConfiguration mc with (nolock)    " +
            "where    " +
            "mc.code = 'CurrentProgramYear' )    " +
            ")    " +
            "GROUP BY    " +
            "pgp.ProviderGroupID ,    " +
            "pgp.State,    " +
            "pgp.ProgramYear ) as trs on    " +
            "pge.ProviderGroupID = trs.ProviderGroupID    " +
            "and pge.state = trs.state    " +
            "and pge.ProgramYear = trs.ProgramYear    " +
            "where    " +
            "pge.IsActionSent = 0 ) as RS    ";

    @Override
    public List<RuleAction> processtoSendActionForNewProviderMembership(Integer beginIndex,int batchSize) {
        log.info("Fetching Eligible provider&state combination to sendAction for New Provider Grp Membership details :{} ", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
        Map<String, Object> bindingMap = new HashMap<>();
        bindingMap.put("begin", beginIndex);
        bindingMap.put("end", batchSize);
        return namedParameterJdbcTemplate.query(GET_ELIGLIBLE_PROVIDER_STATE_TO_SEND_ACTION,bindingMap, new NewProviderGroupMembershipRowMapper());
    }

    @Override
    public List<Integer> getRowCountforNewProviderMembership(int batchsize) {
        log.info("Fetching  count Eligible provider&state combination to sendAction for New Provider Grp Membership details :{} ", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
       Integer totalRows =   namedParameterJdbcTemplate.queryForObject(GET_COUNT_ELIGLIBLE_PROVIDER_STATE_TO_SEND_ACTION, new HashMap<>(), Integer.class);
        log.info("Fetching  count Eligible provider&state combination to sendAction for New Provider Grp Membership details  :{}, totalRows :{} ", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(),totalRows);
        List<Integer> batches = new ArrayList<>();
        if (totalRows > 0) {
            for (int batchOffset = 0; batchOffset <= totalRows; batchOffset += batchsize) {
                batches.add(batchOffset);
            }
        }
        return batches;
    }

    @Override
    @Transactional
    public int[] updateBaseLine(List<RuleAction> actions) {
        return this.jdbcTemplate.batchUpdate(
                UPDATE_BASE_LINE,
                new BatchPreparedStatementSetter() {
                    public void setValues(PreparedStatement ps, int i)
                            throws SQLException {
                        NewMemberShipAction newMemberShipAction = (NewMemberShipAction)actions.get(i);
                        ps.setLong(1, newMemberShipAction.getCurrentWeekMemberShipCount());
                        ps.setString(2, newMemberShipAction.getProviderGroupId());
                        ps.setString(3, newMemberShipAction.getState());
                        ps.setInt(4, newMemberShipAction.getProgramYear());
                    }
                    public int getBatchSize() {
                        return actions.size();
                    }
                });
    }

    public static class NewProviderGroupMembershipRowMapper implements RowMapper<RuleAction> {

        @Override
        public RuleAction mapRow(ResultSet rs, int rowNum) throws SQLException {
            List<String> userList=new ArrayList<>();
            StringBuilder ruleResult=new StringBuilder();
            NewMemberShipAction newMemberShipAction =new NewMemberShipAction();
            newMemberShipAction.setCurrentWeekMemberShipCount(rs.getLong("eligibleMembercount"));
            newMemberShipAction.setPreviousWeekMemberShipCount(rs.getLong("Baseline"));
            newMemberShipAction.setProviderGroupId(rs.getString("ProviderGroupID"));
            newMemberShipAction.setState(rs.getString("State"));
            newMemberShipAction.setProgramYear(rs.getInt("ProgramYear"));
            newMemberShipAction.setProviderGroupName(rs.getString("ProviderGroupName")!=null?rs.getString("ProviderGroupName"):" ");
            newMemberShipAction.setIsShared(false);
            userList.add(rs.getString("OwnerUUID"));
            newMemberShipAction.setUserUuid(userList);
            newMemberShipAction.setRuleType(RuleEnum.NEW_MEMBERSHIP_AVAILABLE.getValue());
            newMemberShipAction.setVerifyRuleResult(true);
            return newMemberShipAction;
        }
    }
}

