package com.optum.rqns.ftm.repository.qfo;

import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.model.qfo.QFOPatientExperienceScore;

import java.util.List;

public interface QFOPatientExperienceScoresRepository {

    List<QFOPatientExperienceScore> fetchQFOPatientExperienceScores(int batchSize, Integer batchOffset, JobEvent jobEvent);

    Long getRecordCount(JobEvent jobEvent);
}
