package com.optum.rqns.ftm.repository.qfo;


import com.optum.rqns.ftm.model.qfo.CommonProgramYearCalenderDTO;
import com.optum.rqns.ftm.model.qfo.QfoPerformanceData;

import java.util.List;

public interface QFOPerformanceRepository {

 Integer calculateAllSuspectConditions(int offset, int batchSize, Integer programYear, CommonProgramYearCalenderDTO commonProgramYearCalenderDTO);

 Long getTotalSuspectConditionsCount(Integer programYear);

 String fetchLastRunDate();

 Long getModifiedSuspectConditionsCount(Integer programYear);

 Integer calculateModifiedSuspectConditions(Integer offset, int batchSize, Integer programYear, CommonProgramYearCalenderDTO commonProgramYearCalenderDTO);

 Long getProviderGroupMemberQualityRecordCount(String executeForAllProviderGroups, Integer programYear);

 Integer loadProviderGroupPerformanceQualityDetails(int batchSize, Integer batchOffset, String executeForAllProviderGroups, CommonProgramYearCalenderDTO commonProgramYearCalenderDTO);

 Long getStarRatingIngestionGroupsRecordCount(String canExecuteForAllProviderGroups, Integer programYear);

 Integer mergeProviderGroupPerformanceDetailsWithASR(int batchSize, Integer batchOffset, String canExecuteForAllProviderGroups, Integer programYear ,CommonProgramYearCalenderDTO commonProgramYearCalenderDTO);

 Long getHealthSystemRecordCount(String executeForAllProviderGroups, CommonProgramYearCalenderDTO commonProgramYearCalenderDTO);

 Integer mergeHealthSystemPerfDetails(int batchSize, Integer batchOffset, String executeForAllProviderGroups, CommonProgramYearCalenderDTO commonProgramYearCalenderDTO);

 Long getStarRatingGlidePathGroupsRecordCount(String groupsToExecute, Integer programYear, boolean isModified, String ratingType);

 Integer mergeStarRatingGlidePathWithRatingIngestion(int batchSize, Integer offset, String groupsToExecute, Integer programYear, CommonProgramYearCalenderDTO commonProgramYearCalenderDTO, boolean isModified, String ratingType);

 Long getStarRatingGlidePathCount(Integer programYear, String durationValue);

 Long getQfoPerformanceDataBobSyncCount(Integer programYear, CommonProgramYearCalenderDTO commonProgramYearCalenderDTO, String groupsToExecute);

 List<QfoPerformanceData> getQfoPerformanceDataBobSyncDetails(int batchSize, Integer batchOffset, Integer programYear, String durationValue, String groupExecute);

 void resetQualityCountsForProviderGroups( Integer programYear, String durationValue );

 void resetSuspectCountsForProviderGroups( Integer programYear, String durationValue );

 List<QfoPerformanceData> getPreviousMonthDisabledProvidersData(Integer programYear);
}
