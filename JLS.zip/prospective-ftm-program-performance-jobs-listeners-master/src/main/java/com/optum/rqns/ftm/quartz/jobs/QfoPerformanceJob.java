package com.optum.rqns.ftm.quartz.jobs;

import com.optum.rqns.ftm.enums.ExecutionWeek;
import com.optum.rqns.ftm.enums.GroupsToExecute;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.producer.JobEventProducer;
import com.optum.rqns.ftm.repository.common.CommonRepository;
import lombok.extern.slf4j.Slf4j;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.time.LocalDate;

@Profile("rqnsFtmJobs")
@Slf4j
@Component
@DisallowConcurrentExecution
public class QfoPerformanceJob implements Job {

    @Autowired
    private JobEventProducer jobEventProducer;

    @Autowired
    private CommonRepository commonRepository;

    private static final String JOB_NAME = JobName.QFOPERFORMANCE.getValue();
    private static final String GROUPS_TO_EXECUTE = GroupsToExecute.MODIFIED.getValue();
    private static final String EXECUTION_WEEK = ExecutionWeek.ALL.getValue();
    private static final String STATUS = Status.IN_PROGRESS.getValue();
    private static final String DESCRIPTION = "Notification to QFO Performance Job to ProgramPerformance Jobs ";

    @Override
    /**
     * Execute method will invoke with Cron Job
     */
    public void execute(JobExecutionContext context) {
        log.info("Job {}  starting @ {}", context.getJobDetail().getKey().getName(), context.getFireTime());
        notifyQfoPerformanceJob(context, buildJobEvent());

    }

    /**
     * Build Job Event for Member Suspect Gaps
     * @return
     */
    private JobEvent buildJobEvent() {
        Integer programYear = LocalDate.now().getYear(); //QFO Calender year based so directly getting from date
        // commonRepository.getCurrentProgramYear();
        return JobEvent.newBuilder().setJobName(JOB_NAME).setGroupsToExecute(GROUPS_TO_EXECUTE)
                .setExecutionWeek(EXECUTION_WEEK).setStatus(STATUS)
                .setProgramYear(programYear)
                .setTimeStamp(Instant.now()).setCascadeEvents(true).build();
    }

    /**
     * Post Job event message to Kafka
     * @param context
     * @param jobEvent
     */
    private void notifyQfoPerformanceJob(JobExecutionContext context, JobEvent jobEvent) {
        try {
            boolean sent = jobEventProducer.postToKafka(jobEvent);
            if (!sent) log.error("Failed to send {}", DESCRIPTION);
            log.info("Successfully sent {}", DESCRIPTION);
        } catch (Exception e) {
            log.error("Job Failed " + "Job ** {} ** starting @ {}  with Exception ## {} ",
                    context.getJobDetail().getKey().getName(), context.getFireTime(), e.getMessage());

        }
    }

}
