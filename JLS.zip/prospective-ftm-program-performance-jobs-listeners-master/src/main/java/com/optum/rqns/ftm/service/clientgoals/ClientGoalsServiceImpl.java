package com.optum.rqns.ftm.service.clientgoals;

import com.fasterxml.uuid.Generators;
import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.Lob;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.avro.models.v1.program.performance.provider.ClientGoals;
import com.optum.rqns.ftm.kafka.avro.models.v1.program.performance.provider.ProgPerfProviderMSSync;
import com.optum.rqns.ftm.kafka.producer.KeyBasedProviderSyncProducer;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.model.clientgoals.ClientGoalsData;
import com.optum.rqns.ftm.repository.clientgoals.ClientGoalsRepository;
import com.optum.rqns.ftm.util.JobUtilility;
import com.optum.rqns.ftm.util.ProgramPerformanceJobUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.time.StopWatch;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

@Service
@Slf4j
public class ClientGoalsServiceImpl implements ClientGoalsService {

    private ClientGoalsRepository clientGoalsRepository;

    @Autowired
    private KeyBasedProviderSyncProducer producer;

    JobUtilility jobUtilility;

    @Value("${new_providergroup_rule_producer_thread_pool_size}")
    private int producerThreadPoolSize;

    public ClientGoalsServiceImpl(ClientGoalsRepository clientGoalsRepository) {
        this.clientGoalsRepository = clientGoalsRepository;
    }

    public JobStatus executeJob(JobEvent jobEvent) {

        MDC.put(Constants.TRACE_ID, Generators.timeBasedGenerator().generate().toString());
        MDC.put(Constants.TRANSACTION_ID, ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
        MDC.put(Constants.MESSAGE_ID, ProgramPerformanceJobUtil.TransactionIdLogger.getMessageIdIdentifier());

        JobStatus jobStatus = new JobStatus();
        jobUtilility = new JobUtilility();
        log.info("{} jobEvent.ClientGoals() :: {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), jobEvent.getJobName());
        try {
            log.info("{} Inside Run Job ", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());

            AtomicInteger updatedRecords = new AtomicInteger();

            final Long totalRows = this.clientGoalsRepository.getRecordCount(jobEvent.getProgramYear());
            log.info("Client Goals record Count {}", totalRows);

            List<Integer> batches = jobUtilility.getBatches(totalRows);
            log.info("Client Goals total Batches offsets are {}", batches.size());

            batches.stream().forEach(batchOffset -> {

                int publishedClientGoals = sendClientGoalsToProviderMS(Constants.BATCH_SIZE, batchOffset, jobEvent.getProgramYear());
                updatedRecords.addAndGet(publishedClientGoals);
            });

            jobStatus.setStatus(Status.SUCCESS);
            jobStatus.setMessage("Completed ClientGoals Provider MS Producer job successfully");
            jobStatus.setUpdatedRows(updatedRecords.longValue());

        } catch(Exception e){
            log.error("Exception while executing with All ClientGoals Provider MS Producer job : {}", e);

            jobStatus.setStatus(Status.FAILURE);
            jobStatus.setMessage("ClientGoals Provider MS Producer job execution failed : " + e.getMessage());
            jobStatus.setUpdatedRows(0L);
        }
        finally {
            MDC.clear();
        }

        return jobStatus;
    }

    /**
     *
     * @param batchSize
     * @param batchOffset
     * @param programYear
     */
    private int sendClientGoalsToProviderMS(int batchSize, Integer batchOffset, Integer programYear) {

        List<ClientGoalsData> clientGoals = clientGoalsRepository.getClientGoals(Constants.BATCH_SIZE, batchOffset, programYear);

        //For parallel producing
        ExecutorService executorService = Executors.newFixedThreadPool(producerThreadPoolSize);
        List<Callable<Boolean>> taskList = new ArrayList<>();

        clientGoals.stream().forEach(clientGoal -> {

            //Publish message to topic
            taskList.add(() -> {
                return producer.postToKafka(buildProviderGroupOpportunitiesSummaryAvroV1(clientGoal),(JobName.RUN_CLIENT_GOALS.getValue() + "_" +
                        clientGoal.getProviderGroupID() + clientGoal.getState() + clientGoal.getProgramYear() +clientGoal.getClientId() + clientGoal.getClientName() + clientGoal.getLob()));
            });


        });

        log.info("{} Publishing ClientGoals to Provider MS  {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), "******* Started ****************");

        // Producing Elements to Topic parallelly
        StopWatch stopWatch = StopWatch.createStarted();
        jobUtilility.producingElementsParallellyToTopic(executorService, taskList);
        stopWatch.stop();
        log.info("Time took for producing messages to kafka in ms is ::" + stopWatch.getTime() + " and rule is ClientGoals Provider MS Service Impl::");

        log.info("{} Published ClientGoals to Provider MS records {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), clientGoals.size());

        return clientGoals.size();
    }

    /**
     *
     * @param clientGoals
     * @return
     */
    private ProgPerfProviderMSSync buildProviderGroupOpportunitiesSummaryAvroV1(ClientGoalsData clientGoals) {

        ClientGoals clientGoal = new ClientGoals();
        clientGoal.setClientId(clientGoals.getClientId());
        clientGoal.setClientName(clientGoals.getClientName());
        clientGoal.setLob(Lob.valueOf(clientGoals.getLob().toUpperCase()).getValue());

        clientGoal.setHasClientGoals(clientGoals.isHasClientGoals());

        ProgPerfProviderMSSync providerMSSync = new ProgPerfProviderMSSync();
        providerMSSync.setProviderGroupID(clientGoals.getProviderGroupID());
        providerMSSync.setProviderGroupName("");
        providerMSSync.setState(clientGoals.getState());
        providerMSSync.setProgramYear(Integer.parseInt(clientGoals.getProgramYear()));
        providerMSSync.setClientGoals(clientGoal);
        providerMSSync.setMessageType(Constants.CLIENT_GOALS_MESSAGE_TYPE);

        return providerMSSync;
    }

}