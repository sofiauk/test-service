package com.optum.rqns.ftm.model;

import com.optum.rqns.ftm.enums.JobName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class JobConfiguration {
    @NotNull
    private Integer jobID;
    @NotNull
    private JobName jobName;
    private String jobDescription;
    private String createdBy;
    private LocalDateTime createdDate;
    private String modifiedBy;
    private LocalDateTime modifiedDate;
    private LocalDateTime lastSuccessfulRunDate;
    private String messageKey;
    private String errorMessage;
    private String message;
    private String jobEvent;
    private boolean isActive;
    private JobExecutionHistory jobExecutionHistory;
}
