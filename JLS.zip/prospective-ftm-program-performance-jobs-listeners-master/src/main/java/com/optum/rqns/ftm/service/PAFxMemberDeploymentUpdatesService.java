package com.optum.rqns.ftm.service;

import com.optum.rqns.ftm.service.IJob;
import org.springframework.stereotype.Service;

@Service
public interface PAFxMemberDeploymentUpdatesService extends IJob {
}
