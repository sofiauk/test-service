package com.optum.rqns.ftm.model.providergroup;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ProviderGroup {
    private String providerGroupId;
    private String state;
    private Boolean newForDeployment;
    private Boolean newForPOC;
    private Double eligiblePreferredMembers;
    private int programYear;
    private String eligibleProgramType;
}