package com.optum.rqns.ftm.exception;

import lombok.Getter;
import org.springframework.http.HttpStatus;

@Getter
public class ProgramPerformanceJobListenerException extends RuntimeException {
    private static final long serialVersionUID = 1905122041950251207L;

    private final HttpStatus httpStatus;
    private final JobError apiError;
    private final Throwable customException;

    public ProgramPerformanceJobListenerException(HttpStatus httpStatus, JobErrorCode code) {
        super(code.getDetail());
        this.httpStatus = httpStatus;
        this.customException = null;
        this.apiError = new JobError(code.getCode(), code.getDetail(),code.getTitle());
    }

    public ProgramPerformanceJobListenerException(String message) {
        super(message);
        this.apiError = new JobError(JobErrorCode.GENERIC.getCode(), message,message);
        this.customException = null;
        this.httpStatus=null;
    }

}