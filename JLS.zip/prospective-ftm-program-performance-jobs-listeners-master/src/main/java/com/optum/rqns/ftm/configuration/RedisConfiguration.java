package com.optum.rqns.ftm.configuration;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.kafka.consumer.redis.RedisConsumerFactory;
import com.optum.rqns.ftm.kafka.consumer.redis.RedisMessageHandler;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.listener.ChannelTopic;
import org.springframework.data.redis.listener.RedisMessageListenerContainer;
import org.springframework.data.redis.repository.configuration.EnableRedisRepositories;
import org.springframework.data.redis.serializer.Jackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import redis.clients.jedis.JedisClientConfig;

@Log4j2
@Configuration
@EnableRedisRepositories
public class RedisConfiguration {

    @Value("${rqns.ftm.redis.hostname}")
    private String hostname;
    @Value("${rqns.ftm.redis.port}")
    private String port;
    @Value("${rqns.ftm.redis.secret}")
    private String clientSecret;
    @Value("${rqns.ftm.redis.poolMaxIdle}")
    private String pool_max_idle;
    @Value("${rqns.ftm.redis.poolMinIdle}")
    private String pool_min_idle;
    @Value("${rqns.ftm.redis.poolMaxTotal}")
    private String pool_max_total;


    @Bean
    public JedisConnectionFactory redisConnectionFactory() {
        JedisConnectionFactory jedisConnectionFactory = new JedisConnectionFactory();
        try {
            RedisStandaloneConfiguration rconfig = jedisConnectionFactory.getStandaloneConfiguration();
            if (rconfig != null) {
                rconfig.setHostName(hostname);
                rconfig.setPort(Integer.valueOf(port));
                rconfig.setPassword(clientSecret);
            }
            GenericObjectPoolConfig<JedisClientConfig> pool = jedisConnectionFactory.getPoolConfig();
            if (pool != null) {
                pool.setMaxIdle(Integer.valueOf(pool_max_idle));
                pool.setMaxTotal(Integer.valueOf(pool_max_total));
                pool.setMinIdle(Integer.valueOf(pool_min_idle));
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return jedisConnectionFactory;
    }

    @Bean
    public RedisTemplate<String, ObjectNode> redisTemplate() {
        RedisTemplate<String, ObjectNode> template = new RedisTemplate<>();
        template.setConnectionFactory(redisConnectionFactory());
        template.setKeySerializer(new StringRedisSerializer());
        template.setValueSerializer(new Jackson2JsonRedisSerializer<>(ObjectNode.class));
        template.setHashKeySerializer(new StringRedisSerializer());
        template.setHashValueSerializer(new Jackson2JsonRedisSerializer<>(ObjectNode.class));
        return template;
    }

    @Bean
    public RedisMessageListenerContainer redisMessageListenerContainer() {

        RedisMessageListenerContainer container = new RedisMessageListenerContainer();
        RedisConsumerFactory redisConsumerFactory = consumerFactory();
        container.setConnectionFactory(redisConnectionFactory());
        for(JobName jobName:JobName.values()){
            RedisMessageHandler obj = redisConsumerFactory.getInstance(jobName);
            if(obj != null) {
                container.addMessageListener(obj, new ChannelTopic(jobName.getValue()));
            }
        }
        return container;
    }

    @Bean
    public RedisConsumerFactory consumerFactory(){

        RedisConsumerFactory redisConsumerFactory = new RedisConsumerFactory();
        return redisConsumerFactory;
    }

}
