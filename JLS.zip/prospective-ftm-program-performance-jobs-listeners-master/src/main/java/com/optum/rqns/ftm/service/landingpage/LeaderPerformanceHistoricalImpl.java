package com.optum.rqns.ftm.service.landingpage;

import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.exception.ProgramPerformanceJobListenerException;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.model.ProgramYearCalendarDTO;
import com.optum.rqns.ftm.repository.common.CommonRepository;
import com.optum.rqns.ftm.repository.landingpage.LeaderPerformanceHistoricalRepository;
import com.optum.rqns.ftm.repository.landingpage.LeaderPerformanceRepository;
import com.optum.rqns.ftm.repository.users.UsersRepository;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.time.StopWatch;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

@Slf4j
@Service
public class LeaderPerformanceHistoricalImpl implements LeaderPerformanceHistorical {

    @Autowired
    private CommonRepository commonRepository;

    @Autowired
    private UsersRepository usersRepository;

    @Autowired
    LeaderPerformanceHistoricalRepository leaderPerformanceHistoricalRepository;

    @Autowired
    LeaderPerformanceRepository leaderPerformanceRepository;

    List<String> leaders;

    List<String> ics;

    public LeaderPerformanceHistoricalImpl(CommonRepository commonRepository) {
        this.commonRepository = commonRepository;
    }
    public static final String ALL = "All";
    static final List<String> LEADER_ROLES = Arrays.asList("RVP", "Director", "Manager");
    static final List<String> IC_ROLES = Arrays.asList("PSC", "HCA");

    @Override
    public JobStatus executeJob(JobEvent jobEvent) {
        JobStatus jobStatus = new JobStatus();
        log.info("jobevent received is {}", jobEvent);
        jobStatus.setStatus(Status.SUCCESS);
        jobStatus.setUpdatedRows(0l);
        jobStatus.setMessage("Successfully completed Historical Leader Performance job");
        try {
            CharSequence groupsToExecute = jobEvent.getGroupsToExecute();
            boolean isAllProviderGroups = Objects.nonNull(groupsToExecute) && ALL.equalsIgnoreCase(groupsToExecute.toString());
            fetchLeadersAndIcs();
            //Fetch all the Week's other than current week for Proj Year and Proj Year-1
            List<ProgramYearCalendarDTO> allProgramYearsDurations = leaderPerformanceHistoricalRepository.getAllProgramYearsDurations(jobEvent.getProgramYear());
            //Previous Year Current Week
           // ProgramYearCalendarDTO previousYearLastWeekDuration = leaderPerformanceHistoricalRepository.getPrevoiusYearLastWeekDuration(jobEvent.getProgramYear());
            //Current Week for Program Year
            ProgramYearCalendarDTO currentWeekDurationForProgramyear = leaderPerformanceHistoricalRepository.getCurrentWeekDurationForProgramyear(jobEvent.getProgramYear());
            //National Level Historical changes for all the weeks other than current week
            loadHistoricalLeaderPerformanceNational(jobStatus, allProgramYearsDurations, isAllProviderGroups);
            //National Level historical changes for current week of previous year
           // currentWeekHistoricalNationalLeaderPerfForProgramyear(jobStatus, previousYearLastWeekDuration, 1, isAllProviderGroups);
            //National Level historical changes for current week of program year
            currentWeekHistoricalNationalLeaderPerfForProgramyear(jobStatus, currentWeekDurationForProgramyear, 1, isAllProviderGroups);
            //IC level Historical changes for previous year current week
            //loadHistoricalForICs(jobStatus, previousYearLastWeekDuration, ics, 1, isAllProviderGroups);
            //Leaders(Manager, Directors, RVP) level Historical changes for previous year current week
            //loadHistoricalForLeaders(jobStatus, previousYearLastWeekDuration, leaders, 1, isAllProviderGroups);
            //IC level Historical changes for program year current week
            loadHistoricalForICs(jobStatus, currentWeekDurationForProgramyear, ics, 1, isAllProviderGroups);
            //Leaders(Manager, Directors, RVP) level Historical changes for previous year current week
            loadHistoricalForLeaders(jobStatus, currentWeekDurationForProgramyear, leaders, 1, isAllProviderGroups);
        }
        catch (Exception e){
            log.error("Error occurred in Historical Leader Performance job", e);
            jobStatus.setMessage(e.getMessage());
            jobStatus.setStatus(Status.FAILURE);
        }
        return jobStatus;
    }

    private void loadHistoricalLeaderPerformanceNational(JobStatus jobStatus, List<ProgramYearCalendarDTO> allProgramYearsDurations, boolean isAllProviderGroups) {
        try {
            allProgramYearsDurations.parallelStream().forEach(dto -> {
                Long timeTaken;
                StopWatch stopWatch=StopWatch.createStarted();
                long nationalAllCount=leaderPerformanceHistoricalRepository.loadLeaderPerformanceNationalLevelAll(dto,0, isAllProviderGroups);
                timeTaken=stopWatch.getTime();
                log.info("National Level LeaderPerformance of All Clients, LOB, region, state, service levels Data updated for Duration Week {} and Program Year {} updated count {} timeTaken {}", dto.getDurationValue(), dto.getProgramYear(), nationalAllCount, timeTaken);
                jobStatus.setUpdatedRows(jobStatus.getUpdatedRows() + nationalAllCount);
                stopWatch=StopWatch.createStarted();
                long updatedCount = leaderPerformanceHistoricalRepository.loadHistoricalLeaderPerformance(dto, 0,isAllProviderGroups);
                timeTaken=stopWatch.getTime();
                log.info("National Level LeaderPerformance Data updated for Duration Week {} and Program Year {} updated count {} timeTaken {}", dto.getDurationValue(), dto.getProgramYear(), updatedCount, timeTaken);
                jobStatus.setUpdatedRows(jobStatus.getUpdatedRows() + updatedCount);
                loadHistoricalForICs(jobStatus, dto,ics,0,isAllProviderGroups);
                loadHistoricalForLeaders(jobStatus, dto,leaders, 0, isAllProviderGroups);
            });
        } catch (Exception e) {
            log.error("exception occurred in historical leader performance data load ", e);
            throw new ProgramPerformanceJobListenerException(e.getMessage());
        }
    }

    private void currentWeekHistoricalNationalLeaderPerfForProgramyear(JobStatus jobStatus, ProgramYearCalendarDTO programYearCalendarDTO, int isCurrentWeek, boolean isAllProviderGroups) {
        try {
            long nationalAllCount=leaderPerformanceHistoricalRepository.loadLeaderPerformanceNationalLevelAll(programYearCalendarDTO,1, isAllProviderGroups);
            log.info("National Level Leader Performance for All Clients, LOBs, regions, states, service levels current Week Data updated for Duration Week {} and Program Year {} updated count {}", programYearCalendarDTO.getDurationValue(), programYearCalendarDTO.getProgramYear(), nationalAllCount);
            jobStatus.setUpdatedRows(jobStatus.getUpdatedRows() + nationalAllCount);
            long updatedCount = leaderPerformanceHistoricalRepository.loadHistoricalLeaderPerformance(programYearCalendarDTO, isCurrentWeek,isAllProviderGroups);
            log.info("Leader Performance Data updated for Current Duration Week {} and for Program Year {} updated count {} ", programYearCalendarDTO.getDurationValue(), programYearCalendarDTO.getProgramYear(),updatedCount);
            jobStatus.setUpdatedRows(jobStatus.getUpdatedRows() + updatedCount);
        } catch (Exception e) {
            log.error("Exception occured while loading current week historical data load for program year ", e);
            throw e;
        }
    }

    private void fetchLeadersAndIcs() {
        //Fetch RVPs,Directors,Managers
        leaders = usersRepository.getUsersByRole(LEADER_ROLES);
        log.info("RVPs,Directors,Managers size {}", leaders.size());

        //Fetch Individual Contributors
        ics = leaderPerformanceRepository.getUsersByRole(IC_ROLES);
        log.info("Individual Contributors size {}", ics.size());
    }

    private void loadHistoricalForICs(JobStatus jobStatus,ProgramYearCalendarDTO programYearCalendarDTO, List<String> ics, int isCurrentWeek, boolean isAllProviderGroups)
    {
        try {
            ics.parallelStream().forEach(ic -> {
                        int updatedCount = 0;
                        //Fetch Service Levels for this IC
                        List<String> serviceLevels = leaderPerformanceRepository.getServiceLevelForUser(ic);
                        // Load Historical Leader Performance data for this IC and Service Level
                         serviceLevels.parallelStream().forEach(sl -> {
                             StopWatch stopWatch=StopWatch.createStarted();
                             int count= leaderPerformanceHistoricalRepository.loadHistoricalICPerformanceData(ic, sl, programYearCalendarDTO, isCurrentWeek, isAllProviderGroups);
                             long timeTaken=stopWatch.getTime();
                             jobStatus.setUpdatedRows(jobStatus.getUpdatedRows() + count);
                             log.info("IC {} Performance Data updated count {} for Duration Week {} and Program year {} TimeTakenAtServiceLevel for IC {}", ic, updatedCount, programYearCalendarDTO.getDurationValue(), programYearCalendarDTO.getProgramYear(), timeTaken);
                             /*stopWatch= StopWatch.createStarted();
                             int goalCount =leaderPerformanceHistoricalRepository.updateICGoalLeaderPerformance(ic,sl,programYearCalendarDTO,  isAllProviderGroups);
                             jobStatus.setUpdatedRows(jobStatus.getUpdatedRows() + goalCount);
                             long goalTime=stopWatch.getTime();
                             log.info("IC {} Performance Data updated with Actual goal data {} for Duration Week {} and Program year {} timeTakenForGoalUpdateAtIC {} ", ic, goalCount, programYearCalendarDTO.getDurationValue(), programYearCalendarDTO.getProgramYear(), goalTime);*/
                        });
                                /*.map(sl -> leaderPerformanceHistoricalRepository.loadHistoricalICPerformanceData(ic, sl, programYearCalendarDTO, isCurrentWeek, isAllProviderGroups))
                                .reduce(Integer::sum)
                                .orElse(0);

                        log.info("IC {} Performance Data updated count {} for Duration Week {} and Program year {}", ic, updatedCount, programYearCalendarDTO.getDurationValue(), programYearCalendarDTO.getProgramYear());

                        //Update the IC Actual Goal calculation
                    int goalCount = serviceLevels.stream().map(sl->leaderPerformanceHistoricalRepository.updateICGoalLeaderPerformance(ic,sl,programYearCalendarDTO,  isAllProviderGroups))
                            .reduce(Integer::sum)
                            .orElse(0);
                    log.info("IC {} Performance Data updated with Actual goal data {} for Duration Week {} and Program year {}", ic, goalCount, programYearCalendarDTO.getDurationValue(), programYearCalendarDTO.getProgramYear());
                    jobStatus.setUpdatedRows(jobStatus.getUpdatedRows() + goalCount);*/
                    });
        }
        catch (Exception e)
        {
            log.error("Error while loading HistoricalForICs", e.getMessage());
            throw e;
        }
    }

    private  void loadHistoricalForLeaders(JobStatus jobStatus,ProgramYearCalendarDTO programYearCalendarDTO, List<String> leaders, int isCurrentWeek, boolean isAllProviderGroups)
    {
        try {
            //Fetch All IC under that Leaders and sum from LeaderPerformance table.
            leaders.parallelStream()
                    .forEach(leader -> {
                        final List<String> totalReporters = usersRepository.getIcReporters(leader);
                        int updatedCount = 0;
                        if (Objects.nonNull(totalReporters) && !totalReporters.isEmpty()) {
                            log.info("leader {} reporters {}", leader, totalReporters);
                            // Historical Leader Performance data at Leaders Level
                            StopWatch stopWatch=StopWatch.createStarted();
                            updatedCount = leaderPerformanceHistoricalRepository.loadLeadersHistoricalLeaderPerformanceData(leader, totalReporters, programYearCalendarDTO, isCurrentWeek, isAllProviderGroups);
                            long leaderTime=stopWatch.getTime();
                            log.info("Historical Leader Performance data at Leader Level {} updated count {} for Duration Week {} and Program year {} TimeTakenAtLeaderlevel {}", leader, updatedCount, programYearCalendarDTO.getDurationValue(), programYearCalendarDTO.getProgramYear(), leaderTime);
                        } else {
                            log.warn("leader {} has no reporters {}", leader, totalReporters);
                        }
                        jobStatus.setUpdatedRows(jobStatus.getUpdatedRows() + updatedCount);
                    });
        }
        catch (Exception e)
        {
            log.error("Exception occured while loadinghistorical for leaders rollup ", e.getMessage());
            throw e;
        }
    }
}
