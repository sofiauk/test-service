package com.optum.rqns.ftm.repository;

import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;

import java.util.List;

public interface PAFxMemberDeploymentUpdatesRepository {

    Integer mergePAFXMemberData(int batchsize, Integer offset, JobEvent jobEvent);

    Long getRecordCount(Integer programYear);

    Long getRecordCountModified(Integer programYear, String joblastrunsuccessfuldate);

    List<Integer> getListOfModifiedIdFromPafx(int batchSize, int offset, Integer programyear, String joblastrunsuccessfuldate);

    Integer mergeModifiedData(String batchdata);
}
