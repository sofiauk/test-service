package com.optum.rqns.ftm.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum PAJobNames {

	RUN_QUALITY_AGGREGATION("RunQualityAggregation", "ProgPerf.MemberQuality", "ProgPerf.QualityAggregation","dcgap.mbr_quality"),
	RUN_MEMBER_SUMMARY_AGGREGATION("RunMemberSummaryAggregation", "ProgPerf.MemberSummary",
			"ProgPerf.MemberSummaryAggregation","dcgap.mbr_summary"),
	RUN_MED_ADHERENCE_AGGREGATION("RunMedAdherenceAggregation", "ProgPerf.MemberMedAdherence",
			"ProgPerf.MedAdherenceAggregation","dcgap.mbr_med_adherence"),
	RUN_SUSPECT_AGGREGATION("RunSuspectAggregation", "ProgPerf.MemberSuspect", "ProgPerf.SuspectAggregation","dcgap.mbr_suspect"),
	RUN_MEMBER_HOSPITAL_EVENTS_AGGREGATION("RunHospitalEventsAggregation", "ProgPerf.MemberHospitalEvents",
			"ProgPerf.HospitalEventsAggregation","dcgap.mbr_hospital_events");

	private String jobName;
	private String sourceTable;
	private String aggregateTable;
	private String dcgapSourceTable;

	public static PAJobNames fromString(String text) {
		for (PAJobNames jobName : PAJobNames.values()) {
			if (jobName.jobName.equalsIgnoreCase(text)) {
				return jobName;
			}
		}
		return null;
	}
}
