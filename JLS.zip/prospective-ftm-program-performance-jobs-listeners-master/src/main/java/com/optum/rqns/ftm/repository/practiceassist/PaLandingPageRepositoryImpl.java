package com.optum.rqns.ftm.repository.practiceassist;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.StopWatch;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.optum.rqns.ftm.enums.GroupsToExecute;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.PAJobNames;
import com.optum.rqns.ftm.model.practiceassist.PaAggregationData;

import lombok.extern.slf4j.Slf4j;

@Repository("PaLandingPageRepositorySQL")
@Slf4j

public class PaLandingPageRepositoryImpl implements PaLandingPageRepository { 
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

   
    @Value("${PPSTCDFeature:false}")
	Boolean  isPPSTCDFeatureEnable;
    
    @Value("${InActiveFeature:false}")
    Boolean  isInActiveFeatureEnable;
 
   	    public final String COUNT_QUERY_MODIFIED  = "SELECT COUNT(*) as totalCount " + 
    	    		" FROM ( " + 
    	    		"	SELECT	ASSOC_PROV_GRP_ID,ASSOC_HLTH_SYS_ID, CLIENT_ID,ASSOC_PROV_ADR_ST_CD ,%s,SUB_CLI_SK,%s,%s ASSOC_PROV_GRP_NM " +
    	    		"	FROM " + 
    	    		"		%s with (NOLOCK)" + 
    	    		"	where " + 
    	    		"		%s " + 
    	    		" GROUP BY "+
    	   			" ASSOC_PROV_GRP_ID ,"+
    	   			" SUB_CLI_SK,"+
    	   			" ASSOC_HLTH_SYS_ID ,"+
    	   			" %s, "+
    	   			" CLIENT_ID,"+
    	   			" ASSOC_PROV_ADR_ST_CD, "+
				    " %s, "+
				    " %s "+
    	   			"ASSOC_PROV_GRP_NM) as src";
   	    
   	 public final String COUNT_QUERY_MODIFIED_WO_PPSTCD  = "SELECT COUNT(*) as totalCount " + 
	    		" FROM ( " + 
	    		"	SELECT	ASSOC_PROV_GRP_ID,ASSOC_HLTH_SYS_ID, CLIENT_ID,ASSOC_PROV_ADR_ST_CD ,%s,SUB_CLI_SK,%s,ASSOC_PROV_GRP_NM " +
	    		"	FROM " + 
	    		"		%s with (NOLOCK)" + 
	    		"	where " + 
	    		"		%s " + 
	    		" GROUP BY "+
	   			" ASSOC_PROV_GRP_ID ,"+
	   			" SUB_CLI_SK,"+
	   			" ASSOC_HLTH_SYS_ID ,"+
	   			" %s, "+
	   			" CLIENT_ID,"+
	   			" ASSOC_PROV_ADR_ST_CD, "+
			    " %s, "+
			   	" ASSOC_PROV_GRP_NM) as src";
    		
   	 public static final String QUALITY_AGGREGATION_AGGR_QUERY_BATCH_WISE =
   			 " SELECT " + 
   			 "	mq.ASSOC_PROV_GRP_ID AS providerGroupId ," + 
   			 "	mq.ASSOC_PROV_ADR_ST_CD AS providerState ," + 
   			 "	mq.gap_yr AS programYear ," + 
   			 "	mq.CLIENT_ID AS clientId ," + 
   			 "	mq.SUB_CLI_SK AS subClientSk ," + 
   			 "	mq.PCP_ID AS providerId," + 
   			 "  mq.ASSOC_HLTH_SYS_ID AS healthSystemId, "+
			 "  mq.ASSOC_PROV_GRP_NM AS providerGroupName, "+
			 " %s "+
   			 "	count(CASE WHEN(QUAL_RETURN_ACTION_NEEDED_COUNT > 0 OR CM_QUAL_ACTION_NEEDED_REJECTED_CNT > 0 ) THEN 1 END ) AS returnActionNeededCount, " + 
   			 "  sum(case when ( SUB_CLI_SK IN (6,84,101) and MSR_16_OMW_GAP_STS is not null and MSR_16_OMW_GAP_STS not in (3) and DATEDIFF(DAY ,SYSDATETIME(), DATEADD(DAY, 180 , MSR_16_OMW_DT)) BETWEEN 0  AND 30) then 1 else 0 END) as OMWCount, " +
   			 " count(CASE WHEN(QUAL_OPEN_COUNT > 0 OR (CM_QUAL_OPEN_NOT_ASSESSED > 0  OR CM_QUAL_OPEN>0) ) THEN 1 END ) AS memberOpportunityCount, " +
   			 " count(CASE WHEN((MSR_HBD2_GAP_STS in ('1','6','7','8','9','10','13') OR MSR_HBDM2_GAP_STS IN ('1','6','7','8','9','10','13') OR MSR_HBDK2_GAP_STS IN ('1','6','7','8','9','10','13')) AND SUB_CLI_SK NOT IN (6,84,101)) THEN 1 END ) AS a1CCount, "+
   			 " SUM(case when (DATEDIFF(DAY , CONVERT(datetime, SWITCHOFFSET(CONVERT(DATETIMEOFFSET, INSRT_DTTM), DATENAME(TZOFFSET, SYSDATETIMEOFFSET()))) , SYSDATETIME()) <= 7) then 1 else 0 END) as NewPatient7Count , "+
			 " SUM(case when (DATEDIFF(DAY , CONVERT(datetime, SWITCHOFFSET(CONVERT(DATETIMEOFFSET, INSRT_DTTM), DATENAME(TZOFFSET, SYSDATETIMEOFFSET()))) , SYSDATETIME()) > 7 and DATEDIFF(DAY , CONVERT(datetime, SWITCHOFFSET(CONVERT(DATETIMEOFFSET, INSRT_DTTM), DATENAME(TZOFFSET, SYSDATETIMEOFFSET()))) , SYSDATETIME())<=30) then 1 else 0 END) as NewPatient30Count, "+
			 " SUM(case when (DATEDIFF(DAY , CONVERT(datetime, SWITCHOFFSET(CONVERT(DATETIMEOFFSET, INSRT_DTTM), DATENAME(TZOFFSET, SYSDATETIMEOFFSET()))) , SYSDATETIME()) > 30 and DATEDIFF(DAY , CONVERT(datetime, SWITCHOFFSET(CONVERT(DATETIMEOFFSET, INSRT_DTTM), DATENAME(TZOFFSET, SYSDATETIMEOFFSET()))) , SYSDATETIME())<=90) then 1 else 0 END) as NewPatient90Count, "+
			 " SUM(case when (HIGH_PRTY_MBR_FLG = 'Y' OR CPG = 1 ) then 1 else 0 END) as HighPriorityCount , "+
			 " count(case when ((MBR_ANNL_CARE_VST_DT is null or MBR_ANNL_CARE_VST_DT = '') or (year(MBR_ANNL_CARE_VST_DT) != GAP_YR )) THEN 1 END) AS annualCareVisitNotCompleteCount, "+
			 " sum(case when ((CURR_YR_FLU_SHT_DT is null or CURR_YR_FLU_SHT_DT ='') and  SUB_CLI_SK IN (6,84,101)) then 1 else 0 END ) as noCurrFluVaccCount  "+
   			 "  FROM ProgPerf.MemberQuality mq with(nolock)  " + 
   			 
   			 "  WHERE  mq.gap_yr =:ProgramYear and mq.is_active = 'Y'  " +
   			 "	%s " + 
   	
   			" GROUP BY "+
   			" mq.ASSOC_PROV_GRP_ID ,"+
   			" mq.SUB_CLI_SK,"+
   			" mq.ASSOC_HLTH_SYS_ID ,"+
   			" mq.GAP_YR ,"+
   			" mq.CLIENT_ID,"+
   			" mq.ASSOC_PROV_ADR_ST_CD, "+
			" mq.ASSOC_PROV_GRP_NM, "+
			" %s "+
   			" mq.PCP_ID "+
   			"  order by mq.ASSOC_PROV_GRP_ID " + 
   			 "  OFFSET :offset ROWS FETCH NEXT :batchsize ROWS ONLY";
   	 
   	 
   	public static final String UPSERT_QUALITY_AGGREGATION = " MERGE    " +
            " INTO    " +
            "  ProgPerf.QualityAggregation AS TARGET    " +
            "    USING(    " +
            " VALUES(:providerGroupId,:subClientSk,:healthSystemId,:providerState,:providerId,:clientId,:programYear, :providerGroupName,:preferredProviderState)) AS SOURCE    " +
            " (ProviderGroupID,SubClientSk,HealthSystemID,ProviderState,ProviderID, ClientID, ProgramYear, ProviderGroupName, PreferredProviderState) ON    " +
            "  (TARGET.ProviderGroupID = SOURCE.providerGroupId    " +
            "  and ISNULL(TARGET.ProviderState,'') = ISNULL(SOURCE.providerState,'')    " +
            "  and TARGET.ProgramYear = SOURCE.programYear    " +
            "  and TARGET.ClientID = SOURCE.clientId    " +
            "  and TARGET.SubClientSk = SOURCE.subClientSk    " +
            "  and ISNULL(TARGET.HealthSystemId,'') = ISNULL(SOURCE.healthSystemId,'')   " +
			"  AND TARGET.ProviderId = SOURCE.providerId    " +
			"  and TARGET.ProviderGroupName = SOURCE.providerGroupName  " +
			"  %s )    " +
            "  WHEN MATCHED THEN    " +
            " UPDATE    " +
            " SET IsActive=1, IsDirty=0,  " +
            "  ReturnActionNeededCount =:returnActionNeededCount,  " +
            "  OMWCount =:omwCount,  " + 
            "  MemberOpportunityCount=:memberOpportunityCount,  "+
			"  A1CCount=:a1CCount,  "+
			"  NewPatient7Count =:newPatient7Count,  " +
			"  NewPatient30Count =:newPatient30Count,  " +
			"  NewPatient90Count =:newPatient90Count,  " +
			"  HighPriorityCount =:highPriorityCount,  " +
			"  AnnualCareVisitNotCompleteCount =:annualCareVisitNotCompleteCount,  " +
			"  NoCurrFluVaccCount =:noCurrFluVaccCount,  " +
			"  UpdatedBy = :updatedby,  " +
            "  UpdatedDate = GETUTCDATE()  " +
            "  WHEN NOT MATCHED BY TARGET THEN  " +
            "  INSERT  " +
            "  (ProviderGroupID,SubClientSk,HealthSystemID,ProviderState,ProviderID, ClientID, ProgramYear, ProviderGroupName, PreferredProviderState,  " +
            "  ReturnActionNeededCount, " +
            "  OMWCount,  MemberOpportunityCount, A1CCount, NewPatient7Count,NewPatient30Count,NewPatient90Count, " +
            "  HighPriorityCount,AnnualCareVisitNotCompleteCount,NoCurrFluVaccCount, "+
            "  CreatedBy, CreatedDate, UpdatedBy, UpdatedDate)  " +
            "  VALUES(:providerGroupId,:subClientSk,:healthSystemId,:providerState,:providerId,:clientId,:programYear, :providerGroupName, :preferredProviderState, "+
            "  :returnActionNeededCount,:omwCount,:memberOpportunityCount,:a1CCount,:newPatient7Count,:newPatient30Count,:newPatient90Count,:highPriorityCount,:annualCareVisitNotCompleteCount,:noCurrFluVaccCount,:createdBy, GETUTCDATE(),:updatedby, GETUTCDATE()); ";
   	
   	
	public static final String SUSPECT_AGGREGATION_AGGR_QUERY_BATCH_WISE = "select 	ASSOC_PROV_GRP_ID AS providerGroupId , "
			+ "SUB_CLI_SK AS subClientSk, 	"
			+ "ASSOC_HLTH_SYS_ID AS healthSystemId, 	"
			+ "GAP_YR AS ProgramYear, "
			+ "	CLIENT_ID AS ClientId, 	"
			+ "ASSOC_PROV_ADR_ST_CD AS providerState, 	"
			+ "PCP_ID AS providerId, 	"
			+ "ASSOC_PROV_GRP_NM AS providerGroupName, 	"
			+ "PREF_PROV_ST_CD AS preferredProviderState, 	"
			+ "count(cnt) notAssessedCount from 	" + 
			"(SELECT 		mq.ASSOC_PROV_GRP_ID , 		"
			+ "mq.SUB_CLI_SK, "
			+ "mq.ASSOC_HLTH_SYS_ID , "
			+ "mq.GAP_YR , 		"
			+ "mq.CLIENT_ID, "
			+ "mq.ASSOC_PROV_ADR_ST_CD, 		"
			+ "mq.PCP_ID, 		"
			+ "mq.ASSOC_PROV_GRP_NM, 		"
			+ "mq.PREF_PROV_ST_CD, 		"
			+ "mq.GLB_MBR_ID, "
			+ "sum(CASE WHEN(SUS_NOT_ASSESSED_COUNT > 0 OR (CM_SUS_OPEN_NOT_ASSESSED > 0 "
			+ "or CM_SUS_OPEN>0 ) ) THEN 1 END ) AS cnt 	"
			+ "from 		"
			+ "ProgPerf.MemberSuspect mq with(nolock) " 
			+" where  mq.gap_yr =:ProgramYear and mq.is_active = 'Y' " 
			+"  and ((mq.cli_sk = 4 and mq.assessment_status = 'Not Assessed') "  
			+"  or (sub_cli_sk not in (6, 84, 101) and mq.assessment_status in ('Open','Open (Not Assessed)'))) "
			+"	%s "
			+ "GROUP BY 		mq.ASSOC_PROV_GRP_ID , 		"
			+ "mq.SUB_CLI_SK, 		"
			+ "mq.ASSOC_HLTH_SYS_ID , 		"
			+ "mq.GAP_YR , 		"
			+ "mq.CLIENT_ID, 		"
			+ "mq.ASSOC_PROV_ADR_ST_CD, 		"
			+ "mq.ASSOC_PROV_GRP_NM, 		"
			+ "mq.PREF_PROV_ST_CD, 		"
			+ "mq.PCP_ID, 		"
			+ "mq.GLB_MBR_ID 	) "
			+ "T "
			+ "group by ASSOC_PROV_GRP_ID , 	" +
			"SUB_CLI_SK, 	" +
			"ASSOC_HLTH_SYS_ID , 	" + 
			"GAP_YR , 	" +
			"CLIENT_ID, 	" +
			"ASSOC_PROV_ADR_ST_CD, 	" +
			"ASSOC_PROV_GRP_NM, 	" +
			"PREF_PROV_ST_CD, 	" +
			"PCP_ID 	 	" +
			"order by 		ASSOC_PROV_GRP_ID   "
			+ "  OFFSET :offset ROWS FETCH NEXT :batchsize ROWS ONLY";
	
	
	public static final String SUSPECT_AGGREGATION_AGGR_QUERY_BATCH_WISE_WO_PPSTCD = "select 	ASSOC_PROV_GRP_ID AS providerGroupId , "
			+ "SUB_CLI_SK AS subClientSk, 	"
			+ "ASSOC_HLTH_SYS_ID AS healthSystemId, 	"
			+ "GAP_YR AS ProgramYear, "
			+ "	CLIENT_ID AS ClientId, 	"
			+ "ASSOC_PROV_ADR_ST_CD AS providerState, 	"
			+ "PCP_ID AS providerId, 	"
			+ "ASSOC_PROV_GRP_NM AS providerGroupName, 	"
			+ "count(cnt) notAssessedCount from 	" + 
			"(SELECT 		mq.ASSOC_PROV_GRP_ID , 		"
			+ "mq.SUB_CLI_SK, "
			+ "mq.ASSOC_HLTH_SYS_ID , "
			+ "mq.GAP_YR , 		"
			+ "mq.CLIENT_ID, "
			+ "mq.ASSOC_PROV_ADR_ST_CD, 		"
			+ "mq.PCP_ID, 		"
			+ "mq.ASSOC_PROV_GRP_NM, 		"
			+ "mq.GLB_MBR_ID, "
			+ "sum(CASE WHEN(SUS_NOT_ASSESSED_COUNT > 0 OR (CM_SUS_OPEN_NOT_ASSESSED > 0 "
			+ "or CM_SUS_OPEN>0 ) ) THEN 1 END ) AS cnt 	"
			+ "from 		"
			+ "ProgPerf.MemberSuspect mq with(nolock) " + 
			" where  mq.gap_yr =:ProgramYear and mq.is_active = 'Y' " 
			+"  and ((mq.cli_sk = 4 and mq.assessment_status = 'Not Assessed') "  
			+"  or (sub_cli_sk not in (6, 84, 101) and mq.assessment_status in ('Open','Open (Not Assessed)'))) "
			+ "	%s "
			+ "GROUP BY 		mq.ASSOC_PROV_GRP_ID , 		"
			+ "mq.SUB_CLI_SK, 		"
			+ "mq.ASSOC_HLTH_SYS_ID , 		"
			+ "mq.GAP_YR , 		"
			+ "mq.CLIENT_ID, 		"
			+ "mq.ASSOC_PROV_ADR_ST_CD, 		"
			+ "mq.ASSOC_PROV_GRP_NM, 		"
			+ "mq.PCP_ID, 		"
			+ "mq.GLB_MBR_ID 	) "
			+ "T "
			+ "group by ASSOC_PROV_GRP_ID , 	" +
			"SUB_CLI_SK, 	" +
			"ASSOC_HLTH_SYS_ID , 	" + 
			"GAP_YR , 	" +
			"CLIENT_ID, 	" +
			"ASSOC_PROV_ADR_ST_CD, 	" +
			"ASSOC_PROV_GRP_NM, 	" +
			"PCP_ID 	 	" +
			"order by 		ASSOC_PROV_GRP_ID   "
			+ "  OFFSET :offset ROWS FETCH NEXT :batchsize ROWS ONLY";
	
	
	public static final String UPDATE_SUSPECT_AGGREGATION = " MERGE    " +
            " INTO    " +
            "  ProgPerf.SuspectAggregation  AS TARGET    " +
            "    USING(    " +
            " VALUES(:providerGroupId,:subClientSk,:healthSystemId,:providerState,:providerId,:clientId,:programYear, :providerGroupName, :preferredProviderState)) AS SOURCE    " +
            " (ProviderGroupID,SubClientSk,HealthSystemID,ProviderState,ProviderID, ClientID, ProgramYear,ProviderGroupName, PreferredProviderState) ON    " +
            "  (TARGET.ProviderGroupID = SOURCE.providerGroupId    " +
            "  and ISNULL(TARGET.ProviderState,'') = ISNULL(SOURCE.providerState,'')    " +
            "  and TARGET.ProgramYear = SOURCE.programYear    " +
            "  and TARGET.ClientID = SOURCE.clientId    " +
            "  and TARGET.SubClientSk = SOURCE.subClientSk    " +
            "  and ISNULL(TARGET.HealthSystemId,'') = ISNULL(SOURCE.healthSystemId,'')   " +
			"  and TARGET.ProviderId = SOURCE.providerId  " +
			"  and TARGET.ProviderGroupName = SOURCE.providerGroupName  " +
            "  %s )    " +
            "  WHEN MATCHED THEN    " +
            " UPDATE    " +
            " SET IsActive=1, IsDirty=0,  " +
            "  NotAssessedCount =:notAssessedCount,  " +
            "  UpdatedBy = :updatedby,  " +
            "  UpdatedDate = GETUTCDATE()  " +
            "  WHEN NOT MATCHED BY TARGET THEN  " +
            "  INSERT  " +
            "  (ProviderGroupID,SubClientSk,HealthSystemID,ProviderState,ProviderID, ClientID, ProgramYear,ProviderGroupName, PreferredProviderState,  " +
            "  NotAssessedCount, " +
            "  CreatedBy, CreatedDate, UpdatedBy, UpdatedDate)  " +
            "  VALUES(:providerGroupId,:subClientSk,:healthSystemId,:providerState,:providerId,:clientId,:programYear,:providerGroupName, :preferredProviderState, "+
            "  :notAssessedCount,:createdBy, GETUTCDATE(),:updatedby, GETUTCDATE()); ";


	 public static final String HOSPITAL_EVENTS_AGGREGATION_AGGR_QUERY_BATCH_WISE =
   			 " SELECT " + 
   			 "	mq.ASSOC_PROV_GRP_ID AS providerGroupId ," + 
   			 "	mq.ASSOC_PROV_ADR_ST_CD AS providerState ," + 
   			 "	mq.gap_yr AS programYear ," + 
   			 "	mq.CLIENT_ID AS clientId ," + 
   			 "	mq.SUB_CLI_SK AS subClientSk ," + 
   			 "	mq.ASSOC_PROV_VDS_ID AS providerId," + 
   			 "  mq.ASSOC_HLTH_SYS_ID AS healthSystemId, "+
			 "  mq.ASSOC_PROV_GRP_NM AS providerGroupName, "+
   			 " sum(case when ( SUB_CLI_SK IN (6,84,101) and DATEDIFF(DAY , GETUTCDATE(),ADT_CLC_DISCH_DATE )>= 0 and DATEDIFF(DAY , GETUTCDATE(),ADT_CLC_DISCH_DATE )<= 3) then 1 else 0 END) as recentDischarge3Count, " + 
   			 " SUM(case when ( SUB_CLI_SK IN (6,84,101) and DATEDIFF(DAY , GETUTCDATE(),ADT_CLC_DISCH_DATE ) > 3 and DATEDIFF(DAY , GETUTCDATE(),ADT_CLC_DISCH_DATE)<= 7) then 1 else 0 END) as recentDischarge7Count," +
   			 " SUM(case when ( SUB_CLI_SK IN (6,84,101) and DATEDIFF(DAY , GETUTCDATE(),ADT_CLC_DISCH_DATE ) > 7 and DATEDIFF(DAY , GETUTCDATE(),ADT_CLC_DISCH_DATE)<= 30) then 1 else 0 END) as recentDischarge30Count " +
   			 "  FROM ProgPerf.MemberHospitalEvents mq with(nolock)  " + 
   			 "  WHERE mq.is_active = 'Y' and mq.gap_yr =:ProgramYear " +
   			 "	%s " + 
   			" GROUP BY "+
   			" mq.ASSOC_PROV_GRP_ID ,"+
   			" mq.SUB_CLI_SK,"+
   			" mq.ASSOC_HLTH_SYS_ID ,"+
   			" mq.GAP_YR ,"+
   			" mq.CLIENT_ID,"+
   			" mq.ASSOC_PROV_ADR_ST_CD, "+
			" mq.ASSOC_PROV_GRP_NM, "+
   			" mq.ASSOC_PROV_VDS_ID "+
   			"  order by mq.ASSOC_PROV_GRP_ID " + 
   			 "  OFFSET :offset ROWS FETCH NEXT :batchsize ROWS ONLY";
   	 
   	 
   	public static final String UPSERT_HOSPITAL_EVENTS_AGGREGATION = " MERGE    " +
            " INTO    " +
            "  ProgPerf.HospitalEventsAggregation AS TARGET    " +
            "    USING(    " +
            " VALUES(:providerGroupId,:subClientSk,:healthSystemId,:providerState,:providerId,:clientId,:programYear,:providerGroupName)) AS SOURCE    " +
            " (ProviderGroupID,SubClientSk,HealthSystemID,ProviderState,ProviderID, ClientID, ProgramYear,ProviderGroupName) ON    " +
            "  (TARGET.ProviderGroupID = SOURCE.providerGroupId    " +
            "  and ISNULL(TARGET.ProviderState,'') = ISNULL(SOURCE.providerState,'')    " +
            "  and TARGET.ProgramYear = SOURCE.programYear    " +
            "  and TARGET.ClientID = SOURCE.clientId    " +
            "  and TARGET.SubClientSk = SOURCE.subClientSk    " +
            "  and ISNULL(TARGET.HealthSystemId,'') = ISNULL(SOURCE.healthSystemId,'')   " +
			"  and TARGET.ProviderGroupName = SOURCE.providerGroupName  " +
            "  AND TARGET.ProviderId = SOURCE.providerId )    " +
            "  WHEN MATCHED THEN    " +
            " UPDATE    " +
            " SET IsActive=1, IsDirty=0,  " +
            "  RecentDischarge3Count =:recentDischarge3Count,  " +
            "  RecentDischarge7Count =:recentDischarge7Count,  " + 
            "  RecentDischarge30Count=:recentDischarge30Count, "+
			"  UpdatedBy = :updatedby,  " +
            "  UpdatedDate = GETUTCDATE()  " +
            "  WHEN NOT MATCHED BY TARGET THEN  " +
            "  INSERT  " +
            "  (ProviderGroupID,SubClientSk,HealthSystemID,ProviderState,ProviderID, ClientID, ProgramYear, ProviderGroupName, " +
            "  RecentDischarge3Count, " +
            " RecentDischarge7Count,  RecentDischarge30Count, " +
            "  CreatedBy, CreatedDate, UpdatedBy, UpdatedDate)  " +
            "  VALUES(:providerGroupId,:subClientSk,:healthSystemId,:providerState,:providerId,:clientId,:programYear,:providerGroupName, "+
            "  :recentDischarge3Count,:recentDischarge7Count,:recentDischarge30Count,:createdBy, GETUTCDATE(),:updatedby, GETUTCDATE()); ";

    public PaLandingPageRepositoryImpl(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
        this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
    }
   	
    
	
	@Override
    public List<PaAggregationData> getPaAggregateDataByBatch(Integer programYear, String joblastrunsuccessfuldate,String jobStartTime,int offset, int batchsize) {
        HashMap<String,Object> params =  new HashMap<>();
        
        StringBuilder  whereCondition = new StringBuilder(100);
        params.put("ProgramYear",String.valueOf(programYear));
         params.put("offset",offset);
        params.put("batchsize", batchsize);
        if (null != joblastrunsuccessfuldate && null!=jobStartTime) {
			whereCondition.append(" AND ASSOC_PROV_GRP_ID  in( select distinct  q.ASSOC_PROV_GRP_ID from "
					+" ProgPerf.MemberQuality q with(nolock)  where  q.gap_yr='"+programYear+"' and q.IS_ACTIVE='Y' ");
				whereCondition.append(" AND  q.UpdatedDate > '" + joblastrunsuccessfuldate + "'");
				whereCondition.append(" AND q.UpdatedDate <='"+jobStartTime+"')");
		}
       
        String PREF_PROV_ST_CD_GRP_BY_PARAM="";
        String PREF_PROV_ST_CD_SELECT_PARAM="";
                
        if(isPPSTCDFeatureEnable) {
        	PREF_PROV_ST_CD_GRP_BY_PARAM=" mq.PREF_PROV_ST_CD, ";
        	PREF_PROV_ST_CD_SELECT_PARAM=" mq.PREF_PROV_ST_CD AS preferredProviderState, ";
        }
		String finalQuery= String.format(QUALITY_AGGREGATION_AGGR_QUERY_BATCH_WISE,PREF_PROV_ST_CD_SELECT_PARAM,whereCondition,PREF_PROV_ST_CD_GRP_BY_PARAM);
				
	    return namedParameterJdbcTemplate.query(finalQuery, params, new BeanPropertyRowMapper<>(PaAggregationData.class));
    }
    
    
    @Override
	public Integer upserQualityAggregation(List<PaAggregationData> paQualityAggregationList) {
		StopWatch stopWatch = StopWatch.createStarted();
		log.info("executing upserQualityAggregation::");
		List<MapSqlParameterSource> params = new ArrayList<>();

		for (PaAggregationData paQualityAggregationData : paQualityAggregationList) {
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue("providerGroupId", paQualityAggregationData.getProviderGroupId());
			source.addValue("providerState", StringUtils.truncate(paQualityAggregationData.getProviderState(),4));
			source.addValue("programYear", paQualityAggregationData.getProgramYear());
			source.addValue("clientId", paQualityAggregationData.getClientId());
			source.addValue("subClientSk", paQualityAggregationData.getSubClientSk());
			source.addValue("healthSystemId", paQualityAggregationData.getHealthSystemId());
			source.addValue("providerId", paQualityAggregationData.getProviderId());
			source.addValue("providerGroupName", paQualityAggregationData.getProviderGroupName());
			source.addValue("preferredProviderState", paQualityAggregationData.getPreferredProviderState());
			source.addValue("returnActionNeededCount", paQualityAggregationData.getReturnActionNeededCount());
			source.addValue("omwCount", paQualityAggregationData.getOmwCount());
			source.addValue("memberOpportunityCount", paQualityAggregationData.getMemberOpportunityCount());
			source.addValue("a1CCount", paQualityAggregationData.getA1CCount());
			source.addValue("newPatient30Count",paQualityAggregationData.getNewPatient30Count());
			source.addValue("newPatient7Count",paQualityAggregationData.getNewPatient7Count());
			source.addValue("newPatient90Count",paQualityAggregationData.getNewPatient90Count());
			source.addValue("highPriorityCount", paQualityAggregationData.getHighPriorityCount());
			source.addValue("annualCareVisitNotCompleteCount", paQualityAggregationData.getAnnualCareVisitNotCompleteCount());
			source.addValue("noCurrFluVaccCount", paQualityAggregationData.getNoCurrFluVaccCount());

			source.addValue("createdBy", JobName.RUN_QUALITY_AGGREGATION.getValue());
			source.addValue("updatedby", JobName.RUN_QUALITY_AGGREGATION.getValue());

			params.add(source);
		}

		String preferredProviderStateCond="";
		if(isPPSTCDFeatureEnable) {
			preferredProviderStateCond=" AND TARGET.PreferredProviderState = SOURCE.preferredProviderState ";
		}
		
		String finalQuery= String.format(UPSERT_QUALITY_AGGREGATION,preferredProviderStateCond);

		int[] batchCount = namedParameterJdbcTemplate.batchUpdate(finalQuery,
				params.toArray(new MapSqlParameterSource[params.size()]));

		log.info("execution completed for {} upserQualityAggregation: {}seconds", batchCount.length,
				stopWatch.getTime(TimeUnit.SECONDS));
	
		return batchCount.length;

	}
    
    @Override
	public List<PaAggregationData> getPaSuspectAggregateDataByBatch(Integer programYear, String joblastrunsuccessfuldate,String jobStartTime,int offset, int batchsize) {
		 HashMap<String,Object> params =  new HashMap<>();
	        StringBuilder  whereCondition = new StringBuilder(100);
	        params.put("ProgramYear",String.valueOf(programYear));
	         params.put("offset",offset);
	        params.put("batchsize", batchsize);
	        if (null != joblastrunsuccessfuldate && null!=jobStartTime) {
				whereCondition.append(" AND ASSOC_PROV_GRP_ID  in( select distinct  q.ASSOC_PROV_GRP_ID from "
						+" ProgPerf.MemberSuspect q with(nolock)  where  q.gap_yr='"+programYear+"'");
				whereCondition.append(" AND q.IS_ACTIVE='Y' AND q.UpdatedDate > '" + joblastrunsuccessfuldate + "'");
				whereCondition.append(" AND q.UpdatedDate <='"+jobStartTime+"')");
	        }
	        
	        String finalQuery=String.format(SUSPECT_AGGREGATION_AGGR_QUERY_BATCH_WISE_WO_PPSTCD,whereCondition);
			if(isPPSTCDFeatureEnable) {
				finalQuery= String.format(SUSPECT_AGGREGATION_AGGR_QUERY_BATCH_WISE,whereCondition);
			}
		
			return namedParameterJdbcTemplate.query(finalQuery, params, new BeanPropertyRowMapper<>(PaAggregationData.class));
	}
    
	@Override
	public Integer upserSuspectAggregation(List<PaAggregationData> paSuspectAggregationList) {
		StopWatch stopWatch = StopWatch.createStarted();
		log.info("executing upserSuspectAggregation::");
		List<MapSqlParameterSource> params = new ArrayList<>();
		for (PaAggregationData paSuspectAggregationData : paSuspectAggregationList) {
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue("providerGroupId", paSuspectAggregationData.getProviderGroupId());
			source.addValue("providerState", StringUtils.truncate(paSuspectAggregationData.getProviderState(),4));
			source.addValue("programYear", paSuspectAggregationData.getProgramYear());
			source.addValue("clientId", paSuspectAggregationData.getClientId());
			source.addValue("subClientSk", paSuspectAggregationData.getSubClientSk());
			source.addValue("healthSystemId", paSuspectAggregationData.getHealthSystemId());
			source.addValue("providerId", paSuspectAggregationData.getProviderId());
			source.addValue("providerGroupName", paSuspectAggregationData.getProviderGroupName());
			source.addValue("preferredProviderState", paSuspectAggregationData.getPreferredProviderState());
			source.addValue("notAssessedCount", paSuspectAggregationData.getNotAssessedCount());
			source.addValue("createdBy", "System");
			source.addValue("updatedby", "System");
			params.add(source);
		}
		String preferredProviderStateCond="";
		if(isPPSTCDFeatureEnable) {
			preferredProviderStateCond=" AND TARGET.PreferredProviderState = SOURCE.preferredProviderState ";
		}
		
		String finalQuery= String.format(UPDATE_SUSPECT_AGGREGATION,preferredProviderStateCond);
		
		int[] batchCount = namedParameterJdbcTemplate.batchUpdate(finalQuery,
				params.toArray(new MapSqlParameterSource[params.size()]));
		log.info("execution completed for {} upserSuspectggregation: {}seconds", batchCount.length,
				stopWatch.getTime(TimeUnit.SECONDS));
		return batchCount.length;
	}
	
	public static final String MEDADHERENCE_AGGREGATION_AGGR_QUERY_BATCH_WISE = "SELECT "
			+ "mq.ASSOC_PROV_GRP_ID AS providerGroupId ,"
			+ "mq.SUB_CLI_SK AS subClientSk , "
			+ "mq.ASSOC_HLTH_SYS_ID AS healthSystemId , "
			+ "mq.GAP_YR AS programYear, "
			+ "mq.CLIENT_ID AS clientId, "
			+ "mq.ASSOC_PROV_ADR_ST_CD AS providerState, "
			+ "mq.PCP_ID AS providerId, "
			+ "mq.ASSOC_PROV_GRP_NM AS providerGroupName, "
			+ " %s "
			+ " sum((case when DATEDIFF(DAY , MAD_ABS_FAIL,SYSDATETIME())>= 0 and (DATEDIFF(DAY , MAD_ABS_FAIL,SYSDATETIME() )<= 30 and SUB_CLI_SK IN (6,84,101)) then 1  "
			+ " when DATEDIFF(DAY , MAH_ABS_FAIL,SYSDATETIME())>= 0 and (DATEDIFF(DAY ,  MAH_ABS_FAIL,SYSDATETIME() )<= 30 and SUB_CLI_SK IN (6,84,101)) then 1  "
			+ " when DATEDIFF(DAY , MAC_ABS_FAIL,SYSDATETIME())>= 0 and (DATEDIFF(DAY , MAC_ABS_FAIL,SYSDATETIME() )<= 30 and SUB_CLI_SK IN (6,84,101)) then 1 "
			+ " when DATEDIFF(DAY , SUPD_ABS_FAIL,SYSDATETIME())>= 0 and (DATEDIFF(DAY , SUPD_ABS_FAIL,SYSDATETIME() )<= 30 and SUB_CLI_SK IN (6,84,101)) then 1 else 0 END) ) as absFailDateCount,"

			+ "count(CASE WHEN(DAYS_SUPPLY_LT_FLG = 'Y' and SUB_CLI_SK IN (6,84,101)) THEN 1 END ) AS rxFillOppurtunityCount "
			+ " from "
			+ " ProgPerf.MemberMedAdherence mq with(nolock) " +
			"  WHERE  mq.gap_yr =:ProgramYear and mq.is_active = 'Y' AND GAP_CNT>0 " +
					"	%s " +
			 "GROUP BY "
			+ "mq.ASSOC_PROV_GRP_ID , "
			+ "mq.SUB_CLI_SK, "
			+ "mq.ASSOC_HLTH_SYS_ID , "
			+ "mq.GAP_YR , "
			+ "mq.CLIENT_ID, "
			+ "mq.ASSOC_PROV_ADR_ST_CD,"
			+ "mq.PCP_ID,"
			+ " %s "
			+" mq.ASSOC_PROV_GRP_NM "
			+ "order by mq.ASSOC_PROV_GRP_ID "
			+ "  OFFSET :offset ROWS FETCH NEXT :batchsize ROWS ONLY";
	
	public static final String  UPDATE_MEDADHERENCE_AGGREGATION = " MERGE    " +
            " INTO    " +
            "  ProgPerf.MedAdherenceAggregation AS TARGET    " +
            "    USING(    " +
            " VALUES(:providerGroupId,:subClientSk,:healthSystemId,:providerState,:providerId,:clientId,:programYear,:providerGroupName,:preferredProviderState)) AS SOURCE    " +
            " (ProviderGroupID,SubClientSk,HealthSystemID,ProviderState,ProviderID, ClientID, ProgramYear,ProviderGroupName, PreferredProviderState) ON    " +
            "  (TARGET.ProviderGroupID = SOURCE.providerGroupId    " +
            "  and ISNULL(TARGET.ProviderState,'') = ISNULL(SOURCE.providerState,'')   " +
            "  and TARGET.ProgramYear = SOURCE.programYear    " +
            "  and TARGET.ClientID = SOURCE.clientId    " +
            "  and TARGET.SubClientSk = SOURCE.subClientSk    " +
            "  and ISNULL(TARGET.HealthSystemId,'') = ISNULL(SOURCE.healthSystemId,'')   " +
			"  and TARGET.ProviderGroupName = SOURCE.providerGroupName  " +
			"  %s " +
            "  AND TARGET.ProviderId = SOURCE.providerId )    " +
            "  WHEN MATCHED THEN    " +
            " UPDATE    " +
            " SET IsActive=1, IsDirty=0,  " +
            "  AbsFailDateCount =:absFailDateCount,  " +
            "  RxFillOppurtunityCount =:rxFillOppurtunityCount,  " +
            "  UpdatedBy = :updatedby,  " +
            "  UpdatedDate = GETUTCDATE()  " +
            "  WHEN NOT MATCHED BY TARGET THEN  " +
            "  INSERT  " +
            "  (ProviderGroupID,SubClientSk,HealthSystemID,ProviderState,ProviderID, ClientID, ProgramYear, ProviderGroupName, PreferredProviderState,  " +
            "  AbsFailDateCount, " +
            "  RxFillOppurtunityCount, " +
            "  CreatedBy, CreatedDate, UpdatedBy, UpdatedDate)  " +
            "  VALUES(:providerGroupId,:subClientSk,:healthSystemId,:providerState,:providerId,:clientId,:programYear,:providerGroupName, :preferredProviderState, "+
            "  :absFailDateCount,:rxFillOppurtunityCount,:createdBy, GETUTCDATE(),:updatedby, GETUTCDATE()); ";


	@Override
	public List<PaAggregationData> getPaMedAdherenceAggregateDataByBatch(Integer programYear,
																		 String joblastrunsuccessfuldate, String jobStartTime, int offset, int batchsize) {
		HashMap<String, Object> params = new HashMap<>();
		StringBuilder whereCondition = new StringBuilder(100);
		params.put("ProgramYear", String.valueOf(programYear));
		params.put("offset", offset);
		params.put("batchsize", batchsize);
		if (null != joblastrunsuccessfuldate && null != jobStartTime) {
			whereCondition.append(" AND ASSOC_PROV_GRP_ID in( select distinct q.ASSOC_PROV_GRP_ID from "
					+ " ProgPerf.MemberMedAdherence q with(nolock) where q.gap_yr='"+programYear+"'");
			whereCondition.append(" AND q.IS_ACTIVE='Y' AND q.UpdatedDate > '" + joblastrunsuccessfuldate + "'");
			whereCondition.append(" AND q.UpdatedDate <='"+jobStartTime+"')");
		}
		
		    String PREF_PROV_ST_CD_GRP_BY_PARAM="";
	        String PREF_PROV_ST_CD_SELECT_PARAM="";
	                
	        if(isPPSTCDFeatureEnable) {
	        	PREF_PROV_ST_CD_GRP_BY_PARAM=" mq.PREF_PROV_ST_CD ";
	        	PREF_PROV_ST_CD_SELECT_PARAM=" mq.PREF_PROV_ST_CD AS preferredProviderState, ";
	        }
	       
	        
			String finalQuery= String.format(MEDADHERENCE_AGGREGATION_AGGR_QUERY_BATCH_WISE,PREF_PROV_ST_CD_SELECT_PARAM,whereCondition,PREF_PROV_ST_CD_GRP_BY_PARAM);
								
		return namedParameterJdbcTemplate.query(finalQuery, params,
				new BeanPropertyRowMapper<>(PaAggregationData.class));
	}


	@Override
	public Integer upserMedAdherenceAggregation(List<PaAggregationData> paMedAdherenceAggregationList) {
		StopWatch stopWatch = StopWatch.createStarted();
		log.info("executing upserMedAdherenceAggregation::");
		List<MapSqlParameterSource> params = new ArrayList<>();
		for (PaAggregationData paMedAdherenceAggregationData : paMedAdherenceAggregationList) {
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue("providerGroupId", paMedAdherenceAggregationData.getProviderGroupId());
			source.addValue("providerState", StringUtils.truncate(paMedAdherenceAggregationData.getProviderState(),4));
			source.addValue("programYear", paMedAdherenceAggregationData.getProgramYear());
			source.addValue("clientId", paMedAdherenceAggregationData.getClientId());
			source.addValue("subClientSk", paMedAdherenceAggregationData.getSubClientSk());
			source.addValue("healthSystemId", paMedAdherenceAggregationData.getHealthSystemId());
			source.addValue("providerId", paMedAdherenceAggregationData.getProviderId());
			source.addValue("providerGroupName", paMedAdherenceAggregationData.getProviderGroupName());
			source.addValue("preferredProviderState", paMedAdherenceAggregationData.getPreferredProviderState());
			source.addValue("rxFillOppurtunityCount", paMedAdherenceAggregationData.getRxFillOppurtunityCount());
			source.addValue("absFailDateCount",paMedAdherenceAggregationData.getAbsFailDateCount());
			source.addValue("createdBy", "System");
			source.addValue("updatedby", "System");
			params.add(source);
		}
		
		String preferredProviderStateCond="";
		if(isPPSTCDFeatureEnable) {
			preferredProviderStateCond=" AND TARGET.PreferredProviderState = SOURCE.preferredProviderState  ";
		}
		
		String finalQuery= String.format(UPDATE_MEDADHERENCE_AGGREGATION,preferredProviderStateCond);
			
		int[] batchCount = namedParameterJdbcTemplate.batchUpdate(finalQuery,
				params.toArray(new MapSqlParameterSource[params.size()]));
		log.info("execution completed for {} upserMedAdherenceAggregation: {}seconds", batchCount.length,
				stopWatch.getTime(TimeUnit.SECONDS));
		return batchCount.length;
	}

	@Override
	@Deprecated
	public List<PaAggregationData> getPaAggregateDataByBatch(Integer programYear, String joblastrunsuccessfuldate,
			int offset, int batchsize) {
		return getPaAggregateDataByBatch(programYear, joblastrunsuccessfuldate,null, offset, batchsize);
	}


	

	public static final String MEMBERSUMMARY_AGGREGATION_AGGR_QUERY_BATCH_WISE = "SELECT "
			+ "mq.ASSOC_PROV_GRP_ID AS providerGroupId , "
			+ "mq.MBR_PGM_YEAR AS programYear , "
			+ "mq.CLIENT_ID AS clientId , "
			+ "mq.SUB_CLI_SK AS subClientSk , "
			+ "mq.ASSOC_PROV_ADR_ST_CD AS providerState, "
			+ "mq.ASSOC_HLTH_SYS_ID AS healthSystemId , "
			+ "mq.PCP_ID AS providerId , "
			+ "mq.ASSOC_PROV_GRP_NM AS providerGroupName, "
			+ " %s "
			+ "SUM(case when (DATEDIFF(DAY , INSRT_DTTM , GETUTCDATE()) <= 7) then 1 else 0 END) as NewPatient7Count , "
			+ "SUM(case when (DATEDIFF(DAY , INSRT_DTTM , GETUTCDATE()) > 7 and DATEDIFF(DAY , INSRT_DTTM , GETUTCDATE())<=30) then 1 else 0 END) as NewPatient30Count , "
			+ "SUM(case when (DATEDIFF(DAY , INSRT_DTTM , GETUTCDATE()) > 30 and DATEDIFF(DAY , INSRT_DTTM , GETUTCDATE())<=90) then 1 else 0 END) as NewPatient90Count, "
			+ "SUM(case when (HIGH_PRTY_MBR_FLG = 'Y' OR CPG = 1 ) then 1 else 0 END) as HighPriorityCount , "
			+ "count(case when ((MBR_ANNL_CARE_VST_DT is null or MBR_ANNL_CARE_VST_DT = '') or (year(MBR_ANNL_CARE_VST_DT) != year(GETUTCDATE()))) THEN 1 END) AS annualCareVisitNotCompleteCount, "
			+ "sum(case when (CURR_YR_FLU_SHT_DT is null) then 1 else 0 END) as noCurrFluVaccCount  "
					+ " from "
			+ "ProgPerf.MemberSummary mq with(nolock) "+
			"  WHERE  mq.MBR_PGM_YEAR =:ProgramYear and mq.is_active = 'Y'  %s " +
			"	%s " +
			 "GROUP BY "
			+ "mq.ASSOC_PROV_GRP_ID, "
			+ "mq.MBR_PGM_YEAR , "
			+ "mq.CLIENT_ID , "
			+ "mq.SUB_CLI_SK, "
			+ "mq.ASSOC_PROV_ADR_ST_CD,"
			+ "mq.ASSOC_HLTH_SYS_ID,"
			+" mq.ASSOC_PROV_GRP_NM, "
			+" %s "
			+ "mq.PCP_ID "
			+ "order by mq.ASSOC_PROV_GRP_ID "
			+ "  OFFSET :offset ROWS FETCH NEXT :batchsize ROWS ONLY";

	public static final String UPDATE_MEMBERSUMMARY_AGGREGATION = " MERGE    " +
			" INTO    " +
			" ProgPerf.MemberSummaryAggregation AS TARGET    " +
			"    USING(    " +
			" VALUES(:providerGroupId,:subClientSk,:healthSystemId,:providerState,:providerId,:clientId,:programYear,:providerGroupName,:preferredProviderState)) AS SOURCE    " +
			" (ProviderGroupID,SubClientSk,HealthSystemID,ProviderState,ProviderID, ClientID, ProgramYear,ProviderGroupName, PreferredProviderState) ON    " +
			"  (TARGET.ProviderGroupID = SOURCE.providerGroupId    " +
			"  and ISNULL(TARGET.ProviderState,'') = ISNULL(SOURCE.providerState,'')   " +
			"  and TARGET.ProgramYear = SOURCE.programYear    " +
			"  and TARGET.ClientID = SOURCE.clientId    " +
			"  and TARGET.SubClientSk = SOURCE.subClientSk    " +
			"  and ISNULL(TARGET.HealthSystemId,'') = ISNULL(SOURCE.healthSystemId,'')   " +
			"  and TARGET.ProviderGroupName = SOURCE.providerGroupName  " +
			"  %s  " +
			"  AND TARGET.ProviderId = SOURCE.providerId )    " +
			"  WHEN MATCHED THEN    " +
			" UPDATE    " +
			 " SET IsActive=1, IsDirty=0,  " +
			"  AnnualCareVisitNotCompleteCount =:annualCareVisitNotCompleteCount,  " +
			"  NewPatient7Count =:newPatient7Count,  " +
			"  NewPatient30Count =:newPatient30Count,  " +
			"  NewPatient90Count =:newPatient90Count,  " +
			"  HighPriorityCount =:highPriorityCount,  " +
			"  NoCurrFluVaccCount =:noCurrFluVaccCount,  " +
			"  UpdatedBy = :updatedby,  " +
			"  UpdatedDate = GETUTCDATE()  " +
			"  WHEN NOT MATCHED BY TARGET THEN  " +
			"  INSERT  " +
			"  (ProviderGroupID,SubClientSk,HealthSystemID,ProviderState,ProviderID, ClientID, ProgramYear, ProviderGroupName, PreferredProviderState,   " +
			"  AnnualCareVisitNotCompleteCount,NewPatient7Count,NewPatient30Count,NewPatient90Count,HighPriorityCount,NoCurrFluVaccCount, " +
			"  CreatedBy, CreatedDate, UpdatedBy, UpdatedDate)  " +
			"  VALUES(:providerGroupId,:subClientSk,:healthSystemId,:providerState,:providerId,:clientId,:programYear,:providerGroupName, :preferredProviderState, "+
			"  :annualCareVisitNotCompleteCount,:newPatient7Count,:newPatient30Count,:newPatient90Count,:highPriorityCount,:noCurrFluVaccCount,:createdBy, GETUTCDATE(),:updatedby, GETUTCDATE()); ";


	@Override
	public List<PaAggregationData> getPaMemberSummaryAggregateDataByBatch(Integer programYear, String joblastrunsuccessfuldate, String jobStartTime,int offset, int batchsize) {
		HashMap<String, Object> params = new HashMap<>();
		StringBuilder whereCondition = new StringBuilder(100);
		params.put("ProgramYear", programYear);
		params.put("offset", offset);
		params.put("batchsize", batchsize);
		if (null != joblastrunsuccessfuldate && null != jobStartTime) {
			whereCondition.append(" AND ASSOC_PROV_GRP_ID in( select distinct q.ASSOC_PROV_GRP_ID from "
					+ " ProgPerf.MemberSummary q with(nolock) where q.MBR_PGM_YEAR="+programYear);
			whereCondition.append(" AND q.IS_ACTIVE='Y' AND q.UpdatedDate > '" + joblastrunsuccessfuldate + "'");
			whereCondition.append(" AND q.UpdatedDate <='"+jobStartTime+"')");
		}
		 String PREF_PROV_ST_CD_GRP_BY_PARAM="";
	     String PREF_PROV_ST_CD_SELECT_PARAM="";
	                
	        if(isPPSTCDFeatureEnable) {
	        	PREF_PROV_ST_CD_GRP_BY_PARAM=" mq.PREF_PROV_ST_CD, ";
	        	PREF_PROV_ST_CD_SELECT_PARAM=" mq.PREF_PROV_ST_CD AS preferredProviderState, ";
	        }
	        
	        String IN_ACTIVE_COND="";
	        if(isInActiveFeatureEnable) {
	        	 IN_ACTIVE_COND=" and ((mq.SUPP_REASON != 'BlankPAFExclusion' and mq.MBR_ASSESSMENT_STATUS != 'Not Received') OR mq.SUPP_REASON = 'BlankPAFExclusion') and SUPP_FLAG = 'Y' ";
	        }
	       
			String finalQuery= String.format(MEMBERSUMMARY_AGGREGATION_AGGR_QUERY_BATCH_WISE,PREF_PROV_ST_CD_SELECT_PARAM,IN_ACTIVE_COND,whereCondition,PREF_PROV_ST_CD_GRP_BY_PARAM);
		
		
		return namedParameterJdbcTemplate.query(finalQuery, params,
				new BeanPropertyRowMapper<>(PaAggregationData.class));
	}

	@Override
	public Integer upserMemberSummaryAggregation(List<PaAggregationData> paMemberSummaryAggregationList) {
		StopWatch stopWatch = StopWatch.createStarted();
		log.info("executing upserMemberSummaryAggregation::");
		List<MapSqlParameterSource> params = new ArrayList<>();
		for (PaAggregationData paMemberSummaryAggregationData : paMemberSummaryAggregationList) {
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue("providerGroupId", paMemberSummaryAggregationData.getProviderGroupId());
			source.addValue("providerState", StringUtils.truncate(paMemberSummaryAggregationData.getProviderState(),4));
			source.addValue("programYear", paMemberSummaryAggregationData.getProgramYear());
			source.addValue("clientId", paMemberSummaryAggregationData.getClientId());
			source.addValue("subClientSk", paMemberSummaryAggregationData.getSubClientSk());
			source.addValue("healthSystemId", paMemberSummaryAggregationData.getHealthSystemId());
			source.addValue("providerId", paMemberSummaryAggregationData.getProviderId());
			source.addValue("providerGroupName", paMemberSummaryAggregationData.getProviderGroupName());
			source.addValue("preferredProviderState", paMemberSummaryAggregationData.getPreferredProviderState());
			source.addValue("annualCareVisitNotCompleteCount", paMemberSummaryAggregationData.getAnnualCareVisitNotCompleteCount());
			source.addValue("newPatient30Count", paMemberSummaryAggregationData.getNewPatient30Count());
			source.addValue("newPatient7Count", paMemberSummaryAggregationData.getNewPatient7Count());
			source.addValue("newPatient90Count", paMemberSummaryAggregationData.getNewPatient90Count());
			source.addValue("highPriorityCount", paMemberSummaryAggregationData.getHighPriorityCount());
			source.addValue("noCurrFluVaccCount", paMemberSummaryAggregationData.getNoCurrFluVaccCount());
			source.addValue("createdBy", "System");
			source.addValue("updatedby", "System");
			params.add(source);
		}
		String preferredProviderStateCond="";
		if(isPPSTCDFeatureEnable) {
			preferredProviderStateCond=" AND TARGET.PreferredProviderState = SOURCE.preferredProviderState  ";
		}
		
		String finalQuery= String.format(UPDATE_MEMBERSUMMARY_AGGREGATION,preferredProviderStateCond);
		
		int[] batchCount = namedParameterJdbcTemplate.batchUpdate(finalQuery,
				params.toArray(new MapSqlParameterSource[params.size()]));
		log.info("execution completed for {} upserMemberSummaryAggregation: {}seconds", batchCount.length,
				stopWatch.getTime(TimeUnit.SECONDS));
		return batchCount.length;
	}

	public final String AFFECTED_PROVIDER_GROUPS_QUERY = " SELECT DISTINCT  ASSOC_PROV_GRP_ID FROM  "
			+ " %s with (NOLOCK) " + " where  %s";

	@Override
	/* 
	 * This method will be invoked from only Modified flow
	 * */
	public List<String> getAffectedProvGrpList(Integer programYear, String joblastrunsuccessfuldate,
			String jobStartTime, String jobName) {

		HashMap<String, Object> params = new HashMap<>();

		StringBuilder whereCondition = new StringBuilder(100);

		if (PAJobNames.RUN_MEMBER_SUMMARY_AGGREGATION.getJobName().equals(jobName)) {
			whereCondition.append(" MBR_PGM_YEAR =:ProgramYear  ");
		} else {
			whereCondition.append(" GAP_YR =:ProgramYear   ");
		}
		
		
		if (null != joblastrunsuccessfuldate && null != jobStartTime ) {

			whereCondition.append(" AND  UpdatedDate > '" + joblastrunsuccessfuldate + "'");
			whereCondition.append(" AND  UpdatedDate <= '" + jobStartTime + "'");
		}
		
		

		params.put("ProgramYear", String.valueOf(programYear));

		String finalQuery = String.format(AFFECTED_PROVIDER_GROUPS_QUERY,
				PAJobNames.fromString(jobName).getSourceTable(), whereCondition);

		return namedParameterJdbcTemplate.queryForList(finalQuery, params, String.class);
	}
	
	@Override
	public Long getRecordCountModifiedByPrvGrps(String jobName,String groupToExecute,  Integer programYear,  String joblastrunsuccessfuldate,String jobStartTime) {
		HashMap<String, Object> params = new HashMap<>();

		StringBuilder whereCondition = new StringBuilder(100);
		/*if (GroupsToExecute.MODIFIED.getValue().equals(groupToExecute) && (null==prvGrpList || prvGrpList.size()<1)) {
			return 0l;
		}*/
	
		String mbrProgramYear = "GAP_YR";
		if (PAJobNames.RUN_MEMBER_SUMMARY_AGGREGATION.getJobName().equals(jobName)) {
			whereCondition.append(" MBR_PGM_YEAR =:ProgramYear  ");
			mbrProgramYear = "MBR_PGM_YEAR";
		} else {
			whereCondition.append(" GAP_YR =:ProgramYear  ");
		}
		if(GroupsToExecute.ALL.getValue().equals(groupToExecute)) {
			whereCondition.append(" AND IS_ACTIVE ='Y'  ");
		}
		if(null != joblastrunsuccessfuldate && null != jobStartTime &&  GroupsToExecute.MODIFIED.getValue().equals(groupToExecute)) {
			whereCondition.append(" AND ASSOC_PROV_GRP_ID  in( select distinct  q.ASSOC_PROV_GRP_ID from "
					+ PAJobNames.fromString(jobName).getSourceTable() + " q with(nolock)  where ");
			if (PAJobNames.RUN_MEMBER_SUMMARY_AGGREGATION.getJobName().equals(jobName)) {
				whereCondition.append(" q.MBR_PGM_YEAR ="+programYear);
			} else {

				whereCondition.append(" q.gap_yr ='"+programYear+"'");
			}
			whereCondition.append(" AND  q.UpdatedDate > '" + joblastrunsuccessfuldate + "'");
			whereCondition.append(" AND q.UpdatedDate <= '"+jobStartTime+"')");

		}
		String pcpId = "PCP_ID";
		if (PAJobNames.RUN_MEMBER_HOSPITAL_EVENTS_AGGREGATION.getJobName().equals(jobName)) {
			pcpId = "ASSOC_PROV_VDS_ID";
		}

		params.put("ProgramYear", String.valueOf(programYear));
		
		String finalQuery = "";
		if (isPPSTCDFeatureEnable) {
			String preferredProviderState = "PREF_PROV_ST_CD,";
			if (PAJobNames.RUN_MEMBER_HOSPITAL_EVENTS_AGGREGATION.getJobName().equals(jobName)) {
				preferredProviderState = "";
			}

			finalQuery = String.format(COUNT_QUERY_MODIFIED, mbrProgramYear, pcpId, preferredProviderState,
					PAJobNames.fromString(jobName).getSourceTable(), whereCondition, mbrProgramYear, pcpId,
					preferredProviderState);
		} else {
			finalQuery = String.format(COUNT_QUERY_MODIFIED_WO_PPSTCD, mbrProgramYear, pcpId,
					PAJobNames.fromString(jobName).getSourceTable(), whereCondition, mbrProgramYear, pcpId);
		}

		return namedParameterJdbcTemplate.queryForObject(finalQuery, params, Long.class);
		
       
	}
	

	public final String UPDATE_INACTIVE_AGGREGATE_QUERY = " UPDATE %s  SET IsActive=0,IsDirty=0,UpdatedDate = GETUTCDATE()  WHERE %s ";
		   		
	@Override
	public Integer inActivateDirtyRecords(String jobName, String groupToExecute, Integer programYear,
			String joblastrunsuccessfuldate,String jobStartTime) {
		StopWatch stopWatch = StopWatch.createStarted();
		HashMap<String, Object> params = new HashMap<>();
		log.info("executing inActivateDirtyRecords::");

		/*if (GroupsToExecute.MODIFIED.getValue().equals(groupToExecute)
				&& (null == prvGrpList || prvGrpList.size() < 1)) {
			log.info("inActivateDirtyRecords execution completed for {} records in {}seconds", 0,
					stopWatch.getTime(TimeUnit.SECONDS));
			return 0;
		}*/

		StringBuilder whereCondition = new StringBuilder(100);

		whereCondition.append(" ProgramYear =:ProgYear AND IsDirty=1 ");

		/*if (null != prvGrpList && prvGrpList.size() > 0 && GroupsToExecute.MODIFIED.getValue().equals(groupToExecute)) {
			whereCondition.append(" AND ProviderGroupID in( :prvGrps) ");
			 params.put("prvGrps", prvGrpList);
		
		}*/
		if(null != joblastrunsuccessfuldate && null != jobStartTime &&  GroupsToExecute.MODIFIED.getValue().equals(groupToExecute)) {
			whereCondition.append(" AND ProviderGroupID  in( select distinct  q.ASSOC_PROV_GRP_ID from "
					+ PAJobNames.fromString(jobName).getSourceTable() + " q with(nolock)  where ");
			if (PAJobNames.RUN_MEMBER_SUMMARY_AGGREGATION.getJobName().equals(jobName)) {
				whereCondition.append(" q.MBR_PGM_YEAR ="+programYear);
			} else {

				whereCondition.append(" q.gap_yr ='"+programYear+"'");
			}
			whereCondition.append(" AND  q.UpdatedDate > '" + joblastrunsuccessfuldate + "'");
			whereCondition.append(" AND q.UpdatedDate <= '"+jobStartTime+"')");

		}

		params.put("ProgYear", programYear);
	
		String finalQuery = String.format(UPDATE_INACTIVE_AGGREGATE_QUERY,
				PAJobNames.fromString(jobName).getAggregateTable(), whereCondition);
		
		
		int updCount = namedParameterJdbcTemplate.update(finalQuery,params);
		log.info("inActivateDirtyRecords execution completed for {} records in {}seconds", updCount,
				stopWatch.getTime(TimeUnit.SECONDS));
		return updCount;
	}

	
	public final String MARK_AS_DIRTY_QUERY = " UPDATE %s  SET IsDirty=1  WHERE %s ";
		
	@Override
	public Integer markedRecordsAsDirty(String jobName, String groupToExecute, Integer programYear,
			String joblastrunsuccessfuldate,String jobStartTime) {
		StopWatch stopWatch = StopWatch.createStarted();
		HashMap<String, Object> params = new HashMap<>();

		log.info("executing markedRecordsAsDirty::");

		/*if (GroupsToExecute.MODIFIED.getValue().equals(groupToExecute)
				&& (null == prvGrpList || prvGrpList.size() < 1)) {
			log.info("markedRecordsAsDirty execution completed for {} records in {}seconds", 0,
					stopWatch.getTime(TimeUnit.SECONDS));
			return 0;
		}*/
	
		StringBuilder whereCondition = new StringBuilder(100);

		whereCondition.append(" ProgramYear =:ProgYear AND IsActive=1 ");

		/*if (null != prvGrpList && prvGrpList.size() > 0 && GroupsToExecute.MODIFIED.getValue().equals(groupToExecute)) {
			whereCondition.append(" AND ProviderGroupID in( :prvGrps) ");
			 params.put("prvGrps", prvGrpList);
			
		}*/
		if(null != joblastrunsuccessfuldate && null != jobStartTime &&  GroupsToExecute.MODIFIED.getValue().equals(groupToExecute)) {
			whereCondition.append(" AND ProviderGroupID  in( select distinct  q.ASSOC_PROV_GRP_ID from "
					+ PAJobNames.fromString(jobName).getSourceTable() + " q with(nolock)  where ");
			if (PAJobNames.RUN_MEMBER_SUMMARY_AGGREGATION.getJobName().equals(jobName)) {
				whereCondition.append(" q.MBR_PGM_YEAR ="+programYear);
			} else {

				whereCondition.append(" q.gap_yr ='"+programYear+"'");
			}
			whereCondition.append(" AND  q.UpdatedDate > '" + joblastrunsuccessfuldate + "'");
			whereCondition.append(" AND q.UpdatedDate <= '"+jobStartTime+"')");

		}

		params.put("ProgYear", programYear);
		
		String finalQuery = String.format(MARK_AS_DIRTY_QUERY,
				PAJobNames.fromString(jobName).getAggregateTable(), whereCondition);
		
		int updCount = namedParameterJdbcTemplate.update(finalQuery,params);
		log.info("markedRecordsAsDirty execution completed for {} records in {}seconds", updCount,
				stopWatch.getTime(TimeUnit.SECONDS));
		return updCount;
	}


	@Override
	public List<PaAggregationData> getPaHospitalEventsAggregateDataByBatch(Integer programYear,
			String joblastrunsuccessfuldate, String jobStartTime, int offset, int batchsize) {
		HashMap<String,Object> params =  new HashMap<>();
        
        StringBuilder  whereCondition = new StringBuilder(100);
        params.put("ProgramYear",programYear);
         params.put("offset",offset);
        params.put("batchsize", batchsize);
        if (null != joblastrunsuccessfuldate && null!=jobStartTime) {
			whereCondition.append(" AND ASSOC_PROV_GRP_ID  in( select distinct  q.ASSOC_PROV_GRP_ID from "
					+" ProgPerf.MemberHospitalEvents q with(nolock)  where  q.gap_yr="+programYear);
				whereCondition.append(" AND q.is_active='Y' AND  q.UpdatedDate > '" + joblastrunsuccessfuldate + "'");
				whereCondition.append(" AND q.UpdatedDate <='"+jobStartTime+"')");
		}
		String finalQuery= String.format(HOSPITAL_EVENTS_AGGREGATION_AGGR_QUERY_BATCH_WISE,whereCondition);
		
        return namedParameterJdbcTemplate.query(finalQuery, params, new BeanPropertyRowMapper<>(PaAggregationData.class));
	}


	@Override
	public Integer upserHospitalEventsAggregation(List<PaAggregationData> paHospitalEventsAggregationList) {
		StopWatch stopWatch = StopWatch.createStarted();
		log.info("executing upserHospitalEventsAggregation::");
		List<MapSqlParameterSource> params = new ArrayList<>();

		for (PaAggregationData paHospitalEventsAggregationData : paHospitalEventsAggregationList) {
			MapSqlParameterSource source = new MapSqlParameterSource();
			source.addValue("providerGroupId", paHospitalEventsAggregationData.getProviderGroupId());
			source.addValue("providerState", StringUtils.truncate(paHospitalEventsAggregationData.getProviderState(),4));
			source.addValue("programYear", paHospitalEventsAggregationData.getProgramYear());
			source.addValue("clientId", paHospitalEventsAggregationData.getClientId());
			source.addValue("subClientSk", paHospitalEventsAggregationData.getSubClientSk());
			source.addValue("healthSystemId", paHospitalEventsAggregationData.getHealthSystemId());
			source.addValue("providerGroupName", paHospitalEventsAggregationData.getProviderGroupName());
			source.addValue("providerId", paHospitalEventsAggregationData.getProviderId());
			source.addValue("recentDischarge3Count", paHospitalEventsAggregationData.getRecentDischarge3Count());
			source.addValue("recentDischarge7Count", paHospitalEventsAggregationData.getRecentDischarge7Count());
			source.addValue("recentDischarge30Count", paHospitalEventsAggregationData.getRecentDischarge30Count());

			source.addValue("createdBy", JobName.RUN_MEMBER_HOSPITAL_EVENTS_AGGREGATION.getValue());
			source.addValue("updatedby", JobName.RUN_MEMBER_HOSPITAL_EVENTS_AGGREGATION.getValue());

			params.add(source);
		}

		int[] batchCount = namedParameterJdbcTemplate.batchUpdate(UPSERT_HOSPITAL_EVENTS_AGGREGATION,
				params.toArray(new MapSqlParameterSource[params.size()]));

		log.info("execution completed for {} upserHospitalEventsAggregation: {}seconds", batchCount.length,
				stopWatch.getTime(TimeUnit.SECONDS));
	
		return batchCount.length;

	}



	@Override
	@Deprecated
	public Integer markedRecordsAsDirty(String jobName, String groupToExecute, Integer programYear,
			String joblastrunsuccessfuldate, String jobStartTime, List<String> affectedPrvGrpList) {
		// TODO Auto-generated method stub
	     throw new RuntimeException("NOT implemented in MS SQL version");
	}



	@Override
	@Deprecated
	public List<PaAggregationData> getPaAggregateDataByBatch(Integer programYear, String joblastrunsuccessfuldate,
			String jobStartTime, List<String> affectedPrvGrpList) {
		// TODO Auto-generated method stub
		throw new RuntimeException("NOT implemented in MS SQL version");
	}



	@Override
	@Deprecated
	public Integer inActivateDirtyRecords(String jobName, String groupToExecute, Integer programYear,
			String joblastrunsuccessfuldate, String jobStartTime, List<String> affectedPrvGrpList) {
		// TODO Auto-generated method stub
		throw new RuntimeException("NOT implemented in MS SQL version");
	}



	@Override
	@Deprecated
	public List<PaAggregationData> getPaMedAdherenceAggregateDataByBatch(Integer programYear,
			String joblastrunsuccessfuldate, String jobStartTime, List<String> affectedPrvGrpList) {
		// TODO Auto-generated method stub
		throw new RuntimeException("NOT implemented in MS SQL version");
	}



	@Override
	@Deprecated
	public List<PaAggregationData> getPaMemberSummaryAggregateDataByBatch(Integer programYear,
			String joblastrunsuccessfuldate, String jobStartTime, List<String> affectedPrvGrpList) {
		// TODO Auto-generated method stub
		throw new RuntimeException("NOT implemented in MS SQL version");
	}
   
	
}
