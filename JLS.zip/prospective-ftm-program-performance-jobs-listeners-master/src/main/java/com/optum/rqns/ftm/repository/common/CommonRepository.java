package com.optum.rqns.ftm.repository.common;

import com.optum.rqns.ftm.model.JobConfiguration;
import com.optum.rqns.ftm.model.JobConfigurationRequest;
import com.optum.rqns.ftm.model.JobRunConfiguration;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.model.ProgramYearCalendarDTO;
import com.optum.rqns.ftm.model.qfo.CommonProgramYearCalenderDTO;

import java.util.List;

public interface CommonRepository {

    Integer upsertJobRunConfiguration(JobRunConfiguration jobRunConfiguration);

    int getBatchSize();

    Boolean getJobIsActiveByName(String jobName);

    Integer getJobIdByName(String jobName);

    Integer updateJobExecutionHistoryAsJobStart(Integer jobID, String correlationKey, String jobEvent, String errorMessage);

    Integer updateJobExecutionHistoryAsJobEnd(Integer jobExecutionId, Status status, String errorMessage, String message, Long affectedRows);

    Integer getJobExecutionHistoryByMessageKey(Integer jobId, String messageKey);

    Integer getJobExecutionHistoryByTime(Integer jobId, Integer thresholdInMinutes);

    Integer updateAffectedRowsCountForJob(String jobName, Long affectedRowCount);

    JobConfiguration getAllJobConfigurations();

    JobConfiguration getJobConfigurationByName(JobName jobName);

    Integer jobConfigurationUpdates(JobConfigurationRequest jobConfiguration);

    String getJobFrequency(String jobName);

    String getCascadedJobs(String jobName);

    ProgramYearCalendarDTO getYTDDuration(Integer programYear);

    CommonProgramYearCalenderDTO getDuration(Integer programYear, String teamType);

    Integer getCurrentProgramYear();

    String getJobsLastRunSuccessfulDate(String  jobName);

	String fetchLastSucessfullJobStartRanDate(String masterOpportunityName);

    List<ProgramYearCalendarDTO> getYTDDurationMonth(Integer programYear, String month);

	Integer getPACurrentProgramYear();

    String getKafkaEnabledConf(String memberStatusRqsEnabled);
}
