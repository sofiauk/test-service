package com.optum.rqns.ftm.repository.jobalerts;

import com.optum.rqns.ftm.model.JobAlert;
import com.optum.rqns.ftm.util.ProgramPerformanceJobUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@Slf4j
public class MonitoringJobRepositoryImpl implements MonitoringJobRepository {

    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    public MonitoringJobRepositoryImpl(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
        this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
    }

    public static final String GET_LONG_RUNNING_JOBS_QUERY = "with masterConfig as (select value as JobInprogressThreshold  " +
            ",(SELECT value   " +
            "from ProgPerf.MasterConfiguration mc with (nolock) where code = 'MonitoringJobExclusionList') as excludeList  " +
            "from ProgPerf.MasterConfiguration with (nolock) " +
            "where code = 'JobInprogressThreshold' " +
            ") " +
            "select  " +
            "jrc.JobName, jrc.JobDescription, jrc.LastRunDate, jrc.CreatedBy,  " +
            "jrc.CreatedDate, jrc.ModifiedBy, jrc.ModifiedDate, jrc.LastSuccessfulRunDate,  " +
            "jrc.messageKey, jrc.jobEvent,  " +
            "CONCAT('The ',jrc.JobName ,' job is running for more than ', (select JobInprogressThreshold from masterConfig) ,' minutes . Please take the necessary action.') as message, " +
            "jrc.isActive as active,  " +
            "jrc.ID, null as jobExecutionHistoryId , jrc.Status,jrc.ErrorMessage,jrc.AffectedRows,jrc.JobStart,jrc.JobEnd  " +
            "from ProgPerf.JobRunConfiguration jrc  with (nolock)  " +
            "where jrc.Status in ('InProgress')  " +
            "and not EXISTS (SELECT value from masterConfig CROSS APPLY STRING_SPLIT(excludeList, ',') where value = jrc.JobName ) " +
            "and DateDiff(MINUTE ,jrc.JobStart ,GetUtcDate())> (select JobInprogressThreshold from  masterConfig) " +
            "and jrc.isActive = 1 ";

    @Override
    public List<JobAlert> getLongRunningJobs() {
        log.info("Fetching JobAlert details :{} ", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
        return namedParameterJdbcTemplate.query(GET_LONG_RUNNING_JOBS_QUERY, BeanPropertyRowMapper.newInstance(JobAlert.class));
    }
}
