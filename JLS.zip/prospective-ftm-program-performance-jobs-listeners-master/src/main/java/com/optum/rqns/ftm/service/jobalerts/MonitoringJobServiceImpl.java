package com.optum.rqns.ftm.service.jobalerts;

import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.model.JobAlert;
import com.optum.rqns.ftm.model.JobRunConfiguration;
import com.optum.rqns.ftm.repository.common.CommonRepository;
import com.optum.rqns.ftm.repository.jobalerts.MonitoringJobRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
public class MonitoringJobServiceImpl implements MonitoringJobService {

    @Autowired
    MonitoringJobRepository monitoringJobRepository;

    @Autowired
    CommonRepository commonRepository;

    @Autowired
    PrometheusJobAlertService prometheusJobAlertService;

    @Override
    public void monitorJobs() {
        log.info("Started monitoring jobs...");
        int execId = -1;
        int jobId = -1;
        try {
            commonRepository.upsertJobRunConfiguration(JobRunConfiguration.builder()
                    .jobName(JobName.MONITORING_JOB)
                    .updateMessageKey(true)
                    .updateMessage(true)
                    .updateJobStart(true)
                    .updateAffectedRows(true)
                    .message(Constants.EMPTY)
                    .createdBy(Constants.SYSTEM)
                    .modifiedBy(Constants.SYSTEM)
                    .status(Status.IN_PROGRESS)
                    .errorMessage(Constants.EMPTY)
                    .affectedRows(null)
                    .build());

            jobId = commonRepository.getJobIdByName(JobName.MONITORING_JOB.getValue());
            execId = commonRepository.updateJobExecutionHistoryAsJobStart(jobId, Constants.EMPTY, Constants.EMPTY, Constants.EMPTY);
            final List<JobAlert> longRunningJobs = monitoringJobRepository.getLongRunningJobs();
            for (JobAlert jobAlert : longRunningJobs) {
                log.info("Sending alert to {}", jobAlert.getJobName());
                prometheusJobAlertService.sendAlerts(jobAlert);
            }
            String message = "Completed MonitoringJob job";
            //JobExecutionHistory
            commonRepository.updateJobExecutionHistoryAsJobEnd(execId, Status.SUCCESS,
                    Constants.EMPTY, message, Long.valueOf(longRunningJobs.size()));

            //Update Success message
            commonRepository.upsertJobRunConfiguration(
                    JobRunConfiguration
                            .builder()
                            .jobName(JobName.MONITORING_JOB)
                            .status(Status.SUCCESS)
                            .updateJobEnd(true)
                            .updateLastSuccessfulRun(true)
                            .updateMessage(true)
                            .message(message)
                            .updateAffectedRows(true)
                            .affectedRows(Long.valueOf(longRunningJobs.size()))
                            .createdBy(Constants.SYSTEM)
                            .modifiedBy(Constants.SYSTEM)
                            .build());
        } catch (Exception e) {
            log.error("Error in monitoring the jobs", e);
            //JobExecutionHistory
            commonRepository.updateJobExecutionHistoryAsJobEnd(execId, Status.FAILURE, e.getMessage(), Constants.EMPTY, null);

            //Update ErrorMessage
            commonRepository.upsertJobRunConfiguration(
                    JobRunConfiguration
                            .builder()
                            .jobName(JobName.MONITORING_JOB)
                            .status(Status.FAILURE)
                            .updateJobEnd(true)
                            .updateLastSuccessfulRun(true)
                            .updateErrorMessage(true)
                            .errorMessage(e.getMessage())
                            .updateAffectedRows(false)
                            .updateMessage(true)
                            .message(Constants.EMPTY)
                            .createdBy(Constants.SYSTEM)
                            .modifiedBy(Constants.SYSTEM)
                            .build()
            );
            throw e;
        }
    }
}
