package com.optum.rqns.ftm.service;

import com.fasterxml.uuid.Generators;
import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.repository.PAFxMemberAssessmentStagingRepository;
import com.optum.rqns.ftm.repository.common.CommonRepository;
import com.optum.rqns.ftm.util.JobUtilility;
import com.optum.rqns.ftm.util.ProgramPerformanceJobUtil;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class PAFxMemberAssessmentStagingServiceImpl implements PAFxMemberAssessmentStagingService{

    private CommonRepository commonRepository;
    private PAFxMemberAssessmentStagingRepository paFxMemberAssessmentStagingRepository;
    private static final int BATCH_SIZE = 10000;
    private JobUtilility jobUtilility =new JobUtilility();

    public PAFxMemberAssessmentStagingServiceImpl(CommonRepository commonRepository, PAFxMemberAssessmentStagingRepository paFxMemberAssessmentStagingRepository){
        this.commonRepository = commonRepository;
        this.paFxMemberAssessmentStagingRepository = paFxMemberAssessmentStagingRepository;
    }
    @Override
    public JobStatus executeJob(JobEvent jobEvent) {

        MDC.put(Constants.TRACE_ID, Generators.timeBasedGenerator().generate().toString());
        MDC.put(Constants.TRANSACTION_ID, ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
        MDC.put(Constants.MESSAGE_ID, ProgramPerformanceJobUtil.TransactionIdLogger.getMessageIdIdentifier());


        log.info("{} jobEvent.StagingTOPAFxMemberAssessment() :: {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), jobEvent.getJobName());
        JobStatus jobStatus = new JobStatus();

        try {
            log.info("{} Received StagingTOPAFxMemberAssessment message from topic : {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), jobEvent.getJobName());

            final Long totalRows = this.paFxMemberAssessmentStagingRepository.getRecordCount(jobEvent);
            log.info("{} Load Staging to PAFXMemberAssessment record Count {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), totalRows);
            List<Integer> batches = getBatches(totalRows);
            log.info("{} Load  Staging to PAFXMemberAssessment staging Batches offsets are {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), batches.size());
            Long totalRowsUpdated = 0l;
            for (Integer offset : batches) {
                totalRowsUpdated = totalRowsUpdated + this.paFxMemberAssessmentStagingRepository.mergePAFxMemberAssessmentData(jobEvent, offset, BATCH_SIZE);
            }
            log.info("{} Load Staging to PAFXMemberAssessment totalRowsUpdated record Count {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), totalRowsUpdated);
            jobStatus.setStatus(Status.SUCCESS);
            jobStatus.setMessage("Completed Successfully StagingTOPAFxMemberAssessment job execution ");
            jobStatus.setUpdatedRows(totalRowsUpdated);
        } catch(Exception e){
            log.error("Exception while executing with Modify Staging to PafxMemberAssessment job : {}", e);

            jobStatus.setStatus(Status.FAILURE);
            jobStatus.setMessage("StagingTOPAFxMemberAssessment job execution failed : " + e.getMessage());
            jobStatus.setUpdatedRows(0L);
        }
        return jobStatus;
    }


    private List<Integer> getBatches(Long totalRows) {
        List<Integer> batches = new ArrayList<>();
        if (totalRows > 0) {
            for (int batchOffset = 0; batchOffset <= totalRows; batchOffset += BATCH_SIZE) {
                batches.add(batchOffset);
            }
        }
        return batches;
    }
}
