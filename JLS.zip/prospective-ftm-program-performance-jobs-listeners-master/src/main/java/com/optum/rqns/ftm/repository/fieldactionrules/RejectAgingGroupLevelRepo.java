package com.optum.rqns.ftm.repository.fieldactionrules;

import com.optum.rqns.ftm.model.fieldactionrules.RuleAction;

import java.util.List;

public interface RejectAgingGroupLevelRepo {

    public List<RuleAction> fetchRejectAgingInfo(Integer beginIndex,int batchSize);

    public  List<Integer> getRowCountAndBatchesForReturnAging(int batchSize);


}
