package com.optum.rqns.ftm.repository.users;



import java.util.List;

public interface UsersRepository {
    List<String> getUsersByRole(List<String> roleName);

    List<String> getIcReporters(String leader);
}
