package com.optum.rqns.ftm.quartz.jobs;

import com.optum.rqns.ftm.enums.ExecutionWeek;
import com.optum.rqns.ftm.enums.GroupsToExecute;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.producer.JobEventProducer;
import lombok.extern.slf4j.Slf4j;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneOffset;

@Profile("rqnsFtmJobs")
@Slf4j
@Component
@DisallowConcurrentExecution
public class MemberQualityGapsJob implements Job {

    @Autowired
    private JobEventProducer jobEventProducer;
    private static final String JOB_NAME = JobName.QFOPERFORMANCE.getValue();// changes to QFOPERFORMANCE as part new sequencing
    private static final String GROUPS_TO_EXECUTE_MODIFIED = GroupsToExecute.MODIFIED.getValue();
    private static final String GROUPS_TO_EXECUTE_ALL = GroupsToExecute.ALL.getValue();
    private static final String GROUPS_TO_EXECUTE_MONTHLY = GroupsToExecute.MONTHLY.getValue();
    private static final String EXECUTION_WEEK = ExecutionWeek.ALL.getValue();
    private static final String STATUS = Status.IN_PROGRESS.getValue();
    private static final String DESCRIPTION = "Notification to RunMemberQuality Gaps in MemberGap Jobs Profile";

    @Override
    /**
     * Execute method will invoke with Cron Job
     */
    public void execute(JobExecutionContext context) {
        log.info("Job {}  starting @ {}", context.getJobDetail().getKey().getName(), context.getFireTime());
        notifyMemberQualityGapsJob(context, buildJobEvent());

    }

    /**
     * Build Job Event for Member Suspect Gaps
     * @return
     */
    private JobEvent buildJobEvent() {
        LocalDateTime dateTime = LocalDateTime.ofInstant(Instant.now(), ZoneOffset.UTC);

        if(isTodayBeginningOfTheMonth()){
            return JobEvent.newBuilder().setJobName(JOB_NAME).setGroupsToExecute(GROUPS_TO_EXECUTE_MONTHLY)
                    .setExecutionWeek(EXECUTION_WEEK).setStatus(STATUS)
                    .setTimeStamp(Instant.now()).setCascadeEvents(true).build();
        }else if(dateTime.getDayOfWeek().toString().equalsIgnoreCase("SUNDAY")){
            return JobEvent.newBuilder().setJobName(JOB_NAME).setGroupsToExecute(GROUPS_TO_EXECUTE_ALL)
                    .setExecutionWeek(EXECUTION_WEEK).setStatus(STATUS)
                    .setTimeStamp(Instant.now()).setCascadeEvents(true).build();
        }else{
            return JobEvent.newBuilder().setJobName(JOB_NAME).setGroupsToExecute(GROUPS_TO_EXECUTE_MODIFIED)
                    .setExecutionWeek(EXECUTION_WEEK).setStatus(STATUS)
                    .setTimeStamp(Instant.now()).setCascadeEvents(true).build();
        }
    }

    /**
     * Post Job event message to Kafka
     * @param context
     * @param jobEvent
     */
    private void notifyMemberQualityGapsJob(JobExecutionContext context, JobEvent jobEvent) {
        try {
            boolean sent = jobEventProducer.postToKafka(jobEvent);
            if (!sent) log.error("Failed to send {}", DESCRIPTION);
            log.info("Successfully sent {}", DESCRIPTION);
        } catch (Exception e) {
            log.error("Job Failed " + "Job ** {} ** starting @ {}  with Exception ## {} ",
                    context.getJobDetail().getKey().getName(), context.getFireTime(), e.getMessage());

        }
    }

    public boolean isTodayBeginningOfTheMonth(){
        LocalDate today = LocalDate.now();
        return today.isEqual(today.withDayOfMonth(1));
    }

}
