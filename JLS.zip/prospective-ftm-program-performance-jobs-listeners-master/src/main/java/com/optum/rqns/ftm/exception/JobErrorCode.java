package com.optum.rqns.ftm.exception;

import com.optum.rqns.ftm.constants.Constants;
import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum JobErrorCode {

    //Kafka JobEventProducer
    INVALID_JOB_NAME("16001","Job Name is not available in Provider Group Opportunities - Job Name list", Constants.INVALID_DATA_WARNING),
    INVALID_GROUPS_TO_EXECUTE("16002","GroupsToExecute is not available in  Provider Group Opportunities - GroupsToExecute list",Constants.INVALID_DATA_WARNING),
    INVALID_EXECUTION_WEEK("16003","ExecutionWeek is not available in Provider Group Opportunities - ExecutionWeek list",Constants.INVALID_DATA_WARNING),
    INVALID_JOB_EVENT_DETAILS("16006","Job details are not configured properly","Invalid Input"),
    UNAUTHORIZED("16007","UnAuthorized!!!","UnAuthorized"),

    GENERIC("1001","Something went wrong please contact System Admin","Internal Server"),
    KAFKA_PRODUCER_EXCEPTION("16004","Kafka producer exception occurred","Kafka Producer Exception"),
    KAFKA_EXCEPTION("16005","Kafka exception occurred","Kafka Exception");

    private String code;
    private String detail;
    private String title;
}
