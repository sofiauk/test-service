
package com.optum.rqns.ftm.kafka.producer;

import com.optum.rqns.ftm.exception.ProgramPerformanceJobListenerException;
import com.optum.rqns.ftm.kafka.avro.models.v1.fieldactionrule.FieldActionRuleMetadata;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.common.KafkaException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.kafka.core.KafkaProducerException;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Component;
import org.springframework.util.concurrent.ListenableFuture;


@Component
@Slf4j
public class KeyBasedFieldActionRuleProducer {

    private KafkaTemplate<String, FieldActionRuleMetadata> kafkaTemplate;

    @Value("${spring.gcpkafka.properties.topics.fieldActionRule}")
    public String topicName;


    public KeyBasedFieldActionRuleProducer(KafkaTemplate<String, FieldActionRuleMetadata> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    public boolean postToKafka(FieldActionRuleMetadata message, String key) {
            try {
                log.info("Key based Message posting ******* {} *******", message.toString());
                ListenableFuture<SendResult<String, FieldActionRuleMetadata>> result=kafkaTemplate.send(topicName,key,message);
                kafkaTemplate.flush();
                log.info("Key based Message sent successfully for fieldActionRule ******* {} ******* [Users,RuleType]  = {},{}", message.getUsers(),message.getRuleType());
                return result.isDone();
            } catch (KafkaProducerException ex) {
                log.error("KafkaProducerException occured while sending message to kafka topic for keyBased {}", ex.getMessage());
                throw new ProgramPerformanceJobListenerException(HttpStatus.NOT_ACCEPTABLE, com.optum.rqns.ftm.exception.JobErrorCode.KAFKA_PRODUCER_EXCEPTION);
            } catch (KafkaException ex) {
                log.error("KafkaException occured while sending message to kafka topic for keyBased {}", ex.getMessage());
                throw new ProgramPerformanceJobListenerException(HttpStatus.NOT_ACCEPTABLE, com.optum.rqns.ftm.exception.JobErrorCode.KAFKA_EXCEPTION);
            } catch (Exception ex) {
                log.error("Exception occured while sending message to kafka topic for keyBased {}", ex.getMessage());
            }

        return false;
    }


}

