package com.optum.rqns.ftm.service.practiceassist;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.stream.IntStream;

import org.apache.commons.lang3.mutable.MutableLong;
import org.apache.commons.lang3.time.StopWatch;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.uuid.Generators;
import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.enums.GroupsToExecute;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.model.practiceassist.PaAggregationData;
import com.optum.rqns.ftm.repository.common.CommonRepository;
import com.optum.rqns.ftm.repository.practiceassist.PaLandingPageRepository;
import com.optum.rqns.ftm.util.ProgramPerformanceJobUtil;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class SuspectAggregationServiceImpl extends PaLandingPageService  {
	
	
	private PaLandingPageRepository paLandingPageRepository;
	private CommonRepository commonRepository;
	
	@Value("${suspect_fetch_batchsize:100000}")
	private  int FETCH_BATCH_SIZE;
	
	@Value("${suspect_upsert_batchsize:5000}")
	private int UPSERT_BATCH_SIZE;
	

	@Value("${new_providergroup_rule_producer_thread_pool_size}")
	private int producerThreadPoolSize;
	
	@Value("${suspect_thread_pool_size:15}")
	private int threadPoolSize;

	public SuspectAggregationServiceImpl(@Qualifier("PaLandingPageRepositorySQL") PaLandingPageRepository paLandingPageRepository,
			CommonRepository commonRepository) {
		this.paLandingPageRepository = paLandingPageRepository;
		this.commonRepository = commonRepository;
	}

	
	public JobStatus executeJob(JobEvent jobEvent) {
		StopWatch stopWatch = StopWatch.createStarted();
		MDC.put(Constants.TRACE_ID, Generators.timeBasedGenerator().generate().toString());
		MDC.put(Constants.TRANSACTION_ID, ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
		MDC.put(Constants.MESSAGE_ID, ProgramPerformanceJobUtil.TransactionIdLogger.getMessageIdIdentifier());

		log.info("{} jobEvent.SuspectAggregation() :: {} Flow Type:{}",
				ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), jobEvent.getJobName(), jobEvent.getGroupsToExecute().toString());
		JobStatus jobStatus = new JobStatus();

		
		
		try {
			
			/*if (!jobEvent.getGroupsToExecute().toString().equalsIgnoreCase(GroupsToExecute.ALL.getValue())) {
				log.error(" SKIP {} jobEvent.SuspectAggregation():: {}",
						ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), jobEvent.getJobName());
				jobStatus.setStatus(Status.SUCCESS);
				jobStatus.setMessage("SKIP");
				return jobStatus;
			}*/
			MutableLong totalRowsUpdated = new MutableLong(); 
            Long totalRowsToBeUpdated=0l;
            //String joblastrunsuccessfuldate=null;
			if (jobEvent.getGroupsToExecute().toString().equalsIgnoreCase(GroupsToExecute.ALL.getValue())) {
				 /*Long totalRows =  this.paLandingPageRepository.getRecordCountModified(jobEvent.getProgramYear(),
						joblastrunsuccessfuldate,jobEvent.getJobName().toString());*/
				Long totalRows = this.paLandingPageRepository.getRecordCountModifiedByPrvGrps(
						jobEvent.getJobName().toString(), GroupsToExecute.ALL.getValue(),jobEvent.getProgramYear(), null,null);
				
				this.paLandingPageRepository.markedRecordsAsDirty(JobName.RUN_SUSPECT_AGGREGATION.getValue(),
						GroupsToExecute.ALL.getValue(), jobEvent.getProgramYear(), null,null);
				
				log.info("{} SuspectAggregation record Count {}",
						ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), totalRows);
				List<Integer> batches = getBatches(totalRows);
				log.info("{} ALL-Full Refresh SuspectAggregation total Batches offsets are {}",
						ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), batches.size());
				ExecutorService executorService = Executors.newFixedThreadPool(threadPoolSize);
			     List<Callable<Long>> taskList = new ArrayList<>();
				for (Integer offset : batches) {
				
					taskList.add(new Callable<Long>() {

						@Override
						public Long call() throws Exception {
							StopWatch stopWatch2 = StopWatch.createStarted();

							log.info("Thread:{} , Fetching data from offset{}  with batch size{}",
									Thread.currentThread().getName(), offset, FETCH_BATCH_SIZE);
							List<PaAggregationData> paSuspectAggregationList = fetchAggregationData(jobEvent, null,null,
									offset);
							log.info("Thread:{} , Fetching data from offset {} is completed for {} records  in {}seconds",
									Thread.currentThread().getName(), offset, paSuspectAggregationList.size(),
									stopWatch2.getTime(TimeUnit.SECONDS));
							return batchUpdate(paSuspectAggregationList);

						}

					});	
				
				}
				totalRowsUpdated.add(invokeAll(executorService, taskList));
				
				this.paLandingPageRepository.inActivateDirtyRecords(JobName.RUN_SUSPECT_AGGREGATION.getValue(),
						GroupsToExecute.ALL.getValue(), jobEvent.getProgramYear(), null,null);

			} else {
				
//				 joblastrunsuccessfuldate = commonRepository
//						.getJobsLastRunSuccessfulDate(jobEvent.getJobName().toString());
				
				String joblastrunsuccessfuldate=commonRepository.fetchLastSucessfullJobStartRanDate(JobName.RUN_SUSPECT_AGGREGATION.getValue());
				
				String jobStartime = getUTCDateTime(LocalDateTime.now());
				
				log.info("{} last sucessfull run datetime:{} ",JobName.RUN_SUSPECT_AGGREGATION.name(), joblastrunsuccessfuldate);
				
				
				/*List<String> affectedPrvGrpList= this.paLandingPageRepository.getAffectedProvGrpList(jobEvent.getProgramYear(),
						joblastrunsuccessfuldate,jobStartime,jobEvent.getJobName().toString());*/
				
				/*totalRowsToBeUpdated = this.paLandingPageRepository.getRecordCountModified(jobEvent.getProgramYear(),
				joblastrunsuccessfuldate,jobStartime,jobEvent.getJobName().toString());*/
				
				totalRowsToBeUpdated = this.paLandingPageRepository.getRecordCountModifiedByPrvGrps(
						jobEvent.getJobName().toString(), GroupsToExecute.MODIFIED.getValue(),
						jobEvent.getProgramYear(), joblastrunsuccessfuldate,jobStartime);
				
				log.info("{} SuspectAggregation totalRowsToBeUpdated Count {}",
						ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), totalRowsToBeUpdated);
				List<Integer> batches = getBatches(totalRowsToBeUpdated);
				log.info("{} Modifed SuspectAggregation total Batches offsets are {}",
						ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), batches.size());
				this.paLandingPageRepository.markedRecordsAsDirty(JobName.RUN_SUSPECT_AGGREGATION.getValue(),
						GroupsToExecute.MODIFIED.getValue(), jobEvent.getProgramYear(), joblastrunsuccessfuldate,jobStartime);
				
				ExecutorService executorService = Executors.newFixedThreadPool(threadPoolSize);
			     List<Callable<Long>> taskList = new ArrayList<>();
			
				for (Integer offset : batches) {
					
					
					taskList.add(new Callable<Long>() {

						@Override
						public Long call() throws Exception {
							StopWatch stopWatch2 = StopWatch.createStarted();

							log.info("Thread:{} , Fetching data from offset{}  with batch size{}",
									Thread.currentThread().getName(), offset, FETCH_BATCH_SIZE);
							List<PaAggregationData> paSuspectAggregationList = fetchAggregationData(jobEvent,joblastrunsuccessfuldate,jobStartime,
									offset);
							log.info("Thread:{} , Fetching data from offset {} is completed for {} records  in {}seconds",
									Thread.currentThread().getName(), offset, paSuspectAggregationList.size(),
									stopWatch2.getTime(TimeUnit.SECONDS));
							return batchUpdate(paSuspectAggregationList);

						}

					});	

				}
				totalRowsUpdated.add(invokeAll(executorService, taskList));
				this.paLandingPageRepository.inActivateDirtyRecords(JobName.RUN_SUSPECT_AGGREGATION.getValue(),
						GroupsToExecute.MODIFIED.getValue(), jobEvent.getProgramYear(), joblastrunsuccessfuldate,jobStartime);
			}

			
			// Generate final message and update in JobRunconfiguration
			String message = "Completed SuspectAggregation job successfully. "
					+ "Updated records in SuspectAggregation: " + totalRowsUpdated;

			jobStatus.setStatus(Status.SUCCESS);
			jobStatus.setMessage(message);
			jobStatus.setUpdatedRows(totalRowsUpdated.toLong());
			log.info("SuspectAggregation execution completed for {}  records in {}seconds", totalRowsUpdated,
					stopWatch.getTime(TimeUnit.SECONDS));

		} catch (Exception e) {
			
			log.error("{} Exception while executing SuspectAggregation job : {}",
					ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), e);
			jobStatus.setStatus(Status.FAILURE);
			jobStatus.setMessage("SuspectAggregation job execution failed : " + e.getMessage());
			jobStatus.setUpdatedRows(0L);
		} finally {
			MDC.clear();
		}
		return jobStatus;
	}

	public Long batchUpdate(List<PaAggregationData> paSuspectAggregationList) {
		
		MutableLong updateCount= new MutableLong();
		
		if (null != paSuspectAggregationList) {
			
			IntStream.range(0, (paSuspectAggregationList.size() + UPSERT_BATCH_SIZE - 1) / UPSERT_BATCH_SIZE)
					.mapToObj(i -> paSuspectAggregationList.subList(i * UPSERT_BATCH_SIZE,
							Math.min(paSuspectAggregationList.size(), (i + 1) * UPSERT_BATCH_SIZE)))
					.forEach(batch -> {
                        Integer count = this.paLandingPageRepository.upserSuspectAggregation(batch);
						updateCount.add(count);
						

					});
		}
	
		return updateCount.longValue();
	}
	
	private List<PaAggregationData> fetchAggregationData(JobEvent jobEvent, String joblastrunsuccessfuldate,String jobStartTime, int offset) {
			
		List<PaAggregationData> paSuspectAggregationList= this.paLandingPageRepository
				.getPaSuspectAggregateDataByBatch(jobEvent.getProgramYear(), joblastrunsuccessfuldate,jobStartTime, offset,FETCH_BATCH_SIZE);
		
		return paSuspectAggregationList;
	}
	
	private List<Integer> getBatches(Long totalRows) {
		List<Integer> batches = new ArrayList<>();
		if (totalRows > 0) {
			for (int batchOffset = 0; batchOffset < totalRows; batchOffset += FETCH_BATCH_SIZE) {
				batches.add(batchOffset);
			}
		}
		return batches;
	}

}
