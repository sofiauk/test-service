package com.optum.rqns.ftm.service.jobalerts;

import org.springframework.stereotype.Service;

@Service
public interface MonitoringJobService {
    void monitorJobs();
}
