package com.optum.rqns.ftm.repository.fieldactionrules;

import com.optum.rqns.ftm.enums.RuleEnum;
import com.optum.rqns.ftm.model.fieldactionrules.ReturnTargetTrackingAction;
import com.optum.rqns.ftm.model.fieldactionrules.RuleAction;
import com.optum.rqns.ftm.util.ProgramPerformanceJobUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@Repository
@Slf4j
public class ReturnTargetTrackingRepoImpl implements ReturnTargetTrackingRepo {


    @Autowired
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    //private static final String PROVIDE_GROUP_RECORD_COUNT_QUERY = "SELECT COUNT(*) as recCount FROM ProgPerf.ProviderGroupPerformanceIDMGlidePath with(nolock) ";

    private static final String RETURN_TARGET_FETCH_QUERY = "with assignedProvGroups as (" +
            "            select" +
            "            distinct a.GroupId as pgGrpId," +
            "            a.State," +
            "            AO.OwnerUUID" +
            "            from" +
            "            ProgPerf.Accounts a WITH (NOLOCK)" +
            "            join ProgPerf.AccountOwner AO WITH (NOLOCK) on" +
            "            AO.AccountId = a.AccountId" +
            "            and ao.OwnerType in (" +
            "            'Secondary HSC','BSC Primary CQC','HCA','PSC','Primary HSC')" +
            "            WHERE AO.OwnerUUID IS NOT NULL " +
            "            and AO.OwnerUUID <> '' )" +
            "            select" +
            "            PerformanceDetails.*" +
            "            from" +
            "            (" +
            "            select" +
            "            sum(ReturnedNetCNAYTDActual) as ReturnedNetCNAYTDActual ," +
            "            sum(ReturnYTDTarget) as ReturnYTDTarget," +
            "            assignedProvGroups.OwnerUUID" +
            "            from" +
            "            ProgPerf.ProviderGroupPerformance p WITH (NOLOCK)" +
            "            join assignedProvGroups on" +
            "            p.ProviderGroupID = assignedProvGroups.pgGrpId" +
            "            and p.state = assignedProvGroups.state" +
            "            and p.ServiceLevel = 'ALL'" +
            "            where" +
            "            ClientName = 'ALL'" +
            "            and ProgramYear = (select value from ProgPerf.MasterConfiguration mc with(nolock) where code ='CurrentProgramYear')" +
            "            and isCurrentWeekForPerformance = 1" +
            "            group by" +
            "            OwnerUUID ) as PerformanceDetails";




   /* @Override
    public Long fetchRecordCount() {
        String query=String.format(PROVIDE_GROUP_RECORD_COUNT_QUERY);
        return namedParameterJdbcTemplate.queryForObject(query, new HashMap<>(), Long.class);
    }*/

    @Override
    public List<RuleAction> fetchReturnTargetInfo() {
        log.info("Fetching Eligible data for ReturnTrackingRule :{} ", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
        return namedParameterJdbcTemplate.query(RETURN_TARGET_FETCH_QUERY, new ReturnTargetTrackingRowMapper());
    }

    public static class ReturnTargetTrackingRowMapper implements RowMapper<RuleAction>{

        @Override
        public RuleAction mapRow(ResultSet rs, int rowNum) throws SQLException {
            List<String> userList=new ArrayList<>();
            StringBuilder ruleResult=new StringBuilder();
            ReturnTargetTrackingAction targetTrackingRuleAction =new ReturnTargetTrackingAction();
            targetTrackingRuleAction.setReturnCNA(rs.getDouble("ReturnedNetCnaYtdActual"));
            targetTrackingRuleAction.setReturnTarget(rs.getDouble("ReturnYTDTarget"));
            targetTrackingRuleAction.setRuleType(RuleEnum.RETURN_TARGET_TRACKING_RULE.getValue());
            userList.add(rs.getString("OwnerUUID"));
            targetTrackingRuleAction.setUserUuid(userList);

            return targetTrackingRuleAction;
        }
    }


}
