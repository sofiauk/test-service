package com.optum.rqns.ftm.service.opamigration;

import com.optum.rqns.ftm.service.IJob;
import org.springframework.stereotype.Service;

@Service
public interface OPAMigrationService extends IJob {
}
