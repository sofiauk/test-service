package com.optum.rqns.ftm.exception;

import lombok.Getter;
import org.springframework.http.HttpStatus;

@Getter
public class FieldActionRulesException extends RuntimeException {
    private static final long serialVersionUID = 1905122041950251207L;

    private final String errorMessage;
    private final String errorDetails;
    private final String jobName;
    
    public FieldActionRulesException(String message, String details, String jobName) {
        super(details);
        this.errorMessage = message;
        this.errorDetails = details;
        this.jobName = jobName;
    }

}