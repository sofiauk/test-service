package com.optum.rqns.ftm.repository.fieldactionrules;

import com.optum.rqns.ftm.enums.RuleEnum;
import com.optum.rqns.ftm.model.fieldactionrules.AvailMembershipClientLobStateAction;
import com.optum.rqns.ftm.model.fieldactionrules.RuleAction;
import com.optum.rqns.ftm.util.ProgramPerformanceJobUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Repository
@Slf4j
public class AvailMembershipClientLobStateRepoImpl implements AvailMembershipClientLobStateRepo {

    @Autowired
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    private static final String AVAILABLE_MEMBERSHIP_CLIENTLOBSTATE_COUNT_QUERY = "WITH pubEligibleMember AS ( " +
            "select " +
            "       COUNT(DeployableCurrentYear) as deployableCurrentYear, " +
            "       cgp.Client, " +
            "       cgp.State , " +
            "       cgp.LobDesc " +
            "from " +
            "       ProgPerf.ClientGoalsPublished cgp with(nolock) " +
            "group by " +
            "       cgp.Client , " +
            "       cgp.State , " +
            "       cgp.LobDesc ) " +
            "        " +
            "       SELECT " +
            "       Count(1) as totalRecCount from ( " +
            "SELECT " +
            "       PA.ProviderState, " +
            "       PA.ClientId, " +
            "       PA.LobName, " +
            "       PA.ClientName , " +
            "       COUNT(CASE WHEN (PA.IsProviderAssociated <> 'No' OR PA.IsProviderAssociated IS NULL) THEN 1 END) AS pafxEligibleMemberCount, " +
            "       pub.deployableCurrentYear as publishedEligibleMemberCount, " +
            "       cpg.UUID  " +
            "FROM " +
            "       ProgPerf.PafExMemberAssessment PA WITH (NOLOCK) " +
            "INNER JOIN pubEligibleMember pub ON " +
            "       pub.Client = PA.ClientId " +
            "       AND UPPER(pub.LobDesc)= UPPER(PA.LobName) " +
            "       AND pub.State = PA.ProviderState " +
            "INNER JOIN ProgPerf.CpdClientMapping cpg ON " +
            "       cpg.Client =PA.ClientName  " +
            "WHERE " +
            "       PA.IsSuppressed = 'N' " +
            "       AND UPPER(PA.RecordStatus) <> 'DELETED' " +
            "       AND LEN(PA.ProviderState) > 0 " +
            "       AND LEN(PA.LobName) > 0 " +
            "       AND LEN(PA.ProgramYear) > 0 " +
            "       AND PA.ProgramYear in ( " +
            "       select " +
            "             value " +
            "       from " +
            "             ProgPerf.MasterConfiguration mc " +
            "       where " +
            "             code in('CurrentProgramYear')) " +
            "GROUP BY " +
            "       PA.ProviderState, " +
            "       PA.ClientId, " +
            "       PA.ClientName, " +
            "       PA.LobName, " +
            "       deployableCurrentYear, " +
            "       cpg.UUID) as FullDataSet";


    private static final String AVAILABLE_MEMBERSHIP_CLIENTLOBSTATE_DATA_QUERY = "WITH pubEligibleMember AS (  " +
            "select  " +
            "       COUNT(DeployableCurrentYear) as deployableCurrentYear,  " +
            "       cgp.Client,  " +
            "       cgp.State ,  " +
            "       cgp.LobDesc  " +
            "from  " +
            "       ProgPerf.ClientGoalsPublished cgp with(nolock)  " +
            "group by  " +
            "       cgp.Client ,  " +
            "       cgp.State ,  " +
            "       cgp.LobDesc )  " +
            "SELECT  " +
            "       PA.ProviderState,  " +
            "       PA.LobName,  " +
            "       PA.ClientName ,  " +
            "       COUNT(CASE WHEN (PA.IsProviderAssociated <> 'No' OR PA.IsProviderAssociated IS NULL) THEN 1 END) AS pafxEligibleMemberCount,  " +
            "       pub.deployableCurrentYear as publishedEligibleMemberCount,  " +
            "       cpg.UUID   " +
            "FROM  " +
            "       ProgPerf.PafExMemberAssessment PA WITH (NOLOCK)  " +
            "INNER JOIN pubEligibleMember pub ON  " +
            "       pub.Client = PA.ClientId  " +
            "       AND UPPER(pub.LobDesc)= UPPER(PA.LobName)  " +
            "       AND pub.State = PA.ProviderState  " +
            "INNER JOIN ProgPerf.CpdClientMapping cpg ON  " +
            "       cpg.Client =PA.ClientName   " +
            " AND cpg.UUID IS NOT NULL and cpg.UUID <> '' "+
            "WHERE  " +
            "       PA.IsSuppressed = 'N'  " +
            "       AND UPPER(PA.RecordStatus) <> 'DELETED'  " +
            "       AND LEN(PA.ProviderState) > 0  " +
            "       AND LEN(PA.LobName) > 0  " +
            "       AND LEN(PA.ProgramYear) > 0  " +
            "       AND PA.ProgramYear in (  " +
            "       select  " +
            "             value  " +
            "       from  " +
            "             ProgPerf.MasterConfiguration mc  " +
            "       where  " +
            "             code in('CurrentProgramYear'))  " +
            "GROUP BY  " +
            "       PA.ProviderState,  " +
            "       PA.ClientName,  " +
            "       PA.LobName,  " +
            "       deployableCurrentYear,  " +
            "       cpg.UUID   " +
            " ORDER BY    " +
            "   PA.ProviderState, " +
            "       PA.ClientName,   " +
            "       PA.LobName,   " +
            "       deployableCurrentYear,   " +
            "       cpg.UUID   " +
            "  OFFSET :begin ROWS FETCH NEXT :end ROWS ONLY; ";


    @Override
    public List<Integer> getRowCountAndBatchesForAvailMembershipClientLobState(int batchSize) {
        log.info("Fetching  Total count for Available membership clientlobstate at Group Level :{} ", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
        Integer totalRows = namedParameterJdbcTemplate.queryForObject(AVAILABLE_MEMBERSHIP_CLIENTLOBSTATE_COUNT_QUERY, new HashMap<>(), Integer.class);
        log.info("Total count for Available membership clientlobstate at Group Level :{} ", totalRows);
        List<Integer> batches = new ArrayList<>();
        if (totalRows != null && totalRows > 0) {
            for (int batchOffset = 0; batchOffset <= totalRows; batchOffset += batchSize) {
                batches.add(batchOffset);
            }
        }
        return batches;
    }

    @Override
    public List<RuleAction> fetchAvailMembershipClientLobStateInfo(Integer beginIndex, int batchSize) {
        log.info("Fetching  Available membership clientlobstate combination to sendAction for  Available membership clientlobstate at Group Level :{} ", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
        Map<String, Object> bindingMap = new HashMap<>();
        bindingMap.put("begin", beginIndex);
        bindingMap.put("end", batchSize);
        return namedParameterJdbcTemplate.query(AVAILABLE_MEMBERSHIP_CLIENTLOBSTATE_DATA_QUERY, bindingMap, new AvailableMembershipClientLobStateRowMapper());
    }

    public static class AvailableMembershipClientLobStateRowMapper implements RowMapper<RuleAction> {

        @Override
        public RuleAction mapRow(ResultSet rs, int rowNum) throws SQLException {
            List<String> userList = new ArrayList<>();

            AvailMembershipClientLobStateAction availMembershipClientLobStateAction = new AvailMembershipClientLobStateAction();
            availMembershipClientLobStateAction.setClient(rs.getString("ClientName"));
            availMembershipClientLobStateAction.setLob(rs.getString("LobName"));
            availMembershipClientLobStateAction.setState(rs.getString("ProviderState"));
            userList.add(rs.getString("UUID"));
            availMembershipClientLobStateAction.setUserUuid(userList);
            availMembershipClientLobStateAction.setRuleType(RuleEnum.AVAIL_MEMBERSHIP_CLIENT_LOB_STATE.getValue());
            availMembershipClientLobStateAction.setPafxEligibleMemberCount(rs.getLong("pafxEligibleMemberCount"));
            availMembershipClientLobStateAction.setPublishedEligibleMemberCount(rs.getLong("publishedEligibleMemberCount"));

            return availMembershipClientLobStateAction;
        }
    }
}

