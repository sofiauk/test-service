package com.optum.rqns.ftm.repository.clientgoals;


import com.optum.rqns.ftm.model.clientgoals.ClientGoalsData;

import java.util.List;

public interface ClientGoalsRepository {

    Long getRecordCount(int programYear);

    List<ClientGoalsData> getClientGoals(int batchSize, Integer batchOffset, int programYear);

}
