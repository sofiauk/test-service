package com.optum.rqns.ftm.kafka.consumer;

import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.repository.common.CommonRepositoryImpl;
import com.optum.rqns.ftm.service.clientgoals.ClientGoalsServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.context.annotation.Profile;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.annotation.TopicPartition;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

@Profile("newProviderGroupRule")
@Component
@Slf4j
public class ClientGoalsConsumer extends JobEventConsumer {

    public ClientGoalsConsumer(final ClientGoalsServiceImpl clientGoalsService, final CommonRepositoryImpl commonRepository) {
        super(clientGoalsService, commonRepository);
    }

    @KafkaListener(topicPartitions = {@TopicPartition(topic = "${spring.gcpkafka.properties.topics.jobEvent}", partitions = {"35"})},
            containerFactory = "jobEventKafkaListenerContainerFactory", autoStartup = "true")
    public void onMessage(ConsumerRecord<String, JobEvent> record, Acknowledgment acknowledgment) {
        log.info("{} Begin Consumer ClientGoals: {}", super.generateTransactionId (record), record);
        processMessage(35, record, acknowledgment);
    }
}
