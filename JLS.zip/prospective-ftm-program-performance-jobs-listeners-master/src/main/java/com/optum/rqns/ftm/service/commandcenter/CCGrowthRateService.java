package com.optum.rqns.ftm.service.commandcenter;

import com.optum.rqns.ftm.service.IJob;

public interface CCGrowthRateService  extends IJob {
}
