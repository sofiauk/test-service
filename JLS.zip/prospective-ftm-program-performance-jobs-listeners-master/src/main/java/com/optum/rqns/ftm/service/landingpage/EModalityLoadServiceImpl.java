package com.optum.rqns.ftm.service.landingpage;

import com.fasterxml.uuid.Generators;
import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.repository.landingpage.LeaderPerformanceRepository;
import com.optum.rqns.ftm.util.ProgramPerformanceJobUtil;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class EModalityLoadServiceImpl implements EModalityLoadService {
    @Autowired
    LeaderPerformanceRepository leaderPerformanceRepository;
    @Override
    public JobStatus executeJob(JobEvent jobEvent) {
        MDC.put(Constants.TRACE_ID, Generators.timeBasedGenerator().generate().toString());
        MDC.put(Constants.TRANSACTION_ID, ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
        MDC.put(Constants.MESSAGE_ID, ProgramPerformanceJobUtil.TransactionIdLogger.getMessageIdIdentifier());

        log.info("jobEvent.RunWeeklyEModalityLoad() :: {}", jobEvent.getJobName());
        JobStatus jobStatus = new JobStatus();

        try {
            long totalUpdatedRecords=0;
            log.info("Received RunWeeklyEModalityLoad job message from topic : {}", jobEvent.getJobName());
            totalUpdatedRecords = this.leaderPerformanceRepository
                    .loadDataToEModalityFromMemberAssessments(jobEvent.getProgramYear());
            log.info("total updated record count {}", totalUpdatedRecords);


            jobStatus.setStatus(Status.SUCCESS);
            jobStatus.setMessage("Completed RunCommandCenterJob job successfully, total updated record count "+totalUpdatedRecords);
            jobStatus.setUpdatedRows(totalUpdatedRecords);

        } catch (Exception e) {
            log.error("Exception while executing RunCommandCenterJob job : ", e);
            jobStatus.setStatus(Status.FAILURE);
            jobStatus.setMessage("RunCommandCenterJob job execution failed : " + e.getMessage());
            jobStatus.setUpdatedRows(0L);
        } finally{

            MDC.clear();
        }
        return jobStatus;
    }
}
