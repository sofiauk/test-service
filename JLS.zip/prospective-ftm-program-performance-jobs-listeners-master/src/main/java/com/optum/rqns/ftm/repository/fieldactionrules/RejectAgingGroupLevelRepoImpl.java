package com.optum.rqns.ftm.repository.fieldactionrules;

import com.optum.rqns.ftm.enums.RuleEnum;
import com.optum.rqns.ftm.model.fieldactionrules.RejectAgingGroupLevelAction;
import com.optum.rqns.ftm.model.fieldactionrules.RuleAction;
import com.optum.rqns.ftm.util.ProgramPerformanceJobUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
@Slf4j
public class RejectAgingGroupLevelRepoImpl implements RejectAgingGroupLevelRepo{

    @Autowired
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    private static final String REJECT_RAGING_GROUP_COUNT_QUERY = "  WITH assignedProvGroups AS (" +
            "SELECT" +
            "  DISTINCT a.GroupId AS pgGrpId ," +
            "  a.STATE ," +
            "  AO.OwnerUUID ," +
            "  AO.AccountId" +
            " FROM" +
            "  ProgPerf.Accounts a WITH (NOLOCK)" +
            " INNER JOIN ProgPerf.AccountOwner AO WITH (NOLOCK) ON" +
            "  AO.AccountId = a.AccountId" +
            "  AND ( ( a.ServiceLevel = 'HCA' AND AO.OwnerType IN('Secondary HSC', 'BSC Primary CQC', 'HCA','Primary HSC'))" +
            "  OR ( a.ServiceLevel IN ('PSC-P'," +
            "  'PSC-B')" +
            "  AND AO.OwnerType = 'PSC' ) )" +
            " WHERE" +
            "  AO.OwnerUUID IS NOT NULL" +
            "  and AO.OwnerUUID <> '') ," +
            " aggergatedAssignedProvGroups AS (" +
            " SELECT" +
            "  DISTINCT pgGrpId ," +
            "  STATE ," +
            "  AccountId ," +
            "  aggregatedOwnerIds = stuff((" +
            "  SELECT" +
            "    ', ' + apg.OwnerUUID AS [text()]" +
            "  FROM" +
            "    assignedProvGroups apg" +
            "  WHERE" +
            "    apg.AccountId = assignedPG.AccountId FOR XML path('') )," +
            "  1," +
            "  1," +
            "  '')" +
            " FROM" +
            "  assignedProvGroups AS assignedPG )" +
            " SELECT" +
            "  Count(1) as totalRecCount" +
            " from" +
            "  (" +
            "  SELECT" +
            "    DISTINCT ma.prov_group_id ," +
            "    ma.prov_group_name ," +
            "    ma.providerstate ," +
            "    prvGrp.aggregatedOwnerIds ," +
            "    prvGrp.AccountId" +
            "  FROM" +
            "    ProgPerf.MemberAssessment ma WITH (NOLOCK)" +
            "  INNER JOIN aggergatedAssignedProvGroups prvGrp ON" +
            "    ma.prov_group_id = prvGrp.pgGrpId" +
            "    AND ma.providerstate = prvGrp.STATE" +
            "    AND ma.overall_status = 'Rejected'" +
            "    AND ma.deriveddeployed = '1'" +
            "    AND ma.singlerejectdate IS NOT NULL" +
            "    AND UPPER(ma.RecordChangeType) <> 'DELETED'" +
            "  WHERE" +
            "    ma.project_year in (" +
            "    select" +
            "      value" +
            "    from" +
            "      ProgPerf.MasterConfiguration mc" +
            "    where" +
            "      code in('CurrentProgramYear'))) AS FullDataSet"    ;

    private static final String REJECT_RAGING_GROUP_LEVEL_QUERY = "    WITH assignedProvGroups AS ("  +
            " SELECT "  +
            "  DISTINCT a.GroupId AS pgGrpId , "  +
            "  a.STATE , "  +
            "  AO.OwnerUUID , "  +
            "  AO.AccountId "  +
            " FROM "  +
            "  ProgPerf.Accounts a WITH (NOLOCK) "  +
            " INNER JOIN ProgPerf.AccountOwner AO WITH (NOLOCK) ON "  +
            "  AO.AccountId = a.AccountId "  +
            "  AND ( ( a.ServiceLevel = 'HCA' AND AO.OwnerType IN('Secondary HSC', 'BSC Primary CQC', 'HCA','Primary HSC')) "  +
            "  OR ( a.ServiceLevel IN ('PSC-P', "  +
            "  'PSC-B') "  +
            "  AND AO.OwnerType = 'PSC' ) ) "  +
            " WHERE "  +
            "  AO.OwnerUUID IS NOT NULL and AO.OwnerUUID <> '') , "  +
            " aggergatedAssignedProvGroups AS ( "  +
            " SELECT "  +
            "  DISTINCT pgGrpId , "  +
            "  STATE , "  +
            "  AccountId , "  +
            "  aggregatedOwnerIds = stuff(( "  +
            "  SELECT "  +
            "   ',' + apg.OwnerUUID AS [text()] "  +
            "  FROM "  +
            "   assignedProvGroups apg "  +
            "  WHERE "  +
            "   apg.AccountId = assignedPG.AccountId FOR XML path('') ), "  +
            "  1, "  +
            "  1, "  +
            "  '') "  +
            " FROM "  +
            "  assignedProvGroups AS assignedPG ) "  +
            " SELECT "  +
            "  DISTINCT ma.prov_group_id , "  +
            "  ma.prov_group_name , "  +
            "  ma.providerstate , "  +
            "  min(ma.singlerejectdate) as singlerejectdate, "  +
            "  DATEDIFF(DAY, "  +
            "  min(ma.singlerejectdate) , "  +
            "  GETUTCDATE()) AS singleRejectDaysCount, "  +
            "  prvGrp.aggregatedOwnerIds , "  +
            "  prvGrp.AccountId "  +
            " FROM "  +
            "  ProgPerf.MemberAssessment ma WITH (NOLOCK) "  +
            " INNER JOIN aggergatedAssignedProvGroups prvGrp ON "  +
            "  ma.prov_group_id = prvGrp.pgGrpId "  +
            "  AND ma.providerstate = prvGrp.STATE "  +
            "  AND ma.overall_status = 'Rejected' "  +
            "  AND ma.deriveddeployed = '1' "  +
            "  AND ma.singlerejectdate is not null "  +
            "  AND UPPER(ma.RecordChangeType) <> 'DELETED'" +
            " WHERE "  +
            "  ma.project_year in ( "  +
            " select value from ProgPerf.MasterConfiguration mc where code in('CurrentProgramYear')) "  +
            " GROUP BY "  +
            "  ma.prov_group_id , "  +
            "  ma.prov_group_name , "  +
            "  ma.providerstate , "  +
            "  prvGrp.aggregatedOwnerIds , "  +
            "  prvGrp.AccountId "  +
            " ORDER BY "  +
            "  ma.prov_group_id , "  +
            "  ma.prov_group_name , "  +
            "  ma.providerstate , "  +
            "  prvGrp.aggregatedOwnerIds , "  +
            "  prvGrp.AccountId " +
            "  OFFSET :begin ROWS FETCH NEXT :end ROWS ONLY; "    ;



    @Override
    public List<Integer> getRowCountAndBatchesForReturnAging(int batchSize) {
        log.info("Fetching  Total count for Reject Aging at Group Level :{} ",ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
        Integer totalRows =   namedParameterJdbcTemplate.queryForObject(REJECT_RAGING_GROUP_COUNT_QUERY, new HashMap<>(), Integer.class);
        log.info("Total count for Reject Aging at Group Level :{} ",totalRows);
        List<Integer> batches = new ArrayList<>();
        if (totalRows!=null && totalRows > 0) {
            for (int batchOffset = 0; batchOffset <= totalRows; batchOffset += batchSize) {
                batches.add(batchOffset);
            }
        }
        return batches;
    }

    @Override
    public List<RuleAction> fetchRejectAgingInfo(Integer beginIndex,int batchSize) {
        log.info("Fetching Eligible provider&state combination to sendAction for Reject Aging at Group Level :{} ",ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
        Map<String, Object> bindingMap = new HashMap<>();
        bindingMap.put("begin",beginIndex);
        bindingMap.put("end",batchSize);
        return namedParameterJdbcTemplate.query(REJECT_RAGING_GROUP_LEVEL_QUERY, bindingMap,new RejectAgingTrackingRowMapper());
    }

    public static class RejectAgingTrackingRowMapper implements RowMapper<RuleAction> {

        @Override
        public RuleAction mapRow(ResultSet rs, int rowNum) throws SQLException {
            List<String> userList=new ArrayList<>();
            String[] userArray=null;
            RejectAgingGroupLevelAction rejectRagingGroupLevel =new RejectAgingGroupLevelAction();
            rejectRagingGroupLevel.setProviderGroupId(rs.getString("prov_group_id"));
            rejectRagingGroupLevel.setProviderGroupName(rs.getString("prov_group_name"));
            rejectRagingGroupLevel.setProviderState(rs.getString("providerstate"));
            userArray=(rs.getString("aggregatedOwnerIds").split(","));
            for(String user:userArray){
                userList.add(user);
            }
            rejectRagingGroupLevel.setUserUuid(userList);
            rejectRagingGroupLevel.setAccountId(rs.getString("AccountId"));
            rejectRagingGroupLevel.setRuleType(RuleEnum.REJECT_AGING_RULE.getValue());
            rejectRagingGroupLevel.setSingleRejectDaysCount(rs.getInt("singleRejectDaysCount"));
            return rejectRagingGroupLevel;
        }
    }
}
