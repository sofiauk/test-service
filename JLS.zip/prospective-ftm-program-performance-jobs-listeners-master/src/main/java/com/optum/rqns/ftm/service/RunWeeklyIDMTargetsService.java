package com.optum.rqns.ftm.service;

public interface RunWeeklyIDMTargetsService extends IJob {
}
