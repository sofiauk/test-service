package com.optum.rqns.ftm.service.opportunities.qfo;

import com.optum.rqns.ftm.opportunities.common.service.ppt.MemberGapsAnnualCareVisitsOpportunitiesServiceImpl;
import com.optum.rqns.ftm.opportunities.common.service.qfo.QfoMemberGapsAnnualCareVisitsOpportunitiesServiceImpl;
import com.optum.rqns.ftm.service.opportunities.OpportunitiesService;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

// added memberGapJobs profile so that beans from common library will be restricted to memberGapJobs profile
@Service
@Profile("memberGapJobs")
public class QFOAnnualCareOpportunitiesServiceImpl extends QFOOpportunitiesService {

    private QfoMemberGapsAnnualCareVisitsOpportunitiesServiceImpl annualCareService;

    public QFOAnnualCareOpportunitiesServiceImpl(QfoMemberGapsAnnualCareVisitsOpportunitiesServiceImpl annualCareService) {
        setBatchingRequired(false);
        qfoMemberGapsService = annualCareService;
    }
}




