package com.optum.rqns.ftm.service.opportunities.qfo;

import com.fasterxml.uuid.Generators;
import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.opportunities.common.service.qfo.QfoMemberGapsAnnualCareVisitsOpportunitiesServiceImpl;
import com.optum.rqns.ftm.opportunities.common.service.qfo.QfoMemberGapsCommonOpportunitiesService;
import com.optum.rqns.ftm.opportunities.common.service.qfo.QfoMemberGapsQualityServiceImpl;
import com.optum.rqns.ftm.opportunities.common.service.qfo.QfoMemberGapsSuspectOpportunitiesServiceImpl;
import com.optum.rqns.ftm.repository.opportunities.OpportunitiesCommonRepositoryImpl;
import com.optum.rqns.ftm.service.IJob;
import com.optum.rqns.ftm.util.ProgramPerformanceJobUtil;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Slf4j
@Service
public abstract class QFOOpportunitiesService implements IJob {

    protected QfoMemberGapsCommonOpportunitiesService qfoMemberGapsService;

    @Autowired
    protected QfoMemberGapsQualityServiceImpl memberGapsQualityService;

    @Autowired
    protected QfoMemberGapsSuspectOpportunitiesServiceImpl memberGapsSuspectOpportunitiesService;

    @Autowired
    protected QfoMemberGapsAnnualCareVisitsOpportunitiesServiceImpl memberGapsAnnualCareVisitsOpportunitiesService;

    @Autowired
    protected OpportunitiesCommonRepositoryImpl opportunitiesCommonRepository;

    private boolean isBatchingRequired = true;

    public void setBatchingRequired(boolean isBatchingRequired) {
        this.isBatchingRequired = isBatchingRequired;
    }

    public JobStatus executeJob(JobEvent jobEvent) {

        MDC.put(Constants.TRACE_ID, Generators.timeBasedGenerator().generate().toString());
        MDC.put(Constants.TRANSACTION_ID, ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
        MDC.put(Constants.MESSAGE_ID, ProgramPerformanceJobUtil.TransactionIdLogger.getMessageIdIdentifier());

        JobStatus jobStatus = new JobStatus();
        try {
            String lastUpdatedDate = null;
            long detailedCount = 0;

            if (Constants.MODIFIED.equalsIgnoreCase(jobEvent.getGroupsToExecute().toString())) {
                lastUpdatedDate = opportunitiesCommonRepository.fetchLastRunDate(jobEvent.getJobName().toString());
                log.info("QFO {} last updated date :: {}", jobEvent.getJobName().toString(), lastUpdatedDate);
            }

            detailedCount = qfoMemberGapsService.aggregateMemberGaps(Optional.empty(), lastUpdatedDate,isBatchingRequired,jobEvent.getGroupsToExecute().toString());

            
            jobStatus.setStatus(Status.SUCCESS);
            jobStatus.setMessage("QFO Completed Job successfully Job Name is {}" + jobEvent.getJobName().toString());
            jobStatus.setUpdatedRows(detailedCount);
            log.info("QFO Completed the Job Successfully:{}", jobEvent.getJobName());

        } catch (Exception e) {
            log.error("QFO Exception while executing job : {}{}", (jobEvent.getJobName().toString()), e);
            jobStatus.setStatus(Status.FAILURE);
            jobStatus.setMessage("QFO Execution is failed for job::" + jobEvent.getJobName().toString());
            jobStatus.setUpdatedRows(0L);
        } finally {
            MDC.clear();
        }
        return jobStatus;
    }

}
