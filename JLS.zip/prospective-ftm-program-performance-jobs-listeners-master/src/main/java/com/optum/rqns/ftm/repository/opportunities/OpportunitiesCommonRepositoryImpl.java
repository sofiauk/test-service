package com.optum.rqns.ftm.repository.opportunities;

import com.optum.rqns.ftm.util.ProgramPerformanceJobUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.Map;

@Slf4j
@Repository
@Primary
public class OpportunitiesCommonRepositoryImpl {

	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	public static final String MASTEROPPORTUNITY = "MASTEROPPORTUNITY";

	private static final String LASTSUCCESSFULRUNDATE_QUERY = "SELECT  " +
			"  TOP 1 CONVERT(varchar,  " +
			"  jeh.JobStart ,  " +
			"  20) AS LastSuccessfulRunDate  " +
			"FROM  " +
			"  ProgPerf.JobExecutionHistory jeh  " +
			"WHERE  " +
			"  jobid = (  " +
			"  SELECT  " +
			"    TOP 1 id  " +
			"  FROM  " +
			"    ProgPerf.JobRunConfiguration jrc  " +
			"  WHERE  " +
			"    JobName = :MASTEROPPORTUNITY )  " +
			"  AND Status = 'Success'  " +
			"ORDER BY  " +
			"  id DESC";

	public String fetchLastRunDate(String masterOpportunityName) {
		log.info("{} : Fetching last job run date from JobRunConfiguration table for Opportunity :{} ",
				ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), masterOpportunityName);
		Map<String, Object> bindingMap = new HashMap<>();
		bindingMap.put(MASTEROPPORTUNITY, masterOpportunityName);

		return namedParameterJdbcTemplate.query(LASTSUCCESSFULRUNDATE_QUERY, bindingMap, rs -> {
			String result = rs.next() ? rs.getString("LastSuccessfulRunDate") : "1900-01-01 00:00:00";
			return result;
		});
	}

}
