package com.optum.rqns.ftm.service.jobalerts;

import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.model.JobAlert;
import com.optum.rqns.ftm.util.ProgramPerformanceJobUtil;
import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Tag;
import io.micrometer.core.instrument.Tags;
import io.micrometer.core.instrument.search.MeterNotFoundException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
@Slf4j
public class PrometheusJobAlertServiceImpl implements PrometheusJobAlertService {
    @Autowired
    private MeterRegistry meterRegistry;

    public String sendAlerts(JobAlert jobAlert) {

        log.info("----Starting the Prometheus alerting manager service---");
        try {
            Gauge.builder("ftm_kafka_job_status", jobAlert.getStatus(), t -> {
                        final Status status = Status.fromString(t);
                        if (status == null) {
                            return 0;
                        }
                        switch (status) {
                            case SUCCESS:
                                return 1;
                            case IN_PROGRESS:
                                return 2;
                            default:
                                return 0;
                        }
                    }
            )
                    .tags(getJobIdTag(jobAlert))
                    .description("Job Status")
                    .register(meterRegistry);
            log.info("Registered Meter Registry Successfully :{}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
            return "SUCCESS";

        } catch (MeterNotFoundException e) {
            log.error("Exception occurred during registering meter registry", e);
            return "FAILURE";
        }
    }

    private Iterable<Tag> getJobIdTag(JobAlert jobAlert) throws MeterNotFoundException {

        log.info("Process started for adding tags to the alerts :{} ", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());


        return Tags.of(
                Tag.of("JobId", String.valueOf(jobAlert.getId())),
                Tag.of("JobExecutionHistoryId", jobAlert.getJobExecutionHistoryId() == null ? " " : String.valueOf(jobAlert.getJobExecutionHistoryId())),
                Tag.of("FTM_Job_Alert_Time", LocalDateTime.now().toString()),
                Tag.of("JobName", jobAlert.getJobName()),
                Tag.of("JobStatus", jobAlert.getStatus()),
                Tag.of("JobDescription", jobAlert.getJobDescription()),
                Tag.of("ModifiedDate", jobAlert.getModifiedDate().toString()),
                Tag.of("LastrunDate", jobAlert.getLastRunDate().toString()),
                Tag.of("CreatedDate", jobAlert.getCreatedDate().toString()),
                Tag.of("JobStartDate", jobAlert.getJobStart().toString()),
                Tag.of("JobEndDate", jobAlert.getJobEnd() == null ? " " : jobAlert.getJobEnd().toString()),
                Tag.of("LastSuccessfulRundate", jobAlert.getLastSuccessfulRunDate().toString()),
                Tag.of("Createdby", jobAlert.getCreatedBy()),
                Tag.of("Modifiedby", jobAlert.getModifiedBy()),
                Tag.of("ErrorMessage", jobAlert.getErrorMessage()),
                Tag.of("AffectedRows", String.valueOf(jobAlert.getAffectedRows())),
                Tag.of("JobEvent", jobAlert.getJobEvent()),
                Tag.of("MessageKey", jobAlert.getMessageKey()),
                Tag.of("Message", jobAlert.getMessage()),
                Tag.of("isActive", String.valueOf(jobAlert.isActive()))
        );

    }
}
