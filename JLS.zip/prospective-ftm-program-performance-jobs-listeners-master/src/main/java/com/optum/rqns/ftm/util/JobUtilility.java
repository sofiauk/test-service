package com.optum.rqns.ftm.util;

import com.optum.rqns.ftm.constants.Constants;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

@Slf4j
public final class JobUtilility {

    public JobUtilility() {
        // Default JobUtilility constructor
    }

    @SneakyThrows
    public long executeQueries(ExecutorService executorService, List<Callable<Integer>> taskList) {
        long totalCount = 0;
        try {
            List<Future<Integer>> results = executorService.invokeAll(taskList);
            for (Future<Integer> f : results) {
                if (f != null && f.get() != null) {
                    totalCount += f.get();
                }
            }
        } catch (InterruptedException | ExecutionException e) {
            log.error("Error while  merging Idm data to performance table  ", e);
            throw e;
        } finally {
            taskList.clear();
            executorService.shutdown();
        }
        return totalCount;
    }

    public List<Integer> getBatches(Long totalRows) {
        List<Integer> batches = new ArrayList<>();
        if (totalRows > 0) {
            for (int batchOffset = 0; batchOffset <= totalRows; batchOffset += Constants.BATCH_SIZE) {
                batches.add(batchOffset);
            }
        }
        return batches;
    }

    /*
     *  To produce the messages parallelly to kafka ,this method is written
     * @param executorService,taskList
     * @return boolean
     */
    public Boolean producingElementsParallellyToTopic(ExecutorService executorService, List<Callable<Boolean>> taskList) {
        boolean iselementsProc = true;
        try {
            List<Future<Boolean>> results = executorService.invokeAll(taskList);
            for(Future<Boolean> f : results) {
                if(f != null && f.get()) {

                } else {
                    log.warn(" Future object not able to fetch::");
                }
            }

        } catch(Exception e) {
            iselementsProc = false;
            log.error("Error while  producing the elements Parallelly " + e);
        } finally {
            taskList.clear();
            executorService.shutdown();
        }
        return iselementsProc;
    }

    public static <T> Predicate<T> distinctByClientNames(Function<? super T, ?>... keyExtractors)
    {
        final Map<List<?>, Boolean> seen = new ConcurrentHashMap<>();
        return t ->
        {
            final List<?> keys = Arrays.stream(keyExtractors)
                    .map(ke -> ke.apply(t))
                    .collect(Collectors.toList());

            return seen.putIfAbsent(keys, Boolean.TRUE) == null;
        };
    }

}
