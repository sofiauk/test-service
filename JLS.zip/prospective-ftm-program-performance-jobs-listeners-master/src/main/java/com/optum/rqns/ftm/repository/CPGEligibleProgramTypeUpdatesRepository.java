package com.optum.rqns.ftm.repository;

import com.optum.rqns.ftm.model.providergroup.PAFXMemberData;
import com.optum.rqns.ftm.model.providergroup.ProviderGroup;

import java.util.List;
import java.util.Map;

public interface CPGEligibleProgramTypeUpdatesRepository {


    Long getRecordMemberAssessmentCount();

    Integer mergeMemberAssessmentData(int batchSize, Integer batchOffset, Integer programYear, String groupsToExecute, String joblastrunsuccessfuldate);

    Integer mergeMemberGapData(int batchSize, Integer offset, Integer programYear, String groupsToExecute, String joblastrunsuccessfuldate);

    List<PAFXMemberData> getPafxMembersProgramTypeBasedOnGroups(String providerGroupIds, Integer programYear);

    int[] updateBatchQueries(List<Map<String, Object>> batchValues);

    Long getPafxGroupsRecordCount(Integer programYear, String grousptoExecute, String joblastrunsuccessfuldate);

    List<ProviderGroup> getProviderGroupExtendedRecords(String providerGroupIds, Integer programYear);

    List<PAFXMemberData> getPafxProviderGroupIds(int batchSize, Integer offset, Integer programYear, String groupstoexecute, String joblastrunsuccessfuldate);

    Long getPafxMembersForCurrentProgramYearRecordCount(Integer programYear, String groupsToExecute, String joblastrunsuccessfuldate);

}
