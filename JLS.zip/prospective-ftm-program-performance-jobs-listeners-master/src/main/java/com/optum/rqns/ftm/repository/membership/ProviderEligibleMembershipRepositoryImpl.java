package com.optum.rqns.ftm.repository.membership;

import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.model.membership.ProviderEligibleMembershipFlatData;
import com.optum.rqns.ftm.util.ProgramPerformanceJobUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;

@Repository
@Slf4j
public class ProviderEligibleMembershipRepositoryImpl implements ProviderEligibleMembershipRepository {

    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    public ProviderEligibleMembershipRepositoryImpl(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
        this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
    }

    private static final String MODIFIED_CONDITION = " AND CAST(PafxMemberUpdatedDate as date) >= (select CAST(LastSuccessfulRunDate as date)" +
            " from ProgPerf.jobrunconfiguration where jobname= '" + JobName.RUN_PROVIDER_ELIGIBLE_MEMBERSHIP.getValue() + "')";

    private static final String FETCH_PROVIDER_MEMBERSHIP = "SELECT     " +
            "      ProviderGroupId,     " +
            "      ProviderId,     " +
            "      ProviderName,     " +
            "      ProviderState,     " +
            "      ProgramYear,     " +
            "      ClientId,     " +
            "      LobName,     " +
            "      ClientName,     " +
            "      count(*) as eligibleMemberCount      " +
            "FROM     " +
            "      ProgPerf.PafExMemberAssessment  WITH (NOLOCK)   " +
            "where     " +
            "      RecordStatus <> 'Deleted'     " +
            "      AND ProgramYear = (     " +
            "      SELECT     " +
            "            [value]     " +
            "      FROM     " +
            "            ProgPerf.MasterConfiguration  WITH (NOLOCK)     " +
            "      WHERE     " +
            "            code = 'CurrentProgramYear')     " +
            "      AND IsSuppressed = 'N'  " +
            "  %s     " +
            "   GROUP BY     " +
            "      ProviderGroupId,     " +
            "      ProviderId,     " +
            "      ProviderName,     " +
            "      ProviderState,     " +
            "      ProgramYear,     " +
            "      ClientId,     " +
            "      LobName,     " +
            "      ClientName     " ;

    private static final String RECORD_COUNT_QUERY = "SELECT count(*) as recCount FROM ("+FETCH_PROVIDER_MEMBERSHIP+") AS memberShipCount ";

    private static final String FETCH_PROVIDER_MEMBERSHIP_WITH_BATCH = FETCH_PROVIDER_MEMBERSHIP + " ORDER BY ProviderGroupId, ProviderId, ProviderName, ProviderState,LobName offset :OFFSET rows FETCH next :BatchSize rows only";


    @Override
    public Long getRecordCount(JobEvent jobEvent) {
        String providerEligibleMembershipCount="";
        if (com.optum.rqns.ftm.constants.Constants.ALL.equalsIgnoreCase(jobEvent.getGroupsToExecute().toString())) {
            log.info("{} : Fetching fot All scenario for RunProviderEligibleMembership Job", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
            providerEligibleMembershipCount = String.format(RECORD_COUNT_QUERY, "");
        } else {
            log.info("{} : Fetching fot Modified scenario for RunProviderEligibleMembership Job", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
            providerEligibleMembershipCount = String.format(RECORD_COUNT_QUERY, MODIFIED_CONDITION);
        }
        log.info("RunProviderEligibleMembership Producer DB Count :{}", providerEligibleMembershipCount);

        return namedParameterJdbcTemplate.queryForObject(providerEligibleMembershipCount,new HashMap<>(), Long.class);

    }


    @Override
    public List<ProviderEligibleMembershipFlatData> getProviderEligibleMembershipDetails(int batchSize, Integer batchOffset,JobEvent jobEvent) {
        String providerEligibleMembershipDetails = null;
        if (com.optum.rqns.ftm.constants.Constants.ALL.equalsIgnoreCase(jobEvent.getGroupsToExecute().toString())) {
            log.info("{} : Fetching fot All scenario for RunProviderEligibleMembership Job", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
            providerEligibleMembershipDetails = String.format(FETCH_PROVIDER_MEMBERSHIP_WITH_BATCH, "");
        } else {
            log.info("{} : Fetching fot Modified scenario for RunProviderEligibleMembership Job", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
            providerEligibleMembershipDetails = String.format(FETCH_PROVIDER_MEMBERSHIP_WITH_BATCH, MODIFIED_CONDITION);
        }
        SqlParameterSource sqlParameterSource = new MapSqlParameterSource("BatchSize", batchSize)
                .addValue("OFFSET", batchOffset);
        log.info("batchsize {} offset {}", batchSize, batchOffset);

        return namedParameterJdbcTemplate.query(providerEligibleMembershipDetails,sqlParameterSource, new BeanPropertyRowMapper<>(ProviderEligibleMembershipFlatData.class));
    }

}
