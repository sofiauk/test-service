package com.optum.rqns.ftm.enums;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class DmnPayload{
    String modelNamespace;
    String modelName;
    Map<String,Object> dmnContext;
}
