package com.optum.rqns.ftm.quartz.config.practiceassist;

import com.optum.rqns.ftm.quartz.jobs.practiceassist.MemberSummaryAggregationJob;
import org.quartz.JobDetail;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.scheduling.quartz.CronTriggerFactoryBean;
import org.springframework.scheduling.quartz.JobDetailFactoryBean;

import com.optum.rqns.ftm.enums.GroupsToExecute;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.quartz.jobs.practiceassist.HospitalEventsAggregationJob;
import com.optum.rqns.ftm.quartz.jobs.practiceassist.MbrMedAdherenceAggregationJob;
import com.optum.rqns.ftm.quartz.jobs.practiceassist.QualityAggregationJob;
import com.optum.rqns.ftm.quartz.jobs.practiceassist.SuspectAggregrationJob;

import lombok.extern.slf4j.Slf4j;

@Profile("paLandingPageJobs")
@Configuration
@Slf4j
public class PAQuartzSubmitJobs {

	@Value("${rqns.ftm.schedulerCron.qualityAggregationDailyJob}")
	private String qualityAggregationDailyJobCronExpression;
	
	@Value("${rqns.ftm.schedulerCron.qualityAggregationWeeklyJob}")
	private String qualityAggregationWeeklyJobCronExpression;
	
	@Value("${rqns.ftm.schedulerCron.suspectAggregationDailyJob}")
	private String suspectAggregationDailyJobCronExpression;
	
	@Value("${rqns.ftm.schedulerCron.suspectAggregationWeeklyJob}")
	private String suspectAggregationWeeklyJobCronExpression;
	
	@Value("${rqns.ftm.schedulerCron.mbrMedAdherenceAggregationDailyJob}")
	private String mbrMedAdherenceAggregationDailyJobCronExpression;
	
	@Value("${rqns.ftm.schedulerCron.mbrMedAdherenceAggregationWeeklyJob}")
	private String mbrMedAdherenceAggregationWeeklyJobCronExpression;

	@Value("${rqns.ftm.schedulerCron.memberSummaryAggregationDailyJob}")
	private String memberSummaryAggregationDailyJobCronExpression;

	@Value("${rqns.ftm.schedulerCron.memberSummaryAggregationWeeklyJob}")
	private String memberSummaryAggregationWeeklyJobCronExpression;
	
	@Value("${rqns.ftm.schedulerCron.memberHospitalEventsAggregationDailyJob}")
	private String memberHospitalEventsAggregationDailyJobCronExpression;

	@Value("${rqns.ftm.schedulerCron.memberHospitalEventsAggregationWeeklyJob}")
	private String memberHospitalEventsAggregationWeeklyJobCronExpression;


	/**
	 * This method is use to configure JobDetails for specific Job
	 * 
	 * @return
	 */
	@Bean(name = "QualityAggregationDailyJob")
	public JobDetailFactoryBean qualityAggregationDailyJob() {
		
		return PAQuartzConfig.createJobDetail(QualityAggregationJob.class, JobName.RUN_QUALITY_AGGREGATION.getValue(),GroupsToExecute.MODIFIED.getValue());
	}

	/**
	 * This method will start Cron Job based on configuration and triggerd with
	 * JobDetails
	 * 
	 * @param jobDetail
	 * @return
	 */
	@Bean(name = " QualityAggregationDailyJobTrigger")
	public CronTriggerFactoryBean triggerQualityAggregationDailyJob(@Qualifier("QualityAggregationDailyJob") JobDetail jobDetail) {
		return PAQuartzConfig.createCronTrigger(jobDetail, qualityAggregationDailyJobCronExpression,
				"triggerQualityAggregationDailyJob");
	}
	
	
	/**
	 * This method is use to configure JobDetails for specific Job
	 * 
	 * @return
	 */
	@Bean(name = "QualityAggregationWeeklyJob")
	public JobDetailFactoryBean qualityAggregationWeeklyJob() {
		
		return PAQuartzConfig.createJobDetail(QualityAggregationJob.class, JobName.RUN_QUALITY_AGGREGATION.getValue(),GroupsToExecute.ALL.getValue());
	}

	/**
	 * This method will start Cron Job based on configuration and triggerd with
	 * JobDetails
	 * 
	 * @param jobDetail
	 * @return
	 */
	@Bean(name = " QualityAggregationWeeklyJobTrigger")
	public CronTriggerFactoryBean triggerQualityAggregationWeeklyJob(@Qualifier("QualityAggregationWeeklyJob") JobDetail jobDetail) {
		return PAQuartzConfig.createCronTrigger(jobDetail, qualityAggregationWeeklyJobCronExpression,
				"triggerQualityAggregationWeeklyJob");
	}
	
	@Bean(name = "SuspectAggregationDailyJob")
	public JobDetailFactoryBean suspectAggregationDailyJob() {
		return PAQuartzConfig.createJobDetail(SuspectAggregrationJob.class, JobName.RUN_SUSPECT_AGGREGATION.getValue(),
		GroupsToExecute.MODIFIED.getValue());
	}
	
	@Bean(name = "SuspectAggregationDailyJobTrigger")
	public CronTriggerFactoryBean triggerSuspectAggregationDailyJob(
			@Qualifier("SuspectAggregationDailyJob") JobDetail jobDetail) {
		return PAQuartzConfig.createCronTrigger(jobDetail, suspectAggregationDailyJobCronExpression,
				"triggerSuspectAggregationDailyJob");
	}
	
	@Bean(name = "SuspectAggregationWeeklyJob")
	public JobDetailFactoryBean suspectAggregationWeeklyJob() {
		return PAQuartzConfig.createJobDetail(SuspectAggregrationJob.class, JobName.RUN_SUSPECT_AGGREGATION.getValue(),
				GroupsToExecute.ALL.getValue());
	}
	
	@Bean(name = " SuspectAggregationWeeklyJobTrigger")
	public CronTriggerFactoryBean triggerSuspectAggregationWeeklyJob(
			@Qualifier("SuspectAggregationWeeklyJob") JobDetail jobDetail) {
		return PAQuartzConfig.createCronTrigger(jobDetail, suspectAggregationWeeklyJobCronExpression,
				"triggerSuspectAggregationWeeklyJob");
	}
	
	@Bean(name = "MbrMedAdherenceAggregationDailyJob")
	public JobDetailFactoryBean mbrMedAdherenceAggregationDailyJob() {
	return PAQuartzConfig.createJobDetail(MbrMedAdherenceAggregationJob.class, JobName.RUN_MED_ADHERENCE_AGGREGATION.getValue(),
	GroupsToExecute.MODIFIED.getValue());
	}
	
	@Bean(name = "MbrMedAdherenceAggregationDailyJobTrigger")
	public CronTriggerFactoryBean triggerMbrMedAdherenceAggregationDailyJob(
	@Qualifier("MbrMedAdherenceAggregationDailyJob") JobDetail jobDetail) {
	return PAQuartzConfig.createCronTrigger(jobDetail, mbrMedAdherenceAggregationDailyJobCronExpression,
	"triggerMbrMedAdherenceAggregationDailyJob");
	}
	
	@Bean(name = "MbrMedAdherenceAggregationWeeklyJob")
	public JobDetailFactoryBean mbrMedAdherenceAggregationWeeklyJob() {
	return PAQuartzConfig.createJobDetail(MbrMedAdherenceAggregationJob.class, JobName.RUN_MED_ADHERENCE_AGGREGATION.getValue(),
	GroupsToExecute.ALL.getValue());
	}
	
	@Bean(name = " MbrMedAdherenceAggregationWeeklyJobTrigger")
	public CronTriggerFactoryBean triggerMbrMedAdherenceAggregationWeeklyJob(
	@Qualifier("MbrMedAdherenceAggregationWeeklyJob") JobDetail jobDetail) {
	return PAQuartzConfig.createCronTrigger(jobDetail, mbrMedAdherenceAggregationWeeklyJobCronExpression,
	"triggerMbrMedAdherenceAggregationWeeklyJob");
	}

// Summary Aggregation
	@Bean(name = "MemberSummaryAggregationDailyJob")
	public JobDetailFactoryBean memberSummaryAggregationDailyJob() {
		return PAQuartzConfig.createJobDetail(MemberSummaryAggregationJob.class, JobName.RUN_MEMBER_SUMMARY_AGGREGATION.getValue(),
				GroupsToExecute.MODIFIED.getValue());
	}

	@Bean(name = "MemberSummaryAggregationDailyJobTrigger")
	public CronTriggerFactoryBean triggerMemberSummaryAggregationDailyJob(
			@Qualifier("MemberSummaryAggregationDailyJob") JobDetail jobDetail) {
		return PAQuartzConfig.createCronTrigger(jobDetail, memberSummaryAggregationDailyJobCronExpression,
				"triggerMemberSummaryAggregationDailyJob");
	}

	@Bean(name = "MemberSummaryAggregationWeeklyJob")
	public JobDetailFactoryBean memberSummaryAggregationWeeklyJob() {
		return PAQuartzConfig.createJobDetail(MemberSummaryAggregationJob.class, JobName.RUN_MEMBER_SUMMARY_AGGREGATION.getValue(),
				GroupsToExecute.ALL.getValue());
	}

	@Bean(name = "MemberSummaryAggregationWeeklyJobTrigger")
	public CronTriggerFactoryBean triggerMemberSummaryAggregationWeeklyJob(
			@Qualifier("MemberSummaryAggregationWeeklyJob") JobDetail jobDetail) {
		return PAQuartzConfig.createCronTrigger(jobDetail, memberSummaryAggregationWeeklyJobCronExpression,
				"triggerMemberSummaryAggregationWeeklyJob");
	}
	
	
	@Bean(name = "HospitalEventsAggregationDailyJob")
	public JobDetailFactoryBean hospitalEventsAggregationDailyJob() {
		
		return PAQuartzConfig.createJobDetail(HospitalEventsAggregationJob.class, JobName.RUN_MEMBER_HOSPITAL_EVENTS_AGGREGATION.getValue(),GroupsToExecute.MODIFIED.getValue());
	}

	@Bean(name = "HospitalEventsAggregationDailyJobTrigger")
	public CronTriggerFactoryBean triggerHospitalEventsAggregationDailyJob(@Qualifier("HospitalEventsAggregationDailyJob") JobDetail jobDetail) {
		return PAQuartzConfig.createCronTrigger(jobDetail, memberHospitalEventsAggregationDailyJobCronExpression,
				"triggerHospitalEventsAggregationDailyJob");
	}
	
	
	@Bean(name = "HospitalEventsAggregationWeeklyJob")
	public JobDetailFactoryBean hospitalEventsAggregationWeeklyJob() {
		
		return PAQuartzConfig.createJobDetail(HospitalEventsAggregationJob.class, JobName.RUN_MEMBER_HOSPITAL_EVENTS_AGGREGATION.getValue(),GroupsToExecute.ALL.getValue());
	}

	@Bean(name = "HospitalEventsAggregationWeeklyJobTrigger")
	public CronTriggerFactoryBean triggerHospitalEventsAggregationWeeklyJob(@Qualifier("HospitalEventsAggregationWeeklyJob") JobDetail jobDetail) {
		return PAQuartzConfig.createCronTrigger(jobDetail, memberHospitalEventsAggregationWeeklyJobCronExpression,
				"triggerHospitalEventsAggregationWeeklyJob");
	}

}
