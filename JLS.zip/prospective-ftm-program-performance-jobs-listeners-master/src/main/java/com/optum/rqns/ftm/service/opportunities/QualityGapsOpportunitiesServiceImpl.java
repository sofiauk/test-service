package com.optum.rqns.ftm.service.opportunities;

import com.optum.rqns.ftm.opportunities.common.service.ppt.MemberGapsQualityServiceImpl;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

// added memberGapJobs profile so that beans from common library will be restricted to memberGapJobs profile
@Service
@Profile("memberGapJobs")
public class QualityGapsOpportunitiesServiceImpl extends OpportunitiesService {

	private MemberGapsQualityServiceImpl qualityGapsService;

	public QualityGapsOpportunitiesServiceImpl(MemberGapsQualityServiceImpl qualityGapsService) {
		setBatchingRequired(true);
		memberGapsService = qualityGapsService;
	}

}
