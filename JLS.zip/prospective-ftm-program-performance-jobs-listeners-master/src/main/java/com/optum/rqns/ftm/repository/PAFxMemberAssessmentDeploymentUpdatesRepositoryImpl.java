package com.optum.rqns.ftm.repository;

import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;

@Repository
@Slf4j
public class PAFxMemberAssessmentDeploymentUpdatesRepositoryImpl implements PAFxMemberDeploymentUpdatesRepository {
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    public final String DATA_MERGE_QUERY = ";WITH PAFX_BATCH AS (  " +
            "SELECT IsDeployed  " +
            ",id  " +
            ", IsProviderAssociated  " +
            ", updatedDate  " +
            ", updatedBy  " +
            ", PafMasterUpdatedDate  " +
            ", ProviderAssociationUpdatedDate  " +
            ", ValidationStatus  " +
            ", AssociationValidFrom  " +
            ", AssociationValidTo  " +
            ", ProviderGroupId  " +
            ", ProviderId  " +
            ", ProviderState  " +
            ", ClientId  " +
            ", LobName  " +
            ", ProgramYear  " +
            ", GlobalMemberId  " +
            ",PreferredMbrReimbType  " +
            ", MbrPopType  " +
            ",EligibleProgramType  " +
            "FROM ProgPerf.PafExMemberAssessment  " +
            "where ProgramYear=:ProgramYear and IsSuppressed ='N'  " +
            "order by id  " +
            "OFFSET :offset ROWS FETCH NEXT :batchsize ROWS ONLY )  " +
            "UPDATE PAFX_BATCH  " +
            "SET IsDeployed = (  " +
            "CASE  " +
            "WHEN MA.ID IS NULL  " +
            "THEN 'false'  " +
            "ELSE 'true'  " +
            "END  " +
            ")  " +
            ", IsProviderAssociated = PRV_GRP_ASN.IsAssociated  " +
            ", updatedDate = getUtcDate()  " +
            ", updatedBy = :updatedBy  " +
            ", ValidationStatus = PRV_GRP_ASN.validationStatus  " +
            ", AssociationValidFrom = PRV_GRP_ASN.ValidatedDate  " +
            ", AssociationValidTo = PRV_GRP_ASN.ExpirationDate  " +
            ",EligibleProgramType = (  " +
            "SELECT cmc.EligibleProgramType from ProgPerf.EligibleProgramTypeTranslation cmc  " +
            "where cmc.ReimbursementType = PAFX_BATCH.PreferredMbrReimbType  " +
            "AND cmc.MemberPopulationType = PAFX_BATCH.MbrPopType  " +
            "AND cmc.IPEFLag =(select  case when   pge.IPEFlag is null then 'NONE' else pge.IPEFlag  end  from ProgPerf.ProviderGroupExtended pge  " +
            "where pge.ProviderGroupID =PAFX_BATCH.ProviderGroupId and pge.State =PAFX_BATCH.ProviderState  " +
            "and pge.ProgramYear =PAFX_BATCH.ProgramYear))  " +
            "FROM PAFX_BATCH  " +
            "LEFT JOIN ProgPerf.MemberAssessment AS MA WITH (NOLOCK)  " +
            "ON PAFX_BATCH.ProviderGroupId = MA.prov_group_id  " +
            "AND PAFX_BATCH.ProviderState = MA.providerstate  " +
            "AND PAFX_BATCH.ClientId = MA.clientid  " +
            "AND PAFX_BATCH.LobName = MA.lob2  " +
            "AND PAFX_BATCH.ProgramYear = MA.project_year  " +
            "AND PAFX_BATCH.GlobalMemberId = MA.mbr_glb_id  " +
            "AND MA.deriveddeployed = 1  " +
            "AND UPPER(MA.RecordChangeType) <> 'DELETED'  " +
            "LEFT JOIN ProgPerf.ProviderGroupAssociation AS PRV_GRP_ASN WITH (NOLOCK)  " +
            "ON PAFX_BATCH.ProviderGroupId = PRV_GRP_ASN.ProviderGroupId  " +
            "AND PAFX_BATCH.ProviderId = PRV_GRP_ASN.ProviderId  ";


    public final String DATA_MERGE_QUERY_MODIFIED =";WITH PAFX_BATCH AS ( " +
            "SELECT IsDeployed " +
            ",id " +
            ", IsProviderAssociated " +
            ", updatedDate " +
            ", updatedBy " +
            ", PafMasterUpdatedDate " +
            ", ProviderAssociationUpdatedDate " +
            ", ValidationStatus " +
            ", AssociationValidFrom " +
            ", AssociationValidTo " +
            ", ProviderGroupId " +
            ", ProviderId " +
            ", ProviderState " +
            ", ClientId " +
            ", LobName " +
            ", ProgramYear " +
            ", GlobalMemberId " +
            ",PreferredMbrReimbType  " +
            ", MbrPopType  " +
            ",EligibleProgramType " +
            "FROM ProgPerf.PafExMemberAssessment " +
            "where id  in (%s) ) " +
            "UPDATE PAFX_BATCH " +
            "SET IsDeployed = ( " +
            "CASE " +
            "WHEN MA.ID IS NULL " +
            "THEN 'false' " +
            "ELSE 'true' " +
            "END " +
            ") " +
            ", IsProviderAssociated = PRV_GRP_ASN.IsAssociated " +
            ", updatedDate = getUtcDate() " +
            ", updatedBy = 'PAFDeployUpdate' " +
            ", ValidationStatus = PRV_GRP_ASN.validationStatus " +
            ", AssociationValidFrom = PRV_GRP_ASN.ValidatedDate " +
            ", AssociationValidTo = PRV_GRP_ASN.ExpirationDate " +
            ",EligibleProgramType = (  " +
            "SELECT cmc.EligibleProgramType from ProgPerf.EligibleProgramTypeTranslation cmc  " +
            "where cmc.ReimbursementType = PAFX_BATCH.PreferredMbrReimbType  " +
            "AND cmc.MemberPopulationType = PAFX_BATCH.MbrPopType  " +
            "AND cmc.IPEFLag =(select  case when   pge.IPEFlag is null then 'NONE' else pge.IPEFlag  end  from ProgPerf.ProviderGroupExtended pge  " +
            "where pge.ProviderGroupID =PAFX_BATCH.ProviderGroupId and pge.State =PAFX_BATCH.ProviderState  " +
            "and pge.ProgramYear =PAFX_BATCH.ProgramYear))  " +
            "FROM PAFX_BATCH " +
            "LEFT JOIN ProgPerf.MemberAssessment AS MA WITH (NOLOCK) " +
            "ON PAFX_BATCH.ProviderGroupId = MA.prov_group_id " +
            "AND PAFX_BATCH.ProviderState = MA.providerstate " +
            "AND PAFX_BATCH.ClientId = MA.clientid " +
            "AND PAFX_BATCH.LobName = MA.lob2 " +
            "AND PAFX_BATCH.ProgramYear = MA.project_year " +
            "AND PAFX_BATCH.GlobalMemberId = MA.mbr_glb_id " +
            "AND MA.deriveddeployed = 1 " +
            "AND UPPER(MA.RecordChangeType) <> 'DELETED' " +
            "LEFT JOIN ProgPerf.ProviderGroupAssociation AS PRV_GRP_ASN WITH (NOLOCK) " +
            "ON PAFX_BATCH.ProviderGroupId = PRV_GRP_ASN.ProviderGroupId " +
            "AND PAFX_BATCH.ProviderId = PRV_GRP_ASN.ProviderId ";


    public final String COUNT_QUERY = "SELECT   " +
            "count(*) as totalCount  " +
            "FROM   " +
            "ProgPerf.PafExMemberAssessment with (NOLOCK)  where ProgramYear=:ProgramYear and IsSuppressed ='N' " ;

    public final String COUNT_QUERY_MODIFIED = "select  " +
            "count(*)  " +
            "from  " +
            "(  " +
            "select  " +
            "PAFX_BATCH.id  " +
            "from  " +
            "ProgPerf.PafExMemberAssessment PAFX_BATCH with (nolock)  " +
            "where  " +
            "PAFX_BATCH.ProgramYear =:ProgramYear  " +
            "and PAFX_BATCH.IsSuppressed = 'N'  " +
            "and PAFX_BATCH.PafxMemberUpdatedDate >:lastSucessfullRun  " +
            "union (  " +
            "select  " +
            "PAFX_BATCH.id  " +
            "from  " +
            "ProgPerf.MemberAssessment ma with (nolock) ,  " +
            "ProgPerf.PafExMemberAssessment PAFX_BATCH with (nolock)  " +
            "where  " +
            "PAFX_BATCH.ProgramYear =:ProgramYear  " +
            "and PAFX_BATCH.IsSuppressed = 'N'  " +
            "and ma.RecordChangeType <> 'Deleted'  " +
            "and ma.project_year =:ProgramYear  " +
            "and (ma.UpdatedDate>:lastSucessfullRun  " +
            "or ma.ModifiedDate >:lastSucessfullRun )  " +
            "and PAFX_BATCH.ProviderGroupId = MA.prov_group_id  " +
            "AND PAFX_BATCH.ProviderState = MA.providerstate  " +
            "AND PAFX_BATCH.ClientId = MA.clientid  " +
            "AND PAFX_BATCH.LobName = MA.lob2  " +
            "AND PAFX_BATCH.ProgramYear = MA.project_year  " +
            "AND PAFX_BATCH.GlobalMemberId = MA.mbr_glb_id)  " +
            "union (  " +
            "select  " +
            "PAFX_BATCH.id  " +
            "from  " +
            "ProgPerf.ProviderGroupAssociation pga with (nolock) ,  " +
            "ProgPerf.PafExMemberAssessment PAFX_BATCH with (nolock)  " +
            "where  " +
            "PAFX_BATCH.ProgramYear =:ProgramYear  " +
            "and PAFX_BATCH.IsSuppressed = 'N'  " +
            "and pga.UpdatedDate >:lastSucessfullRun  " +
            "and PAFX_BATCH.ProviderGroupId = pga.ProviderGroupId  " +
            "AND PAFX_BATCH.ProviderId = pga.ProviderId )  " +
            "UNION (  " +
            "select  " +
            "PAFX_BATCH.id  " +
            "from  " +
            "ProgPerf.ProviderGroupExtended pge with (nolock) ,  " +
            "ProgPerf.PafExMemberAssessment PAFX_BATCH with (nolock)  " +
            "where  " +
            "PAFX_BATCH.ProgramYear =:ProgramYear  " +
            "and PAFX_BATCH.IsSuppressed = 'N'  " +
            "and pge.ProgramYear =:ProgramYear  " +
            "and pge.UpdatedDate >:lastSucessfullRun  " +
            "and pge.ProviderGroupID = PAFX_BATCH.ProviderGroupId  " +
            "and pge.State = PAFX_BATCH.ProviderState     " +
            "and pge.UpdatedBy not in (select * from  STRING_SPLIT((select value from ProgPerf.MasterConfiguration mc where mc.code='EXCLUDE_MODIFIED_DATA_FOR_PAFXJOB'),',')) ) ) Modifieddata  ";

    public final String GET_MODIFIED_ID ="select  " +
            "*  " +
            "from  " +
            "(  " +
            "select  " +
            "PAFX_BATCH.id  " +
            "from  " +
            "ProgPerf.PafExMemberAssessment PAFX_BATCH with (nolock)  " +
            "where  " +
            "PAFX_BATCH.ProgramYear =:ProgramYear  " +
            "and PAFX_BATCH.IsSuppressed = 'N'  " +
            "and PAFX_BATCH.PafxMemberUpdatedDate >:lastSucessfullRun  " +
            "union (  " +
            "select  " +
            "PAFX_BATCH.id  " +
            "from  " +
            "ProgPerf.MemberAssessment ma with (nolock) ,  " +
            "ProgPerf.PafExMemberAssessment PAFX_BATCH with (nolock)  " +
            "where  " +
            "PAFX_BATCH.ProgramYear =:ProgramYear  " +
            "and PAFX_BATCH.IsSuppressed = 'N'  " +
            "and ma.RecordChangeType <> 'Deleted'  " +
            "and ma.project_year =:ProgramYear  " +
            "and (ma.UpdatedDate>:lastSucessfullRun  " +
            "or ma.ModifiedDate >:lastSucessfullRun )  " +
            "and PAFX_BATCH.ProviderGroupId = MA.prov_group_id  " +
            "AND PAFX_BATCH.ProviderState = MA.providerstate  " +
            "AND PAFX_BATCH.ClientId = MA.clientid  " +
            "AND PAFX_BATCH.LobName = MA.lob2  " +
            "AND PAFX_BATCH.ProgramYear = MA.project_year  " +
            "AND PAFX_BATCH.GlobalMemberId = MA.mbr_glb_id)  " +
            "union (  " +
            "select  " +
            "PAFX_BATCH.id  " +
            "from  " +
            "ProgPerf.ProviderGroupAssociation pga with (nolock) ,  " +
            "ProgPerf.PafExMemberAssessment PAFX_BATCH with (nolock)  " +
            "where  " +
            "PAFX_BATCH.ProgramYear =:ProgramYear  " +
            "and PAFX_BATCH.IsSuppressed = 'N'  " +
            "and pga.UpdatedDate >:lastSucessfullRun  " +
            "and PAFX_BATCH.ProviderGroupId = pga.ProviderGroupId  " +
            "AND PAFX_BATCH.ProviderId = pga.ProviderId )  " +
            "UNION (  " +
            "select  " +
            "PAFX_BATCH.id  " +
            "from  " +
            "ProgPerf.ProviderGroupExtended pge with (nolock) ,  " +
            "ProgPerf.PafExMemberAssessment PAFX_BATCH with (nolock)  " +
            "where  " +
            "PAFX_BATCH.ProgramYear =:ProgramYear  " +
            "and PAFX_BATCH.IsSuppressed = 'N'  " +
            "and pge.ProgramYear =:ProgramYear  " +
            "and pge.UpdatedDate >:lastSucessfullRun  " +
            "and pge.ProviderGroupID = PAFX_BATCH.ProviderGroupId  " +
            "and pge.State = PAFX_BATCH.ProviderState " +
            "and pge.UpdatedBy not in (select * from  STRING_SPLIT((select value from ProgPerf.MasterConfiguration mc where mc.code='EXCLUDE_MODIFIED_DATA_FOR_PAFXJOB'),',')) ) ) Modifieddata  " +
            "order by id  " +
            "OFFSET :offset ROWS FETCH NEXT :batchsize ROWS ONLY  ";


    public PAFxMemberAssessmentDeploymentUpdatesRepositoryImpl(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
        this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
    }

    @Override
    public Long getRecordCount(Integer programYear) {
        HashMap<String,Object> params =  new HashMap<>();
        params.put("ProgramYear",programYear);
        return namedParameterJdbcTemplate.queryForObject(COUNT_QUERY, params, Long.class);
    }


    @Override
    public Integer mergePAFXMemberData(int batchSize, Integer batchOffset, JobEvent jobEvent) {
        SqlParameterSource sqlParameterSource = new MapSqlParameterSource("batchsize", batchSize)
                .addValue("offset", batchOffset)
                .addValue("updatedBy","PAFDeployUpdate")
                .addValue("ProgramYear",jobEvent.getProgramYear());

        log.info("mergePAFXMemberData batchsize {} offset {}", batchSize, batchOffset);
        String query= String.format(DATA_MERGE_QUERY, Constants.EMPTY);
        return this.namedParameterJdbcTemplate
                .update(query, sqlParameterSource);
    }


    @Override
    public Long getRecordCountModified(Integer programYear, String joblastrunsuccessfuldate) {
        HashMap<String,Object> params =  new HashMap<>();
        params.put("ProgramYear",programYear);
        params.put("lastSucessfullRun",joblastrunsuccessfuldate);
        return namedParameterJdbcTemplate.queryForObject(COUNT_QUERY_MODIFIED, params, Long.class);
    }

    @Override
    public List<Integer> getListOfModifiedIdFromPafx(int batchSize, int offset, Integer programyear,  String joblastrunsuccessfuldate) {
        HashMap<String,Object> params =  new HashMap<>();
        params.put("ProgramYear",programyear);
        params.put("lastSucessfullRun",joblastrunsuccessfuldate);
        params.put("batchsize",batchSize);
        params.put("offset",offset);
        return namedParameterJdbcTemplate.queryForList(GET_MODIFIED_ID, params, Integer.class);
    }

    @Override
    public Integer mergeModifiedData(String batchdata) {
        SqlParameterSource sqlParameterSource = new MapSqlParameterSource();
        String query= String.format(DATA_MERGE_QUERY_MODIFIED, batchdata);
        return this.namedParameterJdbcTemplate
                .update(query, sqlParameterSource);
    }
}