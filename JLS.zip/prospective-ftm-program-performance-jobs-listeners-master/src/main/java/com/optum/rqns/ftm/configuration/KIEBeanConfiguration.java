package com.optum.rqns.ftm.configuration;

import com.optum.rqns.ftm.model.fieldactionrules.AvailMembershipClientLobStateAction;
import com.optum.rqns.ftm.model.fieldactionrules.NewMemberShipAction;
import com.optum.rqns.ftm.model.fieldactionrules.ChangeServiceAction;
import com.optum.rqns.ftm.model.fieldactionrules.NewProviderManualAssociationAction;
import com.optum.rqns.ftm.model.fieldactionrules.RejectAgingGroupLevelAction;
import com.optum.rqns.ftm.model.fieldactionrules.ReturnTargetTrackingAction;
import com.optum.rqns.ftm.model.fieldactionrules.RuleAction;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContexts;
import org.kie.server.api.marshalling.MarshallingFormat;
import org.kie.server.client.KieServicesClient;
import org.kie.server.client.KieServicesConfiguration;
import org.kie.server.client.KieServicesFactory;
import org.kie.server.client.RuleServicesClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import javax.net.ssl.SSLContext;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashSet;
import java.util.Set;

@Configuration
@Slf4j
public class KIEBeanConfiguration {

    @Value("${kie.server.url}")
    String url;

    @Value("${kie.server.username}")
    String userName;

    @Value("${kie.server.password}")
    String password;

    private static final MarshallingFormat FORMAT = MarshallingFormat.JSON;

    @Value("${ssl.sslCertificateDirectory}")
    private String sslCertificateDirectory;

    @Value("${ssl.certKeyPassword}")
    private String certKeyPassword;

    @Bean
    public KieServicesClient getKieServicesClient() {
        try {
            KieServicesConfiguration conf = KieServicesFactory.newRestConfiguration(url, userName, password);

            //If you use custom classes, such as Obj.class, add them to the configuration.
            Set<Class<?>> extraClassList = new HashSet<Class<?>>();
            extraClassList.add(RuleAction.class);
            extraClassList.add(ReturnTargetTrackingAction.class);
            extraClassList.add(ChangeServiceAction.class);
            extraClassList.add(NewMemberShipAction.class);
            extraClassList.add(RejectAgingGroupLevelAction.class);
            extraClassList.add(NewProviderManualAssociationAction.class);
            extraClassList.add(AvailMembershipClientLobStateAction.class);
            conf.addExtraClasses(extraClassList);

            conf.setMarshallingFormat(FORMAT);
            return KieServicesFactory.newKieServicesClient(conf);
        } catch(Exception exception) {
            log.error("Exception while creating KieServicesClient");
        }
        return null;
    }

    @Bean
    public RuleServicesClient  ruleServicesClient(KieServicesClient kieServicesClient) {
        try {
            return kieServicesClient.getServicesClient(RuleServicesClient.class);
        } catch (Exception exception) {
            log.error("Exception in creating RuleServiceClient");
        }
        return null;
    }

    @Bean(name = "restTemplate")
    public RestTemplate getRestTemplate() throws Exception{
        String jksLocation = sslCertificateDirectory;
        final String jksSecret = certKeyPassword;
        SSLContext sslContext = null;
        try {
             sslContext = SSLContexts.custom().loadTrustMaterial(new File(jksLocation), jksSecret.toCharArray()).build();
        }catch (FileNotFoundException excep){
            //in local build, pointing to standard cert path to avoid each dev changing code in local.
            //To continue smooth flow and Its default value, So no need to move to yml
            jksLocation = "./src/main/resources/certs/standard_trusts.jks";
            sslContext = SSLContexts.custom().loadTrustMaterial(new File(jksLocation), jksSecret.toCharArray()).build();
        }
        SSLConnectionSocketFactory sslConnectionSocketFactory = new SSLConnectionSocketFactory(sslContext);
        CloseableHttpClient httpclient = HttpClients.custom().setSSLSocketFactory(sslConnectionSocketFactory).build();
        HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory(httpclient);
        RestTemplate restTemplate = new RestTemplate(factory);
        return restTemplate;
    }
}
