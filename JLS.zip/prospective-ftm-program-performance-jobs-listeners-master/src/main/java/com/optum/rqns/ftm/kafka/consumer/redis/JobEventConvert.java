package com.optum.rqns.ftm.kafka.consumer.redis;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class JobEventConvert {
    private String jobName;
    private int programYear;
    private String status;
    private String groupsToExecute;
    private String executionWeek;
    @JsonIgnore
    private LocalDateTime timeStamp;
    private boolean cascadeEvents;
    private String jobInput;
    private String frequency;
    private String eventType;

}