package com.optum.rqns.ftm.service.landingpage;

import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.exception.ProgramPerformanceJobListenerException;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.model.ProgramYearCalendarDTO;
import com.optum.rqns.ftm.repository.common.CommonRepository;
import com.optum.rqns.ftm.repository.landingpage.LeaderPerformanceRepository;
import com.optum.rqns.ftm.repository.users.UsersRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Slf4j
@Service
public class LeaderPerformanceServiceImpl implements LeaderPerformanceService {

    @Autowired
    private UsersRepository usersRepository;

    @Autowired
    private LeaderPerformanceRepository leaderPerformanceRepository;

    @Autowired
    private CommonRepository commonRepository;

     static final List<String> LEADER_ROLES = Arrays.asList("RVP", "Director", "Manager");
     static final List<String> IC_ROLES = Arrays.asList("PSC", "HCA");

    @Override
    public JobStatus executeJob(JobEvent jobEvent) {
        JobStatus jobStatus = new JobStatus();
        try {


            log.info("jobevent received is {}", jobEvent);
            jobStatus.setStatus(Status.SUCCESS);
            jobStatus.setUpdatedRows(0l);
            jobStatus.setMessage("Successfully completed LeaderLandingPage job");


            //0. get Current Duration Value
            ProgramYearCalendarDTO programYearCalendarDTO = commonRepository.getYTDDuration(jobEvent.getProgramYear());
            log.info("ProgramYearCalendarDTO {}", programYearCalendarDTO);

            dataCleanUp(jobEvent.getProgramYear(), jobStatus, programYearCalendarDTO);

            //1. National Level at All clients, Lob, Region, state, Service Level(HSC,PSC-B,PSC-P).
            loadNationalLevelForAllClientLobStateRegion(jobStatus,programYearCalendarDTO);
            //1.a National Level at individual client, Lob, State, region, Service Level
            fetchProgPerfWeeklyAndInsert(jobStatus, programYearCalendarDTO);
            //2. For Individual
            // 2.a For all Individual
            calculateForAllUsers(jobStatus, programYearCalendarDTO);
            // 2.b For Specified only.

            log.info("job status is {}", jobStatus);
        } catch (Exception e) {
            log.error("Error occurred in calculating Leader Performance", e);
            jobStatus.setMessage(e.getMessage());
            jobStatus.setStatus(Status.FAILURE);
        }

        return jobStatus;
    }

    private void dataCleanUp(int programYear, JobStatus jobStatus, ProgramYearCalendarDTO programYearCalendarDTO) {

        final Integer updatedRows = leaderPerformanceRepository.flagIsCurrentWeekFalse(programYear,programYearCalendarDTO);
        jobStatus.setUpdatedRows(jobStatus.getUpdatedRows() + updatedRows);

        final Integer rows = leaderPerformanceRepository.flagIsActiveFalse(programYear,programYearCalendarDTO);
        jobStatus.setUpdatedRows(jobStatus.getUpdatedRows() + rows);

        final Integer row =leaderPerformanceRepository.updateIsActiveFlagToFalse(programYear+"");
        jobStatus.setUpdatedRows(jobStatus.getUpdatedRows() + row);
        updateJobStatusMessage(jobStatus, "LeaderPerformance flag false count:" + rows);

    }

    private void updateJobStatusMessage(JobStatus jobStatus, String s) {

        log.info(s);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(jobStatus.getMessage()).append(s);
        jobStatus.setMessage(stringBuilder.toString());
    }

    private void calculateForAllUsers(JobStatus jobStatus, ProgramYearCalendarDTO programYearCalendarDTO) {

        try {
            //1. get RVPs,Directors,Managers
            List<String> leaders = usersRepository.getUsersByRole(LEADER_ROLES);
            log.info("leaders size {}", leaders.size());

            //2. get ICs
            List<String> ics = leaderPerformanceRepository.getUsersByRole(IC_ROLES);
            log.info("ics size {}", ics.size());


            //3. Calculate For ics
            ics.parallelStream()
                    .forEach(ic -> {
                        int updatedCount = 0;
                        // 1. Calculate Service Levels for this IC
                        List<String> serviceLevels = leaderPerformanceRepository.getServiceLevelForUser(ic);

                        List<String> serviceLevelsForPOC = serviceLevels.parallelStream().filter(sl-> sl.equalsIgnoreCase("HCA")).collect(Collectors.toList());
                        // 2. Calculate Performance data
                        updatedCount = serviceLevels.parallelStream()
                                .map(sl -> leaderPerformanceRepository.calculateICPerformanceData(ic, sl, programYearCalendarDTO))
                                .reduce(Integer::sum)
                                .orElse(0);

                        log.info("IC {} Performance Data updated count {}", ic, updatedCount);

                        //Update the IC Actual Goal calculation
                        int goalCount = serviceLevels.parallelStream().map(sl->leaderPerformanceRepository.updateICGoalLeaderPerformance(ic,sl,programYearCalendarDTO))
                                .reduce(Integer::sum)
                                .orElse(0);
                        log.info("IC {} Performance Data updated with Actual goal data {}", ic, goalCount);
                        // 3. Calculate Growth Rate & POC

                        int growthRateUpdatedCount = serviceLevelsForPOC.parallelStream()
                                .map(sl -> leaderPerformanceRepository.calculateICGrowthRatePOCData(ic,sl, programYearCalendarDTO))
                                .reduce(Integer::sum)
                                .orElseGet(() -> 0);

                        log.info("IC {} GrowthRate & POC updated count {}", ic, growthRateUpdatedCount);

                        updatedCount +=growthRateUpdatedCount;

                        // 4. Calculate EModality
//                        int emodalityClientAndLObUpdatedCount = serviceLevels.parallelStream()
//                                .reduce(Integer::sum)
//                                .orElseGet(() -> 0);

                        int emodalityUpdatedCount = serviceLevels.parallelStream()
                                .map(sl -> {
                                    int count = leaderPerformanceRepository.calculateEModalityPOCData(ic,sl, programYearCalendarDTO);
                                    count +=leaderPerformanceRepository.calculateEModalityPOCDataForClientAndLob(ic,sl, programYearCalendarDTO);
                                    count +=leaderPerformanceRepository.calculateReturenNetCnaForALL(ic,sl, programYearCalendarDTO);
                                    count +=leaderPerformanceRepository.calculateReturenNetCnaForClientAndLob(ic,sl, programYearCalendarDTO);
                                    count +=leaderPerformanceRepository.calculateLeaderGrowthRatePOCDataForAllRegionAndState(ic,List.of(ic),programYearCalendarDTO.getProgramYear());
                                    return count;
                                })
                                .reduce(Integer::sum)
                                .orElseGet(() -> 0);

                        log.info("IC {} Calculate EModality & POC updated count {}", ic, emodalityUpdatedCount);
                        updatedCount +=emodalityUpdatedCount;
//                        updatedCount +=emodalityClientAndLObUpdatedCount;

                        //5. CGap Calculation

                        int cGapUpdatedCount = serviceLevels.parallelStream()
                                .map(sl -> leaderPerformanceRepository.calculateCGapData(ic,sl, programYearCalendarDTO))
                                .reduce(Integer::sum)
                                .orElseGet(() -> 0);

                        log.info("IC {} CGAP Closure updated count {}", ic, cGapUpdatedCount);

                        updatedCount +=cGapUpdatedCount;


                        jobStatus.setUpdatedRows(jobStatus.getUpdatedRows() + updatedCount);


                    });
            //4. get All IC under that Leaders and sum from LeaderPerformance table.
            leaders.parallelStream()
                    .forEach(leader -> {
                        final List<String> totalReporters = usersRepository.getIcReporters(leader);

                        int updatedCount = 0;
                        if (Objects.nonNull(totalReporters) && !totalReporters.isEmpty()) {
                            log.info("leader {} reporters {}", leader, totalReporters);

                            // 1. Calculate Performance data
                            updatedCount = leaderPerformanceRepository.calculateLeaderPerformanceData(leader, totalReporters, programYearCalendarDTO.getDurationValue());
                            log.info("Leader {} Performance updated count {}", leader, updatedCount);

                            // 2. Calculate Growth Rate & POC
                            updatedCount += leaderPerformanceRepository.calculateLeaderGrowthRatePOCData(leader, totalReporters,programYearCalendarDTO.getProgramYear());

                            updatedCount += leaderPerformanceRepository.calculateLeaderGrowthRatePOCDataForAllRegionAndState(leader, List.of(leader),programYearCalendarDTO.getProgramYear());

                            log.info("Leader {} GrowthRate & POC updated count {}", leader, updatedCount);

                            // 4. Calculate EModality
                        }

                        jobStatus.setUpdatedRows(jobStatus.getUpdatedRows() + updatedCount);

                    });

            // 5. Calculate National level calculateICGrowthRatePOCData

            int updatedCount = leaderPerformanceRepository.calculateNationalGrowthRatePOCData(Constants.NATIONAL, programYearCalendarDTO);
            updatedCount +=  leaderPerformanceRepository.calculateReturnNetCnaForNational(Constants.NATIONAL, programYearCalendarDTO);
            updatedCount +=  leaderPerformanceRepository.calculateReturnNetCnaForAllNational(Constants.NATIONAL, programYearCalendarDTO);
            updatedCount +=  leaderPerformanceRepository.calculateEModalityPOCDataForNational(Constants.NATIONAL, programYearCalendarDTO);
            updatedCount +=  leaderPerformanceRepository.calculateEModalityPOCDataForNationalClientLob(Constants.NATIONAL, programYearCalendarDTO);

            updatedCount += leaderPerformanceRepository.calculateLeaderGrowthRatePOCDataForAllRegionAndState(Constants.NATIONAL, List.of(Constants.NATIONAL),programYearCalendarDTO.getProgramYear());

            // 6. Update Regions
            updatedCount += leaderPerformanceRepository.updateRegions(programYearCalendarDTO);
            jobStatus.setUpdatedRows(jobStatus.getUpdatedRows() + updatedCount);


        } catch (Exception e) {
            log.error("exception occurred in calculating leader level performance", e);
            throw new ProgramPerformanceJobListenerException("exception occurred in calculating leader performance");
        }
    }

    private JobStatus fetchProgPerfWeeklyAndInsert(JobStatus jobStatus, ProgramYearCalendarDTO programYearCalendarDTO) {
        StringBuilder stringBuilder = new StringBuilder();
        try {
            long updatedCount = jobStatus.getUpdatedRows() + leaderPerformanceRepository.loadLeaderPerformanceWeekly(programYearCalendarDTO);
            jobStatus.setUpdatedRows(updatedCount);
            stringBuilder.append(jobStatus.getMessage()).append(" Nation level records updated successfully.");
            jobStatus.setMessage(stringBuilder.toString());
            log.info("Number of rows updated until nation level : {}", jobStatus.getUpdatedRows() + jobStatus.getUpdatedRows());
            updatedCount = jobStatus.getUpdatedRows() + leaderPerformanceRepository.loadLeaderPerformanceWeeklyCGAPClosureStateRegion(programYearCalendarDTO);
            log.info("Number of rows updated State and Region level CGAP  suspect Closure  : {}", updatedCount);

           long updatedGoalCount = jobStatus.getUpdatedRows() + leaderPerformanceRepository.updateNationalGoalsLeaderPerformance(programYearCalendarDTO);
            log.info("Number of rows updated  LOB, Client,State and Region level Goals  : {}", updatedGoalCount);
            jobStatus.setUpdatedRows(updatedGoalCount);

        } catch (DataAccessException e) {
            log.error("Nation level records update failed.", e);
            throw e;
        }
        return jobStatus;
    }

    private JobStatus loadNationalLevelForAllClientLobStateRegion(JobStatus jobStatus, ProgramYearCalendarDTO programYearCalendarDTO) {
        StringBuilder stringBuilder = new StringBuilder();
        try {
            long updatedCount = jobStatus.getUpdatedRows() + leaderPerformanceRepository.loadLeaderPerformanceNationalLevelAll(programYearCalendarDTO);
            jobStatus.setUpdatedRows(updatedCount);
            stringBuilder.append(jobStatus.getMessage()).append(" National level for All clients,lob, state, region, service level records updated successfully.");
            jobStatus.setMessage(stringBuilder.toString());
            log.info("Number of rows updated until nation @All client level : {}", jobStatus.getUpdatedRows() + jobStatus.getUpdatedRows());
            updatedCount = jobStatus.getUpdatedRows() + leaderPerformanceRepository.loadLeaderPerformanceWeeklyCGAPClosureNational(programYearCalendarDTO);
            log.info("Number of rows updated  nation level @ALL CGAP  suspect Closure  : {}",updatedCount);

            long updatedGoalCount = jobStatus.getUpdatedRows() +leaderPerformanceRepository.updateAllNationalGoalsLeaderPerformance(programYearCalendarDTO);
            jobStatus.setUpdatedRows(updatedGoalCount);
            stringBuilder.append(jobStatus.getMessage()).append(" National level for All clients,lob, state, region, service level goals updated successfully.");
            jobStatus.setMessage(stringBuilder.toString());
            log.info("Number of rows updated until nation @All client level : {}", jobStatus.getUpdatedRows() + jobStatus.getUpdatedRows());

        } catch (DataAccessException e) {
            log.error("Nation level records update failed @All client level.", e);
            throw e;
        }
        return jobStatus;
    }
}
