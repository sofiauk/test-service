package com.optum.rqns.ftm.repository.jobalerts;

import com.optum.rqns.ftm.model.JobAlert;
import com.optum.rqns.ftm.util.ProgramPerformanceJobUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.Map;

@Repository
@Slf4j
public class PrometheusJobAlertRepositoryImpl implements PrometheusJobAlertRepository {

    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    public PrometheusJobAlertRepositoryImpl(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
        this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
    }

    private static final String GET_JOB_ALERT_BY_JOB_NAME =
            "select top 1 A.JobName, A.JobDescription, A.LastRunDate, A.CreatedBy, " +
                    "A.CreatedDate, A.ModifiedBy, A.ModifiedDate, A.LastSuccessfulRunDate, " +
                    "A.messageKey, A.jobEvent, A.message, A.isActive, " +
                    "C.ID, C.JobID, C.Status,C.ErrorMessage,C.AffectedRows,C.JobStart,C.JobEnd " +
                    "FROM ProgPerf.JobRunConfiguration A WITH (NOLOCK)" +
                    "inner join " +
                    "    ProgPerf.JobExecutionHistory " +
                    "    as C on A.ID = C.JobID " +
                    "where A.JobName = :JOB_NAME " +
                    "ORDER by C.ID DESC";


    @Override
    public JobAlert getJobAlertByName(String jobName) {
        log.info("Fetching JobAlert details :{} ", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
        Map<String, Object> bindingMap = new HashMap<>();
        bindingMap.put("JOB_NAME", jobName);

        return namedParameterJdbcTemplate.queryForObject(GET_JOB_ALERT_BY_JOB_NAME, bindingMap, BeanPropertyRowMapper.newInstance(JobAlert.class));


    }
}
