package com.optum.rqns.ftm.service.fieldactionrules;

import com.google.gson.Gson;
import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.model.fieldactionrules.ChangeServiceAction;
import com.optum.rqns.ftm.model.fieldactionrules.RuleAction;
import com.optum.rqns.ftm.repository.fieldactionrules.ChangeServiceLevelRuleRepositoryImpl;
import com.optum.rqns.ftm.util.ProgramPerformanceJobUtil;
import lombok.extern.slf4j.Slf4j;
import org.jboss.logging.MDC;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
@Service
@Slf4j
public class ChangeServiceLevelRuleServiceImpl extends FieldActionRuleService  {


    private ChangeServiceLevelRuleRepositoryImpl changeServiceLevelRuleRepository;

    public ChangeServiceLevelRuleServiceImpl(ChangeServiceLevelRuleRepositoryImpl changeServiceLevelRuleRepository) {
        this.changeServiceLevelRuleRepository = changeServiceLevelRuleRepository;
        setBatchingRequired(true);
    }


    @Override
    public List<RuleAction> fetchRuleData(Integer beginIndex, int batchSize, boolean isBatchingRequired) {
        log.info("Inside Fetch Rule data for Change Service Level: transactionID :{}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
        return changeServiceLevelRuleRepository.getProvidersWithChangeServiceLevel(beginIndex,batchSize);
    }

    @Override
    public List<Integer> fetchRuleBatchingOffsetList(int batchsize) {
        log.info("Inside Fetch Rule Batching offset: transactionID :{},batchsize:{}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(),batchsize);
        return changeServiceLevelRuleRepository.getRowCountforChangeServiceLevel(batchsize);
    }


    @Override
    public String getRuleResult(RuleAction ruleAction) {
        Map<String,Object> resultMap=new HashMap<>();
        Gson gson=new Gson();
        if(ruleAction instanceof ChangeServiceAction){
            ChangeServiceAction qualifiedProviders=(ChangeServiceAction) ruleAction;
            resultMap.put("managerEmail",qualifiedProviders.getManagerEmail());
            resultMap.put("groupId",qualifiedProviders.getGroupId());
            resultMap.put("state",qualifiedProviders.getState());
            resultMap.put("managerUUID",qualifiedProviders.getManagerUUID());
            resultMap.put("groupName",qualifiedProviders.getGroupName());
            resultMap.put("actionType","Task");
            resultMap.put("userUuid",qualifiedProviders.getManagerUUID());
        }

        return gson.toJson(resultMap);
    }

    @Override
    public String getRuleContext(RuleAction ruleAction) {
        Map<String,Object> resultMap=new HashMap<>();
        Gson gson=new Gson();
        if(ruleAction instanceof ChangeServiceAction){
            ChangeServiceAction action=(ChangeServiceAction) ruleAction;
            resultMap.put("derivedDeployed",action.getDerivedDeployed());
            resultMap.put("eligibleDeployableMembers",action.getEligibleDeployableMembers());
        }
        return gson.toJson(resultMap);
    }

}
