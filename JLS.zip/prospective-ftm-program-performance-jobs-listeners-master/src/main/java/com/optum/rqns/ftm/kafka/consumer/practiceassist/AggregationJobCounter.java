package com.optum.rqns.ftm.kafka.consumer.practiceassist;


import com.optum.rqns.ftm.util.ProviderJobStatusDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Collections;
import java.util.concurrent.atomic.AtomicInteger;

@Slf4j
@Service
public class AggregationJobCounter {

    @Autowired
    private RestTemplate restTemplate;

    @Value("${cacheDeleteUrlCTC}")
    private String cacheDeleteUrlCTC;

    @Value("${cacheDeleteUrlCTC}")
    private String cacheDeleteUrlELR;

    public AtomicInteger aggrJobCounter = new AtomicInteger(0);

    public void aggrJobStatusIs(String jobStatus) {
        String cacheStatusCTC = "";
        String cacheStatusELR = "";
        if (aggrJobCounter.incrementAndGet() >= 5) {
            try{
                aggrJobCounter.set(0);
                ProviderJobStatusDTO providerJobStatusDTO = new ProviderJobStatusDTO();
                providerJobStatusDTO.setMbrHospitalEvents("done");
                providerJobStatusDTO.setIsForceRefresh(false);
                providerJobStatusDTO.setMbrMedAdherence("done");
                providerJobStatusDTO.setMbrQuality("done");
                providerJobStatusDTO.setMbrSummary("done");
                providerJobStatusDTO.setMbrSuspect("done");
                final HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.APPLICATION_JSON);
                headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
                log.info("Starting to call cacheClear");
                HttpEntity<ProviderJobStatusDTO> entity = new HttpEntity<ProviderJobStatusDTO>(providerJobStatusDTO, headers);
                ResponseEntity<Object> clearCTCCacheResponse = restTemplate.postForEntity(cacheDeleteUrlCTC, entity, Object.class);
                ResponseEntity<Object> clearELRCacheResponse = restTemplate.postForEntity(cacheDeleteUrlELR, entity, Object.class);
                if(null != clearCTCCacheResponse) {
                    cacheStatusCTC = clearCTCCacheResponse.getStatusCode().toString();
                }
                if(null != clearELRCacheResponse) {
                    cacheStatusELR = clearELRCacheResponse.getStatusCode().toString();
                }
                log.info("Finished call cacheClear, cacheStatusCTC is "+ cacheStatusCTC + ", cacheStatusELR is" +cacheStatusELR);
            }
            catch (Exception ex){
                log.error("Exception occured while calling clear cache URL", ex);
            }
        } }
}

