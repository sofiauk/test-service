package com.optum.rqns.ftm.repository.commandcenter;


import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.HashMap;

@Repository
@Slf4j
@RequiredArgsConstructor
public class CommandCenterRepositoryImpl implements CommandCenterRepository{
    @Autowired
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    private final String DATA_MERGE_QUERY = "MERGE progperf.[CommandCenterPerformance] AS tgt  " +
            "   USING (  " +
            " SELECT  " +
            "   'All' AS providergroupid,  " +
            "   pg.state,  " +
            "   pg.clientname,  " +
            "   pg.lobname,  " +
            "   pg.region,  " +
            "   pg.programyear,  " +
            "   pg.durationvalue,  " +
            "   Sum(eligiblepreferredmembercount) eligiblepreferredmembercount,  " +
            "   Sum(eligibledeployablemembercount) eligibledeployablemembercount,  " +
            "   Min(durationstartdate) durationstartdate,  " +
            "   Max(durationenddate) durationenddate,  " +
            "   Max(eligiblemembercountlastupdated) eligiblemembercountlastupdated,  " +
            "   Sum(returnytdactual) returnytdactual,  " +
            "   Sum(returnytdtarget) returnytdtarget,  " +
            "   Sum(returnyetarget) returnyetarget ,  " +
            "   Sum(returnednetcnaytdactual) returnednetcnaytdactual,  " +
            "   Min(returnedstartdate) returnedstartdate,  " +
            "   Max(lastreturneddate) lastreturneddate,  " +
            "   Sum(currentweekreturnscount) currentweekreturnscount,  " +
            "   Sum(previousweekreturnscount) previousweekreturnscount,  " +
            "   Sum(nextweekforcastreturnscount) nextweekforcastreturnscount,  " +
            "   Sum(returnytdtargetvariance) returnytdtargetvariance,  " +
            "   Sum(returnyetargetvariance) returnyetargetvariance,  " +
            "   Sum(deployytdactual) deployytdactual,  " +
            "   Sum(deployytdtarget) deployytdtarget,  " +
            "   Sum(deployyetarget) deployyetarget,  " +
            "   Min(deploymentstartdate) deploymentstartdate,  " +
            "   Max(lastdeploymentdate) lastdeploymentdate,  " +
            "   Sum(currentweekdeploymentscount) currentweekdeploymentscount,  " +
            "   Sum(previousweekdeploymentscount) previousweekdeploymentscount,  " +
            "   Sum(nextweekforcastdeploymentscount) nextweekforcastdeploymentscount,  " +
            "   Sum(deployytdtargetvariance) deployytdtargetvariance,  " +
            "   Sum(deployyetargetvariance) deployyetargetvariance,  " +
            "   Sum(deploymentsopportunityassessmentcount) deploymentsopportunityassessmentcount,  " +
            "   Sum(returnsopportunityassessmentcount) returnsopportunityassessmentcount  " +
            " FROM  " +
            "   progperf.providergroupperformanceweekly pg  " +
            " WHERE  " +
            "   LEN(pg.state) > 0  " +
            "   AND LEN(pg.clientname) > 0  " +
            "   AND LEN(pg.lobname) > 0  " +
            "   AND LEN(pg.region) > 0  " +
            "   AND pg.ProgramYear = :ProgramYear " +
            "   AND  pg.DurationValue = (  SELECT TOP 1 DurationValue FROM ProgPerf.ProgramYearCalendar  " +
            "  WITH (NOLOCK) where  DurationType ='WEEK' and   " +
            "  StartDate <= (SELECT CAST( getUTCDate() AS Date )) AND " +
            "  EndDate >= (SELECT CAST( getUTCDate() AS Date )) and ProgramYear = :ProgramYear)  " +
            " GROUP BY  " +
            "   pg.state,  " +
            "   pg.clientname,  " +
            "   pg.lobname,  " +
            "   pg.region,  " +
            "   pg.programyear,  " +
            "   pg.durationvalue ) AS src ON  " +
            " ( tgt.[STATE] = src.[STATE]  " +
            "   AND tgt.clientname = src.clientname  " +
            "   AND tgt.lobname = src.lobname  " +
            "   AND tgt.programyear = src.programyear  " +
            "   AND tgt.durationvalue = src.durationvalue And tgt.region = src.region )  " +
            " WHEN MATCHED THEN  " +
            " UPDATE  " +
            " SET  " +
            "   tgt.eligiblepreferredmembercount = src.eligiblepreferredmembercount,  " +
            "   tgt.eligibledeployablemembercount = src.eligibledeployablemembercount,  " +
            "   tgt.durationstartdate = src.durationstartdate,  " +
            "   tgt.durationenddate = src.durationenddate,  " +
            "   tgt.eligiblemembercountlastupdated = src.eligiblemembercountlastupdated,  " +
            "   tgt.returnytdactual = src.returnytdactual,  " +
            "   tgt.returnytdtarget = src.returnytdtarget,  " +
            "   tgt.returnyetarget = src.returnyetarget,  " +
            "   tgt.returnednetcnaytdactual = src.returnednetcnaytdactual,  " +
            "   tgt.returnedstartdate = src.returnedstartdate,  " +
            "   tgt.lastreturneddate = src.lastreturneddate,  " +
            "   tgt.currentweekreturnscount = src.currentweekreturnscount,  " +
            "   tgt.previousweekreturnscount = src.previousweekreturnscount,  " +
            "   tgt.nextweekforcastreturnscount = src.nextweekforcastreturnscount,  " +
            "   tgt.returnytdtargetvariance = src.returnytdtargetvariance,  " +
            "   tgt.returnyetargetvariance = src.returnyetargetvariance,  " +
            "   tgt.deployytdactual = src.deployytdactual,  " +
            "   tgt.deployytdtarget = src.deployytdtarget,  " +
            "   tgt.deployyetarget = src.deployyetarget,  " +
            "   tgt.deploymentstartdate = src.deploymentstartdate,  " +
            "   tgt.lastdeploymentdate = src.lastdeploymentdate,  " +
            "   tgt.currentweekdeploymentscount = src.currentweekdeploymentscount,  " +
            "   tgt.previousweekdeploymentscount = src.previousweekdeploymentscount,  " +
            "   tgt.nextweekforcastdeploymentscount = src.nextweekforcastdeploymentscount,  " +
            "   tgt.deployytdtargetvariance = src.deployytdtargetvariance,  " +
            "   tgt.deployyetargetvariance = src.deployyetargetvariance,  " +
            "   tgt.deploymentsopportunityassessmentcount = src.deploymentsopportunityassessmentcount,  " +
            "   tgt.returnsopportunityassessmentcount = src.returnsopportunityassessmentcount,  " +
            "   tgt.region = src.region,  " +
            "   tgt.updateddate = getutcdate() ,  " +
            "   tgt.updatedby = 'RunCommandCenterDailyJob',  " +
            "   tgt.month= DateName(month,src.durationstartdate),  " +
            "        tgt.isLastWeekOfMonth = 1, tgt.iscurrentweekforperformance = 1  " +
            "   WHEN NOT MATCHED THEN  " +
            "   INSERT  " +
            "   ( providergroupid ,  " +
            "   state ,  " +
            "   servicelevel ,  " +
            "   clientname ,  " +
            "   lobname ,  " +
            "   programyear ,  " +
            "   durationvalue ,  " +
            "   iscurrentweekforperformance,  " +
            "   eligiblepreferredmembercount ,  " +
            "   eligibledeployablemembercount ,  " +
            "   durationstartdate ,  " +
            "   durationenddate ,  " +
            "   eligiblemembercountlastupdated ,  " +
            "   returnytdactual ,  " +
            "   returnytdtarget ,  " +
            "   returnyetarget ,  " +
            "   returnednetcnaytdactual ,  " +
            "   returnedstartdate ,  " +
            "   lastreturneddate ,  " +
            "   currentweekreturnscount ,  " +
            "   previousweekreturnscount ,  " +
            "   nextweekforcastreturnscount ,  " +
            "   returnytdtargetvariance ,  " +
            "   returnyetargetvariance ,  " +
            "   deployytdactual ,  " +
            "   deployytdtarget ,  " +
            "   deployyetarget ,  " +
            "   deploymentstartdate ,  " +
            "   lastdeploymentdate ,  " +
            "   currentweekdeploymentscount ,  " +
            "   previousweekdeploymentscount ,  " +
            "   nextweekforcastdeploymentscount ,  " +
            "   deployytdtargetvariance ,  " +
            "   deployyetargetvariance ,  " +
            "   deploymentsopportunityassessmentcount ,  " +
            "   returnsopportunityassessmentcount ,  " +
            "   region,  " +
            "   createddate ,  " +
            "   updateddate ,  " +
            "   createdby ,  " +
            "   updatedby,  " +
            "   isLastWeekOfMonth,  " +
            "   Month )  " +
            " VALUES ( src.providergroupid ,  " +
            " src.state ,  " +
            " 'All' ,  " +
            " src.clientname ,  " +
            " src.lobname ,  " +
            " src.programyear ,  " +
            " src.durationvalue ,  " +
            " 1,  " +
            " src.eligiblepreferredmembercount ,  " +
            " src.eligibledeployablemembercount ,  " +
            " src.durationstartdate ,  " +
            " src.durationenddate ,  " +
            " src.eligiblemembercountlastupdated ,  " +
            " src.returnytdactual ,  " +
            " src.returnytdtarget ,  " +
            " src.returnyetarget ,  " +
            " src.returnednetcnaytdactual ,  " +
            " src.returnedstartdate ,  " +
            " src.lastreturneddate ,  " +
            " src.currentweekreturnscount ,  " +
            " src.previousweekreturnscount ,  " +
            " src.nextweekforcastreturnscount ,  " +
            " src.returnytdtargetvariance ,  " +
            " src.returnyetargetvariance ,  " +
            " src.deployytdactual ,  " +
            " src.deployytdtarget ,  " +
            " src.deployyetarget ,  " +
            " src.deploymentstartdate ,  " +
            " src.lastdeploymentdate ,  " +
            " src.currentweekdeploymentscount ,  " +
            " src.previousweekdeploymentscount ,  " +
            " src.nextweekforcastdeploymentscount ,  " +
            " src.deployytdtargetvariance ,  " +
            " src.deployyetargetvariance ,  " +
            " src.deploymentsopportunityassessmentcount ,  " +
            " src.returnsopportunityassessmentcount ,  " +
            " src.region,  " +
            " getutcdate() ,  " +
            " getutcdate() ,  " +
            " 'RunCommandCenterDailyJob' ,  " +
            " 'RunCommandCenterDailyJob',  " +
            " 1,  " +
            " DateName(month,src.durationstartdate)); ";

    private final String CALCULATE_CC_PERFORMANCE_DEPLOY_AGGREGATE_QUERY = "MERGE progperf.[commandcenterperformanceaggregates] AS tgt  using (  SELECT   b.isnewfordeployment,   a.project_year AS programyear,   (   CASE    WHEN a.deploydate < (mc.value) THEN    CASE     WHEN b.isnewfordeployment = 1 THEN 'ReturnRates_NewFirstHalfOfYearDeployCount'     ELSE 'ReturnRates_ExistingFirstHalfOfYearDeployCount'    END    ELSE    CASE     WHEN b.isnewfordeployment = 1 THEN 'ReturnRates_NewSecondHalfOfYearDeployCount'     ELSE 'ReturnRates_ExistingSecondHalfOfYearDeployCount'    END   END ) NAME,   Isnull(Sum(a.deriveddeployed),0) AS value  FROM   progperf.memberassessment a,   progperf.ProviderGroupExtended b,   progperf.masterconfiguration mc  WHERE   a.prov_group_id + a.providerstate = b.providergroupid + b.state   AND a.deriveddeployed = 1   AND a.chart_dup_id = 1   AND a.project_year = :ProgramYear  AND b.programyear =a.project_year And b.isnewfordeployment IS NOT NULL And b.isnewfordeployment !='' AND a.recordchangetype <> 'DELETED'   AND mc.code = 'CommandCenter_Performance_Aggregate_Date'  GROUP BY   b.isnewfordeployment,   a.project_year,   (   CASE    WHEN a.deploydate < (mc.value) THEN    CASE     WHEN b.isnewfordeployment = 1 THEN 'ReturnRates_NewFirstHalfOfYearDeployCount'     ELSE 'ReturnRates_ExistingFirstHalfOfYearDeployCount'    END    ELSE    CASE     WHEN b.isnewfordeployment = 1 THEN 'ReturnRates_NewSecondHalfOfYearDeployCount'     ELSE 'ReturnRates_ExistingSecondHalfOfYearDeployCount'    END   END ) ) AS src ON ( tgt.NAME = src.NAME  AND tgt.programyear = src.programyear ) WHEN matched THEN UPDATE SET  tgt.value = src.value,  tgt.updatedby = 'RunCommandCenterAggregates',  tgt.updateddate = Getutcdate()  WHEN NOT matched THEN INSERT  ( NAME,  value,  programyear,  updatedby,  updateddate) VALUES ( src.NAME, src.value, src.programyear, 'RunCommandCenterAggregates', Getutcdate() ); ";
    private final String CALCULATE_CC_PERFORMANCE_RETURNS_AGGREGATE_QUERY = "MERGE progperf.[commandcenterperformanceaggregates] AS tgt  using (   SELECT   b.isnewfordeployment,   a.project_year AS programyear,   (   CASE    WHEN a.deploydate < (mc.value) THEN    CASE     WHEN b.isnewfordeployment = 1 THEN 'ReturnRates_NewFirstHalfOfYearReturnCount'     ELSE 'ReturnRates_ExistingFirstHalfOfYearReturnCount'    END    ELSE    CASE     WHEN b.isnewfordeployment = 1 THEN 'ReturnRates_NewSecondHalfOfYearReturnCount'     ELSE 'ReturnRates_ExistingSecondHalfOfYearReturnCount'    END   END ) NAME,   Isnull(Sum(a.returnednetcna),0) AS value  FROM   progperf.memberassessment a,   progperf.ProviderGroupExtended b,   progperf.masterconfiguration mc  WHERE   a.prov_group_id + a.providerstate = b.providergroupid + b.state   AND a.deriveddeployed = 1   AND a.chart_dup_id = 1   AND a.project_year = :ProgramYear  AND b.programyear =a.project_year And b.isnewfordeployment IS NOT NULL And b.isnewfordeployment !='' AND a.recordchangetype <> 'DELETED'   AND mc.code = 'CommandCenter_Performance_Aggregate_Date'  GROUP BY   b.isnewfordeployment,   a.project_year,   (   CASE    WHEN a.deploydate < mc.value THEN    CASE     WHEN b.isnewfordeployment = 1 THEN 'ReturnRates_NewFirstHalfOfYearReturnCount'     ELSE 'ReturnRates_ExistingFirstHalfOfYearReturnCount'    END    ELSE    CASE     WHEN b.isnewfordeployment = 1 THEN 'ReturnRates_NewSecondHalfOfYearReturnCount'     ELSE 'ReturnRates_ExistingSecondHalfOfYearReturnCount'    END   END )) AS src ON ( tgt.NAME = src.NAME  AND tgt.programyear = src.programyear ) WHEN matched THEN UPDATE SET  tgt.value = src.value,  tgt.updatedby = 'RunCommandCenterAggregates',  tgt.updateddate = Getutcdate()  WHEN NOT matched THEN INSERT  ( NAME,  value,  programyear,  updatedby,  updateddate) VALUES ( src.NAME, src.value, src.programyear, 'RunCommandCenterAggregates', Getutcdate() ); ";

   @Override
   public Long mergeDataFromProgPerfWeeklyToCommandCenter(Integer programYear) {
       HashMap map = new HashMap<String,Object>();
       map.put("ProgramYear",programYear);
       return (long)namedParameterJdbcTemplate.update(DATA_MERGE_QUERY,map);
    }

    @Override
    public Long calculateCCPerformance(Integer programYear) {
        HashMap map = new HashMap<String,Object>();
        map.put("ProgramYear",programYear);
        return (long)namedParameterJdbcTemplate.update(CALCULATE_CC_PERFORMANCE_DEPLOY_AGGREGATE_QUERY,map) + (long)namedParameterJdbcTemplate.update(CALCULATE_CC_PERFORMANCE_RETURNS_AGGREGATE_QUERY,map);
    }

}
