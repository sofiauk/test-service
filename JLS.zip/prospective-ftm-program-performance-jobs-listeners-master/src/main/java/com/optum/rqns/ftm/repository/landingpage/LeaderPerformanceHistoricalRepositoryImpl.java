package com.optum.rqns.ftm.repository.landingpage;

import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.model.ProgramYearCalendarDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Repository
@Slf4j
public class LeaderPerformanceHistoricalRepositoryImpl implements LeaderPerformanceHistoricalRepository {

    private static final String UPDATED_BY = "UpdatedBy";
    private static final String PROGRAM_YEAR = "ProgramYear";
    private static final String ELSE_CONDITION = " else NULL ";
    private static final String OWNER_UUID = "OwnerUUID";
    private static final String SERVICE_LEVEL = "ServiceLevel";
    private static final String REPORTERS = "Reporters";
    private static final String DURATION_VALUE = "DurationValue";
    private static final String DURATION_START_DATE = "DurationStartDate";
    private static final String DURATION_END_DATE = "DurationEndDate";
    private static final String IS_CURRENT_WEEK = "IsCurrentWeek";
    private static final String EMPTY_STRING = "";

    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;


    private static final String SELECT_PROGRAM_YEARS_DURATIONS = " select " +
            " pyc.ProgramYear, " +
            " pyc.DurationValue , " +
            " pyc.StartDate , " +
            " pyc.EndDate, " +
            " pyc.DurationType, " +
            " pyc.ID " +
            "from " +
            " ProgPerf.ProgramYearCalendar pyc WITH (NOLOCK) " +
            "where " +
            " pyc.ProgramYear in( :ProgramYear) " +
            " and pyc.EndDate <= getutcdate() " +
            " and pyc.DurationType = 'WEEK' " +
            " and pyc.DurationValue not in ( " +
            " SELECT " +
            "  TOP 1 DurationValue " +
            " FROM " +
            "  ProgPerf.ProgramYearCalendar WITH (NOLOCK) " +
            " where " +
            "  DurationType = 'WEEK' " +
            "  and StartDate <= ( " +
            "  SELECT " +
            "   CAST( getUTCDate() AS Date )) " +
            "   AND EndDate >= ( " +
            "   SELECT " +
            "    CAST( getUTCDate() AS Date )) " +
            "    and ProgramYear = :ProgramYear) " +
            "order by " +
            " pyc.StartDate asc";


    private static final String LAST_SUCCESSFUL_RUN_DATE = "select " +
            " convert(varchar, " +
            " min(jrc.lastsuccessfulrundate), " +
            " 23) as updateddate " +
            "from " +
            " PROGPERF.JOBRUNCONFIGURATION jrc with (nolock) " +
            "where " +
            " jrc.JobName in ('" +
            JobName.LOAD_HISTORICAL_LEADER_PERFORMANCE.getValue() + "')";

    private static final String MEMBER_ASSESSMENT_QUERY_FILTER = " and ma.UpdatedDate >= (" + LAST_SUCCESSFUL_RUN_DATE + ")";

    private static final String SELECT_PREVIOUS_YEAR_LAST_WEEK_DURATION = "SELECT " +
            " TOP 1 pyc.ProgramYear, " +
            " pyc.DurationValue , " +
            " pyc.StartDate , " +
            " pyc.EndDate, " +
            " pyc.DurationType, " +
            " pyc.ID " +
            "FROM " +
            " ProgPerf.ProgramYearCalendar pyc WITH (NOLOCK) " +
            "WHERE " +
            " pyc.ProgramYear in(:ProgramYear-1) " +
            " AND pyc.DurationType = 'WEEK' " +
            "ORDER by " +
            " EndDate desc ";

    String CURRENT_WEEK_DURATION_AND_PROGRAM_YEAR = "SELECT " +
            "  TOP 1  ProgramYear,  DurationValue ,StartDate ,EndDate, DurationType, ID       " +
            " FROM " +
            "  ProgPerf.ProgramYearCalendar WITH (NOLOCK) " +
            " where " +
            "  DurationType = 'WEEK' " +
            "  and StartDate <= ( " +
            "  SELECT " +
            "   CAST( getUTCDate() AS Date )) " +
            "   AND EndDate >= ( " +
            "   SELECT " +
            "    CAST( getUTCDate() AS Date )) " +
            "    and ProgramYear = :ProgramYear ";

    String LEADERS_HISTORICAL_PERFORMANCE_QUERY = "Merge ProgPerf.LeaderPerformance as tgt " +
            " using ( " +
            "SELECT " +
            " count(*) as recCount, " +
            " lp.State, " +
            " lp.Region, " +
            " lp.ClientName, " +
            " lp.lob, " +
            " lp.servicelevel, " +
            " lp.ProgramYear, " +
            " lp.DurationValue, " +
            " min(lp.DurationStartDate) as DurationStartDate, " +
            " max(lp.DurationEndDate) as DurationEndDate, " +
            " sum(lp.DeployActualPerf) as DeployActualPerf, " +
            " sum(lp.ReturnNetCnaActualPerf) as ReturnNetCnaActualPerf, " +
            " sum(lp.CompletedAssessmentActualPerf) as CompletedAssessmentActualPerf " +
            "from " +
            " ProgPerf.LeaderPerformance lp with (nolock) " +
            "WHERE " +
            "  lp.IsActive = 1 "+
            " and LEN(lp.State) > 0 " +
            " and LEN(lp.Lob)> 0 " +
            " and LEN(lp.DurationValue)> 0 " +
            " and LEN(lp.ClientName)> 0 " +
            " AND LEN(lp.UUID) > 0 " +
            " AND len(lp.region) > 0 " +
            " and lp.UUID in (:Reporters) " +
            " and lp.ProgramYear =:ProgramYear " +
            " and lp.DurationValue =:DurationValue " +
            "GROUP by " +
            " lp.State, " +
            " lp.Region, " +
            " lp.ClientName, " +
            " lp.Lob, " +
            " lp.servicelevel, " +
            " lp.DurationValue, " +
            " lp.ProgramYear ) as src on " +
            "( src.Region = tgt.Region " +
            " and src.State = tgt.State " +
            " and src.ClientName = tgt.ClientName " +
            " and src.Lob = tgt.Lob " +
            " and src.ServiceLevel = tgt.ServiceLevel " +
            " and src.ProgramYear = tgt.ProgramYear " +
            " and src.DurationValue = tgt.DurationValue " +
            " and tgt.UUID = :OwnerUUID ) " +
            "when MATCHED THEN " +
            "update " +
            "set " +
            " tgt.DurationStartDate = src.DurationStartDate, " +
            " tgt.DurationEndDate = src.DurationEndDate, " +
            " tgt.isCurrentWeek = :IsCurrentWeek, " +
            " tgt.IsActive =1, " +
            " tgt.DeployActualPerf = src.DeployActualPerf, " +
            " tgt.ReturnNetCnaActualPerf = src.ReturnNetCnaActualPerf, " +
            " tgt.CompletedAssessmentActualPerf = src.CompletedAssessmentActualPerf, " +
            " tgt.UpdatedBy = :UpdatedBy, " +
            " tgt.UpdatedDate = GETUTCDATE() " +
            " WHEN Not MATCHED THEN " +
            "INSERT " +
            " (UUID, " +
            " Region, " +
            " State, " +
            " ClientId, " +
            " ClientName, " +
            " LOB, " +
            " ServiceLevel, " +
            " ProgramYear, " +
            " DurationValue, " +
            " DurationStartDate, " +
            " DurationEndDate, " +
            " IsCurrentWeek, " +
            " DeployActualPerf, " +
            " ReturnNetCnaActualPerf, " +
            " CompletedAssessmentActualPerf, " +
            " updatedBy, " +
            " updatedDate, " +
            " createdDate, " +
            " createdBy, " +
            " IsActive) " +
            "VALUES (:OwnerUUID , " +
            "src.region, " +
            "src.State, " +
            "NULL, " +
            "src.ClientName, " +
            "src.Lob, " +
            "src.ServiceLevel, " +
            "src.ProgramYear , " +
            "src.DurationValue, " +
            "src.DurationStartDate, " +
            "src.DurationEndDate, " +
            ":IsCurrentWeek, " +
            "src.DeployActualPerf, " +
            "src.ReturnNetCnaActualPerf, " +
            "src.CompletedAssessmentActualPerf, " +
            ":UpdatedBy, " +
            "GETUTCDATE() , " +
            "GETUTCDATE() , " +
            ":UpdatedBy, " +
            "1);";

    String HISTORICAL_LEADER_PERF_DATA_LOAD = " with rs as ( " +
            "SELECT " +
            " pgpw.Region, " +
            " pgpw.State, " +
            " pgpw.ClientName, " +
            " pgpw.LobName, " +
            " a.servicelevel, " +
            " pgpw.ProgramYear, " +
            " pgpw.DurationValue, " +
            " sum(ReturnedNetCnaYtdActual) ReturnNetCnaActualPerf, " +
            " sum(DeployYTDActual) DeployActualPerf, " +
            " sum(Completed) CompletedAssessmentActualPerf " +
            "from " +
            " ProgPerf.ProviderGroupPerformanceWeekly pgpw with (nolock) " +
            "inner join ProgPerf.Accounts a with (nolock) on " +
            " (pgpw.ProviderGroupID = a.groupId " +
            "  and pgpw.State = a.State) " +
            "where " +
            " pgpw.DurationValue = :DurationValue " +
            " and pgpw.ProgramYear = :ProgramYear " +
            " and LEN(pgpw.State) > 0 " +
            " and LEN(pgpw.LobName)> 0 " +
            " and LEN(pgpw.DurationValue)> 0 " +
            " and LEN(pgpw.ClientName)> 0 " +
            " and LEN(pgpw.ProviderGroupID) > 0 " +
            " and len(pgpw.region) > 0 " +
            " and a.ServiceLevel in ( " +
            " select " +
            "  distinct ServiceLevel " +
            " from " +
            "  ProgPerf.Accounts a " +
            " where " +
            "  ServiceLevel <> '' ) " +
            "GROUP by " +
            " pgpw.State, " +
            " pgpw.Region, " +
            " pgpw.ClientName, " +
            " pgpw.LobName, " +
            " a.servicelevel, " +
            " pgpw.ProgramYear, " +
            " pgpw.DurationValue ) Merge ProgPerf.LeaderPerformance as target " +
            " using ( " +
            "select " +
            " rs.* " +
            "from " +
            " rs " +
            " )src on " +
            "( src.Region = target.Region " +
            " and src.State = target.State " +
            " and src.ClientName = target.ClientName " +
            " and src.LobName = target.Lob " +
            " and src.ServiceLevel = target.ServiceLevel " +
            " and src.ProgramYear = target.ProgramYear " +
            " and src.DurationValue = target.DurationValue " +
            " and target.UUID = :OwnerUUID ) " +
            "when MATCHED THEN " +
            "update " +
            "set " +
            " target.DeployActualPerf = src.DeployActualPerf, " +
            " target.ReturnNetCnaActualPerf = src.ReturnNetCnaActualPerf, " +
            " target.CompletedAssessmentActualPerf = src.CompletedAssessmentActualPerf, " +
            " target.DurationStartDate = :DurationStartDate, " +
            " target.DurationEndDate = :DurationEndDate, " +
            " target.UpdatedBy = :UpdatedBy, " +
            " target.IsCurrentWeek =:IsCurrentWeek, " +
            " target.IsActive = 1 , " +
            " target.UpdatedDate = GETUTCDATE() " +
            " WHEN Not MATCHED THEN " +
            "INSERT " +
            " (UUID, " +
            " Region, " +
            " State, " +
            " ClientId, " +
            " ClientName, " +
            " LOB, " +
            " ServiceLevel, " +
            " ProgramYear, " +
            " DurationValue, " +
            " DurationStartDate, " +
            " DurationEndDate, " +
            " IsCurrentWeek, " +
            " IsActive, " +
            " DeployActualPerf, " +
            " ReturnNetCnaActualPerf, " +
            " CompletedAssessmentActualPerf, " +
            " updatedBy, " +
            " updatedDate, " +
            " createdDate, " +
            " createdBy) " +
            "VALUES (:OwnerUUID , " +
            "src.region, " +
            "src.State, " +
            "NULL , " +
            "src.ClientName, " +
            "src.LobName, " +
            "src.ServiceLevel, " +
            "src.ProgramYear , " +
            ":DurationValue, " +
            ":DurationStartDate, " +
            ":DurationEndDate, " +
            ":IsCurrentWeek, " +
            "1, " +
            "src.DeployActualPerf, " +
            "src.ReturnNetCnaActualPerf, " +
            "src.CompletedAssessmentActualPerf, " +
            ":UpdatedBy, " +
            "GETUTCDATE() , " +
            "GETUTCDATE() , " +
            ":UpdatedBy);";

    String HISTORICAL_ICS_LEADER_PERFORMANCE ="with rs as ( " +
            "SELECT " +
            " DISTINCT a.GroupId, " +
            " a.State , " +
            " a.ServiceLevel " +
            "from " +
            " ProgPerf.AccountOwner ao with (nolock) " +
            "join ProgPerf.Accounts a with (nolock) on " +
            " a.AccountId = ao.AccountId " +
            "where " +
            " ao.OwnerUUID in( :OwnerUUID) " +
            " and a.ServiceLevel = :ServiceLevel ) , " +
            "resultSet as ( " +
            "SELECT " +
            " pgpw.State, " +
            " pgpw.Region, " +
            " pgpw.ClientName, " +
            " pgpw.LobName as lob, " +
            " rs.servicelevel, " +
            " pgpw.ProgramYear, " +
            " pgpw.DurationValue, " +
            " sum(pgpw.DeployYTDActual) as DeployActualPerf, " +
            " sum(pgpw.ReturnedNetCnaYtdActual) as ReturnNetCnaActualPerf, " +
            " sum(pgpw.Completed) as CompletedAssessmentActualPerf " +
            "from " +
            " ProgPerf.ProviderGroupPerformanceWeekly pgpw with (nolock) , " +
            " rs " +
            "where " +
            " pgpw.ProviderGroupID = rs.GroupId " +
            " and pgpw.State = rs.state " +
            " and pgpw.DurationValue = :DurationValue " +
            " and pgpw.ProgramYear = :ProgramYear " +
            " and LEN(pgpw.State) > 0 " +
            "  and LEN(pgpw.LobName)> 0 " +
            "   and LEN(pgpw.DurationValue)> 0 " +
            "    and LEN(pgpw.ClientName)> 0 " +
            "     AND LEN(pgpw.ProviderGroupID) > 0 " +
            "      AND len(pgpw.region) > 0 " +
            "     GROUP by " +
            "      pgpw.State, " +
            "      pgpw.Region, " +
            "      pgpw.ClientName, " +
            "      pgpw.LobName, " +
            "      rs.servicelevel, " +
            "      pgpw.DurationValue, " +
            "      pgpw.ProgramYear) " +
            "  Merge ProgPerf.LeaderPerformance as tgt " +
            " using ( " +
            " select " +
            " resultset.* " +
            "from " +
            " resultset " +
            " ) as src on " +
            " ( src.Region = tgt.Region " +
            "  and src.State = tgt.State " +
            "  and src.ClientName = tgt.ClientName " +
            "  and src.Lob = tgt.Lob " +
            "  and src.ServiceLevel = tgt.ServiceLevel " +
            "  and src.ProgramYear = tgt.ProgramYear " +
            "  and src.DurationValue = tgt.DurationValue " +
            "  and tgt.UUID = :OwnerUUID ) " +
            " when MATCHED THEN " +
            "update " +
            "set " +
            " tgt.DeployActualPerf = src.DeployActualPerf, " +
            " tgt.ReturnNetCnaActualPerf = src.ReturnNetCnaActualPerf, " +
            " tgt.CompletedAssessmentActualPerf = src.CompletedAssessmentActualPerf, " +
            " tgt.DurationStartDate = :DurationStartDate, " +
            " tgt.DurationEndDate = :DurationEndDate, " +
            " tgt.isCurrentWeek =:IsCurrentWeek, " +
            " tgt.isActive = 1 , " +
            " tgt.UpdatedBy = :UpdatedBy , " +
            " tgt.UpdatedDate = GETUTCDATE() " +
            " WHEN Not MATCHED THEN " +
            "INSERT " +
            " (UUID, " +
            " Region, " +
            " State, " +
            " ClientId, " +
            " ClientName, " +
            " LOB, " +
            " ServiceLevel, " +
            " ProgramYear, " +
            " DurationValue, " +
            " DurationStartDate, " +
            " DurationEndDate, " +
            " IsCurrentWeek, " +
            " DeployActualPerf, " +
            " ReturnNetCnaActualPerf, " +
            " CompletedAssessmentActualPerf, " +
            " updatedBy, " +
            " updatedDate, " +
            " createdDate, " +
            " createdBy, " +
            " IsActive) " +
            "VALUES (:OwnerUUID , " +
            "src.region, " +
            "src.State, " +
            "NULL, " +
            "src.ClientName, " +
            "src.Lob, " +
            "src.ServiceLevel, " +
            "src.ProgramYear , " +
            "src.DurationValue, " +
            ":DurationStartDate, " +
            ":DurationEndDate, " +
            ":IsCurrentWeek, " +
            "src.DeployActualPerf, " +
            "src.ReturnNetCnaActualPerf, " +
            "src.CompletedAssessmentActualPerf, " +
            ":UpdatedBy, " +
            "GETUTCDATE() , " +
            "GETUTCDATE() , " +
            ":UpdatedBy, " +
            "1);";

    String IC_GOAL_UPDATE_LEADER_PERFORMANCE = "  with rs as ( " +
            "SELECT " +
            " DISTINCT a.GroupId, " +
            " a.State , " +
            " a.ServiceLevel " +
            "from " +
            " ProgPerf.AccountOwner ao with (nolock) " +
            "join ProgPerf.Accounts a on " +
            " a.AccountId = ao.AccountId " +
            "where " +
            " ao.OwnerUUID in( :OwnerUUID) " +
            " and a.ServiceLevel = :ServiceLevel ), " +
            "gc as ( " +
            "SELECT " +
            " pgp.ClientName, " +
            " case " +
            "  when sum(DeployYETarget) > 0 then sum(ReturnedNetCnaYtdActual)  " +
            ELSE_CONDITION +
            " end ReturnNetCnaActualGoal, " +
            " case " +
            "  when sum(DeployYETarget) > 0 then sum(Completed) " +
            ELSE_CONDITION +
            " end CompletedAssessmentActualGoal, " +
            " case " +
            "  when sum(DeployYETarget) > 0 then sum(DeployYTDActual) " +
            ELSE_CONDITION +
            " end DeployActualGoal " +
            "FROM " +
            " ProgPerf.ProviderGroupPerformanceWeekly pgp with (nolock) , " +
            " rs " +
            "where " +
            "  pgp.DurationValue = :DurationValue " +
            " and pgp.ProgramYear = :ProgramYear " +
            " and pgp.ServiceLevel = rs.ServiceLevel " +
            " and pgp.ProviderGroupID = rs.GroupId " +
            " and pgp.State = rs.state " +
            " and LEN(pgp.State) > 0 " +
            "  and LEN(pgp.LobName)> 0 " +
            "   and LEN(pgp.DurationValue)> 0 " +
            "    and LEN(pgp.ClientName)> 0 " +
            "     and LEN(pgp.ProviderGroupID) > 0 " +
            "      and len(pgp.region) > 0 " +
            "     GROUP by " +
            "      ClientName) Merge ProgPerf.LeaderPerformance as tgt " +
            " using ( " +
            "SELECT " +
            " pgpw.State, " +
            " pgpw.Region, " +
            " pgpw.ClientName, " +
            " pgpw.LobName as lob, " +
            " count(*) as recCount, " +
            " rs.servicelevel, " +
            " pgpw.ProgramYear, " +
            " pgpw.DurationValue, " +
            " ReturnNetCnaActualGoal, " +
            " CompletedAssessmentActualGoal, " +
            " DeployActualGoal " +
            "from " +
            "  ProgPerf.ProviderGroupPerformanceWeekly pgpw with (nolock), " +
            " rs, gc " +
            "WHERE pgpw.ProviderGroupID = rs.GroupId " +
            "and pgpw.State = rs.state " +
            "and gc.ClientName = pgpw.ClientName " +
            "and pgpw.DurationValue = :DurationValue " +
            "and pgpw.ProgramYear = :ProgramYear " +
            " and LEN(pgpw.State) > 0 " +
            "and LEN(pgpw.LobName)> 0 " +
            "and LEN(pgpw.DurationValue)> 0 " +
            "and LEN(pgpw.ClientName)> 0 " +
            "AND LEN(pgpw.ProviderGroupID) > 0 " +
            "AND len(pgpw.region) > 0 " +
            "      GROUP by " +
            "       pgpw.State, " +
            "       pgpw.Region, " +
            "       pgpw.ClientName, " +
            "       pgpw.LobName, " +
            "       rs.servicelevel, " +
            "       pgpw.DurationValue, " +
            "       pgpw.ProgramYear, " +
            "       ReturnNetCnaActualGoal, " +
            "       CompletedAssessmentActualGoal, " +
            "       DeployActualGoal) as src on " +
            "( src.Region = tgt.Region " +
            " and src.State = tgt.State " +
            " and src.ClientName = tgt.ClientName " +
            " and src.Lob = tgt.Lob " +
            " and src.ServiceLevel = tgt.ServiceLevel " +
            " and src.ProgramYear = tgt.ProgramYear " +
            " and src.DurationValue = tgt.DurationValue " +
            " and tgt.UUID = :OwnerUUID ) " +
            "when MATCHED THEN " +
            "update " +
            "set " +
            " tgt.DeployActualGoal = src.DeployActualGoal, " +
            " tgt.ReturnNetCnaActualGoal = src.ReturnNetCnaActualGoal, " +
            " tgt.CompletedAssessmentActualGoal = src.CompletedAssessmentActualGoal, " +
            " tgt.UpdatedBy = :UpdatedBy, " +
            " tgt.UpdatedDate = GETUTCDATE();";

    String NATIONAL_LEVEL_FOR_ALL_CLIENTS_LOB_REGION_STATE_SERVICE_LEVELS="with rs as ( " +
            "SELECT " +
            " 'ALL' as Region, " +
            " 'ALL' as State, " +
            " 'ALL' as ClientName, " +
            " 'ALL' as LobName, " +
            " 'PSC-B,PSC-P,HCA' as servicelevel, " +
            " pgpw.ProgramYear, " +
            " pgpw.DurationValue, " +
            " sum(ReturnedNetCnaYtdActual) ReturnNetCnaActualPerf, " +
            " sum(DeployYTDActual) DeployActualPerf, " +
            " sum(Completed) CompletedAssessmentActualPerf " +
            "from " +
            " ProgPerf.ProviderGroupPerformanceWeekly pgpw with (nolock) , " +
            " ProgPerf.Accounts a with (nolock) " +
            "where " +
            " pgpw.ProviderGroupID = a.groupId " +
            " and pgpw.State = a.State " +
            " and pgpw.DurationValue = :DurationValue " +
            " and pgpw.ProgramYear = :ProgramYear " +
            " and LEN(pgpw.State) > 0 " +
            " and LEN(pgpw.LobName)> 0 " +
            " and LEN(pgpw.DurationValue)> 0 " +
            " and LEN(pgpw.ClientName)> 0 " +
            " and LEN(pgpw.ProviderGroupID) > 0 " +
            " and len(pgpw.region) > 0 " +
            " and a .ServiceLevel in ('HCA', 'PSC-P', 'PSC-B') " +
            "GROUP by " +
            " pgpw.ProgramYear, " +
            " pgpw.DurationValue ) " +
            " Merge ProgPerf.LeaderPerformance as target " +
            " using (  " +
            "select " +
            " rs.* " +
            "from " +
            " rs " +
            " ) src on " +
            " ( src.Region  = target.Region " +
            " and src.State = target.State " +
            " and src.ClientName = target.ClientName " +
            " and src.LobName = target.Lob " +
            " and src.ServiceLevel = target.ServiceLevel " +
            " and src.ProgramYear = target.ProgramYear " +
            " and src.DurationValue = target.DurationValue " +
            " and target.UUID = :OwnerUUID ) " +
            "when MATCHED THEN " +
            "update " +
            "set " +
            " target.DeployActualPerf = src.DeployActualPerf, " +
            " target.ReturnNetCnaActualPerf = src.ReturnNetCnaActualPerf, " +
            " target.CompletedAssessmentActualPerf = src.CompletedAssessmentActualPerf, " +
            " target.DurationStartDate = :DurationStartDate, " +
            " target.DurationEndDate = :DurationEndDate, " +
            " target.UpdatedBy = :UpdatedBy, " +
            " target.IsCurrentWeek =:IsCurrentWeek, " +
            " target.IsActive = 1, " +
            " target.UpdatedDate = GETUTCDATE() " +
            " WHEN Not MATCHED THEN " +
            "INSERT " +
            " (UUID, " +
            " Region, " +
            " State, " +
            " ClientId, " +
            " ClientName, " +
            " LOB, " +
            " ServiceLevel, " +
            " ProgramYear, " +
            " DurationValue, " +
            " DurationStartDate, " +
            " DurationEndDate, " +
            " IsCurrentWeek, " +
            " IsActive, " +
            " DeployActualPerf, " +
            " ReturnNetCnaActualPerf, " +
            " CompletedAssessmentActualPerf, " +
            " updatedBy, " +
            " updatedDate, " +
            " createdDate, " +
            " createdBy) " +
            "VALUES (:OwnerUUID , " +
            "src.region, " +
            "src.State, " +
            "NULL , " +
            "src.ClientName, " +
            "src.LobName, " +
            "src.ServiceLevel, " +
            "src.ProgramYear , " +
            ":DurationValue, " +
            ":DurationStartDate, " +
            ":DurationEndDate, " +
            ":IsCurrentWeek, " +
            "1, " +
            "src.DeployActualPerf, " +
            "src.ReturnNetCnaActualPerf, " +
            "src.CompletedAssessmentActualPerf, " +
            ":UpdatedBy, " +
            "GETUTCDATE() , " +
            "GETUTCDATE() , " +
            ":UpdatedBy);";

    public LeaderPerformanceHistoricalRepositoryImpl(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
        this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
    }

    @Override
    public List<ProgramYearCalendarDTO> getAllProgramYearsDurations(int programYear) {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put(PROGRAM_YEAR, programYear);
        return namedParameterJdbcTemplate.query(SELECT_PROGRAM_YEARS_DURATIONS, paramMap, BeanPropertyRowMapper.newInstance(ProgramYearCalendarDTO.class));
    }

    @Override
    public ProgramYearCalendarDTO getPrevoiusYearLastWeekDuration(int programYear) {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put(PROGRAM_YEAR, programYear);
        log.info("Previous Program Year {}" ,programYear);
        return namedParameterJdbcTemplate.queryForObject(SELECT_PREVIOUS_YEAR_LAST_WEEK_DURATION, paramMap, BeanPropertyRowMapper.newInstance(ProgramYearCalendarDTO.class));
    }

    @Override
    public ProgramYearCalendarDTO getCurrentWeekDurationForProgramyear(int programYear) {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put(PROGRAM_YEAR, programYear);
        log.info("Current Program Year {}" ,programYear);
        return namedParameterJdbcTemplate.queryForObject(CURRENT_WEEK_DURATION_AND_PROGRAM_YEAR, paramMap, BeanPropertyRowMapper.newInstance(ProgramYearCalendarDTO.class));
    }

    @Override
    public int loadLeadersHistoricalLeaderPerformanceData(String userId, List<String> totalReporters, ProgramYearCalendarDTO programYearCalendarDTO, int isCurretnWeek, boolean isAllProviderGroups) {
        /*String query;
        if (isAllProviderGroups) {
            query = String.format(LEADERS_HISTORICAL_PERFORMANCE_QUERY, EMPTY_STRING);
        } else {
            query = String.format(LEADERS_HISTORICAL_PERFORMANCE_QUERY, MEMBER_ASSESSMENT_QUERY_FILTER);
        }*/
        log.info("Leader Name {} DurationValue {} totalReporters {} ", userId, programYearCalendarDTO.getDurationValue(), totalReporters);
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put(PROGRAM_YEAR, programYearCalendarDTO.getProgramYear());
        paramMap.put(IS_CURRENT_WEEK, isCurretnWeek);
        paramMap.put(OWNER_UUID, userId);
        paramMap.put(REPORTERS, Objects.isNull(totalReporters) ? "" : totalReporters);
        paramMap.put(DURATION_VALUE, programYearCalendarDTO.getDurationValue());
        paramMap.put(UPDATED_BY, JobName.LOAD_HISTORICAL_LEADER_PERFORMANCE.getValue());
        return namedParameterJdbcTemplate.update(LEADERS_HISTORICAL_PERFORMANCE_QUERY, paramMap);
    }

    @Override
    public int loadHistoricalICPerformanceData(String userId, String serviceLevel, ProgramYearCalendarDTO programYearCalendarDTO, int isCurrentWeek, boolean isAllProviderGroups) {
       /* String query;
        if (isAllProviderGroups) {
            query = String.format(HISTORICAL_ICS_LEADER_PERFORMANCE, EMPTY_STRING);
        } else {
            query = String.format(HISTORICAL_ICS_LEADER_PERFORMANCE, MEMBER_ASSESSMENT_QUERY_FILTER);
        }*/
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put(IS_CURRENT_WEEK, isCurrentWeek);
        paramMap.put(SERVICE_LEVEL, serviceLevel);
        paramMap.put(PROGRAM_YEAR, programYearCalendarDTO.getProgramYear());
        paramMap.put(DURATION_VALUE, programYearCalendarDTO.getDurationValue());
        paramMap.put(UPDATED_BY, JobName.LOAD_HISTORICAL_LEADER_PERFORMANCE.getValue());
        paramMap.put(DURATION_START_DATE, programYearCalendarDTO.getStartDate().toString());
        paramMap.put(DURATION_END_DATE, programYearCalendarDTO.getEndDate().toString());
        paramMap.put(OWNER_UUID, userId);
        return namedParameterJdbcTemplate.update(HISTORICAL_ICS_LEADER_PERFORMANCE, paramMap);
    }

    @Override
    public long loadHistoricalLeaderPerformance(ProgramYearCalendarDTO programYearCalendarDTO, int isCurrentWeek, boolean isAllProviderGroups) {
       /* String query;
        if (isAllProviderGroups) {
            query = String.format(HISTORICAL_LEADER_PERF_DATA_LOAD, EMPTY_STRING);
        } else {
            query = String.format(HISTORICAL_LEADER_PERF_DATA_LOAD, MEMBER_ASSESSMENT_QUERY_FILTER);
        }*/
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put(IS_CURRENT_WEEK, isCurrentWeek);
        paramMap.put(PROGRAM_YEAR, programYearCalendarDTO.getProgramYear());
        paramMap.put(DURATION_VALUE, programYearCalendarDTO.getDurationValue());
        paramMap.put(UPDATED_BY, JobName.LOAD_HISTORICAL_LEADER_PERFORMANCE.getValue());
        paramMap.put(DURATION_START_DATE, programYearCalendarDTO.getStartDate().toString());
        paramMap.put(DURATION_END_DATE, programYearCalendarDTO.getEndDate().toString());
        paramMap.put(OWNER_UUID, "National");
        return namedParameterJdbcTemplate.update(HISTORICAL_LEADER_PERF_DATA_LOAD, paramMap);
    }

    @Override
    public int updateICGoalLeaderPerformance(String userId, String serviceLevel, ProgramYearCalendarDTO programYearCalendarDTO, boolean isAllProviderGroups) {
        String query;
        if (isAllProviderGroups) {
            query = String.format(IC_GOAL_UPDATE_LEADER_PERFORMANCE, EMPTY_STRING, EMPTY_STRING);
        } else {
            query = String.format(IC_GOAL_UPDATE_LEADER_PERFORMANCE, MEMBER_ASSESSMENT_QUERY_FILTER, MEMBER_ASSESSMENT_QUERY_FILTER);
        }
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put(OWNER_UUID, userId);
        paramMap.put(SERVICE_LEVEL, serviceLevel);
        paramMap.put(DURATION_VALUE, programYearCalendarDTO.getDurationValue());
        paramMap.put(PROGRAM_YEAR, programYearCalendarDTO.getProgramYear());
        paramMap.put(UPDATED_BY, JobName.LOAD_HISTORICAL_LEADER_PERFORMANCE.getValue());
        return namedParameterJdbcTemplate.update(query, paramMap);
    }

    @Override
    public long loadLeaderPerformanceNationalLevelAll(ProgramYearCalendarDTO programYearCalendarDTO, int isCurrentWeek, boolean isAllProviderGroups)
    {
     /*   String query;
        if (isAllProviderGroups) {
            query = String.format(NATIONAL_LEVEL_FOR_ALL_CLIENTS_LOB_REGION_STATE_SERVICE_LEVELS, EMPTY_STRING);
        } else {
            query = String.format(NATIONAL_LEVEL_FOR_ALL_CLIENTS_LOB_REGION_STATE_SERVICE_LEVELS,  MEMBER_ASSESSMENT_QUERY_FILTER);
        }*/
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put(OWNER_UUID, "National");
        paramMap.put(IS_CURRENT_WEEK, isCurrentWeek);
        paramMap.put(PROGRAM_YEAR, programYearCalendarDTO.getProgramYear());
        paramMap.put(DURATION_VALUE, programYearCalendarDTO.getDurationValue());
        paramMap.put(DURATION_START_DATE, programYearCalendarDTO.getStartDate().toString());
        paramMap.put(DURATION_END_DATE, programYearCalendarDTO.getEndDate().toString());
        paramMap.put(UPDATED_BY, JobName.LOAD_HISTORICAL_LEADER_PERFORMANCE.getValue());
        return namedParameterJdbcTemplate.update(NATIONAL_LEVEL_FOR_ALL_CLIENTS_LOB_REGION_STATE_SERVICE_LEVELS, paramMap);
    }
}
