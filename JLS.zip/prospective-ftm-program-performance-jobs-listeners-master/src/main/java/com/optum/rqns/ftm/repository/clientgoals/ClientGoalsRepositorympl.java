package com.optum.rqns.ftm.repository.clientgoals;

import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.model.clientgoals.ClientGoalsData;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@Slf4j
public class ClientGoalsRepositorympl implements ClientGoalsRepository {

    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    public ClientGoalsRepositorympl(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
        this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
    }

    private static final String MODIFIED_CONDITION = "where CAST(UpdatedDate as date) >= (select CAST(LastSuccessfulRunDate as date)" +
            " from ProgPerf.jobrunconfiguration where jobname= '" + JobName.RUN_CLIENT_GOALS.getValue() + "')";

    private static final String CLIENT_GOALS_QUERY = "SELECT pgw.ProviderGroupID, pgw.State, pgw.ProgramYear, pgw.ClientName, pgw.LobName as lob, " +
            "cc.ClientId AS clientId, (CASE WHEN DeployYETarget > 0 AND IsIDMTarget = 1 THEN 1 ELSE 0 END) AS hasClientGoals " +
            "FROM ProgPerf.ProviderGroupPerformanceWeekly pgw WITH (NOLOCK) " +
            "INNER JOIN ProgPerf.ClientConfiguration cc ON pgw.ClientName = cc.ClientName " +
            "WHERE ProgramYear = :PROGRAM_YEAR " +
            "AND DurationValue = (select DurationValue from ProgPerf.ProgramYearCalendar pyc where GetUtcDate() between pyc.StartDate and pyc.EndDate and DurationType = 'Week')";

    private static final String CLIENT_GOALS = CLIENT_GOALS_QUERY + " ORDER BY ProgramYear offset :OFFSET rows FETCH next :BatchSize rows only";

    private static final String RECORD_COUNT_QUERY = "SELECT count(*) as recCount FROM ("+CLIENT_GOALS_QUERY+") AS ProvGpPerfWeekly";

    @Override
    public Long getRecordCount(int programYear) {
        SqlParameterSource sqlParameterSource = new MapSqlParameterSource("PROGRAM_YEAR", programYear);
        log.info("ClientGoals Producer DB Count :{}", RECORD_COUNT_QUERY);
        return namedParameterJdbcTemplate.queryForObject(RECORD_COUNT_QUERY, sqlParameterSource, Long.class);
    }

    @Override
    public List<ClientGoalsData> getClientGoals(int batchSize, Integer batchOffset, int programYear) {

        SqlParameterSource sqlParameterSource = new MapSqlParameterSource("BatchSize", batchSize)
                .addValue("OFFSET", batchOffset)
                .addValue("PROGRAM_YEAR",programYear);
        log.info("batchsize {} offset {}", batchSize, batchOffset);

        return namedParameterJdbcTemplate.query(CLIENT_GOALS, sqlParameterSource, new BeanPropertyRowMapper<>(ClientGoalsData.class));
    }

}
