package com.optum.rqns.ftm.util;

import com.google.gson.Gson;
import com.optum.rqns.ftm.constants.Constants;

import java.lang.reflect.Type;
import java.util.Objects;
import java.util.regex.Pattern;

public final class ProgramPerformanceJobUtil {

    private static Gson gson = new Gson();
    /**
     * Max log message size
     */
    static final int LOG_MESSAGE_LIMIT = 5000;

    /**
     *  Match on any CR/LF or non-printable ASCII
     */
    static final Pattern SANTIZE_EXPRESSION = Pattern.compile("[\r\n\\P{Print}]+");

    private ProgramPerformanceJobUtil() {

    }

    public static boolean canExecuteForAllProviderGroups(CharSequence groupsToExecute) {
        return Constants.ALL.equalsIgnoreCase(String.valueOf(groupsToExecute));
    }

    public static class TransactionIdLogger {
        private static String transactionIdentifier;
        private static String messageIdIdentifier;

        public static String getTransactionIdentifier() {
            return transactionIdentifier;
        }

        public static void setTransactionIdentifier(String transactionIdentifier) {
            TransactionIdLogger.transactionIdentifier = transactionIdentifier;
        }

        public static String getMessageIdIdentifier() {
            return messageIdIdentifier;
        }

        public static void setMessageIdIdentifier(String messageIdIdentifier) {
            TransactionIdLogger.messageIdIdentifier = messageIdIdentifier;
        }
    }

    public static String getQuotedString(String string) {
        if (Objects.nonNull(string)) {
            return string.replace("'", "''");
        }
        return string;
    }

    public static Object jsonToPojo(String json, Class clz) {
        return gson.fromJson(json, clz);
    }

    public static Object jsonToTypePojo(String json, Type type) {
        return gson.fromJson(json, type);
    }

    public static String toJson(Object obj)
    {
        return gson.toJson (obj);
    }

    public static String sanitizeLogMessage(String logMessage) {
        var sanitizedMessage = SANTIZE_EXPRESSION.matcher(logMessage).replaceAll("_");
        if (sanitizedMessage.length() > LOG_MESSAGE_LIMIT) {
            sanitizedMessage = sanitizedMessage.substring(0, LOG_MESSAGE_LIMIT);
        }
        return sanitizedMessage;
    }
}
