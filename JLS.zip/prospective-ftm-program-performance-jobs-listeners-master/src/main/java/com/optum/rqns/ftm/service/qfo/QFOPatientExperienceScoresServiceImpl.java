package com.optum.rqns.ftm.service.qfo;

import com.fasterxml.uuid.Generators;
import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.avro.models.v1.program.performance.provider.qfo.QFOPatientExperience;
import com.optum.rqns.ftm.kafka.producer.KeyBasedQFOPatientExperienceScoreSyncProducer;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.model.qfo.QFOPatientExperienceScore;
import com.optum.rqns.ftm.repository.qfo.QFOPatientExperienceScoresRepository;
import com.optum.rqns.ftm.util.JobUtilility;
import com.optum.rqns.ftm.util.ProgramPerformanceJobUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.time.StopWatch;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

@Service
@Slf4j
public class QFOPatientExperienceScoresServiceImpl implements QFOPatientExperienceScoresService {

    private QFOPatientExperienceScoresRepository qfoPatientExperienceScoresRepository;
    private static final int BATCH_SIZE = 25000;

    @Value("${spring.db_connection_thread_pool_size}")
    private int dbConnectionThreadPoolSize;


    @Value("${qfo_patient_experience_scores_producer_thread_pool_size}")
    private int producerThreadPoolSize;

    @Autowired
    private KeyBasedQFOPatientExperienceScoreSyncProducer producer;

    JobUtilility jobUtilility;


    public QFOPatientExperienceScoresServiceImpl(QFOPatientExperienceScoresRepository qfoPatientExperienceScoresRepository) {
        this.qfoPatientExperienceScoresRepository = qfoPatientExperienceScoresRepository;
    }


    public JobStatus executeJob(JobEvent jobEvent) {

        MDC.put(Constants.TRACE_ID, Generators.timeBasedGenerator().generate().toString());
        MDC.put(Constants.TRANSACTION_ID, ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
        MDC.put(Constants.MESSAGE_ID, ProgramPerformanceJobUtil.TransactionIdLogger.getMessageIdIdentifier());

        JobStatus jobStatus = new JobStatus();
        jobUtilility = new JobUtilility();
        log.info("{} jobEvent.QFOPatientExperienceScores() :: {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), jobEvent.getJobName());
        try {
            log.info("{} Inside Run Job ", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());

            AtomicInteger updatedRecords = new AtomicInteger();

            final Long totalRows = this.qfoPatientExperienceScoresRepository.getRecordCount(jobEvent);
            log.info(" QFOPatientExperienceScores record Count {}", totalRows);

            List<Integer> batches = jobUtilility.getBatches(totalRows);
            log.info(" QFOPatientExperienceScores total Batches offsets are {}", batches.size());

            batches.stream().forEach(batchOffset -> {

                int publishedQFOPatientExpScore = sendQFOPatientExperienceScoresToProviderMS(batchOffset, jobEvent);
                updatedRecords.addAndGet(publishedQFOPatientExpScore);
            });

            jobStatus.setStatus(Status.SUCCESS);
            jobStatus.setMessage("Completed  QFOPatientExperienceScores Provider MS Producer job successfully");
            jobStatus.setUpdatedRows(updatedRecords.longValue());

        } catch (Exception e) {
            log.error("Exception while executing with All  QFOPatientExperienceScores Provider MS Producer job : {}", e);

            jobStatus.setStatus(Status.FAILURE);
            jobStatus.setMessage(" QFOPatientExperienceScores Provider MS Producer job execution failed : " + e.getMessage());
            jobStatus.setUpdatedRows(0L);
        } finally {
            MDC.clear();
        }

        return jobStatus;
    }

    /**
     * @param batchOffset
     */
    private int sendQFOPatientExperienceScoresToProviderMS(Integer batchOffset, JobEvent jobEvent) {

        List<QFOPatientExperienceScore> qfoPatientExperienceScores = qfoPatientExperienceScoresRepository.fetchQFOPatientExperienceScores(Constants.BATCH_SIZE, batchOffset, jobEvent);

        //For parallel producing
        ExecutorService executorService = Executors.newFixedThreadPool(producerThreadPoolSize);
        List<Callable<Boolean>> taskList = new ArrayList<>();

        qfoPatientExperienceScores.stream().forEach(qfoPatientExperienceScore -> {

            //Publish message to topic
            taskList.add(() -> {
                return producer.postToKafka(buildQfoPatientExperienceScoresAvroV1(qfoPatientExperienceScore), qfoPatientExperienceScore.getProviderGroupId() + "_" + qfoPatientExperienceScore.getProgramYear());
            });


        });

        log.info("{} Publishing  QFOPatientExperienceScores to Provider MS  {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), "******* Started ****************");

        // Producing Elements to Topic parallelly
        StopWatch stopWatch = StopWatch.createStarted();
        jobUtilility.producingElementsParallellyToTopic(executorService, taskList);
        stopWatch.stop();
        log.info("Time took for producing messages to kafka in ms is ::" + stopWatch.getTime() + " and rule is  QFOPatientExperienceScores Provider MS Service Impl::");

        log.info("{} Published  QFOPatientExperienceScores to Provider MS records {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), qfoPatientExperienceScores.size());

        return qfoPatientExperienceScores.size();
    }

    /**
     * @param qfoPatientExperience
     * @return
     */
    private QFOPatientExperience buildQfoPatientExperienceScoresAvroV1(QFOPatientExperienceScore qfoPatientExperience) {


        QFOPatientExperience qfoPatientExperienceAvro = new QFOPatientExperience();
        qfoPatientExperienceAvro.setProviderGroupID(qfoPatientExperience.getProviderGroupId());
        qfoPatientExperienceAvro.setProgramYear(qfoPatientExperience.getProgramYear());
         if(Objects.nonNull(qfoPatientExperience.getGncRate())){
             qfoPatientExperienceAvro.setGncRate(convertDecimalToPercentage(qfoPatientExperience.getGncRate()));
         }
         if(Objects.nonNull(qfoPatientExperience.getDpcRate())){
             qfoPatientExperienceAvro.setDpcRate(convertDecimalToPercentage(qfoPatientExperience.getDpcRate()));
         }
         if(Objects.nonNull(qfoPatientExperience.getCooRate())){
            qfoPatientExperienceAvro.setCooRate(convertDecimalToPercentage(qfoPatientExperience.getCooRate()));
         }
        qfoPatientExperienceAvro.setCreatedDate(qfoPatientExperience.getCreatedDate().toInstant(ZoneOffset.UTC));
        qfoPatientExperienceAvro.setUpdateDate(qfoPatientExperience.getUpdatedDate().toInstant(ZoneOffset.UTC));

        return qfoPatientExperienceAvro;
    }


    private Integer convertDecimalToPercentage(float f) {
        if (f == 0) return 0;
        return (int) Math.round(Double.valueOf(new Float(f).toString()).doubleValue() * 100);

    }
}