package com.optum.rqns.ftm.repository;

import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;

public interface PAFxMemberAssessmentStagingRepository {
    Long getRecordCount(JobEvent jobEvent);

    Integer mergePAFxMemberAssessmentData(JobEvent jobEvent, Integer offset, int batchSize);
}
