package com.optum.rqns.ftm.service.commandcenter;

import com.optum.rqns.ftm.service.IJob;

public interface CommandCenterService extends IJob {
}
