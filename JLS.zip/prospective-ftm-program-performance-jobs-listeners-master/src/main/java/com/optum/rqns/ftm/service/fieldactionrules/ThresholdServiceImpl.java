package com.optum.rqns.ftm.service.fieldactionrules;

import com.google.gson.reflect.TypeToken;
import com.jayway.jsonpath.JsonPath;
import com.optum.rqns.ftm.enums.DMNRuleDefinitionDetails;
import com.optum.rqns.ftm.enums.DmnPayload;
import com.optum.rqns.ftm.model.fieldactionrules.RuleAction;
import com.optum.rqns.ftm.util.ProgramPerformanceJobUtil;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.ListUtils;
import org.apache.commons.lang3.time.StopWatch;
import org.drools.core.command.runtime.SetGlobalCommand;
import org.kie.api.KieServices;
import org.kie.api.command.BatchExecutionCommand;
import org.kie.api.command.Command;
import org.kie.api.command.KieCommands;
import org.kie.api.runtime.ExecutionResults;
import org.kie.server.api.model.KieServiceResponse;
import org.kie.server.api.model.ServiceResponse;
import org.kie.server.client.RuleServicesClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
@Slf4j
public class ThresholdServiceImpl {

    private static final Integer BATCH_SIZE = 10000;

    private static final String DATA_LIST = "dataList";

    public static final String DMN_RULE_JSON_PATH = "$.result.dmn-evaluation-result.decision-results..result";


    @Autowired
    private RuleServicesClient rulesClient;

    @Value("${kie.server.threshold.containerId}")
    private String containerId;

    @Autowired
    private RestTemplate restTemplate;

    @Value("${kie.server.dmnRestUrl}")
    private String dmnRestUrl;

    @Value("${kie.server.username}")
    private String userName;

    @Value("${kie.server.password}")
    private String dmPass;

    //its local to DMN , so its defined inside class
    @AllArgsConstructor
    @Getter
    enum DMNMapper{
        MODEL_NAMESPACE("modelNamespace","model-namespace"),
        MODEL_NAME("modelName","model-name"),
        DMN_CONTEXT("dmnContext","dmn-context");

        private String name;
        private String value;
    }

    public List<RuleAction> invokeDMRuleRestAPIList(List<RuleAction> inputData,String jobName) {
        StopWatch stopWatch = StopWatch.createStarted();

        log.info("Start : Input RulesData Size {} -> Call to Kieserver DMN Redhat Rules API JobName {}",inputData.size(), jobName);

        List<RuleAction> responseData = new ArrayList<>();
        for (int index = 0; index < inputData.size(); index++) {
            log.info("Counter {} invoking DMN Rule {} endpoint ", index, dmnRestUrl);
            List<RuleAction> responseList = invokeDMRuleRestAPI(buildDMNRuleCompliantPayload(inputData.get(index), jobName),inputData.get(index).getClass());

            if (!CollectionUtils.isEmpty(responseList)) {
                responseData.addAll(responseList.stream().filter(Objects::nonNull).collect(Collectors.toList()));
                log.info("Rule {} passed TotalRulesPassedResponseList {}  ",inputData.get(index).getRuleType(), responseData.size());
            }
        }

        stopWatch.stop();
        log.info("Time taken {} ms for KieServer DMN Rule Processing for FieldActionRule {} " ,stopWatch.getTime(),jobName);
        log.info("Successfully finished DMN Rules FieldActionRule size  {}  for {} ", responseData.size(),jobName);

        return responseData;
    }

    private String buildDMNRuleCompliantPayload(RuleAction input,String jobName){

        Map<String,Object> inputMap = new HashMap<>();
        DMNRuleDefinitionDetails dMNRuleDefinitionDetails =DMNRuleDefinitionDetails.getDMNRuleDefinitionDetails(jobName);
        inputMap.put(dMNRuleDefinitionDetails.getInputDataActionName(), input);
        DmnPayload payload = DmnPayload.builder()
                .modelName(dMNRuleDefinitionDetails.getModelName())
                .modelNamespace(dMNRuleDefinitionDetails.getModelNamespace())
                .dmnContext(inputMap)
                .build();
        return fieldNamesMapper(ProgramPerformanceJobUtil.toJson(payload));
    }

    private String fieldNamesMapper(String payload){
        payload =payload
                .replace(DMNMapper.MODEL_NAMESPACE.getName(),DMNMapper.MODEL_NAMESPACE.getValue())
                .replace(DMNMapper.MODEL_NAME.getName(),DMNMapper.MODEL_NAME.getValue())
                .replace(DMNMapper.DMN_CONTEXT.getName(),DMNMapper.DMN_CONTEXT.getValue());
        return payload;
    }

    private <T>List<RuleAction> invokeDMRuleRestAPI(String dmnPayloadJson,Class<T> type) {
        log.debug("input dmnPayloadJSON {} ",dmnPayloadJson);
        List<RuleAction> responseList  = null;
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        headers.setBasicAuth(userName,dmPass);
        HttpEntity<String> entity = new HttpEntity<>(dmnPayloadJson,headers);
        ResponseEntity<String> responseEntity = restTemplate.exchange(dmnRestUrl, HttpMethod.POST, entity, String.class);
        if( HttpStatus.OK.equals(responseEntity.getStatusCode())){
            log.debug(" DMN rule response body json {}", responseEntity.getBody());
            List result= JsonPath.parse(responseEntity.getBody()).read(DMN_RULE_JSON_PATH,List.class);
            if(!CollectionUtils.isEmpty(result) && result.get(0) != null) {
                //Type token = new TypeToken<List<NewProviderManualAssociationAction>>(){}.getType();
                Type token =TypeToken.getParameterized(List.class, type).getType();

                responseList = (List<RuleAction>) ProgramPerformanceJobUtil.jsonToTypePojo(result.toString(), token);
            }
        }else {
            log.error(" Error in processing the DMN Rule Respone {} - {} ", responseEntity.getStatusCode(),responseEntity.getBody());
        }
        return responseList;
    }


    protected List<RuleAction> execute(List<RuleAction> inputData) {
        List<RuleAction> dataList = new ArrayList<>();
        try{

            List<List<RuleAction>> batchSizedList = ListUtils.partition(inputData, BATCH_SIZE);

            for (List<RuleAction> dataBatchList : batchSizedList) {
                if (!dataBatchList.isEmpty()) {
                    log.info("== Sending Rule InputData to the Kie server ==");

                    List<RuleAction> outList = new ArrayList<>();

                    KieCommands commandsFactory = KieServices.Factory.get().getCommands();

                    SetGlobalCommand setDetailListCommand = new SetGlobalCommand();
                    setDetailListCommand.setIdentifier(DATA_LIST);
                    setDetailListCommand.setObject(outList);
                    setDetailListCommand.setOutIdentifier(DATA_LIST);

                    //batch insertion
                    List<Object> objects = new ArrayList<>(dataBatchList);
                    Command<?> insertElementsCommand = commandsFactory.newInsertElements(objects);

                    Command<?> fireAllRules = commandsFactory.newFireAllRules();
                    Command<?> disposeCommand = commandsFactory.newDispose();

                    BatchExecutionCommand batchExecutionCommand = commandsFactory.newBatchExecution(
                            Arrays.asList(setDetailListCommand, insertElementsCommand, fireAllRules, disposeCommand));


                    ServiceResponse<ExecutionResults> executeResponse = rulesClient.executeCommandsWithResults(containerId, batchExecutionCommand);

                    if (executeResponse.getType() == KieServiceResponse.ResponseType.SUCCESS) {
                        log.info("Received - Commands executed with success! Response: ");

                        List<RuleAction> ruleBatchList=(List<RuleAction>) executeResponse.getResult().getValue(DATA_LIST);

                        log.info("RuleBatchList size = {}", !ruleBatchList.isEmpty() ? ruleBatchList.size():" Empty Response");

                        dataList.addAll(ruleBatchList);
                    } else {
                        log.info("Error executing rules. Message: ");
                        log.error("Error Message: {}", executeResponse.getMsg());
                    }
                }
            }

        }catch (Exception e){
            log.error("Exception = {}",e);
        }

        log.info("final data size from Drools Engine Response : {}",!dataList.isEmpty() ? dataList.size() : "no data");

        return dataList;
    }

}
