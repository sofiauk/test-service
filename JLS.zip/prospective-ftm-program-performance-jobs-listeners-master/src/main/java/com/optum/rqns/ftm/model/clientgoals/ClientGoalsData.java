package com.optum.rqns.ftm.model.clientgoals;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.time.LocalDateTime;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ClientGoalsData {

    private String providerGroupID;
    private String programYear;
    private String state;
    private String clientId;
    private String clientName;
    private String lob;
    private boolean hasClientGoals;

}
