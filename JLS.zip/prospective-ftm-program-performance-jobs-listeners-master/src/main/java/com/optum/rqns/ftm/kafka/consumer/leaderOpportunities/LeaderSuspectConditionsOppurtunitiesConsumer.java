package com.optum.rqns.ftm.kafka.consumer.leaderOpportunities;

import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.consumer.JobEventConsumer;
import com.optum.rqns.ftm.repository.common.CommonRepository;
import com.optum.rqns.ftm.service.leaderopportunities.LeaderSuspectConditionsOppurtunitiesServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.context.annotation.Profile;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.annotation.TopicPartition;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

@Profile("memberGapJobs")
@Component
@Slf4j
public class LeaderSuspectConditionsOppurtunitiesConsumer extends JobEventConsumer {
    public LeaderSuspectConditionsOppurtunitiesConsumer(final LeaderSuspectConditionsOppurtunitiesServiceImpl leaderSuspectConditionsOppurtunitiesService, final CommonRepository commonRepository) {
        super(leaderSuspectConditionsOppurtunitiesService, commonRepository);
    }

    @KafkaListener(topicPartitions = {@TopicPartition(topic = "${spring.gcpkafka.properties.topics.jobEvent}", partitions = {"43"})},
            containerFactory = "jobEventKafkaListenerContainerFactory", autoStartup = "true")
    public void onMessage(ConsumerRecord<String, JobEvent> record, Acknowledgment acknowledgment) {
        log.info("{} Begin QualityGaps Leader Opportunities Consumer : {}", super.generateTransactionId(record), record);
        processMessage(43, record, acknowledgment);
    }
}
