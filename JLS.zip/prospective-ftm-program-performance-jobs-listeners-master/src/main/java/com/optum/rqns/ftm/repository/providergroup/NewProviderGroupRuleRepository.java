package com.optum.rqns.ftm.repository.providergroup;


import com.optum.rqns.ftm.model.providergroup.MemberAssessmentHistory;
import com.optum.rqns.ftm.model.providergroup.ProviderGroup;

import java.util.List;
import java.util.Map;

public interface NewProviderGroupRuleRepository {
    List<ProviderGroup> getProviderGroupDetails(Integer programYear);

    List<MemberAssessmentHistory> getMemberAssessmentHistoryDetails(String providerGroupIds, Integer programYear);

    List<MemberAssessmentHistory> getMemberAssessmentHistoryDetailsBasedOnLastJobRunDate(Integer programYear);

    int[] updateBatchQueries(List<Map<String, Object>> batchValues);

    List<ProviderGroup> getProviderGroupDetailsBasedOnProviderGroups(String providerGroupIds, Integer programYear, boolean executeForNewGroups);

    List<Integer> getRowCountforIsEligiblePOClist(int batchsize);

    int updateIsGroupEligiblePOC(boolean isAllProviderGroups, int programYear, int begin, int end);

    int updateCommandCenterPerformanceAggregates(Integer programYear);

    Long getProviderGroupsRecordCount(boolean executeForNewGroups, Integer programYear);

    List<ProviderGroup> getProviderGroupDetailsByOffset(int batchSize, Integer offset, boolean executeForNewGroups, Integer programYear);

    Long getMemberAssessmentHistoryDetailsBasedOnLastJobRunDateRecordCount(Integer programYear);

    List<MemberAssessmentHistory> getMemberAssessmentHistoryProviderGroupsBasedOnLastRunDate(int batchSize, Integer offset, Integer programYear);

    List<MemberAssessmentHistory> getMemberAssessmentHistoryDetailsBasedOnLastJobRunDateRecordsByOffset(String providerGroupIds, Integer programYear);

    List<String> getProviderGroupDetailsForNewGroups(Integer programYear);

    List<ProviderGroup> getProviderGroupDetailsBasedOnGroupIds(Integer programYear, String providerGroupIds);
}
