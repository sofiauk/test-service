package com.optum.rqns.ftm.service.fieldactionrules;

import com.google.gson.Gson;
import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.model.fieldactionrules.RejectAgingGroupLevelAction;
import com.optum.rqns.ftm.model.fieldactionrules.RuleAction;
import com.optum.rqns.ftm.repository.fieldactionrules.RejectAgingGroupLevelRepoImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Slf4j
public class RejectAgingGroupLevelServiceImpl extends FieldActionRuleService {

    @Autowired
    private RejectAgingGroupLevelRepoImpl rejectAgingGroupLevelRepoImpl;

    public RejectAgingGroupLevelServiceImpl() {
       setBatchingRequired(true);
    }


    @Override
    public List<Integer> fetchRuleBatchingOffsetList(int batchSize) {
        return rejectAgingGroupLevelRepoImpl.getRowCountAndBatchesForReturnAging(batchSize);
    }


    @Override
    public List<RuleAction> fetchRuleData(Integer beginIndex, int batchSize,boolean isbatchingrequireed) {

        return rejectAgingGroupLevelRepoImpl.fetchRejectAgingInfo(beginIndex,batchSize);
    }



    @Override
    public String getRuleResult(RuleAction ruleAction) {

        Map<String,Object> resultMap=new HashMap<>();
        Gson gson=new Gson();
        if(ruleAction instanceof RejectAgingGroupLevelAction){
            RejectAgingGroupLevelAction rejectAgingGroupLevel=(RejectAgingGroupLevelAction) ruleAction;
            resultMap.put(Constants.PROVIDER_GROUP_ID,rejectAgingGroupLevel.getProviderGroupId());
            resultMap.put(Constants.PROVIDER_STATE,rejectAgingGroupLevel.getProviderState());
            resultMap.put(Constants.PROVIDER_NAME,rejectAgingGroupLevel.getProviderGroupName());
        }

        return gson.toJson(resultMap);
    }

    @Override
    public String getRuleContext(RuleAction ruleAction) {
        Map<String,Object> resultMap=new HashMap<>();
        Gson gson=new Gson();
        if(ruleAction instanceof RejectAgingGroupLevelAction ){
            RejectAgingGroupLevelAction rejectAgingGroupLevel=(RejectAgingGroupLevelAction) ruleAction;
            resultMap.put(Constants.SINGLE_REJECT_DAYS_COUNT,rejectAgingGroupLevel.getSingleRejectDaysCount());
        }

        return gson.toJson(resultMap);
    }
}
