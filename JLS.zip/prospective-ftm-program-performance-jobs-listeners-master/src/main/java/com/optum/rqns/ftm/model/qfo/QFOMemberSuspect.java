package com.optum.rqns.ftm.model.qfo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class QFOMemberSuspect {
    private String providerGroupId;
    private int programYear;
   
}