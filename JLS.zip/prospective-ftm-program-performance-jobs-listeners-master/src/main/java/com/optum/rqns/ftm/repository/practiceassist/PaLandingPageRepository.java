package com.optum.rqns.ftm.repository.practiceassist;

import java.util.List;

import com.optum.rqns.ftm.model.practiceassist.PaAggregationData;

public interface PaLandingPageRepository {


	List<PaAggregationData> getPaAggregateDataByBatch(Integer programYear, String joblastrunsuccessfuldate, int offset,
			int batchsize);

	Integer upserQualityAggregation(List<PaAggregationData> paQualityAggregationList);

		
	List<PaAggregationData> getPaSuspectAggregateDataByBatch(Integer programYear, String joblastrunsuccessfuldate,String jobStartTime, int offset, int batchsize);
	
	Integer upserSuspectAggregation(List<PaAggregationData> paSuspectAggregationList);
	
	List<PaAggregationData> getPaMedAdherenceAggregateDataByBatch(Integer programYear, String joblastrunsuccessfuldate, String jobStartTime, int offset,
			int batchsize);
	
	Integer upserMedAdherenceAggregation(List<PaAggregationData> paMedAdherenceAggregationList);
	
	List<PaAggregationData> getPaAggregateDataByBatch(Integer programYear, String joblastrunsuccessfuldate,
			String jobStartTime, int offset, int batchsize);

	List<PaAggregationData> getPaMemberSummaryAggregateDataByBatch(Integer programYear, String joblastrunsuccessfuldate,String jobStartTime, int offset,
																  int batchsize);

	Integer upserMemberSummaryAggregation(List<PaAggregationData> paMemberSummaryAggregationList);
	
	List<String> getAffectedProvGrpList(Integer programYear, String joblastrunsuccessfuldate, String jobStartTime,
			String jobName);

	List<PaAggregationData> getPaHospitalEventsAggregateDataByBatch(Integer programYear, String joblastrunsuccessfuldate,
			String jobStartTime, int offset, int batchsize);
	
	Integer upserHospitalEventsAggregation(List<PaAggregationData> paHospitalEventsAggregationList);

	Long getRecordCountModifiedByPrvGrps(String jobName, String groupToExecute, Integer programYear,
			String joblastrunsuccessfuldate, String jobStartTime);

	Integer inActivateDirtyRecords(String jobName, String groupToExecute, Integer programYear,
			String joblastrunsuccessfuldate, String jobStartTime);

	Integer markedRecordsAsDirty(String jobName, String groupToExecute, Integer programYear,
			String joblastrunsuccessfuldate, String jobStartTime);

	Integer markedRecordsAsDirty(String jobName, String groupToExecute, Integer programYear,
			String joblastrunsuccessfuldate, String jobStartTime, List<String> affectedPrvGrpList);

	List<PaAggregationData> getPaAggregateDataByBatch(Integer programYear, String joblastrunsuccessfuldate,
			String jobStartTime, List<String> affectedPrvGrpList);

	Integer inActivateDirtyRecords(String jobName, String groupToExecute, Integer programYear,
			String joblastrunsuccessfuldate, String jobStartTime, List<String> affectedPrvGrpList);

	List<PaAggregationData> getPaMedAdherenceAggregateDataByBatch(Integer programYear, String joblastrunsuccessfuldate,
			String jobStartTime, List<String> affectedPrvGrpList);

	List<PaAggregationData> getPaMemberSummaryAggregateDataByBatch(Integer programYear, String joblastrunsuccessfuldate,
			String jobStartTime, List<String> affectedPrvGrpList);

	

	


}
