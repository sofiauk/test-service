package com.optum.rqns.ftm.constants;

import java.util.Arrays;
import java.util.List;

public final class Constants {

    public static final String DATE_FORMAT = "yyyy-MM-dd";
    public static final int BATCH_SIZE = 10000;
    public static final int NEW_PROVIDER_GROUP_RULE_BATCH_SIZE = 5000;
    public static final int PROJECT_YEAR_2020 = 2020;
    public static final int PROJECT_YEAR_2019 = 2019;
    public static final String  DATE_TIME_FORMAT = "yyyy-MM-dd'T'hh:mm:ss";
    public static final String  ALL = "All";

    public static final String LINGER_MS_CONFIG = "120000";
    public static final String REQUEST_TIMEOUT_MS_CONFIG = "120000";
    public static final int DB_BATCH_SIZE = 1000;
    public static final String INVALID_DATA_WARNING = "Invalid Data Warning";

    public static final String IDM_GLIDEPATH_JOB_DESCRIPTION = "Job to execute IDM GlidePath";
    public static final String SYSTEM = "System";
    public static final String EMPTY = "";

    public static final String TRACE_ID = "traceId";
    public static final String TRANSACTION_ID = "transactionId";
    public static final String MESSAGE_ID = "messageId";

    public static final String PUBLISHING_DATA_EXCEPTION = "Publishing Data Exception";

    // Fields Names which we need Rule Result. Instead of hardcoding common variables keeping here


    public static final String PROVIDER_GROUP_ID = "providerGroupID";
    public static final String PROVIDER_STATE = "providerState";
    public static final String PROVIDER_ID = "providerID";
    public static final String ELIGIBLE_PREFERRED_MEMBER_COUNT = "eligiblePreferredMemberCount";
    public static final String PROVIDER_NAME="ProviderName";
    public static final String RETURN_TARGET="ReturnTarget";
    public static final String RETURN_CNA   ="ReturnCna";
    public static final String SINGLE_REJECT_DAYS_COUNT="SingleRejectDaysCount";

    public static final String CLIENT = "Client";
    public static final String STATE="State";
    public static final String LOB="Lob";
    public static final String PAFX_ELIGIBLE_MEMBER_COUNT   ="pafxEligibleMemberCount";
    public static final String PUBLISHED_ELIGIBLE_MEMBER_COUNT="publishedEligibleMemberCount";

    public static final String USER_UUID="UserUUID";


    public static final String COMPLETE = "Complete";
    public static final String ONE = "1";

    public static final String CLIENT_GOALS_MESSAGE_TYPE = "ClientGoals";
    public static final String ADDITIONAL_PROVIDERGROUP_STATS_MESSAGE_TYPE = "AdditionalProviderGroupStats";

    // Opportunities constants

    public static final String QUALITY_GAPS="Quality Gaps";
    public static final String ANNUAL_CARE_VISITS="Annual Care Visits";
    public static final String SUSPECT_CONDITIONS="Suspect Conditions";

    public static final String SUSPECT_CONDITIONS_NOT_ASSESSED="Suspect Conditions Not Assessed";
    public static final String PATIENTS_NOT_FULLY_ASSESSED="Patients Not Fully Assessed";
    public static final String MODIFIED="Modified";

    public static final String COMMA = ",";

    public static final String rowAction="Upsert";

    public static final String messageType="EnhancedOpportunity";

    public static final String USER_ID="userId";
    public static final String OWNER_UUID="OwnerUUID";
    public static final String SERVICE_LEVEL="ServiceLevel";
    public static final String MASTER_OPPORTUNITY_TYPE="MasterOpportunityType";
    public static final String PROGRAM_YEAR="ProgramYear";
    public static final String REPORTERS="Reporters";
    public static final String UPDATED_BY="UpdatedBy";
    public static final String NATIONAL = "National";
    public static final String AFFECTED_ROWS = "AffectedRows";
    public static final String QFO = "QFO";
    public static final String TEAM_TYPE= "TeamType";
    public static final String PPT="PPT";
    public static final String OFFSET= "OFFSET";
    public static final String BATCHSIZE ="BATCHSIZE";
    public static final String LAST_MODIFIED =":MODIFIED";
    public static final String DURATION_VALUE = "DurationValue";
    public static final String CONSUMER_JOBEVENT = "jobEvent";
    public static final String QFO_PERFORMANCE_MESSAGE_TYPE = "QFOPerformance";
    public static final String MONTHLY = "Monthly";
    //Schema Registry SSL
    public static final String SCHEMA_REGISTRY_SSL_TRUSTSTORE_LOCATION = "schema.registry.ssl.truststore.location";
    public static final String SCHEMA_REGISTRY_SSL_TRUSTSTORE_PASSWORD = "schema.registry.ssl.truststore.password";
    public static final String SCHEMA_REGISTRY_SSL_KEYSTORE_LOCATION = "schema.registry.ssl.keystore.location";
    public static final String SCHEMA_REGISTRY_SSL_KEYSTORE_PASSWORD = "schema.registry.ssl.keystore.password";
    public static final String SCHEMA_REGISTRY_SSL_KEY_PASSWORD = "schema.registry.ssl.key.password";

    public static final String BOOTSTRAP_SERVERS = "bootstrap.servers";
    public static final String CLIENT_ID = "client.id";

    //GCP certs for application based - naming should be puma/ofc only because certs defined in same format in yml file
    public static final String OFC = "ofc";
    public static final String  MEMBER_STATUS_RQS_ENABLED = "MemberStatusRqsEnabled";
    public static final String  MEMBER_STATUS_GCP_ENABLED = "MemberStatusGcpEnabled";
}
