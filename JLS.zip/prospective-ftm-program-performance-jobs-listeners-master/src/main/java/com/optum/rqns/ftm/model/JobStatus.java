package com.optum.rqns.ftm.model;

import com.optum.rqns.ftm.enums.Status;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@NoArgsConstructor
@ToString
public class JobStatus {
    private Status status;
    private String message;
    private Long updatedRows;
}