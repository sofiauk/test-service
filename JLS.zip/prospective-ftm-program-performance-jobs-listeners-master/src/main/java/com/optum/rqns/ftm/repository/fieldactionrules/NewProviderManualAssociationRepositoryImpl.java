package com.optum.rqns.ftm.repository.fieldactionrules;

import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.model.fieldactionrules.NewProviderManualAssociationAction;
import com.optum.rqns.ftm.model.fieldactionrules.RuleAction;
import com.optum.rqns.ftm.util.ProgramPerformanceJobUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
@Slf4j
public class NewProviderManualAssociationRepositoryImpl implements NewProviderManualAssociationRepository {

    @Autowired
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    public NewProviderManualAssociationRepositoryImpl(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
        this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
    }

    public static final String GET_NEW_PROVIDER_MANUAL_ASSOCIATION_RULE_COUNT =
            " With AssignedProviderGroups AS ( SELECT DISTINCT A.GroupId, A.State, AO.OwnerUUID FROM ProgPerf.Accounts A WITH (NOLOCK) JOIN ProgPerf.AccountOwner AO ON AO.AccountId = A.AccountId AND (AO.OwnerUUID IS NOT NULL AND LEN(AO.OwnerUUID) > 0) AND A.ServiceLevel ='HCA' AND AO.OwnerType = 'HCA')" +
                    " SELECT count(*) TotalCount from" +
                    " ( SELECT AssignedProviderGroups.OwnerUUID userUuid, ProviderGroupId," +
                    " ProviderState," +
                    " ProviderId," +
                    " ProviderName," +
                    " count(*) eligiblePreferredMemberCount" +
                    " FROM ProgPerf.PafExMemberAssessment PA WITH (NOLOCK) join AssignedProviderGroups" +
                    " ON PA.ProviderGroupId = AssignedProviderGroups.GroupId AND PA.ProviderState = AssignedProviderGroups.state" +
                    " WHERE IsProviderAssociated IS NULL AND RecordStatus <> 'Deleted' AND IsSuppressed = 'N'" +
                    " AND ProgramYear = ( select value from ProgPerf.MasterConfiguration mc WITH(NOLOCK) where code = 'CurrentProgramYear')" +
                    " GROUP BY AssignedProviderGroups.OwnerUUID, ProviderGroupId, ProviderState, ProviderId, ProviderName ) AS NewProviderManualAssociation";


    @Override
    public List<Integer> getNewProviderManualAssociationRuleCount(int batchsize) {
        log.info("Fetching TotalCount from DB for NewProviderManualAssociationRule  transactionID :{} ", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
        Integer totalRows = namedParameterJdbcTemplate.queryForObject(GET_NEW_PROVIDER_MANUAL_ASSOCIATION_RULE_COUNT, new HashMap<>(), Integer.class);
        List<Integer> batches = new ArrayList<>();
        if (totalRows != null && totalRows > 0) {
            for (int batchOffset = 0; batchOffset <= totalRows; batchOffset += batchsize) {
                batches.add(batchOffset);
            }
        }
        log.info("Fetched TotalCount from DB for NewProviderManualAssociationRule  transactionID :{}, totalRows :{} , batchSize: {} , noOfBatches: {} ", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), totalRows, batchsize, batches.size());
        return batches;
    }

    public static final String GET_NEW_PROVIDER_MANUAL_ASSOCIATION_RULE_DATA = "With AssignedProviderGroups AS ( SELECT DISTINCT A.GroupId, A.State, AO.OwnerUUID FROM ProgPerf.Accounts A WITH (NOLOCK) JOIN ProgPerf.AccountOwner AO ON AO.AccountId = A.AccountId AND (AO.OwnerUUID IS NOT NULL AND LEN(AO.OwnerUUID) > 0) AND A.ServiceLevel ='HCA' AND AO.OwnerType = 'HCA')" +
            " SELECT" +
            " AssignedProviderGroups.OwnerUUID UserUuid," +
            " ProviderGroupID," +
            " (SELECT TOP 1 pg.ProviderGroupName FROM ProgPerf.ProviderGroup pg WITH (NOLOCK) WHERE pg.ProviderGroupID = PA.ProviderGroupId and pg.State = PA.ProviderState) as ProivderGroupName," +
            " ProviderState," +
            " ProviderID," +
            " ProviderName," +
            " count(*) eligiblePreferredMemberCount" +
            " FROM ProgPerf.PafExMemberAssessment PA WITH (NOLOCK) join AssignedProviderGroups" +
            " ON PA.ProviderGroupId = AssignedProviderGroups.GroupId AND PA.ProviderState = AssignedProviderGroups.state" +
            " WHERE IsProviderAssociated IS NULL AND RecordStatus <> 'Deleted' AND IsSuppressed = 'N'" +
            " AND ProgramYear = ( select value from ProgPerf.MasterConfiguration mc WITH(NOLOCK) where code = 'CurrentProgramYear')" +
            " GROUP BY AssignedProviderGroups.OwnerUUID, ProviderGroupId, ProviderState, ProviderId, ProviderName" +
            " ORDER BY UserUuid,ProviderGroupID,ProviderState,ProviderId OFFSET :begin ROWS FETCH NEXT :end ROWS ONLY";

    public static class NewProviderManualAssociationRuleRowMapper implements RowMapper<RuleAction> {

        @Override
        public RuleAction mapRow(ResultSet rs, int rowNum) throws SQLException {
            NewProviderManualAssociationAction newProviderManualAssociationAction = new NewProviderManualAssociationAction();

            List<String> userList = new ArrayList<>();
            userList.add(rs.getString("UserUuid"));
            newProviderManualAssociationAction.setUserUuid(userList);

            newProviderManualAssociationAction.setProviderGroupID(rs.getString("ProviderGroupID"));
            newProviderManualAssociationAction.setProviderGroupName(rs.getString("ProivderGroupName"));
            newProviderManualAssociationAction.setProviderState(rs.getString("ProviderState"));
            newProviderManualAssociationAction.setProviderID(rs.getString("ProviderID"));
            newProviderManualAssociationAction.setProviderName(rs.getString("ProviderName"));
            newProviderManualAssociationAction.setEligiblePreferredMemberCount(rs.getInt("eligiblePreferredMemberCount"));
            newProviderManualAssociationAction.setRuleType(JobName.NEW_PROVIDER_MANUAL_ASSOCIATION_JOB.getValue());

            return newProviderManualAssociationAction;
        }
    }

    @Override
    public List<RuleAction> getNewProviderManualAssociationRuleData(Integer beginIndex, int batchSize) {
        log.info("Fetching RuleData from DB for NewProviderManualAssociationRule transactionID :{} ", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier());
        Map<String, Object> bindingMap = new HashMap<>();
        bindingMap.put("begin", beginIndex);
        bindingMap.put("end", batchSize);
        List<RuleAction> ruleActions = namedParameterJdbcTemplate.query(GET_NEW_PROVIDER_MANUAL_ASSOCIATION_RULE_DATA, bindingMap, new NewProviderManualAssociationRuleRowMapper());
        log.info("Fetched RuleData from DB for NewProviderManualAssociationRule transactionID :{} , RuleDataCount: {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(), ruleActions.size());
        return ruleActions;
    }
}

