package com.optum.rqns.ftm.service.fieldactionrules;

import com.google.gson.Gson;
import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.model.fieldactionrules.AvailMembershipClientLobStateAction;
import com.optum.rqns.ftm.model.fieldactionrules.ChangeServiceAction;
import com.optum.rqns.ftm.model.fieldactionrules.RuleAction;
import com.optum.rqns.ftm.repository.fieldactionrules.AvailMembershipClientLobStateRepoImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Slf4j
public class AvailMemberShipClientLobStateServiceImpl extends FieldActionRuleService {

    @Autowired
    private AvailMembershipClientLobStateRepoImpl availMembershipClientLobStateRepo;

    public AvailMemberShipClientLobStateServiceImpl() {
        setBatchingRequired(true);
    }


    @Override
    public List<Integer> fetchRuleBatchingOffsetList(int batchSize) {
        return availMembershipClientLobStateRepo.getRowCountAndBatchesForAvailMembershipClientLobState(batchSize);
    }


    @Override
    public List<RuleAction> fetchRuleData(Integer beginIndex, int batchSize, boolean isbatchingrequireed) {

        return availMembershipClientLobStateRepo.fetchAvailMembershipClientLobStateInfo(beginIndex, batchSize);
    }


    @Override
    public String getRuleResult(RuleAction ruleAction) {

        Map<String, Object> resultMap = new HashMap<>();
        Gson gson = new Gson();
        if(ruleAction instanceof AvailMembershipClientLobStateAction) {
            AvailMembershipClientLobStateAction availMembershipClientLobStateAction = (AvailMembershipClientLobStateAction) ruleAction;
            resultMap.put(Constants.CLIENT, availMembershipClientLobStateAction.getClient());
            resultMap.put(Constants.STATE, availMembershipClientLobStateAction.getState());
            resultMap.put(Constants.LOB, availMembershipClientLobStateAction.getLob());
        }
        return gson.toJson(resultMap);
    }

    @Override
    public String getRuleContext(RuleAction ruleAction) {
        Map<String, Object> resultMap = new HashMap<>();
        Gson gson = new Gson();
        if(ruleAction instanceof AvailMembershipClientLobStateAction) {
            AvailMembershipClientLobStateAction availMembershipClientLobStateAction = (AvailMembershipClientLobStateAction) ruleAction;
            resultMap.put(Constants.USER_UUID, ruleAction.getUserUuid());
            resultMap.put(Constants.PAFX_ELIGIBLE_MEMBER_COUNT, availMembershipClientLobStateAction.getPafxEligibleMemberCount());
            resultMap.put(Constants.PUBLISHED_ELIGIBLE_MEMBER_COUNT, availMembershipClientLobStateAction.getPublishedEligibleMemberCount());
        }
        return gson.toJson(resultMap);
    }


}
