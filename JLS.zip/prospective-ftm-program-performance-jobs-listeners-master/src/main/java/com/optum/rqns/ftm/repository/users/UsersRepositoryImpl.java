package com.optum.rqns.ftm.repository.users;

import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
@Slf4j
public class UsersRepositoryImpl implements UsersRepository {

    private static final String USERS_BY_ROLES_QUERY = "SELECT DISTINCT u.UUID " +
            "from Auth.UserGroups ug " +
            "join Auth.UserUserGroup uug on ug.GroupName in (:RoleNames) and uug.UserGroupId = ug.UserGroupid " +
            "JOIN Auth.Users u on u.UserId = uug.UserId ;";

    private static final String LEADER_IC_REPORTS = "WITH cte_org AS ( " +
            "    SELECT       " +
            "        UUID, " +
            "        PersonnelHierarchyId, " +
            "        ParentID  " +
            "    FROM       " +
            "        ProgPerf.PersonnelHierarchy " +
            "    WHERE ParentID = (SELECT top 1  PersonnelHierarchyId from ProgPerf.PersonnelHierarchy where uuid = :LeaderUuid) " +
            "    UNION ALL " +
            "    SELECT " +
            "        e.UUID, " +
            "        e.PersonnelHierarchyId, " +
            "        e.ParentID " +
            "    FROM " +
            "        ProgPerf.PersonnelHierarchy e " +
            "        INNER JOIN cte_org o " +
            "            ON o.PersonnelHierarchyId = e.ParentId " +
            ") , parent_ids as (SELECT DISTINCT ParentID from ProgPerf.PersonnelHierarchy ph where ph.ParentID is not null)  " +
            "SELECT co.UUID FROM cte_org co " +
            "WHERE co.PersonnelHierarchyId NOT IN (select ParentID from parent_ids)  OPTION (MAXRECURSION 0)  ;";
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    public UsersRepositoryImpl(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
        this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
    }

    @Override
    public List<String> getUsersByRole(List<String> roleNames) {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put("RoleNames", roleNames);
        return namedParameterJdbcTemplate.queryForList(USERS_BY_ROLES_QUERY, paramMap, String.class);
    }

    @Override
    public List<String> getIcReporters(String leader) {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put("LeaderUuid", leader);
        return namedParameterJdbcTemplate.queryForList(LEADER_IC_REPORTS, paramMap, String.class);
    }
}
