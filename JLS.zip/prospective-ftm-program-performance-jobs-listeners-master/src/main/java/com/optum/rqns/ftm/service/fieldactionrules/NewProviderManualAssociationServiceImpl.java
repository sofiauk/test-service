package com.optum.rqns.ftm.service.fieldactionrules;

import com.google.gson.Gson;
import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.model.fieldactionrules.NewProviderManualAssociationAction;
import com.optum.rqns.ftm.model.fieldactionrules.RuleAction;
import com.optum.rqns.ftm.repository.fieldactionrules.NewProviderManualAssociationRepository;
import com.optum.rqns.ftm.util.ProgramPerformanceJobUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Slf4j
public class NewProviderManualAssociationServiceImpl extends FieldActionRuleService {


    @Value("${jobs.workqueueRuleAction.newProviderManualAssociation.batchSize}")
    public int batchSize;

    private NewProviderManualAssociationRepository newProviderManualAssociationRepository;

    public NewProviderManualAssociationServiceImpl(NewProviderManualAssociationRepository newProviderManualAssociationRepository) {
        this.newProviderManualAssociationRepository = newProviderManualAssociationRepository;
        setBatchingRequired(true);
    }

    @Override
    public List<Integer> fetchRuleBatchingOffsetList(int batchsize) {
        setBatchSize(this.batchSize);
        log.info("Inside fetchRuleBatchingOffsetList for RunNewProviderManualAssociationFieldActionRule : transactionID :{} , default batchsize: {}, configured batchsize: {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(),batchsize,this.batchSize);
        return newProviderManualAssociationRepository.getNewProviderManualAssociationRuleCount(this.batchSize);
    }


    @Override
    public List<RuleAction> fetchRuleData(Integer beginIndex,int batchSize, boolean batchingrequired) {
        log.info("Inside fetchRuleData for RunNewProviderManualAssociationFieldActionRule : transactionID :{} , beginIndex: {}, batchSize: {}", ProgramPerformanceJobUtil.TransactionIdLogger.getTransactionIdentifier(),beginIndex,batchSize);
        return newProviderManualAssociationRepository.getNewProviderManualAssociationRuleData(beginIndex,batchSize);
    }


    @Override
    public String getRuleResult(RuleAction ruleAction) {
        Map<String,Object> resultMap=new HashMap<>();
        Gson gson=new Gson();
        if(ruleAction instanceof NewProviderManualAssociationAction){
            NewProviderManualAssociationAction newProviderManualAssociationAction=(NewProviderManualAssociationAction) ruleAction;
            resultMap.put(Constants.PROVIDER_GROUP_ID,newProviderManualAssociationAction.getProviderGroupID());
            resultMap.put(Constants.PROVIDER_STATE,newProviderManualAssociationAction.getProviderState());
            resultMap.put(Constants.PROVIDER_ID,newProviderManualAssociationAction.getProviderID());
        }
        return gson.toJson(resultMap);
    }

    @Override
    public String getRuleContext(RuleAction ruleAction) {
        Map<String,Object> resultMap=new HashMap<>();
        Gson gson=new Gson();
        if(ruleAction instanceof NewProviderManualAssociationAction) {
            NewProviderManualAssociationAction newProviderManualAssociationAction = (NewProviderManualAssociationAction) ruleAction;
            resultMap.put(Constants.ELIGIBLE_PREFERRED_MEMBER_COUNT, newProviderManualAssociationAction.getEligiblePreferredMemberCount());
        }
        return gson.toJson(resultMap);
    }

}
