package com.optum.rqns.ftm.repository.membership;

import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.model.membership.ProviderEligibleMembershipFlatData;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;

@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        ProviderEligibleMembershipRepositoryImpl.class
})
public class ProviderEligibleMembershipRepoImplTest {

    @MockBean
    NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @InjectMocks
    ProviderEligibleMembershipRepositoryImpl repository;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        repository = new ProviderEligibleMembershipRepositoryImpl(this.namedParameterJdbcTemplate);
    }

    private static final String MODIFIED_CONDITION = "where CAST(PafxMemberUpdatedDate as date) >= (select CAST(LastSuccessfulRunDate as date)" +
            " from ProgPerf.jobrunconfiguration where jobname= '" + JobName.RUN_PROVIDER_ELIGIBLE_MEMBERSHIP.getValue() + "')";

    private static final String FETCH_PROVIDER_MEMBERSHIP = "SELECT     " +
            "      ProviderGroupId,     " +
            "      ProviderId,     " +
            "      ProviderName,     " +
            "      ProviderState,     " +
            "      ProgramYear,     " +
            "      ClientId,     " +
            "      LobName,     " +
            "      ClientName,     " +
            "      count(*) as eligibleMemberCount      " +
            "FROM     " +
            "      ProgPerf.PafExMemberAssessment  WITH (NOLOCK)   " +
            "where     " +
            "      RecordStatus <> 'Deleted'     " +
            "      AND ProgramYear = (     " +
            "      SELECT     " +
            "            [value]     " +
            "      FROM     " +
            "            ProgPerf.MasterConfiguration  WITH (NOLOCK)     " +
            "      WHERE     " +
            "            code = 'CurrentProgramYear')     " +
            "      AND IsSuppressed = 'N'  " +
            "  %s     " +
            "   GROUP BY     " +
            "      ProviderGroupId,     " +
            "      ProviderId,     " +
            "      ProviderName,     " +
            "      ProviderState,     " +
            "      ProgramYear,     " +
            "      ClientId,     " +
            "      LobName,     " +
            "      ClientName     " ;

    private static final String RECORD_COUNT_QUERY = "SELECT count(*) as recCount FROM ("+FETCH_PROVIDER_MEMBERSHIP+") AS memberShipCount ";

    private static final String FETCH_PROVIDER_MEMBERSHIP_WITH_BATCH = FETCH_PROVIDER_MEMBERSHIP + " ORDER BY ProviderGroupId, ProviderId, ProviderName, ProviderState,LobName offset :OFFSET rows FETCH next :BatchSize rows only";


    @Test
    public void processProviderEligibleMembershipDetailsAllScenario() {

        JobEvent jobEvent = new JobEvent();
        jobEvent.setJobName(JobName.RUN_PROVIDER_ELIGIBLE_MEMBERSHIP.getValue());
        jobEvent.setGroupsToExecute("All");
        jobEvent.setProgramYear(2022);

        List<ProviderEligibleMembershipFlatData> result = new ArrayList<>();
        String query1 = String.format(FETCH_PROVIDER_MEMBERSHIP, "");
        SqlParameterSource sqlParameterSource = new MapSqlParameterSource("BatchSize", 10)
                .addValue("OFFSET", 5);

        Mockito.when(namedParameterJdbcTemplate.query(query1, new BeanPropertyRowMapper<>(ProviderEligibleMembershipFlatData.class)))
                .thenReturn(result);


        List<ProviderEligibleMembershipFlatData> providerEligibleMembershipDetails = repository.getProviderEligibleMembershipDetails(10,1,jobEvent);

        assert providerEligibleMembershipDetails.size() == 0;
    }

    @Test
    public void processProviderEligibleMembershipDetailsModifiedScenario() {

        JobEvent jobEvent = new JobEvent();
        jobEvent.setJobName(JobName.RUN_PROVIDER_ELIGIBLE_MEMBERSHIP.getValue());
        jobEvent.setGroupsToExecute("Modified");
        jobEvent.setProgramYear(2022);

        List<ProviderEligibleMembershipFlatData> result = new ArrayList<>();
        String query1 = String.format(FETCH_PROVIDER_MEMBERSHIP, MODIFIED_CONDITION);
        SqlParameterSource sqlParameterSource = new MapSqlParameterSource("BatchSize", 10)
                .addValue("OFFSET", 5);

        Mockito.when(namedParameterJdbcTemplate.query(query1, sqlParameterSource,new BeanPropertyRowMapper<>(ProviderEligibleMembershipFlatData.class)))
                .thenReturn(result);


        List<ProviderEligibleMembershipFlatData> providerEligibleMembershipDetails = repository.getProviderEligibleMembershipDetails(10,1 ,jobEvent);

        assert providerEligibleMembershipDetails.size() == 0;
    }

    @Test
    public void getRecordCountTest() {

        JobEvent jobEvent = new JobEvent();
        jobEvent.setJobName(JobName.RUN_PROVIDER_ELIGIBLE_MEMBERSHIP.getValue());
        jobEvent.setGroupsToExecute("All");
        jobEvent.setProgramYear(2022);
        SqlParameterSource sqlParameterSource = new MapSqlParameterSource("BatchSize", 10)
                .addValue("OFFSET", 5);


        Mockito.when(namedParameterJdbcTemplate.queryForObject(RECORD_COUNT_QUERY, sqlParameterSource, Long.class))
                .thenReturn(10l);

        Long recordCount = repository.getRecordCount(jobEvent);
        assert recordCount == null;
    }
}