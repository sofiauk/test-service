package com.optum.rqns.ftm.enums;

import org.junit.Assert;
import org.junit.Test;

public class ExecutionWeekTest {

    @Test
    public void apiJobNameTest(){
        ExecutionWeek executionWeek = ExecutionWeek.ALL;
        Assert.assertNotNull(executionWeek.getValue());
        Assert.assertEquals(ExecutionWeek.valueOf("ALL"), executionWeek);

    }
}
