package com.optum.rqns.ftm.model.providergroup;

import com.optum.rqns.ftm.util.GetterSetterTester;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class MemberAssessmentHistoryTest extends GetterSetterTester<MemberAssessmentHistory> {

    @Override
    public MemberAssessmentHistory getTestInstance() {
        return new MemberAssessmentHistory();
    }

    @Test
    public void TestConfig() {
        assertNotNull(getTestInstance());
    }

    @Test
    public void testMemberAssessmentHistory(){


        MemberAssessmentHistory memberAssessmentHistory = new MemberAssessmentHistory("PG1","MN", "test",1, "test","test");
        memberAssessmentHistory.builder();

        Double eligibleMembers = 1d;
        assertEquals("PG1", memberAssessmentHistory.getProvGroupId());
        assertEquals("MN", memberAssessmentHistory.getProviderState());
        assertEquals("test", memberAssessmentHistory.getOverallStatus());
        assertEquals(1, memberAssessmentHistory.getProjectYear());
        assertEquals("test", memberAssessmentHistory.getDerivedDeployed());
        assertEquals("test", memberAssessmentHistory.getReturned());
    }
}