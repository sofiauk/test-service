package com.optum.rqns.ftm;

import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.http.codec.support.DefaultServerCodecConfigurer;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.assertTrue;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Application.class, properties = {"jasypt.encryptor.password=Not4Use"})
@ActiveProfiles("default")
public class ApplicationTests {

    @SpyBean
    private DefaultServerCodecConfigurer serverCodecConfigurer;

    @Test
    public void contextLoads() {
        Assert.assertTrue(true);
    }

    @org.junit.Test
    public void test() {
        try{
            Application.main(new String[] {});

            assertTrue(true);
            // This test will load the spring context
            // and test all the configuration classes and dependency injections.
        }catch(Exception e){
            e.printStackTrace();
        }
    }

}
