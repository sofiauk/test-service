package com.optum.rqns.ftm.service.fieldactionrules;


import com.optum.rqns.ftm.enums.ExecutionWeek;
import com.optum.rqns.ftm.enums.GroupsToExecute;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.RuleEnum;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.producer.JobEventProducer;
import com.optum.rqns.ftm.kafka.producer.KeyBasedFieldActionRuleProducer;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.model.fieldactionrules.ChangeServiceAction;
import com.optum.rqns.ftm.model.fieldactionrules.NewMemberShipAction;
import com.optum.rqns.ftm.model.fieldactionrules.RuleAction;
import com.optum.rqns.ftm.repository.fieldactionrules.NewProviderGroupMembershipRepo;
import com.optum.rqns.ftm.repository.fieldactionrules.NewProviderGroupMembershipRepoImpl;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        NewProviderGroupMembershipServiceImpl.class
})
public class NewProviderGroupMembershipServiceTest {

    @MockBean
    NewProviderGroupMembershipRepo newProviderGroupMembershipRepo;
    @MockBean
    KIERuleOrchestrator kieRuleOrchestrator;
    @MockBean
    private JobEventProducer jobEventProducer;
    @MockBean
    private FieldActionRuleService fieldActionRuleService;
    @MockBean
    KeyBasedFieldActionRuleProducer producerV1;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @InjectMocks
    private NewProviderGroupMembershipServiceImpl newProviderGroupMembershipServiceImpl;

    @Test
    public void executeJob() {
        List<RuleAction> list = new ArrayList<>();
        list.add(new NewMemberShipAction());
        List<Integer> intList= new ArrayList<>();
        intList.add(100);
        JobEvent jobEvent = JobEvent.newBuilder().setJobName(JobName.RUN_NEW_PROVIDER_GROUP_MEMBERSHIP.getValue())
                .setGroupsToExecute(GroupsToExecute.MODIFIED.getValue())
                .setExecutionWeek(ExecutionWeek.ALL.getValue()).setStatus(Status.IN_PROGRESS.getValue())
                .setTimeStamp(Instant.now()).setCascadeEvents(true).build();
        int[] count = {20};
        ReflectionTestUtils.setField(newProviderGroupMembershipServiceImpl, "batchSize", 100);
        Mockito.when(newProviderGroupMembershipRepo.getRowCountforNewProviderMembership(Mockito.anyInt())).thenReturn(Mockito.anyList());
        Mockito.when(newProviderGroupMembershipRepo.processtoSendActionForNewProviderMembership(Mockito.anyInt(),1000)).thenReturn(list);
        Mockito.when(newProviderGroupMembershipRepo.updateBaseLine(Mockito.anyList())).thenReturn(count);
        Mockito.when(kieRuleOrchestrator.getRulesExecutedData(Mockito.anyList(), Mockito.any())).thenReturn(list);
        Mockito.when(jobEventProducer.postToKafka(getJobEvent())).thenReturn(true);
        final JobStatus jobStatus =newProviderGroupMembershipServiceImpl.executeJob(jobEvent);
        assert jobStatus.getUpdatedRows() == 0;

    }

    private JobEvent getJobEvent(){
        JobEvent jobEvent = new JobEvent();
        jobEvent.setProgramYear(2020);
        jobEvent.setJobName("RunWeeklyJobs");
        jobEvent.setExecutionWeek("Current");
        jobEvent.setGroupsToExecute("All");
        jobEvent.setTimeStamp(Instant.now());
        jobEvent.setStatus("Complete");
        jobEvent.setCascadeEvents(true);

        return jobEvent;
    }

    @Test
    public void postprocessing() {
        int[] count = {20};
        List<RuleAction> list = new ArrayList<>();
        list.add(new NewMemberShipAction());
        Mockito.when(newProviderGroupMembershipRepo.updateBaseLine(Mockito.anyList())).thenReturn(count);
        int updated= newProviderGroupMembershipServiceImpl.postProcessing(list);
        assert updated== 20;

    }

    @Test
    public void getresultset() {
        NewMemberShipAction ruleAction = new NewMemberShipAction();
        String updated= newProviderGroupMembershipServiceImpl.getRuleResult(ruleAction);
        assert updated.equals("{}");

    }

    @Test
    public void fetchdataresult() {
        List<RuleAction> list = new ArrayList<>();
        list.add(new NewMemberShipAction());
        Mockito.when(newProviderGroupMembershipRepo.processtoSendActionForNewProviderMembership(0,1000)).thenReturn(list);
        List<RuleAction> data = newProviderGroupMembershipServiceImpl.fetchRuleData(0,1000,true);
        assert data.size()==1;

    }


}