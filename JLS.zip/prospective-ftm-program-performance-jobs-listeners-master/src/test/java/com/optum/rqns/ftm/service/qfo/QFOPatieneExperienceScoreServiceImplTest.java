package com.optum.rqns.ftm.service.qfo;


import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.producer.KeyBasedQFOPatientExperienceScoreSyncProducer;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.model.qfo.QFOPatientExperienceScore;
import com.optum.rqns.ftm.repository.qfo.QFOPatientExperienceScoresRepository;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;


@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        QFOPatientExperienceScoresServiceImpl.class
})
@SpringBootTest(properties = {
        "qfo_patient_experience_scores_producer_thread_pool_size =1000",
})
public class QFOPatieneExperienceScoreServiceImplTest {

    @MockBean
    private QFOPatientExperienceScoresRepository qfoPatientExperienceScoresRepository;

    @MockBean
    private KeyBasedQFOPatientExperienceScoreSyncProducer producer;

    @InjectMocks
    private QFOPatientExperienceScoresServiceImpl qfoPatientExperienceScoresService;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void getQfoPatientExperienceScoresTest() {
        try {
            ReflectionTestUtils.setField(qfoPatientExperienceScoresService, "qfo_patient_experience_scores_producer_thread_pool_size", 1000);

            Mockito.when(qfoPatientExperienceScoresRepository.getRecordCount(getJobEvent(JobName.QFO_PATIENT_EXPERIENCE_SCORES.toString(), false))).thenReturn(1L);

            List<QFOPatientExperienceScore> qfoPatientExperienceScores = getQFOPatientExperienceScores();

            Mockito.when(qfoPatientExperienceScoresRepository.fetchQFOPatientExperienceScores(Constants.BATCH_SIZE, 10000, getJobEvent(JobName.QFO_PATIENT_EXPERIENCE_SCORES.toString(), false)))
                    .thenReturn(qfoPatientExperienceScores);
            JobStatus jobStatus = qfoPatientExperienceScoresService.executeJob(getJobEvent(JobName.QFO_PATIENT_EXPERIENCE_SCORES.toString(), false));
            assert Status.SUCCESS == jobStatus.getStatus();

            assert 1L == jobStatus.getUpdatedRows();

        } catch (Exception e) {
        }

    }

    private JobEvent getJobEvent(String jobName, boolean isModified) {
        JobEvent jobEvent = new JobEvent();
        jobEvent.setProgramYear(2022);
        jobEvent.setJobName(jobName);
        jobEvent.setGroupsToExecute(isModified ? "Modified" : "All");
        jobEvent.setExecutionWeek("Current");
        jobEvent.setTimeStamp(Instant.now());
        jobEvent.setStatus("Complete");
        return jobEvent;
    }

    private List<QFOPatientExperienceScore> getQFOPatientExperienceScores() {

        QFOPatientExperienceScore qfoPatientExperienceScore1 =
                QFOPatientExperienceScore.builder()
                        .providerGroupId("123")
                        .programYear(2022)
                       .cooRate(1f)
                        .dpcRate(1f)
                        .gncRate(3f)
                        .build();

        QFOPatientExperienceScore qfoPatientExperienceScore2 = QFOPatientExperienceScore.builder()
                .providerGroupId("456")
                .programYear(2022)
               .cooRate(3f)
                .dpcRate(4f)
                .gncRate(1f)
                .build();

        List<QFOPatientExperienceScore> qfoPatientExperienceScores = new ArrayList<>();
        qfoPatientExperienceScores.add(qfoPatientExperienceScore1);
        qfoPatientExperienceScores.add(qfoPatientExperienceScore2);

        return qfoPatientExperienceScores;
    }

}