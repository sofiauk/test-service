package com.optum.rqns.ftm.enums;

import org.junit.Assert;
import org.junit.Test;

public class StatusTest {

    @Test
    public void apiStatusTest(){
        Status status = Status.SUCCESS;
        Assert.assertNotNull(status.getValue());
        Assert.assertEquals(Status.valueOf("SUCCESS"), status);

        Status.fromString("Failure1");

        Assert.assertEquals(Status.FAILURE, Status.fromString("Failure"));
    }
}
