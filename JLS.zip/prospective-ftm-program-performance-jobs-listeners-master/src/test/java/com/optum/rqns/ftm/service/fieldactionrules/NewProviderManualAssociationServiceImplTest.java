package com.optum.rqns.ftm.service.fieldactionrules;

import com.optum.rqns.ftm.enums.ExecutionWeek;
import com.optum.rqns.ftm.enums.GroupsToExecute;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.producer.JobEventProducer;
import com.optum.rqns.ftm.kafka.producer.KeyBasedFieldActionRuleProducer;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.model.fieldactionrules.NewProviderManualAssociationAction;
import com.optum.rqns.ftm.model.fieldactionrules.RuleAction;
import com.optum.rqns.ftm.repository.fieldactionrules.NewProviderManualAssociationRepositoryImpl;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        NewProviderManualAssociationServiceImpl.class
})
@SpringBootTest(properties = {
        "spring.producer_thread_pool_size=10",
        "jobs.workqueueRuleAction.newProviderGroupMembership.batchSize=10",
})
public class NewProviderManualAssociationServiceImplTest {


    @MockBean
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @MockBean
    private NewProviderManualAssociationRepositoryImpl newProviderManualAssociationRepository;

    @MockBean
    private FieldActionRuleService fieldActionRuleService;

    @InjectMocks
    private NewProviderManualAssociationServiceImpl newProviderManualAssociationService;

    @MockBean
    private JobEventProducer jobEventProducer;

    @MockBean
    KeyBasedFieldActionRuleProducer producerV1;

    @MockBean
    KIERuleOrchestrator kieRuleOrchestrator;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void executeJob() {
        List<RuleAction> list = new ArrayList<>();
        list.add(new NewProviderManualAssociationAction("test", "test", "test", 1, "test", "test"));
        List<Integer> intList = new ArrayList<>();
        intList.add(100);
        Mockito.when(newProviderManualAssociationService.fetchRuleBatchingOffsetList(Mockito.anyInt())).thenReturn(intList);
        ReflectionTestUtils.setField(newProviderManualAssociationService, "producerThreadPoolSize", 1);
        Mockito.when(newProviderManualAssociationRepository.getNewProviderManualAssociationRuleData(2, 2)).thenReturn(getProviderDetailsInfo());
        Mockito.when(kieRuleOrchestrator.getRulesExecutedData(Mockito.anyList(), Mockito.any())).thenReturn(list);
        Mockito.when(jobEventProducer.postToKafka(getJobEvent())).thenReturn(true);

        JobEvent jobEvent = JobEvent.newBuilder().setJobName(JobName.NEW_PROVIDER_MANUAL_ASSOCIATION_JOB.toString())
                .setGroupsToExecute(GroupsToExecute.MODIFIED.getValue())
                .setExecutionWeek(ExecutionWeek.ALL.getValue()).setStatus(Status.IN_PROGRESS.getValue())
                .setTimeStamp(Instant.now()).setCascadeEvents(true).build();
        final JobStatus jobStatus = newProviderManualAssociationService.executeJob(jobEvent);

    }

    @Test
    public void testGetRuleResult() {
        RuleAction ruleAction = this.getProviderDetailsInfo().get(0);
        Assert.assertNotNull(newProviderManualAssociationService.getRuleResult(ruleAction));

    }

    @Test
    public void fetchRuleBatchingOffsetListTest() {
        Assert.assertNotNull(newProviderManualAssociationService.fetchRuleBatchingOffsetList(1000));

    }

    private JobEvent getJobEvent() {
        JobEvent jobEvent = new JobEvent();
        jobEvent.setProgramYear(2020);
        jobEvent.setJobName("RunWeeklyJobs");
        jobEvent.setExecutionWeek("Current");
        jobEvent.setGroupsToExecute("All");
        jobEvent.setTimeStamp(Instant.now());
        jobEvent.setStatus("Complete");
        jobEvent.setCascadeEvents(true);

        return jobEvent;
    }

    private List<RuleAction> getProviderDetailsInfo() {

        List<RuleAction> ruleActions = new ArrayList<>();
        NewProviderManualAssociationAction newProviderManualAssociationAction = new NewProviderManualAssociationAction();
        newProviderManualAssociationAction.setProviderGroupID("Test");
        newProviderManualAssociationAction.setProviderID("Test");
        newProviderManualAssociationAction.setProviderState("Test");
        newProviderManualAssociationAction.setEligiblePreferredMemberCount(10);


        ruleActions.add(newProviderManualAssociationAction);
        return ruleActions;
    }

    @Test
    public void getRuleContext(){
        RuleAction ruleAction = this.getProviderDetailsInfo().get(0);
        Assert.assertNotNull(newProviderManualAssociationService.getRuleContext(ruleAction));

    }
}
