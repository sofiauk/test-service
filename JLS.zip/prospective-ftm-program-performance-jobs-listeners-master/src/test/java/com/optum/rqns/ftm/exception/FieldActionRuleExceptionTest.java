package com.optum.rqns.ftm.exception;

import org.junit.Assert;
import org.junit.Test;

public class FieldActionRuleExceptionTest {

    @Test
    public void testFieldActionRuleException() throws FieldActionRulesException{
        FieldActionRulesException fieldActionRulesException = new FieldActionRulesException("test","test","test");
        Assert.assertNotNull(fieldActionRulesException.getErrorMessage());
        Assert.assertNotNull(fieldActionRulesException.getErrorDetails());
        Assert.assertNotNull(fieldActionRulesException.getJobName());

    }
}
