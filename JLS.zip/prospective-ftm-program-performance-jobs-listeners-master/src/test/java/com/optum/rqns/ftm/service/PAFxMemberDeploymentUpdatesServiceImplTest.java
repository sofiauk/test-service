package com.optum.rqns.ftm.service;


import com.optum.rqns.ftm.enums.ExecutionWeek;
import com.optum.rqns.ftm.enums.GroupsToExecute;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.exception.ProgramPerformanceJobListenerException;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.producer.JobEventProducer;
import com.optum.rqns.ftm.kafka.producer.KeyBasedProviderSyncProducer;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.model.providergroup.PAFXMemberData;
import com.optum.rqns.ftm.model.providergroup.ProviderGroup;
import com.optum.rqns.ftm.repository.PAFxMemberDeploymentUpdatesRepository;
import com.optum.rqns.ftm.repository.common.CommonRepository;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.util.DateUtil;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        PAFxMemberDeploymentUpdatesServiceImpl.class
})
@SpringBootTest(properties = {
        "spring.db_connection_thread_pool_size=10",
})
public class PAFxMemberDeploymentUpdatesServiceImplTest {

    @MockBean
    private PAFxMemberDeploymentUpdatesRepository pafxMemberDeploymentUpdatesRepository;

    @InjectMocks
    private PAFxMemberDeploymentUpdatesServiceImpl pafxMemberDeploymentUpdatesServiceImpl;

    @MockBean
    private CommonRepository commonRepository;


    @MockBean
    private KeyBasedProviderSyncProducer producer;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }
    @MockBean
    private JobEventProducer jobEventProducer;

    @Test
    public void executeJob() {
        ReflectionTestUtils.setField(pafxMemberDeploymentUpdatesServiceImpl, "producerThreadPoolSize", 1);

        Mockito.when(pafxMemberDeploymentUpdatesRepository.getRecordCount(2021)).thenReturn(25000l);
        Mockito.when(commonRepository.getJobsLastRunSuccessfulDate(JobName.RUN_PAFX_MEMBER_DEPLOYMENT_UPDATES.name())).thenReturn(DateUtil.now().toString());
        Mockito.when(pafxMemberDeploymentUpdatesRepository.mergePAFXMemberData(25000,0, JobEvent.newBuilder().setProgramYear(2021).build()))
                .thenReturn(0);
        Mockito.when(pafxMemberDeploymentUpdatesRepository.mergePAFXMemberData(25000,0, JobEvent.newBuilder().setProgramYear(2021).build()))
                .thenReturn(0);


        JobEvent jobEvent = JobEvent.newBuilder().setProgramYear(2021).setJobName(JobName.RUN_PAFX_MEMBER_DEPLOYMENT_UPDATES.getValue())
                .setGroupsToExecute(GroupsToExecute.ALL.getValue())
                .setExecutionWeek(ExecutionWeek.ALL.getValue()).setStatus(Status.IN_PROGRESS.getValue())
                .setTimeStamp(Instant.now()).setCascadeEvents(true).build();
        final JobStatus jobStatus = pafxMemberDeploymentUpdatesServiceImpl.executeJob(jobEvent);

        assert jobStatus.getUpdatedRows() == 0;
    }

    private JobEvent getJobEvent(){
        JobEvent jobEvent = new JobEvent();
        jobEvent.setProgramYear(2020);
        jobEvent.setJobName(JobName.RUN_ELIGIBLE_MEMBER_COUNT.getValue());
        jobEvent.setExecutionWeek("Current");
        jobEvent.setGroupsToExecute("All");
        jobEvent.setTimeStamp(Instant.now());
        jobEvent.setStatus("Complete");
        jobEvent.setCascadeEvents(true);

        return jobEvent;
    }
    @Test
    public void executeJobException() {
        ReflectionTestUtils.setField(pafxMemberDeploymentUpdatesServiceImpl, "producerThreadPoolSize", 1);

        JobEvent jobEventinput = JobEvent.newBuilder().setJobName(JobName.RUN_PAFX_MEMBER_DEPLOYMENT_UPDATES.getValue())
                .setProgramYear(2021)
                .setGroupsToExecute(GroupsToExecute.ALL.getValue())
                .setExecutionWeek(ExecutionWeek.ALL.getValue()).setStatus(Status.IN_PROGRESS.getValue())
                .setTimeStamp(Instant.now()).setCascadeEvents(true).build();
        Mockito.when(pafxMemberDeploymentUpdatesRepository.getRecordCount(2021)).thenReturn(25000l);
        Mockito.when(commonRepository.getJobsLastRunSuccessfulDate(JobName.RUN_PAFX_MEMBER_DEPLOYMENT_UPDATES.name())).thenReturn(DateUtil.now().toString());
        Mockito.when(pafxMemberDeploymentUpdatesRepository.mergePAFXMemberData(25000, 0, jobEventinput))
                .thenThrow(new ProgramPerformanceJobListenerException(""));

        final JobStatus jobStatus = pafxMemberDeploymentUpdatesServiceImpl.executeJob(jobEventinput);
        assert Status.FAILURE == jobStatus.getStatus();
        assert 0 == jobStatus.getUpdatedRows();
    }
    @Test
    public void executeJobModified() {
        ReflectionTestUtils.setField(pafxMemberDeploymentUpdatesServiceImpl, "producerThreadPoolSize", 1);

        Mockito.when(pafxMemberDeploymentUpdatesRepository.getRecordCount(2021)).thenReturn(25000l);
        Mockito.when(commonRepository.getJobsLastRunSuccessfulDate(JobName.RUN_PAFX_MEMBER_DEPLOYMENT_UPDATES.name())).thenReturn(DateUtil.now().toString());
        Mockito.when(pafxMemberDeploymentUpdatesRepository.getRecordCountModified(Mockito.anyInt(),Mockito.anyString()))
                .thenReturn(100l);
        ArrayList<Integer> list = new ArrayList<>();
        list.add(1);
        list.add(2);
        Mockito.when(pafxMemberDeploymentUpdatesRepository.getListOfModifiedIdFromPafx(25000,0,2022,DateUtil.now().toString()))
                .thenReturn(list);
        Mockito.when(pafxMemberDeploymentUpdatesRepository.getListOfModifiedIdFromPafx(25000,25000,2022,DateUtil.now().toString()))
                .thenReturn(list);

        Mockito.when(pafxMemberDeploymentUpdatesRepository.mergeModifiedData("1"))
                .thenReturn(0);

        JobEvent jobEvent = JobEvent.newBuilder().setProgramYear(2021).setJobName(JobName.RUN_PAFX_MEMBER_DEPLOYMENT_UPDATES.getValue())
                .setGroupsToExecute(GroupsToExecute.MODIFIED.getValue())
                .setExecutionWeek(ExecutionWeek.ALL.getValue()).setStatus(Status.IN_PROGRESS.getValue())
                .setTimeStamp(Instant.now()).setCascadeEvents(true).build();
        final JobStatus jobStatus = pafxMemberDeploymentUpdatesServiceImpl.executeJob(jobEvent);

        assert jobStatus.getUpdatedRows() == 0;
    }


}
