package com.optum.rqns.ftm.repository.jobalerts;

import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.model.JobAlert;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = {
        MonitoringJobRepositoryImpl.class
})
public class MonitoringJobRepositoryImplTest {

    @MockBean
    NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @InjectMocks
    MonitoringJobRepositoryImpl monitoringJobRepository;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }


    @Test
    public void getLongRunningJobs() {
        final JobAlert mockJobAlert = JobAlert.builder().jobName(JobName.MONITORING_JOB.getValue()).build();
        List<JobAlert> mockJobAlerts = new ArrayList<>();
        mockJobAlerts.add(mockJobAlert);
        Mockito.when(namedParameterJdbcTemplate.query(Mockito.any(String.class), Mockito.any(BeanPropertyRowMapper.class)))
                .thenReturn(mockJobAlerts);

        Assert.assertEquals(mockJobAlerts, monitoringJobRepository.getLongRunningJobs());
    }
}