package com.optum.rqns.ftm.repository.commandcenter;



import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;

import static org.junit.jupiter.api.Assertions.*;

@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        CCGrowthRateRepositoryImpl.class
})
@SpringBootTest(properties = {
        "spring.db_connection_thread_pool_size=10",
})
public class CCGrowthRateRepositoryImplTest {

    @MockBean
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @InjectMocks
    private CCGrowthRateRepositoryImpl ccGrowthRateRepository;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }


    @Test
    public void updateAgreedStatusByIPEFlagTest() {
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.any(String.class),Mockito.any(HashMap.class)))
                .thenReturn(20);

        final int recordCount = ccGrowthRateRepository.updateAgreedStatusByIPEFlag(2021);

        assert recordCount == 20;
    }

    @Test
    public void updateAgreedStatusByDeployActualTest() {
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.any(String.class),Mockito.any(HashMap.class)))
                .thenReturn(20);

        final int recordCount = ccGrowthRateRepository.updateAgreedStatusByDeployActual(2021);

        assert recordCount == 20;
    }

    @Test
    public void updateEngagedStatusByDeployActualTest() {
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.any(String.class),Mockito.any(HashMap.class)))
                .thenReturn(20);

        final int recordCount = ccGrowthRateRepository.updateEngagedStatusByDeployActual(2021);

        assert recordCount == 20;
    }

    @Test
    public void flagAgreedAndEngagedTo0Test(){
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.any(String.class),Mockito.any(HashMap.class)))
                .thenReturn(20);

        final int recordCount = ccGrowthRateRepository.flagAgreedAndEngagedTo0(2021);

        assert recordCount == 20;
    }

    @Test
    public void updateMOMGrowthRateTable() {
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.any(String.class),Mockito.any(HashMap.class)))
                .thenReturn(20);

        final int recordCount = ccGrowthRateRepository.updateMOMGrowthRateTable(2021);

        assert recordCount == 20;
    }
}