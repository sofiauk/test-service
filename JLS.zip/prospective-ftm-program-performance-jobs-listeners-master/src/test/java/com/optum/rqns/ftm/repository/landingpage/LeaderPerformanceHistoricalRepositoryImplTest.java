package com.optum.rqns.ftm.repository.landingpage;

import com.optum.rqns.ftm.model.ProgramYearCalendarDTO;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;


import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        LeaderPerformanceHistoricalRepositoryImpl.class
})
@SpringBootTest(properties = {
        "spring.db_connection_thread_pool_size=10",
})
public class LeaderPerformanceHistoricalRepositoryImplTest {

    @MockBean
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
    @InjectMocks
    private LeaderPerformanceHistoricalRepositoryImpl leaderPerformanceHistoricalRepository;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void  getAllProgramYearsDurations(){
        Mockito.when(namedParameterJdbcTemplate.query(Mockito.anyString(), Mockito.anyMap(), (BeanPropertyRowMapper) Mockito.any())).thenReturn(getProgramYearCalendars());
        List<ProgramYearCalendarDTO> programYearCalendarDTOList = leaderPerformanceHistoricalRepository.getAllProgramYearsDurations(2021);
        int programyear = programYearCalendarDTOList.get(0).getProgramYear();
        Assert.assertEquals(programyear,2021);
    }

    @Test
    public void  getPrevoiusYearLastWeekDuration(){
        Mockito.when(namedParameterJdbcTemplate.queryForObject(Mockito.anyString(), Mockito.anyMap(), (BeanPropertyRowMapper) Mockito.any())).thenReturn(getProgramYearCalendar());
        ProgramYearCalendarDTO programYearCalendarDTO = leaderPerformanceHistoricalRepository.getPrevoiusYearLastWeekDuration(2021);
        int programyear = programYearCalendarDTO.getProgramYear();
        Assert.assertEquals(programyear,2021);
    }

    @Test
    public void  getCurrentWeekDurationForProgramyear(){
        Mockito.when(namedParameterJdbcTemplate.queryForObject(Mockito.anyString(), Mockito.anyMap(), (BeanPropertyRowMapper) Mockito.any())).thenReturn(getProgramYearCalendar());
        ProgramYearCalendarDTO programYearCalendarDTO = leaderPerformanceHistoricalRepository.getCurrentWeekDurationForProgramyear(2021);
        int programyear = programYearCalendarDTO.getProgramYear();
        Assert.assertEquals(programyear,2021);
    }

    @Test
    public void loadLeadersHistoricalLeaderPerformanceData(){
        List<String> totalReporters = new ArrayList<>();
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(), Mockito.anyMap())).thenReturn(1);
        int recordCount = leaderPerformanceHistoricalRepository.loadLeadersHistoricalLeaderPerformanceData("test",totalReporters,getProgramYearCalendar(),1,true);
        Assert.assertEquals(1,recordCount);
    }

    @Test
    public void loadHistoricalICPerformanceData(){
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(), Mockito.anyMap())).thenReturn(1);
        int recordCount = leaderPerformanceHistoricalRepository.loadHistoricalICPerformanceData("test","test",getProgramYearCalendar(),1,true);
        Assert.assertEquals(1,recordCount);
    }

    @Test
    public void loadHistoricalLeaderPerformance(){
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(), Mockito.anyMap())).thenReturn(1);
        long recordCount = leaderPerformanceHistoricalRepository.loadHistoricalLeaderPerformance(getProgramYearCalendar(),(int)1,true);
        Assert.assertEquals(1l,recordCount);
    }

    @Test
    public void updateICGoalLeaderPerformance(){
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(), Mockito.anyMap())).thenReturn(1);
        long recordCount = leaderPerformanceHistoricalRepository.updateICGoalLeaderPerformance("test","test",getProgramYearCalendar(),true);
        Assert.assertEquals(1l,recordCount);
    }

    @Test
    public void loadLeaderPerformanceNationalLevelAll(){
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(), Mockito.anyMap())).thenReturn(1);
        long recordCount = leaderPerformanceHistoricalRepository.loadLeaderPerformanceNationalLevelAll(getProgramYearCalendar(),1,true);
        Assert.assertEquals(1l,recordCount);
    }

    private ProgramYearCalendarDTO getProgramYearCalendar() {
        ProgramYearCalendarDTO programYearCalendarDTO = new ProgramYearCalendarDTO();
        programYearCalendarDTO.setProgramYear(2021);
        programYearCalendarDTO.setDurationType("test");
        programYearCalendarDTO.setDurationValue("test");
        programYearCalendarDTO.setId(1l);
        programYearCalendarDTO.setEndDate(LocalDate.now());
        programYearCalendarDTO.setStartDate(LocalDate.now());
        return programYearCalendarDTO;
    }

    private List<ProgramYearCalendarDTO> getProgramYearCalendars() {
        ProgramYearCalendarDTO programYearCalendarDTO = new ProgramYearCalendarDTO();
        programYearCalendarDTO.setProgramYear(2021);
        programYearCalendarDTO.setDurationType("test");
        programYearCalendarDTO.setDurationValue("test");
        programYearCalendarDTO.setId(1l);
        programYearCalendarDTO.setEndDate(LocalDate.now());
        programYearCalendarDTO.setStartDate(LocalDate.now());
        List<ProgramYearCalendarDTO> programYearCalendarDTOList = new ArrayList<>();
        programYearCalendarDTOList.add(programYearCalendarDTO);
        return programYearCalendarDTOList;
    }


}
