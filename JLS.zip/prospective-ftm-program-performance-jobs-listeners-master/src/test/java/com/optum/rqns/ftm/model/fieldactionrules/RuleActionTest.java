package com.optum.rqns.ftm.model.fieldactionrules;

import com.optum.rqns.ftm.util.GetterSetterTester;
import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;

public class RuleActionTest extends GetterSetterTester<RuleAction> {

    @Override
    public RuleAction getTestInstance() {
        ArrayList<String> list = new ArrayList<>();
        return new RuleAction(list,"test","test","test","test","test",false,"test","test","test",true);
    }

    @Test
    public void getRuleAction() {
        RuleAction ruleAction = this.getTestInstance();
        Assert.assertNotNull(ruleAction);
        Assert.assertEquals(ruleAction.getRuleType(),"test");
    }
}
