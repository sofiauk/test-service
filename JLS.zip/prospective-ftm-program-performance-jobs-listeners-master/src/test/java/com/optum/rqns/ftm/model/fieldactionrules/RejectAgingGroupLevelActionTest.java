package com.optum.rqns.ftm.model.fieldactionrules;

import com.optum.rqns.ftm.util.GetterSetterTester;
import org.junit.Assert;
import org.junit.Test;

public class RejectAgingGroupLevelActionTest extends GetterSetterTester<RejectAgingGroupLevelAction> {

    @Override
    public RejectAgingGroupLevelAction getTestInstance() {
        return new RejectAgingGroupLevelAction("test","test",1,"test","test","test");
    }

    @Test
    public void getRejectAgingGroupLevelAction() {
        RejectAgingGroupLevelAction rejectAgingGroupLevelAction = this.getTestInstance();
        Assert.assertNotNull(rejectAgingGroupLevelAction);
        Assert.assertEquals(rejectAgingGroupLevelAction.getServiceLevel(), "test");
        Assert.assertEquals(rejectAgingGroupLevelAction.getAccountId(),"test");
    }
}
