package com.optum.rqns.ftm.repository;

import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;
import java.util.concurrent.Callable;

@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        RunWeeklyIDMTargetsRepositoryImpl.class
})
@SpringBootTest(properties = {
        "spring.db_connection_thread_pool_size=10",
})
public class RunWeeklyIDMTargetsRepositoryImplTest {

    @MockBean
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @InjectMocks
    private RunWeeklyIDMTargetsRepositoryImpl deployReturnTargetsRepository;


    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }


    @Test
    public void getRecordCountTest() {

        Mockito.when(namedParameterJdbcTemplate.queryForObject(Mockito.anyString(),Mockito.any(HashMap.class),Mockito.eq(Long.class)))
                .thenReturn(20l);

        final Long recordCount = deployReturnTargetsRepository.getRecordCount(2021);

        assert recordCount == 20;
    }


    @Test
    public void mergeDataTest() throws Exception {

        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(), Mockito.any(SqlParameterSource.class)))
                .thenReturn(20);

        final Callable<Integer> integerCallable = deployReturnTargetsRepository.mergeData(25000, 0,2021);

        assert integerCallable.call() == 20;
    }

}
