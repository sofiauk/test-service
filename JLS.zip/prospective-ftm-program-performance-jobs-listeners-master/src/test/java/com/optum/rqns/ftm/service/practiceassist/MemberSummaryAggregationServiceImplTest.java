package com.optum.rqns.ftm.service.practiceassist;


import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.optum.rqns.ftm.enums.ExecutionWeek;
import com.optum.rqns.ftm.enums.GroupsToExecute;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.exception.ProgramPerformanceJobListenerException;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.producer.JobEventProducer;
import com.optum.rqns.ftm.kafka.producer.KeyBasedProviderSyncProducer;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.model.practiceassist.PaAggregationData;
import com.optum.rqns.ftm.repository.common.CommonRepository;
import com.optum.rqns.ftm.repository.practiceassist.PaLandingPageRepositoryMysqlImpl;

import lombok.extern.slf4j.Slf4j;

@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        MemberSummaryAggregationServiceImpl.class,PaLandingPageRepositoryMysqlImpl.class
})
@SpringBootTest(properties = {
        "spring.db_connection_thread_pool_size=10",
})
public class MemberSummaryAggregationServiceImplTest {

        
    @MockBean
    private PaLandingPageRepositoryMysqlImpl paLandingPageRepository;
   
    @MockBean
	private CommonRepository commonRepository;

    @MockBean
    private KeyBasedProviderSyncProducer producer;
    
    @InjectMocks
    private  MemberSummaryAggregationServiceImpl memberSummaryAggregationServiceImpl;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);  
    }
    @MockBean
    private JobEventProducer jobEventProducer;
    
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    @Test
    public void executeModifiedJobTest() {
        ReflectionTestUtils.setField(memberSummaryAggregationServiceImpl, "producerThreadPoolSize", 1);
        
        ReflectionTestUtils.setField(memberSummaryAggregationServiceImpl, "FETCH_BATCH_SIZE", 1);
        ReflectionTestUtils.setField(memberSummaryAggregationServiceImpl, "UPSERT_BATCH_SIZE", 1);
        ReflectionTestUtils.setField(memberSummaryAggregationServiceImpl, "threadPoolSize", 1);
        List<String> provGrpList= new ArrayList<String>();
        provGrpList.add("TestprvGrpId-1");

    	
       	
        Mockito.when(commonRepository.fetchLastSucessfullJobStartRanDate(JobName.RUN_MEMBER_SUMMARY_AGGREGATION.getValue())).thenReturn(LocalDateTime.now().format(formatter));
        
        Mockito.when(paLandingPageRepository.getAffectedProvGrpList(Mockito.any(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn( provGrpList);
        
          
        Mockito.when(paLandingPageRepository.markedRecordsAsDirty(Mockito.anyString(),Mockito.anyString(),Mockito.anyInt(), Mockito.anyString(),Mockito.anyString(),Mockito.any())).thenReturn(1);
      
        List<PaAggregationData> paSummaryAggregationList= new ArrayList<PaAggregationData>();
        paSummaryAggregationList.add(new PaAggregationData() );
        Mockito.when(paLandingPageRepository.getPaMemberSummaryAggregateDataByBatch(Mockito.anyInt(),Mockito.anyString(),Mockito.anyString(),Mockito.any()))
                .thenReturn(paSummaryAggregationList);

        Mockito.when(paLandingPageRepository.upserMemberSummaryAggregation(paSummaryAggregationList)).thenReturn(1);
        
        Mockito. when(paLandingPageRepository.inActivateDirtyRecords(Mockito.anyString(),Mockito.anyString(), Mockito.anyInt(), Mockito.anyString(),Mockito.anyString(),Mockito.any())).thenReturn(1);
   
          
        final JobStatus jobStatus = memberSummaryAggregationServiceImpl.executeJob(getJobEvent(GroupsToExecute.MODIFIED.getValue()));
         assert jobStatus.getUpdatedRows() == 1;
    }

    
    @Test
    public void executeAllJobTest() {
        ReflectionTestUtils.setField(memberSummaryAggregationServiceImpl, "producerThreadPoolSize", 1);
        ReflectionTestUtils.setField(memberSummaryAggregationServiceImpl, "FETCH_BATCH_SIZE", 1);
        ReflectionTestUtils.setField(memberSummaryAggregationServiceImpl, "UPSERT_BATCH_SIZE", 1);
        ReflectionTestUtils.setField(memberSummaryAggregationServiceImpl, "threadPoolSize", 1);

        List<String> provGrpList= new ArrayList<String>();
        provGrpList.add("TestprvGrpId-1");

        
        Mockito.when(paLandingPageRepository.getAffectedProvGrpList(Mockito.any(),ArgumentMatchers.isNull(),ArgumentMatchers.isNull(),Mockito.anyString())).thenReturn( provGrpList);
        
        Mockito.when(paLandingPageRepository.markedRecordsAsDirty(Mockito.anyString(),Mockito.anyString(),Mockito.anyInt(), ArgumentMatchers.isNull(),ArgumentMatchers.isNull(),Mockito.any())).thenReturn(1);
     
            
        List<PaAggregationData> paSummaryAggregationList= new ArrayList<PaAggregationData>();
        paSummaryAggregationList.add(new PaAggregationData() );
        Mockito.when(paLandingPageRepository.getPaMemberSummaryAggregateDataByBatch(Mockito.anyInt(),ArgumentMatchers.isNull(),ArgumentMatchers.isNull(),Mockito.any(List.class)))
                .thenReturn(paSummaryAggregationList);

        Mockito.when(paLandingPageRepository.upserMemberSummaryAggregation(paSummaryAggregationList)).thenReturn(1);
   
        Mockito. when(paLandingPageRepository.inActivateDirtyRecords(Mockito.anyString(),Mockito.anyString(), Mockito.anyInt(), ArgumentMatchers.isNull(),ArgumentMatchers.isNull(),Mockito.any())).thenReturn(1);
          
        final JobStatus jobStatus =memberSummaryAggregationServiceImpl.executeJob(getJobEvent(GroupsToExecute.ALL.getValue()));
                
        assert jobStatus.getUpdatedRows() == 1;
    }
    
    
    @Test
    public void executeJobExceptionTest() {
        ReflectionTestUtils.setField(memberSummaryAggregationServiceImpl, "producerThreadPoolSize", 1);
        ReflectionTestUtils.setField(memberSummaryAggregationServiceImpl, "FETCH_BATCH_SIZE", 1);
        ReflectionTestUtils.setField(memberSummaryAggregationServiceImpl, "UPSERT_BATCH_SIZE", 1);
        ReflectionTestUtils.setField(memberSummaryAggregationServiceImpl, "threadPoolSize", 1);

        List<PaAggregationData> paSummaryAggregationList= new ArrayList<PaAggregationData>();
        paSummaryAggregationList.add(new PaAggregationData() );
        
        Mockito.when(paLandingPageRepository.getPaMemberSummaryAggregateDataByBatch(Mockito.anyInt(),ArgumentMatchers.isNull(),ArgumentMatchers.isNull(),Mockito.any(List.class))) 
        .thenThrow(new ProgramPerformanceJobListenerException(""));

        Mockito.when(paLandingPageRepository.upserMemberSummaryAggregation(paSummaryAggregationList)).thenReturn(1);
   
          
        final JobStatus jobStatus = memberSummaryAggregationServiceImpl.executeJob(getJobEvent(GroupsToExecute.ALL.getValue()));
        
        assert 0 == jobStatus.getUpdatedRows();
    }
    private JobEvent getJobEvent(String groupsToExecute){
        JobEvent jobEvent = new JobEvent();
        jobEvent.setJobName(JobName.RUN_MEMBER_SUMMARY_AGGREGATION.getValue());
        jobEvent.setExecutionWeek( ExecutionWeek.ALL.getValue());
        jobEvent.setGroupsToExecute(groupsToExecute);
        jobEvent.setProgramYear(2021);
        jobEvent.setTimeStamp(Instant.now());
        jobEvent.setStatus(Status.IN_PROGRESS.getValue()); 
       
        return jobEvent;
    }
   
     


}
