package com.optum.rqns.ftm.service.jobalerts;

import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.model.JobAlert;
import com.optum.rqns.ftm.repository.common.CommonRepository;
import com.optum.rqns.ftm.repository.jobalerts.MonitoringJobRepository;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertTrue;

@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        MonitoringJobServiceImpl.class
})
public class MonitoringJobServiceImplTest {

    @InjectMocks
    MonitoringJobServiceImpl monitoringJobService;

    @MockBean
    MonitoringJobRepository monitoringJobRepository;

    @MockBean
    CommonRepository commonRepository;

    @MockBean
    PrometheusJobAlertService prometheusJobAlertService;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }


    @Test
    public void monitorJobs() {
        List<JobAlert> jobAlerts = new ArrayList<>();
        jobAlerts.add(JobAlert.builder()
                .jobName(JobName.MONITORING_JOB.getValue()).build());
        Mockito.when(monitoringJobRepository.getLongRunningJobs()).thenReturn(jobAlerts);
        monitoringJobService.monitorJobs();
        assertTrue(true);
    }

    @Test
    public void monitorJobsExceptionTest() {
        List<JobAlert> jobAlerts = new ArrayList<>();
        jobAlerts.add(JobAlert.builder()
                .jobName(JobName.MONITORING_JOB.getValue()).build());
        Mockito.when(monitoringJobRepository.getLongRunningJobs()).thenThrow(new RuntimeException());
        try {
            monitoringJobService.monitorJobs();
            Assert.assertTrue(false);
        } catch (Exception e) {
            assertTrue(true);
        }
    }
}