package com.optum.rqns.ftm.repository.fieldactionrules;

import com.optum.rqns.ftm.model.fieldactionrules.RuleAction;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        ReturnTargetTrackingRepoImpl.class
})
public class ReturnTargetTrackingRepoImplTest {

    @MockBean
    NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @MockBean
    ResultSet resultSet;

    @InjectMocks
    ReturnTargetTrackingRepoImpl returnTargetTrackingRepo;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void getNewProviderManualAssociationRuleDataTest() {
        List<RuleAction> list = returnTargetTrackingRepo.fetchReturnTargetInfo();
        Assert.assertNotNull(list);

    }

    @Test
    public void testMapper() throws SQLException {
        ReturnTargetTrackingRepoImpl.ReturnTargetTrackingRowMapper mapper = new ReturnTargetTrackingRepoImpl.ReturnTargetTrackingRowMapper();
        Mockito.when(resultSet.getDouble("ReturnedNetCnaYtdActual")).thenReturn(2d);
        Mockito.when(resultSet.getDouble("ReturnYTDTarget")).thenReturn(2d);
        Mockito.when(resultSet.getString("OwnerUUID")).thenReturn("Test123");
        RuleAction action = mapper.mapRow(resultSet, 1);
        Assert.assertNotNull(action);
    }
}
