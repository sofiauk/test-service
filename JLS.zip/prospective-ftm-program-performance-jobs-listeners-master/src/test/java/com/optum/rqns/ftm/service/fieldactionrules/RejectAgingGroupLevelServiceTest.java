package com.optum.rqns.ftm.service.fieldactionrules;

import com.optum.rqns.ftm.enums.ExecutionWeek;
import com.optum.rqns.ftm.enums.GroupsToExecute;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.RuleEnum;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.producer.JobEventProducer;
import com.optum.rqns.ftm.kafka.producer.KeyBasedFieldActionRuleProducer;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.model.fieldactionrules.RejectAgingGroupLevelAction;
import com.optum.rqns.ftm.model.fieldactionrules.ReturnTargetTrackingAction;
import com.optum.rqns.ftm.model.fieldactionrules.RuleAction;
import com.optum.rqns.ftm.repository.fieldactionrules.RejectAgingGroupLevelRepoImpl;
import com.optum.rqns.ftm.repository.fieldactionrules.ReturnTargetTrackingRepoImpl;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
public class RejectAgingGroupLevelServiceTest {

    @MockBean
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @MockBean
    private RejectAgingGroupLevelRepoImpl  rejectAgingGroupLevelRepoImpl;

    @InjectMocks
    private RejectAgingGroupLevelServiceImpl rejectAgingGroupLevelServiceImpl;

    @MockBean
    private JobEventProducer jobEventProducer;

    @MockBean
    KIERuleOrchestrator kieRuleOrchestrator;

    @MockBean
    private KeyBasedFieldActionRuleProducer keyBasedFieldActionRuleProducer;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void executeJob() {

        List<Integer> intList = new ArrayList<>();
        intList.add(100);

        ReflectionTestUtils.setField(rejectAgingGroupLevelServiceImpl, "producerThreadPoolSize", 1);
        ReflectionTestUtils.setField(rejectAgingGroupLevelServiceImpl, "batchSize", 1);
        Mockito.when(rejectAgingGroupLevelRepoImpl.getRowCountAndBatchesForReturnAging(1)).thenReturn(intList);
        Mockito.when(rejectAgingGroupLevelRepoImpl.fetchRejectAgingInfo(Mockito.anyInt(), Mockito.anyInt())).thenReturn((getRejectAgingInfo()));
        Mockito.when(kieRuleOrchestrator.getRulesExecutedData(Mockito.anyList(),Mockito.any())).thenReturn((getRejectAgingInfo()));
        Mockito.when(keyBasedFieldActionRuleProducer.postToKafka(Mockito.any(),Mockito.anyString())).thenReturn(true);

        Mockito.when(jobEventProducer.postToKafka(Mockito.any())).thenReturn(true);

        final JobStatus jobStatus = rejectAgingGroupLevelServiceImpl.executeJob(getJobEvent());
        Assert.assertEquals(Status.SUCCESS,jobStatus.getStatus());
        Assert.assertEquals((Long) 1L, jobStatus.getUpdatedRows());
    }

    @Test
    public void executeJob_Exception() {
        Mockito.when(rejectAgingGroupLevelRepoImpl.fetchRejectAgingInfo(0,100)).thenThrow(new NullPointerException());

        final JobStatus jobStatus = rejectAgingGroupLevelServiceImpl.executeJob(getJobEvent());

        Assert.assertEquals(Status.SUCCESS,jobStatus.getStatus());
       // Assert.assertEquals((Long) 0L, jobStatus.getUpdatedRows());
    }

    private JobEvent getJobEvent(){
        return JobEvent.newBuilder().setJobName(JobName.REJECT_AGING_JOB.toString())
                .setGroupsToExecute(GroupsToExecute.MODIFIED.getValue())
                .setExecutionWeek(ExecutionWeek.ALL.getValue()).setStatus(Status.IN_PROGRESS.getValue())
                .setTimeStamp(Instant.now()).setCascadeEvents(true).build();
    }

    private List<RuleAction> getRejectAgingInfo(){
        List<RuleAction> ruleActions=new ArrayList<>();
        List<String> userList=new ArrayList<>();
        RejectAgingGroupLevelAction rejectAgingGroupLevelAction =new RejectAgingGroupLevelAction();
        rejectAgingGroupLevelAction.setSingleRejectDaysCount(123);
        rejectAgingGroupLevelAction.setProviderGroupId("411817152");
        rejectAgingGroupLevelAction.setProviderState("NY");
        rejectAgingGroupLevelAction.setServiceLevel("HCA");
        rejectAgingGroupLevelAction.setProviderGroupName("FAMILY HEALTH SERVICES MINNESOTA PA");
        userList.add("12345");
        rejectAgingGroupLevelAction.setRuleType(JobName.REJECT_AGING_JOB.toString());
        rejectAgingGroupLevelAction.setUserUuid(userList);
        ruleActions.add(rejectAgingGroupLevelAction);
        return ruleActions;
    }

    @Test
    public void testGetRuleResult() {
        RuleAction ruleAction = this.getRejectAgingInfo().get(0);
        Assert.assertNotNull(rejectAgingGroupLevelServiceImpl.getRuleResult(ruleAction));

    }

    @Test
    public void testGetRuleContext() {
        RuleAction ruleAction = this.getRejectAgingInfo().get(0);
        Assert.assertNotNull(rejectAgingGroupLevelServiceImpl.getRuleContext(ruleAction));

    }
}
