package com.optum.rqns.ftm.service.practiceassist;


import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import org.assertj.core.util.DateUtil;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.optum.rqns.ftm.enums.ExecutionWeek;
import com.optum.rqns.ftm.enums.GroupsToExecute;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.exception.ProgramPerformanceJobListenerException;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.producer.JobEventProducer;
import com.optum.rqns.ftm.kafka.producer.KeyBasedProviderSyncProducer;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.model.practiceassist.PaAggregationData;
import com.optum.rqns.ftm.repository.common.CommonRepository;
import com.optum.rqns.ftm.repository.practiceassist.PaLandingPageRepository;

import lombok.extern.slf4j.Slf4j;

@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
		HospitalEventsAggregationServiceImpl.class
})
@SpringBootTest(properties = {
        "spring.db_connection_thread_pool_size=10",
})
public class HospitalEventsAggregationServiceImplTest { 

        
    @MockBean
    @Qualifier("PaLandingPageRepositorySQL")
    private PaLandingPageRepository paLandingPageRepository;
   
    @MockBean
	private CommonRepository commonRepository;

    @MockBean
    private KeyBasedProviderSyncProducer producer;
    
    @InjectMocks
    private  HospitalEventsAggregationServiceImpl hospitalEventsAggregationServiceImpl;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);  
    }
    @MockBean
    private JobEventProducer jobEventProducer;

    @Test
    public void executeModifiedJobTest() {
        //ReflectionTestUtils.setField(hospitalEventsAggregationServiceImpl, "producerThreadPoolSize", 1);
        
        ReflectionTestUtils.setField(hospitalEventsAggregationServiceImpl, "FETCH_BATCH_SIZE", 1);
        ReflectionTestUtils.setField(hospitalEventsAggregationServiceImpl, "UPSERT_BATCH_SIZE", 1);
        ReflectionTestUtils.setField(hospitalEventsAggregationServiceImpl, "threadPoolSize", 1);
        
        List<String> provGrpList= new ArrayList<String>();
        provGrpList.add("TestprvGrpId-1");

        Mockito.when(commonRepository.fetchLastSucessfullJobStartRanDate(JobName.RUN_MEMBER_HOSPITAL_EVENTS_AGGREGATION.getValue())).thenReturn(DateUtil.now().toString());
        
        Mockito.when(paLandingPageRepository.getAffectedProvGrpList(Mockito.anyInt(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn( provGrpList);
        
        
        Mockito.when(paLandingPageRepository.getRecordCountModifiedByPrvGrps(Mockito.anyString(), Mockito.anyString(),
    			Mockito.anyInt(), Mockito.anyString(),Mockito.anyString())).thenReturn(1L);
        
        Mockito.when(paLandingPageRepository.markedRecordsAsDirty(Mockito.anyString(),Mockito.anyString(),Mockito.anyInt(), Mockito.anyString(),Mockito.anyString())).thenReturn(1);
      
        List<PaAggregationData> paHospitalEventsAggregationList= new ArrayList<PaAggregationData>();
        paHospitalEventsAggregationList.add(new PaAggregationData() );
        Mockito.when(paLandingPageRepository.getPaAggregateDataByBatch(Mockito.anyInt(),Mockito.anyString(),Mockito.anyString(),Mockito.anyInt(),Mockito.anyInt()))
                .thenReturn(paHospitalEventsAggregationList);

        Mockito.when(paLandingPageRepository.upserHospitalEventsAggregation(paHospitalEventsAggregationList)).thenReturn(1);
        
        Mockito. when(paLandingPageRepository.inActivateDirtyRecords(Mockito.anyString(),Mockito.anyString(), Mockito.anyInt(), Mockito.anyString(),Mockito.anyString())).thenReturn(1);
   
          
        final JobStatus jobStatus = hospitalEventsAggregationServiceImpl.executeJob(getJobEvent(GroupsToExecute.MODIFIED.getValue()));
         assert jobStatus.getUpdatedRows() == 0;
    }

    
    @Test
    public void executeAllJobTest() {
       // ReflectionTestUtils.setField(hospitalEventsAggregationServiceImpl, "producerThreadPoolSize", 1);
        ReflectionTestUtils.setField(hospitalEventsAggregationServiceImpl, "FETCH_BATCH_SIZE", 1);
        ReflectionTestUtils.setField(hospitalEventsAggregationServiceImpl, "UPSERT_BATCH_SIZE", 1);
        ReflectionTestUtils.setField(hospitalEventsAggregationServiceImpl, "threadPoolSize", 1);

        List<String> provGrpList= new ArrayList<String>();
        provGrpList.add("TestprvGrpId-1");

        
        Mockito.when(paLandingPageRepository.getRecordCountModifiedByPrvGrps(Mockito.anyString(), Mockito.anyString(),Mockito.anyInt(), ArgumentMatchers.isNull(),ArgumentMatchers.isNull())).thenReturn(1L);
        
        Mockito.when(paLandingPageRepository.markedRecordsAsDirty(Mockito.anyString(),Mockito.anyString(),Mockito.anyInt(), ArgumentMatchers.isNull(),ArgumentMatchers.isNull())).thenReturn(1);
     
            
        List<PaAggregationData> paHospitalEventsAggregationList= new ArrayList<PaAggregationData>();
        paHospitalEventsAggregationList.add(new PaAggregationData() );
        Mockito.when(paLandingPageRepository.getPaAggregateDataByBatch(Mockito.anyInt(),ArgumentMatchers.isNull(),ArgumentMatchers.isNull(),Mockito.anyInt(),Mockito.anyInt()))
                .thenReturn(paHospitalEventsAggregationList);

        Mockito.when(paLandingPageRepository.upserHospitalEventsAggregation(paHospitalEventsAggregationList)).thenReturn(1);
   
        Mockito. when(paLandingPageRepository.inActivateDirtyRecords(Mockito.anyString(),Mockito.anyString(), Mockito.anyInt(), ArgumentMatchers.isNull(),ArgumentMatchers.isNull())).thenReturn(1);
          
        final JobStatus jobStatus = hospitalEventsAggregationServiceImpl.executeJob(getJobEvent(GroupsToExecute.ALL.getValue()));
                
        assert jobStatus.getUpdatedRows() == 0;
    }
    
    
    @Test
    public void executeJobExceptionTest() {
       // ReflectionTestUtils.setField(hospitalEventsAggregationServiceImpl, "producerThreadPoolSize", 1);
        ReflectionTestUtils.setField(hospitalEventsAggregationServiceImpl, "FETCH_BATCH_SIZE", 1);
        ReflectionTestUtils.setField(hospitalEventsAggregationServiceImpl, "UPSERT_BATCH_SIZE", 1);
        ReflectionTestUtils.setField(hospitalEventsAggregationServiceImpl, "threadPoolSize", 1);

        Mockito.when(paLandingPageRepository.getRecordCountModifiedByPrvGrps(Mockito.anyString(), Mockito.anyString(),Mockito.anyInt(), ArgumentMatchers.isNull(),ArgumentMatchers.isNull())).thenReturn(1L);
     
            
        List<PaAggregationData> paHospitalEventsAggregationList= new ArrayList<PaAggregationData>();
        paHospitalEventsAggregationList.add(new PaAggregationData() );
        Mockito.when(paLandingPageRepository.getPaAggregateDataByBatch(Mockito.anyInt(),ArgumentMatchers.isNull(),Mockito.anyInt(),Mockito.anyInt()))
        .thenThrow(new ProgramPerformanceJobListenerException(""));

        Mockito.when(paLandingPageRepository.upserHospitalEventsAggregation(paHospitalEventsAggregationList)).thenReturn(1);
   
          
        final JobStatus jobStatus = hospitalEventsAggregationServiceImpl.executeJob(getJobEvent(GroupsToExecute.ALL.getValue()));
        
        assert 0 == jobStatus.getUpdatedRows();
    }
    private JobEvent getJobEvent(String groupsToExecute){
        JobEvent jobEvent = new JobEvent();
        jobEvent.setJobName(JobName.RUN_MEMBER_HOSPITAL_EVENTS_AGGREGATION.getValue());
        jobEvent.setExecutionWeek( ExecutionWeek.ALL.getValue());
        jobEvent.setGroupsToExecute(groupsToExecute);
        jobEvent.setProgramYear(2021);
        jobEvent.setTimeStamp(Instant.now());
        jobEvent.setStatus(Status.IN_PROGRESS.getValue()); 
       
        return jobEvent;
    }
   
     


}
