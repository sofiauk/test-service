package com.optum.rqns.ftm.kafka.producer;

import com.optum.rqns.ftm.enums.ExecutionWeek;
import com.optum.rqns.ftm.enums.GroupsToExecute;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.exception.ProgramPerformanceJobListenerException;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.KafkaException;
import org.junit.Assert;
import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.kafka.core.KafkaProducerException;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.util.concurrent.ListenableFuture;

@SpringBootTest
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        JobEventProducer.class
})
public class JobEventProducerTest {

    @BeforeEach
    public void initMocks() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void postToKafka() {
        SendResult<String, JobEvent> sendResult = Mockito.mock(SendResult.class);
        ListenableFuture<SendResult<String, JobEvent>> listenableFuture =
                Mockito.mock(ListenableFuture.class);

        KafkaTemplate<String, JobEvent> kafkaTemplate =
                Mockito.mock(KafkaTemplate.class);

        Mockito.doNothing().when(kafkaTemplate).flush();
        Mockito.when(listenableFuture.isDone()).thenReturn(true);
        Mockito.when(kafkaTemplate.send(Mockito.anyString(),Mockito.anyInt(),Mockito.any(),Mockito.any())).thenReturn(listenableFuture);

        JobEvent jobEvent = new JobEvent();
        jobEvent.setJobName(JobName.IDM_GLIDEPATH.getValue());
        jobEvent.setCascadeEvents(true);
        jobEvent.setExecutionWeek(ExecutionWeek.CURRENT.getValue());
        jobEvent.setGroupsToExecute(GroupsToExecute.ALL.getValue());

        JobEventProducer jobEventProducer
                = new JobEventProducer(kafkaTemplate);
        jobEventProducer.topicName = "DataSync.Program.Performance.JobEvent";

        boolean result = jobEventProducer.postToKafka(jobEvent);

        Assert.assertTrue(result);
    }

    @Test(expected = ProgramPerformanceJobListenerException.class)
    public void postToKafka_KafkaProducerException() {
        SendResult<String, JobEvent> sendResult = Mockito.mock(SendResult.class);
        ListenableFuture<SendResult<String, JobEvent>> listenableFuture =
                Mockito.mock(ListenableFuture.class);

        KafkaTemplate<String, JobEvent> kafkaTemplate =
                Mockito.mock(KafkaTemplate.class);

        ProducerRecord producerRecord = new ProducerRecord("test", "test");
        Mockito.doNothing().when(kafkaTemplate).flush();
        Mockito.when(listenableFuture.isDone()).thenReturn(true);
        Mockito.when(kafkaTemplate.send(Mockito.anyString(),Mockito.anyInt(),Mockito.any(),Mockito.any())).thenThrow(new KafkaProducerException(producerRecord, "test", new NullPointerException()));

        JobEvent jobEvent = new JobEvent();
        jobEvent.setJobName(JobName.IDM_GLIDEPATH.getValue());
        jobEvent.setCascadeEvents(true);
        jobEvent.setExecutionWeek(ExecutionWeek.CURRENT.getValue());
        jobEvent.setGroupsToExecute(GroupsToExecute.ALL.getValue());

        JobEventProducer jobEventProducer
                = new JobEventProducer(kafkaTemplate);
        jobEventProducer.topicName = "DataSync.Program.Performance.JobEvent";

        boolean result = jobEventProducer.postToKafka(jobEvent);
    }

    @Test(expected = ProgramPerformanceJobListenerException.class)
    public void postToKafka_KafkaException() {
        SendResult<String, JobEvent> sendResult = Mockito.mock(SendResult.class);
        ListenableFuture<SendResult<String, JobEvent>> listenableFuture =
                Mockito.mock(ListenableFuture.class);

        KafkaTemplate<String, JobEvent> kafkaTemplate =
                Mockito.mock(KafkaTemplate.class);

        Mockito.doNothing().when(kafkaTemplate).flush();
        Mockito.when(listenableFuture.isDone()).thenReturn(true);
        Mockito.when(kafkaTemplate.send(Mockito.anyString(),Mockito.anyInt(),Mockito.any(),Mockito.any())).thenThrow(new KafkaException("test"));

        JobEvent jobEvent = new JobEvent();
        jobEvent.setJobName(JobName.IDM_GLIDEPATH.getValue());
        jobEvent.setCascadeEvents(true);
        jobEvent.setExecutionWeek(ExecutionWeek.CURRENT.getValue());
        jobEvent.setGroupsToExecute(GroupsToExecute.ALL.getValue());

        JobEventProducer jobEventProducer
                = new JobEventProducer(kafkaTemplate);
        jobEventProducer.topicName = "DataSync.Program.Performance.JobEvent";

        boolean result = jobEventProducer.postToKafka(jobEvent);
    }

    @Test
    public void postToKafka_Exception() {
        SendResult<String, JobEvent> sendResult = Mockito.mock(SendResult.class);
        ListenableFuture<SendResult<String, JobEvent>> listenableFuture =
                Mockito.mock(ListenableFuture.class);

        KafkaTemplate<String, JobEvent> kafkaTemplate =
                Mockito.mock(KafkaTemplate.class);

        Mockito.doNothing().when(kafkaTemplate).flush();
        Mockito.when(listenableFuture.isDone()).thenReturn(true);
        Mockito.when(kafkaTemplate.send(Mockito.anyString(),Mockito.anyInt(),Mockito.any(),Mockito.any())).thenThrow(new NullPointerException("test"));

        JobEvent jobEvent = new JobEvent();
        jobEvent.setJobName(JobName.IDM_GLIDEPATH.getValue());
        jobEvent.setCascadeEvents(true);
        jobEvent.setExecutionWeek(ExecutionWeek.CURRENT.getValue());
        jobEvent.setGroupsToExecute(GroupsToExecute.ALL.getValue());

        JobEventProducer jobEventProducer
                = new JobEventProducer(kafkaTemplate);
        jobEventProducer.topicName = "DataSync.Program.Performance.JobEvent";

        boolean result = jobEventProducer.postToKafka(jobEvent);

        Assert.assertFalse(result);
    }

    @Test(expected = ProgramPerformanceJobListenerException.class)
    public void postToKafka_EmptyJobName() {

        KafkaTemplate<String, JobEvent> kafkaTemplate =
                Mockito.mock(KafkaTemplate.class);

        JobEvent jobEvent = new JobEvent();

        JobEventProducer jobEventProducer
                = new JobEventProducer(kafkaTemplate);
        jobEventProducer.topicName = "DataSync.Program.Performance.JobEvent";

        boolean result = jobEventProducer.postToKafka(jobEvent);
    }

    @Test(expected = ProgramPerformanceJobListenerException.class)
    public void postToKafka_EmptyGroupsToExecute() {

        KafkaTemplate<String, JobEvent> kafkaTemplate =
                Mockito.mock(KafkaTemplate.class);

        JobEvent jobEvent = new JobEvent();
        jobEvent.setJobName(JobName.IDM_GLIDEPATH.getValue());
        jobEvent.setGroupsToExecute("Test");

        JobEventProducer jobEventProducer
                = new JobEventProducer(kafkaTemplate);
        jobEventProducer.topicName = "DataSync.Program.Performance.JobEvent";

        boolean result = jobEventProducer.postToKafka(jobEvent);
    }

    @Test(expected = ProgramPerformanceJobListenerException.class)
    public void postToKafka_EmptyExecutionWeek() {

        KafkaTemplate<String, JobEvent> kafkaTemplate =
                Mockito.mock(KafkaTemplate.class);

        JobEvent jobEvent = new JobEvent();
        jobEvent.setJobName(JobName.IDM_GLIDEPATH.getValue());
        jobEvent.setGroupsToExecute(GroupsToExecute.ALL.getValue());
        jobEvent.setExecutionWeek("First");

        JobEventProducer jobEventProducer
                = new JobEventProducer(kafkaTemplate);
        jobEventProducer.topicName = "DataSync.Program.Performance.JobEvent";

        boolean result = jobEventProducer.postToKafka(jobEvent);
    }
}