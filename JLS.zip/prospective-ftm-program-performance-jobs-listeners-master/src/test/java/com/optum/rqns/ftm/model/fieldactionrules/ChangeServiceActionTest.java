package com.optum.rqns.ftm.model.fieldactionrules;


import com.optum.rqns.ftm.util.GetterSetterTester;
import org.junit.Assert;
import org.junit.Test;

public class ChangeServiceActionTest extends GetterSetterTester<ChangeServiceAction> {
    @Override
    public ChangeServiceAction getTestInstance() {
        return new ChangeServiceAction(1,1,"test","test","test","test","test");
    }
    @Test
    public void getChangeServiceAction(){
        ChangeServiceAction changeServiceAction= this.getTestInstance();
        Assert.assertNotNull(changeServiceAction);
        Assert.assertEquals(changeServiceAction.getManagerUUID(),"test");
    }
}
