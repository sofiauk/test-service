package com.optum.rqns.ftm.service.fieldactionrules;

import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.enums.ExecutionWeek;
import com.optum.rqns.ftm.enums.GroupsToExecute;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.exception.FieldActionRulesException;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.producer.JobEventProducer;
import com.optum.rqns.ftm.kafka.producer.KeyBasedFieldActionRuleProducer;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.model.fieldactionrules.AvailMembershipClientLobStateAction;
import com.optum.rqns.ftm.model.fieldactionrules.RuleAction;
import com.optum.rqns.ftm.repository.fieldactionrules.AvailMembershipClientLobStateRepoImpl;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
public class AvailMemberShipClientLobStateServiceImplTest {

    @MockBean
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @MockBean
    private AvailMembershipClientLobStateRepoImpl availMembershipClientLobStateRepo;

    @InjectMocks
    private AvailMemberShipClientLobStateServiceImpl availMemberShipClientLobStateService;

    @MockBean
    private JobEventProducer jobEventProducer;

    @MockBean
    KIERuleOrchestrator kieRuleOrchestrator;

    @MockBean
    private KeyBasedFieldActionRuleProducer keyBasedFieldActionRuleProducer;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void executeJob() {

        List<Integer> intList = new ArrayList<>();
        intList.add(100);

        ReflectionTestUtils.setField(availMemberShipClientLobStateService, "producerThreadPoolSize", 1);
        ReflectionTestUtils.setField(availMemberShipClientLobStateService, "batchSize", 1);
        Mockito.when(availMembershipClientLobStateRepo.getRowCountAndBatchesForAvailMembershipClientLobState(1)).thenReturn(intList);
        Mockito.when(availMembershipClientLobStateRepo.fetchAvailMembershipClientLobStateInfo(Mockito.anyInt(), Mockito.anyInt())).thenReturn((getAvailMembershipClientLobStateActionInfo()));
        Mockito.when(kieRuleOrchestrator.getRulesExecutedData(Mockito.anyList(),Mockito.any())).thenReturn((getAvailMembershipClientLobStateActionInfo()));
        Mockito.when(keyBasedFieldActionRuleProducer.postToKafka(Mockito.any(),Mockito.anyString())).thenReturn(true);

        Mockito.when(jobEventProducer.postToKafka(Mockito.any())).thenReturn(true);

        final JobStatus jobStatus = availMemberShipClientLobStateService.executeJob(getJobEvent());
        Assert.assertEquals(Status.SUCCESS,jobStatus.getStatus());
        Assert.assertEquals((Long) 1L, jobStatus.getUpdatedRows());
    }

    @Test
    public void executeJob_Exception() {
        Mockito.when(availMembershipClientLobStateRepo.fetchAvailMembershipClientLobStateInfo(0,100)).thenThrow(new NullPointerException());

        final JobStatus jobStatus = availMemberShipClientLobStateService.executeJob(getJobEvent());

        Assert.assertEquals(Status.SUCCESS,jobStatus.getStatus());
        // Assert.assertEquals((Long) 0L, jobStatus.getUpdatedRows());
    }

    private JobEvent getJobEvent(){
        return JobEvent.newBuilder().setJobName(JobName.AVAIL_MEMBERSHIP_CLIENT_LOB_STATE_RULE.toString())
                .setGroupsToExecute(GroupsToExecute.MODIFIED.getValue())
                .setExecutionWeek(ExecutionWeek.ALL.getValue()).setStatus(Status.IN_PROGRESS.getValue())
                .setTimeStamp(Instant.now()).setCascadeEvents(true).build();
    }

    private List<RuleAction> getAvailMembershipClientLobStateActionInfo(){
        List<RuleAction> ruleActions=new ArrayList<>();
        List<String> userList=new ArrayList<>();
        AvailMembershipClientLobStateAction availMembershipClientLobStateAction =new AvailMembershipClientLobStateAction();
        availMembershipClientLobStateAction.setClient("Anthem");
        availMembershipClientLobStateAction.setLob("Medicare");
        availMembershipClientLobStateAction.setState("CA");
        availMembershipClientLobStateAction.setPafxEligibleMemberCount(2L);
        availMembershipClientLobStateAction.setPublishedEligibleMemberCount(1L);
        userList.add("12345");
        availMembershipClientLobStateAction.setRuleType(JobName.AVAIL_MEMBERSHIP_CLIENT_LOB_STATE_RULE.toString());
        availMembershipClientLobStateAction.setUserUuid(userList);
        ruleActions.add(availMembershipClientLobStateAction);
        return ruleActions;
    }

    @Test
    public void testGetRuleResult() {
        RuleAction ruleAction = this.getAvailMembershipClientLobStateActionInfo().get(0);
        Assert.assertNotNull(availMemberShipClientLobStateService.getRuleResult(ruleAction));

    }

    @Test
    public void testGetRuleContext() {
        RuleAction ruleAction = this.getAvailMembershipClientLobStateActionInfo().get(0);
        Assert.assertNotNull(availMemberShipClientLobStateService.getRuleContext(ruleAction));

    }

    @Test
    public void testFetchRuleBatchingOffsetList(){
        Assert.assertNotNull(availMemberShipClientLobStateService.fetchRuleBatchingOffsetList(1000));

    }

}
