package com.optum.rqns.ftm.repository.common;

import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.model.JobConfiguration;
import com.optum.rqns.ftm.model.JobConfigurationRequest;
import com.optum.rqns.ftm.model.JobRunConfiguration;
import com.optum.rqns.ftm.model.ProgramYearCalendarDTO;
import com.optum.rqns.ftm.model.qfo.CommonProgramYearCalenderDTO;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;



@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        CommonRepositoryImpl.class
})
public class CommonRepositoryImplTest {

    @MockBean
    NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @InjectMocks
    CommonRepositoryImpl commonRepository;

    @MockBean
    CommonRepositoryImpl.ProgramYearCalendarDTOMapper mapper;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        commonRepository = new CommonRepositoryImpl(this.namedParameterJdbcTemplate);
    }

    @Test
    public void insertJobRunConfiguration() {

        JobRunConfiguration jobRunConfiguration = JobRunConfiguration
                .builder()
                .jobName(JobName.IDM_GLIDEPATH)
                .jobDescription(Constants.IDM_GLIDEPATH_JOB_DESCRIPTION)
                .status(Status.IN_PROGRESS)
                .updateJobStart(true)
                .updateLastRun(true)
                .updateMessage(true)
                .updateMessageKey(true)
                .updateJobEvent(true)
                .messageKey("")
                .message("")
                .jobEvent("")
                .errorMessage("")
                .updateAffectedRows(true)
                .affectedRows(10L)
                .modifiedBy(JobName.IDM_GLIDEPATH.getValue())
                .build();

        Integer jobRunExecution = commonRepository
                .upsertJobRunConfiguration(jobRunConfiguration);
        Assert.assertEquals(new Integer(0), jobRunExecution);

    }


    @Test
    public void updateSuccessJobRunConfiguration() {

        JobRunConfiguration jobRunConfiguration = JobRunConfiguration
                .builder()
                .jobName(JobName.IDM_GLIDEPATH)
                .status(Status.SUCCESS)
                .updateJobEnd(true)
                .updateLastSuccessfulRun(true)
                .affectedRows(2l)
                .build();

        Integer jobRunExecution = commonRepository
                .upsertJobRunConfiguration(jobRunConfiguration);

        Assert.assertEquals(new Integer(0), jobRunExecution);
    }

    @Test
    public void updateFailureJobRunConfiguration() {

        JobRunConfiguration jobRunConfigurationDTO = JobRunConfiguration
                .builder()
                .jobName(JobName.IDM_GLIDEPATH)
                .status(Status.FAILURE)
                .errorMessage("Failure Message")
                .updateJobEnd(true)
                .build();

        Integer jobRunExecution = commonRepository
                .upsertJobRunConfiguration(jobRunConfigurationDTO);

        Assert.assertEquals(new Integer(0), jobRunExecution);

    }


    @Test
    public void getJobIsActiveByName() {
        Boolean jobRunExecution = commonRepository
                .getJobIsActiveByName(JobName.IDM_GLIDEPATH.getValue());


        System.out.println("job =" + jobRunExecution);
    }

    @Test
    public void getJobIdName() {

        Integer jobRunExecution = commonRepository
                .getJobIdByName(JobName.IDM_GLIDEPATH.getValue());

        System.out.println("job =" + jobRunExecution);
    }

    @Test
    public void updateJobExecutionHistoryAsJobEnd_Success() {

        Integer jobRunExecution = commonRepository
                .updateJobExecutionHistoryAsJobEnd(1, Status.SUCCESS, "", "", 0L);

        System.out.println("job =" + jobRunExecution);

    }

    @Test
    public void updateJobExecutionHistoryAsJobEnd_Failed() {

        Integer jobRunExecution = commonRepository
                .updateJobExecutionHistoryAsJobEnd(1, Status.FAILURE, "Failed", "", 0L);

        System.out.println("job =" + jobRunExecution);

    }

    @Test
    public void getJobExecutionHistoryByTime() {

        Integer jobExecutionHistoryByTime = commonRepository
                .getJobExecutionHistoryByTime(1, 5);

        Assert.assertEquals(null, jobExecutionHistoryByTime);

    }

    @Test
    public void updateAffectedRowsCountForJob() {

        Integer affectedRowsUpdated = commonRepository
                .updateAffectedRowsCountForJob("Returns", 10L);

        Assert.assertEquals(new Integer(0), affectedRowsUpdated);

    }

    @Test
    public void getJobExecutionHistoryByMessageKey() {

        Integer result = commonRepository
                .getJobExecutionHistoryByMessageKey(1, "Test");

        Assert.assertEquals(null, result);

    }

    @Test
    public void getBatchSize() {
        int batchSize = commonRepository.getBatchSize();
        Assert.assertEquals(1000, batchSize);
    }

    @Test
    public void getAllJobsConfigurationsTest() {

        JobConfiguration jobConfiguration = commonRepository.getAllJobConfigurations();

        Assert.assertEquals(null, jobConfiguration);
    }

    @Test
    public void getJobConfigurationsByNameTest() {

        JobConfiguration jobConfiguration = commonRepository.getJobConfigurationByName(JobName.IDM_GLIDEPATH);
        System.out.println("getJobConfigurationsByNameTest = " + jobConfiguration);

        Assert.assertEquals(null, jobConfiguration);


    }

    @Test
    public void jobConfigurationUpdates() {

        JobConfigurationRequest jobConfigurationRequest = new JobConfigurationRequest();
        jobConfigurationRequest.setIsActive(true);
        jobConfigurationRequest.setLastSuccessfulRunDate(LocalDateTime.now());
        Integer result = commonRepository.jobConfigurationUpdates(jobConfigurationRequest);

        Assert.assertEquals(new Integer(0), result);

    }

    @Test
    public void jobConfigurationUpdatesISActive() {
        JobConfigurationRequest jobConfigurationRequestBody = new JobConfigurationRequest();
        jobConfigurationRequestBody.setJobName("ExportsData");
        jobConfigurationRequestBody.setIsActive(false);

        Integer result = commonRepository.jobConfigurationUpdates(jobConfigurationRequestBody);
        System.out.println("jobConfigurationUpdatesISActive=" + result);

        Assert.assertEquals(new Integer(0), result);

    }

    @Test
    public void jobConfigurationUpdatesLastSuccessFullRunDate() {

        JobConfigurationRequest jobConfigurationRequestBody = new JobConfigurationRequest();
        jobConfigurationRequestBody.setJobName("ExportsData");
        jobConfigurationRequestBody.setLastSuccessfulRunDate(LocalDateTime.now());

        Integer result = commonRepository.jobConfigurationUpdates(jobConfigurationRequestBody);

        Assert.assertEquals(new Integer(0), result);

    }

    @Test
    public void getJobFrequency() {

        String GET_JOB_FREQUENCY_CHECK = "Select jrc.Frequency from ProgPerf.JobRunConfiguration jrc where jrc.JobName=:JOB_NAME";
        SqlParameterSource param = new MapSqlParameterSource("JOB_NAME", "test");
        Mockito.when(namedParameterJdbcTemplate.queryForObject(GET_JOB_FREQUENCY_CHECK, param, String.class)).thenReturn("test");
        Assert.assertNull(commonRepository.getJobFrequency("test"));
    }

    @Test
    public void getCascadedJobs() {

        String GET_CASCADED_JOBS = "SELECT convert(varchar(4000), jrc.cascadedEvents) as cascadedEvents from ProgPerf.JobRunConfiguration jrc where jrc.JobName =:JOB_NAME";
        SqlParameterSource param = new MapSqlParameterSource("JOB_NAME", "test");
        Mockito.when(namedParameterJdbcTemplate.queryForObject(GET_CASCADED_JOBS, param, String.class)).thenReturn("test");
        Assert.assertNull(commonRepository.getCascadedJobs("test"));
    }

    @Test
    public void getCurrentProgramYearTest(){
        String GET_CURRENT_PROGRAM_YEAR = "select mc.value from ProgPerf.MasterConfiguration mc WITH (NOLOCK) where mc.code='CurrentProgramYear";
        SqlParameterSource param = new MapSqlParameterSource();
        Mockito.when(namedParameterJdbcTemplate.queryForObject(GET_CURRENT_PROGRAM_YEAR, param, Integer.class)).thenReturn(1);
        Assert.assertNull(commonRepository.getCurrentProgramYear());
    }

    @Test
    public void getYTDDurationTest() throws SQLException {

        final ProgramYearCalendarDTO mockProgramYearCalendarDTO = ProgramYearCalendarDTO.builder()
                .programYear(2021)
                .durationValue("2021_WEEK01")
                .startDate(LocalDate.of(2021, 02, 01))
                .endDate(LocalDate.of(2021, 02, 8))
                .build();

        Mockito.when(
                namedParameterJdbcTemplate
                        .queryForObject(
                                Mockito.anyString(),
                                Mockito.any(SqlParameterSource.class),
                                Mockito.any(CommonRepositoryImpl.ProgramYearCalendarDTOMapper.class)
                        )
        )
                .thenReturn(mockProgramYearCalendarDTO);
        final ProgramYearCalendarDTO programYearCalendarDTO = commonRepository.getYTDDuration(2021);

        Assert.assertNotNull(programYearCalendarDTO);
        Assert.assertEquals(mockProgramYearCalendarDTO.getProgramYear(), programYearCalendarDTO.getProgramYear());
        Assert.assertEquals(mockProgramYearCalendarDTO.getDurationValue(), programYearCalendarDTO.getDurationValue());
        Assert.assertEquals(mockProgramYearCalendarDTO.getStartDate(), programYearCalendarDTO.getStartDate());
        Assert.assertEquals(mockProgramYearCalendarDTO.getEndDate(), programYearCalendarDTO.getEndDate());
    }

    @Test
    public void getDurationTest()
    {
        final CommonProgramYearCalenderDTO mockCommonProgramYearCalenderDTO = CommonProgramYearCalenderDTO.builder()
                .programYear(2021)
                .durationValue("JAN_2021")
                .startDate(LocalDate.of(2021, 01, 01))
                .endDate(LocalDate.of(2021, 01, 31))
                .build();

        Mockito.when(
                namedParameterJdbcTemplate
                        .queryForObject(
                                Mockito.anyString(),
                                Mockito.anyMap(),
                                Mockito.eq(CommonProgramYearCalenderDTO.class)
                        )
        )
                .thenReturn(mockCommonProgramYearCalenderDTO);
        final CommonProgramYearCalenderDTO commonProgramYearCalenderDTO = commonRepository.getDuration(2021,"QFO");
        Assert.assertNull(commonProgramYearCalenderDTO);
    }
}