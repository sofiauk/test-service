package com.optum.rqns.ftm.service.commandcenter;

import com.optum.rqns.ftm.enums.ExecutionWeek;
import com.optum.rqns.ftm.enums.GroupsToExecute;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.producer.JobEventProducer;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.repository.commandcenter.CommandCenterRepository;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.time.Instant;

@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        CommandCenterServiceImpl.class
})
@SpringBootTest(properties = {
        "spring.db_connection_thread_pool_size=10",
})
public class CommandCenterServiceTest {

    @MockBean
    private CommandCenterRepository commandCenterRepository;

    @InjectMocks
    private CommandCenterServiceImpl commandCenterService;

    @MockBean
    private JobEventProducer jobEventProducer;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void executeJob() {

//        ReflectionTestUtils.setField(deployReturnTargetsService, "dbConnectionThreadPoolSize", 10);


        Mockito.when(commandCenterRepository.mergeDataFromProgPerfWeeklyToCommandCenter(2021))
                .thenReturn(20l);
        Mockito.when(commandCenterRepository.calculateCCPerformance(Mockito.any(Integer.class)))
                .thenReturn(20l);


        Mockito.when(jobEventProducer.postToKafka(getJobEvent())).thenReturn(true);

        JobEvent jobEvent = JobEvent.newBuilder().setProgramYear(2021).setJobName(JobName.RUN_COMMAND_CENTER.getValue())
                .setGroupsToExecute(GroupsToExecute.MODIFIED.getValue())
                .setExecutionWeek(ExecutionWeek.ALL.getValue()).setStatus(Status.IN_PROGRESS.getValue())
                .setTimeStamp(Instant.now()).setCascadeEvents(true).build();
        final JobStatus jobStatus = commandCenterService.executeJob(jobEvent);
        assert jobStatus.getUpdatedRows() == 20;
    }

    private JobEvent getJobEvent() {
        JobEvent jobEvent = new JobEvent();
        jobEvent.setProgramYear(2020);
        jobEvent.setJobName("RunWeeklyJobs");
        jobEvent.setExecutionWeek("Current");
        jobEvent.setGroupsToExecute("All");
        jobEvent.setTimeStamp(Instant.now());
        jobEvent.setStatus("Complete");
        jobEvent.setCascadeEvents(true);

        return jobEvent;
    }

    @Test
    public void executeJobException() {

//        ReflectionTestUtils.setField(deployReturnTargetsService, "dbConnectionThreadPoolSize", 10);

//        Mockito.when(runWeeklyIDMTargetsRepository.getRecordCount(2021)).thenReturn(25000l);
        Mockito.when(commandCenterRepository.mergeDataFromProgPerfWeeklyToCommandCenter(2021))
                .thenThrow(new NullPointerException());

        Mockito.when(jobEventProducer.postToKafka(getJobEvent())).thenReturn(true);

        JobEvent jobEvent = JobEvent.newBuilder().setProgramYear(2021).setJobName(JobName.RUN_COMMAND_CENTER.getValue())
                .setGroupsToExecute(GroupsToExecute.MODIFIED.getValue())
                .setExecutionWeek(ExecutionWeek.ALL.getValue()).setStatus(Status.IN_PROGRESS.getValue())
                .setTimeStamp(Instant.now()).setCascadeEvents(true).build();
        final JobStatus jobStatus = commandCenterService.executeJob(jobEvent);
        assert Status.FAILURE == jobStatus.getStatus();
        assert 0 == jobStatus.getUpdatedRows();
    }


}
