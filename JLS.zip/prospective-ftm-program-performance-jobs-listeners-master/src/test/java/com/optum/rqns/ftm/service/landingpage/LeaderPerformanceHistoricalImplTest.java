package com.optum.rqns.ftm.service.landingpage;

import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.producer.JobEventProducer;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.model.ProgramYearCalendarDTO;
import com.optum.rqns.ftm.repository.common.CommonRepository;
import com.optum.rqns.ftm.repository.landingpage.LeaderPerformanceHistoricalRepository;
import com.optum.rqns.ftm.repository.landingpage.LeaderPerformanceRepository;
import com.optum.rqns.ftm.repository.users.UsersRepository;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        LeaderPerformanceHistoricalImpl.class
})
@SpringBootTest(properties = {
        "spring.db_connection_thread_pool_size=10",
})
public class LeaderPerformanceHistoricalImplTest {

    @MockBean
    private LeaderPerformanceHistoricalRepository leaderPerformanceHistoricalRepository;

    @MockBean
    private  LeaderPerformanceRepository leaderPerformanceRepository;

    @MockBean
    private UsersRepository usersRepository;

    @MockBean
    private CommonRepository commonRepository;

    @InjectMocks
    private LeaderPerformanceHistoricalImpl leaderPerformanceHistorical;

    @MockBean
    private JobEventProducer jobEventProducer;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    public static final String ALL = "All";
    static final List<String> LEADER_ROLES = Arrays.asList("RVP", "Director", "Manager");
    static final List<String> IC_ROLES = Arrays.asList("PSC", "HCA");
    @Test
    public void executeJob() {
        Mockito.when(leaderPerformanceHistoricalRepository.getAllProgramYearsDurations(Mockito.anyInt())).thenReturn(getProgramYearCalendars());
        Mockito.when(leaderPerformanceHistoricalRepository.getPrevoiusYearLastWeekDuration(Mockito.anyInt())).thenReturn(getProgramYearCalendar());
        Mockito.when(leaderPerformanceHistoricalRepository.getCurrentWeekDurationForProgramyear(Mockito.anyInt())).thenReturn(getProgramYearCalendar());
        Mockito.when(leaderPerformanceHistoricalRepository.getAllProgramYearsDurations(Mockito.anyInt())).thenReturn(getProgramYearCalendars());
        final JobStatus jobStatus = leaderPerformanceHistorical.executeJob(JobEvent.newBuilder().setProgramYear(2021).build());
        JobStatus mockJobStatus = new JobStatus();
        mockJobStatus.setUpdatedRows(0l);
        mockJobStatus.setStatus(Status.SUCCESS);
        mockJobStatus.setMessage("Successfully completed LeaderLandingPage job");

        Assert.assertEquals(mockJobStatus.getUpdatedRows(), jobStatus.getUpdatedRows());
        Assert.assertEquals(mockJobStatus.getStatus(), jobStatus.getStatus());

    }

    @Test
    public void  allProgramYearsDurations(){

        Mockito.when(leaderPerformanceHistoricalRepository.getAllProgramYearsDurations(Mockito.anyInt())).thenReturn(getProgramYearCalendars());
        Mockito.when(leaderPerformanceHistoricalRepository.getPrevoiusYearLastWeekDuration(Mockito.anyInt())).thenReturn(getProgramYearCalendar());
        Mockito.when(leaderPerformanceHistoricalRepository.getCurrentWeekDurationForProgramyear(Mockito.anyInt())).thenReturn(getProgramYearCalendar());
        Mockito.when(leaderPerformanceHistoricalRepository.getAllProgramYearsDurations(Mockito.anyInt())).thenReturn(getProgramYearCalendars());
        Mockito.when(leaderPerformanceHistoricalRepository.loadLeaderPerformanceNationalLevelAll(Mockito.any(), Mockito.anyInt(), Mockito.anyBoolean())).thenReturn(1L);
        mockLeaderDbCalls();
        JobStatus jobStatus = leaderPerformanceHistorical.executeJob(JobEvent.newBuilder().setProgramYear(2021).build());
        JobStatus mockJobStatus = new JobStatus();
        mockJobStatus.setUpdatedRows(3L);
        mockJobStatus.setStatus(Status.SUCCESS);
        mockJobStatus.setMessage("Successfully completed LeaderLandingPage job");

        Assert.assertEquals(mockJobStatus.getUpdatedRows(), jobStatus.getUpdatedRows());
        Assert.assertEquals(mockJobStatus.getStatus(), jobStatus.getStatus());
    }

    private void mockLeaderDbCalls() {
        Mockito.when(commonRepository.getYTDDuration(Mockito.anyInt()))
                .thenReturn(ProgramYearCalendarDTO.builder().programYear(2021).build());

        Mockito.when(leaderPerformanceRepository.getUsersByRole(IC_ROLES))
                .thenReturn(Arrays.asList("HCA1","PSC1"));
        Mockito.when(usersRepository.getUsersByRole(LEADER_ROLES))
                .thenReturn(Arrays.asList("Director1","Manager1"));

        Mockito.when(usersRepository.getIcReporters("Director1"))
                .thenReturn(Arrays.asList("IC1","IC2"));
        Mockito.when(usersRepository.getIcReporters("Manager1"))
                .thenReturn(new ArrayList<>());

        Mockito.when(leaderPerformanceRepository.getServiceLevelForUser(
                "HCA1"
        )).thenReturn(Arrays.asList("HCA","None"));
        Mockito.when(leaderPerformanceRepository.getServiceLevelForUser(
                "PSC1"
        )).thenReturn(Arrays.asList("PSC"));
        Mockito.when(leaderPerformanceRepository.calculateLeaderPerformanceData(
                Mockito.anyString(),Mockito.anyList(),Mockito.anyString()
        )).thenReturn(20);
        Mockito.when(leaderPerformanceRepository.calculateICPerformanceData(
                Mockito.anyString(),Mockito.anyString(), Mockito.any()
        )).thenReturn(10);
        Mockito.when(leaderPerformanceRepository.updateICGoalLeaderPerformance(
                Mockito.anyString(),Mockito.anyString(), Mockito.any()
        )).thenReturn(1);
    }

    @Test
    public void executeJob_Exception() {

        mockLeaderDbCalls();
        JobStatus jobStatus = leaderPerformanceHistorical.executeJob(JobEvent.newBuilder().setProgramYear(null).build());
        JobStatus mockJobStatus = new JobStatus();
        mockJobStatus.setUpdatedRows(0l);
        mockJobStatus.setStatus(Status.FAILURE);
        mockJobStatus.setMessage("Successfully completed LeaderLandingPage job");
        Assert.assertEquals(mockJobStatus.getStatus(), jobStatus.getStatus());

    }

    @Test
    public void exception_loadHistoricalLeaderPerformanceNational(){

    }
    private ProgramYearCalendarDTO getProgramYearCalendar() {
        ProgramYearCalendarDTO programYearCalendarDTO = new ProgramYearCalendarDTO();
        programYearCalendarDTO.setProgramYear(2021);
        programYearCalendarDTO.setDurationType("test");
        programYearCalendarDTO.setDurationValue("test");
        programYearCalendarDTO.setId(1l);
        programYearCalendarDTO.setEndDate(LocalDate.now());
        programYearCalendarDTO.setStartDate(LocalDate.now());
        return programYearCalendarDTO;
    }

    private List<ProgramYearCalendarDTO> getProgramYearCalendars() {
        ProgramYearCalendarDTO programYearCalendarDTO = new ProgramYearCalendarDTO();
        programYearCalendarDTO.setProgramYear(2021);
        programYearCalendarDTO.setDurationType("test");
        programYearCalendarDTO.setDurationValue("test");
        programYearCalendarDTO.setId(1l);
        programYearCalendarDTO.setEndDate(LocalDate.now());
        programYearCalendarDTO.setStartDate(LocalDate.now());
        List<ProgramYearCalendarDTO> programYearCalendarDTOList = new ArrayList<>();
        programYearCalendarDTOList.add(programYearCalendarDTO);
        return programYearCalendarDTOList;
    }

}
