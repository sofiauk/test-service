package com.optum.rqns.ftm.service.opamigration;

import com.optum.rqns.ftm.enums.ExecutionWeek;
import com.optum.rqns.ftm.enums.GroupsToExecute;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.producer.JobEventProducer;
import com.optum.rqns.ftm.kafka.producer.KeyBasedMemberOverallStatusSyncProducer;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.model.opamigration.MemberOverallStatus;
import com.optum.rqns.ftm.repository.opamigration.OPAMigrationRepository;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.Instant;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        OPAMigrationServiceImpl.class
})
@SpringBootTest(properties = {
        "producer_thread_pool_size=1",
})
public class OpaMigrationServiceImplTest {

    @InjectMocks
    private OPAMigrationServiceImpl opaMigrationService;

    @MockBean
    private OPAMigrationRepository opaMigrationRepository;

    @MockBean
    private KeyBasedMemberOverallStatusSyncProducer memberOverallStatusSyncProducer;

    @MockBean
    private JobEventProducer jobEventProducer;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void getMemberOverallStatusAllDetails(){
        ReflectionTestUtils.setField(opaMigrationService, "producerThreadPoolSize", 1);
        List<MemberOverallStatus> memberOverallStatusList = getMemberStatus();
        Mockito.when(opaMigrationRepository.getRecordCount(2021)).thenReturn(2l);
        Mockito.when(opaMigrationRepository.getMemberStatusDetails(Mockito.anyInt(), Mockito.anyInt(), Mockito.anyInt()))
                .thenReturn(memberOverallStatusList);

        JobEvent jobEvent = JobEvent.newBuilder().setProgramYear(2021).setJobName(JobName.RUN_MEMBER_PAYMENT_OVERALL_STATUS_SYNC.getValue())
                .setGroupsToExecute(GroupsToExecute.ALL.getValue())
                .setExecutionWeek(ExecutionWeek.ALL.getValue()).setStatus(Status.IN_PROGRESS.getValue())
                .setTimeStamp(Instant.now()).setCascadeEvents(true)
                .setJobInput("{\"executeAll\": true}").build();
        JobStatus jobStatus = opaMigrationService.executeJob(jobEvent);
        assert Status.SUCCESS == jobStatus.getStatus();
        assert 6 == jobStatus.getUpdatedRows();
    }

    @Test
    public void getMemberOverallStatusLastUpdateDetails(){
        ReflectionTestUtils.setField(opaMigrationService, "producerThreadPoolSize", 1);
        List<MemberOverallStatus> memberOverallStatusList = getMemberStatus();
        Mockito.when(opaMigrationRepository.getRecordCountForLastUpdateJobRunConfiguration(2021)).thenReturn(2l);
        Mockito.when(opaMigrationRepository.getMemberStatusDetailsBasedOnLostJobRunDate(Mockito.anyInt(), Mockito.anyInt(), Mockito.anyInt()))
                .thenReturn(memberOverallStatusList);

        JobEvent jobEvent = JobEvent.newBuilder().setProgramYear(2021).setJobName(JobName.RUN_MEMBER_PAYMENT_OVERALL_STATUS_SYNC.getValue())
                .setGroupsToExecute(GroupsToExecute.MODIFIED.getValue())
                .setExecutionWeek(ExecutionWeek.ALL.getValue()).setStatus(Status.IN_PROGRESS.getValue())
                .setTimeStamp(Instant.now()).setCascadeEvents(true).build();
        JobStatus jobStatus = opaMigrationService.executeJob(jobEvent);
        assert Status.SUCCESS == jobStatus.getStatus();
        assert 6 == jobStatus.getUpdatedRows();
    }

    private List<MemberOverallStatus> getMemberStatus() {
        MemberOverallStatus memberOverallStatus = MemberOverallStatus.builder().globalMemberId("123").overallStatus("Complete").clientId("ATE").lob("Medicare").messageCorrId("1407078").programYear(2021).providerGroupId("1234567")
                .build();
        MemberOverallStatus memberOverallStatus1 = MemberOverallStatus.builder().globalMemberId("345").overallStatus("Returned").clientId("WLP")
                .lob("Medicare").messageCorrId("45637").programYear(2021)
                .providerGroupId("989789")
                .build();
        MemberOverallStatus memberOverallStatus2 = MemberOverallStatus.builder().globalMemberId("345").overallStatus("Not Received").clientId("WLP")
                .lob("Medicare").messageCorrId("45637").programYear(2021)
                .providerGroupId("989789")
                .build();
        MemberOverallStatus memberOverallStatus3 = MemberOverallStatus.builder().globalMemberId("345").overallStatus("Rejected").clientId("WLP")
                .lob("Medicare").messageCorrId("45637").programYear(2021)
                .providerGroupId("989789")
                .build();
        MemberOverallStatus memberOverallStatus4 = MemberOverallStatus.builder().globalMemberId("345").overallStatus("CNA_Returned").clientId("WLP")
                .lob("Medicare").messageCorrId("45637").programYear(2021)
                .providerGroupId("989789")
                .build();
        MemberOverallStatus memberOverallStatus5 = MemberOverallStatus.builder().globalMemberId("345").overallStatus("CNA_WLA").clientId("WLP")
                .lob("Medicare").messageCorrId("45637").programYear(2021)
                .providerGroupId("989789")
                .build();
        List<MemberOverallStatus> list = new ArrayList<>();
        list.add(memberOverallStatus);
        list.add(memberOverallStatus1);
        list.add(memberOverallStatus2);
        list.add(memberOverallStatus3);
        list.add(memberOverallStatus4);
        list.add(memberOverallStatus5);
        return list;
    }

    @Test
    public void executeJobException() {

        ReflectionTestUtils.setField(opaMigrationService, "producerThreadPoolSize", 1);
        List<MemberOverallStatus> memberOverallStatusList = getMemberStatus();
        Mockito.when(opaMigrationRepository.getRecordCount(2021)).thenReturn(2l);
        Mockito.when(opaMigrationRepository.getMemberStatusDetails(Mockito.anyInt(), Mockito.anyInt(), Mockito.anyInt()))
                .thenReturn(memberOverallStatusList);

        JobEvent jobEvent = JobEvent.newBuilder().setJobName(JobName.RUN_MEMBER_PAYMENT_OVERALL_STATUS_SYNC.getValue())
                .setGroupsToExecute(GroupsToExecute.ALL.getValue())
                .setExecutionWeek(ExecutionWeek.ALL.getValue()).setStatus(Status.IN_PROGRESS.getValue())
                .setTimeStamp(Instant.now()).setCascadeEvents(true).build();
        JobStatus jobStatus = opaMigrationService.executeJob(jobEvent);
        assert Status.FAILURE == jobStatus.getStatus();
        assert 0 == jobStatus.getUpdatedRows();
    }

}
