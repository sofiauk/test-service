package com.optum.rqns.ftm.repository.opamigration;

import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.model.opamigration.MemberOverallStatus;
import com.optum.rqns.ftm.model.providergroup.ProviderGroup;
import com.optum.rqns.ftm.repository.providergroup.NewProviderGroupRuleRepositoryImpl;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        OPAMigrationRepositoryImpl.class
})
public class OpaMigrationRepositoryImplTest {

    @MockBean
    NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @MockBean
    ResultSet resultSet;

    @InjectMocks
    OPAMigrationRepositoryImpl repository;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        repository = new OPAMigrationRepositoryImpl(this.namedParameterJdbcTemplate);
    }

    @Test
    public void getMemberOverAllStatusCountForAll(){
        Mockito.when(namedParameterJdbcTemplate.queryForObject(Mockito.anyString(),Mockito.any(HashMap.class),Mockito.eq(Long.class)))
                .thenReturn(20l);

        final Long recordCount = repository.getRecordCount(2021);

        assert recordCount == 20;
    }

    @Test
    public void getMemberOverAllStatusCountForUpdate(){
        Mockito.when(namedParameterJdbcTemplate.queryForObject(Mockito.anyString(),Mockito.any(HashMap.class),Mockito.eq(Long.class)))
                .thenReturn(20l);

        final Long recordCount = repository.getRecordCountForLastUpdateJobRunConfiguration(2021);

        assert recordCount == 20;
    }

    @Test
    public void getMemberOverAllStatusForAll(){

        String query  = "select " +
                "   lob2 as lob," +
                "   clientid as clientId, " +
                "   prov_group_id as providerGroupId, " +
                "   mbr_glb_id as globalMemberId, " +
                "   project_year as programYear, " +
                "   overall_status as overallStatus, " +
                "   chart_id as messageCorrId, " +
                "   deploydate as deployDate, " +
                "   retrieval_date_clean as retrievalDateClean, " +
                "   singlerejectdate as singleRejectDate, " +
                "   screeningdate as screeningDate, " +
                "   cnaon as cnaOn " +
                "   from " +
                "   ProgPerf.MemberAssessment ma " +
                "   where " +
                "   chart_dup_id = 1 " +
                "   AND projecttype <> 'CAPE' " +
                "   AND project_year = :PROGRAMYEAR " +
                "   ORDER BY project_year, chart_id offset :OFFSET rows FETCH next :BatchSize rows only";

        List<MemberOverallStatus> result = new ArrayList<>();

        Mockito.when(namedParameterJdbcTemplate.query(query, new BeanPropertyRowMapper<>(MemberOverallStatus.class)))
                .thenReturn(result);
        List<MemberOverallStatus> memberOverallStatuses = repository.getMemberStatusDetails(50,0,2021);

        assert memberOverallStatuses.size() == 0;
    }

    @Test
    public void getMemberOverAllStatusForUpdate(){

        String query  = "select " +
                "   lob2 as lob," +
                "   clientid as clientId, " +
                "   prov_group_id as providerGroupId, " +
                "   mbr_glb_id as globalMemberId, " +
                "   project_year as programYear, " +
                "   overall_status as overallStatus, " +
                "   chart_id as messageCorrId, " +
                "   deploydate as deployDate, " +
                "   retrieval_date_clean as retrievalDateClean, " +
                "   singlerejectdate as singleRejectDate, " +
                "   screeningdate as screeningDate, " +
                "   cnaon as cnaOn " +
                "   from " +
                "   ProgPerf.MemberAssessment ma " +
                "   where " +
                "   chart_dup_id = 1 " +
                "   AND projecttype <> 'CAPE' " +
                "   AND project_year = :PROGRAMYEAR " +
                "   AND CAST(UpdatedDate as DATE) >= (select CAST(LastSuccessfulRunDate as DATE) " +
                "   FROM ProgPerf.JobRunConfiguration where JobName = '" + JobName.RUN_MEMBER_PAYMENT_OVERALL_STATUS_SYNC.getValue() + "')" +
                "   ORDER BY project_year, chart_id offset :OFFSET rows FETCH next :BatchSize rows only";

        List<MemberOverallStatus> result = new ArrayList<>();

        Mockito.when(namedParameterJdbcTemplate.query(query, new BeanPropertyRowMapper<>(MemberOverallStatus.class)))
                .thenReturn(result);
        List<MemberOverallStatus> memberOverallStatuses = repository.getMemberStatusDetailsBasedOnLostJobRunDate(50,0,2021);

        assert memberOverallStatuses.size() == 0;
    }
}
