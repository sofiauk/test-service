package com.optum.rqns.ftm.enums;

import org.junit.Assert;
import org.junit.Test;

public class DMNRuleDefinitionDetailsTest {

    @Test
    public void getDMNRuleDefinitionDetails(){
        Assert.assertEquals(DMNRuleDefinitionDetails.REJECCT_AGING_DMN_RULE,DMNRuleDefinitionDetails.getDMNRuleDefinitionDetails("RunRejectAgingFieldActionRule"));
        Assert.assertEquals(DMNRuleDefinitionDetails.NEW_PROVIDER_MANUAL_ASSOCIATION_JOB,DMNRuleDefinitionDetails.getDMNRuleDefinitionDetails("RunNewProviderManualAssociationFieldActionRule"));
        Assert.assertEquals(DMNRuleDefinitionDetails.RUN_CHANGE_SERVICE_LEVEL_RULE,DMNRuleDefinitionDetails.getDMNRuleDefinitionDetails("RunChangeServiceLevelFieldActionRule"));
        Assert.assertEquals(DMNRuleDefinitionDetails.AVAIL_MEMBERSHIP_CLIENT_LOB_STATE_RULE,DMNRuleDefinitionDetails.getDMNRuleDefinitionDetails("AvailMembershipClientLobStateFieldActionRule"));
        Assert.assertEquals(DMNRuleDefinitionDetails.RUN_NEW_PROVIDER_GROUP_MEMBERSHIP,DMNRuleDefinitionDetails.getDMNRuleDefinitionDetails("RunNewProviderGroupMembershipFieldActionRule"));
        Assert.assertEquals(DMNRuleDefinitionDetails.RETURN_METRIC_JOB,DMNRuleDefinitionDetails.getDMNRuleDefinitionDetails("RunReturnTargetTrackingFieldActionRule"));
        Assert.assertNull(DMNRuleDefinitionDetails.getDMNRuleDefinitionDetails("test"));
    }
}
