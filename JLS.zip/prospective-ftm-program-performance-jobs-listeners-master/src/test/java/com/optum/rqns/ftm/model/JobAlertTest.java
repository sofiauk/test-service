package com.optum.rqns.ftm.model;

import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.util.GetterSetterTester;
import org.junit.Test;

import java.time.LocalDateTime;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class JobAlertTest extends GetterSetterTester<JobAlert> {

    @Override
    public JobAlert getTestInstance() {
        return new JobAlert();
    }

    @Test
    public void TestConfig() {
        assertNotNull(getTestInstance());
    }

    @Test
    public void testJobAlert(){

        JobAlert jobAlert = new JobAlert(1,1,"test","test", "test", Constants.SYSTEM, LocalDateTime.now(), Constants.SYSTEM,
                LocalDateTime.now(),
                LocalDateTime.now(), LocalDateTime.now(), LocalDateTime.now(), "test", 1, LocalDateTime.now(),
                "test", "test", "test", false);

        jobAlert.builder();

        assertEquals(Constants.SYSTEM, jobAlert.getCreatedBy());
        assertEquals(false, jobAlert.isActive());
    }
}