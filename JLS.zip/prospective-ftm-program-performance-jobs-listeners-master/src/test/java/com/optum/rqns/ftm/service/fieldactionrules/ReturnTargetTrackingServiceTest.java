package com.optum.rqns.ftm.service.fieldactionrules;

import com.optum.rqns.ftm.enums.ExecutionWeek;
import com.optum.rqns.ftm.enums.GroupsToExecute;
import com.optum.rqns.ftm.enums.RuleEnum;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.producer.JobEventProducer;
import com.optum.rqns.ftm.kafka.producer.KeyBasedFieldActionRuleProducer;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.model.fieldactionrules.ReturnTargetTrackingAction;
import com.optum.rqns.ftm.model.fieldactionrules.RuleAction;
import com.optum.rqns.ftm.repository.fieldactionrules.ReturnTargetTrackingRepoImpl;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
public class ReturnTargetTrackingServiceTest {

    @MockBean
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @MockBean
    private ReturnTargetTrackingRepoImpl returnTargetTrackingRepoImpl;

    @InjectMocks
    private ReturnTargetTrackingServiceImpl returnTargetTrackingServiceImpl;

    @MockBean
    private JobEventProducer jobEventProducer;

    @MockBean
    KIERuleOrchestrator kieRuleOrchestrator;

    @MockBean
    private KeyBasedFieldActionRuleProducer keyBasedFieldActionRuleProducer;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void executeJob() {
        ReflectionTestUtils.setField(returnTargetTrackingServiceImpl, "producerThreadPoolSize", 1);
        Mockito.when(returnTargetTrackingRepoImpl.fetchReturnTargetInfo()).thenReturn((getReturnTargetInfo()));
        Mockito.when(kieRuleOrchestrator.getRulesExecutedData(Mockito.anyList(),Mockito.any())).thenReturn((getReturnTargetInfo()));
        Mockito.when(keyBasedFieldActionRuleProducer.postToKafka(Mockito.any(),Mockito.anyString())).thenReturn(true);

        Mockito.when(jobEventProducer.postToKafka(Mockito.any())).thenReturn(true);

        final JobStatus jobStatus = returnTargetTrackingServiceImpl.executeJob(getJobEvent());
        Assert.assertEquals(Status.SUCCESS,jobStatus.getStatus());
        Assert.assertEquals((Long) 1L, jobStatus.getUpdatedRows());
    }

    @Test
    public void executeJob_Exception() {
        Mockito.when(returnTargetTrackingRepoImpl.fetchReturnTargetInfo()).thenThrow(new NullPointerException());

        final JobStatus jobStatus = returnTargetTrackingServiceImpl.executeJob(getJobEvent());

        Assert.assertEquals(Status.FAILURE,jobStatus.getStatus());
        Assert.assertEquals((Long) 0L, jobStatus.getUpdatedRows());
    }

    private JobEvent getJobEvent(){
        return JobEvent.newBuilder().setJobName(RuleEnum.THRESHOLD_RULE.getValue())
                .setGroupsToExecute(GroupsToExecute.MODIFIED.getValue())
                .setExecutionWeek(ExecutionWeek.ALL.getValue()).setStatus(Status.IN_PROGRESS.getValue())
                .setTimeStamp(Instant.now()).setCascadeEvents(true).build();
    }

    private List<RuleAction> getReturnTargetInfo(){
        List<RuleAction> ruleActions=new ArrayList<>();
        List<String> userList=new ArrayList<>();
        ReturnTargetTrackingAction targetTrackingRuleAction =new ReturnTargetTrackingAction();
        targetTrackingRuleAction.setReturnTarget(100.00);
        targetTrackingRuleAction.setReturnCNA(100.00);
        targetTrackingRuleAction.setRuleType((RuleEnum.THRESHOLD_RULE).toString());
        userList.add("12345");
        targetTrackingRuleAction.setUserUuid(userList);
        ruleActions.add(targetTrackingRuleAction);
        return ruleActions;
    }

    @Test
    public void filterRuleActions(){
        List<RuleAction> ruleActions = new ArrayList<>();
        Assert.assertNotNull(returnTargetTrackingServiceImpl.filterRuleActions(ruleActions));

    }
}
