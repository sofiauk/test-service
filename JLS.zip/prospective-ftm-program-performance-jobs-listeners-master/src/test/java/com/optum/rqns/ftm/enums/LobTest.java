package com.optum.rqns.ftm.enums;

import org.junit.Assert;
import org.junit.Test;

public class LobTest {

    @Test
    public void lobTest(){
        Lob lob = Lob.COMMERCIAL;
        Assert.assertNotNull(lob.getValue());
        Assert.assertEquals(Lob.valueOf("COMMERCIAL"), lob);

    }
}
