package com.optum.rqns.ftm.service.landingpage;

import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.producer.JobEventProducer;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.model.ProgramYearCalendarDTO;
import com.optum.rqns.ftm.repository.commandcenter.CCGrowthRateRepository;
import com.optum.rqns.ftm.repository.common.CommonRepository;
import com.optum.rqns.ftm.repository.landingpage.LeaderPerformanceRepository;
import com.optum.rqns.ftm.repository.users.UsersRepository;
import com.optum.rqns.ftm.service.commandcenter.CCGrowthRateServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.connect.errors.DataException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.dao.DataAccessException;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        LeaderPerformanceServiceImpl.class
})
@SpringBootTest(properties = {
        "spring.db_connection_thread_pool_size=10",
})
public class LeaderPerformanceServiceImplTest {

    @MockBean
    private LeaderPerformanceRepository leaderPerformanceRepository;

    @MockBean
    private UsersRepository usersRepository;

    @MockBean
    private CommonRepository commonRepository;

    @InjectMocks
    private LeaderPerformanceServiceImpl leaderPerformanceService;

    @MockBean
    private JobEventProducer jobEventProducer;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    public static final List<String> LEADER_ROLES = Arrays.asList("RVP", "Director", "Manager");
    public static final List<String> IC_ROLES = Arrays.asList("PSC", "HCA");

    @Test
    public void executeJob() {
        mockLeaderDbCalls();
        final JobStatus jobStatus = leaderPerformanceService.executeJob(JobEvent.newBuilder().setProgramYear(2021).build());
        JobStatus mockJobStatus = new JobStatus();
        mockJobStatus.setUpdatedRows(31l);
        mockJobStatus.setStatus(Status.SUCCESS);
        mockJobStatus.setMessage("Successfully completed LeaderLandingPage job");

        Assert.assertEquals(mockJobStatus.getUpdatedRows(), jobStatus.getUpdatedRows());
        Assert.assertEquals(mockJobStatus.getStatus(), jobStatus.getStatus());

    }

    @Test
    public void calculateForAllUsers() {

        JobStatus mockJobStatus = new JobStatus();
        mockJobStatus.setUpdatedRows(31L);
        mockJobStatus.setStatus(Status.SUCCESS);
        mockJobStatus.setMessage("Successfully completed LeaderLandingPage job");

        mockLeaderDbCalls();

        final JobStatus jobStatus = leaderPerformanceService.executeJob(JobEvent.newBuilder().setProgramYear(2021).build());

        Assert.assertEquals(mockJobStatus.getUpdatedRows(), jobStatus.getUpdatedRows());
        Assert.assertEquals(mockJobStatus.getStatus(), jobStatus.getStatus());

    }

    private void mockLeaderDbCalls() {
        Mockito.when(commonRepository.getYTDDuration(Mockito.anyInt()))
                .thenReturn(ProgramYearCalendarDTO.builder().programYear(2021).build());

        Mockito.when(leaderPerformanceRepository.getUsersByRole(IC_ROLES))
                .thenReturn(Arrays.asList("HCA1","PSC1"));
        Mockito.when(usersRepository.getUsersByRole(LEADER_ROLES))
                .thenReturn(Arrays.asList("Director1","Manager1"));

        Mockito.when(usersRepository.getIcReporters("Director1"))
                .thenReturn(Arrays.asList("IC1","IC2"));
        Mockito.when(usersRepository.getIcReporters("Manager1"))
                .thenReturn(new ArrayList<>());

        Mockito.when(leaderPerformanceRepository.getServiceLevelForUser(
                "HCA1"
        )).thenReturn(Arrays.asList("HCA","None"));
        Mockito.when(leaderPerformanceRepository.getServiceLevelForUser(
                "PSC1"
        )).thenReturn(Arrays.asList("PSC"));
        Mockito.when(leaderPerformanceRepository.calculateLeaderPerformanceData(
                Mockito.anyString(),Mockito.anyList(),Mockito.anyString()
        )).thenReturn(20);
        Mockito.when(leaderPerformanceRepository.calculateICPerformanceData(
                Mockito.anyString(),Mockito.anyString(), Mockito.any()
        )).thenReturn(10);
        Mockito.when(leaderPerformanceRepository.updateICGoalLeaderPerformance(
                Mockito.anyString(),Mockito.anyString(), Mockito.any()
        )).thenReturn(1);
        Mockito.when(leaderPerformanceRepository.updateNationalGoalsLeaderPerformance(Mockito.any(ProgramYearCalendarDTO.class))).thenReturn(1);
        Mockito.when(leaderPerformanceRepository.updateNationalGoalsLeaderPerformance(Mockito.any(ProgramYearCalendarDTO.class))).thenReturn(1);
        Mockito.when(leaderPerformanceRepository.loadLeaderPerformanceNationalLevelAll(Mockito.any()))
                .thenReturn(0L);
        Mockito.when(leaderPerformanceRepository.loadLeaderPerformanceWeeklyCGAPClosureStateRegion(Mockito.any(ProgramYearCalendarDTO.class)))
                .thenReturn(0L);
        Mockito.when(leaderPerformanceRepository.loadLeaderPerformanceWeeklyCGAPClosureNational(Mockito.any(ProgramYearCalendarDTO.class)))
                .thenReturn(0L);
        Mockito.when(leaderPerformanceRepository.calculateEModalityPOCDataForClientAndLob(Mockito.anyString(), Mockito.anyString(),Mockito.any(ProgramYearCalendarDTO.class))).thenReturn(0);;
        Mockito.when(leaderPerformanceRepository.calculateEModalityPOCData(Mockito.anyString(), Mockito.anyString(),Mockito.any(ProgramYearCalendarDTO.class))).thenReturn(0);
        Mockito.when(leaderPerformanceRepository.calculateReturenNetCnaForClientAndLob(Mockito.anyString(), Mockito.anyString(),Mockito.any(ProgramYearCalendarDTO.class))).thenReturn(0);
        Mockito.when(leaderPerformanceRepository.calculateReturenNetCnaForALL(Mockito.anyString(), Mockito.anyString(),Mockito.any(ProgramYearCalendarDTO.class))).thenReturn(0);
        Mockito.when(leaderPerformanceRepository.calculateEModalityPOCDataForNationalClientLob(Mockito.anyString(), Mockito.any(ProgramYearCalendarDTO.class))).thenReturn(0);
        Mockito.when(leaderPerformanceRepository.calculateEModalityPOCDataForNational(Mockito.anyString(), Mockito.any(ProgramYearCalendarDTO.class))).thenReturn(0);
        Mockito.when(leaderPerformanceRepository.calculateReturnNetCnaForNational(Mockito.anyString(), Mockito.any(ProgramYearCalendarDTO.class))).thenReturn(0);
        Mockito.when(leaderPerformanceRepository.calculateNationalGrowthRatePOCData(Mockito.anyString(), Mockito.any(ProgramYearCalendarDTO.class))).thenReturn(0);
        Mockito.when(leaderPerformanceRepository.calculateReturnNetCnaForAllNational(Mockito.anyString(), Mockito.any(ProgramYearCalendarDTO.class))).thenReturn(0);

    }

    @Test
    public void calculateForAllUsersExceptionTest() {

        JobStatus mockJobStatus = new JobStatus();
        mockJobStatus.setUpdatedRows(50l);
        mockJobStatus.setStatus(Status.FAILURE);
        mockJobStatus.setMessage("Successfully completed LeaderLandingPage job");

        mockLeaderDbCalls();

        Mockito.when(leaderPerformanceRepository.calculateLeaderGrowthRatePOCData(
                Mockito.anyString(),Mockito.anyList(),Mockito.anyInt()
        )).thenThrow(new RuntimeException("some Exception occured"));

        final JobStatus jobStatus = leaderPerformanceService.executeJob(JobEvent.newBuilder().setProgramYear(2021).build());
        Assert.assertEquals(mockJobStatus.getStatus(), jobStatus.getStatus());

    }
}