package com.optum.rqns.ftm.model.fieldactionrules;

import com.optum.rqns.ftm.util.GetterSetterTester;
import org.junit.Assert;
import org.junit.Test;

public class NewMemberShipActionTest extends GetterSetterTester<NewMemberShipAction> {

    @Override
    public NewMemberShipAction getTestInstance() {
        return new NewMemberShipAction(1L,1L,"test","test",1,"test");
    }

    @Test
    public void getNewMemberShipAction() {
        NewMemberShipAction newMemberShipAction = this.getTestInstance();
        Assert.assertNotNull(newMemberShipAction);
        Assert.assertEquals(newMemberShipAction.getProviderGroupId(), "test");
    }
}
