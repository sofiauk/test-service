package com.optum.rqns.ftm.service.qfo;

import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.enums.ExecutionWeek;
import com.optum.rqns.ftm.enums.GroupsToExecute;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.producer.JobEventProducer;
import com.optum.rqns.ftm.kafka.producer.KeyBasedProviderSyncProducer;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.model.qfo.CommonProgramYearCalenderDTO;
import com.optum.rqns.ftm.model.qfo.QfoPerformanceData;
import com.optum.rqns.ftm.repository.common.CommonRepositoryImpl;
import com.optum.rqns.ftm.repository.qfo.QFOPerformanceRepositoryImpl;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        QFOPerformanceServiceImpl.class
})
@SpringBootTest(properties = {
        "new_providergroup_rule_producer_thread_pool_size=1",
})
public class QFOPerformanceServiceImplTest {

    @MockBean
    private QFOPerformanceRepositoryImpl qfoPerformanceRepository;

    @MockBean
    private CommonRepositoryImpl commonRepository;

    @InjectMocks
    private QFOPerformanceServiceImpl qfoPerformanceService;

    @MockBean
    private JobEventProducer jobEventProducer;

    @MockBean
    private KeyBasedProviderSyncProducer producer;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void executeJob() {
        ReflectionTestUtils.setField(qfoPerformanceService, "producerThreadPoolSize", 1);
        Mockito.when(commonRepository.getDuration(Mockito.any(), Mockito.any())).thenReturn(CommonProgramYearCalenderDTO.builder().durationValue("JAN_2021").build());
        Mockito.when(qfoPerformanceRepository.getProviderGroupMemberQualityRecordCount(Mockito.anyString(), Mockito.anyInt())).thenReturn(25000l);
        Mockito.when(qfoPerformanceRepository.loadProviderGroupPerformanceQualityDetails(Mockito.anyInt(),Mockito.anyInt(),Mockito.anyString(), Mockito.any())).thenReturn(1);
        Mockito.when(qfoPerformanceRepository.getStarRatingIngestionGroupsRecordCount(Mockito.anyString(), Mockito.anyInt())).thenReturn(25000l);
        Mockito.when(qfoPerformanceRepository.mergeProviderGroupPerformanceDetailsWithASR(25000, 0
                , GroupsToExecute.ALL.toString(),2021,CommonProgramYearCalenderDTO.builder().programYear(2021).durationValue("JAN_2021").build()))
                .thenReturn(10);
        Mockito.when(qfoPerformanceRepository.mergeProviderGroupPerformanceDetailsWithASR(25000, 25000
                , GroupsToExecute.MODIFIED.toString(), 2021,CommonProgramYearCalenderDTO.builder().programYear(2021).durationValue("JAN_2021").build()))
                .thenReturn(10);
        Mockito.when(qfoPerformanceRepository.getHealthSystemRecordCount(Mockito.any(),Mockito.any())).thenReturn(1L);
        Mockito.when(qfoPerformanceRepository.mergeHealthSystemPerfDetails(Mockito.anyInt(),Mockito.anyInt(),Mockito.any(),Mockito.any())).thenReturn(1);
        Mockito.when(qfoPerformanceRepository.getStarRatingGlidePathCount(Mockito.anyInt(), Mockito.anyString())).thenReturn(2l);
        Mockito.when(qfoPerformanceRepository.getStarRatingGlidePathGroupsRecordCount(Mockito.anyString(), Mockito.anyInt(),Mockito.anyBoolean(),Mockito.anyString())).thenReturn(25000l);
        Mockito.when(qfoPerformanceRepository.mergeStarRatingGlidePathWithRatingIngestion(25000, 0
                , GroupsToExecute.MODIFIED.toString(), 2021,CommonProgramYearCalenderDTO.builder().programYear(2021).durationValue("MAY_2022").build(),false,"GROUP"))
                .thenReturn(10);
        List<QfoPerformanceData> qfoPerformanceData = getPerformanceDetails();
        Mockito.when(qfoPerformanceRepository.getQfoPerformanceDataBobSyncCount(Mockito.anyInt(),Mockito.any(),Mockito.anyString())).thenReturn(4l);
        Mockito.when(qfoPerformanceRepository.getQfoPerformanceDataBobSyncDetails(Mockito.anyInt(),Mockito.any(),Mockito.any(),
                Mockito.anyString(),Mockito.anyString())).thenReturn(qfoPerformanceData);
//        Mockito.when(jobEventProducer.postToKafka(getJobEvent())).thenReturn(true);

        JobEvent jobEvent = JobEvent.newBuilder().setJobName(JobName.IDM_GLIDEPATH.getValue())
                .setGroupsToExecute(GroupsToExecute.MODIFIED.getValue())
                .setProgramYear(2022)
                .setExecutionWeek(ExecutionWeek.ALL.getValue()).setStatus(Status.IN_PROGRESS.getValue())
                .setTimeStamp(Instant.now()).setCascadeEvents(true).build();
        final JobStatus jobStatus = qfoPerformanceService.executeJob(jobEvent);

        assert Status.SUCCESS == jobStatus.getStatus();

        assert jobStatus.getUpdatedRows() == 4;
    }

    private JobEvent getJobEvent(){
        JobEvent jobEvent = new JobEvent();
        jobEvent.setProgramYear(2021);
        jobEvent.setJobName(JobName.QFOPERFORMANCE.toString());
        jobEvent.setExecutionWeek("Current");
        jobEvent.setGroupsToExecute("All");
        jobEvent.setTimeStamp(Instant.now());
        jobEvent.setStatus("Complete");
        jobEvent.setCascadeEvents(true);

        return jobEvent;
    }

    @Test
    public void executeJobException() {

        Mockito.when(qfoPerformanceRepository.getStarRatingIngestionGroupsRecordCount(Mockito.anyString(), Mockito.anyInt())).thenReturn(25000l);
        Mockito.when(qfoPerformanceRepository.mergeProviderGroupPerformanceDetailsWithASR(25000, 0
                , GroupsToExecute.MODIFIED.toString(), 2021,CommonProgramYearCalenderDTO.builder().programYear(2021).durationValue("JAN_2021").build()))
                .thenReturn(10);
        Mockito.when(qfoPerformanceRepository.getStarRatingGlidePathCount(Mockito.anyInt(), Mockito.anyString())).thenReturn(25l);
        Mockito.when(qfoPerformanceRepository.getStarRatingGlidePathGroupsRecordCount(Mockito.anyString(), Mockito.anyInt(),Mockito.anyBoolean(),Mockito.anyString())).thenReturn(25000l);
        Mockito.when(qfoPerformanceRepository.mergeStarRatingGlidePathWithRatingIngestion(25000, 0
                , GroupsToExecute.MODIFIED.toString(), 2021,CommonProgramYearCalenderDTO.builder().programYear(2021).durationValue("MAY_2022").build(),false,"GROUP"))
                .thenReturn(10);
        List<QfoPerformanceData> qfoPerformanceData = getPerformanceDetails();
        Mockito.when(qfoPerformanceRepository.getQfoPerformanceDataBobSyncCount(Mockito.anyInt(),Mockito.any(),Mockito.anyString())).thenReturn(4l);
        Mockito.when(qfoPerformanceRepository.getQfoPerformanceDataBobSyncDetails(Mockito.anyInt(),Mockito.any(),Mockito.any(),
                Mockito.anyString(),Mockito.anyString())).thenReturn(qfoPerformanceData);
        Mockito.when(qfoPerformanceRepository.getPreviousMonthDisabledProvidersData(Mockito.anyInt())).thenReturn(qfoPerformanceData);
        Mockito.when(jobEventProducer.postToKafka(getJobEvent())).thenReturn(true);

        JobEvent jobEvent = JobEvent.newBuilder().setJobName(JobName.IDM_GLIDEPATH.getValue())
                .setGroupsToExecute(GroupsToExecute.MODIFIED.getValue())
                .setExecutionWeek(ExecutionWeek.ALL.getValue()).setStatus(Status.IN_PROGRESS.getValue())
                .setTimeStamp(Instant.now()).setCascadeEvents(true).build();
        final JobStatus jobStatus = qfoPerformanceService.executeJob(jobEvent);
        assert Status.FAILURE == jobStatus.getStatus();
        assert 0 == jobStatus.getUpdatedRows();
    }

    private List<QfoPerformanceData> getPerformanceDetails() {
        QfoPerformanceData qfoPerformanceData = QfoPerformanceData.builder()
                .acvCompleted(2).conditionsAssessed(20).mapCpiEligiblePatients(100)
                .programYear("2022").providerGroupId("123456").build();
        QfoPerformanceData qfoPerformanceData1 = QfoPerformanceData.builder()
                .acvCompleted(22).conditionsAssessed(20).mapCpiEligiblePatients(50)
                .programYear("2022").providerGroupId("45632").build();
        QfoPerformanceData qfoPerformanceData2 = QfoPerformanceData.builder()
                .acvCompleted(10).conditionsAssessed(10).mapCpiEligiblePatients(23)
                .programYear("2022").providerGroupId("8536").build();
        QfoPerformanceData qfoPerformanceData4 = QfoPerformanceData.builder()
                .acvCompleted(27).conditionsAssessed(38).mapCpiEligiblePatients(60)
                .programYear("2022").providerGroupId("808090809").build();
        List<QfoPerformanceData> list = new ArrayList<>();
        list.add(qfoPerformanceData);
        list.add(qfoPerformanceData1);
        list.add(qfoPerformanceData2);
        list.add(qfoPerformanceData4);
        return list;
    }

    @Test
    public void executeJobExceptionWithMonthly() {

        Mockito.when(qfoPerformanceRepository.getStarRatingIngestionGroupsRecordCount(Mockito.anyString(), Mockito.anyInt())).thenReturn(25000l);
        Mockito.when(qfoPerformanceRepository.mergeProviderGroupPerformanceDetailsWithASR(25000, 0
                , GroupsToExecute.MODIFIED.toString(), 2021,CommonProgramYearCalenderDTO.builder().programYear(2021).durationValue("JAN_2021").build()))
                .thenReturn(10);
        Mockito.when(qfoPerformanceRepository.getStarRatingGlidePathCount(Mockito.anyInt(), Mockito.anyString())).thenReturn(25l);
        Mockito.when(qfoPerformanceRepository.getStarRatingGlidePathGroupsRecordCount(Mockito.anyString(), Mockito.anyInt(),Mockito.anyBoolean(),Mockito.anyString())).thenReturn(25000l);
        Mockito.when(qfoPerformanceRepository.mergeStarRatingGlidePathWithRatingIngestion(25000, 0
                , GroupsToExecute.MODIFIED.toString(), 2021,CommonProgramYearCalenderDTO.builder().programYear(2021).durationValue("MAY_2022").build(),false,"GROUP"))
                .thenReturn(10);
        List<QfoPerformanceData> qfoPerformanceData = getPerformanceDetails();
        Mockito.when(qfoPerformanceRepository.getQfoPerformanceDataBobSyncCount(Mockito.anyInt(),Mockito.any(),Mockito.anyString())).thenReturn(4l);
        Mockito.when(qfoPerformanceRepository.getQfoPerformanceDataBobSyncDetails(Mockito.anyInt(),Mockito.any(),Mockito.any(),
                Mockito.anyString(),Mockito.anyString())).thenReturn(qfoPerformanceData);
        Mockito.when(qfoPerformanceRepository.getPreviousMonthDisabledProvidersData(Mockito.anyInt())).thenReturn(qfoPerformanceData);
        Mockito.when(jobEventProducer.postToKafka(getJobEvent())).thenReturn(true);

        JobEvent jobEvent = JobEvent.newBuilder().setJobName(JobName.IDM_GLIDEPATH.getValue())
                .setGroupsToExecute(Constants.MONTHLY)
                .setExecutionWeek(ExecutionWeek.ALL.getValue()).setStatus(Status.IN_PROGRESS.getValue())
                .setTimeStamp(Instant.now()).setCascadeEvents(true).build();
        final JobStatus jobStatus = qfoPerformanceService.executeJob(jobEvent);
        assert Status.FAILURE == jobStatus.getStatus();
        assert 0 == jobStatus.getUpdatedRows();
    }

}