package com.optum.rqns.ftm.repository.qfo;


import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.model.qfo.QFOPatientExperienceScore;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        QFOPatientExperienceScoresRepositoryImpl.class
})
public class QFOPatientExperienceScoreRepositoryimplTest {

    @MockBean
    NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @InjectMocks
    QFOPatientExperienceScoresRepositoryImpl repository;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        repository = new QFOPatientExperienceScoresRepositoryImpl(this.namedParameterJdbcTemplate);
    }

    @Test
    public void getRecordCountAllScenario() {


        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(), Mockito.any(HashMap.class)))
                .thenReturn(20);

        Long recordCount = repository.getRecordCount(getJobEvent(JobName.QFO_PATIENT_EXPERIENCE_SCORES.toString(), false));
        assert recordCount == null;
    }

    @Test
    public void getRecordCountModifiedScenario() {


        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(), Mockito.any(HashMap.class)))
                .thenReturn(20);

        Long recordCount = repository.getRecordCount(getJobEvent(JobName.QFO_PATIENT_EXPERIENCE_SCORES.toString(), true));
        assert recordCount == null;
    }

    @Test
    public void getQFOPatientExperienceScoresAllScenario() {

        String query = "SELECT HEALTHORGID AS ProviderGroupId, PROGRAMYEAR AS ProgramYear, GNCRATE AS GncRate,  COORATE AS CooRate, DPCRATE AS DpcRate, CreatedDate AS CreatedDate, " +
                " UpdatedDate AS UpdatedDate FROM  ProgPerf.PATIENTEXPERIENCESCORE PES WHERE  HEALTHORGIDTYPE = 'PG' " +
                " AND RPT_MO_KEY =(  SELECT  max(RPT_MO_KEY)  FROM  ProgPerf.PATIENTEXPERIENCESCORE )  AND PROGRAMYEAR = ( " +
                " select  [value] from  ProgPerf.MasterConfiguration  where  code = 'CurrentProgramYear')   ORDER BY ProgramYear offset :OFFSET rows FETCH next :BatchSize rows only ";

        List<QFOPatientExperienceScore> result = new ArrayList<>();

        SqlParameterSource sqlParameterSource = new MapSqlParameterSource("BatchSize", 0)
                .addValue("OFFSET", 1000)
                .addValue("PROGRAM_YEAR", 2021);

        Mockito.when(namedParameterJdbcTemplate.query(query, sqlParameterSource, new BeanPropertyRowMapper<>(QFOPatientExperienceScore.class)))
                .thenReturn(result);

        List<QFOPatientExperienceScore> qfoPatientExperienceScores = repository.fetchQFOPatientExperienceScores(0, 1000, getJobEvent(JobName.QFO_PATIENT_EXPERIENCE_SCORES.toString(), false));

        assert qfoPatientExperienceScores.size() == 0;

    }

    private JobEvent getJobEvent(String jobName, boolean isModified) {
        JobEvent jobEvent = new JobEvent();
        jobEvent.setProgramYear(2022);
        jobEvent.setJobName(jobName);
        jobEvent.setGroupsToExecute(isModified ? "Modified" : "All");
        jobEvent.setExecutionWeek("Current");
        jobEvent.setTimeStamp(Instant.now());
        jobEvent.setStatus("Complete");
        return jobEvent;
    }

    @Test
    public void getQFOPatientExperienceScoresModifiedScenario() {

        String query = "SELECT HEALTHORGID AS ProviderGroupId, PROGRAMYEAR AS ProgramYear, GNCRATE AS GncRate,  COORATE AS CooRate, DPCRATE AS DpcRate, CreatedDate AS CreatedDate, " +
                " UpdatedDate AS UpdatedDate FROM  ProgPerf.PATIENTEXPERIENCESCORE PES WHERE  HEALTHORGIDTYPE = 'PG' " +
                " AND RPT_MO_KEY =(  SELECT  max(RPT_MO_KEY)  FROM  ProgPerf.PATIENTEXPERIENCESCORE )  AND PROGRAMYEAR = ( " +
                " select  [value] from  ProgPerf.MasterConfiguration  where  code = 'CurrentProgramYear') " +
                "AND  CAST(UpdatedDate as date) >= (select CAST(LastSuccessfulRunDate as date)" +
                " from ProgPerf.jobrunconfiguration where jobname= '" + JobName.QFO_PATIENT_EXPERIENCE_SCORES.getValue() + "')" +
                "  ORDER BY ProgramYear offset :OFFSET rows FETCH next :BatchSize rows only ";

        List<QFOPatientExperienceScore> result = new ArrayList<>();

        SqlParameterSource sqlParameterSource = new MapSqlParameterSource("BatchSize", 0)
                .addValue("OFFSET", 1000)
                .addValue("PROGRAM_YEAR", 2021);

        Mockito.when(namedParameterJdbcTemplate.query(query, sqlParameterSource, new BeanPropertyRowMapper<>(QFOPatientExperienceScore.class)))
                .thenReturn(result);

        List<QFOPatientExperienceScore> qfoPatientExperienceScores = repository.fetchQFOPatientExperienceScores(0, 1000, getJobEvent(JobName.QFO_PATIENT_EXPERIENCE_SCORES.toString(), true));

        assert qfoPatientExperienceScores.size() == 0;

    }

}