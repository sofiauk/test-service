package com.optum.rqns.ftm.model;

import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.util.GetterSetterTester;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class JobRunConfigurationTest extends GetterSetterTester<JobRunConfiguration> {

    @Override
    public JobRunConfiguration getTestInstance() {
        return new JobRunConfiguration();
    }

    @Test
    public void TestConfig() {
        assertNotNull(getTestInstance());
    }

    @Test
    public void testJobRunConfiguration(){

        JobRunConfiguration jobRunConfiguration = new JobRunConfiguration(JobName.IDM_GLIDEPATH, "test", Status.SUCCESS, Constants.SYSTEM,
        Constants.SYSTEM, "test", false, false, false, false, false, false, 0L, "test", "test", "test", false, false, false, false);

        jobRunConfiguration.builder();

        assertEquals(Constants.SYSTEM, jobRunConfiguration.getCreatedBy());
        assertEquals(false, jobRunConfiguration.isActive);
    }
}