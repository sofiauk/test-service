package com.optum.rqns.ftm.model.fieldactionrules;

import com.optum.rqns.ftm.util.GetterSetterTester;
import org.junit.Assert;
import org.junit.Test;

public class NewProviderManualAssociationActionTest extends GetterSetterTester<NewProviderManualAssociationAction> {
    @Override
    public NewProviderManualAssociationAction getTestInstance() {
        return new NewProviderManualAssociationAction("test", "test", "test", 1, "test", "test");
    }

    @Test
    public void getNewProviderManualAssociationAction() {
        NewProviderManualAssociationAction newProviderManualAssociationAction = this.getTestInstance();
        Assert.assertNotNull(newProviderManualAssociationAction);
        Assert.assertEquals(newProviderManualAssociationAction.getProviderGroupID(), "test");
    }
}
