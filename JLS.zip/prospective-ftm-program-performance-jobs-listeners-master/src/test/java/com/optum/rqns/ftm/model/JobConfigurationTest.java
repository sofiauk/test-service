package com.optum.rqns.ftm.model;

import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.util.GetterSetterTester;
import org.junit.Test;

import java.time.LocalDateTime;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class JobConfigurationTest extends GetterSetterTester<JobConfiguration> {

    @Override
    public JobConfiguration getTestInstance() {
        return new JobConfiguration();
    }

    @Test
    public void TestConfig() {
        assertNotNull(getTestInstance());
    }

    @Test
    public void testJobConfiguration(){

        JobConfiguration jobConfiguration = new JobConfiguration(123, JobName.IDM_GLIDEPATH, "test", Constants.SYSTEM, LocalDateTime.now(), Constants.SYSTEM,
                LocalDateTime.now(), LocalDateTime.now(),"test","test","test", "test", false, new JobExecutionHistory());

        jobConfiguration.builder();

        assertEquals(Constants.SYSTEM, jobConfiguration.getCreatedBy());
        assertEquals(false, jobConfiguration.isActive());
    }
}