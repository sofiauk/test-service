package com.optum.rqns.ftm.repository.clientgoals;

import com.optum.rqns.ftm.model.clientgoals.ClientGoalsData;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;

@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        ClientGoalsRepositorympl.class
})
public class ClientGoalsRepositoryImplTest {

    @MockBean
    NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @InjectMocks
    ClientGoalsRepositorympl repository;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        repository = new ClientGoalsRepositorympl(this.namedParameterJdbcTemplate);
    }

    @Test
    public void processGetProviderGroupDetails() {
        String query  = "SELECT COUNT(*) as recCount FROM ProgPerf.ProviderGroupPerformanceWeekly " +
                "WHERE DeployYETarget > 0 AND ProgramYear = 2021 "+
                "AND DurationValue = (select DurationValue from ProgPerf.ProgramYearCalendar pyc where GetUtcDate() between pyc.StartDate and pyc.EndDate and DurationType = 'Week')";

        SqlParameterSource sqlParameterSource = new MapSqlParameterSource("PROGRAM_YEAR", 2021);
        Mockito.when(namedParameterJdbcTemplate.queryForObject(query, sqlParameterSource, Long.class))
                .thenReturn(10l);

        Long recordCount = repository.getRecordCount(2021);
        assert recordCount == null;
    }

    @Test
    public void processGetClientGoals() {
        String query  = "SELECT prov_group_id, providerstate, overall_status, project_year, deriveddeployed, returned from ProgPerf.MemberAssessmentHistory " +
                "WHERE prov_group_id in ('PG1') " +
                "AND project_year = ((select mc.value from ProgPerf.MasterConfiguration mc WITH (NOLOCK) where mc.code='CurrentProgramYear') - 1)";

        List<ClientGoalsData> result = new ArrayList<>();

        SqlParameterSource sqlParameterSource = new MapSqlParameterSource("BatchSize", 0)
                .addValue("OFFSET", 1000)
                .addValue("PROGRAM_YEAR",2021);

        Mockito.when(namedParameterJdbcTemplate.query(query, sqlParameterSource, new BeanPropertyRowMapper<>(ClientGoalsData.class)))
                .thenReturn(result);

        List<ClientGoalsData> clientGoalsData = repository.getClientGoals(0,1000, 2021);

        assert clientGoalsData.size() == 0;
    }

}