package com.optum.rqns.ftm.model.fieldactionrules;

import com.optum.rqns.ftm.util.GetterSetterTester;
import org.junit.Assert;
import org.junit.Test;


public class AvailMemberShipClientLobStateActionTest extends GetterSetterTester<AvailMembershipClientLobStateAction> {
    @Override
    public AvailMembershipClientLobStateAction getTestInstance() {
        return new AvailMembershipClientLobStateAction(1L,2L,"test","Test","test");
    }

    @Test
    public void getAvailMembershipClientLobStateAction() {
        AvailMembershipClientLobStateAction availMembershipClientLobStateAction = this.getTestInstance();
        Assert.assertNotNull(availMembershipClientLobStateAction);
        Assert.assertEquals(availMembershipClientLobStateAction.getClient(), "test");
    }
}
