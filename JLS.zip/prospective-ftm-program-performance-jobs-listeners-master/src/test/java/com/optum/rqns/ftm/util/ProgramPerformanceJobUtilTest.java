package com.optum.rqns.ftm.util;

import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.apache.commons.lang3.StringUtils;

public class ProgramPerformanceJobUtilTest {
    @Test
    public void testSantizeMessage_pass(){
        Assert.assertEquals("logmessage",ProgramPerformanceJobUtil.sanitizeLogMessage("logmessage"));
    }

    @Test
    public void testSantizeMessage_substring(){
        Assert.assertEquals(StringUtils.repeat("*", 5000),ProgramPerformanceJobUtil.sanitizeLogMessage(StringUtils.repeat("*", 6000)));
    }

    @Test
    public void testSantizeMessage_unsanitized(){
        Assert.assertEquals("_Print_",ProgramPerformanceJobUtil.sanitizeLogMessage("\rPrint\n"));
    }
}
