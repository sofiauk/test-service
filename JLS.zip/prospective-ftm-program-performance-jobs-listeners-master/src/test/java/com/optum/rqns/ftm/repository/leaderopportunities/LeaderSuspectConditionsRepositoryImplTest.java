package com.optum.rqns.ftm.repository.leaderopportunities;

import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.HashMap;

@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        LeaderOpportunitiesCommonRepositoryImpl.class
})
@SpringBootTest(properties = {
        "spring.db_connection_thread_pool_size=10",
})
public class LeaderSuspectConditionsRepositoryImplTest {
    @MockBean
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
    @InjectMocks
    private LeaderOpportunitiesCommonRepositoryImpl leaderCommonOpportunitiesRepository;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }


    @Test
    public void calculateSuspectConditionsDataTest() {
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(), Mockito.any(HashMap.class)))
                .thenReturn(20);
        final int recordCount = leaderCommonOpportunitiesRepository.calculateLeaderSuspectOppData("User1", new ArrayList<>(), "Quality Gaps");
        Assert.assertEquals(20,recordCount);
    }

    @Test
    public void calculateICLeaderSuspectConditionsDataTest() {
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(), Mockito.any(HashMap.class)))
                .thenReturn(20);
        final int recordCount = leaderCommonOpportunitiesRepository.calculateICSuspectOppData("User2", "HCA", "Suspect Conditions", 2021);
        Assert.assertEquals(20,recordCount);
    }

}
