package com.optum.rqns.ftm.service.membership;

import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.producer.KeyBasedProviderEligibleMembershipProducer;
import com.optum.rqns.ftm.kafka.producer.KeyBasedProviderSyncProducer;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.model.membership.ProviderEligibleMembershipFlatData;
import com.optum.rqns.ftm.repository.membership.ProviderEligibleMembershipRepository;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;


@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        ProviderEligibleMembershipServiceImpl.class
})
@SpringBootTest(properties = {
        "new_providergroup_rule_producer_thread_pool_size=10",
})
public class ProviderEligibleMembershipServiceTest {

    @MockBean
    private ProviderEligibleMembershipRepository providerEligibleMembershipRepository;

    @MockBean
    private KeyBasedProviderEligibleMembershipProducer producer;

    @InjectMocks
    private ProviderEligibleMembershipServiceImpl providerEligibleMembershipService;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void getProviderEligibleMembershipTest() {
        try {
            ReflectionTestUtils.setField(providerEligibleMembershipService, "producerThreadPoolSize", 10);
            JobEvent jobEvent = new JobEvent();
            jobEvent.setJobName(JobName.RUN_PROVIDER_ELIGIBLE_MEMBERSHIP.getValue());
            jobEvent.setGroupsToExecute("All");
            jobEvent.setProgramYear(2022);
            Mockito.when(providerEligibleMembershipRepository.getRecordCount(jobEvent)).thenReturn(25000l);


            List<ProviderEligibleMembershipFlatData> providerEligibleMembershipData = getProviderEligibleMembershipData();

            Mockito.when(providerEligibleMembershipRepository.getProviderEligibleMembershipDetails(10,1,jobEvent))
                    .thenReturn(providerEligibleMembershipData);

            JobStatus jobStatus = providerEligibleMembershipService.executeJob(getJobEvent(JobName.RUN_PROVIDER_ELIGIBLE_MEMBERSHIP.toString(), false));
            assert Status.SUCCESS == jobStatus.getStatus();

            assert 0 == jobStatus.getUpdatedRows();

        }catch(Exception e){}

    }

    private JobEvent getJobEvent(String jobName, boolean isModified) {
        JobEvent jobEvent = new JobEvent();
        jobEvent.setProgramYear(2022);
        jobEvent.setJobName(jobName);
        jobEvent.setGroupsToExecute(isModified ? "Modified" : "All");
        jobEvent.setExecutionWeek("Current");
        jobEvent.setTimeStamp(Instant.now());
        jobEvent.setStatus("Complete");
        return jobEvent;
    }

    private List<ProviderEligibleMembershipFlatData> getProviderEligibleMembershipData() {

        ProviderEligibleMembershipFlatData providerEligibleMembershipFlatData1 =
                ProviderEligibleMembershipFlatData.builder()
                        .providerGroupId("12113")
                       .providerState("CA")
                        .programYear(2022)
                        .clientId("AET")
                        .clientName("Aetna")
                        .build();

        ProviderEligibleMembershipFlatData  providerEligibleMembershipFlatData2 = ProviderEligibleMembershipFlatData.builder()
                .providerGroupId("45611")
                .providerState("CA")
                .programYear(2022)
                .clientId("AET")
                .clientName("Aetna")
                .build();

        List<ProviderEligibleMembershipFlatData> providerEligibleMembershipFlatDataList = new ArrayList<>();
        providerEligibleMembershipFlatDataList.add(providerEligibleMembershipFlatData1);
        providerEligibleMembershipFlatDataList.add(providerEligibleMembershipFlatData2);

        return  providerEligibleMembershipFlatDataList;
    }

}