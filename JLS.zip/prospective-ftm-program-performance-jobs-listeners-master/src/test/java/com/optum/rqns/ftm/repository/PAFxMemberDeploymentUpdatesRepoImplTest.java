package com.optum.rqns.ftm.repository;


import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.model.providergroup.PAFXMemberData;
import com.optum.rqns.ftm.model.providergroup.ProviderGroup;
import io.swagger.models.auth.In;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;

@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        PAFxMemberAssessmentDeploymentUpdatesRepositoryImpl.class
})
@SpringBootTest(properties = {
        "spring.db_connection_thread_pool_size=10",
})
public class PAFxMemberDeploymentUpdatesRepoImplTest {

    @MockBean
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @InjectMocks
    private PAFxMemberAssessmentDeploymentUpdatesRepositoryImpl pafxMemberAssessmentDeploymentUpdatesRepository;


    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }


    @Test
    public void getRecordCountTest() {
        HashMap<String,Object> params =  new HashMap<>();
        params.put("ProgramYear",2021);
        Mockito.when(namedParameterJdbcTemplate.queryForObject(pafxMemberAssessmentDeploymentUpdatesRepository.COUNT_QUERY,params,Long.class))
                .thenReturn(20l);

        final Long recordCount = pafxMemberAssessmentDeploymentUpdatesRepository.getRecordCount(2021);


        assert recordCount == 20;
    }


    @Test
    public void mergePAFXMemberDataTest() throws Exception {


        Mockito.when(namedParameterJdbcTemplate.update(pafxMemberAssessmentDeploymentUpdatesRepository.DATA_MERGE_QUERY,new HashMap<>()))
                .thenReturn(20);
        JobEvent jobEvent = JobEvent.newBuilder().setProgramYear(2021).build();
        final Integer integerCallable = pafxMemberAssessmentDeploymentUpdatesRepository.mergePAFXMemberData(25000, 0, jobEvent);

        assert integerCallable == 0;
    }



    @Test
    public void getRecordCountModified() {
        HashMap<String,Object> params =  new HashMap<>();
        params.put("ProgramYear",2021);
        params.put("lastSucessfullRun","2022-03-22 07:30:00");
        Mockito.when(namedParameterJdbcTemplate.queryForObject(pafxMemberAssessmentDeploymentUpdatesRepository.COUNT_QUERY_MODIFIED,params,Long.class))
                .thenReturn(20l);

        final Long recordCount = pafxMemberAssessmentDeploymentUpdatesRepository.getRecordCountModified(2021,"2022-03-22 07:30:00");


        assert recordCount == 20;
    }


   @Test
    public void getListOfModifiedIdFromPafx() {
       final List<Object> usersList = Arrays.asList(1, 2);
       Mockito.when(namedParameterJdbcTemplate.queryForList(
               Mockito.anyString(),
               Mockito.anyMap(),
               Mockito.any()
       )).thenReturn(usersList);

        final List<Integer>  recordCount = pafxMemberAssessmentDeploymentUpdatesRepository.getListOfModifiedIdFromPafx(25000,0,2021,"2022-03-22 07:30:00");


        assert recordCount.size() == 2;
    }


    @Test
    public void mergeModifiedData() {
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(), Mockito.any(SqlParameterSource.class)))
                .thenReturn(20);

        final Integer recordCount = pafxMemberAssessmentDeploymentUpdatesRepository.mergeModifiedData("1,2");


        assert recordCount == 20;
    }

}
