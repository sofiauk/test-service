package com.optum.rqns.ftm.service;

import com.optum.rqns.ftm.enums.ExecutionWeek;
import com.optum.rqns.ftm.enums.GroupsToExecute;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.exception.ProgramPerformanceJobListenerException;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.repository.PAFxMemberAssessmentStagingRepository;
import com.optum.rqns.ftm.repository.common.CommonRepository;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.time.Instant;

@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        PAFxMemberAssessmentStagingServiceImpl.class
})
public class PAFxMemberAssessmentStagingServiceImplTest {

    @MockBean
    private PAFxMemberAssessmentStagingRepository paFxMemberAssessmentStagingRepository;

    @InjectMocks
    private PAFxMemberAssessmentStagingServiceImpl paFxMemberAssessmentStagingService;

    @MockBean
    private CommonRepository commonRepository;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }


    @Test
    public void executeJob() {
//        ReflectionTestUtils.setField(paFxMemberAssessmentStagingService, "producerThreadPoolSize", 1);

        Mockito.when(paFxMemberAssessmentStagingRepository.getRecordCount(getJobEvent())).thenReturn(25000l);
        Mockito.when(paFxMemberAssessmentStagingRepository.mergePAFxMemberAssessmentData(getJobEvent(),0,10000))
                .thenReturn(0);


        JobEvent jobEvent = JobEvent.newBuilder().setProgramYear(2021).setJobName(JobName.RUN_PAFX_MEMBER_ASSESSMENT_STAGING.getValue())
                .setGroupsToExecute(GroupsToExecute.ALL.getValue())
                .setExecutionWeek(ExecutionWeek.ALL.getValue()).setStatus(Status.IN_PROGRESS.getValue())
                .setTimeStamp(Instant.now()).setCascadeEvents(true).build();
        final JobStatus jobStatus = paFxMemberAssessmentStagingService.executeJob(jobEvent);

        assert jobStatus.getUpdatedRows() == 0;
    }

    private JobEvent getJobEvent(){
        JobEvent jobEvent = new JobEvent();
        jobEvent.setProgramYear(2022);
        jobEvent.setJobName(JobName.RUN_PAFX_MEMBER_ASSESSMENT_STAGING.getValue());
        jobEvent.setExecutionWeek("Current");
        jobEvent.setGroupsToExecute("All");
        jobEvent.setTimeStamp(Instant.now());
        jobEvent.setStatus("Complete");

        return jobEvent;
    }
    @Test
    public void executeJobException() {

        JobEvent jobEventinput = JobEvent.newBuilder().setJobName(JobName.RUN_PAFX_MEMBER_ASSESSMENT_STAGING.getValue())
                .setProgramYear(2022)
                .setGroupsToExecute(GroupsToExecute.ALL.getValue())
                .setExecutionWeek(ExecutionWeek.ALL.getValue()).setStatus(Status.IN_PROGRESS.getValue())
                .setTimeStamp(Instant.now()).setCascadeEvents(true).build();
        Mockito.when(paFxMemberAssessmentStagingRepository.getRecordCount(getJobEvent())).thenReturn(25000l);
        Mockito.when(paFxMemberAssessmentStagingRepository.mergePAFxMemberAssessmentData(Mockito.any(),Mockito.anyInt(), Mockito.anyInt()))
                .thenThrow(new ProgramPerformanceJobListenerException(""));

        final JobStatus jobStatus = paFxMemberAssessmentStagingService.executeJob(jobEventinput);
        System.out.println("job status {}"+jobStatus.getStatus());
        assert Status.SUCCESS == jobStatus.getStatus();
        assert 0 == jobStatus.getUpdatedRows();
    }

}
