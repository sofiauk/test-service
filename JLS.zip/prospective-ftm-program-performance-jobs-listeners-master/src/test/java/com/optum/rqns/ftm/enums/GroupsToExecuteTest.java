package com.optum.rqns.ftm.enums;

import org.junit.Assert;
import org.junit.Test;

public class GroupsToExecuteTest {

    @Test
    public void apiJobNameTest(){
        GroupsToExecute groupsToExecute = GroupsToExecute.ALL;
        Assert.assertNotNull(groupsToExecute.getValue());
        Assert.assertEquals(GroupsToExecute.valueOf("ALL"), groupsToExecute);
    }

}
