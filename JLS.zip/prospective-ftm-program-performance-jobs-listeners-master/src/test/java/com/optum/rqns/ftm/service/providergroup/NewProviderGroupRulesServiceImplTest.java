package com.optum.rqns.ftm.service.providergroup;

import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.producer.JobEventProducer;
import com.optum.rqns.ftm.kafka.producer.KeyBasedProviderSyncProducer;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.model.providergroup.MemberAssessmentHistory;
import com.optum.rqns.ftm.model.providergroup.ProviderGroup;
import com.optum.rqns.ftm.repository.providergroup.NewProviderGroupRuleRepository;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        NewProviderGroupRulesServiceImpl.class
})
@SpringBootTest(properties = {
        "new_providergroup_rule_producer_thread_pool_size=1",
})
public class NewProviderGroupRulesServiceImplTest {

    @MockBean
    private NewProviderGroupRuleRepository providerGroupDetailsRepository;

    @MockBean
    private KeyBasedProviderSyncProducer producer;

    @MockBean
    private JobEventProducer jobEventProducer;

    @InjectMocks
    private NewProviderGroupRulesServiceImpl newProviderGroupService;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void getNewProviderGroupDetails() {
        try {
            ReflectionTestUtils.setField(newProviderGroupService, "producerThreadPoolSize", 1);
            List<ProviderGroup> providerGroups = getProviderGroups();

            Mockito.when(providerGroupDetailsRepository.getProviderGroupsRecordCount(Mockito.anyBoolean(), Mockito.anyInt())).thenReturn(10000l);
            Mockito.when(providerGroupDetailsRepository.getProviderGroupDetailsByOffset(Constants.NEW_PROVIDER_GROUP_RULE_BATCH_SIZE, 5000, true, 0)).thenReturn(providerGroups);

            Mockito.when(jobEventProducer.postToKafka(getJobEvent())).thenReturn(true);

            List<MemberAssessmentHistory> memberAssessmentHistories = getMemberAssessmentHistory();
            Mockito.when(providerGroupDetailsRepository.getMemberAssessmentHistoryDetails(Mockito.anyString(), Mockito.anyInt()))
                    .thenReturn(memberAssessmentHistories);

            Mockito.when(providerGroupDetailsRepository.updateBatchQueries(Mockito.anyList())).thenReturn(new int[1]);
            Mockito.when(providerGroupDetailsRepository.updateIsGroupEligiblePOC(Mockito.anyBoolean(),Mockito.anyInt(),Mockito.anyInt(),Mockito.anyInt())).thenReturn(2);
            Mockito.when(providerGroupDetailsRepository.updateCommandCenterPerformanceAggregates(2021)).thenReturn(2);

            JobStatus jobStatus = newProviderGroupService.executeJob(getJobEvent(JobName.RUN_NEW_PROVIDER_GROUP_RULES.toString(), false));
            assert Status.SUCCESS == jobStatus.getStatus();

            assert 0 == jobStatus.getUpdatedRows();

        }catch(Exception e){
        }

    }

    @Test
    public void getNewProviderGroupDetails_With_Modified() {
        try {
            ReflectionTestUtils.setField(newProviderGroupService, "producerThreadPoolSize", 1);
            List<ProviderGroup> providerGroups = getProviderGroups();
            Mockito.when(providerGroupDetailsRepository.getProviderGroupDetailsBasedOnProviderGroups(Mockito.anyString(), Mockito.anyInt(), Mockito.anyBoolean()))
                    .thenReturn(providerGroups);

            Mockito.when(jobEventProducer.postToKafka(getJobEvent())).thenReturn(true);

            List<MemberAssessmentHistory> memberAssessmentHistories = getMemberAssessmentHistory();

            Mockito.when(providerGroupDetailsRepository.getMemberAssessmentHistoryDetailsBasedOnLastJobRunDateRecordCount(Mockito.anyInt())).thenReturn(10000l);
            Mockito.when(providerGroupDetailsRepository.getMemberAssessmentHistoryProviderGroupsBasedOnLastRunDate(10000, 0, 2022))
                    .thenReturn(memberAssessmentHistories);
            Mockito.when(providerGroupDetailsRepository.getMemberAssessmentHistoryDetailsBasedOnLastJobRunDateRecordsByOffset("'PG1,'PG2'", 2022))
                    .thenReturn(memberAssessmentHistories);

            Mockito.when(providerGroupDetailsRepository.updateBatchQueries(Mockito.anyList())).thenReturn(new int[1]);
            Mockito.when(providerGroupDetailsRepository.updateIsGroupEligiblePOC(Mockito.anyBoolean(),Mockito.anyInt(),Mockito.anyInt(),Mockito.anyInt())).thenReturn(2);


            JobStatus jobStatus = newProviderGroupService.executeJob(getJobEvent(JobName.RUN_NEW_PROVIDER_GROUP_RULES.toString(), true));
            assert Status.SUCCESS == jobStatus.getStatus();

            assert 2 == jobStatus.getUpdatedRows();

        }catch(Exception e){}

    }

    @Test
    public void getNewProviderGroupDetails_With_Modified_With_Zero_Count() {
        try {
            ReflectionTestUtils.setField(newProviderGroupService, "producerThreadPoolSize", 1);
            List<ProviderGroup> providerGroups = getProviderGroups();
            Mockito.when(providerGroupDetailsRepository.getProviderGroupDetailsBasedOnProviderGroups(Mockito.anyString(), Mockito.anyInt(), Mockito.anyBoolean()))
                    .thenReturn(providerGroups);

            Mockito.when(jobEventProducer.postToKafka(getJobEvent())).thenReturn(true);

            List<MemberAssessmentHistory> memberAssessmentHistories = getMemberAssessmentHistory();

            Mockito.when(providerGroupDetailsRepository.getMemberAssessmentHistoryDetailsBasedOnLastJobRunDateRecordCount(2021)).thenReturn(10000l);
            Mockito.when(providerGroupDetailsRepository.getMemberAssessmentHistoryProviderGroupsBasedOnLastRunDate(10000, 0, 2022))
                    .thenReturn(memberAssessmentHistories);
            Mockito.when(providerGroupDetailsRepository.getMemberAssessmentHistoryDetailsBasedOnLastJobRunDateRecordsByOffset("'PG1,'PG2'", 2022))
                    .thenReturn(memberAssessmentHistories);

            Mockito.when(providerGroupDetailsRepository.updateBatchQueries(Mockito.anyList())).thenReturn(new int[1]);
            Mockito.when(providerGroupDetailsRepository.updateIsGroupEligiblePOC(Mockito.anyBoolean(),Mockito.anyInt(),Mockito.anyInt(),Mockito.anyInt())).thenReturn(2);


            JobStatus jobStatus = newProviderGroupService.executeJob(getJobEvent(JobName.RUN_NEW_PROVIDER_GROUP_RULES.toString(), true));
            assert Status.SUCCESS == jobStatus.getStatus();

            assert 0 == jobStatus.getUpdatedRows();

        }catch(Exception e){}

    }

    private JobEvent getJobEvent(String jobName, boolean isModified) {
        JobEvent jobEvent = new JobEvent();
        jobEvent.setProgramYear(2020);
        jobEvent.setJobName(jobName);
        jobEvent.setGroupsToExecute(isModified ? "Modified" : "All");
        jobEvent.setExecutionWeek("Current");
        jobEvent.setTimeStamp(Instant.now());
        jobEvent.setStatus("Complete");
        jobEvent.setJobInput("{\"executeForNewGroups\": true}");
        return jobEvent;
    }

    private List<ProviderGroup>  getProviderGroups() {
        ProviderGroup providerGroupDTO1 =
                ProviderGroup.builder()
                        .providerGroupId("123")
                        .state("CA")
                        .newForDeployment(true)
                        .programYear(2020)
                        .build();

        ProviderGroup ProviderGroupDTO2 =
                ProviderGroup.builder()
                        .providerGroupId("456")
                        .state("CA")
                        .newForDeployment(true)
                        .eligiblePreferredMembers(20d)
                        .programYear(2020)
                        .build();

        List<ProviderGroup> providerGroups = new ArrayList<>();
        providerGroups.add(providerGroupDTO1);
        providerGroups.add(ProviderGroupDTO2);

        return  providerGroups;
    }

    private List<MemberAssessmentHistory> getMemberAssessmentHistory() {

        MemberAssessmentHistory memberAssessmentHistory1 =
                MemberAssessmentHistory.builder()
                        .provGroupId("123")
                        .providerState("CA")
                        .overallStatus("test")
                        .projectYear(2019)
                        .build();

        MemberAssessmentHistory memberAssessmentHistory2 =
                MemberAssessmentHistory.builder()
                        .provGroupId("456")
                        .providerState("CA")
                        .overallStatus("complete")
                        .projectYear(2019)
                        .build();

        List<MemberAssessmentHistory> memberAssessmentHistories = new ArrayList<>();
        memberAssessmentHistories.add(memberAssessmentHistory1);
        memberAssessmentHistories.add(memberAssessmentHistory2);

        return memberAssessmentHistories;
    }
    private JobEvent getJobEvent(){
        JobEvent jobEvent = new JobEvent();
        jobEvent.setProgramYear(2021);
        jobEvent.setJobName(JobName.RUN_NEW_PROVIDER_GROUP_RULES.getValue());
        jobEvent.setExecutionWeek("Current");
        jobEvent.setGroupsToExecute("All");
        jobEvent.setTimeStamp(Instant.now());
        jobEvent.setStatus("Complete");
        jobEvent.setCascadeEvents(true);
        jobEvent.setJobInput("{\"executeForNewGroups\": true}");

        return jobEvent;
    }

}