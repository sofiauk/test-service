package com.optum.rqns.ftm.model.providergroup;

import com.optum.rqns.ftm.util.GetterSetterTester;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class ProviderGroupTest extends GetterSetterTester<ProviderGroup> {

    @Override
    public ProviderGroup getTestInstance() {
        return new ProviderGroup();
    }

    @Test
    public void TestConfig() {
        assertNotNull(getTestInstance());
    }

    @Test
    public void testProviderGroup(){


        ProviderGroup providerGroup = new ProviderGroup("PG1","MN",true,true,
                1d, 2021, "FLA");
        providerGroup.builder();

        Double eligibleMembers = 1d;
        assertEquals("PG1", providerGroup.getProviderGroupId());
        assertEquals("MN", providerGroup.getState());
        assertEquals(eligibleMembers, providerGroup.getEligiblePreferredMembers());
        assertEquals(2021, providerGroup.getProgramYear());
        assertEquals("PG1", providerGroup.getProviderGroupId());
        assertEquals(true, providerGroup.getNewForDeployment());
        assertEquals(true, providerGroup.getNewForPOC());
        assertEquals("FLA", providerGroup.getEligibleProgramType());
    }
}