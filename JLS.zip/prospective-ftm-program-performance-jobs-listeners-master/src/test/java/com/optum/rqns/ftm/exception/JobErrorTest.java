package com.optum.rqns.ftm.exception;

import com.optum.rqns.ftm.util.GetterSetterTester;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class JobErrorTest extends GetterSetterTester<JobError> {

    @Override
    public JobError getTestInstance() {
        return new JobError("1001","tst","test");
    }

    @Test
    public void TestConfig() {
        JobError error = getTestInstance();
        assertNotNull(error);
        assertNotNull(error.toString());
        assertEquals("test",error.getTitle());
    }

    @Test
    public void TestConfig_ApiError() {
        JobError error = new JobError("1","1","1");
        error.toString();

        assertNotNull(error.getCode());
        assertNotNull(error.getTitle());
        assertNotNull(error.getDetail());

    }
}
