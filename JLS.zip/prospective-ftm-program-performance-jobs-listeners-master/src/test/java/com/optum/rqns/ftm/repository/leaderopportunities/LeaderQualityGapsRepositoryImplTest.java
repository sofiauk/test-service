package com.optum.rqns.ftm.repository.leaderopportunities;

import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        LeaderOpportunitiesCommonRepositoryImpl.class
})
@SpringBootTest(properties = {
        "spring.db_connection_thread_pool_size=10",
})
public class LeaderQualityGapsRepositoryImplTest {
    @MockBean
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
    @InjectMocks
    private LeaderOpportunitiesCommonRepositoryImpl leaderCommonOpportunitiesRepository;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }


    @Test
    public void calculateLeaderQualityGapsDataTest() {
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(), Mockito.any(HashMap.class)))
                .thenReturn(20);
        final int recordCount = leaderCommonOpportunitiesRepository.calculateLeaderCommonOppData("User1", new ArrayList<>(), "Quality Gaps", JobName.LEADER_QUALITY_GAPS_OPPORTUNITIES.getValue());
        Assert.assertEquals(20,recordCount);
    }

    @Test
    public void calculateICLeaderQualityGapsDataTest() {
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(), Mockito.any(HashMap.class)))
                .thenReturn(20);
        final int recordCount = leaderCommonOpportunitiesRepository.calculateICQualityGapsAndACVOppData("User2", "HCA", "Quality Gaps", 2021, JobName.LEADER_QUALITY_GAPS_OPPORTUNITIES.getValue());
        Assert.assertEquals(20,recordCount);
    }

    @Test
    public void getLeaderQualityGapsServiceLevelForUserTest() {

        Mockito.when(
                namedParameterJdbcTemplate
                        .queryForList(
                                Mockito.anyString(),
                                Mockito.anyMap(),
                                Mockito.any()
                        )
        )
                .thenReturn(Arrays.asList("HCA", "PSC"));
        final List<String> serviceLevels = leaderCommonOpportunitiesRepository.getServiceLevelForUser("User1");

        Assert.assertNotNull(serviceLevels);
        Assert.assertEquals("HCA", serviceLevels.get(0));
        Assert.assertEquals("PSC", serviceLevels.get(1));
    }

    @Test
    public void flagIsActiveFalseLeaderOpportunitiesTest() {
        JobEvent jobEvent = new JobEvent();
        jobEvent.setJobName(JobName.LEADER_QUALITY_GAPS_OPPORTUNITIES.getValue());
        jobEvent.setProgramYear(2021);

        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(), Mockito.any(HashMap.class)))
                .thenReturn(2021);
        final int recordCount = leaderCommonOpportunitiesRepository.flagIsActiveFalseLeaderOpportunities(jobEvent,JobName.LEADER_QUALITY_GAPS_OPPORTUNITIES.getValue());
        Assert.assertEquals(2021,recordCount);
    }

}
