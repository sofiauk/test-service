package com.optum.rqns.ftm.service.fieldactionrules;

import com.optum.rqns.ftm.enums.ExecutionWeek;
import com.optum.rqns.ftm.enums.GroupsToExecute;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.producer.JobEventProducer;
import com.optum.rqns.ftm.kafka.producer.KeyBasedFieldActionRuleProducer;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.model.fieldactionrules.ChangeServiceAction;
import com.optum.rqns.ftm.model.fieldactionrules.RuleAction;
import com.optum.rqns.ftm.repository.fieldactionrules.ChangeServiceLevelRuleRepositoryImpl;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        ChangeServiceLevelRuleServiceImpl.class
})
@SpringBootTest(properties = {
        "spring.producer_thread_pool_size=10",
})
public class ChangeServiceLevelRuleTest {


    @MockBean
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @MockBean
    private ChangeServiceLevelRuleRepositoryImpl changeServiceLevelRuleRepository;

    @MockBean
    private FieldActionRuleService fieldActionRuleService;

    @InjectMocks
    private ChangeServiceLevelRuleServiceImpl changeServiceLevelRuleService;

    @MockBean
    private JobEventProducer jobEventProducer;

    @MockBean
    KeyBasedFieldActionRuleProducer producerV1;

    @MockBean
    KIERuleOrchestrator kieRuleOrchestrator;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void executeJob() {
        List<RuleAction> list = new ArrayList<>();
        list.add(new ChangeServiceAction(1, 1, "test", "test", "test", "test", "test"));
        List<Integer> intList= new ArrayList<>();
        intList.add(100);
        Mockito.when(changeServiceLevelRuleService.fetchRuleBatchingOffsetList(Mockito.anyInt())).thenReturn(intList);
      //  Mockito.when(changeServiceLevelRuleService.fetchRuleData(Mockito.any(),Mockito.anyInt(),Mockito.anyBoolean())).thenReturn(list);
        ReflectionTestUtils.setField(changeServiceLevelRuleService, "producerThreadPoolSize", 1);
        Mockito.when(changeServiceLevelRuleRepository.getProvidersWithChangeServiceLevel(2, 2)).thenReturn(getProviderDetailsInfo());
        Mockito.when(kieRuleOrchestrator.getRulesExecutedData(Mockito.anyList(), Mockito.any())).thenReturn(list);
        Mockito.when(jobEventProducer.postToKafka(getJobEvent())).thenReturn(true);

        JobEvent jobEvent = JobEvent.newBuilder().setJobName(JobName.RUN_CHANGE_SERVICE_LEVEL_RULE.toString())
                .setGroupsToExecute(GroupsToExecute.MODIFIED.getValue())
                .setExecutionWeek(ExecutionWeek.ALL.getValue()).setStatus(Status.IN_PROGRESS.getValue())
                .setTimeStamp(Instant.now()).setCascadeEvents(true).build();
        final JobStatus jobStatus = changeServiceLevelRuleService.executeJob(jobEvent);
        //assert jobStatus.getUpdatedRows() == 20;
    }

    @Test
    public void testGetRuleResult(){
        RuleAction ruleAction=this.getProviderDetailsInfo().get(0);
        Assert.assertNotNull(changeServiceLevelRuleService.getRuleResult(ruleAction));

    }

    @Test
    public void testFetchRuleBatchingOffsetList(){
        Assert.assertNotNull(changeServiceLevelRuleService.fetchRuleBatchingOffsetList(1000));

    }
    private JobEvent getJobEvent(){
        JobEvent jobEvent = new JobEvent();
        jobEvent.setProgramYear(2020);
        jobEvent.setJobName("RunWeeklyJobs");
        jobEvent.setExecutionWeek("Current");
        jobEvent.setGroupsToExecute("All");
        jobEvent.setTimeStamp(Instant.now());
        jobEvent.setStatus("Complete");
        jobEvent.setCascadeEvents(true);

        return jobEvent;
    }

    private List<RuleAction> getProviderDetailsInfo(){

        List<RuleAction> ruleActions=new ArrayList<>();
        ChangeServiceAction changeServiceAction =new ChangeServiceAction();
        changeServiceAction.setGroupName("test");
        changeServiceAction.setState("test");
        changeServiceAction.setGroupId("test");
        changeServiceAction.setManagerUUID("test");
        changeServiceAction.setManagerEmail("test");
        changeServiceAction.setEligibleDeployableMembers(1);
        changeServiceAction.setDerivedDeployed(1);


        ruleActions.add(changeServiceAction);
        return ruleActions;
    }

    @Test
    public void getRuleContext(){
        RuleAction ruleAction = this.getProviderDetailsInfo().get(0);
        Assert.assertNotNull(changeServiceLevelRuleService.getRuleContext(ruleAction));

    }
}
