package com.optum.rqns.ftm.model.opportunities;

import com.optum.rqns.ftm.util.GetterSetterTester;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class OpportunitiesSummaryCountsTest extends GetterSetterTester<OpportunitiesSummaryCounts> {
    @Override
    public OpportunitiesSummaryCounts getTestInstance() {
            return  new OpportunitiesSummaryCounts(1,1,1);
    }

    @Test
    public void testPAFXMemberData(){
        OpportunitiesSummaryCounts opportunitiesSummaryCounts = this.getTestInstance();
        opportunitiesSummaryCounts.builder();
        assertEquals(1, opportunitiesSummaryCounts.getTotalAssessmentCount());
        assertEquals(this.getTestInstance().toString(),opportunitiesSummaryCounts.toString());

    }

}
