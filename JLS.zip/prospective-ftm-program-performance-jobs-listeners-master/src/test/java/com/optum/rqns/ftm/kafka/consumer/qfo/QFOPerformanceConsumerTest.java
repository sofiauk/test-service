package com.optum.rqns.ftm.kafka.consumer.qfo;

import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.model.JobRunConfiguration;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.repository.common.CommonRepositoryImpl;
import com.optum.rqns.ftm.service.qfo.QFOPerformanceServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.json.simple.parser.ParseException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import static org.mockito.ArgumentMatchers.any;

@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        QFOPerformanceConsumer.class
})
public class QFOPerformanceConsumerTest {

    @InjectMocks
    private QFOPerformanceConsumer qfoPerformanceConsumer;

    @Mock
    private Acknowledgment acknowledgment;

    @Mock
    private QFOPerformanceServiceImpl qfoPerformanceService;

    @Mock
    private CommonRepositoryImpl commonRepository;

    @Before
    public void initMocks() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void onMessageTestSuccess() throws ParseException {
        JobEvent jobEvent = new JobEvent();
        jobEvent.setJobName(JobName.QFOPERFORMANCE.getValue());


        JobStatus jobStatus = new JobStatus();
        jobStatus.setMessage("success");
        jobStatus.setStatus(Status.SUCCESS);
        jobStatus.setUpdatedRows(1L);
        ConsumerRecord<String, JobEvent> consumerRecord =
                new ConsumerRecord<>("test.topic", 13, 0, new String(), jobEvent);
        Mockito.when(commonRepository.getJobIsActiveByName(any(String.class))).thenReturn(true);
        Mockito.when(commonRepository.upsertJobRunConfiguration(any(JobRunConfiguration.class))).thenReturn(1);
        Mockito.when(commonRepository.updateJobExecutionHistoryAsJobStart(any(Integer.class), any(String.class), any(String.class), any(String.class))).thenReturn(1);
        Mockito.when(commonRepository.getJobIdByName(any(String.class))).thenReturn(1);
        Mockito.when(commonRepository.getJobExecutionHistoryByTime(any(Integer.class),any(Integer.class))).thenReturn(0);
        Mockito.when(commonRepository.getJobExecutionHistoryByMessageKey(any(Integer.class), any(String.class))).thenReturn(0);
        Mockito.when(qfoPerformanceService.executeJob(any(JobEvent.class))).thenReturn(jobStatus);
        Mockito.when(commonRepository.updateJobExecutionHistoryAsJobEnd(any(Integer.class), any(Status.class),
                any(String.class),any(String.class),  any(Long.class))).thenReturn(1);
        qfoPerformanceConsumer.onMessage(consumerRecord, acknowledgment);

        Mockito.verify(acknowledgment, Mockito.times(1)).acknowledge();
        Mockito.verify(commonRepository, Mockito.times(2)).upsertJobRunConfiguration(any(JobRunConfiguration.class));
        Mockito.verify(commonRepository, Mockito.times(1)).updateJobExecutionHistoryAsJobStart(any(Integer.class), any(String.class), any(String.class), any(String.class));
        Mockito.verify(commonRepository, Mockito.times(1)).updateJobExecutionHistoryAsJobEnd(any(Integer.class), any(Status.class),
                any(String.class),any(String.class),  any(Long.class));
        Mockito.verify(commonRepository, Mockito.times(2)).getJobIdByName(any(String.class));
        Mockito.verify(qfoPerformanceService, Mockito.times(1)).executeJob(any(JobEvent.class));

    }
}
