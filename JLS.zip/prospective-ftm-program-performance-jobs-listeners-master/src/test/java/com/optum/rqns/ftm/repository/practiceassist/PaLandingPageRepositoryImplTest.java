package com.optum.rqns.ftm.repository.practiceassist;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.optum.rqns.ftm.enums.GroupsToExecute;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.model.practiceassist.PaAggregationData;

import lombok.extern.slf4j.Slf4j;

@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
		PaLandingPageRepositoryImpl.class
})
@SpringBootTest(properties = {
        "spring.db_connection_thread_pool_size=10",
})
public class PaLandingPageRepositoryImplTest {

    @MockBean
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @InjectMocks
    private PaLandingPageRepositoryImpl paLandingPageRepositoryImpl;


    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(paLandingPageRepositoryImpl, "isPPSTCDFeatureEnable", false);
        ReflectionTestUtils.setField(paLandingPageRepositoryImpl, "isInActiveFeatureEnable", false);
    }


  
	@Test
	public void getPaAggregateDataByBatchTest() {
		List result = new ArrayList<PaAggregationData>();

		result.add(new PaAggregationData());

		Mockito.when(namedParameterJdbcTemplate.query(Mockito.anyString(), Mockito.any(HashMap.class),
				Mockito.any(BeanPropertyRowMapper.class))).thenReturn(result);

		final List<PaAggregationData> data = paLandingPageRepositoryImpl.getPaAggregateDataByBatch(2021,"2022-04-13 21:19:15", "2022-04-12 21:19:15",1, 100);

		assert data.size() ==1 ;
	}
	
	@Test
	public void getUpserQualityAggregation() {

		List data = new ArrayList<PaAggregationData>();

		int[] batchCount = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

		data.add(new PaAggregationData());

		Mockito.when(
				namedParameterJdbcTemplate.batchUpdate(Mockito.anyString(), Mockito.any(MapSqlParameterSource[].class)))
				.thenReturn(batchCount);

		final Integer updatedCount = paLandingPageRepositoryImpl.upserQualityAggregation(data);

		assert updatedCount == 10;

	}
	
	
	@Test
	public void getUpserSuspectAggregation()
	{
		List data = new ArrayList<PaAggregationData>();

		int[] batchCount = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
		data.add(new PaAggregationData());
		Mockito.when(
				namedParameterJdbcTemplate.batchUpdate(Mockito.anyString(), Mockito.any(MapSqlParameterSource[].class)))
				.thenReturn(batchCount);
		final Integer updatedCount = paLandingPageRepositoryImpl.upserSuspectAggregation(data);
		assert updatedCount == 10;
	}
	
	@Test
	public void getPaSuspectAggregateDataByBatch() {
		List result = new ArrayList<PaAggregationData>();

		result.add(new PaAggregationData());

		Mockito.when(namedParameterJdbcTemplate.query(Mockito.anyString(), Mockito.any(HashMap.class),
				Mockito.any(BeanPropertyRowMapper.class))).thenReturn(result);

		final List<PaAggregationData> data = paLandingPageRepositoryImpl.getPaSuspectAggregateDataByBatch(2021,"2022-04-13 21:19:15","2022-04-13 22:20:15", 1, 100);

		assert data.size() ==1 ;
	}
	
	@Test
	public void getUpserMedAdherenceAggregateDataByBatch() {
		List data = new ArrayList<PaAggregationData>();

		int[] batchCount = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
		data.add(new PaAggregationData());
		Mockito.when(
				namedParameterJdbcTemplate.batchUpdate(Mockito.anyString(), Mockito.any(MapSqlParameterSource[].class)))
				.thenReturn(batchCount);
		final Integer updatedCount = paLandingPageRepositoryImpl.upserMedAdherenceAggregation(data);
		assert updatedCount == 10;
	}
	
	@Test
	public void getPaMedAdherenceAggregateDataByBatch() {
		List result = new ArrayList<PaAggregationData>();

		result.add(new PaAggregationData());

		Mockito.when(namedParameterJdbcTemplate.query(Mockito.anyString(), Mockito.any(HashMap.class),
				Mockito.any(BeanPropertyRowMapper.class))).thenReturn(result);

		final List<PaAggregationData> data = paLandingPageRepositoryImpl.getPaMedAdherenceAggregateDataByBatch(2021,"2022-04-13 21:19:15", "2022-04-13 21:19:15",1, 100);

		assert data.size() ==1 ;
	}

	@Test
	public void getUpserMemberSummaryAggregationDataByBatch() {
		List data = new ArrayList<PaAggregationData>();

		int[] batchCount = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
		data.add(new PaAggregationData());
		Mockito.when(
						namedParameterJdbcTemplate.batchUpdate(Mockito.anyString(), Mockito.any(MapSqlParameterSource[].class)))
				.thenReturn(batchCount);
		final Integer updatedCount = paLandingPageRepositoryImpl.upserMemberSummaryAggregation(data);
		assert updatedCount == 10;
	}

	@Test
	public void getPaMemberSummaryAggregateDataByBatch() {
		List result = new ArrayList<PaAggregationData>();

		result.add(new PaAggregationData());

		Mockito.when(namedParameterJdbcTemplate.query(Mockito.anyString(), Mockito.any(HashMap.class),
				Mockito.any(BeanPropertyRowMapper.class))).thenReturn(result);

		final List<PaAggregationData> data = paLandingPageRepositoryImpl.getPaMemberSummaryAggregateDataByBatch(2021,"2022-04-13 21:19:15","2022-04-13 21:19:1", 1, 100);

		assert data.size() ==1 ;
	}
	
	@Test
	public void getPaHospitalEventsAggregateDataByBatchTest() {
		List result = new ArrayList<PaAggregationData>();

		result.add(new PaAggregationData());

		Mockito.when(namedParameterJdbcTemplate.query(Mockito.anyString(), Mockito.any(HashMap.class),
				Mockito.any(BeanPropertyRowMapper.class))).thenReturn(result);

		final List<PaAggregationData> data = paLandingPageRepositoryImpl.getPaHospitalEventsAggregateDataByBatch(2021,"2022-04-13 21:19:15", "2022-04-12 21:19:15",1, 100);

		assert data.size() ==1 ;
	}
	
	@Test
	public void getUpserHospitalEventsAggregation() {

		List data = new ArrayList<PaAggregationData>();

		int[] batchCount = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

		data.add(new PaAggregationData());

		Mockito.when(
				namedParameterJdbcTemplate.batchUpdate(Mockito.anyString(), Mockito.any(MapSqlParameterSource[].class)))
				.thenReturn(batchCount);

		final Integer updatedCount = paLandingPageRepositoryImpl.upserHospitalEventsAggregation(data);

		assert updatedCount == 10;

	}


	@Test
	public void getAffectedProvGrpList() {
		List<Object> result = new ArrayList<Object>();

		result.add("ABC12355");

		Mockito.when(namedParameterJdbcTemplate.queryForList(Mockito.anyString(),
                Mockito.anyMap(),
                Mockito.any())).thenReturn(result);
		
		final List<String> provGrpList = paLandingPageRepositoryImpl.getAffectedProvGrpList(2021, "2022-04-13 21:19:15",
				"2022-04-13 21:19:1", JobName.RUN_QUALITY_AGGREGATION.getValue());

		assert provGrpList.size() == 1;
	}
	
	@Test
	public void getRecordCountModifiedByPrvGrpsModTest() {
		HashMap<String, Object> params = new HashMap<>();
		List<String> prvGrpList = new ArrayList<String>();
		prvGrpList.add("TestProvGrpId01");
		params.put("ProgramYear", 2021);
		Mockito.when(namedParameterJdbcTemplate.queryForObject(Mockito.anyString(), Mockito.any(HashMap.class),
				Mockito.any(Class.class))).thenReturn(10l);

		final Long recordCount = paLandingPageRepositoryImpl.getRecordCountModifiedByPrvGrps(
				JobName.RUN_QUALITY_AGGREGATION.getValue(), GroupsToExecute.MODIFIED.getValue(), 2021, "2022-04-13 21:19:15", "2022-04-12 21:19:15");

		assert recordCount == 10;
	}
	
	@Test
	public void getRecordCountModifiedByPrvGrpsAllTest() {
		HashMap<String, Object> params = new HashMap<>();
		List<String> prvGrpList = new ArrayList<String>();
		prvGrpList.add("TestProvGrpId01");
		params.put("ProgramYear", 2021);
		Mockito.when(namedParameterJdbcTemplate.queryForObject(Mockito.anyString(), Mockito.any(HashMap.class),
				Mockito.any(Class.class))).thenReturn(100l);

	
		final Long recordCount = paLandingPageRepositoryImpl.getRecordCountModifiedByPrvGrps(
				JobName.RUN_QUALITY_AGGREGATION.getValue(), GroupsToExecute.ALL.getValue(), 2021, "2022-04-13 21:19:15", "2022-04-12 21:19:15");

		assert recordCount == 100;
	}
	
	@Test
	public void markedRecordsAsDirtyAllTest() {
	
		List<String> prvGrpList = new ArrayList<String>();
		prvGrpList.add("TestProvGrpId01");
	
		Mockito.when(
				namedParameterJdbcTemplate.update(Mockito.anyString(), Mockito.any(HashMap.class)))
				.thenReturn(10);

		final Integer updatedCount = paLandingPageRepositoryImpl.markedRecordsAsDirty(
				JobName.RUN_QUALITY_AGGREGATION.getValue(), GroupsToExecute.ALL.getValue(), 2021, "2022-04-13 21:19:15", "2022-04-12 21:19:15");
		assert updatedCount == 10;
	}
	
	@Test
	public void markedRecordsAsDirtyModTest() {

		List<String> prvGrpList = new ArrayList<String>();
		prvGrpList.add("TestProvGrpId01");
	
		Mockito.when(
				namedParameterJdbcTemplate.update(Mockito.anyString(), Mockito.any(HashMap.class)))
				.thenReturn(5);

		final Integer updatedCount = paLandingPageRepositoryImpl.markedRecordsAsDirty(
				JobName.RUN_QUALITY_AGGREGATION.getValue(), GroupsToExecute.MODIFIED.getValue(), 2021, "2022-04-13 21:19:15", "2022-04-12 21:19:15");
		assert updatedCount == 5;
	}
	
	@Test
	public void inActivateDirtyRecordsModTest() {

		List<String> prvGrpList = new ArrayList<String>();
		prvGrpList.add("TestProvGrpId01");
	
		Mockito.when(
				namedParameterJdbcTemplate.update(Mockito.anyString(), Mockito.any(HashMap.class)))
				.thenReturn(5);

		final Integer updatedCount = paLandingPageRepositoryImpl.inActivateDirtyRecords(
				JobName.RUN_QUALITY_AGGREGATION.getValue(), GroupsToExecute.MODIFIED.getValue(), 2021, "2022-04-13 21:19:15", "2022-04-12 21:19:15");

		assert updatedCount == 5;
	}
	
	@Test
	public void inActivateDirtyRecordsAllTest() {

		List<String> prvGrpList = new ArrayList<String>();
		prvGrpList.add("TestProvGrpId01");

		Mockito.when(
				namedParameterJdbcTemplate.update(Mockito.anyString(), Mockito.any(HashMap.class)))
				.thenReturn(10);

		final Integer updatedCount = paLandingPageRepositoryImpl.inActivateDirtyRecords(
				JobName.RUN_QUALITY_AGGREGATION.getValue(), GroupsToExecute.ALL.getValue(), 2021, "2022-04-13 21:19:15", "2022-04-12 21:19:15");

		assert updatedCount == 10;
	}
}
