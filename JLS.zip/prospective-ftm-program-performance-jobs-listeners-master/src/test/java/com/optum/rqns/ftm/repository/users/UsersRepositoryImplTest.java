package com.optum.rqns.ftm.repository.users;

import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        UsersRepositoryImpl.class
})
@SpringBootTest(properties = {
        "spring.db_connection_thread_pool_size=10",
})
public class UsersRepositoryImplTest {

    @MockBean
    NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @InjectMocks
    UsersRepositoryImpl usersRepository;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void getUsersByRole() {


        final List<Object> usersList = Arrays.asList("User1", "User2");

        Mockito.when(namedParameterJdbcTemplate.queryForList(
                Mockito.anyString(),
                Mockito.anyMap(),
                Mockito.any()
        )).thenReturn(usersList);

        final List<String> usersByRole = usersRepository.getUsersByRole(Arrays.asList("HCA", "PSC"));

        assert (usersList.equals(usersByRole));

    }

    @Test
    public void getIcReporters() {


        final List<Object> usersList = Arrays.asList("User1", "User2");

        Mockito.when(namedParameterJdbcTemplate.queryForList(
                Mockito.anyString(),
                Mockito.anyMap(),
                Mockito.any()
        )).thenReturn(usersList);

        final List<String> leaderReporters = usersRepository.getIcReporters("Leader");

        assert (usersList.equals(leaderReporters));
    }
}