package com.optum.rqns.ftm.repository.providergroup;

import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.model.providergroup.MemberAssessmentHistory;
import com.optum.rqns.ftm.model.providergroup.ProviderGroup;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;

@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        NewProviderGroupRuleRepositoryImpl.class
})
public class NewProviderGroupRuleRepositoryImplTest {

    @MockBean
    NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @MockBean
    ResultSet resultSet;

    @InjectMocks
    NewProviderGroupRuleRepositoryImpl repository;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        repository = new NewProviderGroupRuleRepositoryImpl(this.namedParameterJdbcTemplate);
    }

    @Test
    public void processGetProviderGroupDetails() {
        String query  = "SELECT PG.ProviderGroupId, PG.State, PG.IsNewForDeployment, PG.EligiblePreferredMembers, PG.ProgramYear as programYear, " +
                "PG.IsNewForPOC as IsNewForPOC FROM ProgPerf.ProviderGroupExtended PG " +
                "WHERE PG.ProgramYear = (select mc.value from ProgPerf.MasterConfiguration mc WITH (NOLOCK) where mc.code='CurrentProgramYear')";

        List<ProviderGroup> result = new ArrayList<>();

        Mockito.when(namedParameterJdbcTemplate.query(query, new BeanPropertyRowMapper<>(ProviderGroup.class)))
                .thenReturn(result);

        List<ProviderGroup> recordCount = repository.getProviderGroupDetails(2022);

        assert recordCount.size() == 0;
    }

    @Test
    public void processGetMemberAssessmentHistoryDetails() {
        String query  = "SELECT prov_group_id, providerstate, overall_status, project_year, deriveddeployed, returned from ProgPerf.MemberAssessmentHistory " +
                "WHERE prov_group_id in ('PG1') " +
                "AND project_year = ((select mc.value from ProgPerf.MasterConfiguration mc WITH (NOLOCK) where mc.code='CurrentProgramYear') - 1)";

        List<MemberAssessmentHistory> result = new ArrayList<>();

        Mockito.when(namedParameterJdbcTemplate.query(query, new BeanPropertyRowMapper<>(MemberAssessmentHistory.class)))
                .thenReturn(result);

        List<MemberAssessmentHistory> recordCount = repository.getMemberAssessmentHistoryDetails("PG1", 2022);

        assert recordCount.size() == 0;
    }

    @Test
    public void processGetMemberAssessmentHistoryDetailsBasedOnLastJobRunDate() {
        String query  = "SELECT prov_group_id, providerstate, overall_status, project_year, deriveddeployed, returned " +
                "FROM ProgPerf.MemberAssessmentHistory " +
                "WHERE CAST(UpdatedDate as DATE) >= (select CAST(LastSuccessfulRunDate as DATE) " +
                "FROM ProgPerf.JobRunConfiguration where JobName = '" + JobName.RUN_NEW_PROVIDER_GROUP_RULES.getValue() + "') " +
                "AND project_year = ((select mc.value from ProgPerf.MasterConfiguration mc WITH (NOLOCK) where mc.code='CurrentProgramYear') - 1)";

        List<MemberAssessmentHistory> result = new ArrayList<>();

        Mockito.when(namedParameterJdbcTemplate.query(query, new BeanPropertyRowMapper<>(MemberAssessmentHistory.class)))
                .thenReturn(result);

        List<MemberAssessmentHistory> recordCount = repository.getMemberAssessmentHistoryDetailsBasedOnLastJobRunDate(2022);

        assert recordCount.size() == 0;
    }

    @Test
    public void processGetProviderGroupDetailsBasedOnProviderGroups() {
        String query  =  "SELECT PG.ProviderGroupId, PG.State, PG.IsNewForDeployment, PG.EligiblePreferredMembers, PG.ProgramYear as programYear, " +
                "PG.IsNewForPOC as IsNewForPOC FROM ProgPerf.ProviderGroupExtended PG " +
                "WHERE PG.ProviderGroupId in (%s) AND PG.ProgramYear = (select mc.value from ProgPerf.MasterConfiguration mc WITH (NOLOCK) WHERE mc.code='CurrentProgramYear')";

        List<ProviderGroup> result = new ArrayList<>();

        Mockito.when(namedParameterJdbcTemplate.query(query, new BeanPropertyRowMapper<>(ProviderGroup.class)))
                .thenReturn(result);

        List<ProviderGroup> recordCount = repository.getProviderGroupDetailsBasedOnProviderGroups("PG1", 2022, true);

        assert recordCount.size() == 0;
    }

    @Test
    public void processupdateBatchQueries() {
        List<Map<String, Object>> batchValues = new ArrayList<>();
        Map<String, Object> map = new HashMap<>();
        map.put("ProgramYear", "2021");
        map.put("ProviderGroupId", "PG1");
        map.put("IsNewForDeployment", "1");
        map.put("state","MN");
        map.put("UpdatedBy","NewProviderGroupRulesJob");

        String query = "UPDATE ProgPerf.ProviderGroup SET " +
                "IsNewForDeployment = :IsNewForDeployment, " +
                "UpdatedBy = :UpdatedBy, " +
                "UpdatedDate = GETUTCDATE() " +
                "WHERE ProviderGroupId = :ProviderGroupId AND state = :State";

        Mockito.when(namedParameterJdbcTemplate.batchUpdate(query, batchValues.toArray(new Map[batchValues.size()])))
                .thenReturn(new int[0]);

        int[]recordCount = repository.updateBatchQueries(batchValues);

        assertEquals(null, recordCount);
    }


    @Test
    public void updateIsEligiblePOCTest() {
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(),Mockito.anyMap())).thenReturn(2);
        int result= repository.updateIsGroupEligiblePOC(true,2021,10,20);
        assertEquals(result,2);
        int result1= repository.updateIsGroupEligiblePOC(false,2021,20,30);
        assertEquals(result1,2);


    }
    @Test
    public void updatedCommandCenterAggregatesTest() {
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(),Mockito.anyMap())).thenReturn(2);
        int result= repository.updateCommandCenterPerformanceAggregates(2022);
        assertEquals(result,0);

    }

    @Test
    public void getMemberAssessmentHistoryDetailsBasedOnLastJobRunDateRecordCountTest() {
        try {
            // Based on LastSuccessfulRunDate
            String MEMBER_ASSESSMENT_HISTORY_LAST_RUN_DATE_COMMON_QUERY = " FROM ProgPerf.MemberAssessmentHistory WITH (NOLOCK) " +
                    "WHERE CAST(UpdatedDate as DATE) >= (select CAST(LastSuccessfulRunDate as DATE) " +
                    "FROM ProgPerf.JobRunConfiguration where JobName = '" +JobName.RUN_NEW_PROVIDER_GROUP_RULES.getValue() + "') " +
                    "AND project_year = (:ProgramYear - 1)";

            String MEMBER_ASSESSMENT_HISTORY_PROVIDER_GROUP_COMMON_QUERY = "SELECT prov_group_id " + MEMBER_ASSESSMENT_HISTORY_LAST_RUN_DATE_COMMON_QUERY + " GROUP BY [prov_group_id]";

            //Count query
            String query = "SELECT count(*) AS totalCount FROM ("
                    + MEMBER_ASSESSMENT_HISTORY_PROVIDER_GROUP_COMMON_QUERY
                    + ") AS LastJobCountNewPGRule";

            SqlParameterSource sqlParameterSource = new MapSqlParameterSource("ProgramYear", 2022);

            Mockito.when(namedParameterJdbcTemplate.queryForObject(query,sqlParameterSource,Long.class))
                    .thenReturn(20l);
            long result = repository.getMemberAssessmentHistoryDetailsBasedOnLastJobRunDateRecordCount(2022);
            assertEquals(result, 2l);
        }catch (Exception e){}
    }

    @Test
    public void getProviderGroupsRecordCountTest() {
        try {
            // Based on LastSuccessfulRunDate
            //Count query
            String query = "select count(*) AS totalCount from ProgPerf.ProviderGroupExtended WITH (NOLOCK) " +
                    "WHERE ProgramYear = %s %s";

            Mockito.when(namedParameterJdbcTemplate.queryForObject(query,new HashMap<>(),Long.class))
                    .thenReturn(20l);
            long result = repository.getProviderGroupsRecordCount(true,2022);
            assertEquals(result, 2l);
        }catch (Exception e){}
    }

    @Test
    public void getRowCountforIsEligiblePOClist() {
        List<Integer> list = repository.getRowCountforIsEligiblePOClist(1000);
        Assert.assertNotNull(list);
    }

    @Test
    public void getProviderGroupDetailsByOffset(){
        List<ProviderGroup> result = new ArrayList<>();
        final String PROVIDER_GROUP_OFFSET_QUERY = "SELECT PG.ProviderGroupId, PG.State, PG.IsNewForDeployment, PG.EligiblePreferredMembers, PG.ProgramYear as programYear, " +
                "PG.IsNewForPOC as IsNewForPOC FROM ProgPerf.ProviderGroupExtended PG WITH (NOLOCK) " +
                "WHERE PG.ProgramYear = (select mc.value from ProgPerf.MasterConfiguration mc WITH (NOLOCK) where mc.code='CurrentProgramYear') " +
                "ORDER BY [ProviderGroupId] "+
                "OFFSET :OFFSET ROWS FETCH NEXT :BATCHSIZE ROWS ONLY";
        SqlParameterSource sqlParameterSource = new MapSqlParameterSource("BATCHSIZE", 1).addValue("OFFSET", 1);;
        Mockito.when(namedParameterJdbcTemplate.query(PROVIDER_GROUP_OFFSET_QUERY, sqlParameterSource,new BeanPropertyRowMapper<>(ProviderGroup.class))).thenReturn(result);
        List<ProviderGroup> recordCount = repository.getProviderGroupDetailsByOffset(Constants.NEW_PROVIDER_GROUP_RULE_BATCH_SIZE, 1, true, 2022);

        assert recordCount.size() == 0;
    }

    @Test
    public void getMemberAssessmentHistoryProviderGroupsBasedOnLastRunDate(){
        final String MEMBER_ASSESSMENT_HISTORY_LAST_RUN_DATE_PROVIDERGROUP_QUERY =  "";
        List<MemberAssessmentHistory> result = new ArrayList<>();
        SqlParameterSource sqlParameterSource = new MapSqlParameterSource("BATCHSIZE", 1).addValue("OFFSET", 1);;
        Mockito.when(namedParameterJdbcTemplate.query(MEMBER_ASSESSMENT_HISTORY_LAST_RUN_DATE_PROVIDERGROUP_QUERY, sqlParameterSource,new BeanPropertyRowMapper<>(MemberAssessmentHistory.class))).thenReturn(result);
        List<MemberAssessmentHistory> recordCount = repository.getMemberAssessmentHistoryProviderGroupsBasedOnLastRunDate(1,1, 2022);

        assert recordCount.size() == 0;

    }

    @Test
    public void getMemberAssessmentHistoryDetailsBasedOnLastJobRunDateRecordsByOffset(){
        final String MEMBER_ASSESSMENT_HISTORY_LAST_RUN_DATE_PROVIDERGROUP_QUERY =  "";
        List<MemberAssessmentHistory> result = new ArrayList<>();
        SqlParameterSource sqlParameterSource = new MapSqlParameterSource("BATCHSIZE", 1).addValue("OFFSET", 1);;
        Mockito.when(namedParameterJdbcTemplate.query("",new BeanPropertyRowMapper<>(MemberAssessmentHistory.class))).thenReturn(result);
        List<MemberAssessmentHistory> recordCount = repository.getMemberAssessmentHistoryDetailsBasedOnLastJobRunDateRecordsByOffset("abc", 2022);

        assert recordCount.size() == 0;

    }


}