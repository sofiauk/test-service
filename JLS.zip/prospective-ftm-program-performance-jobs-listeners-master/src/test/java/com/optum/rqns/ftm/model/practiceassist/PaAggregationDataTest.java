package com.optum.rqns.ftm.model.practiceassist;

import static org.junit.Assert.assertEquals;

import java.time.LocalDateTime;

import org.junit.Test;

import com.optum.rqns.ftm.util.GetterSetterTester;

public class PaAggregationDataTest extends GetterSetterTester<PaAggregationData> {
	@Override
	public PaAggregationData getTestInstance() {
		return new PaAggregationData();

	}

	@Test
    public void testPaAggregationData(){


    	PaAggregationData paAggregationData= PaAggregationData.builder().programYear(2021)
    			.a1CCount(0).clientId("clientId").createdBy("createdBy").healthSystemId("6")
    			.latestUpdatedDate(LocalDateTime.now()).memberOpportunityCount(1)
    			.newPatient30Count(1).omwCount(10).providerGroupId("providerGroupId")
    			.providerId("providerId").providerState("AZ").subClientSk(6)
    			.returnActionNeededCount(100).updatedBy("updatedBy").notAssessedCount(1).   			
    			build();
       
        
        assertEquals("providerGroupId", paAggregationData.getProviderGroupId());
        assertEquals("clientId", paAggregationData.getClientId());
        assertEquals("6", paAggregationData.getHealthSystemId());
        assertEquals(2021, paAggregationData.getProgramYear());
        assertEquals("providerId", paAggregationData.getProviderId()); 
        assertEquals(6, paAggregationData.getSubClientSk());
        assertEquals(1, paAggregationData.getMemberOpportunityCount());
        assertEquals(1, paAggregationData.getNewPatient30Count());
        assertEquals(100, paAggregationData.getReturnActionNeededCount());
        assertEquals("updatedBy", paAggregationData.getUpdatedBy());
        assertEquals(1, paAggregationData.getNotAssessedCount());
        
       
    }

}
