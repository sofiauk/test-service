package com.optum.rqns.ftm.model;

import com.optum.rqns.ftm.util.GetterSetterTester;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class JobStatusTest extends GetterSetterTester<JobStatus> {

    @Override
    public JobStatus getTestInstance() {
        return new JobStatus();
    }

    @Test
    public void TestConfig() {
        assertNotNull(getTestInstance());
    }

    @Test
    public void testJobStatus(){

        Long l = 0L;
        JobStatus jobStatus = new JobStatus();
        jobStatus.setMessage("test");
        assertEquals("test", jobStatus.getMessage());
    }
}