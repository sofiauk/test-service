package com.optum.rqns.ftm.repository.fieldactionrules;


import com.optum.rqns.ftm.model.fieldactionrules.ChangeServiceAction;
import com.optum.rqns.ftm.model.fieldactionrules.RuleAction;
import com.optum.rqns.ftm.repository.common.CommonRepositoryImpl;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;


@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        ChangeServiceLevelRuleRepositoryImpl.class
})
public class ChangeServiceLevelRuleRepositoryTest {

    @MockBean
    NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @MockBean
    ResultSet resultSet;

    @InjectMocks
    ChangeServiceLevelRuleRepositoryImpl repository;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
            }

    @Test
    public void getProviderDetailsTest() {
        List<RuleAction> list= repository.getProvidersWithChangeServiceLevel(2,2);
        Assert.assertNotNull(list);

    }

    @Test
    public void getAccountDetailsCount() {
        List<Integer> list= repository.getRowCountforChangeServiceLevel(1000);
        Assert.assertNotNull(list);

    }
    @Test
    public void testMapper() throws SQLException {
        ChangeServiceLevelRuleRepositoryImpl.ChangeServiceRuleActionMapper mapper= new ChangeServiceLevelRuleRepositoryImpl.ChangeServiceRuleActionMapper();
       ChangeServiceAction action= mapper.mapRow(resultSet,1);
       Assert.assertNotNull(action);
    }



}