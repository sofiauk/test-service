package com.optum.rqns.ftm.model.fieldactionrules;

import com.optum.rqns.ftm.util.GetterSetterTester;
import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;

public class JobSequenceTest extends GetterSetterTester<JobSequence> {

    ArrayList<JobDetails> list = new ArrayList<>();

    @Override
    public JobSequence getTestInstance() {

        JobDetails jobDetails = new JobDetails();
        list.add(jobDetails);
        return new JobSequence(list);
    }
    @Test
    public void getJobSequence(){
        JobSequence jobSequence = this.getTestInstance();
        Assert.assertNotNull(jobSequence);
        Assert.assertEquals(jobSequence.getCascadedJobs(),list);
    }

    @Test
    public void testNonParameterizedConstructor(){
        JobSequence jobSequence = new JobSequence();
        Assert.assertNull(jobSequence.getCascadedJobs());
    }
}
