package com.optum.rqns.ftm.service;


import com.optum.rqns.ftm.enums.ExecutionWeek;
import com.optum.rqns.ftm.enums.GroupsToExecute;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.producer.JobEventProducer;
import com.optum.rqns.ftm.kafka.producer.KeyBasedProviderSyncProducer;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.model.providergroup.PAFXMemberData;
import com.optum.rqns.ftm.model.providergroup.ProviderGroup;
import com.optum.rqns.ftm.repository.CPGEligibleProgramTypeUpdatesRepository;
import com.optum.rqns.ftm.repository.common.CommonRepository;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.util.DateUtil;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        CPGEligibleProgramTypeUpdatesServiceImpl.class
})
@SpringBootTest(properties = {
        "spring.db_connection_thread_pool_size=10",
})
public class CPGEligibleProgramTypeUpdatesServiceImplTest {

    @MockBean
    private CPGEligibleProgramTypeUpdatesRepository cpgEligibleProgramTypeUpdatesRepository;

    @InjectMocks
    private CPGEligibleProgramTypeUpdatesServiceImpl cpgEligibleProgramTypeUpdatesServiceImpl ;

    @MockBean
    private KeyBasedProviderSyncProducer producer;

    @MockBean
    private CommonRepository commonRepository;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }
    @MockBean
    private JobEventProducer jobEventProducer;

    @Test
    public void executeJob() {
        ReflectionTestUtils.setField(cpgEligibleProgramTypeUpdatesServiceImpl, "producerThreadPoolSize", 1);

        Mockito.when(commonRepository.getJobsLastRunSuccessfulDate(JobName.RUN_PAFX_MEMBER_DEPLOYMENT_UPDATES.name())).thenReturn(DateUtil.now().toString());
        Mockito.when(cpgEligibleProgramTypeUpdatesRepository.getPafxMembersForCurrentProgramYearRecordCount(2021, "ALL", DateUtil.now().toString())).thenReturn(25000l);

        Mockito.when(cpgEligibleProgramTypeUpdatesRepository.mergeMemberAssessmentData(25000,0, 2021,"ALL", DateUtil.now().toString()))
                .thenReturn(10);
        Mockito.when(cpgEligibleProgramTypeUpdatesRepository.mergeMemberAssessmentData(25000,25000, 2021,"ALL", DateUtil.now().toString()))
                .thenReturn(10);
        Mockito.when(cpgEligibleProgramTypeUpdatesRepository.mergeMemberGapData(25000,25000, 2021,"ALL", DateUtil.now().toString()))
                .thenReturn(10);

        Mockito.when(cpgEligibleProgramTypeUpdatesRepository.getPafxGroupsRecordCount(2021,"ALL", DateUtil.now().toString()))
                .thenReturn(9000l);

        List<PAFXMemberData> pafxMemberDataList = new ArrayList<>();
        PAFXMemberData pafxMemberData = new PAFXMemberData();
        pafxMemberData.setProviderGroupId("PG1");
        pafxMemberData.setProviderState("NY");
        pafxMemberData.setProgramYear(2021);
        pafxMemberData.setEligibleProgType("IOA,CGAP");

        PAFXMemberData pafxMemberData1 = new PAFXMemberData();
        pafxMemberData1.setProviderGroupId("PG2");
        pafxMemberData1.setProviderState("NY");
        pafxMemberData1.setProgramYear(2021);
        pafxMemberData1.setEligibleProgType("IOA,CGAP,FLA");

        pafxMemberDataList.add(pafxMemberData);
        pafxMemberDataList.add(pafxMemberData1);

        Mockito.when(cpgEligibleProgramTypeUpdatesRepository.getPafxProviderGroupIds(10000,0, 2021, "ALL", DateUtil.now().toString()))
                .thenReturn(pafxMemberDataList);
        Mockito.when(cpgEligibleProgramTypeUpdatesRepository.getPafxMembersProgramTypeBasedOnGroups("'PG1','PG2'", 2021))
                .thenReturn(pafxMemberDataList);

        List<ProviderGroup> providerGroupsWithEligibleProgramTypes = new ArrayList<>();
        ProviderGroup providerGroup = new ProviderGroup();
        providerGroup.setProviderGroupId("PG1");
        providerGroup.setState("NY");
        providerGroup.setProgramYear(2021);
        providerGroup.setEligibleProgramType("IOA");
        providerGroupsWithEligibleProgramTypes.add(providerGroup);

        Mockito.when(cpgEligibleProgramTypeUpdatesRepository.getProviderGroupExtendedRecords("'PG1','PG2'", 2021))
                .thenReturn(providerGroupsWithEligibleProgramTypes);

        Mockito.when(cpgEligibleProgramTypeUpdatesRepository.updateBatchQueries(Mockito.anyList())).thenReturn(new int[1]);

        JobEvent jobEvent = JobEvent.newBuilder().setProgramYear(2021).setJobName(JobName.RUN_PAFX_MEMBER_DEPLOYMENT_UPDATES.getValue())
                .setGroupsToExecute(GroupsToExecute.ALL.getValue())
                .setExecutionWeek(ExecutionWeek.ALL.getValue()).setStatus(Status.IN_PROGRESS.getValue())
                .setTimeStamp(Instant.now()).setCascadeEvents(true).build();
        final JobStatus jobStatus = cpgEligibleProgramTypeUpdatesServiceImpl.executeJob(jobEvent);

        assert jobStatus.getUpdatedRows() == 0;
    }

    private JobEvent getJobEvent(){
        JobEvent jobEvent = new JobEvent();
        jobEvent.setProgramYear(2020);
        jobEvent.setJobName(JobName.RUN_ELIGIBLE_MEMBER_COUNT.getValue());
        jobEvent.setExecutionWeek("Current");
        jobEvent.setGroupsToExecute("All");
        jobEvent.setTimeStamp(Instant.now());
        jobEvent.setStatus("Complete");
        jobEvent.setCascadeEvents(true);

        return jobEvent;
    }
    @Test
    public void executeJobException() {
        ReflectionTestUtils.setField(cpgEligibleProgramTypeUpdatesServiceImpl, "producerThreadPoolSize", 1);

        Mockito.when(cpgEligibleProgramTypeUpdatesRepository.getPafxMembersForCurrentProgramYearRecordCount(2021, "ALL", DateUtil.now().toString())).thenThrow(new NullPointerException());

        JobEvent jobEventinput = JobEvent.newBuilder().setJobName(JobName.RUN_PAFX_MEMBER_DEPLOYMENT_UPDATES.getValue())
                .setProgramYear(2021)
                .setGroupsToExecute(GroupsToExecute.MODIFIED.getValue())
                .setExecutionWeek(ExecutionWeek.ALL.getValue()).setStatus(Status.IN_PROGRESS.getValue())
                .setTimeStamp(Instant.now()).setCascadeEvents(true).build();

        Mockito.when(jobEventProducer.postToKafka(getJobEvent())).thenReturn(true);

        JobEvent jobEvent = JobEvent.newBuilder().setJobName(JobName.IDM_GLIDEPATH.getValue())
                .setGroupsToExecute(GroupsToExecute.MODIFIED.getValue())
                .setExecutionWeek(ExecutionWeek.ALL.getValue()).setStatus(Status.IN_PROGRESS.getValue())
                .setTimeStamp(Instant.now()).setCascadeEvents(true).build();
        final JobStatus jobStatus = cpgEligibleProgramTypeUpdatesServiceImpl.executeJob(jobEvent);

        assert Status.SUCCESS == jobStatus.getStatus();
        assert 0 == jobStatus.getUpdatedRows();
    }


}
