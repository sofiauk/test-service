package com.optum.rqns.ftm.enums;

import org.junit.Assert;
import org.junit.Test;

import java.time.LocalDateTime;
import java.util.HashMap;


public class DmnPayloadTest {

    @Test
    public void testDmnPayload(){

        DmnPayload dmnPayload = new DmnPayload("test","test", new HashMap<String, Object>());
        dmnPayload.builder();
        Assert.assertEquals("test", dmnPayload.getModelName());
        Assert.assertEquals("test", dmnPayload.getModelNamespace());
        Assert.assertNotNull(dmnPayload.getDmnContext());
    }

    @Test
    public void testNonParameterizedConstructor(){
        DmnPayload dmnPayload = new DmnPayload();
        Assert.assertNull(dmnPayload.getModelName());
    }

}
