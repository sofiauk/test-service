package com.optum.rqns.ftm.service.landingpage;

import com.optum.rqns.ftm.enums.ExecutionWeek;
import com.optum.rqns.ftm.enums.GroupsToExecute;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.producer.JobEventProducer;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.repository.landingpage.LeaderPerformanceRepository;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.time.Instant;

@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        EModalityLoadService.class
})
@SpringBootTest(properties = {
        "spring.db_connection_thread_pool_size=10",
})
public class EModalityLoadServiceTest {
    @MockBean
    private LeaderPerformanceRepository leaderPerformanceRepository;
    @MockBean
    private JobEventProducer jobEventProducer;
    @InjectMocks
    private EModalityLoadServiceImpl eModalityLoadService;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void executeJob() {

        Mockito.when(leaderPerformanceRepository.loadDataToEModalityFromMemberAssessments(Mockito.anyInt()))
                .thenReturn(20l);


        Mockito.when(jobEventProducer.postToKafka(getJobEvent())).thenReturn(true);

        JobEvent jobEvent = JobEvent.newBuilder().setProgramYear(2021).setJobName(JobName.RUN_COMMAND_CENTER.getValue())
                .setGroupsToExecute(GroupsToExecute.MODIFIED.getValue())
                .setExecutionWeek(ExecutionWeek.ALL.getValue()).setStatus(Status.IN_PROGRESS.getValue())
                .setTimeStamp(Instant.now()).setCascadeEvents(true).build();
        final JobStatus jobStatus = eModalityLoadService.executeJob(jobEvent);
        assert jobStatus.getUpdatedRows() == 20;
    }

    @Test
    public void executeJobException() {
        Mockito.when(leaderPerformanceRepository.loadDataToEModalityFromMemberAssessments(Mockito.anyInt()))
                .thenThrow(new NullPointerException());

        Mockito.when(jobEventProducer.postToKafka(getJobEvent())).thenReturn(true);

        JobEvent jobEvent = JobEvent.newBuilder().setProgramYear(2021).setJobName(JobName.RUN_COMMAND_CENTER.getValue())
                .setGroupsToExecute(GroupsToExecute.MODIFIED.getValue())
                .setExecutionWeek(ExecutionWeek.ALL.getValue()).setStatus(Status.IN_PROGRESS.getValue())
                .setTimeStamp(Instant.now()).setCascadeEvents(true).build();
        final JobStatus jobStatus = eModalityLoadService.executeJob(jobEvent);
        assert Status.FAILURE == jobStatus.getStatus();
        assert 0 == jobStatus.getUpdatedRows();
    }


    private JobEvent getJobEvent() {
        JobEvent jobEvent = new JobEvent();
        jobEvent.setProgramYear(2020);
        jobEvent.setJobName("RunWeeklyEModalityLoad");
        jobEvent.setExecutionWeek("Current");
        jobEvent.setGroupsToExecute("All");
        jobEvent.setTimeStamp(Instant.now());
        jobEvent.setStatus("Complete");
        jobEvent.setCascadeEvents(true);

        return jobEvent;
    }
}
