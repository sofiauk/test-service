package com.optum.rqns.ftm.model.fieldactionrules;

import com.optum.rqns.ftm.util.GetterSetterTester;
import org.junit.Assert;
import org.junit.Test;

public class JobDetailsTest extends GetterSetterTester<JobDetails> {

    @Override
    public JobDetails getTestInstance() {
        return new JobDetails("test",false, "true");
    }
    @Test
    public void getJobDetails(){
        JobDetails jobDetails= JobDetails.builder().jobName("test").triggerOnError(false).build();
        Assert.assertNotNull(jobDetails);
        Assert.assertEquals(jobDetails.getJobName(),"test");
    }

    @Test
    public void testNonParameterizedConstructor(){
        JobDetails jobDetails = new JobDetails();
        Assert.assertNull(jobDetails.getJobName());
    }


}
