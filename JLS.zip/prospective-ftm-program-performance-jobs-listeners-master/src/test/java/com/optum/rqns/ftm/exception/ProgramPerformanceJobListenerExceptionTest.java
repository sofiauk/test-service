package com.optum.rqns.ftm.exception;

import org.junit.Assert;
import org.junit.Test;

public class ProgramPerformanceJobListenerExceptionTest {

    @Test
    public void testProgramPerformanceJobListenerException(){
        ProgramPerformanceJobListenerException programPerformanceJobListenerException = new ProgramPerformanceJobListenerException("test");
        Assert.assertNull(programPerformanceJobListenerException.getCustomException());
        Assert.assertNull(programPerformanceJobListenerException.getHttpStatus());
        Assert.assertNotNull(programPerformanceJobListenerException.getApiError());
    }
}
