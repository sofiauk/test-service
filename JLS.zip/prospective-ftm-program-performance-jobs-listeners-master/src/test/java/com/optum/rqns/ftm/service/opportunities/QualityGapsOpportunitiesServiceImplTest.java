package com.optum.rqns.ftm.service.opportunities;


import com.optum.rqns.ftm.repository.opportunities.OpportunitiesCommonRepositoryImpl;
import org.junit.Before;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;


public class QualityGapsOpportunitiesServiceImplTest {


    @Mock
    private OpportunitiesCommonRepositoryImpl opportunitiesCommonRepository;

    @InjectMocks
    private QualityGapsOpportunitiesServiceImpl qualityGapsOpportunitiesService;

    @Before
    public void initMocks() {
        MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(qualityGapsOpportunitiesService, "opportunitiesCommonRepository", opportunitiesCommonRepository);
    }

}
