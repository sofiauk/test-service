package com.optum.rqns.ftm.model.providergroup;

import com.optum.rqns.ftm.util.GetterSetterTester;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class PAFXMemberDataTest extends GetterSetterTester<PAFXMemberData> {
    @Override
    public PAFXMemberData getTestInstance() {
        return  new PAFXMemberData("test","test",1,"test");
    }

    @Test
    public void testPAFXMemberData(){


        PAFXMemberData pafxMemberData = this.getTestInstance();
        pafxMemberData.builder();
        assertEquals("test", pafxMemberData.getProviderGroupId());
        assertEquals(this.getTestInstance().toString(),pafxMemberData.toString());
    }

}
