package com.optum.rqns.ftm.enums;

import org.junit.Assert;
import org.junit.Test;

public class JobNameTest {

    @Test
    public void apiJobNameTest(){
        JobName jobName = JobName.IDM_GLIDEPATH;
        Assert.assertNotNull(jobName.getValue());
        Assert.assertEquals(JobName.valueOf("IDM_GLIDEPATH"), jobName);

        jobName.getPartitionId();
        JobName.fromString("Failure1");

        Assert.assertEquals(JobName.IDM_GLIDEPATH, JobName.fromString("RunIDMGlidepathMergeToProvGroupPerf"));
    }
}
