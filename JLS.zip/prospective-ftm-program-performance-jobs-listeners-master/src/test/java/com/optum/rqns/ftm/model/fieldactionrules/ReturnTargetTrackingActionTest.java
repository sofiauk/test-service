package com.optum.rqns.ftm.model.fieldactionrules;

import com.optum.rqns.ftm.util.GetterSetterTester;
import org.junit.Assert;
import org.junit.Test;

public class ReturnTargetTrackingActionTest extends GetterSetterTester<ReturnTargetTrackingAction> {

    @Override
    public ReturnTargetTrackingAction getTestInstance() {
        return new ReturnTargetTrackingAction(1d,1d);
    }

    @Test
    public void getReturnTargetTrackingAction() {
        ReturnTargetTrackingAction returnTargetTrackingAction = this.getTestInstance();
        Assert.assertNotNull(returnTargetTrackingAction);
        Assert.assertEquals(returnTargetTrackingAction.getReturnCNA(),1d,0d);
    }
}
