//package com.optum.rqns.ftm.repository.opportunities;
//
//import com.optum.rqns.ftm.constants.Constants;
//import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
//import com.optum.rqns.ftm.model.opportunities.OpportunitiesConfiguration;
//import com.optum.rqns.ftm.model.opportunities.OpportunitiesDetails;
//import com.optum.rqns.ftm.model.opportunities.OpportunitiesSummary;
//import lombok.extern.slf4j.Slf4j;
//import org.junit.Assert;
//import org.junit.Before;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mockito;
//import org.mockito.MockitoAnnotations;
//import org.springframework.boot.test.mock.mockito.MockBean;
//import org.springframework.jdbc.core.BeanPropertyRowMapper;
//import org.springframework.jdbc.core.ResultSetExtractor;
//import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
//import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
//import org.springframework.jdbc.core.namedparam.SqlParameterSource;
//import org.springframework.test.context.ActiveProfiles;
//import org.springframework.test.context.ContextConfiguration;
//import org.springframework.test.context.junit4.SpringRunner;
//
//import java.sql.ResultSet;
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.List;
//
//@RunWith(SpringRunner.class)
//@Slf4j
//@ActiveProfiles("test")
//@ContextConfiguration(classes = { OpportunitiesCommonRepositoryImpl.class })
//public class OpportunitiesCommonRepositoryImplTest {
//
//	@MockBean
//	NamedParameterJdbcTemplate namedParameterJdbcTemplate;
//
//	@MockBean
//	ResultSet resultSet;
//
//	@InjectMocks
//	OpportunitiesCommonRepositoryImpl opportunitiesCommonRepoImpl;
//
//	@Before
//	public void init() {
//		MockitoAnnotations.initMocks(this);
//	}
//
//	@Test
//	public void upsertDeploymentOpportunitiesDetails() {
//		int[] count = { 2, 4, 6 };
//		Mockito.when(namedParameterJdbcTemplate.batchUpdate(Mockito.anyString(), (SqlParameterSource[]) Mockito.any()))
//				.thenReturn(count);
//		Mockito.when(namedParameterJdbcTemplate.query(Mockito.anyString(), Mockito.anyMap(),
//				(BeanPropertyRowMapper) Mockito.any())).thenReturn(getOpportunitiesDetails());
//		Mockito.when(namedParameterJdbcTemplate.queryForObject(Mockito.anyString(), Mockito.anyMap(),
//				(BeanPropertyRowMapper) Mockito.any())).thenReturn(new ArrayList<Integer>());
//		Mockito.when(namedParameterJdbcTemplate.queryForObject(Mockito.anyString(), (SqlParameterSource) Mockito.any(),
//				Mockito.eq(Integer.class))).thenReturn(11);
//
//		Integer upsertRows = opportunitiesCommonRepoImpl.upsertOpportunitiesDetails(getOpportunitiesDetails());
//		Assert.assertNotNull(upsertRows);
//		Integer upsertSummaryRows = opportunitiesCommonRepoImpl.upsertOpportunitiesSummary(getOpportunitiesSummary());
//		Assert.assertNotNull(upsertSummaryRows);
//
//		List<OpportunitiesDetails> opportunitiesDetails = opportunitiesCommonRepoImpl.executingOpportunities(
//				getOpportunitiesConfiguration().get(0), JobEvent.newBuilder().setGroupsToExecute("Modified").build(),
//				"test");
//		Assert.assertNotNull(opportunitiesDetails);
//
//		List<OpportunitiesConfiguration> opportunitiesConfList = opportunitiesCommonRepoImpl
//				.fetchOpportunityConfigurationBatchWise(0, 10, Constants.QUALITY_GAPS);
//		Assert.assertNotNull(opportunitiesConfList);
//
//		List<Integer> integerList = opportunitiesCommonRepoImpl.getRowCountForOpportunityBatch(10,
//				Constants.QUALITY_GAPS);
//
//		Assert.assertNotNull(integerList);
//
//	}
//
//	@Test
//	public void fetchOpportunitiesSummary() {
//
//		Mockito.when(namedParameterJdbcTemplate.query(Mockito.anyString(), Mockito.anyMap(),
//				(BeanPropertyRowMapper) Mockito.any())).thenReturn(getOpportunitiesDetails());
//
//		String masterOpportunityName = "AnnualCareOpportunities";
//		List<OpportunitiesSummary> opportunitiesSummaries = opportunitiesCommonRepoImpl
//				.fetchOpportunitiesSummary(masterOpportunityName, Constants.ANNUAL_CARE_VISITS);
//		Assert.assertNotNull(opportunitiesSummaries);
//	}
//
//	@Test
//	public void fetchLastRunDateTest() {
//		Mockito.when(namedParameterJdbcTemplate.query(Mockito.anyString(), Mockito.anyMap(),
//				(ResultSetExtractor) Mockito.any())).thenReturn("Test");
//		String result = opportunitiesCommonRepoImpl.fetchLastRunDate("QualityGaps");
//		Assert.assertNotNull(result);
//	}
//
//	@Test
//	public void fetchOpportunityConfiguration() {
//		OpportunitiesConfiguration opportunitiesConf = OpportunitiesConfiguration.builder()
//				.masterOpportunityName("QualityGaps").build();
//		List<OpportunitiesConfiguration> opportunitiesConfs = new ArrayList<>(Arrays.asList(opportunitiesConf));
//		Mockito.when(namedParameterJdbcTemplate.query(Mockito.anyString(), Mockito.anyMap(),
//				(BeanPropertyRowMapper) Mockito.any())).thenReturn(opportunitiesConfs);
//		List<OpportunitiesConfiguration> result = opportunitiesCommonRepoImpl
//				.fetchOpportunityConfiguration("QualityGaps");
//		Assert.assertNotNull(result);
//	}
//
//	public List<OpportunitiesConfiguration> getOpportunitiesConfiguration() {
//
//		List<OpportunitiesConfiguration> opportunitiesConfs = new ArrayList<>();
//
//		OpportunitiesConfiguration opportunitiesConf = OpportunitiesConfiguration.builder()
//				.whereClauseCondition("MSR_1_BCS_GAP_STS is not null")
//				.selectClauseCondition("MSR_1_BCS_GAP_STS not in (3)").opportunityName("Diabetes Care – Eye Exam")
//				.opportunityDisplayOrder(1).masterOpportunityName(Constants.QUALITY_GAPS).build();
//
//		opportunitiesConfs.add(opportunitiesConf);
//		return opportunitiesConfs;
//	}
//
//	public List<OpportunitiesDetails> getOpportunitiesDetails() {
//
//		List<OpportunitiesDetails> opportunitiesDetailsList = new ArrayList<>();
//		OpportunitiesDetails opportunitiesDetails = OpportunitiesDetails.builder().assessmentCount(1)
//				.clientName("Aetna").deploymentCount(1).displayText("Test").gapCount(1).lobName("Medicare")
//				.masterOpportunityType(Constants.QUALITY_GAPS).masterOpportunityTypePosition(1)
//				.opportunityType("Diabetes Care – Eye Exam").programYear(2021).providerGroupID("3804")
//				.providerGroupName("MERCY CLINIC EAST COMMUNITIES").serviceLevel("ALL").build();
//
//		opportunitiesDetailsList.add(opportunitiesDetails);
//		return opportunitiesDetailsList;
//	}
//
//	public List<OpportunitiesSummary> getOpportunitiesSummary() {
//
//		List<OpportunitiesSummary> opportunitiesSummaryList = new ArrayList<>();
//		OpportunitiesDetails opportunitiesDetails = OpportunitiesDetails.builder().assessmentCount(1)
//				.clientName("Aetna").deploymentCount(1).displayText("Test").gapCount(1).lobName("Medicare")
//				.masterOpportunityType(Constants.QUALITY_GAPS).masterOpportunityTypePosition(1)
//				.opportunityType("Diabetes Care – Eye Exam").programYear(2021).providerGroupID("3804")
//				.providerGroupName("MERCY CLINIC EAST COMMUNITIES").serviceLevel("ALL").build();
//		OpportunitiesSummary opportunitiesSummary = OpportunitiesSummary.builder()
//				.masterLevelOpportunity(Constants.QUALITY_GAPS).masterLevelOpportunityPosition(1).programYear(2021)
//				.providerGroupID("3804").providerGroupName("MERCY CLINIC EAST COMMUNITIES").state("OH")
//				.totalAssessmentsCount(1).totalGapsCount(1).build();
//
//		opportunitiesSummaryList.add(opportunitiesSummary);
//		return opportunitiesSummaryList;
//	}
//
//}
