package com.optum.rqns.ftm.kafka.producer;

import com.optum.rqns.ftm.enums.ExecutionWeek;
import com.optum.rqns.ftm.enums.GroupsToExecute;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.exception.ProgramPerformanceJobListenerException;
import com.optum.rqns.ftm.kafka.avro.models.v1.fieldactionrule.Action;
import com.optum.rqns.ftm.kafka.avro.models.v1.fieldactionrule.FieldActionRuleMetadata;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.model.fieldactionrules.RejectAgingGroupLevelAction;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.KafkaException;
import org.junit.Assert;
import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.kafka.core.KafkaProducerException;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.util.concurrent.ListenableFuture;

import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@SpringBootTest
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        KeyBasedFieldActionRuleProducer.class
})
public class KeyBasedFieldActionRuleProducerTest {

    @BeforeEach
    public void initMocks() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void postToKafka() {
        ListenableFuture<SendResult<String, FieldActionRuleMetadata>> listenableFuture =
                Mockito.mock(ListenableFuture.class);

        KafkaTemplate<String, FieldActionRuleMetadata> kafkaTemplate =
                Mockito.mock(KafkaTemplate.class);


        FieldActionRuleMetadata fieldActionRuleMetadata = getFieldActionRuleMetadata();
        Mockito.doNothing().when(kafkaTemplate).flush();
        Mockito.when(listenableFuture.isDone()).thenReturn(true);
        Mockito.when(kafkaTemplate.send(Mockito.anyString(),Mockito.any(),Mockito.any())).thenReturn(listenableFuture);



        KeyBasedFieldActionRuleProducer jobEventProducer
                = new KeyBasedFieldActionRuleProducer(kafkaTemplate);
        jobEventProducer.topicName = "DataSync.Auth.UserRole";

        boolean result = jobEventProducer.postToKafka(fieldActionRuleMetadata,"Test");

        Assert.assertTrue(result);
    }

    private FieldActionRuleMetadata getFieldActionRuleMetadata() {
        FieldActionRuleMetadata fieldActionRuleMetadata = new FieldActionRuleMetadata();
        Action action=new Action();
        action.setVerifyRuleResult(false);
        fieldActionRuleMetadata.setUsers(Arrays.asList("Test1","Test2"));
        fieldActionRuleMetadata.setAction(action);
        fieldActionRuleMetadata.setRuleType("Test");
        fieldActionRuleMetadata.setRuleResult("Test");
        fieldActionRuleMetadata.setRuleContext("Test");
        return fieldActionRuleMetadata;
    }

    @Test(expected = ProgramPerformanceJobListenerException.class)
    public void postToKafka_KafkaProducerException() {
        ListenableFuture<SendResult<String, FieldActionRuleMetadata>> listenableFuture =
                Mockito.mock(ListenableFuture.class);

        KafkaTemplate<String, FieldActionRuleMetadata> kafkaTemplate =
                Mockito.mock(KafkaTemplate.class);

        FieldActionRuleMetadata fieldActionRuleMetadata = getFieldActionRuleMetadata();

        ProducerRecord producerRecord = new ProducerRecord("test", "test");

        Mockito.doNothing().when(kafkaTemplate).flush();
        Mockito.when(listenableFuture.isDone()).thenReturn(true);
        Mockito.when(kafkaTemplate.send(Mockito.anyString(),Mockito.any(),Mockito.any())).thenThrow(new KafkaProducerException(producerRecord, "test", new NullPointerException()));


        KeyBasedFieldActionRuleProducer jobEventProducer
                = new KeyBasedFieldActionRuleProducer(kafkaTemplate);
        jobEventProducer.topicName = "DataSync.Auth.UserRole";

        boolean result = jobEventProducer.postToKafka(fieldActionRuleMetadata,"Test");
    }

    @Test(expected = ProgramPerformanceJobListenerException.class)
    public void postToKafka_KafkaException() {
        ListenableFuture<SendResult<String, FieldActionRuleMetadata>> listenableFuture =
                Mockito.mock(ListenableFuture.class);

        KafkaTemplate<String, FieldActionRuleMetadata> kafkaTemplate =
                Mockito.mock(KafkaTemplate.class);

        FieldActionRuleMetadata fieldActionRuleMetadata = getFieldActionRuleMetadata();
        Mockito.doNothing().when(kafkaTemplate).flush();
        Mockito.when(listenableFuture.isDone()).thenReturn(true);
        Mockito.when(kafkaTemplate.send(Mockito.anyString(),Mockito.any(),Mockito.any())).thenThrow(new KafkaException("test"));

        KeyBasedFieldActionRuleProducer jobEventProducer
                = new KeyBasedFieldActionRuleProducer(kafkaTemplate);
        jobEventProducer.topicName = "DataSync.Auth.UserRole";

        boolean result = jobEventProducer.postToKafka(fieldActionRuleMetadata,"Test");
    }

    @Test
    public void postToKafka_Exception() {
        ListenableFuture<SendResult<String, FieldActionRuleMetadata>> listenableFuture =
                Mockito.mock(ListenableFuture.class);

        KafkaTemplate<String, FieldActionRuleMetadata> kafkaTemplate =
                Mockito.mock(KafkaTemplate.class);

        FieldActionRuleMetadata fieldActionRuleMetadata = getFieldActionRuleMetadata();

        Mockito.doNothing().when(kafkaTemplate).flush();
        Mockito.when(listenableFuture.isDone()).thenReturn(true);
        Mockito.when(kafkaTemplate.send(Mockito.anyString(),Mockito.any(),Mockito.any())).thenThrow(new NullPointerException("test"));

        KeyBasedFieldActionRuleProducer jobEventProducer
                = new KeyBasedFieldActionRuleProducer(kafkaTemplate);
        jobEventProducer.topicName = "DataSync.Auth.UserRole";

        boolean result = jobEventProducer.postToKafka(fieldActionRuleMetadata,"Test");

        Assert.assertFalse(result);
    }

}
