package com.optum.rqns.ftm.service;


import com.optum.rqns.ftm.configuration.KIEBeanConfiguration;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.model.fieldactionrules.NewProviderManualAssociationAction;
import com.optum.rqns.ftm.model.fieldactionrules.RejectAgingGroupLevelAction;
import com.optum.rqns.ftm.model.fieldactionrules.ReturnTargetTrackingAction;
import com.optum.rqns.ftm.model.fieldactionrules.RuleAction;
import com.optum.rqns.ftm.service.fieldactionrules.KIERuleOrchestrator;
import com.optum.rqns.ftm.service.fieldactionrules.RuleCommandImpl;
import com.optum.rqns.ftm.service.fieldactionrules.ThresholdServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        KIERuleOrchestrator.class,
        KIEBeanConfiguration.class,
        RuleCommandImpl.class,
        ThresholdServiceImpl.class
})
@SpringBootTest(properties = {
        "kie.server.username=wbadmin@123","kie.server.password=ftm@123",
})
public class KIEOrchestratorTest {

    @Autowired
    private KIERuleOrchestrator kieRuleOrchestrator;

    @MockBean
    private RestTemplate restTemplate;

    @MockBean
    private KIERuleOrchestrator kIERuleOrchestrator;

    @MockBean
    private KIEBeanConfiguration kIEBeanConfiguration;

    @MockBean
    private RuleCommandImpl ruleCommandImpl;

    @MockBean
    private ThresholdServiceImpl thresholdServiceImpl;

    @Test
    public void test()  {
        try {
            List<RuleAction> ruleActionList = new ArrayList<>();
            RejectAgingGroupLevelAction inputData = new RejectAgingGroupLevelAction();
            inputData.setSingleRejectDaysCount(200);
            ruleActionList.add(inputData);
            List<RuleAction> responseList =kieRuleOrchestrator.getRulesExecutedData(ruleActionList, JobName.THRESHOLD_RULE.getValue());
            if(!CollectionUtils.isEmpty(responseList)) {
                assert responseList.size() == 1;
            }
        } catch (Exception e){

        }
    }

    @Test
    public void invokeRejectsAgingDMNRuleRestAPIListTest() {

        List<RuleAction> inputList = new ArrayList<>();
        RejectAgingGroupLevelAction inputData = new RejectAgingGroupLevelAction();
        inputData.setSingleRejectDaysCount(200);
        inputList.add(inputData);

        List<RuleAction> responseList = kieRuleOrchestrator.getRulesExecutedData(inputList, JobName.REJECT_AGING_JOB.getValue());

        if(!CollectionUtils.isEmpty(responseList)) {
            assert responseList.size() == 1;
            assert responseList.get(0).getActionType().equalsIgnoreCase("Task");
        }
    }


    @Test
    public void invokeDMNReturnTargetTrackingRuleRestAPIListTest() {

        List<RuleAction> inputList = new ArrayList<>();
        ReturnTargetTrackingAction inputData = new ReturnTargetTrackingAction();
        inputData.setReturnCNA(90.0);
        inputData.setReturnTarget(60.0);

        inputList.add(inputData);

        List<RuleAction> responseList = kieRuleOrchestrator.getRulesExecutedData(inputList, JobName.REJECT_AGING_JOB.getValue());

        if(!CollectionUtils.isEmpty(responseList)) {
            assert responseList.size() == 1;
            assert responseList.get(0).getActionType().equalsIgnoreCase("Task");
        }
    }


    @Test
    public void invokeDMNNewProviderManualAssociationRuleRestAPIListTest() {

        List<RuleAction> inputList = new ArrayList<>();
        NewProviderManualAssociationAction inputData = new NewProviderManualAssociationAction();
        inputData.setEligiblePreferredMemberCount(200);

        inputList.add(inputData);

        List<RuleAction> responseList = kieRuleOrchestrator.getRulesExecutedData(inputList, JobName.NEW_PROVIDER_MANUAL_ASSOCIATION_JOB.getValue());

        if(!CollectionUtils.isEmpty(responseList)) {
            NewProviderManualAssociationAction action =(NewProviderManualAssociationAction)responseList.get(0);

            assert responseList.size() == 1;
            assert responseList.get(0).getActionType().equalsIgnoreCase("Task");
        }
    }
}
