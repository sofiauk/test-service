package com.optum.rqns.ftm.model;

import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.util.GetterSetterTester;
import org.junit.Test;

import java.time.LocalDateTime;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class JobExecutionHistoryTest extends GetterSetterTester<JobExecutionHistory> {

    @Override
    public JobExecutionHistory getTestInstance() {
        return new JobExecutionHistory();
    }

    @Test
    public void TestConfig() {
        assertNotNull(getTestInstance());
    }

    @Test
    public void testJobExecutionHistory(){

        JobExecutionHistory jobExecutionHistory = new JobExecutionHistory(1, 1, Status.SUCCESS, "test", 1, LocalDateTime.now(), LocalDateTime.now(),
                     "test", "test", "test");

        jobExecutionHistory.builder();

        assertEquals(Status.SUCCESS, jobExecutionHistory.getStatus());
        assertEquals("test", jobExecutionHistory.getErrorMessage());
    }
}