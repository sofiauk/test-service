package com.optum.rqns.ftm.configuration;

import com.optum.rqns.ftm.util.GetterSetterTester;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class EnvironmentConfigurationTest extends GetterSetterTester<EnvironmentConfiguration> {

    @Override
    public EnvironmentConfiguration getTestInstance() {
        return new EnvironmentConfiguration();
    }

    @Test
    public void TestConfig() {
        assertNotNull(getTestInstance());
    }

    @Test
    public void testJobAlert(){

        EnvironmentConfiguration environmentConfiguration = new EnvironmentConfiguration();
        environmentConfiguration.setApplicationName("test");

        assertEquals("test", environmentConfiguration.getApplicationName());
    }
}