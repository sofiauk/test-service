package com.optum.rqns.ftm.service.commandcenter;

import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.producer.JobEventProducer;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.repository.commandcenter.CCGrowthRateRepository;
import com.optum.rqns.ftm.repository.commandcenter.CommandCenterRepository;
import lombok.extern.slf4j.Slf4j;
import org.drools.core.command.assertion.AssertEquals;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        CCGrowthRateServiceImpl.class
})
@SpringBootTest(properties = {
        "spring.db_connection_thread_pool_size=10",
})
public class CCGrowthRateServiceImplTest {

    @MockBean
    private CCGrowthRateRepository ccGrowthRateRepository;

    @InjectMocks
    private CCGrowthRateServiceImpl ccGrowthRateService;

    @MockBean
    private JobEventProducer jobEventProducer;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void executeJob() {

        mockDbCalls();

        final JobStatus jobStatus = ccGrowthRateService.executeJob(JobEvent.newBuilder().setJobInput("{\"resetAllFlags\":true}").setProgramYear(2021).build());
        JobStatus mockJobStatus = new JobStatus();
        mockJobStatus.setUpdatedRows(10l);
        mockJobStatus.setStatus(Status.SUCCESS);
        mockJobStatus.setMessage("Flag Reset Count :2\n" +
                "Agreed GrowthRateStatus record updated count by IPE Flag :2\n" +
                "Agreed GrowthRateStatus record updated count by DeployYtdActual :2\n" +
                "Engaged GrowthRateStatus record updated count byDeployYtdActual :2\n" +
                "Calculated AgreedYTD, EngageDYTD, TotalProviderGroups, AgreedYTD%, EngagedYTD %, Updated Count:2"
        );
        Assert.assertEquals(mockJobStatus.getUpdatedRows(),jobStatus.getUpdatedRows());
        Assert.assertEquals(mockJobStatus.getStatus(),jobStatus.getStatus());
        Assert.assertEquals(mockJobStatus.getMessage(),jobStatus.getMessage());

    }

    private void mockDbCalls() {
        Mockito.when(ccGrowthRateRepository.updateAgreedStatusByIPEFlag(Mockito.anyInt()))
                .thenReturn(2);
        Mockito.when(ccGrowthRateRepository.updateAgreedStatusByDeployActual(Mockito.anyInt()))
                .thenReturn(2);
        Mockito.when(ccGrowthRateRepository.updateEngagedStatusByDeployActual(Mockito.anyInt()))
                .thenReturn(2);
        Mockito.when(ccGrowthRateRepository.flagAgreedAndEngagedTo0(Mockito.anyInt()))
                .thenReturn(2);
        Mockito.when(ccGrowthRateRepository.updateMOMGrowthRateTable(Mockito.anyInt()))
                .thenReturn(2);

    }
}