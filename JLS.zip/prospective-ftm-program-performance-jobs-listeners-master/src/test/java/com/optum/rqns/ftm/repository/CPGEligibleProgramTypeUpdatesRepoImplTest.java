package com.optum.rqns.ftm.repository;


import com.optum.rqns.ftm.model.providergroup.PAFXMemberData;
import com.optum.rqns.ftm.model.providergroup.ProviderGroup;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.util.DateUtil;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;

@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        PAFxMemberAssessmentDeploymentUpdatesRepositoryImpl.class
})
@SpringBootTest(properties = {
        "spring.db_connection_thread_pool_size=10",
})
public class CPGEligibleProgramTypeUpdatesRepoImplTest {

    @MockBean
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @InjectMocks
    private CPGEligibleProgramTypeUpdatesRepositoryImpl cpgEligibleProgramTypeUpdatesRepositoryImpl;


    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }




    @Test
    public void getRecordMemberAssessmentCountTest() {
        String query = "SELECT   " +
                "count(*) as totalCount  " +
                "FROM   " +
                "ProgPerf.MemberAssessment with (NOLOCK)";
        Mockito.when(namedParameterJdbcTemplate.queryForObject(query,new HashMap<>(),Long.class))
                .thenReturn(20l);

        final Long recordCount = cpgEligibleProgramTypeUpdatesRepositoryImpl.getRecordMemberAssessmentCount();


        assert recordCount == 20;
    }


    @Test
    public void mergeMemberAssessmentDataTest() throws Exception {

        String MEMBER_ASSESSMENT_MERGE_QUERY = "MERGE ProgPerf.[MemberAssessment] AS tgt" +
                "       USING (" +
                "            SELECT EligibleProgramType, CPG, ClientId, LobName, ProviderGroupId, [ProviderState], ProgramYear, GlobalMemberId" +
                "             FROM ProgPerf.[PafExMemberAssessment] " +
                "             WHERE ProgramYear = (select mc.value from ProgPerf.MasterConfiguration mc WITH (NOLOCK) where mc.code='CurrentProgramYear')" +
                "             ORDER BY [ID] OFFSET :OFFSET ROWS FETCH NEXT :BATCHSIZE ROWS ONLY" +
                "             ) AS src" +
                "             ON (" +
                "                           tgt.clientid = src.ClientId" +
                "                           AND tgt.lob2 = src.LobName" +
                "                           AND tgt.prov_group_id = src.ProviderGroupId" +
                "                           AND tgt.[providerstate] = src.[ProviderState]" +
                "                           AND tgt.project_year = src.ProgramYear" +
                "                           AND tgt.mbr_glb_id = src.GlobalMemberId" +
                "                           AND (ISNULL(tgt.EligibleProgramType,'') != ISNULL(src.EligibleProgramType,'') OR ISNULL(tgt.CPG,'') != ISNULL(src.CPG,''))" +
                "                           )" +
                "       WHEN MATCHED" +
                "             THEN" +
                "                    UPDATE" +
                "                    SET tgt.EligibleProgramType = src.EligibleProgramType" +
                "                           , tgt.CPG = src.CPG" +
                "                           , tgt.UpdatedDate = getUtcDate()" +
                ";";

        Mockito.when(namedParameterJdbcTemplate.update(MEMBER_ASSESSMENT_MERGE_QUERY,new HashMap<>()))
                .thenReturn(20);

        final Integer integerCallable = cpgEligibleProgramTypeUpdatesRepositoryImpl.mergeMemberAssessmentData(25000, 0, 2021,"ALL", DateUtil.now().toString());

        assert integerCallable == 0;
    }

    @Test
    public void mergeMemberGapData() throws Exception {


        Mockito.when(namedParameterJdbcTemplate.update("",new HashMap<>()))
                .thenReturn(20);

        final Integer integerCallable = cpgEligibleProgramTypeUpdatesRepositoryImpl.mergeMemberGapData(25000, 0, 2021,"ALL", DateUtil.now().toString());

        assert integerCallable == 0;
    }

    @Test
    public void updateBatchQueriesTest() throws Exception {

        List<Map<String, Object>> batchValues = new ArrayList<>();
        Map<String, Object> map = new HashMap<>();
        map.put("ProgramYear", "2021");
        map.put("ProviderGroupID", "PG1");
        map.put("EligibleProgramType", "IOA");
        map.put("State","MN");
        map.put("UpdatedBy","PAFXJob");

        String query = "MERGE INTO ProgPerf.ProviderGroupExtended AS tgt USING (VALUES " +
                "        (:ProviderGroupID, :State, :ProgramYear, :EligibleProgramType, :UpdatedBy))" +
                "        AS src " +
                "       (ProviderGroupID,State,ProgramYear,EligibleProgramType,UpdatedBy)" +
                "       ON ( tgt.ProviderGroupID = src.ProviderGroupID AND tgt.State = src.State AND tgt.ProgramYear = src.ProgramYear)" +
                "       WHEN MATCHED THEN UPDATE SET" +
                "       tgt.EligibleProgramType=src.EligibleProgramType, tgt.UpdatedBy=src.UpdatedBy, tgt.UpdatedDate=getUtcDate() " +
                "       WHEN NOT MATCHED THEN" +
                "       INSERT (ProviderGroupID,State,ProgramYear,EligibleProgramType,CreatedBy,CreatedDate,UpdatedBy,UpdatedDate)" +
                "       VALUES (src.ProviderGroupID,src.State,src.ProgramYear,src.EligibleProgramType," +
                "       'PAFDeployUpdate',GETUTCDATE(),src.UpdatedBy,getUtcDate());";

        Mockito.when(namedParameterJdbcTemplate.batchUpdate(query, batchValues.toArray(new Map[batchValues.size()])))
                .thenReturn(new int[0]);

        int[] recordCount = cpgEligibleProgramTypeUpdatesRepositoryImpl.updateBatchQueries(batchValues);
        assertEquals(0, recordCount.length);
    }

    @Test
    public void getPafxGroupsRecordCountTest() throws Exception {

    String PAFX_GROUPS_COMMON_COUNT_QUERY = "SELECT ProviderGroupId from ProgPerf.PafExMemberAssessment WITH (NOLOCK)" +
            "        WHERE ProgramYear = :ProgramYear and IsSuppressed ='N' " +
            "        GROUP BY ProviderGroupId ";

    String query = "select count(*) AS totalCount from (" + PAFX_GROUPS_COMMON_COUNT_QUERY + ") AS PAFXMemberCount";


    SqlParameterSource sqlParameterSource = new MapSqlParameterSource("ProgramYear", 2021);
    Mockito.when(namedParameterJdbcTemplate.queryForObject(query, sqlParameterSource, Long.class))
            .thenReturn(20l);

    final Long integerCallable = cpgEligibleProgramTypeUpdatesRepositoryImpl.getPafxGroupsRecordCount(2021,"ALL", DateUtil.now().toString());

    assert 20l == 20l;

    }

    @Test
    public void getPafxMembersProgramTypeBasedOnGroupsTest() throws Exception {

        String query = "SELECT DISTINCT pafx.ProviderGroupId, pafx.ProviderState, pafx.ProgramYear, pafx.EligibleProgramType AS EligibleProgType " +
                "       FROM ProgPerf.PafExMemberAssessment pafx " +
                "       WHERE ProviderGroupId IN (%s)  AND ProgramYear = (select mc.value from ProgPerf.MasterConfiguration mc WITH (NOLOCK) where mc.code='CurrentProgramYear') ";

        List<PAFXMemberData> pafxMemberDataList = new ArrayList<>();
        Mockito.when(namedParameterJdbcTemplate.query(query, new BeanPropertyRowMapper<>(PAFXMemberData.class)))
                .thenReturn(pafxMemberDataList);


        List<PAFXMemberData> pafxMemberData = cpgEligibleProgramTypeUpdatesRepositoryImpl.getPafxMembersProgramTypeBasedOnGroups("'PG1'", 2021);
        assert pafxMemberData.size() == 0;
    }

    @Test
    public void getProviderGroupExtendedRecordsTest() throws Exception {

        String query = "SELECT ProviderGroupID, State, ProgramYear, EligibleProgramType from ProgPerf.ProviderGroupExtended WITH (NOLOCK) " +
                "       WHERE ProviderGroupId IN (%s) " +
                "       AND ProgramYear = (select mc.value from ProgPerf.MasterConfiguration mc WITH (NOLOCK) where mc.code='CurrentProgramYear')";

        List<ProviderGroup> pafxMemberDataList = new ArrayList<>();
        Mockito.when(namedParameterJdbcTemplate.query(query, new BeanPropertyRowMapper<>(ProviderGroup.class)))
                .thenReturn(pafxMemberDataList);


        List<ProviderGroup> pafxMemberData = cpgEligibleProgramTypeUpdatesRepositoryImpl.getProviderGroupExtendedRecords("'PG1'", 2021);
        assert pafxMemberData.size() == 0;
    }

    @Test
    public void getPafxProviderGroupIdsTest() throws Exception {
        String commonQuery = "SELECT ProviderGroupId from ProgPerf.PafExMemberAssessment " +
                "        WHERE ProgramYear = (select mc.value from ProgPerf.MasterConfiguration mc WITH (NOLOCK) where mc.code='CurrentProgramYear') " +
                "        GROUP BY ProviderGroupId ";
        String query = commonQuery +
                "       ORDER BY [ProviderGroupId] "+
                "       OFFSET :OFFSET ROWS FETCH NEXT :BATCHSIZE ROWS ONLY";
        List<PAFXMemberData> pafxMemberDataList = new ArrayList<>();
        Mockito.when(namedParameterJdbcTemplate.query(query, new BeanPropertyRowMapper<>(PAFXMemberData.class)))
                .thenReturn(pafxMemberDataList);


        List<PAFXMemberData> pafxMemberData = cpgEligibleProgramTypeUpdatesRepositoryImpl.getPafxProviderGroupIds(5000,0, 2021, "ALL", DateUtil.now().toString());
        assert pafxMemberData.size() == 0;
    }

    @Test
    public void getPafxMembersForCurrentProgramYearRecordCountTest() {


        Mockito.when(namedParameterJdbcTemplate.queryForObject(Mockito.anyString(),Mockito.anyMap(),Mockito.eq(Long.class)))
                .thenReturn(20l);

        final Long integerCallable = cpgEligibleProgramTypeUpdatesRepositoryImpl.getPafxMembersForCurrentProgramYearRecordCount(2021, "Modified", "2022-03-22 07:30:00");

        assert integerCallable == 20l;
    }

    @Test
    public void getPafxMembersForCurrentProgramYearRecordCountTestALL() {


        Mockito.when(namedParameterJdbcTemplate.queryForObject(Mockito.anyString(),Mockito.anyMap(),Mockito.eq(Long.class)))
                .thenReturn(20l);

        final Long integerCallable = cpgEligibleProgramTypeUpdatesRepositoryImpl.getPafxMembersForCurrentProgramYearRecordCount(2021, "ALL", "2022-03-22 07:30:00");

        assert integerCallable == 20l;
    }
}
