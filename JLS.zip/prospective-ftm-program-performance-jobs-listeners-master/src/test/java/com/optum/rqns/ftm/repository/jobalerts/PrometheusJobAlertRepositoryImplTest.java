package com.optum.rqns.ftm.repository.jobalerts;

import com.optum.rqns.ftm.model.JobAlert;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.time.LocalDateTime;

@RunWith(SpringRunner.class)
@Slf4j
@ContextConfiguration(classes = {
        PrometheusJobAlertRepositoryImpl.class
})
public class PrometheusJobAlertRepositoryImplTest {

    @MockBean
    NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @InjectMocks
    PrometheusJobAlertRepositoryImpl jobAlertRepository;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }


    @Test
    public void getJobAlertDTODetailsTest() {
        LocalDateTime date = LocalDateTime.now();
        JobAlert jobAlertDTO = JobAlert.builder()
                .build();

        JobAlert result = jobAlertRepository.getJobAlertByName("");
        System.out.println("***"+result);


    }

}
