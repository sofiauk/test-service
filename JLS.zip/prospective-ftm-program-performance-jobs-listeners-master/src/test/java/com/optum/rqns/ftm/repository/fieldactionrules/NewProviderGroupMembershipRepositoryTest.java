package com.optum.rqns.ftm.repository.fieldactionrules;


import com.optum.rqns.ftm.enums.RuleEnum;
import com.optum.rqns.ftm.model.fieldactionrules.ChangeServiceAction;
import com.optum.rqns.ftm.model.fieldactionrules.NewMemberShipAction;
import com.optum.rqns.ftm.model.fieldactionrules.RuleAction;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        NewProviderGroupMembershipRepoImpl.class
})
public class NewProviderGroupMembershipRepositoryTest {

    @MockBean
    NamedParameterJdbcTemplate namedParameterJdbcTemplate;
    @MockBean
    JdbcTemplate jdbcTemplate;
    @MockBean
    ResultSet resultSet;

    @InjectMocks
    NewProviderGroupMembershipRepoImpl repository;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        repository = new NewProviderGroupMembershipRepoImpl(this.namedParameterJdbcTemplate,this.jdbcTemplate);
    }

    @Test
    public void getRowCountforNewProviderMembershipTest() {
        Mockito.when(namedParameterJdbcTemplate.queryForObject(repository.GET_COUNT_ELIGLIBLE_PROVIDER_STATE_TO_SEND_ACTION,new HashMap<>(),Integer.class))
                .thenReturn(2000);

        List<Integer> recordCount = repository.getRowCountforNewProviderMembership(1000);

        assert recordCount.size() == 3;
    }

    @Test
    public void processtoSendActionForNewProviderMembershipTest() {
        String query = "SELECT COUNT(*) as totalrowcount FROM ProgPerf.ProviderGroupPerformance ";
        List<Integer> result = new ArrayList<>();
        result.add(0);
        result.add(1000);
        result.add(2000);
        NewMemberShipAction action  = new NewMemberShipAction();
        action.setCurrentWeekMemberShipCount(30l);
        action.setPreviousWeekMemberShipCount(10l);
        action.setProviderGroupId("123");
        action.setProgramYear(2021);
        action.setProviderGroupName("Test");
        action.setState("OH");
        action.setIsShared(false);
        action.setRuleType(RuleEnum.THRESHOLD_RULE.getValue());
        List<String> uuid = new ArrayList<>();
        uuid.add("uathcauser10");
        action.setUserUuid(uuid);

        Mockito.when(namedParameterJdbcTemplate.queryForObject(query,new HashMap<>(),new NewProviderGroupMembershipRepoImpl.NewProviderGroupMembershipRowMapper()))
                .thenReturn(action);

        List<RuleAction> recordCount = repository.processtoSendActionForNewProviderMembership(0,1000);

        assert recordCount.size() == 0;
    }


    @Test
    public void testMapper() throws SQLException {
        NewProviderGroupMembershipRepoImpl.NewProviderGroupMembershipRowMapper   mapper = new NewProviderGroupMembershipRepoImpl.NewProviderGroupMembershipRowMapper();
        RuleAction action = mapper.mapRow(resultSet, 1);
        Assert.assertNotNull(action);
    }


}