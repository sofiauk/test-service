package com.optum.rqns.ftm.service.practiceassist;


import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.assertj.core.util.DateUtil;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.optum.rqns.ftm.enums.ExecutionWeek;
import com.optum.rqns.ftm.enums.GroupsToExecute;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.exception.ProgramPerformanceJobListenerException;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.producer.JobEventProducer;
import com.optum.rqns.ftm.kafka.producer.KeyBasedProviderSyncProducer;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.model.practiceassist.PaAggregationData;
import com.optum.rqns.ftm.repository.common.CommonRepository;
import com.optum.rqns.ftm.repository.practiceassist.PaLandingPageRepositoryMysqlImpl;

import lombok.extern.slf4j.Slf4j;

@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        MbrMedAdherenceAggregationServiceImpl.class,PaLandingPageRepositoryMysqlImpl.class
})
@SpringBootTest(properties = {
        "spring.db_connection_thread_pool_size=10",
})
public class MedAdherenceAggregationServiceImplTest {

        
      
    @MockBean
    private PaLandingPageRepositoryMysqlImpl paLandingPageRepositoryMysqlImpl;
   
    @MockBean
	private CommonRepository commonRepository;

    @MockBean
    private KeyBasedProviderSyncProducer producer;
    
    @InjectMocks
    private  MbrMedAdherenceAggregationServiceImpl mbrMedAdherenceAggregationServiceImpl;
    
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);  
    }
    @MockBean
    private JobEventProducer jobEventProducer;

    @Test
    public void executeModifiedJobTest() {
        ReflectionTestUtils.setField(mbrMedAdherenceAggregationServiceImpl, "producerThreadPoolSize", 1);
        
        ReflectionTestUtils.setField(mbrMedAdherenceAggregationServiceImpl, "FETCH_BATCH_SIZE", 1);
        ReflectionTestUtils.setField(mbrMedAdherenceAggregationServiceImpl, "UPSERT_BATCH_SIZE", 1);
        ReflectionTestUtils.setField(mbrMedAdherenceAggregationServiceImpl, "threadPoolSize", 1);
        List<String> provGrpList= new ArrayList<String>();
        provGrpList.add("TestprvGrpId-1");

        Mockito.when(commonRepository.fetchLastSucessfullJobStartRanDate(JobName.RUN_MED_ADHERENCE_AGGREGATION.getValue())).thenReturn(LocalDateTime.now().format(formatter));
        
        Mockito.when(paLandingPageRepositoryMysqlImpl.getAffectedProvGrpList(Mockito.anyInt(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn( provGrpList);
        
        
     
        Mockito.when(paLandingPageRepositoryMysqlImpl.markedRecordsAsDirty(Mockito.anyString(),Mockito.anyString(),Mockito.anyInt(), Mockito.anyString(),Mockito.anyString(),Mockito.any(List.class))).thenReturn(1);

        List<PaAggregationData> paMedAdherenceAggregationList = new ArrayList<PaAggregationData>();
        paMedAdherenceAggregationList.add(new PaAggregationData() );
        Mockito.when(paLandingPageRepositoryMysqlImpl.getPaAggregateDataByBatch(Mockito.anyInt(),ArgumentMatchers.isNull(),Mockito.anyString(),Mockito.any(List.class)))
        .thenReturn(paMedAdherenceAggregationList);

        Mockito.when(paLandingPageRepositoryMysqlImpl.upserMedAdherenceAggregation(paMedAdherenceAggregationList)).thenReturn(1);
       
        Mockito. when(paLandingPageRepositoryMysqlImpl.inActivateDirtyRecords(Mockito.anyString(),Mockito.anyString(), Mockito.anyInt(), Mockito.anyString(),Mockito.anyString(),Mockito.any(List.class))).thenReturn(1);
        final JobStatus jobStatus = mbrMedAdherenceAggregationServiceImpl.executeJob(getJobEvent(GroupsToExecute.MODIFIED.getValue()));
         assert jobStatus.getUpdatedRows() == 0;
    }

    
    @Test
    public void executeAllJobTest() {
        ReflectionTestUtils.setField(mbrMedAdherenceAggregationServiceImpl, "producerThreadPoolSize", 1);
        ReflectionTestUtils.setField(mbrMedAdherenceAggregationServiceImpl, "FETCH_BATCH_SIZE", 1);
        ReflectionTestUtils.setField(mbrMedAdherenceAggregationServiceImpl, "UPSERT_BATCH_SIZE", 1);
        ReflectionTestUtils.setField(mbrMedAdherenceAggregationServiceImpl, "threadPoolSize", 1);

        List<String> provGrpList= new ArrayList<String>();
        provGrpList.add("TestprvGrpId-1");

        
        Mockito.when(paLandingPageRepositoryMysqlImpl.getAffectedProvGrpList(Mockito.anyInt(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn( provGrpList);
        
        Mockito.when(paLandingPageRepositoryMysqlImpl.markedRecordsAsDirty(Mockito.anyString(),Mockito.anyString(),Mockito.anyInt(), Mockito.anyString(),Mockito.anyString(),Mockito.any(List.class))).thenReturn(1);

            
        List<PaAggregationData> paMedAdherenceAggregationList = new ArrayList<PaAggregationData>();
        paMedAdherenceAggregationList.add(new PaAggregationData() );
        Mockito.when(paLandingPageRepositoryMysqlImpl.getPaAggregateDataByBatch(Mockito.anyInt(),ArgumentMatchers.isNull(),Mockito.anyString(),Mockito.any(List.class)))
        .thenReturn(paMedAdherenceAggregationList);


        Mockito.when(paLandingPageRepositoryMysqlImpl.upserMedAdherenceAggregation(paMedAdherenceAggregationList)).thenReturn(1);
   
        Mockito. when(paLandingPageRepositoryMysqlImpl.inActivateDirtyRecords(Mockito.anyString(),Mockito.anyString(), Mockito.anyInt(), Mockito.anyString(),Mockito.anyString(),Mockito.any(List.class))).thenReturn(1);
          
        final JobStatus jobStatus = mbrMedAdherenceAggregationServiceImpl.executeJob(getJobEvent(GroupsToExecute.ALL.getValue()));
                
        assert jobStatus.getUpdatedRows() == 0;
    }
    
    
    @Test
    public void executeJobExceptionTest() {
        ReflectionTestUtils.setField(mbrMedAdherenceAggregationServiceImpl, "producerThreadPoolSize", 1);
        ReflectionTestUtils.setField(mbrMedAdherenceAggregationServiceImpl, "FETCH_BATCH_SIZE", 1);
        ReflectionTestUtils.setField(mbrMedAdherenceAggregationServiceImpl, "UPSERT_BATCH_SIZE", 1);
        ReflectionTestUtils.setField(mbrMedAdherenceAggregationServiceImpl, "threadPoolSize", 1);

        List<String> provGrpList= new ArrayList<String>();
        provGrpList.add("TestprvGrpId-1");
        Mockito.when(paLandingPageRepositoryMysqlImpl.getAffectedProvGrpList(Mockito.anyInt(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn( provGrpList);
            
        List<PaAggregationData> paMedAdherenceAggregationList = new ArrayList<PaAggregationData>();
        paMedAdherenceAggregationList.add(new PaAggregationData() );
        Mockito.when(paLandingPageRepositoryMysqlImpl.getPaAggregateDataByBatch(Mockito.anyInt(),ArgumentMatchers.isNull(),Mockito.anyString(),Mockito.any(List.class)))
        .thenThrow(new ProgramPerformanceJobListenerException(""));

        Mockito.when(paLandingPageRepositoryMysqlImpl.upserMedAdherenceAggregation(paMedAdherenceAggregationList)).thenReturn(1);
   
          
        final JobStatus jobStatus = mbrMedAdherenceAggregationServiceImpl.executeJob(getJobEvent(GroupsToExecute.ALL.getValue()));
        
        assert 0 == jobStatus.getUpdatedRows();
    }
    private JobEvent getJobEvent(String groupsToExecute){
        JobEvent jobEvent = new JobEvent();
        jobEvent.setJobName(JobName.RUN_MED_ADHERENCE_AGGREGATION.getValue());
        jobEvent.setExecutionWeek( ExecutionWeek.ALL.getValue());
        jobEvent.setGroupsToExecute(groupsToExecute);
        jobEvent.setProgramYear(2021);
        jobEvent.setTimeStamp(Instant.now());
        jobEvent.setStatus(Status.IN_PROGRESS.getValue()); 
       
        return jobEvent;
    }
   
     


}
