package com.optum.rqns.ftm.repository.qfo;

import com.optum.rqns.ftm.enums.GroupsToExecute;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.model.qfo.CommonProgramYearCalenderDTO;
import com.optum.rqns.ftm.model.qfo.QfoPerformanceData;
import com.optum.rqns.ftm.repository.IDMGlidePathRepositoryImpl;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.Callable;

@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        QFOPerformanceRepositoryImpl.class
})
@SpringBootTest(properties = {
        "spring.db_connection_thread_pool_size=10",
})
public class QFOPerformanceRepositoryImplTest {

    @MockBean
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @InjectMocks
    private QFOPerformanceRepositoryImpl qfoPerformanceRepository;


    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }


    @Test
    public void getRecordCountTest() {

        String query = "select count(*) AS totalCount from (SELECT GroupId from ProgPerf.StarRatingIngestion WITH (NOLOCK) WHERE ProgramYear =  2021  GROUP BY GroupId ) AS ASRRatingCount";
        Mockito.when(namedParameterJdbcTemplate.queryForObject(query,new HashMap<>(),Long.class))
                .thenReturn(20l);

        final Long recordCount = qfoPerformanceRepository.getStarRatingIngestionGroupsRecordCount(GroupsToExecute.ALL.toString(), 2021);

        assert recordCount == 20;
    }

    @Test
    public void getRecordCountModifiedTest() {

        String query = "select count(*) AS totalCount from (SELECT GroupId from ProgPerf.StarRatingIngestion WITH (NOLOCK) WHERE ProgramYear =  2021  AND CAST(UpdatedDate as date) >= (select CAST(LastSuccessfulRunDate as date) from ProgPerf.jobrunconfiguration where jobname = 'RunQFOPerformance') GROUP BY GroupId ) AS ASRRatingCount";
        Mockito.when(namedParameterJdbcTemplate.queryForObject(query,new HashMap<>(),Long.class))
                .thenReturn(20l);

        final Long recordCount = qfoPerformanceRepository.getStarRatingIngestionGroupsRecordCount(GroupsToExecute.MODIFIED.toString(), 2021);

        assert recordCount == 20;
    }

    @Test
    public void mergeIDMDataAllTest() throws Exception {

        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(),Mockito.any(SqlParameterSource.class)))
                .thenReturn(20);

        final Integer integerCallable = qfoPerformanceRepository.mergeProviderGroupPerformanceDetailsWithASR(25000, 0, GroupsToExecute.ALL.toString(), 2021,CommonProgramYearCalenderDTO.builder().programYear(2021).durationValue("JAN_2021").build());

        assert integerCallable == 20;
    }

    @Test
    public void mergeIDMDataModifiedTest() throws Exception {

        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(),Mockito.any(SqlParameterSource.class)))
                .thenReturn(20);

        final Integer integerCallable = qfoPerformanceRepository.mergeProviderGroupPerformanceDetailsWithASR(25000, 0, GroupsToExecute.MODIFIED.toString(), 2021,CommonProgramYearCalenderDTO.builder().programYear(2021).durationValue("JAN_2021").build());


        assert integerCallable == 20;
    }

    @Test
    public void loadProviderGroupPerformanceQualityDetailsModifiedTest(){
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(),Mockito.anyMap()))
                .thenReturn(1);
         Integer updateCOunt = qfoPerformanceRepository.loadProviderGroupPerformanceQualityDetails(10000, 0, GroupsToExecute.MODIFIED.toString(),CommonProgramYearCalenderDTO.builder().programYear(2021).durationValue("JAN_2021").build());
        assert updateCOunt == 1;
    }

    @Test
    public void loadProviderGroupPerformanceQualityDetailsAllTest(){
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(),Mockito.anyMap()))
                .thenReturn(1);
        Integer updateCOunt = qfoPerformanceRepository.loadProviderGroupPerformanceQualityDetails(25000, 0, GroupsToExecute.ALL.toString(), CommonProgramYearCalenderDTO.builder().programYear(2021).durationValue("JAN_2021").build());
        assert updateCOunt == 1;
    }

    @Test
    public void getProviderGroupMemberQualityRecordCountModifiedTest(){
        Mockito.when(namedParameterJdbcTemplate.queryForObject(Mockito.anyString(),Mockito.anyMap(),Mockito.eq(Long.class)))
                .thenReturn(1L);
        Long count = qfoPerformanceRepository.getProviderGroupMemberQualityRecordCount( GroupsToExecute.MODIFIED.toString(),2021);
        assert count == 1L;
    }

    @Test
    public void getProviderGroupMemberQualityRecordCountAllTest(){
        Mockito.when(namedParameterJdbcTemplate.queryForObject(Mockito.anyString(),Mockito.anyMap(),Mockito.eq(Long.class))).thenReturn(1L);
        Long count = qfoPerformanceRepository.getProviderGroupMemberQualityRecordCount( GroupsToExecute.ALL.toString(),2021);
        assert count == 1L;
    }

    @Test
    public void getHealthSystemRecordCountModifiedTest(){
        Mockito.when(namedParameterJdbcTemplate.queryForObject(Mockito.anyString(),Mockito.anyMap(),Mockito.eq(Long.class)))
                .thenReturn(1L);
        Long count = qfoPerformanceRepository.getHealthSystemRecordCount( GroupsToExecute.MODIFIED.toString(), CommonProgramYearCalenderDTO.builder().programYear(2021).durationValue("JAN_2021").build());
        assert count == 1L;
    }

    @Test
    public void getHealthSystemRecordCountAllTest(){
        Mockito.when(namedParameterJdbcTemplate.queryForObject(Mockito.anyString(),Mockito.anyMap(),Mockito.eq(Long.class))).thenReturn(1L);
        Long count = qfoPerformanceRepository.getHealthSystemRecordCount( GroupsToExecute.ALL.toString(),CommonProgramYearCalenderDTO.builder().programYear(2021).durationValue("JAN_2021").build());
        assert count == 1L;
    }

    @Test
    public void mergeHealthSystemPerfDetailsModifiedTest(){
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(),Mockito.anyMap()))
                .thenReturn(1);
        Integer updateCOunt = qfoPerformanceRepository.mergeHealthSystemPerfDetails(10000, 0, GroupsToExecute.MODIFIED.toString(),CommonProgramYearCalenderDTO.builder().programYear(2021).durationValue("JAN_2021").build());
        assert updateCOunt == 1;
    }

    @Test
    public void mergeHealthSystemPerfDetailsAllTest(){
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(),Mockito.anyMap()))
                .thenReturn(1);
        Integer updateCOunt = qfoPerformanceRepository.mergeHealthSystemPerfDetails(25000, 0, GroupsToExecute.ALL.toString(), CommonProgramYearCalenderDTO.builder().programYear(2021).durationValue("JAN_2021").build());
        assert updateCOunt == 1;
    }

    @Test
    public void getStarRatingGlidePathInitialCount(){
        Mockito.when(namedParameterJdbcTemplate.queryForObject(Mockito.anyString(),Mockito.anyMap(),Mockito.eq(Long.class))).thenReturn(1L);
        Long queryCount = qfoPerformanceRepository.getStarRatingGlidePathCount(2022,"MAY_2022");
        assert  queryCount == 1;
    }

    @Test
    public void getStarRatingGlidePathGroupsRecordCountForGroupTest(){
        Mockito.when(namedParameterJdbcTemplate.queryForObject(Mockito.anyString(),Mockito.anyMap(),Mockito.eq(Long.class))).thenReturn(1L);
        Long glidePathCount = qfoPerformanceRepository.getStarRatingGlidePathGroupsRecordCount(GroupsToExecute.ALL.getValue(),2022, false, "GROUP");
        assert glidePathCount == 1;
    }

    @Test
    public void getStarRatingGlidePathGroupsRecordCountForHealthSystemTest(){
        Mockito.when(namedParameterJdbcTemplate.queryForObject(Mockito.anyString(),Mockito.anyMap(),Mockito.eq(Long.class))).thenReturn(1L);
        Long glidePathCount = qfoPerformanceRepository.getStarRatingGlidePathGroupsRecordCount(GroupsToExecute.ALL.getValue(),2022, false, "HEALTHSYSTEM");
        assert glidePathCount == 1;
    }

    @Test
    public void mergeStarRatingGlidePathWithRatingIngestionTest(){
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(),Mockito.anyMap()))
                .thenReturn(1);
        Integer updateCOunt = qfoPerformanceRepository.mergeStarRatingGlidePathWithRatingIngestion(25000, 0, GroupsToExecute.ALL.toString(),2022, CommonProgramYearCalenderDTO.builder().programYear(2022).durationValue("JAN_2022").build(),
                false, "GROUP");
        assert updateCOunt == 1;
    }

    @Test
    public void mergeStarRatingGlidePathWithRatingIngestionHealthSystemTest(){
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(),Mockito.anyMap()))
                .thenReturn(1);
        Integer updateCOunt = qfoPerformanceRepository.mergeStarRatingGlidePathWithRatingIngestion(25000, 0, GroupsToExecute.ALL.toString(),2022, CommonProgramYearCalenderDTO.builder().programYear(2022).durationValue("JAN_2022").build(),
                false, "HEALTHSYSTEM");
        assert updateCOunt == 1;
    }

    @Test
    public void getQfoPerformanceDataBobSyncCountTest(){
        Mockito.when(namedParameterJdbcTemplate.queryForObject(Mockito.anyString(),Mockito.anyMap(),Mockito.eq(Long.class)))
                .thenReturn(1l);
        Long publishCount = qfoPerformanceRepository.getQfoPerformanceDataBobSyncCount(2022,CommonProgramYearCalenderDTO.builder().programYear(2021).durationValue("JAN_2021").build(), "ALL");
        assert publishCount == 1;
    }

    @Test
    public void getQfoPerformanceDataBobSyncCountModifiedTest(){
        Mockito.when(namedParameterJdbcTemplate.queryForObject(Mockito.anyString(),Mockito.anyMap(),Mockito.eq(Long.class)))
                .thenReturn(1l);
        Long publishCount = qfoPerformanceRepository.getQfoPerformanceDataBobSyncCount(2022,CommonProgramYearCalenderDTO.builder().programYear(2021).durationValue("JAN_2021").build(), "Modified");
        assert publishCount == 1;
    }

    @Test
    public void getQfoPerformanceDataBobSyncDetailsTest(){
        String query =  "with aggregratePerformance as (  " +
                "select " +
                " pgp.ProviderGroupId as ProviderGroupId,  " +
                " SUM(pgp.TotalPatients) as TotalPatients, " +
                " sum(pgp.MapCpiEligiblePatients) as MapCpiEligiblePatients,  " +
                " SUM(pgp.SuspectConditionsTotal) as SuspectConditionsTotal, " +
                " pgp.ProgramYear as ProgramYear, " +
                " pgp.DurationValue as DurationValue, " +
                " (SUM(pgp.MapCpiAnnualCareVisits) /sum(pgp.MapCpiEligiblePatients) * 100 ) as ACVCompleted, " +
                " ( sum(SuspectConditionsAssessedDiagnosed)+sum(SuspectConditionsAssessedUndiagnosed) / sum(SuspectConditionsTotal) * 100 ) as McaipTotalAssessed, " +
                " ( sum(SuspectConditionsAssessedDiagnosed)+sum(SuspectConditionsAssessedUndiagnosed) ) as conditionsAssessed " +
                " from " +
                " ProgPerf.ProviderGroupPerformanceDetails pgp  " +
                " where  " +
                " pgp.ProgramYear = :ProgramYear  " +
                " AND pgp.DurationValue = ( " +
                " select " +
                " TOP 1 DurationValue " +
                " from " +
                " ProgPerf.CommonProgramYearCalender WITH (NOLOCK) " +
                " where " +
                " DurationType = 'MONTH'  " +
                " AND StartDate <= ( " +
                " select " +
                " CAST( getUTCDate() AS Date )) " +
                " AND EndDate >= ( " +
                " select " +
                " CAST( getUTCDate() AS Date )) " +
                " and ProgramYear = :ProgramYear " +
                " and TeamType = 'QFO' )  " +
                " %s " +
                " group by  " +
                " pgp.ProviderGroupId, " +
                " pgp.ProgramYear , " +
                " pgp.DurationValue  " +
                " )  " +
                " select " +
                " apgp.*,  " +
                " srgp.OverallRating as OverAllStartRating, " +
                " srgp.MapcpiRating as MapCpiStartRating, " +
                " srgp.PartDRating as MapCpiPartDRating " +
                " from  " +
                " aggregratePerformance apgp  " +
                " left join ProgPerf.StarRatingGlidePath srgp  " +
                " on " +
                " srgp.ProgramYear = apgp.ProgramYear " +
                " and srgp.GroupId = apgp.ProviderGroupId  " +
                " and srgp.RatingType = 'GROUP'  " +
                " and srgp.DurationValue =  apgp.DurationValue " +
                " ORDER BY " +
                " srgp.GroupId asc OFFSET :OFFSET ROWS FETCH NEXT :BATCHSIZE ROWS ONLY";
        List<QfoPerformanceData> qfoPerformanceData = new ArrayList<>();
        SqlParameterSource sqlParameterSource = new MapSqlParameterSource("BatchSize", 0)
                .addValue("OFFSET", 1000)
                .addValue("ProgramYear",20212);

        Mockito.when(namedParameterJdbcTemplate.query(query, sqlParameterSource, new BeanPropertyRowMapper<>(QfoPerformanceData.class)))
                .thenReturn(qfoPerformanceData);

        List<QfoPerformanceData> list = qfoPerformanceRepository.getQfoPerformanceDataBobSyncDetails(100, 0,2022,"JUN_2022", "ALL");

        assert list.size() == 0;
    }

    @Test
    public void getQfoPerformanceDataBobSyncDetailsModifiedTest(){
        String query =  "with aggregratePerformance as (  " +
                "select " +
                " pgp.ProviderGroupId as ProviderGroupId,  " +
                " SUM(pgp.TotalPatients) as TotalPatients, " +
                " sum(pgp.MapCpiEligiblePatients) as MapCpiEligiblePatients,  " +
                " SUM(pgp.SuspectConditionsTotal) as SuspectConditionsTotal, " +
                " pgp.ProgramYear as ProgramYear, " +
                " pgp.DurationValue as DurationValue, " +
                " (SUM(pgp.MapCpiAnnualCareVisits) /sum(pgp.MapCpiEligiblePatients) * 100 ) as ACVCompleted, " +
                " ( sum(SuspectConditionsAssessedDiagnosed)+sum(SuspectConditionsAssessedUndiagnosed) / sum(SuspectConditionsTotal) * 100 ) as McaipTotalAssessed, " +
                " ( sum(SuspectConditionsAssessedDiagnosed)+sum(SuspectConditionsAssessedUndiagnosed) ) as conditionsAssessed " +
                " from " +
                " ProgPerf.ProviderGroupPerformanceDetails pgp  " +
                " where  " +
                " pgp.ProgramYear = :ProgramYear  " +
                " AND pgp.DurationValue = ( " +
                " select " +
                " TOP 1 DurationValue " +
                " from " +
                " ProgPerf.CommonProgramYearCalender WITH (NOLOCK) " +
                " where " +
                " DurationType = 'MONTH'  " +
                " AND StartDate <= ( " +
                " select " +
                " CAST( getUTCDate() AS Date )) " +
                " AND EndDate >= ( " +
                " select " +
                " CAST( getUTCDate() AS Date )) " +
                " and ProgramYear = :ProgramYear " +
                " and TeamType = 'QFO' )  " +
                " %s " +
                " group by  " +
                " pgp.ProviderGroupId, " +
                " pgp.ProgramYear , " +
                " pgp.DurationValue  " +
                " )  " +
                " select " +
                " apgp.*,  " +
                " srgp.OverallRating as OverAllStartRating, " +
                " srgp.MapcpiRating as MapCpiStartRating, " +
                " srgp.PartDRating as MapCpiPartDRating " +
                " from  " +
                " aggregratePerformance apgp  " +
                " left join ProgPerf.StarRatingGlidePath srgp  " +
                " on " +
                " srgp.ProgramYear = apgp.ProgramYear " +
                " and srgp.GroupId = apgp.ProviderGroupId  " +
                " and srgp.RatingType = 'GROUP'  " +
                " and srgp.DurationValue =  apgp.DurationValue " +
                " ORDER BY " +
                " srgp.GroupId asc OFFSET :OFFSET ROWS FETCH NEXT :BATCHSIZE ROWS ONLY";
        List<QfoPerformanceData> qfoPerformanceData = new ArrayList<>();
        SqlParameterSource sqlParameterSource = new MapSqlParameterSource("BatchSize", 0)
                .addValue("OFFSET", 1000)
                .addValue("ProgramYear",20212);

        Mockito.when(namedParameterJdbcTemplate.query(query, sqlParameterSource, new BeanPropertyRowMapper<>(QfoPerformanceData.class)))
                .thenReturn(qfoPerformanceData);

        List<QfoPerformanceData> list = qfoPerformanceRepository.getQfoPerformanceDataBobSyncDetails(100, 0,2022,"JUN_2022", "MODIFIED");

        assert list.size() == 0;
    }

    @Test
    public void getPreviousMonthDisabledProvidersDataTest(){
        SqlParameterSource sqlParameterSource = new MapSqlParameterSource
                ("ProgramYear",2022);
        List<QfoPerformanceData> qfoPerformanceData = new ArrayList<>();
        Mockito.when(namedParameterJdbcTemplate.query("",sqlParameterSource,new BeanPropertyRowMapper<>(QfoPerformanceData.class)))
                .thenReturn(qfoPerformanceData);
        List<QfoPerformanceData> list = qfoPerformanceRepository.getPreviousMonthDisabledProvidersData(2022);
        assert list.size() == 0;
    }
}