package com.optum.rqns.ftm.service.fieldactionrules;

import com.optum.rqns.ftm.model.fieldactionrules.RuleAction;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.kie.server.client.RuleServicesClient;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        ThresholdServiceImpl.class
})
public class ThresholdServiceImplTest {

    @MockBean
    RuleServicesClient ruleServicesClient;

    @MockBean
    RestTemplate restTemplate;

    @InjectMocks
    ThresholdServiceImpl thresholdService;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test(expected = NullPointerException.class)
    public void invokeDMRuleRestAPIList(){
        List<RuleAction> inputData = new ArrayList<>();
        RuleAction ruleAction = new RuleAction();
        inputData.add(ruleAction);
        Mockito.when(thresholdService.invokeDMRuleRestAPIList(inputData,"test")).thenReturn(inputData);
        thresholdService.invokeDMRuleRestAPIList(inputData,"test");

    }

}
