package com.optum.rqns.ftm.service.jobalerts;

import com.optum.rqns.ftm.model.JobAlert;
import com.optum.rqns.ftm.repository.jobalerts.PrometheusJobAlertRepositoryImpl;
import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.MeterRegistry;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.time.LocalDateTime;

@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        PrometheusJobAlertServiceImpl.class
})
public class PrometheusJobAlertServiceImplTest {

    @MockBean
    private PrometheusJobAlertRepositoryImpl jobAlertRepository;

    @MockBean
    MeterRegistry meterRegistry;

    @InjectMocks
    private PrometheusJobAlertServiceImpl prometheusJobAlertService;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void sendAlertsTestFailure() {
        Gauge gauge = null;
        LocalDateTime date = LocalDateTime.now();
        JobAlert jobAlertDTO = JobAlert.builder()
                .id(1)
                .jobName("TEST")
                .affectedRows(1)
                .errorMessage("TEST")
                .createdBy("TEST")
                .isActive(true)
                .jobDescription("TEST")
                .jobEvent("TEST")
                .lastSuccessfulRunDate(date)
                .status("test")
                .createdDate(date)
                .lastRunDate(date)
                .jobEnd(date)
                .jobExecutionHistoryId(1)
                .jobStart(date)
                .message("test")
                .messageKey("test")
                .modifiedDate(date)
                .modifiedBy("test")
                .build();
        Mockito.when(Gauge.builder(Mockito.anyString(), Mockito.any()).tags().description(Mockito.anyString()).register(meterRegistry)).thenThrow(new RuntimeException());

        String result = prometheusJobAlertService.sendAlerts(jobAlertDTO);
        Assert.assertEquals("SUCCESS", result);
    }

    @Test
    public void sendAlertsTestSuccess() {

        LocalDateTime date = LocalDateTime.now();
        JobAlert jobAlertDTO = JobAlert.builder()
                .id(1)
                .status("SUCCESS")
                .jobName("TEST")
                .jobExecutionHistoryId(1)
                .createdDate(date)
                .modifiedDate(date)
                .modifiedBy("TEST")
                .lastRunDate(date)
                .lastSuccessfulRunDate(date)
                .jobStart(date)
                .jobEnd(date)
                .createdBy("TEST")
                .affectedRows(0)
                .errorMessage("")
                .jobDescription("TEST")
                .messageKey("")
                .message("")
                .isActive(true)
                .jobEvent("")
                .build();
        Gauge gauge = Gauge.builder("job.status", jobAlertDTO.getStatus(), t -> {
            return t == "SUCCESS" ? 1 : 0;
        }).tags("id", "1").description("TEST").register(meterRegistry);

//        Mockito.when(Gauge.builder("job.status", jobAlertDTO.getStatus(), t -> {
//            return t == "SUCCESS" ? 1 : 0;
//        }).tags("id", "1").description("TEST").register(meterRegistry)).thenReturn(gauge);
        String result = prometheusJobAlertService.sendAlerts(jobAlertDTO);
        Assert.assertEquals("SUCCESS", result);

    }

}