package com.optum.rqns.ftm.kafka.producer;

import com.optum.rqns.ftm.kafka.avro.models.v1.fieldactionrule.Action;
import com.optum.rqns.ftm.kafka.avro.models.v1.pps.MemberPaymentOverallStatusSync;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.KafkaException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.kafka.core.KafkaProducerException;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.util.concurrent.ListenableFuture;

import java.util.HashMap;
import java.util.Map;

@SpringBootTest
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        KeyBasedMemberOverallStatusSyncProducer.class
})
public class KeyBasedMemberOverallStatusSyncProducerTest {

    @InjectMocks
    KeyBasedMemberOverallStatusSyncProducer producer;

    @Before
    public void initMocks() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void postToKafka() {
        ListenableFuture<SendResult<String, MemberPaymentOverallStatusSync>> listenableFuture =
                Mockito.mock(ListenableFuture.class);

        KafkaTemplate<String, MemberPaymentOverallStatusSync> kafkaTemplate =
                Mockito.mock(KafkaTemplate.class);


        MemberPaymentOverallStatusSync memberPaymentOverallStatusSync = getMemberPaymentOverallStatusSync();
        Mockito.doNothing().when(kafkaTemplate).flush();
        Mockito.when(listenableFuture.isDone()).thenReturn(true);
        Mockito.when(kafkaTemplate.send(Mockito.anyString(),Mockito.any(),Mockito.any())).thenReturn(listenableFuture);

        Map<String, String> map = new HashMap<>();
        map.put("MemberStatusRqsEnabled", "true");
        map.put("MemberStatusGcpEnabled", "true");
        producer.rqsTopicName = "DataSync.Auth.UserRole";
        producer.gcpTopicName =  "rqs_member.status";

        boolean result = producer.postToKafka(memberPaymentOverallStatusSync,"Test",map);

        Assert.assertFalse(result);
    }

    private MemberPaymentOverallStatusSync getMemberPaymentOverallStatusSync() {
        MemberPaymentOverallStatusSync memberPaymentOverallStatusSync = new MemberPaymentOverallStatusSync();
        Action action=new Action();
        action.setVerifyRuleResult(false);
        memberPaymentOverallStatusSync.setAssessmentDttm("Test");
        memberPaymentOverallStatusSync.setClientId("Test");
        memberPaymentOverallStatusSync.setGlobalMemberId("Test");
        memberPaymentOverallStatusSync.setLob("Test");
        memberPaymentOverallStatusSync.setMessageBatchId("Test");
        memberPaymentOverallStatusSync.setMessageCorrelationId("Test");
        memberPaymentOverallStatusSync.setOverallStatus("Test");
        memberPaymentOverallStatusSync.setProviderGroupId("Test");
        memberPaymentOverallStatusSync.setSource("Test");
        memberPaymentOverallStatusSync.setProgramYear(1);
        return memberPaymentOverallStatusSync;
    }

    @Test
    public void postToKafka_KafkaProducerException() {
        ListenableFuture<SendResult<String, MemberPaymentOverallStatusSync>> listenableFuture =
                Mockito.mock(ListenableFuture.class);

        KafkaTemplate<String, MemberPaymentOverallStatusSync> kafkaTemplate =
                Mockito.mock(KafkaTemplate.class);

        MemberPaymentOverallStatusSync memberPaymentOverallStatusSync = getMemberPaymentOverallStatusSync();

        ProducerRecord producerRecord = new ProducerRecord("test", "test");

        Mockito.doNothing().when(kafkaTemplate).flush();
        Mockito.when(listenableFuture.isDone()).thenReturn(true);
        Mockito.when(kafkaTemplate.send(Mockito.anyString(),Mockito.any(),Mockito.any())).thenThrow(new KafkaProducerException(producerRecord, "test", new NullPointerException()));


        Map<String, String> map = new HashMap<>();
        map.put("MemberStatusRqsEnabled", "true");
        map.put("MemberStatusGcpEnabled", "true");
        producer.rqsTopicName = "DataSync.Auth.UserRole";
        producer.gcpTopicName =  "rqs_member.status";

        boolean result = producer.postToKafka(memberPaymentOverallStatusSync,"Test",map);

        Assert.assertFalse(result);
    }

    @Test
    public void postToKafka_KafkaException() {
        ListenableFuture<SendResult<String, MemberPaymentOverallStatusSync>> listenableFuture =
                Mockito.mock(ListenableFuture.class);

        KafkaTemplate<String, MemberPaymentOverallStatusSync> kafkaTemplate =
                Mockito.mock(KafkaTemplate.class);

        MemberPaymentOverallStatusSync memberPaymentOverallStatusSync = getMemberPaymentOverallStatusSync();
        Mockito.doNothing().when(kafkaTemplate).flush();
        Mockito.when(listenableFuture.isDone()).thenReturn(true);
        Mockito.when(kafkaTemplate.send(Mockito.anyString(),Mockito.any(),Mockito.any())).thenThrow(new KafkaException("test"));
        Map<String, String> map = new HashMap<>();
        map.put("MemberStatusRqsEnabled", "true");
        map.put("MemberStatusGcpEnabled", "true");
        producer.rqsTopicName = "DataSync.Auth.UserRole";
        producer.gcpTopicName =  "rqs_member.status";

        boolean result = producer.postToKafka(memberPaymentOverallStatusSync,"Test", map);
        Assert.assertFalse(result);
    }

    @Test
    public void postToKafka_Exception() {
        ListenableFuture<SendResult<String, MemberPaymentOverallStatusSync>> listenableFuture =
                Mockito.mock(ListenableFuture.class);

        KafkaTemplate<String, MemberPaymentOverallStatusSync> kafkaTemplate =
                Mockito.mock(KafkaTemplate.class);

        MemberPaymentOverallStatusSync memberPaymentOverallStatusSync = getMemberPaymentOverallStatusSync();

        Mockito.doNothing().when(kafkaTemplate).flush();
        Mockito.when(listenableFuture.isDone()).thenReturn(true);
        Mockito.when(kafkaTemplate.send(Mockito.anyString(),Mockito.any(),Mockito.any())).thenThrow(new NullPointerException("test"));

        Map<String, String> map = new HashMap<>();
        map.put("MemberStatusRqsEnabled", "true");
        map.put("MemberStatusGcpEnabled", "true");
        producer.rqsTopicName = "DataSync.Auth.UserRole";
        producer.gcpTopicName =  "rqs_member.status";

        boolean result = producer.postToKafka(memberPaymentOverallStatusSync,"Test", map);

        Assert.assertFalse(result);
    }
}
