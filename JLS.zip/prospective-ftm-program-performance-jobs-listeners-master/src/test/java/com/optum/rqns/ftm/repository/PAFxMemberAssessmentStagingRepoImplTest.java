package com.optum.rqns.ftm.repository;

import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.time.Instant;
import java.util.HashMap;

@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        PAFxMemberAssessmentStagingRepositoryImpl.class
})
public class PAFxMemberAssessmentStagingRepoImplTest {

    @MockBean
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @InjectMocks
    private PAFxMemberAssessmentStagingRepositoryImpl paFxMemberAssessmentStagingRepository;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void getRecordCountTest() {
        HashMap<String,Object> params =  new HashMap<>();
        params.put("ProgramYear",2022);
        Mockito.when(namedParameterJdbcTemplate.queryForObject(Mockito.anyString(),Mockito.any(HashMap.class),Mockito.eq(Long.class)))
                .thenReturn(20l);

        JobEvent jobEvent = JobEvent.newBuilder().
                setProgramYear(2022)
                .setJobName(JobName.RUN_PAFX_MEMBER_ASSESSMENT_STAGING.getValue())
                .setExecutionWeek("Current")
                .setGroupsToExecute("All")
                .setTimeStamp(Instant.now())
                .setStatus("Complete").build();

        final Long recordCount = paFxMemberAssessmentStagingRepository.getRecordCount(jobEvent);
        System.out.println("record count{}"+recordCount);

        assert recordCount == 20l;
    }

    @Test
    public void getRecordCountModifiedTest() {
        HashMap<String,Object> params =  new HashMap<>();
        params.put("ProgramYear",2022);
        Mockito.when(namedParameterJdbcTemplate.queryForObject(Mockito.anyString(),Mockito.any(HashMap.class),Mockito.eq(Long.class)))
                .thenReturn(10l);

        JobEvent jobEvent = JobEvent.newBuilder().
                setProgramYear(2022)
                .setJobName(JobName.RUN_PAFX_MEMBER_ASSESSMENT_STAGING.getValue())
                .setExecutionWeek("Current")
                .setGroupsToExecute("Modified")
                .setTimeStamp(Instant.now())
                .setStatus("Complete").build();

        final Long recordCount = paFxMemberAssessmentStagingRepository.getRecordCount(jobEvent);
        assert recordCount == 10l;
    }

    @Test
    public void mergePAFXMemberDataTest() throws Exception {


        Mockito.when(namedParameterJdbcTemplate.update(paFxMemberAssessmentStagingRepository.MERGE_QUERY,new HashMap<>()))
                .thenReturn(20);
        JobEvent jobEvent = JobEvent.newBuilder().
                setProgramYear(2022)
                .setJobName(JobName.RUN_PAFX_MEMBER_ASSESSMENT_STAGING.getValue())
                .setExecutionWeek("Current")
                .setGroupsToExecute("All")
                .setTimeStamp(Instant.now())
                .setStatus("Complete").build();
        final Integer integerCallable = paFxMemberAssessmentStagingRepository.mergePAFxMemberAssessmentData(jobEvent, 0, 10000);

        assert integerCallable == 0;
    }

    @Test
    public void mergePAFXMemberDataModifiedTest() throws Exception {


        Mockito.when(namedParameterJdbcTemplate.update(paFxMemberAssessmentStagingRepository.MERGE_QUERY,new HashMap<>()))
                .thenReturn(20);
        JobEvent jobEvent = JobEvent.newBuilder().
                setProgramYear(2022)
                .setJobName(JobName.RUN_PAFX_MEMBER_ASSESSMENT_STAGING.getValue())
                .setExecutionWeek("Current")
                .setGroupsToExecute("Modified")
                .setTimeStamp(Instant.now())
                .setStatus("Complete").build();
        final Integer integerCallable = paFxMemberAssessmentStagingRepository.mergePAFxMemberAssessmentData(jobEvent, 0, 10000);

        assert integerCallable == 0;
    }
}
