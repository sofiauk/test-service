package com.optum.rqns.ftm.exception;

import org.junit.Assert;
import org.junit.Test;

public class JobErrorCodeTest {

    @Test
    public void apiErrorCodeTest(){
        JobErrorCode generic = JobErrorCode.GENERIC;
        Assert.assertNotNull(generic.getCode());
        Assert.assertNotNull(generic.getDetail());
        Assert.assertNotNull(generic.getTitle());
        Assert.assertEquals(JobErrorCode.valueOf("GENERIC"), generic);
    }

}
