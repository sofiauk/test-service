//package com.optum.rqns.ftm.repository.opportunities;
//
//import com.optum.rqns.ftm.constants.Constants;
//import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
//import com.optum.rqns.ftm.model.opportunities.OpportunitiesConfiguration;
//import com.optum.rqns.ftm.model.opportunities.OpportunitiesDetails;
//import com.optum.rqns.ftm.model.opportunities.OpportunitiesSummary;
//import lombok.extern.slf4j.Slf4j;
//import org.junit.Assert;
//import org.junit.Before;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mockito;
//import org.mockito.MockitoAnnotations;
//import org.springframework.boot.test.mock.mockito.MockBean;
//import org.springframework.jdbc.core.BeanPropertyRowMapper;
//import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
//import org.springframework.jdbc.core.namedparam.SqlParameterSource;
//import org.springframework.test.context.ActiveProfiles;
//import org.springframework.test.context.ContextConfiguration;
//import org.springframework.test.context.junit4.SpringRunner;
//
//import java.sql.ResultSet;
//import java.util.ArrayList;
//import java.util.List;
//
//@RunWith(SpringRunner.class)
//@Slf4j
//@ActiveProfiles("test")
//@ContextConfiguration(classes = { SuspectConditionsOpportunitiesRepositoryImpl.class })
//public class SuspectConditionsOpportunitiesRepositoryImplTest {
//
//	@MockBean
//	NamedParameterJdbcTemplate namedParameterJdbcTemplate;
//
//	@MockBean
//	ResultSet resultSet;
//
//	@InjectMocks
//	SuspectConditionsOpportunitiesRepositoryImpl opportunitiesCommonRepoImpl;
//
//	@Before
//	public void init() {
//		MockitoAnnotations.initMocks(this);
//	}
//
//	@Test
//	public void upsertDeploymentOpportunitiesDetails() {
//		int[] count = { 2, 4, 6 };
//		Mockito.when(namedParameterJdbcTemplate.batchUpdate(Mockito.anyString(), (SqlParameterSource[]) Mockito.any()))
//				.thenReturn(count);
//		Mockito.when(namedParameterJdbcTemplate.query(Mockito.anyString(), Mockito.anyMap(),
//				(BeanPropertyRowMapper) Mockito.any())).thenReturn(getOpportunitiesDetails());
//		Mockito.when(namedParameterJdbcTemplate.queryForObject(Mockito.anyString(), Mockito.anyMap(),
//				(BeanPropertyRowMapper) Mockito.any())).thenReturn(new ArrayList<Integer>());
//		List<OpportunitiesDetails> opportunitiesDetails = opportunitiesCommonRepoImpl
//				.getSuspectConditionsOpportunitiesDetails(getOpportunitiesConfiguration().get(0),
//						JobEvent.newBuilder().setGroupsToExecute("Modified").build(), "test");
//		List<OpportunitiesDetails> opportunitiesDetail = opportunitiesCommonRepoImpl
//				.getSuspectConditionsOpportunitiesDetails(
//						getOpportunitiesConfigurationPaitentsNotFullyAssessed().get(0),
//						JobEvent.newBuilder().setGroupsToExecute("Modified").build(), "test");
//		Assert.assertNotNull(opportunitiesDetails);
//		Assert.assertNotNull(opportunitiesDetail);
//	}
//
//	public List<OpportunitiesConfiguration> getOpportunitiesConfiguration() {
//
//		List<OpportunitiesConfiguration> opportunitiesConfs = new ArrayList<>();
//
//		OpportunitiesConfiguration opportunitiesConf = OpportunitiesConfiguration.builder()
//				.selectClauseCondition("ASSESSMENT_STATUS = 'NOT ASSESSED'")
//				.opportunityName("Suspect Conditions Not Assessed").opportunityDisplayOrder(1)
//				.masterOpportunityName(Constants.SUSPECT_CONDITIONS).build();
//
//		opportunitiesConfs.add(opportunitiesConf);
//		return opportunitiesConfs;
//	}
//
//	public List<OpportunitiesConfiguration> getOpportunitiesConfigurationPaitentsNotFullyAssessed() {
//
//		List<OpportunitiesConfiguration> opportunitiesConfs = new ArrayList<>();
//
//		OpportunitiesConfiguration opportunitiesConf = OpportunitiesConfiguration.builder()
//				.selectClauseCondition("ASSESSMENT_STATUS = 'NOT ASSESSED'")
//				.opportunityName("Patients Not Fully Assessed").opportunityDisplayOrder(2)
//				.masterOpportunityName(Constants.SUSPECT_CONDITIONS).build();
//
//		opportunitiesConfs.add(opportunitiesConf);
//		return opportunitiesConfs;
//	}
//
//	public List<OpportunitiesDetails> getOpportunitiesDetails() {
//
//		List<OpportunitiesDetails> opportunitiesDetailsList = new ArrayList<>();
//		OpportunitiesDetails opportunitiesDetails = OpportunitiesDetails.builder().assessmentCount(1)
//				.clientName("Aetna").deploymentCount(1).displayText("Test").gapCount(1).lobName("Medicare")
//				.masterOpportunityType(Constants.SUSPECT_CONDITIONS).masterOpportunityTypePosition(1)
//				.opportunityType("Patients Not Fully Assessed").programYear(2021).providerGroupID("3804")
//				.providerGroupName("MERCY CLINIC EAST COMMUNITIES").serviceLevel("ALL").build();
//
//		opportunitiesDetailsList.add(opportunitiesDetails);
//		return opportunitiesDetailsList;
//	}
//
//	public List<OpportunitiesSummary> getOpportunitiesSummary() {
//
//		List<OpportunitiesSummary> opportunitiesSummaryList = new ArrayList<>();
//		OpportunitiesDetails opportunitiesDetails = OpportunitiesDetails.builder().assessmentCount(1)
//				.clientName("Aetna").deploymentCount(1).displayText("Test").gapCount(1).lobName("Medicare")
//				.masterOpportunityType(Constants.SUSPECT_CONDITIONS).masterOpportunityTypePosition(1)
//				.opportunityType("Patients Not Fully Assessed").programYear(2021).providerGroupID("3804")
//				.providerGroupName("MERCY CLINIC EAST COMMUNITIES").serviceLevel("ALL").build();
//		OpportunitiesSummary opportunitiesSummary = OpportunitiesSummary.builder()
//				.masterLevelOpportunity(Constants.SUSPECT_CONDITIONS).masterLevelOpportunityPosition(1)
//				.programYear(2021).providerGroupID("3804").providerGroupName("MERCY CLINIC EAST COMMUNITIES")
//				.state("OH").totalAssessmentsCount(1).totalGapsCount(1).build();
//
//		opportunitiesSummaryList.add(opportunitiesSummary);
//		return opportunitiesSummaryList;
//	}
//
//}
