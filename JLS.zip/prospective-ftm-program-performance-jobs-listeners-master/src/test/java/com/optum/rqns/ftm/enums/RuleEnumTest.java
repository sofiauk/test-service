package com.optum.rqns.ftm.enums;

import org.junit.Assert;
import org.junit.Test;
import org.mockito.Mockito;

public class RuleEnumTest {

    @Test
    public void ruleEnumTest(){
        RuleEnum ruleEnum=RuleEnum.THRESHOLD_RULE;
        Assert.assertNotNull(ruleEnum.getValue());
        Assert.assertEquals(RuleEnum.valueOf("THRESHOLD_RULE"), ruleEnum);
    }

    @Test
    public void TestParseValue(){
        Assert.assertEquals(RuleEnum.THRESHOLD_RULE,RuleEnum.parseValue("THRESHOLD_RULE"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testParseValue_Error(){
        Mockito.when(RuleEnum.parseValue("test")).thenThrow(new IllegalArgumentException());
        RuleEnum.parseValue("test");

    }
}
