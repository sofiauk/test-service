package com.optum.rqns.ftm.kafka.producer;



import com.optum.rqns.ftm.kafka.avro.models.v1.fieldactionrule.Action;
import com.optum.rqns.ftm.kafka.avro.models.v1.program.performance.provider.AdditionalProviderGroupStats;
import com.optum.rqns.ftm.kafka.avro.models.v1.program.performance.provider.ClientGoals;
import com.optum.rqns.ftm.kafka.avro.models.v1.program.performance.provider.NewProviderGroup;
import com.optum.rqns.ftm.kafka.avro.models.v1.program.performance.provider.Opportunity;
import com.optum.rqns.ftm.kafka.avro.models.v1.program.performance.provider.PerformanceDetail;
import com.optum.rqns.ftm.kafka.avro.models.v1.program.performance.provider.ProgPerfProviderMSSync;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.KafkaException;
import org.junit.Assert;
import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.kafka.core.KafkaProducerException;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.concurrent.ListenableFuture;

import java.util.Arrays;

@SpringBootTest
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        KeyBasedProviderSyncProducer.class
})
public class KeyBasedProviderSyncProducerTest {

    @BeforeEach
    public void initMocks() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void postToKafka() {
        ListenableFuture<SendResult<String, ProgPerfProviderMSSync>> listenableFuture =
                Mockito.mock(ListenableFuture.class);

        KafkaTemplate<String, ProgPerfProviderMSSync> kafkaTemplate =
                Mockito.mock(KafkaTemplate.class);
        KeyBasedProviderSyncProducer jobEventProducer
                = new KeyBasedProviderSyncProducer();
        ReflectionTestUtils.setField(jobEventProducer,"kafkaTemplate",kafkaTemplate);
        ProgPerfProviderMSSync progPerfProviderMSSync = getProgPerfProviderMSSync();
        Mockito.doNothing().when(kafkaTemplate).flush();
        Mockito.when(listenableFuture.isDone()).thenReturn(true);
        Mockito.when(kafkaTemplate.send(Mockito.anyString(),Mockito.any(),Mockito.any())).thenReturn(listenableFuture);




        jobEventProducer.topicName = "DataSync.Auth.UserRole";

        boolean result = jobEventProducer.postToKafka(progPerfProviderMSSync,"Test");

        Assert.assertTrue(result);
    }

    private ProgPerfProviderMSSync getProgPerfProviderMSSync() {
        ProgPerfProviderMSSync progPerfProviderMSSync = new ProgPerfProviderMSSync();
        Action action=new Action();
        action.setVerifyRuleResult(false);
        progPerfProviderMSSync.setMessageType("Test");
        progPerfProviderMSSync.setProviderGroupID("Test");
        progPerfProviderMSSync.setProviderGroupName("Test");
        progPerfProviderMSSync.setState("Test");
        progPerfProviderMSSync.setAdditionalProviderGroupStats(new AdditionalProviderGroupStats());
        progPerfProviderMSSync.setClientGoals(new ClientGoals());
        progPerfProviderMSSync.setNewProviderGroup(new NewProviderGroup());
        progPerfProviderMSSync.setOpportunity(new Opportunity());
        progPerfProviderMSSync.setPerformance(new PerformanceDetail());
        progPerfProviderMSSync.setProgramYear(1);
        return progPerfProviderMSSync;
    }

    @Test
    public void postToKafka_KafkaProducerException() {
        ListenableFuture<SendResult<String, ProgPerfProviderMSSync>> listenableFuture =
                Mockito.mock(ListenableFuture.class);

        KafkaTemplate<String, ProgPerfProviderMSSync> kafkaTemplate =
                Mockito.mock(KafkaTemplate.class);
        KeyBasedProviderSyncProducer jobEventProducer
                = new KeyBasedProviderSyncProducer();
        ReflectionTestUtils.setField(jobEventProducer,"kafkaTemplate",kafkaTemplate);

        ProgPerfProviderMSSync progPerfProviderMSSync = getProgPerfProviderMSSync();

        ProducerRecord producerRecord = new ProducerRecord("test", "test");

        Mockito.doNothing().when(kafkaTemplate).flush();
        Mockito.when(listenableFuture.isDone()).thenReturn(true);
        Mockito.when(kafkaTemplate.send(Mockito.anyString(),Mockito.any(),Mockito.any())).thenThrow(new KafkaProducerException(producerRecord, "test", new NullPointerException()));



        jobEventProducer.topicName = "DataSync.Auth.UserRole";

        boolean result = jobEventProducer.postToKafka(progPerfProviderMSSync,"Test");

        Assert.assertFalse(result);
    }

    @Test
    public void postToKafka_KafkaException() {
        ListenableFuture<SendResult<String, ProgPerfProviderMSSync>> listenableFuture =
                Mockito.mock(ListenableFuture.class);

        KafkaTemplate<String, ProgPerfProviderMSSync> kafkaTemplate =
                Mockito.mock(KafkaTemplate.class);

        ProgPerfProviderMSSync progPerfProviderMSSync = getProgPerfProviderMSSync();
        Mockito.doNothing().when(kafkaTemplate).flush();
        Mockito.when(listenableFuture.isDone()).thenReturn(true);
        Mockito.when(kafkaTemplate.send(Mockito.anyString(),Mockito.any(),Mockito.any())).thenThrow(new KafkaException("test"));

        KeyBasedProviderSyncProducer jobEventProducer
                = new KeyBasedProviderSyncProducer();
        jobEventProducer.topicName = "DataSync.Auth.UserRole";

        boolean result = jobEventProducer.postToKafka(progPerfProviderMSSync,"Test");
        Assert.assertFalse(result);
    }

    @Test
    public void postToKafka_Exception() {
        ListenableFuture<SendResult<String, ProgPerfProviderMSSync>> listenableFuture =
                Mockito.mock(ListenableFuture.class);

        KafkaTemplate<String, ProgPerfProviderMSSync> kafkaTemplate =
                Mockito.mock(KafkaTemplate.class);

        ProgPerfProviderMSSync progPerfProviderMSSync = getProgPerfProviderMSSync();

        Mockito.doNothing().when(kafkaTemplate).flush();
        Mockito.when(listenableFuture.isDone()).thenReturn(true);
        Mockito.when(kafkaTemplate.send(Mockito.anyString(),Mockito.any(),Mockito.any())).thenThrow(new NullPointerException("test"));

        KeyBasedProviderSyncProducer jobEventProducer
                = new KeyBasedProviderSyncProducer();
        jobEventProducer.topicName = "DataSync.Auth.UserRole";

        boolean result = jobEventProducer.postToKafka(progPerfProviderMSSync,"Test");

        Assert.assertFalse(result);
    }
}
