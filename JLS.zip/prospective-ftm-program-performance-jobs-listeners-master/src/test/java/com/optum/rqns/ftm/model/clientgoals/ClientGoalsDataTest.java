package com.optum.rqns.ftm.model.clientgoals;

import com.optum.rqns.ftm.util.GetterSetterTester;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class ClientGoalsDataTest extends GetterSetterTester<ClientGoalsData> {

    @Override
    public ClientGoalsData getTestInstance() {
        return new ClientGoalsData();
    }

    @Test
    public void TestConfig() {
        assertNotNull(getTestInstance());
    }

    @Test
    public void testClientGoalsData(){

        ClientGoalsData noArgsConstrcutor = new ClientGoalsData();
        noArgsConstrcutor.setClientId("AET");

        assertEquals("AET", noArgsConstrcutor.getClientId());
        ClientGoalsData clientGoalsData = new ClientGoalsData("test","test","test","test","test","test",true);
        clientGoalsData.builder();

        clientGoalsData.toString();

        assertEquals("test", clientGoalsData.getClientId());
        assertEquals("test", clientGoalsData.getClientName());
        assertEquals("test", clientGoalsData.getLob());
        assertEquals("test", clientGoalsData.getProgramYear());
        assertEquals("test", clientGoalsData.getProviderGroupID());
        assertEquals("test", clientGoalsData.getState());
        assertEquals(true, clientGoalsData.isHasClientGoals());
    }
}