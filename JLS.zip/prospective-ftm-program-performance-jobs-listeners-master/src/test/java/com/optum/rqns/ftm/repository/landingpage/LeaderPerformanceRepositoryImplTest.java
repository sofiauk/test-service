package com.optum.rqns.ftm.repository.landingpage;

import com.optum.rqns.ftm.model.ProgramYearCalendarDTO;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        LeaderPerformanceRepositoryImpl.class
})
@SpringBootTest(properties = {
        "spring.db_connection_thread_pool_size=10",
})
public class LeaderPerformanceRepositoryImplTest {
    @MockBean
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
    @InjectMocks
    private LeaderPerformanceRepositoryImpl leaderPerformanceRepository;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void loadDataToEModalityFromMemberAssessments(){
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(),Mockito.any(HashMap.class)))
                .thenReturn(20);
        final Long recordCount = leaderPerformanceRepository.loadDataToEModalityFromMemberAssessments(2021);
        assert recordCount == 20;
    }

    @Test
    public void calculateLeaderPerformanceData(){
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(),Mockito.any(HashMap.class)))
                .thenReturn(20);
        final int recordCount = leaderPerformanceRepository.calculateLeaderPerformanceData("User1",new ArrayList<>(),"");
        assert recordCount == 20;
    }

    @Test
    public void calculateICPerformanceData(){
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(),Mockito.any(HashMap.class)))
                .thenReturn(20);
        final ProgramYearCalendarDTO programYearCalendarDTO = ProgramYearCalendarDTO.builder()
                .startDate(LocalDate.now())
                .endDate(LocalDate.now())
                .durationValue("")
                .build();
        final int recordCount = leaderPerformanceRepository.calculateICPerformanceData("User2","HCA", programYearCalendarDTO);
        assert recordCount == 20;
    }

    @Test
    public void getServiceLevelForUser(){

        Mockito.when(
                namedParameterJdbcTemplate
                        .queryForList(
                                Mockito.anyString(),
                                Mockito.anyMap(),
                                Mockito.any()
                        )
        )
                .thenReturn(Arrays.asList("HCA","PSC"));
        final List<String> serviceLevels = leaderPerformanceRepository.getServiceLevelForUser("User1");

        Assert.assertNotNull(serviceLevels);
        Assert.assertEquals("HCA",serviceLevels.get(0));
        Assert.assertEquals("PSC",serviceLevels.get(1));
    }

 @Test
    public void loadLeaderPerformanceWeekly()
 {
     Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(), Mockito.anyMap())).thenReturn(1);
     final ProgramYearCalendarDTO programYearCalendarDTO = ProgramYearCalendarDTO.builder()
             .startDate(LocalDate.now())
             .endDate(LocalDate.now())
             .durationValue("")
             .build();
     final Long recordCount = leaderPerformanceRepository.loadLeaderPerformanceWeekly(programYearCalendarDTO);
     assert recordCount == 1;
 }

    @Test
    public void flagIsCurrentWeekFalse() {
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(), Mockito.any(SqlParameterSource.class))).thenReturn(1);
        final Integer recordCount = leaderPerformanceRepository.flagIsCurrentWeekFalse(2021, ProgramYearCalendarDTO.builder().build());
        log.info(recordCount+"");
        assert recordCount == 1;
    }

    @Test
    public void flagIsActiveFalse() {
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(), Mockito.any(SqlParameterSource.class))).thenReturn(1);
        final Integer recordCount = leaderPerformanceRepository.flagIsActiveFalse(2021, ProgramYearCalendarDTO.builder().build());
        log.info(recordCount+"");
        assert recordCount == 1;
    }

    @Test
    public void calculateICGrowthRatePOCData() {
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(), Mockito.anyMap())).thenReturn(1);
        final Integer recordCount = leaderPerformanceRepository.calculateICGrowthRatePOCData("1","sl", ProgramYearCalendarDTO.builder().programYear(2021).build());
        log.info(recordCount+"");
        assert recordCount == 1;
    }

    @Test
    public void calculateLeaderGrowthRatePOCData() {
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(), Mockito.anyMap())).thenReturn(1);
        final Integer recordCount = leaderPerformanceRepository.calculateLeaderGrowthRatePOCData("1",new ArrayList<>(),2022);
        log.info(recordCount+"");
        assert recordCount == 1;
    }

    @Test
    public void calculateLeaderGrowthRatePOCDataForAllRegionAndState() {
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(), Mockito.anyMap())).thenReturn(1);
        final Integer recordCount = leaderPerformanceRepository.calculateLeaderGrowthRatePOCDataForAllRegionAndState("1",new ArrayList<>(),2022);
        log.info(recordCount+"");
        assert recordCount == 1;
    }

    @Test
    public void calculateEModalityPOCDataForClientAndLob() {
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(), Mockito.anyMap())).thenReturn(1);
        final Integer recordCount = leaderPerformanceRepository.calculateEModalityPOCDataForClientAndLob("1", "HCA",ProgramYearCalendarDTO.builder().build());
        log.info(recordCount+"");
        assert recordCount == 1;
    }

    @Test
    public void updateIsActiveFlagToFalse() {
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(), Mockito.any(SqlParameterSource.class))).thenReturn(1);
        final Integer recordCount = leaderPerformanceRepository.updateIsActiveFlagToFalse("2020");
        log.info(recordCount+"");
        assert recordCount == 1;
    }

    @Test
    public void updateICGoalLeaderPerformance() {
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(), Mockito.anyMap())).thenReturn(1);
        Integer count = leaderPerformanceRepository.updateICGoalLeaderPerformance("userId", "serviceLevel", ProgramYearCalendarDTO.builder().build());
        assert count == 1;
    }

     @Test
    public void updateRegions() {
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(), Mockito.any(SqlParameterSource.class))).thenReturn(1);
        final Integer recordCount = leaderPerformanceRepository.updateRegions(ProgramYearCalendarDTO.builder().build());
        log.info(recordCount+"");
        assert recordCount == 1;
    }

    @Test
    public void calculateCGapData() {
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(), Mockito.anyMap())).thenReturn(1);
        Integer count = leaderPerformanceRepository.calculateCGapData("userId", "serviceLevel", ProgramYearCalendarDTO.builder()
                .startDate(LocalDate.now())
                .endDate(LocalDate.now())
                .build());
        assert count == 1;
    }

    @Test
    public void calculateEModalityPOCData() {
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(), Mockito.anyMap())).thenReturn(1);
        final Integer recordCount = leaderPerformanceRepository.calculateEModalityPOCData("1","sl", ProgramYearCalendarDTO.builder().programYear(2021).build());
        log.info(recordCount+"");
        assert recordCount == 1;
    }

    @Test
    public void getUsersForRole()
    {
        final List<Object> usersList = Arrays.asList("User1", "User2");
        Mockito.when(namedParameterJdbcTemplate.queryForList(
                Mockito.anyString(),
                Mockito.anyMap(),
                Mockito.any()
        )).thenReturn(usersList);
        final List<String> usersByRole = leaderPerformanceRepository.getUsersByRole(Arrays.asList("HCA", "PSC"));
        assert (usersList.equals(usersByRole));
    }

    @Test
    public void loadLeaderPerformanceNationalLevelAll()
    {
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(), Mockito.anyMap())).thenReturn(1);
        final long recordCount = leaderPerformanceRepository.loadLeaderPerformanceNationalLevelAll(ProgramYearCalendarDTO.builder().programYear(2021)
                .startDate(LocalDate.now())
                .endDate(LocalDate.now())
                .durationValue("WEEK").build());
        log.info(recordCount+"");
        assert recordCount == 1;
    }

    @Test
    public void calculateReturnNetCna() {
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(), Mockito.anyMap())).thenReturn(1);
        final Integer recordCount = leaderPerformanceRepository.calculateReturenNetCnaForALL("1", "HCA",ProgramYearCalendarDTO.builder().build());
        log.info(recordCount+"");
        assert recordCount == 1;
    }

    @Test
    public void calculateReturnNetCnaClineAndLob() {
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(), Mockito.anyMap())).thenReturn(1);
        final Integer recordCount = leaderPerformanceRepository.calculateReturenNetCnaForClientAndLob("1", "HCA",ProgramYearCalendarDTO.builder().build());
        log.info(recordCount+"");
        assert recordCount == 1;
    }

    @Test
    public void calculateNationalGrowthRatePOCData() {
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(), Mockito.anyMap())).thenReturn(1);
        final Integer recordCount = leaderPerformanceRepository.calculateNationalGrowthRatePOCData("1", ProgramYearCalendarDTO.builder().build());
        log.info(recordCount+"");
        assert recordCount == 1;
    }

    @Test
    public void calculateReturnNetCnaForNational() {
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(), Mockito.anyMap())).thenReturn(1);
        final Integer recordCount = leaderPerformanceRepository.calculateReturnNetCnaForNational("1", ProgramYearCalendarDTO.builder().build());
        log.info(recordCount+"");
        assert recordCount == 1;
    }
    @Test
    public void calculateEModalityPOCDataForNational() {
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(), Mockito.anyMap())).thenReturn(1);
        final Integer recordCount = leaderPerformanceRepository.calculateEModalityPOCDataForNational("1", ProgramYearCalendarDTO.builder().build());
        log.info(recordCount+"");
        assert recordCount == 1;
    }

    @Test
    public void calculateEModalityPOCDataForNationalClientLob() {
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(), Mockito.anyMap())).thenReturn(1);
        final Integer recordCount = leaderPerformanceRepository.calculateEModalityPOCDataForNationalClientLob("1", ProgramYearCalendarDTO.builder().build());
        log.info(recordCount+"");
        assert recordCount == 1;
    }
    @Test
    public void calculateReturnNetCnaForAllNational() {
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(), Mockito.anyMap())).thenReturn(1);
        final Integer recordCount = leaderPerformanceRepository.calculateReturnNetCnaForAllNational("1", ProgramYearCalendarDTO.builder().build());
        log.info(recordCount+"");
        assert recordCount == 1;
    }

    @Test
    public void loadLeaderPerformanceWeeklyCGAPClosureStateRegion() {
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(), Mockito.anyMap())).thenReturn(1);
        final long recordCount = leaderPerformanceRepository.loadLeaderPerformanceWeeklyCGAPClosureStateRegion(ProgramYearCalendarDTO.builder().build());
        log.info(recordCount+"");
        assert recordCount == 1;
    }

    @Test
    public void loadLeaderPerformanceWeeklyCGAPClosureNational() {
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(), Mockito.anyMap())).thenReturn(1);
        final long recordCount = leaderPerformanceRepository.loadLeaderPerformanceWeeklyCGAPClosureNational(ProgramYearCalendarDTO.builder().build());
        log.info(recordCount+"");
        assert recordCount == 1;
    }

    @Test
    public void updateAllNationalGoalsLeaderPerformance()
    {
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(), Mockito.anyMap())).thenReturn(1);
        final long recordCount = leaderPerformanceRepository.updateAllNationalGoalsLeaderPerformance(ProgramYearCalendarDTO.builder().build());
        log.info(recordCount+"");
        assert recordCount == 1;
    }

    @Test
    public void updateNationalGoalsLeaderPerformance()
    {
        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(), Mockito.anyMap())).thenReturn(1);
        final long recordCount = leaderPerformanceRepository.updateNationalGoalsLeaderPerformance(ProgramYearCalendarDTO.builder().build());
        log.info(recordCount+"");
        assert recordCount == 1;
    }
}
