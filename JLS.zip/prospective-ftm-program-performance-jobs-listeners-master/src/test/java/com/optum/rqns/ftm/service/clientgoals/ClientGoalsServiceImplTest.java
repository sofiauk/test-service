package com.optum.rqns.ftm.service.clientgoals;

import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.producer.KeyBasedProviderSyncProducer;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.model.clientgoals.ClientGoalsData;
import com.optum.rqns.ftm.repository.clientgoals.ClientGoalsRepository;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        ClientGoalsServiceImpl.class
})
@SpringBootTest(properties = {
        "new_providergroup_rule_producer_thread_pool_size=1",
})
public class ClientGoalsServiceImplTest {

    @MockBean
    private ClientGoalsRepository clientGoalsRepository;

    @MockBean
    private KeyBasedProviderSyncProducer producer;

    @InjectMocks
    private ClientGoalsServiceImpl clientGoalsService;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void getClientGoalsTest() {
        try {
            ReflectionTestUtils.setField(clientGoalsService, "producerThreadPoolSize", 1);

            Mockito.when(clientGoalsRepository.getRecordCount(Mockito.anyInt())).thenReturn(25000l);

            List<ClientGoalsData> clientGoalsData = getClientGoals();

            Mockito.when(clientGoalsRepository.getClientGoals(Constants.BATCH_SIZE,10000,2021))
                    .thenReturn(clientGoalsData);
            JobStatus jobStatus = clientGoalsService.executeJob(getJobEvent(JobName.RUN_CLIENT_GOALS.toString(), false));
            assert Status.SUCCESS == jobStatus.getStatus();

            assert 2 == jobStatus.getUpdatedRows();

        }catch(Exception e){}

    }

    private JobEvent getJobEvent(String jobName, boolean isModified) {
        JobEvent jobEvent = new JobEvent();
        jobEvent.setProgramYear(2021);
        jobEvent.setJobName(jobName);
        jobEvent.setGroupsToExecute(isModified ? "Modified" : "All");
        jobEvent.setExecutionWeek("Current");
        jobEvent.setTimeStamp(Instant.now());
        jobEvent.setStatus("Complete");
        return jobEvent;
    }

    private List<ClientGoalsData>  getClientGoals() {

        ClientGoalsData clientGoalsData1 =
                ClientGoalsData.builder()
                        .providerGroupID("123")
                        .state("CA")
                        .programYear("2021")
                        .hasClientGoals(true)
                        .clientId("AET")
                        .clientName("Aetna")
                        .build();

        ClientGoalsData  clientGoalsData2 = ClientGoalsData.builder()
                .providerGroupID("456")
                .state("CA")
                .programYear("2021")
                .hasClientGoals(true)
                .clientId("AET")
                .clientName("Aetna")
                .build();

        List<ClientGoalsData> clientGoalsDataList = new ArrayList<>();
        clientGoalsDataList.add(clientGoalsData1);
        clientGoalsDataList.add(clientGoalsData2);

        return  clientGoalsDataList;
    }

}