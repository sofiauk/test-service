package com.optum.rqns.ftm.service.leaderopportunities;

import com.optum.rqns.ftm.constants.Constants;
import com.optum.rqns.ftm.enums.JobName;
import com.optum.rqns.ftm.enums.Status;
import com.optum.rqns.ftm.kafka.avro.models.v1.notification.JobEvent;
import com.optum.rqns.ftm.kafka.producer.JobEventProducer;
import com.optum.rqns.ftm.model.JobStatus;
import com.optum.rqns.ftm.model.ProgramYearCalendarDTO;
import com.optum.rqns.ftm.repository.common.CommonRepository;
import com.optum.rqns.ftm.repository.leaderopportunities.LeaderOpportunitiesCommonRepositoryImpl;
import com.optum.rqns.ftm.repository.users.UsersRepository;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        LeaderQualityGapsOpportunitiesServiceImpl.class
})
@SpringBootTest(properties = {
        "spring.db_connection_thread_pool_size=10",
})
public class LeaderQualityGapsServiceImplTest {

    @MockBean
    private LeaderOpportunitiesCommonRepositoryImpl leaderCommonOpportunitiesRepository;

    @MockBean
    private UsersRepository usersRepository;

    @MockBean
    private CommonRepository commonRepository;

    @InjectMocks
    private LeaderQualityGapsOpportunitiesServiceImpl leaderQualityGapsOpportunitiesService;

    @MockBean
    private JobEventProducer jobEventProducer;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    public static final List<String> LEADER_ROLES = Arrays.asList("RVP", "Director", "Manager");
    public static final List<String> IC_ROLES = Arrays.asList("PSC", "HCA");

    @Test
    public void executeJob() {

        JobStatus mockJobStatus = new JobStatus();
        mockJobStatus.setUpdatedRows(40l);
        mockJobStatus.setStatus(Status.SUCCESS);
        mockJobStatus.setMessage("Successfully completed Leader Quality Gaps opportunities job");

        mockLeaderDbCalls();

        final JobStatus jobStatus = leaderQualityGapsOpportunitiesService.executeJob(JobEvent.newBuilder().setProgramYear(2021).setJobName(JobName.LEADER_QUALITY_GAPS_OPPORTUNITIES.getValue()).setStatus(Status.SUCCESS.getValue()).build());

        Assert.assertEquals(mockJobStatus.getUpdatedRows(), jobStatus.getUpdatedRows());
        Assert.assertEquals(mockJobStatus.getStatus(), jobStatus.getStatus());

    }

    @Test
    public void calculateForAllUsers() {

        JobStatus mockJobStatus = new JobStatus();
        mockJobStatus.setUpdatedRows(40l);
        mockJobStatus.setStatus(Status.SUCCESS);
        mockJobStatus.setMessage("Successfully completed Leader Quality Gaps opportunities job");

        mockLeaderDbCalls();

        final JobStatus jobStatus = leaderQualityGapsOpportunitiesService.executeJob(JobEvent.newBuilder().setProgramYear(2021).setJobName(JobName.LEADER_QUALITY_GAPS_OPPORTUNITIES.getValue()).build());

        Assert.assertEquals(mockJobStatus.getUpdatedRows(), jobStatus.getUpdatedRows());
        Assert.assertEquals(mockJobStatus.getStatus(), jobStatus.getStatus());

    }

    private void mockLeaderDbCalls() {
        Mockito.when(commonRepository.getYTDDuration(Mockito.anyInt()))
                .thenReturn(ProgramYearCalendarDTO.builder().programYear(2021).build());

        Mockito.when(usersRepository.getUsersByRole(IC_ROLES))
                .thenReturn(Arrays.asList("HCA1", "PSC1"));
        Mockito.when(usersRepository.getUsersByRole(LEADER_ROLES))
                .thenReturn(Arrays.asList("Director1", "Manager1"));

        Mockito.when(usersRepository.getIcReporters("Director1"))
                .thenReturn(Arrays.asList("IC1", "IC2"));
        Mockito.when(usersRepository.getIcReporters("Manager1"))
                .thenReturn(new ArrayList<>());

        Mockito.when(leaderCommonOpportunitiesRepository.getServiceLevelForUser(
                "HCA1"
        )).thenReturn(Arrays.asList("HCA", "None"));
        Mockito.when(leaderCommonOpportunitiesRepository.getServiceLevelForUser(
                "PSC1"
        )).thenReturn(Arrays.asList("PSC"));
        Mockito.when(leaderCommonOpportunitiesRepository.calculateLeaderCommonOppData(
                Mockito.anyString(), Mockito.anyList(), Mockito.anyString(),Mockito.anyString()
        )).thenReturn(20);
        Mockito.when(leaderCommonOpportunitiesRepository.calculateICQualityGapsAndACVOppData(
                Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyInt(),Mockito.anyString())).thenReturn(10);
    }

    @Test
    public void calculateForAllUsersExceptionTest() {

        JobStatus mockJobStatus = new JobStatus();
        mockJobStatus.setUpdatedRows(50l);
        mockJobStatus.setStatus(Status.FAILURE);
        mockJobStatus.setMessage("Successfully completed Leader Quality Gaps opportunities job");

        mockLeaderDbCalls();

        Mockito.when(leaderCommonOpportunitiesRepository.calculateLeaderCommonOppData(
                Mockito.anyString(), Mockito.anyList(), Mockito.anyString(),Mockito.anyString()
        )).thenThrow(new RuntimeException("some Exception occured"));

        final JobStatus jobStatus = leaderQualityGapsOpportunitiesService.executeJob(JobEvent.newBuilder().setProgramYear(2021).setJobName(JobName.LEADER_QUALITY_GAPS_OPPORTUNITIES.getValue()).build());
        Assert.assertEquals(mockJobStatus.getStatus(), jobStatus.getStatus());

    }
}
