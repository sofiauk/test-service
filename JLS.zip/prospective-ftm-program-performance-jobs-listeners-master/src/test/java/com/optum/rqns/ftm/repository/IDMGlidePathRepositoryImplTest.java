package com.optum.rqns.ftm.repository;

import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;
import java.util.concurrent.Callable;

@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("test")
@ContextConfiguration(classes = {
        IDMGlidePathRepositoryImpl.class
})
@SpringBootTest(properties = {
        "spring.db_connection_thread_pool_size=10",
})
public class IDMGlidePathRepositoryImplTest {

    @MockBean
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @InjectMocks
    private IDMGlidePathRepositoryImpl idmGlidePathRepository;


    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }


    @Test
    public void getRecordCountTest() {
        String query = "SELECT COUNT(*) as recCount FROM ProgPerf.ProviderGroupPerformanceIDMGlidePath ";
        Mockito.when(namedParameterJdbcTemplate.queryForObject(query,new HashMap<>(),Long.class))
                .thenReturn(20l);

        final Long recordCount = idmGlidePathRepository.getRecordCount(true);

        assert recordCount == 20;
    }
    @Test
    public void getRecordCountModifiedTest() {
        String query = "SELECT COUNT(*) as recCount FROM ProgPerf.ProviderGroupPerformanceIDMGlidePath " +
                "where CAST(UpdatedDate as date) >= (select CAST(LastSuccessfulRunDate as date) " +
                "from ProgPerf.jobrunconfiguration where jobname= 'RunIDMGlidepathMergeToProvGroupPerf')";
        Mockito.when(namedParameterJdbcTemplate.queryForObject(query,new HashMap<>(),Long.class))
                .thenReturn(20l);

        final Long recordCount = idmGlidePathRepository.getRecordCount(false);

        assert recordCount == 20;
    }

    @Test
    public void mergeIDMDataAllTest() throws Exception {

        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(),Mockito.any(SqlParameterSource.class)))
                .thenReturn(20);

        final Callable<Integer> integerCallable = idmGlidePathRepository.mergeIDMData(25000, 0, true);

        assert integerCallable.call() == 20;
    }

    @Test
    public void mergeIDMDataModifiedTest() throws Exception {

        Mockito.when(namedParameterJdbcTemplate.update(Mockito.anyString(),Mockito.any(SqlParameterSource.class)))
                .thenReturn(20);

        final Callable<Integer> integerCallable = idmGlidePathRepository.mergeIDMData(25000, 0, false);

        assert integerCallable.call() == 20;
    }

}