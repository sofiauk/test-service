package com.optum.rqns.ftm.model;

import com.optum.rqns.ftm.util.GetterSetterTester;
import org.junit.Test;

import java.time.LocalDateTime;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class JobConfigurationRequestTest extends GetterSetterTester<JobConfigurationRequest> {

    @Override
    public JobConfigurationRequest getTestInstance() {
        return new JobConfigurationRequest();
    }

    @Test
    public void TestConfig() {
        assertNotNull(getTestInstance());
    }

    @Test
    public void testJobConfigurationRequest(){

        JobConfigurationRequest jobConfigurationRequest = new JobConfigurationRequest("test", false, LocalDateTime.now());

        assertEquals("test", jobConfigurationRequest.getJobName());
        assertEquals(false, jobConfigurationRequest.getIsActive());
    }
}