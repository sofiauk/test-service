# prospective-ftm-program-performance-jobs-listeners
Listeners for program performance jobs execution

# FTM Program Performance Jobs ListenersService
[![Build Status](https://jenkins-rqs-common.origin-ctc-core.optum.com/buildStatus/icon?job=RQNS%2FRQNS%2Fprospective-ftm-program-performance-jobs-listeners%2Fmaster)](https://jenkins-rqs-common.origin-ctc-core.optum.com/job/RQNS/job/RQNS/job/prospective-ftm-program-performance-jobs-listeners/job/master/)


##GCP certs - configuration changes for local setup
* Copy certs from REPO to local machine: https://github.optum.com/RQNS/prospective-ftm-common-certs
* Use local path in spring.gcpkafka.properties.certs.ofc.ssl - certs configuration like below (in application-{env}.yml file)-
* key-store-location: "C:/Users/msoni6/IdeaProjects/Common-Certs/certs/ofc/dev/keystore.jks"
* trust-store-location: "C:/Users/msoni6/IdeaProjects/Common-Certs/certs/ofc/dev/truststore.jks"